package main

import (
	"bytes"
	"crypto/sha256"
	"crypto/tls"
	"encoding/hex"
	"encoding/json"
	"io"
	"net"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// Exercises the real origin listener -> metering wrapper -> authenticated
// multiplexed WSS session -> TCP target, including padding and half-close.
func TestAccessRunOriginMetersRealStreamsAndHasNoListenBypass(t *testing.T) {
	const host = "access-origin.example.com"
	const token = "access-origin-integration-0123456789abcdef"
	baselineStreams, baselineMemory := activeStreams.Load(), memoryBudget.Load()
	t.Cleanup(func() { waitForStreamBaseline(t, baselineStreams, baselineMemory) })
	target := managedTestListener(t, func(c net.Conn) {
		_, _ = io.Copy(c, c)
		_ = c.(*net.TCPConn).CloseWrite()
	})
	allow, err := ParseAllowList(target.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	dir := t.TempDir()
	cert, err := loadOrCreateCert(filepath.Join(dir, "server.crt"), filepath.Join(dir, "server.key"), host, false)
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(cert.Certificate[0])
	cfg := &Config{Mode: "origin", Transport: TransportWSS, Token: token, SNI: host, WSHost: host,
		WSPath: "/access-integration", UTLSProfile: "chrome", Fingerprint: hex.EncodeToString(sum[:]),
		MinSessions: 1, Sessions: 1, Target: target.Addr().String(), allowList: allow, PadRatio: 0.17,
		AccessConfig: filepath.Join(dir, "access.json"), AccessState: filepath.Join(dir, "state.json")}
	limiter := NewAdaptiveRateLimiter(10, 5)
	frontend := managedTestListener(t, func(raw net.Conn) {
		_ = raw.SetDeadline(time.Now().Add(5 * time.Second))
		conn := tls.Server(raw, &tls.Config{Certificates: []tls.Certificate{cert},
			MinVersion: tls.VersionTLS13, NextProtos: []string{"http/1.1"}})
		if err := conn.Handshake(); err != nil {
			return
		}
		ws, ip, err := acceptServerWebSocket(conn, host, cfg.WSPath, token)
		if err != nil {
			return
		}
		_ = raw.SetDeadline(time.Time{})
		dispatchEgressConn(ws, ip, cfg, limiter)
	})
	cfg.Connect = frontend.Addr().String()
	reservePort := func() string {
		t.Helper()
		ln, err := net.Listen("tcp", "127.0.0.1:0")
		if err != nil {
			t.Fatal(err)
		}
		addr := ln.Addr().String()
		ln.Close()
		return addr
	}
	aAddr, bAddr := reservePort(), reservePort()
	cfg.Listen = reservePort()
	access := accessConfig{Version: 1, Accounts: []accessAccountConfig{
		{ID: "a", Name: "limited", Listen: aAddr, QuotaBytes: 64, Enabled: true},
		{ID: "b", Name: "other", Listen: bAddr, QuotaBytes: 1000, Enabled: true},
	}}
	if err := atomicAccessJSON(cfg.AccessConfig, access); err != nil {
		t.Fatal(err)
	}
	if err := initializeAccessState(cfg.AccessConfig, cfg.AccessState); err != nil {
		t.Fatal(err)
	}
	stop, exited := make(chan struct{}), make(chan struct{})
	result := make(chan error, 1)
	go func() { defer close(exited); result <- runOrigin(cfg, stop) }()
	t.Cleanup(func() {
		close(stop)
		reg.mu.Lock()
		var owned []*Session
		for sess := range reg.set {
			if sess.token == token {
				owned = append(owned, sess)
			}
		}
		reg.mu.Unlock()
		for _, sess := range owned {
			sess.Close()
		}
		awaitDone(t, exited)
	})
	waitUsage := func(id string, expected int64) {
		t.Helper()
		until := time.Now().Add(5 * time.Second)
		for time.Now().Before(until) {
			var status struct {
				Accounts []struct {
					ID   string `json:"id"`
					Used int64  `json:"used_bytes"`
				} `json:"accounts"`
			}
			b, err := os.ReadFile(cfg.AccessState + ".status.json")
			if err == nil && json.Unmarshal(b, &status) == nil {
				for _, a := range status.Accounts {
					if a.ID == id && a.Used == expected {
						return
					}
				}
			}
			select {
			case err := <-result:
				t.Fatalf("origin exited: %v", err)
			default:
			}
			time.Sleep(10 * time.Millisecond)
		}
		t.Fatalf("account %s did not reach usage %d", id, expected)
	}
	waitUsage("a", 0) // Initial status is emitted only after listeners start.
	if bypass, err := net.DialTimeout("tcp", cfg.Listen, 100*time.Millisecond); err == nil {
		bypass.Close()
		t.Fatal("origin opened unmetered -listen alongside customer listeners")
	}
	a, err := net.DialTimeout("tcp", aAddr, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer a.Close()
	_ = a.SetDeadline(time.Now().Add(5 * time.Second))
	payload := []byte("12345678")
	if _, err := a.Write(payload); err != nil {
		t.Fatal(err)
	}
	reply := make([]byte, len(payload))
	if _, err := io.ReadFull(a, reply); err != nil || !bytes.Equal(reply, payload) {
		t.Fatalf("metered tunnel echo failed: %q, %v", reply, err)
	}
	waitUsage("a", 16) // Exact client bytes; WSS/mux/padding are not billed.
	_, _ = a.Write(make([]byte, 48))
	waitUsage("a", 64)
	if _, err := a.Read(reply); err == nil {
		t.Fatal("exhausted customer connection remained usable")
	}
	b, err := net.DialTimeout("tcp", bAddr, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer b.Close()
	_ = b.SetDeadline(time.Now().Add(5 * time.Second))
	if _, err := b.Write(payload); err != nil {
		t.Fatal(err)
	}
	_ = b.(*net.TCPConn).CloseWrite()
	all, err := io.ReadAll(b)
	if err != nil || !bytes.Equal(all, payload) {
		t.Fatalf("other customer/half-close failed after exhaustion: %q, %v", all, err)
	}
	waitUsage("b", 16)
}

func TestCDNTLS12RequiresExplicitCompatibilityAndStillChecksPin(t *testing.T) {
	const host = "quota-test.example.com"
	const token = "quota-test-secret-0123456789abcdef"
	dir := t.TempDir()
	cert, err := loadOrCreateCert(filepath.Join(dir, "test.crt"), filepath.Join(dir, "test.key"), host, false)
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(cert.Certificate[0])
	server := managedTestListener(t, func(raw net.Conn) {
		_ = raw.SetDeadline(time.Now().Add(5 * time.Second))
		conn := tls.Server(raw, &tls.Config{Certificates: []tls.Certificate{cert},
			MinVersion: tls.VersionTLS12, MaxVersion: tls.VersionTLS12, NextProtos: []string{"http/1.1"}})
		if err := conn.Handshake(); err != nil {
			return // Wrong-pin/default-policy subcases intentionally reject.
		}
		ws, _, err := acceptServerWebSocket(conn, host, "/quota-test", token)
		if err == nil {
			_, _ = io.Copy(ws, ws)
		}
	})
	for _, tc := range []struct {
		name, minimum, pin string
		works              bool
	}{
		{"strict-default", "", hex.EncodeToString(sum[:]), false},
		{"strict-explicit", "1.3", hex.EncodeToString(sum[:]), false},
		{"compatibility", "1.2", hex.EncodeToString(sum[:]), true},
		{"wrong-pin", "1.2", strings.Repeat("0", 64), false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			cfg := &Config{Transport: TransportWSS, Token: token, SNI: host, WSHost: host,
				WSPath: "/quota-test", UTLSProfile: "chrome", Fingerprint: tc.pin, TLSMinVersion: tc.minimum}
			transport, err := newOriginTransport(cfg)
			if err != nil {
				t.Fatal(err)
			}
			conn, err := transport.dialWith(server.Addr().String(), TransportWSS)
			if (err == nil) != tc.works {
				t.Fatalf("dial = %v, expected works=%v", err, tc.works)
			}
			if conn != nil {
				defer conn.Close()
				_ = conn.SetDeadline(time.Now().Add(5 * time.Second))
				if _, err := conn.Write([]byte("hello")); err != nil {
					t.Fatal(err)
				}
				buf := make([]byte, 5)
				if _, err := io.ReadFull(conn, buf); err != nil || string(buf) != "hello" {
					t.Fatalf("compatibility payload = %q, %v", buf, err)
				}
			}
		})
	}
}

func TestAccessRealListenersHotReload(t *testing.T) {
	m := newQuotaTestManager(t, 0, 100, 100)
	// Select two actual ports, then let the manager acquire them itself.
	for i := range m.cfg.Accounts {
		ln, err := net.Listen("tcp", "127.0.0.1:0")
		if err != nil {
			t.Fatal(err)
		}
		m.cfg.Accounts[i].Listen = ln.Addr().String()
		ln.Close()
	}
	if err := atomicAccessJSON(m.configPath, m.cfg); err != nil {
		t.Fatal(err)
	}
	m.handle = func(c net.Conn) { defer c.Close(); _, _ = io.Copy(c, c) }
	if err := m.reload(); err != nil {
		t.Fatal(err)
	}
	first, err := net.DialTimeout("tcp", m.cfg.Accounts[0].Listen, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer first.Close()
	_ = first.SetDeadline(time.Now().Add(3 * time.Second))
	if _, err := first.Write([]byte("ping")); err != nil {
		t.Fatal(err)
	}
	buf := make([]byte, 4)
	if _, err := io.ReadFull(first, buf); err != nil || string(buf) != "ping" {
		t.Fatalf("echo = %q, %v", buf, err)
	}
	changed := m.cfg
	changed.Accounts = append([]accessAccountConfig(nil), changed.Accounts...)
	changed.Accounts[0].Enabled = false
	if err := atomicAccessJSON(m.configPath, changed); err != nil {
		t.Fatal(err)
	}
	if err := m.reload(); err != nil {
		t.Fatal(err)
	}
	if _, err := first.Read(buf); err == nil {
		t.Fatal("disabled account connection was left open")
	}
	second, err := net.DialTimeout("tcp", m.cfg.Accounts[1].Listen, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer second.Close()
	_ = second.SetDeadline(time.Now().Add(3 * time.Second))
	if _, err := second.Write([]byte("pong")); err != nil {
		t.Fatal(err)
	}
	if _, err := io.ReadFull(second, buf); err != nil || string(buf) != "pong" {
		t.Fatalf("other account stopped during reload: %q, %v", buf, err)
	}
	// Wait for the successful socket write's accounting commit.
	deadline := time.Now().Add(time.Second)
	for time.Now().Before(deadline) {
		m.mu.Lock()
		used := m.totalUsed
		m.mu.Unlock()
		if used == 16 {
			return
		}
		time.Sleep(time.Millisecond)
	}
	t.Fatal("upload/download socket accounting did not total 16")
}
