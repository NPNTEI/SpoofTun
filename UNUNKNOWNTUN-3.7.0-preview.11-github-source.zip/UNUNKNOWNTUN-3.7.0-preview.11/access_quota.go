package main

// Access accounting happens at the local client socket, before tunnel framing
// and padding. Durable reservations make a crash conservative: at most 64 KiB
// per active account can be charged without having actually crossed the socket.
import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"math"
	"net"
	"os"
	"os/signal"
	"path/filepath"
	"regexp"
	"sort"
	"strings"
	"sync"
	"syscall"
	"time"

	"golang.org/x/sys/unix"
)

const accessReservation = int64(64 * 1024)

var errAccessQuota = errors.New("customer or tunnel traffic quota exhausted")
var accessIDPattern = regexp.MustCompile(`^[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}$`)

type accessAccountConfig struct {
	ID         string `json:"id"`
	Name       string `json:"name"`
	Listen     string `json:"listen"`
	QuotaBytes int64  `json:"quota_bytes"`
	Enabled    bool   `json:"enabled"`
}

type accessConfig struct {
	Version         int                   `json:"version"`
	TotalQuotaBytes int64                 `json:"total_quota_bytes"`
	Accounts        []accessAccountConfig `json:"accounts"`
}

type accessDisk struct {
	Version        int              `json:"version"`
	TotalUsedBytes int64            `json:"total_used_bytes"`
	Accounts       map[string]int64 `json:"accounts"`
	Checksum       string           `json:"checksum"`
}

type accessAccount struct {
	config  accessAccountConfig
	used    int64
	pending int64
	ceiling int64
	conns   map[*accessConn]struct{}
}

type accessListener struct {
	id string
	ln net.Listener
}

type accessManager struct {
	mu           sync.Mutex
	cond         *sync.Cond
	configPath   string
	statePath    string
	revision     string
	cfg          accessConfig
	accounts     map[string]*accessAccount
	listeners    map[string]accessListener
	totalUsed    int64
	totalPending int64
	lock         *os.File
	failure      error
	closed       bool
	stop         chan struct{}
	wg           sync.WaitGroup
	handle       func(net.Conn)
}

func decodeAccessJSON(data []byte, out any) error {
	dec := json.NewDecoder(strings.NewReader(string(data)))
	dec.DisallowUnknownFields()
	if err := dec.Decode(out); err != nil {
		return err
	}
	if err := dec.Decode(new(any)); err != io.EOF {
		return errors.New("trailing JSON data")
	}
	return nil
}

func readAccessConfig(path string) (accessConfig, string, error) {
	var cfg accessConfig
	data, err := os.ReadFile(path)
	if err != nil {
		return cfg, "", err
	}
	if len(data) > 1024*1024 {
		return cfg, "", errors.New("access config exceeds 1 MiB")
	}
	if err := decodeAccessJSON(data, &cfg); err != nil {
		return cfg, "", fmt.Errorf("access config: %w", err)
	}
	if cfg.Version != 1 || cfg.TotalQuotaBytes < 0 || len(cfg.Accounts) > 4096 {
		return cfg, "", errors.New("invalid access config version, quota or account count")
	}
	ids, addresses := map[string]bool{}, map[string]bool{}
	for _, a := range cfg.Accounts {
		if !accessIDPattern.MatchString(a.ID) || ids[a.ID] || a.QuotaBytes < 0 || len(a.Name) > 256 {
			return cfg, "", fmt.Errorf("invalid or duplicate access account %q", a.ID)
		}
		ids[a.ID] = true
		addrs, err := parseAddressList(a.Listen, "account listen", true)
		if err != nil {
			return cfg, "", fmt.Errorf("account %s: %w", a.ID, err)
		}
		for _, addr := range addrs {
			host, port, _ := net.SplitHostPort(addr)
			if net.ParseIP(host) == nil || port == "0" {
				return cfg, "", fmt.Errorf("account %s needs a numeric IP and nonzero listen port", a.ID)
			}
			if addresses[addr] {
				return cfg, "", fmt.Errorf("duplicate customer listen address %s", addr)
			}
			addresses[addr] = true
		}
	}
	sum := sha256.Sum256(data)
	return cfg, hex.EncodeToString(sum[:]), nil
}

func accessDiskChecksum(d accessDisk) string {
	d.Checksum = ""
	b, _ := json.Marshal(d)
	sum := sha256.Sum256(b)
	return hex.EncodeToString(sum[:])
}

func readAccessDisk(path string) (accessDisk, error) {
	var d accessDisk
	info, err := os.Lstat(path)
	if err != nil {
		return d, fmt.Errorf("access state unavailable; refusing to reset usage: %w", err)
	}
	if !info.Mode().IsRegular() || info.Mode().Perm()&0077 != 0 {
		return d, errors.New("access state must be a private regular file (0600)")
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return d, fmt.Errorf("access state unavailable; refusing to reset usage: %w", err)
	}
	if len(b) > 16*1024*1024 {
		return d, errors.New("access state exceeds 16 MiB")
	}
	if err := decodeAccessJSON(b, &d); err != nil {
		return d, fmt.Errorf("access state corrupt: %w", err)
	}
	if d.Version != 1 || d.Accounts == nil || d.TotalUsedBytes < 0 || d.Checksum != accessDiskChecksum(d) {
		return d, errors.New("access state invalid/checksum mismatch; refusing to reset usage")
	}
	var sum int64
	for id, used := range d.Accounts {
		if !accessIDPattern.MatchString(id) || used < 0 || used > math.MaxInt64-sum {
			return d, errors.New("invalid account usage in access state")
		}
		sum += used
	}
	if sum != d.TotalUsedBytes {
		return d, errors.New("access state totals do not match")
	}
	return d, nil
}

func atomicAccessJSON(path string, value any) (err error) {
	b, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	f, err := os.CreateTemp(filepath.Dir(path), ".access-*")
	if err != nil {
		return err
	}
	defer os.Remove(f.Name())
	defer f.Close()
	if err = f.Chmod(0600); err != nil {
		return err
	}
	if _, err = f.Write(append(b, '\n')); err != nil {
		return err
	}
	if err = f.Sync(); err != nil {
		return err
	}
	if err = f.Close(); err != nil {
		return err
	}
	if err = os.Rename(f.Name(), path); err != nil {
		return err
	}
	dir, err := os.Open(filepath.Dir(path))
	if err != nil {
		return err
	}
	defer dir.Close()
	return dir.Sync()
}

func lockAccessState(path string) (*os.File, error) {
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return nil, err
	}
	f, err := os.OpenFile(path+".lock", os.O_CREATE|os.O_RDWR, 0600)
	if err != nil {
		return nil, err
	}
	if err := unix.Flock(int(f.Fd()), unix.LOCK_EX|unix.LOCK_NB); err != nil {
		f.Close()
		return nil, fmt.Errorf("access state already in use: %w", err)
	}
	return f, nil
}

func initializeAccessState(configPath, statePath string) error {
	cfg, _, err := readAccessConfig(configPath)
	if err != nil {
		return err
	}
	lock, err := lockAccessState(statePath)
	if err != nil {
		return err
	}
	defer lock.Close()
	if _, err := os.Lstat(statePath); !errors.Is(err, os.ErrNotExist) {
		return errors.New("access state already exists or cannot be inspected; initialization refused")
	}
	d := accessDisk{Version: 1, Accounts: map[string]int64{}}
	for _, a := range cfg.Accounts {
		d.Accounts[a.ID] = 0
	}
	d.Checksum = accessDiskChecksum(d)
	return atomicAccessJSON(statePath, d)
}

func openAccessManager(configPath, statePath string) (*accessManager, error) {
	lock, err := lockAccessState(statePath)
	if err != nil {
		return nil, err
	}
	d, err := readAccessDisk(statePath)
	if err != nil {
		lock.Close()
		return nil, err
	}
	m := &accessManager{configPath: configPath, statePath: statePath, lock: lock,
		accounts: map[string]*accessAccount{}, listeners: map[string]accessListener{}, stop: make(chan struct{})}
	m.cond = sync.NewCond(&m.mu)
	for id, used := range d.Accounts {
		m.accounts[id] = &accessAccount{config: accessAccountConfig{ID: id}, used: used, ceiling: used, conns: map[*accessConn]struct{}{}}
		m.totalUsed += used
	}
	return m, nil
}

func (m *accessManager) persistLocked() error {
	d := accessDisk{Version: 1, Accounts: map[string]int64{}}
	for id, a := range m.accounts {
		d.Accounts[id] = a.ceiling
		d.TotalUsedBytes += a.ceiling
	}
	d.Checksum = accessDiskChecksum(d)
	return atomicAccessJSON(m.statePath, d)
}

func (m *accessManager) allowedLocked(a *accessAccount) int64 {
	if m.closed || m.failure != nil || !a.config.Enabled {
		return 0
	}
	n := int64(math.MaxInt64) - m.totalUsed - m.totalPending
	n = min(n, accessReservation-a.pending)
	if a.config.QuotaBytes > 0 {
		n = min(n, a.config.QuotaBytes-a.used-a.pending)
	}
	if m.cfg.TotalQuotaBytes > 0 {
		n = min(n, m.cfg.TotalQuotaBytes-m.totalUsed-m.totalPending)
	}
	return max(0, n)
}

// reserve persists a conservative high-water mark BEFORE allowing any bytes.
func (m *accessManager) reserve(c *accessConn, want int, write bool) (int, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	a := c.account
	for {
		if (a.config.QuotaBytes > 0 && a.used >= a.config.QuotaBytes) ||
			(m.cfg.TotalQuotaBytes > 0 && m.totalUsed >= m.cfg.TotalQuotaBytes) {
			return 0, errAccessQuota
		}
		if c.closed {
			return 0, net.ErrClosed
		}
		deadline := c.readDeadline
		if write {
			deadline = c.writeDeadline
		}
		if !deadline.IsZero() && !time.Now().Before(deadline) {
			return 0, os.ErrDeadlineExceeded
		}
		if m.allowedLocked(a) > 0 {
			break
		}
		if m.closed || m.failure != nil || !a.config.Enabled ||
			(a.config.QuotaBytes > 0 && a.used >= a.config.QuotaBytes) ||
			(m.cfg.TotalQuotaBytes > 0 && m.totalUsed >= m.cfg.TotalQuotaBytes) ||
			m.totalUsed == math.MaxInt64 {
			return 0, errAccessQuota
		}
		var timer *time.Timer
		if !deadline.IsZero() {
			timer = time.AfterFunc(time.Until(deadline), func() {
				m.mu.Lock()
				m.cond.Broadcast()
				m.mu.Unlock()
			})
		}
		m.cond.Wait() // Another in-flight write holds the last bytes.
		if timer != nil {
			timer.Stop()
		}
	}
	n := min(int64(want), m.allowedLocked(a))
	if a.ceiling < a.used+a.pending+n {
		// Reclaim unused reservations from other accounts. This prevents an
		// idle account from holding the final bytes of the shared tunnel quota.
		for _, other := range m.accounts {
			other.ceiling = other.used + other.pending
		}
		extra := min(max(n, accessReservation), m.allowedLocked(a))
		a.ceiling += extra
		if err := m.persistLocked(); err != nil {
			m.failure = fmt.Errorf("persist access reservation: %w", err)
			m.cond.Broadcast()
			go m.closeConnections(nil)
			return 0, m.failure
		}
	}
	a.pending += n
	m.totalPending += n
	return int(n), nil
}

func (m *accessManager) finish(a *accessAccount, reserved, used int) {
	m.mu.Lock()
	a.pending -= int64(reserved)
	m.totalPending -= int64(reserved)
	a.used += int64(used)
	m.totalUsed += int64(used)
	exhausted := a.config.QuotaBytes > 0 && a.used >= a.config.QuotaBytes
	allExhausted := m.cfg.TotalQuotaBytes > 0 && m.totalUsed >= m.cfg.TotalQuotaBytes
	m.cond.Broadcast()
	m.mu.Unlock()
	if allExhausted {
		m.closeConnections(nil)
	} else if exhausted {
		m.closeConnections(a)
	}
}

func (m *accessManager) closeConnections(only *accessAccount) {
	m.mu.Lock()
	var conns []*accessConn
	for _, a := range m.accounts {
		if only == nil || only == a {
			for c := range a.conns {
				conns = append(conns, c)
			}
		}
	}
	m.mu.Unlock()
	for _, c := range conns {
		_ = c.Close()
	}
}

func (m *accessManager) wrap(id string, c net.Conn) (*accessConn, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	a := m.accounts[id]
	if a == nil || m.closed || m.failure != nil || !a.config.Enabled ||
		(a.config.QuotaBytes > 0 && a.used >= a.config.QuotaBytes) ||
		(m.cfg.TotalQuotaBytes > 0 && m.totalUsed >= m.cfg.TotalQuotaBytes) {
		_ = c.Close()
		return nil, errAccessQuota
	}
	wrapped := &accessConn{Conn: c, manager: m, account: a}
	a.conns[wrapped] = struct{}{}
	return wrapped, nil
}

type accessConn struct {
	net.Conn
	manager       *accessManager
	account       *accessAccount
	once          sync.Once
	closed        bool // Guarded by manager.mu, including deadline fields.
	readDeadline  time.Time
	writeDeadline time.Time
}

func (c *accessConn) Read(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}
	// Reading before reservation does not pass any excess bytes into the
	// tunnel, and avoids idle reads reserving quota needed by writes.
	n, readErr := c.Conn.Read(p[:min(int64(len(p)), accessReservation)])
	if n == 0 {
		return n, readErr
	}
	allowed, err := c.manager.reserve(c, n, false)
	if err != nil {
		return 0, err
	}
	c.manager.finish(c.account, allowed, allowed)
	if allowed < n {
		return allowed, errAccessQuota
	}
	return allowed, readErr
}

func (c *accessConn) Write(p []byte) (int, error) {
	written := 0
	for len(p) > 0 {
		allowed, err := c.manager.reserve(c, len(p), true)
		if err != nil {
			return written, err
		}
		n, writeErr := c.Conn.Write(p[:allowed])
		c.manager.finish(c.account, allowed, n)
		written += n
		p = p[n:]
		if writeErr != nil {
			return written, writeErr
		}
		if n < allowed {
			return written, io.ErrShortWrite
		}
	}
	return written, nil
}

func (c *accessConn) Close() error {
	var err error
	c.once.Do(func() {
		c.manager.mu.Lock()
		c.closed = true
		delete(c.account.conns, c)
		c.manager.cond.Broadcast()
		c.manager.mu.Unlock()
		err = c.Conn.Close()
	})
	return err
}

func (c *accessConn) SetDeadline(t time.Time) error {
	if err := c.Conn.SetDeadline(t); err != nil {
		return err
	}
	c.manager.mu.Lock()
	c.readDeadline, c.writeDeadline = t, t
	c.manager.cond.Broadcast()
	c.manager.mu.Unlock()
	return nil
}

func (c *accessConn) SetReadDeadline(t time.Time) error {
	if err := c.Conn.SetReadDeadline(t); err != nil {
		return err
	}
	c.manager.mu.Lock()
	c.readDeadline = t
	c.manager.cond.Broadcast()
	c.manager.mu.Unlock()
	return nil
}

func (c *accessConn) SetWriteDeadline(t time.Time) error {
	if err := c.Conn.SetWriteDeadline(t); err != nil {
		return err
	}
	c.manager.mu.Lock()
	c.writeDeadline = t
	c.manager.cond.Broadcast()
	c.manager.mu.Unlock()
	return nil
}

func (c *accessConn) CloseWrite() error {
	if conn, ok := c.Conn.(interface{ CloseWrite() error }); ok {
		return conn.CloseWrite()
	}
	return nil
}

func (c *accessConn) SetLinger(seconds int) error {
	if conn, ok := c.Conn.(interface{ SetLinger(int) error }); ok {
		return conn.SetLinger(seconds)
	}
	return nil
}

func (m *accessManager) reload() error {
	cfg, revision, err := readAccessConfig(m.configPath)
	if err != nil {
		return err
	}
	// Reload is called only by the owning run loop.
	wanted := map[string]string{}
	for _, a := range cfg.Accounts {
		if a.Enabled {
			addrs, _ := parseAddressList(a.Listen, "account listen", true)
			for _, addr := range addrs {
				wanted[addr] = a.ID
			}
		}
	}
	opened := map[string]accessListener{}
	for addr, id := range wanted {
		if old, exists := m.listeners[addr]; exists {
			if old.id != id {
				err = fmt.Errorf("port %s belongs to another account; restart to reassign it", addr)
				break
			}
			continue
		}
		var ln net.Listener
		ln, err = net.Listen("tcp", addr)
		if err != nil {
			break
		}
		opened[addr] = accessListener{id: id, ln: ln}
	}
	if err != nil {
		for _, l := range opened {
			l.ln.Close()
		}
		return err
	}
	m.mu.Lock()
	var reducedAccounts []*accessAccount
	for _, conf := range cfg.Accounts {
		if old := m.accounts[conf.ID]; old != nil && conf.QuotaBytes > 0 &&
			(old.config.QuotaBytes == 0 || conf.QuotaBytes < old.config.QuotaBytes) {
			reducedAccounts = append(reducedAccounts, old)
		}
	}
	totalReduced := cfg.TotalQuotaBytes > 0 &&
		(m.cfg.TotalQuotaBytes == 0 || cfg.TotalQuotaBytes < m.cfg.TotalQuotaBytes)
	for _, a := range m.accounts {
		a.config.Enabled = false
	}
	for _, conf := range cfg.Accounts {
		a := m.accounts[conf.ID]
		if a == nil {
			a = &accessAccount{conns: map[*accessConn]struct{}{}}
			m.accounts[conf.ID] = a
		}
		a.config = conf
	}
	m.cfg, m.revision = cfg, revision
	if err = m.persistLocked(); err != nil {
		m.failure = err
	}
	m.cond.Broadcast()
	closeAccounts := reducedAccounts
	for _, a := range m.accounts {
		if !a.config.Enabled || (a.config.QuotaBytes > 0 && a.used >= a.config.QuotaBytes) {
			closeAccounts = append(closeAccounts, a)
		}
	}
	allBlocked := m.failure != nil || totalReduced || (cfg.TotalQuotaBytes > 0 && m.totalUsed >= cfg.TotalQuotaBytes)
	m.mu.Unlock()
	if allBlocked {
		m.closeConnections(nil)
	} else {
		for _, a := range closeAccounts {
			m.closeConnections(a)
		}
	}
	if err != nil {
		for _, l := range opened {
			l.ln.Close()
		}
		return err
	}
	for addr, l := range m.listeners {
		if _, keep := wanted[addr]; !keep {
			l.ln.Close()
			delete(m.listeners, addr)
		}
	}
	for addr, l := range opened {
		m.listeners[addr] = l
		m.wg.Add(1)
		go m.accept(l)
	}
	return m.writeStatus()
}

func (m *accessManager) accept(l accessListener) {
	defer m.wg.Done()
	for {
		conn, err := l.ln.Accept()
		if err != nil {
			if errors.Is(err, net.ErrClosed) {
				return
			}
			select {
			case <-m.stop:
				return
			case <-time.After(50 * time.Millisecond):
				continue
			}
		}
		if tc, ok := conn.(*net.TCPConn); ok {
			configureTCPConn(tc)
		}
		wrapped, err := m.wrap(l.id, conn)
		if err != nil {
			continue
		}
		select {
		case localAcceptSlots <- struct{}{}:
			go func() {
				defer func() { <-localAcceptSlots }()
				m.handle(wrapped)
			}()
		default:
			wrapped.Close()
		}
	}
}

func (m *accessManager) writeStatus() error {
	m.mu.Lock()
	defer m.mu.Unlock()
	accounts := make([]map[string]any, 0, len(m.cfg.Accounts))
	for _, cfg := range m.cfg.Accounts {
		a := m.accounts[cfg.ID]
		remaining := int64(-1)
		if cfg.QuotaBytes > 0 {
			remaining = max(0, cfg.QuotaBytes-a.used)
		}
		accounts = append(accounts, map[string]any{"id": cfg.ID, "name": cfg.Name,
			"listen": cfg.Listen, "enabled": cfg.Enabled, "quota_bytes": cfg.QuotaBytes,
			"used_bytes": a.used, "reserved_bytes": a.ceiling, "remaining_bytes": remaining,
			"blocked": !cfg.Enabled || m.failure != nil || m.closed ||
				(cfg.QuotaBytes > 0 && a.used >= cfg.QuotaBytes) ||
				(m.cfg.TotalQuotaBytes > 0 && m.totalUsed >= m.cfg.TotalQuotaBytes), "connections": len(a.conns)})
	}
	sort.Slice(accounts, func(i, j int) bool { return accounts[i]["id"].(string) < accounts[j]["id"].(string) })
	status := map[string]any{"version": 1, "updated_at": time.Now().UTC().Format(time.RFC3339),
		"config_revision": m.revision, "total_used_bytes": m.totalUsed, "total_quota_bytes": m.cfg.TotalQuotaBytes,
		"accounts": accounts, "running": !m.closed, "error": ""}
	if m.failure != nil {
		status["error"] = m.failure.Error()
	}
	return atomicAccessJSON(m.statePath+".status.json", status)
}

func (m *accessManager) Close() error {
	m.mu.Lock()
	if m.closed {
		m.mu.Unlock()
		return nil
	}
	m.closed = true
	close(m.stop)
	m.cond.Broadcast()
	m.mu.Unlock()
	for _, l := range m.listeners {
		l.ln.Close()
	}
	m.wg.Wait()
	m.closeConnections(nil)
	// Keep the already durable high-water marks at shutdown. In-flight I/O
	// may still be completing; lowering them here would risk free traffic.
	_ = m.writeStatus()
	return m.lock.Close()
}

func runAccessListeners(configPath, statePath string, done <-chan struct{}, handle func(net.Conn)) error {
	m, err := openAccessManager(configPath, statePath)
	if err != nil {
		return err
	}
	defer m.Close()
	hup := make(chan os.Signal, 1)
	signal.Notify(hup, syscall.SIGHUP)
	defer signal.Stop(hup)
	m.handle = handle
	if err := m.reload(); err != nil {
		return err
	}
	log.Printf("[access] %d customer listeners active, accounting upload + download", len(m.listeners))
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()
	for {
		select {
		case <-done:
			return nil
		case <-hup:
			if err := m.reload(); err != nil {
				log.Printf("[access] reload rejected: %v", err)
			} else {
				log.Printf("[access] customer config reloaded")
			}
		case <-ticker.C:
			if err := m.writeStatus(); err != nil {
				log.Printf("[access] status snapshot: %v", err)
			}
		}
	}
}
