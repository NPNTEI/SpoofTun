package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"net"
	"os"
	"path/filepath"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

type quotaTestConn struct {
	input  *bytes.Reader
	output atomic.Int64
	closed atomic.Bool
}

func (c *quotaTestConn) Read(p []byte) (int, error) {
	if c.closed.Load() {
		return 0, net.ErrClosed
	}
	return c.input.Read(p)
}
func (c *quotaTestConn) Write(p []byte) (int, error) {
	if c.closed.Load() {
		return 0, net.ErrClosed
	}
	c.output.Add(int64(len(p)))
	return len(p), nil
}
func (c *quotaTestConn) Close() error                     { c.closed.Store(true); return nil }
func (c *quotaTestConn) LocalAddr() net.Addr              { return &net.TCPAddr{} }
func (c *quotaTestConn) RemoteAddr() net.Addr             { return &net.TCPAddr{} }
func (c *quotaTestConn) SetDeadline(time.Time) error      { return nil }
func (c *quotaTestConn) SetReadDeadline(time.Time) error  { return nil }
func (c *quotaTestConn) SetWriteDeadline(time.Time) error { return nil }

func newQuotaTestManager(t *testing.T, total int64, quotas ...int64) *accessManager {
	t.Helper()
	dir := t.TempDir()
	cfg := accessConfig{Version: 1, TotalQuotaBytes: total}
	for i, q := range quotas {
		cfg.Accounts = append(cfg.Accounts, accessAccountConfig{ID: string(rune('a' + i)), Name: "Customer", Listen: "127.0.0.1:" + stringPort(20000+i), QuotaBytes: q, Enabled: true})
	}
	configPath, statePath := filepath.Join(dir, "access.json"), filepath.Join(dir, "state.json")
	if err := atomicAccessJSON(configPath, cfg); err != nil {
		t.Fatal(err)
	}
	if err := initializeAccessState(configPath, statePath); err != nil {
		t.Fatal(err)
	}
	m, err := openAccessManager(configPath, statePath)
	if err != nil {
		t.Fatal(err)
	}
	m.cfg = cfg
	for _, a := range cfg.Accounts {
		m.accounts[a.ID].config = a
	}
	t.Cleanup(func() { _ = m.Close() })
	return m
}

func stringPort(n int) string {
	b, _ := json.Marshal(n)
	return string(b)
}

func quotaWrap(t *testing.T, m *accessManager, id, input string) (*accessConn, *quotaTestConn) {
	t.Helper()
	c := &quotaTestConn{input: bytes.NewReader([]byte(input))}
	w, err := m.wrap(id, c)
	if err != nil {
		t.Fatal(err)
	}
	return w, c
}

func TestAccessCombinedUploadDownloadAndIsolation(t *testing.T) {
	m := newQuotaTestManager(t, 0, 10, 100)
	a, rawA := quotaWrap(t, m, "a", "1234")
	otherA, rawOtherA := quotaWrap(t, m, "a", "")
	defer otherA.Close()
	b, rawB := quotaWrap(t, m, "b", "")
	buf := make([]byte, 10)
	if n, err := a.Read(buf); n != 4 || err != nil {
		t.Fatalf("read = %d, %v", n, err)
	}
	if n, err := a.Write([]byte("123456789")); n != 6 || !errors.Is(err, errAccessQuota) {
		t.Fatalf("write = %d, %v", n, err)
	}
	if m.accounts["a"].used != 10 || rawA.output.Load() != 6 || !rawA.closed.Load() || !rawOtherA.closed.Load() {
		t.Fatal("account was not charged/stopped exactly at its combined quota")
	}
	if rawB.closed.Load() {
		t.Fatal("unrelated account was closed")
	}
	if n, err := b.Write([]byte("still works")); n != 11 || err != nil {
		t.Fatalf("unrelated account write = %d, %v", n, err)
	}
	newConn := &quotaTestConn{}
	if _, err := m.wrap("a", newConn); !errors.Is(err, errAccessQuota) || !newConn.closed.Load() {
		t.Fatal("exhausted account accepted a new connection")
	}
}

func TestAccessConcurrentQuotaIsStrict(t *testing.T) {
	m := newQuotaTestManager(t, 0, 12345)
	var wg sync.WaitGroup
	var passed atomic.Int64
	start := make(chan struct{})
	for range 40 {
		c, _ := quotaWrap(t, m, "a", "")
		wg.Add(1)
		go func() {
			defer wg.Done()
			<-start
			for range 30 {
				n, err := c.Write(bytes.Repeat([]byte{'a'}, 137))
				passed.Add(int64(n))
				if err != nil {
					return
				}
			}
		}()
	}
	close(start)
	wg.Wait()
	if passed.Load() != 12345 || m.totalUsed != 12345 {
		t.Fatalf("concurrent traffic %d / charged %d, expected exact cap 12345", passed.Load(), m.totalUsed)
	}
}

func TestAccessTotalQuotaAcrossAccounts(t *testing.T) {
	m := newQuotaTestManager(t, 15, 0, 0)
	a, _ := quotaWrap(t, m, "a", "")
	b, rawB := quotaWrap(t, m, "b", "")
	if _, err := a.Write([]byte("1234567890")); err != nil {
		t.Fatal(err)
	}
	if n, err := b.Write([]byte("1234567890")); n != 5 || !errors.Is(err, errAccessQuota) {
		t.Fatalf("shared limit = %d, %v", n, err)
	}
	if !rawB.closed.Load() || m.totalUsed != 15 {
		t.Fatal("shared tunnel quota was not enforced")
	}
}

func TestAccessUnlimitedAndLargeWrite(t *testing.T) {
	m := newQuotaTestManager(t, 0, 0)
	a, _ := quotaWrap(t, m, "a", "")
	p := make([]byte, 4*accessReservation+123)
	if n, err := a.Write(p); n != len(p) || err != nil {
		t.Fatalf("unlimited write = %d, %v", n, err)
	}
	if m.accounts["a"].ceiling-m.accounts["a"].used > accessReservation {
		t.Fatal("unused crash reservation exceeded bound")
	}
}

func TestAccessRestartChargesDurableReservation(t *testing.T) {
	m := newQuotaTestManager(t, 0, 1000000)
	a, _ := quotaWrap(t, m, "a", "")
	if _, err := a.Write([]byte("abc")); err != nil {
		t.Fatal(err)
	}
	state, err := readAccessDisk(m.statePath)
	if err != nil || state.Accounts["a"] != accessReservation {
		t.Fatalf("durable reservation = %#v, %v", state, err)
	}
	if err := m.Close(); err != nil {
		t.Fatal(err)
	}
	restarted, err := openAccessManager(m.configPath, m.statePath)
	if err != nil {
		t.Fatal(err)
	}
	defer restarted.Close()
	if restarted.accounts["a"].used != accessReservation {
		t.Fatal("restart forgot traffic reservation")
	}
	info, _ := os.Stat(m.statePath)
	if info.Mode().Perm() != 0600 {
		t.Fatalf("state permissions = %o", info.Mode().Perm())
	}
}

func TestAccessMissingCorruptStateAndExclusiveLock(t *testing.T) {
	m := newQuotaTestManager(t, 0, 100)
	if _, err := openAccessManager(m.configPath, m.statePath); err == nil {
		t.Fatal("second writer acquired state")
	}
	if err := initializeAccessState(m.configPath, m.statePath); err == nil {
		t.Fatal("initialization overwrote live state")
	}
	m.Close()
	if err := initializeAccessState(m.configPath, m.statePath); err == nil {
		t.Fatal("initialization overwrote existing state")
	}
	if err := os.Chmod(m.statePath, 0644); err != nil {
		t.Fatal(err)
	}
	if _, err := openAccessManager(m.configPath, m.statePath); err == nil {
		t.Fatal("publicly readable state accepted")
	}
	if err := os.Chmod(m.statePath, 0600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(m.statePath, []byte(`{"version":1,"accounts":{},"total_used_bytes":0,"checksum":"bad"}`), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := openAccessManager(m.configPath, m.statePath); err == nil {
		t.Fatal("corrupt state silently reset")
	}
	if err := os.Remove(m.statePath); err != nil {
		t.Fatal(err)
	}
	if _, err := openAccessManager(m.configPath, m.statePath); err == nil {
		t.Fatal("missing state silently reset")
	}
}

func TestAccessPersistenceFailureDeniesTraffic(t *testing.T) {
	m := newQuotaTestManager(t, 0, 100)
	c, raw := quotaWrap(t, m, "a", "")
	m.statePath = filepath.Join(t.TempDir(), "missing-directory", "state.json")
	if n, err := c.Write([]byte("abc")); n != 0 || err == nil || raw.output.Load() != 0 {
		t.Fatalf("unaccounted traffic leaked = %d, %v", n, err)
	}
	if _, err := m.wrap("a", &quotaTestConn{}); err == nil {
		t.Fatal("account admitted after state persistence failed")
	}
}

func TestAccessConfigValidation(t *testing.T) {
	for name, data := range map[string]string{
		"bad version":      `{"version":2,"accounts":[]}`,
		"negative quota":   `{"version":1,"total_quota_bytes":-1,"accounts":[]}`,
		"duplicate id":     `{"version":1,"accounts":[{"id":"a","listen":"127.0.0.1:1000"},{"id":"a","listen":"127.0.0.1:1001"}]}`,
		"duplicate listen": `{"version":1,"accounts":[{"id":"a","listen":"127.0.0.1:1000"},{"id":"b","listen":"127.0.0.1:1000"}]}`,
		"hostname listen":  `{"version":1,"accounts":[{"id":"a","listen":"localhost:1000"}]}`,
		"unknown field":    `{"version":1,"accounts":[],"typo":true}`,
	} {
		t.Run(name, func(t *testing.T) {
			path := filepath.Join(t.TempDir(), "config.json")
			if err := os.WriteFile(path, []byte(data), 0600); err != nil {
				t.Fatal(err)
			}
			if _, _, err := readAccessConfig(path); err == nil {
				t.Fatal("invalid config accepted")
			}
		})
	}
}

func TestAccessReadDoesNotForwardExcess(t *testing.T) {
	m := newQuotaTestManager(t, 0, 3)
	c, _ := quotaWrap(t, m, "a", "123456789")
	buf := make([]byte, 20)
	n, err := c.Read(buf)
	if n != 3 || string(buf[:n]) != "123" || !errors.Is(err, errAccessQuota) {
		t.Fatalf("excess bytes escaped: %d %v", n, err)
	}
}

func TestAccessReloadDisableRetainsUsageAndRejectsInvalid(t *testing.T) {
	m := newQuotaTestManager(t, 0, 100)
	c, raw := quotaWrap(t, m, "a", "")
	if _, err := c.Write([]byte("test")); err != nil {
		t.Fatal(err)
	}
	config := m.cfg
	config.Accounts[0].Enabled = false
	if err := atomicAccessJSON(m.configPath, config); err != nil {
		t.Fatal(err)
	}
	if err := m.reload(); err != nil {
		t.Fatal(err)
	}
	if !raw.closed.Load() || m.accounts["a"].used != 4 {
		t.Fatal("disable did not close account or lost its usage")
	}
	_, expectedRevision, _ := readAccessConfig(m.configPath)
	if m.revision != expectedRevision {
		t.Fatal("revision ack incorrect")
	}
	if err := os.WriteFile(m.configPath, []byte("bad"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := m.reload(); err == nil || m.revision != expectedRevision {
		t.Fatal("bad reload changed working revision")
	}
}

func TestAccessReadEOFPreservesAccounting(t *testing.T) {
	m := newQuotaTestManager(t, 0, 100)
	c, _ := quotaWrap(t, m, "a", "abc")
	data, err := io.ReadAll(c)
	if err != nil || string(data) != "abc" || m.totalUsed != 3 {
		t.Fatalf("read = %q %v usage=%d", data, err, m.totalUsed)
	}
}

func TestAccessWaitingReservationHonorsCloseAndDeadline(t *testing.T) {
	for _, mode := range []string{"close", "deadline"} {
		t.Run(mode, func(t *testing.T) {
			m := newQuotaTestManager(t, 0, 0)
			left, right := net.Pipe()
			defer right.Close()
			first, err := m.wrap("a", left)
			if err != nil {
				t.Fatal(err)
			}
			defer first.Close()
			firstDone := make(chan struct{})
			go func() { defer close(firstDone); _, _ = first.Write(make([]byte, accessReservation)) }()
			deadline := time.Now().Add(time.Second)
			for {
				m.mu.Lock()
				pending := m.totalPending
				m.mu.Unlock()
				if pending == accessReservation {
					break
				}
				if time.Now().After(deadline) {
					t.Fatal("first write never reserved quota")
				}
				time.Sleep(time.Millisecond)
			}
			second, _ := quotaWrap(t, m, "a", "")
			secondDone := make(chan error, 1)
			go func() { _, err := second.Write([]byte("x")); secondDone <- err }()
			want := net.ErrClosed
			if mode == "close" {
				second.Close()
			} else {
				want = os.ErrDeadlineExceeded
				if err := second.SetWriteDeadline(time.Now().Add(20 * time.Millisecond)); err != nil {
					t.Fatal(err)
				}
			}
			select {
			case err := <-secondDone:
				if !errors.Is(err, want) {
					t.Fatalf("waiting write returned %v, expected %v", err, want)
				}
			case <-time.After(time.Second):
				t.Fatal("closed/deadline-expired connection remained blocked in quota reservation")
			}
			first.Close()
			select {
			case <-firstDone:
			case <-time.After(time.Second):
				t.Fatal("first write did not stop")
			}
		})
	}
}
