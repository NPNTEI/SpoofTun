package main

import (
	"bytes"
	"context"
	"errors"
	"io"
	"net"
	"strings"
	"testing"
	"time"
)

// Deliberately ignore native deadlines: the absolute authentication watchdog
// must also bound adapters whose write is blocked above the socket layer.
type authDeadlineIgnoringConn struct{ net.Conn }

func (authDeadlineIgnoringConn) SetDeadline(time.Time) error      { return nil }
func (authDeadlineIgnoringConn) SetReadDeadline(time.Time) error  { return nil }
func (authDeadlineIgnoringConn) SetWriteDeadline(time.Time) error { return nil }

func authRegressionPair(t *testing.T, transport string) (net.Conn, net.Conn) {
	t.Helper()
	origin, peer := net.Pipe()
	if transport == TransportWSS {
		origin, peer = newWebSocketConn(origin, true), newWebSocketConn(peer, false)
	}
	t.Cleanup(func() { origin.Close(); peer.Close() })
	return origin, peer
}

func authRegressionReadFrame(conn net.Conn) error {
	var wire [HeaderSize]byte
	if _, err := io.ReadFull(conn, wire[:]); err != nil {
		return err
	}
	h, err := DecodeHeader(wire[:])
	if err != nil {
		return err
	}
	_, err = io.CopyN(io.Discard, conn, int64(h.Length)+int64(h.PadLen))
	return err
}

func authRegressionWriteFrame(conn net.Conn, cmd byte, payload []byte, pad uint16) error {
	h := ctrlHeader(cmd, 0, 0)
	h.Length, h.PadLen = uint32(len(payload)), pad
	wire := make([]byte, HeaderSize+len(payload))
	h.encodeTo(wire)
	copy(wire[HeaderSize:], payload)
	_, err := writeFull(conn, wire)
	return err
}

func TestOriginAuthenticationAbsoluteTimeout(t *testing.T) {
	for _, transport := range []string{TransportTLS, TransportWSS} {
		for _, stage := range []string{"initial-write", "challenge", "partial-challenge", "response-write", "auth-ok", "auth-ok-padding", "negotiation"} {
			t.Run(transport+"/"+stage, func(t *testing.T) {
				origin, peer := authRegressionPair(t, transport)
				reached := make(chan struct{})
				releasePeer := make(chan struct{})
				peerDone := make(chan struct{})
				go func() {
					defer close(peerDone)
					if stage != "initial-write" {
						if authRegressionReadFrame(peer) != nil {
							return
						}
					}
					if stage != "initial-write" && stage != "challenge" {
						challenge := bytes.Repeat([]byte{7}, 32)
						if stage == "partial-challenge" {
							h := ctrlHeader(CmdAuthChallenge, 0, 0)
							h.Length = 32
							wire := make([]byte, HeaderSize+4)
							h.encodeTo(wire)
							if _, err := writeFull(peer, wire); err != nil {
								return
							}
						} else {
							if authRegressionWriteFrame(peer, CmdAuthChallenge, challenge, 0) != nil {
								return
							}
							if stage != "response-write" {
								if authRegressionReadFrame(peer) != nil {
									return
								}
							}
							if stage == "auth-ok-padding" || stage == "negotiation" {
								var pad uint16
								if stage == "auth-ok-padding" {
									pad = 4 // Deliberately omit the declared padding.
								}
								if authRegressionWriteFrame(peer, CmdAuthOK, nil, pad) != nil {
									return
								}
							}
						}
					}
					close(reached)
					<-releasePeer
				}()
				t.Cleanup(func() {
					close(releasePeer)
					origin.Close()
					peer.Close()
					awaitDone(t, peerDone)
				})
				result := make(chan error, 1)
				go func() {
					_, err := authenticateOriginSessionContext(context.Background(), authDeadlineIgnoringConn{origin}, &Config{Token: "timeout-test"}, "test", transport, 100*time.Millisecond)
					result <- err
				}()
				select {
				case err := <-result:
					if !errors.Is(err, context.DeadlineExceeded) {
						t.Fatalf("authentication error = %v; want context deadline", err)
					}
					wantStage := map[string]string{"initial-write": "send-request", "challenge": "read-challenge-header", "partial-challenge": "read-challenge-body", "response-write": "send-response", "auth-ok": "read-accept-header", "auth-ok-padding": "read-accept-body", "negotiation": "negotiate-stream-credit"}[stage]
					if !strings.Contains(err.Error(), "[gdt-auth/"+wantStage+"]") {
						t.Fatalf("missing precise authentication stage %s: %v", wantStage, err)
					}
				case <-time.After(2 * time.Second):
					t.Fatal("authentication did not return on absolute timeout")
				}
				select {
				case <-reached:
				default:
					t.Fatal("test peer did not reach the intended authentication stage")
				}
			})
		}
	}
}

func TestOriginAuthenticationShutdownCancellation(t *testing.T) {
	for _, transport := range []string{TransportTLS, TransportWSS} {
		t.Run(transport, func(t *testing.T) {
			origin, _ := authRegressionPair(t, transport)
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			result := make(chan error, 1)
			go func() {
				_, err := authenticateOriginSessionContext(ctx, authDeadlineIgnoringConn{origin}, &Config{Token: "cancel-test"}, "test", transport, time.Hour)
				result <- err
			}()
			cancel()
			select {
			case err := <-result:
				if !errors.Is(err, context.Canceled) {
					t.Fatalf("authentication error = %v; want context cancellation", err)
				}
			case <-time.After(2 * time.Second):
				t.Fatal("shutdown did not cancel authentication")
			}
		})
	}
}

func TestOriginAuthenticationSuccessDisarmsWatchdog(t *testing.T) {
	for _, transport := range []string{TransportTLS, TransportWSS} {
		t.Run(transport, func(t *testing.T) {
			origin, peer := authRegressionPair(t, transport)
			peerDone := make(chan struct{})
			go func() {
				defer close(peerDone)
				if authRegressionReadFrame(peer) != nil ||
					authRegressionWriteFrame(peer, CmdAuthChallenge, bytes.Repeat([]byte{9}, 32), 0) != nil ||
					authRegressionReadFrame(peer) != nil ||
					authRegressionWriteFrame(peer, CmdAuthOK, nil, 0) != nil {
					return
				}
				var wire [HeaderSize]byte
				if _, err := io.ReadFull(peer, wire[:]); err != nil {
					return
				}
				h, err := DecodeHeader(wire[:])
				if err != nil || h.Cmd != CmdPing {
					return
				}
				body := make([]byte, int(h.Length)+int(h.PadLen))
				if _, err := io.ReadFull(peer, body); err != nil {
					return
				}
				// A legacy egress echoes the reserved Ping unchanged.
				_ = authRegressionWriteFrame(peer, CmdPong, body[:h.Length], 0)
			}()
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			sess, err := authenticateOriginSessionContext(ctx, authDeadlineIgnoringConn{origin}, &Config{Token: "success-test"}, "test", transport, 100*time.Millisecond)
			if err != nil {
				t.Fatal(err)
			}
			t.Cleanup(func() { sess.Close(); reg.remove(sess) })
			awaitDone(t, peerDone)
			cancel() // The completed auth scope must not cancel a live session.
			timer := time.NewTimer(150 * time.Millisecond)
			defer timer.Stop()
			select {
			case <-sess.done:
				t.Fatal("completed session was closed by its authentication watchdog")
			case <-timer.C:
			}
		})
	}
}
