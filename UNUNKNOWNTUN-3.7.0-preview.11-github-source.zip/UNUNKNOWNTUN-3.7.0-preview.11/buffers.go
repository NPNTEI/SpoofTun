package main

import (
	"sync/atomic"
	"unsafe"
)

// receiveBuffer has exactly one owner: the transport pump, the session reader,
// a stream's queue, or its socket writer. Ownership is transferred, never shared.
// In particular, Pop transfers ownership to the writer; it does NOT recycle the
// buffer while writeFull may still be reading it.
type receiveBuffer struct {
	data  []byte
	cache chan *receiveBuffer
}

type receiveBufferClass struct {
	size  int
	cache chan *receiveBuffer
}

// A bounded cache is deliberate: unlike sync.Pool its idle retention has a
// hard ceiling, independent of GC pacing and GOMAXPROCS, on small VPSes.
// Six classes x 16 entries retain at most 2,981,888 payload bytes (~2.84 MiB).
// Oversized H2 messages remain supported but are never retained in the cache.
var receiveBufferClasses = func() []receiveBufferClass {
	var classes []receiveBufferClass
	for _, n := range []int{1024, 4096, 16384, 32768, 65536, MaxFramePayload + MaxPadding} {
		classes = append(classes, receiveBufferClass{n, make(chan *receiveBuffer, 16)})
	}
	return classes
}()

func acquireReceiveBuffer(n int) *receiveBuffer {
	for _, class := range receiveBufferClasses {
		if n > class.size {
			continue
		}
		select {
		case buf := <-class.cache:
			buf.data = buf.data[:n]
			return buf
		default:
			return &receiveBuffer{data: make([]byte, n, class.size), cache: class.cache}
		}
	}
	return &receiveBuffer{data: make([]byte, n)}
}

func (b *receiveBuffer) release() {
	if b == nil || b.cache == nil {
		return
	}
	select {
	case b.cache <- b:
	default:
	}
}

type receivedChunk struct {
	data  []byte
	owner *receiveBuffer
	// Reservation follows the ownership transfer from queue to socket writer.
	// A blocked write must not make its still-live backing storage disappear
	// from the receive budget merely because Pop removed it from the queue.
	budget  int64
	account *atomic.Int64
}

func (p receivedChunk) release() {
	if p.budget != 0 {
		p.account.Add(-p.budget)
		memoryBudget.Add(-p.budget)
	}
	p.owner.release()
}

// receiveAllocationCharge conservatively includes allocation granularity for
// the supported 64-bit Go runtimes: round small allocations to a power of two
// and large allocations to 8 KiB pages. This is a receive-storage reservation,
// not a measurement or hard cap of process RSS. The bounded idle cache, socket
// buffers, transport readers and Go runtime have separate overhead.
func receiveAllocationCharge(n int) int64 {
	if n <= 0 {
		return 0
	}
	v := int64(n)
	if v > 32768 {
		return ((v + 8191) / 8192) * 8192
	}
	charge := int64(16)
	for charge < v {
		charge <<= 1
	}
	return charge
}

func receiveChunkCharge(chunk receivedChunk) int64 {
	capacity := cap(chunk.data)
	if chunk.owner != nil {
		// data can be a tiny payload slice of a much larger padded frame.
		capacity = cap(chunk.owner.data)
	}
	charge := receiveAllocationCharge(capacity)
	if chunk.owner != nil {
		charge += receiveAllocationCharge(int(unsafe.Sizeof(receiveBuffer{})))
	}
	return charge
}

func receiveQueueCharge(capacity int) int64 {
	return receiveAllocationCharge(capacity * int(unsafe.Sizeof(receivedChunk{})))
}

func reserveReceiveMemory(n int64) bool {
	if n < 0 {
		return false
	}
	for {
		used := memoryBudget.Load()
		limit := maxMemoryBudget.Load()
		if used < 0 || used > limit || n > limit-used {
			return false
		}
		if memoryBudget.CompareAndSwap(used, used+n) {
			return true
		}
	}
}
