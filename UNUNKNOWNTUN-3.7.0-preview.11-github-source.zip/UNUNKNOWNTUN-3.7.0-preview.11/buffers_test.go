package main

import (
	"bytes"
	"encoding/binary"
	"io"
	"net"
	"testing"
	"time"
)

func testOwnedBuffer(n int) *receiveBuffer {
	return &receiveBuffer{data: make([]byte, n), cache: make(chan *receiveBuffer, 8)}
}

func TestReceiveBufferOwnershipAcrossDrainAndReset(t *testing.T) {
	before := memoryBudget.Load()
	b := newStreamBuffer()
	first, second := testOwnedBuffer(1024), testOwnedBuffer(2048)
	if !b.push(receivedChunk{data: first.data, owner: first}) || !b.push(receivedChunk{data: second.data, owner: second}) {
		t.Fatal("push failed")
	}
	b.CloseWrite()
	chunk, _, ok := b.Pop()
	if !ok || len(first.cache) != 0 {
		t.Fatal("buffer recycled before socket write")
	}
	b.Close()
	b.Close()
	if len(first.cache) != 0 || len(second.cache) != 1 {
		t.Fatal("reset released a writer-owned buffer or missed queued buffer")
	}
	chunk.release()
	if len(first.cache) != 1 || memoryBudget.Load() != before {
		t.Fatal("ownership/accounting mismatch after release")
	}
}

func TestReceiveQueueCompactionKeepsFIFO(t *testing.T) {
	before := memoryBudget.Load()
	b := newStreamBuffer()
	defer b.Close()
	const count = 4096
	next := 0
	for i := 0; i < count; i++ {
		owner := acquireReceiveBuffer(8)
		binary.BigEndian.PutUint64(owner.data, uint64(i))
		if !b.push(receivedChunk{data: owner.data, owner: owner}) {
			owner.release()
			t.Fatal("push failed")
		}
		if i%3 != 0 {
			chunk, _, ok := b.Pop()
			if !ok || binary.BigEndian.Uint64(chunk.data) != uint64(next) {
				t.Fatal("queue order changed")
			}
			chunk.release()
			next++
		}
	}
	b.CloseWrite()
	for next < count {
		chunk, _, ok := b.Pop()
		if !ok || binary.BigEndian.Uint64(chunk.data) != uint64(next) {
			t.Fatal("drain order changed")
		}
		chunk.release()
		next++
	}
	_, eof, ok := b.Pop()
	if ok || !eof || memoryBudget.Load() != before {
		t.Fatal("queue did not finish cleanly")
	}
}

func TestReceiveBudgetRejectionReleasesPayload(t *testing.T) {
	before := memoryBudget.Load()
	limit := maxMemoryBudget.Load()
	defer maxMemoryBudget.Store(limit)
	s := newSession(&discardBenchConn{}, "origin", 0, nil)
	defer s.Close()
	s.markAuthenticated()
	st := newStream(1, s)
	st.state.Store(StateOpen)
	if err := s.registerStream(1, st); err != nil {
		t.Fatal(err)
	}
	maxMemoryBudget.Store(before + 32)
	owner := testOwnedBuffer(64)
	s.handleReceivedFrame(dataHeader(1, 0), owner.data, owner)
	if len(owner.cache) != 1 || memoryBudget.Load() != before || s.getStream(1) != nil || s.Closed() {
		t.Fatal("budget rejection did not release/reset only its stream")
	}
}

func TestAsyncPongDoesNotKeepRecycledPayload(t *testing.T) {
	s := &Session{bestEffortQ: make(chan frameRequest, 1)}
	s.authenticated.Store(true)
	owner := testOwnedBuffer(8)
	copy(owner.data, []byte("12345678"))
	s.handleReceivedFrame(ctrlHeader(CmdPing, 0, 0), owner.data, owner)
	if len(owner.cache) != 1 {
		t.Fatal("ping payload retained")
	}
	clear(owner.data)
	req := <-s.bestEffortQ
	if string(req.payload) != "12345678" {
		t.Fatal("asynchronous Pong used recycled bytes")
	}
}

func TestResetUnblocksWriterAndReleasesInFlightBuffer(t *testing.T) {
	before := memoryBudget.Load()
	s := newSession(&discardBenchConn{}, "origin", 0, nil)
	defer s.Close()
	local, peer := net.Pipe()
	defer peer.Close()
	st := newStream(1, s)
	st.setConn(local)
	st.state.Store(StateOpen)
	if err := s.registerStream(1, st); err != nil {
		t.Fatal(err)
	}
	owner := testOwnedBuffer(4096)
	copy(owner.data, bytes.Repeat([]byte("z"), 4096))
	if !st.rbuf.push(receivedChunk{data: owner.data, owner: owner}) {
		t.Fatal("push failed")
	}
	done := make(chan struct{})
	go func() { defer close(done); st.pumpToConn() }()
	// Read a single byte so the writer is known to own a partially-written lease.
	peer.SetReadDeadline(time.Now().Add(time.Second))
	var one [1]byte
	if _, err := io.ReadFull(peer, one[:]); err != nil {
		t.Fatal(err)
	}
	if len(owner.cache) != 0 {
		t.Fatal("in-flight data was recycled")
	}
	st.resetAndUnregister()
	awaitDone(t, done)
	if len(owner.cache) != 1 || memoryBudget.Load() != before {
		t.Fatal("reset leaked the writer's lease")
	}
}

func TestReceiveCacheHasHardRetentionLimit(t *testing.T) {
	var owners []*receiveBuffer
	for _, class := range receiveBufferClasses {
		for i := 0; i < 64; i++ {
			owners = append(owners, acquireReceiveBuffer(class.size))
		}
	}
	for _, owner := range owners {
		owner.release()
	}
	retained := 0
	for _, class := range receiveBufferClasses {
		retained += len(class.cache) * class.size
	}
	if retained > 2981888 {
		t.Fatalf("cache retained %d bytes", retained)
	}
	large := acquireReceiveBuffer(1024 * 1024)
	if large.cache != nil {
		t.Fatal("oversized receive allocation may not be cached")
	}
}
