package main

import (
	"crypto/rand"
	"fmt"
	"math/big"
	"strconv"
	"strings"
)

// Byte padding is opt-in and bounded by the existing wire decoder limit.
// It does not imply browser equivalence, anonymity, or a DPI bypass.
type bytePaddingRange struct{ min, max int }

func parseBytePadding(value string) (bytePaddingRange, error) {
	if value == "" {
		value = "0"
	}
	parts := strings.Split(value, "-")
	if len(parts) < 1 || len(parts) > 2 {
		return bytePaddingRange{}, fmt.Errorf("[padding/config] use bytes or MIN-MAX, 0..%d", MaxPadding)
	}
	vals := make([]int, len(parts))
	for i, p := range parts {
		if p == "" || strings.Trim(p, "0123456789") != "" {
			return bytePaddingRange{}, fmt.Errorf("[padding/config] invalid byte range")
		}
		n, err := strconv.Atoi(p)
		if err != nil || n < 0 || n > MaxPadding {
			return bytePaddingRange{}, fmt.Errorf("[padding/config] range must be 0..%d", MaxPadding)
		}
		vals[i] = n
	}
	r := bytePaddingRange{vals[0], vals[len(vals)-1]}
	if r.min > r.max {
		return bytePaddingRange{}, fmt.Errorf("[padding/config] minimum exceeds maximum")
	}
	return r, nil
}

func (r bytePaddingRange) choose() (int, error) {
	if r.min < 0 || r.max > MaxPadding || r.min > r.max {
		return 0, fmt.Errorf("[padding/config] invalid session range")
	}
	if r.min == r.max {
		return r.min, nil
	}
	n, err := rand.Int(rand.Reader, big.NewInt(int64(r.max-r.min+1)))
	if err != nil {
		return 0, fmt.Errorf("[padding/random] %w", err)
	}
	return r.min + int(n.Int64()), nil
}

func paddingForConfig(cfg *Config) bytePaddingRange {
	if cfg.Transport != TransportWSS && cfg.Transport != TransportXHTTP {
		return bytePaddingRange{}
	}
	r, _ := parseBytePadding(cfg.PaddingBytes) // validated before a runtime is started
	return r
}
