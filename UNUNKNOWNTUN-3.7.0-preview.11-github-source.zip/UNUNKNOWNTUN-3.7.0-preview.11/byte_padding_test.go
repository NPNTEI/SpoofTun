package main

import (
	"bytes"
	"testing"
)

func TestBytePaddingValidation(t *testing.T) {
	for _, value := range []string{"", "0", "32", "100-1000", "0-1024"} {
		r, err := parseBytePadding(value)
		if err != nil {
			t.Fatal(value, err)
		}
		for i := 0; i < 100; i++ {
			n, err := r.choose()
			if err != nil || n < r.min || n > r.max {
				t.Fatal(n, err)
			}
		}
	}
	for _, value := range []string{"-1", "1000-100", "1025", "1-2-3", "1.2", "1 2", "+4"} {
		if _, err := parseBytePadding(value); err == nil {
			t.Fatal("accepted", value)
		}
	}
}

func TestOptInBytePaddingPreservesFramesAndAccounting(t *testing.T) {
	for _, value := range []string{"0", "32", "100-1000", "1024"} {
		r, _ := parseBytePadding(value)
		conn := &unpaddedRecordingConn{}
		sess := newSession(nil, "origin", 0, nil, r)
		sess.conn = conn
		payload := []byte("unchanged bytes")
		batch := []frameRequest{{h: dataHeader(1, 0), payload: payload}, {h: ctrlHeader(CmdPing, 0, 0), payload: make([]byte, 8)}}
		if err := sess.rawWriteBatch(batch); err != nil {
			t.Fatal(err)
		}
		wire := conn.data.Bytes()
		h, err := DecodeHeader(wire[:HeaderSize])
		if err != nil {
			t.Fatal(err)
		}
		if int(h.PadLen) < r.min || int(h.PadLen) > r.max || h.Length != uint32(len(payload)) {
			t.Fatal(h)
		}
		if !bytes.Equal(wire[HeaderSize:HeaderSize+len(payload)], payload) {
			t.Fatal("payload changed")
		}
		second := HeaderSize + len(payload) + int(h.PadLen)
		control, err := DecodeHeader(wire[second : second+HeaderSize])
		if err != nil || control.PadLen != 0 {
			t.Fatal("control padding", err, control)
		}
		if sess.bytesOut.Load() != uint64(len(wire)) {
			t.Fatal("padding not counted")
		}
		sess.Close()
	}
}

func TestPaddingCannotEnableGREOrTLS(t *testing.T) {
	if _, err := currentRuntimeConfig(&Config{Transport: TransportTLS, PaddingBytes: "32"}); err == nil {
		t.Fatal("enabled padding on direct TLS")
	}
}
