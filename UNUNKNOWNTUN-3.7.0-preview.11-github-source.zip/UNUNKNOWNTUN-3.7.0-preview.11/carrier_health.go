package main

import (
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"log"
	"sync"
	"time"
)

const (
	carrierHealthQueryPrefix uint32 = 0x47484331 // GHC1; distinct from stream-window discovery.
	carrierHealthReplyPrefix uint32 = 0x47484131 // GHA1
	carrierHealthPayloadSize        = 1024
	carrierHealthReplaySlots        = 32
	carrierHealthInterval           = 15 * time.Second
	carrierHealthTimeout            = 10 * time.Second
	carrierHealthFailures           = 3
	carrierHealthMaxProofAge        = carrierHealthFailures * (carrierHealthInterval + carrierHealthTimeout)
	maxCarrierHealthFrames          = 32
)

type carrierHealthMode uint8

const (
	carrierHealthUnknown carrierHealthMode = iota
	carrierHealthLegacy
	carrierHealthPayload
)

// The watchdog proves only authenticated interserver payload delivery. It does
// not test a target website, Internet connectivity, or any client stream. Client
// idleness and target silence therefore cannot count as failures. Writes and
// unrelated reads cannot satisfy a probe: only its complete, fresh echo can.
//
// A single pending probe bounds memory and delayed replies cannot acknowledge a
// later probe. Failed attempts back off for a full interval before retrying;
// three misses take about 75 seconds after the last success, avoiding churn on
// one delayed packet. The caller supplies time for deterministic state tests.
type carrierHealthState struct {
	mu             sync.Mutex
	mode           carrierHealthMode
	pending        []byte
	started        time.Time
	lastProofStart time.Time
	deadline       time.Time
	next           time.Time
	failures       int
	failed         bool
	seen           [carrierHealthReplaySlots][16]byte
	seenLen        int
	seenNext       int
	expired        [carrierHealthFailures]expiredCarrierHealthProbe
	expireAt       int
}

type expiredCarrierHealthProbe struct {
	digest  [sha256.Size]byte
	started time.Time
	valid   bool
}

func (c *carrierHealthState) configure(mode carrierHealthMode, now time.Time) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.mode = mode
	c.next = now.Add(carrierHealthInterval)
}

func (c *carrierHealthState) supportsPayload() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.mode == carrierHealthPayload
}

func (c *carrierHealthState) enabled() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.mode != carrierHealthUnknown
}

func (c *carrierHealthState) beginLocked(now time.Time) (carrierHealthMode, []byte, error) {
	size := 8
	if c.mode == carrierHealthPayload {
		size = carrierHealthPayloadSize
	}
	payload := make([]byte, size)
	for {
		if _, err := rand.Read(payload); err != nil {
			return c.mode, nil, fmt.Errorf("generate carrier-health nonce: %w", err)
		}
		// Legacy probes must never accidentally look like capability queries.
		prefix := binary.BigEndian.Uint32(payload)
		if prefix != carrierHealthQueryPrefix && prefix != initialWindowQueryPrefix {
			break
		}
	}
	c.pending = payload
	c.started = now
	c.deadline = now.Add(carrierHealthTimeout)
	return c.mode, payload, nil
}

func (c *carrierHealthState) initialProbe(now time.Time) ([]byte, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	_, payload, err := c.beginLocked(now)
	return payload, err
}

// poll never extends the pending deadline and never counts the same missed
// reply twice. Enqueue delay is part of the deadline, so a starved application
// queue cannot appear healthy just because control messages still get through.
func (c *carrierHealthState) poll(now time.Time) (carrierHealthMode, []byte, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.mode == carrierHealthUnknown || c.failed {
		return c.mode, nil, nil
	}
	if c.pending != nil {
		if now.Before(c.deadline) {
			return c.mode, nil, nil
		}
		c.expired[c.expireAt] = expiredCarrierHealthProbe{digest: sha256.Sum256(c.pending), started: c.started, valid: true}
		c.expireAt = (c.expireAt + 1) % len(c.expired)
		c.pending = nil
		c.failures++
		c.next = now.Add(carrierHealthInterval)
		if c.failures >= carrierHealthFailures {
			c.failed = true
			coverage := "authenticated payload"
			if c.mode == carrierHealthLegacy {
				coverage = "legacy 8-byte heartbeat (no full payload coverage)"
			}
			return c.mode, nil, fmt.Errorf("%s roundtrip timed out on %d consecutive attempts", coverage, c.failures)
		}
		return c.mode, nil, nil
	}
	if now.Before(c.next) {
		return c.mode, nil, nil
	}
	return c.beginLocked(now)
}

func (c *carrierHealthState) accept(mode carrierHealthMode, payload []byte, now time.Time) bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.failed || c.mode != mode || c.pending == nil || !now.Before(c.deadline) ||
		subtle.ConstantTimeCompare(c.pending, payload) != 1 {
		return false
	}
	c.pending = nil
	c.lastProofStart = c.started
	c.failures = 0
	c.next = now.Add(carrierHealthInterval)
	return true
}

// A congested data FIFO can deliver an exact echo after its 10s attempt timed
// out. That is real authenticated payload progress, not a dead carrier. Retain
// only three consumed-once fingerprints for at most the 75s failure budget.
// Such a reply clears the miss streak, but never acknowledges or extends a
// newer pending probe. This tolerance does not apply to initial authentication,
// whose accept call remains strict and bounded by the absolute auth deadline.
func (c *carrierHealthState) observe(mode carrierHealthMode, payload []byte, now time.Time) {
	if c.accept(mode, payload, now) {
		return
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.failed || c.mode != mode {
		return
	}
	if c.pending != nil && !now.Before(c.deadline) && now.Sub(c.started) <= carrierHealthMaxProofAge &&
		subtle.ConstantTimeCompare(c.pending, payload) == 1 {
		// The reader may observe the late reply just before the timer records
		// its expiration. It belongs to this old probe, not a newer one.
		c.pending = nil
		c.lastProofStart = c.started
		c.failures = 0
		c.next = now.Add(carrierHealthInterval)
		return
	}
	digest := sha256.Sum256(payload)
	for i := range c.expired {
		old := &c.expired[i]
		if old.valid && (now.Sub(old.started) > carrierHealthMaxProofAge || !old.started.After(c.lastProofStart)) {
			old.valid = false
		}
		if old.valid && old.digest == digest {
			old.valid = false
			c.lastProofStart = old.started
			c.failures = 0
			return
		}
	}
}

// Requests have a fresh 128-bit random nonce in their first 16 bytes. Remember
// a bounded recent set and ignore replays, including altered-payload reuse of
// the same nonce. Replies are checked against the entire pending payload.
func (c *carrierHealthState) rememberRequest(payload []byte) bool {
	var nonce [16]byte
	copy(nonce[:], payload)
	c.mu.Lock()
	defer c.mu.Unlock()
	for i := 0; i < c.seenLen; i++ {
		if c.seen[i] == nonce {
			return false
		}
	}
	c.seen[c.seenNext] = nonce
	c.seenNext = (c.seenNext + 1) % len(c.seen)
	if c.seenLen < len(c.seen) {
		c.seenLen++
	}
	return true
}

func carrierHealthHeader(cmd byte) Header {
	h := ctrlHeader(cmd, 0, 0)
	h.Category = CategoryData
	return h
}

func (s *Session) queueCarrierHealth(cmd byte, payload []byte) bool {
	select {
	case <-s.done:
		return false
	default:
	}
	select {
	case s.dataQ <- frameRequest{h: carrierHealthHeader(cmd), payload: payload}:
		return true
	default:
		return false
	}
}

func (s *Session) runCarrierHealth(now time.Time) bool {
	if s.closed.Load() {
		return false
	}
	if s.side != "origin" || !s.authenticated.Load() {
		return true
	}
	mode, payload, err := s.carrierHealth.poll(now)
	if err != nil {
		s.failCarrierHealth(err.Error())
		return false
	}
	if payload != nil {
		if mode == carrierHealthPayload {
			s.queueCarrierHealth(CmdCarrierHealth, payload)
		} else {
			// Rolling upgrades retain a bounded authenticated heartbeat. Legacy
			// Ping/Pong traverses control queues and proves no bulk-data coverage.
			s.writeAsync(ctrlHeader(CmdPing, 0, 0), payload, false)
		}
	}
	return true
}

func (s *Session) acceptCarrierHealthCapability(payload []byte) bool {
	if s.side != "egress" || s.initialStreamSeen.Load() || len(payload) != 8 ||
		binary.BigEndian.Uint32(payload) != carrierHealthQueryPrefix {
		return false
	}
	s.carrierHealth.configure(carrierHealthPayload, time.Now())
	reply := append([]byte(nil), payload...)
	binary.BigEndian.PutUint32(reply, carrierHealthReplyPrefix)
	s.writeAsync(ctrlHeader(CmdPong, 0, 0), reply, true)
	return true
}

func readCarrierHealthFrame(s *Session) (Header, []byte, error) {
	var wire [HeaderSize]byte
	if _, err := io.ReadFull(s.conn, wire[:]); err != nil {
		return Header{}, nil, err
	}
	h, err := DecodeHeader(wire[:])
	if err != nil {
		return h, nil, err
	}
	body := make([]byte, int(h.Length)+int(h.PadLen))
	if _, err := io.ReadFull(s.conn, body); err != nil {
		return h, nil, err
	}
	return h, body[:h.Length], nil
}

func handleCarrierHealthNegotiationControl(s *Session, h Header, payload []byte) error {
	if h.Cmd != CmdWindowResize && h.Cmd != CmdPing {
		return fmt.Errorf("unexpected command 0x%02X during carrier-health negotiation", h.Cmd)
	}
	s.handleFrame(h, payload)
	if s.Closed() {
		return errors.New("session closed during carrier-health negotiation")
	}
	return nil
}

// The origin calls this before publishing the session, while its original
// absolute authentication deadline and cancellation watchdog are still active.
// An interrupted exchange is never a fallback. Only an authenticated exact echo
// positively identifies a legacy peer. Known pre-window-negotiation peers have
// already supplied that echo and cannot implement this later capability.
func negotiateCarrierHealth(s *Session) error {
	legacy := func() error {
		s.carrierHealth.configure(carrierHealthLegacy, time.Now())
		log.Printf("[origin] peer uses legacy 8-byte carrier heartbeat; no full payload coverage, upgrade both endpoints")
		return nil
	}
	if !s.fixedInitialWindow.Load() {
		return legacy()
	}
	query := make([]byte, 8)
	binary.BigEndian.PutUint32(query, carrierHealthQueryPrefix)
	if _, err := rand.Read(query[4:]); err != nil {
		return fmt.Errorf("carrier-health capability nonce: %w", err)
	}
	if err := s.writeFrame(ctrlHeader(CmdPing, 0, 0), query); err != nil {
		return fmt.Errorf("carrier-health capability query: %w", err)
	}
	negotiated := false
	for i := 0; i < maxCarrierHealthFrames; i++ {
		h, payload, err := readCarrierHealthFrame(s)
		if err != nil {
			return fmt.Errorf("carrier-health capability reply: %w", err)
		}
		if h.Cmd != CmdPong {
			if err := handleCarrierHealthNegotiationControl(s, h, payload); err != nil {
				return err
			}
			continue
		}
		if subtle.ConstantTimeCompare(query[4:], payload[4:]) != 1 {
			return errors.New("carrier-health capability nonce mismatch")
		}
		switch binary.BigEndian.Uint32(payload) {
		case carrierHealthQueryPrefix:
			return legacy()
		case carrierHealthReplyPrefix:
			s.carrierHealth.configure(carrierHealthPayload, time.Now())
			negotiated = true
		default:
			return errors.New("unexpected carrier-health capability response")
		}
		break
	}
	if !negotiated {
		return errors.New("too many frames during carrier-health capability negotiation")
	}
	payload, err := s.carrierHealth.initialProbe(time.Now())
	if err != nil {
		return err
	}
	if err := s.writeFrame(carrierHealthHeader(CmdCarrierHealth), payload); err != nil {
		return fmt.Errorf("initial carrier-health payload write: %w", err)
	}
	for i := 0; i < maxCarrierHealthFrames; i++ {
		h, reply, err := readCarrierHealthFrame(s)
		if err != nil {
			return fmt.Errorf("initial carrier-health payload reply: %w", err)
		}
		if h.Cmd == CmdCarrierHealthReply {
			if !s.carrierHealth.accept(carrierHealthPayload, reply, time.Now()) {
				return errors.New("initial carrier-health payload mismatch or late reply")
			}
			log.Printf("[origin] authenticated 1KiB carrier payload roundtrip confirmed")
			return nil
		}
		if err := handleCarrierHealthNegotiationControl(s, h, reply); err != nil {
			return err
		}
	}
	return errors.New("too many frames during initial carrier-health payload roundtrip")
}
