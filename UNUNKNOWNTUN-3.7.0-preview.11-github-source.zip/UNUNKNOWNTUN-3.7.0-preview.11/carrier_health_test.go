package main

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func TestCarrierHealthHeaderBounds(t *testing.T) {
	for _, cmd := range []byte{CmdCarrierHealth, CmdCarrierHealthReply} {
		good := carrierHealthHeader(cmd)
		good.Length = carrierHealthPayloadSize
		for _, tc := range []struct {
			name string
			edit func(*Header)
			bad  bool
		}{
			{"valid", func(*Header) {}, false},
			{"control", func(h *Header) { h.Category = CategoryControl }, true},
			{"client-stream", func(h *Header) { h.StreamID = 1 }, true},
			{"fin", func(h *Header) { h.Flags = FlagFIN }, true},
			{"empty", func(h *Header) { h.Length = 0 }, true},
			{"short", func(h *Header) { h.Length-- }, true},
			{"oversize", func(h *Header) { h.Length++ }, true},
		} {
			t.Run(tc.name+map[byte]string{CmdCarrierHealth: "/request", CmdCarrierHealthReply: "/reply"}[cmd], func(t *testing.T) {
				h := good
				tc.edit(&h)
				var wire [HeaderSize]byte
				h.encodeTo(wire[:])
				_, err := DecodeHeader(wire[:])
				if (err != nil) != tc.bad {
					t.Fatalf("validation error = %v, want invalid=%v", err, tc.bad)
				}
			})
		}
	}
}

func TestCarrierHealthConsecutiveMissesAndBackoff(t *testing.T) {
	for _, mode := range []carrierHealthMode{carrierHealthLegacy, carrierHealthPayload} {
		var c carrierHealthState
		now := time.Unix(100, 0)
		c.configure(mode, now)
		for attempt := 0; attempt < carrierHealthFailures; attempt++ {
			start := now.Add(carrierHealthInterval)
			_, payload, err := c.poll(start)
			if err != nil || len(payload) == 0 {
				t.Fatalf("attempt %d did not start: %v", attempt, err)
			}
			for _, sample := range []time.Duration{0, time.Second, carrierHealthTimeout - time.Nanosecond} {
				if _, duplicate, err := c.poll(start.Add(sample)); err != nil || duplicate != nil {
					t.Fatalf("extra probe while one is pending: %v", err)
				}
			}
			now = start.Add(carrierHealthTimeout)
			_, _, err = c.poll(now)
			if (err != nil) != (attempt == carrierHealthFailures-1) {
				t.Fatalf("attempt %d error = %v", attempt, err)
			}
			if c.accept(mode, payload, now) {
				t.Fatal("late reply acknowledged an expired probe")
			}
			if _, early, err := c.poll(now.Add(carrierHealthInterval - time.Nanosecond)); err != nil || early != nil {
				t.Fatalf("retry did not back off: %v", err)
			}
		}
		if elapsed := now.Sub(time.Unix(100, 0)); elapsed != 75*time.Second {
			t.Fatalf("failure threshold elapsed = %s", elapsed)
		}
		if c.pending != nil || !c.failed || c.failures != carrierHealthFailures {
			t.Fatalf("terminal watchdog state: pending=%t failed=%t failures=%d", c.pending != nil, c.failed, c.failures)
		}
	}
}

func TestCarrierHealthMatchingAndTransientRecovery(t *testing.T) {
	var c carrierHealthState
	now := time.Unix(100, 0)
	c.configure(carrierHealthPayload, now)
	_, old, _ := c.poll(now.Add(carrierHealthInterval))
	_, _, _ = c.poll(now.Add(carrierHealthInterval + carrierHealthTimeout))
	now = now.Add(2*carrierHealthInterval + carrierHealthTimeout)
	_, current, err := c.poll(now)
	if err != nil || len(current) != carrierHealthPayloadSize {
		t.Fatalf("retry = %d bytes, %v", len(current), err)
	}
	corrupt := append([]byte(nil), current...)
	corrupt[len(corrupt)-1] ^= 1
	for _, wrong := range [][]byte{old, corrupt, current[:8], nil} {
		if c.accept(carrierHealthPayload, wrong, now.Add(time.Second)) {
			t.Fatal("mismatched payload satisfied the probe")
		}
	}
	if c.accept(carrierHealthLegacy, current, now.Add(time.Second)) {
		t.Fatal("wrong reply mode satisfied the probe")
	}
	if !c.accept(carrierHealthPayload, current, now.Add(9*time.Second)) {
		t.Fatal("delayed but timely exact payload did not recover")
	}
	if c.accept(carrierHealthPayload, current, now.Add(9*time.Second)) {
		t.Fatal("duplicate reply acknowledged twice")
	}
	if c.failures != 0 || c.failed || c.pending != nil {
		t.Fatal("transient loss was not cleared by successful roundtrip")
	}
}

func TestCarrierHealthCongestedButProgressingPayload(t *testing.T) {
	var c carrierHealthState
	base := time.Unix(100, 0)
	c.configure(carrierHealthPayload, base)
	type delayedEcho struct {
		payload []byte
		arrives time.Time
	}
	var transit []delayedEcho
	proofs := 0
	// A busy FIFO can hold tens of MiB while every write still succeeds. Each
	// probe here takes 50s for the complete data-queue roundtrip, well beyond
	// its individual timeout, but delivers real payload within the failure
	// budget. It must not churn a steadily progressing carrier.
	for second := 1; second <= 300; second++ {
		now := base.Add(time.Duration(second) * time.Second)
		for len(transit) > 0 && !now.Before(transit[0].arrives) {
			c.observe(carrierHealthPayload, transit[0].payload, now)
			transit = transit[1:]
			proofs++
		}
		_, payload, err := c.poll(now)
		if err != nil {
			t.Fatalf("progressing FIFO closed at second %d: %v", second, err)
		}
		if payload != nil {
			transit = append(transit, delayedEcho{payload, now.Add(50 * time.Second)})
		}
	}
	if proofs < 5 || c.failed {
		t.Fatal("delayed payload progress was not exercised")
	}
}

func TestCarrierHealthLateProofDoesNotAcknowledgeNewProbeOrReplay(t *testing.T) {
	var c carrierHealthState
	base := time.Unix(100, 0)
	at := func(seconds int) time.Time { return base.Add(time.Duration(seconds) * time.Second) }
	c.configure(carrierHealthPayload, base)
	_, first, _ := c.poll(at(15))
	c.poll(at(25))
	_, second, _ := c.poll(at(40))
	deadline := c.deadline
	corrupt := append([]byte(nil), first...)
	corrupt[len(corrupt)-1] ^= 1
	c.observe(carrierHealthPayload, corrupt, at(48))
	if c.failures != 1 {
		t.Fatal("corrupted late reply reset failure streak")
	}
	c.observe(carrierHealthPayload, first, at(49))
	if c.failures != 0 || !bytes.Equal(c.pending, second) || !c.deadline.Equal(deadline) {
		t.Fatal("late payload proof acknowledged or extended newer probe")
	}
	c.poll(at(50))
	c.observe(carrierHealthPayload, first, at(51))
	if c.failures != 1 {
		t.Fatal("replayed consumed proof postponed failure")
	}
	_, third, _ := c.poll(at(65))
	c.observe(carrierHealthPayload, third, at(66))
	c.poll(at(81))
	c.poll(at(91))
	c.observe(carrierHealthPayload, second, at(92))
	if c.failures != 1 {
		t.Fatal("proof older than a newer confirmed probe postponed failure")
	}
}

func TestCarrierHealthLateProofHasBoundedFreshness(t *testing.T) {
	var c carrierHealthState
	base := time.Unix(100, 0)
	c.configure(carrierHealthPayload, base)
	started := base.Add(carrierHealthInterval)
	_, payload, _ := c.poll(started)
	c.poll(started.Add(carrierHealthTimeout))
	c.observe(carrierHealthPayload, payload, started.Add(carrierHealthMaxProofAge+time.Nanosecond))
	if c.failures != 1 {
		t.Fatal("ancient exact echo postponed a new failure")
	}
}

func TestCarrierHealthIdleAndBusySuccess(t *testing.T) {
	for _, busy := range []bool{false, true} {
		s := newSession(nil, "origin", 0, nil)
		s.markAuthenticated()
		now := time.Unix(100, 0)
		s.carrierHealth.configure(carrierHealthPayload, now)
		for round := 0; round < 20; round++ {
			now = now.Add(carrierHealthInterval)
			if busy {
				s.lastWireActivity.Store(now.UnixNano())
			}
			if !s.runCarrierHealth(now) {
				t.Fatal("healthy carrier closed")
			}
			select {
			case req := <-s.dataQ:
				if req.h.Cmd != CmdCarrierHealth || req.h.Category != CategoryData || req.h.StreamID != 0 {
					t.Fatalf("probe did not use isolated data command: %+v", req.h)
				}
				if !s.carrierHealth.accept(carrierHealthPayload, req.payload, now.Add(time.Second)) {
					t.Fatal("healthy roundtrip rejected")
				}
			case <-time.After(time.Second):
				t.Fatal("outgoing activity suppressed probe")
			}
			now = now.Add(time.Second)
		}
		if s.streamCount() != 0 || s.nextID.Load() != 1 {
			t.Fatal("health probes consumed client stream IDs")
		}
		s.Close()
	}
}

func TestCarrierHealthBlackholeDespiteOutgoingWrites(t *testing.T) {
	for _, fullQueue := range []bool{false, true} {
		s := newSession(nil, "origin", 0, nil)
		s.markAuthenticated()
		now := time.Unix(100, 0)
		s.carrierHealth.configure(carrierHealthPayload, now)
		if fullQueue {
			s.dataQ = make(chan frameRequest, 1)
			s.dataQ <- frameRequest{h: dataHeader(77, 0), payload: []byte("client")}
		}
		for attempt := 0; attempt < carrierHealthFailures; attempt++ {
			now = now.Add(carrierHealthInterval)
			s.lastWireActivity.Store(now.UnixNano())
			if !s.runCarrierHealth(now) {
				t.Fatal("closed before consecutive timeout threshold")
			}
			if !fullQueue {
				<-s.dataQ // Accepted outgoing writes are not incoming payload proof.
			}
			now = now.Add(carrierHealthTimeout)
			s.lastWireActivity.Store(now.UnixNano())
			alive := s.runCarrierHealth(now)
			if alive != (attempt < carrierHealthFailures-1) {
				t.Fatalf("attempt %d alive=%v", attempt, alive)
			}
		}
		if !s.Closed() {
			t.Fatal("blackholed carrier remained available")
		}
		if fullQueue {
			req := <-s.dataQ
			if !bytes.Equal(req.payload, []byte("client")) {
				t.Fatal("watchdog replaced or consumed queued client data")
			}
		}
	}
}

func TestCarrierHealthRequestReplayAndQueueBounds(t *testing.T) {
	s := newSession(nil, "egress", 0, nil)
	defer s.Close()
	s.markAuthenticated()
	s.carrierHealth.configure(carrierHealthPayload, time.Now())
	s.dataQ = make(chan frameRequest, 1)
	payload := bytes.Repeat([]byte{3}, carrierHealthPayloadSize)
	h := carrierHealthHeader(CmdCarrierHealth)
	s.handleFrame(h, payload)
	s.handleFrame(h, payload)
	if len(s.dataQ) != 1 || s.Closed() {
		t.Fatal("replayed request queued duplicate replies or closed session")
	}
	payload[0] = 4
	s.handleFrame(h, payload) // A full data queue must not block the reader.
	if len(s.dataQ) != 1 || s.Closed() {
		t.Fatal("full data queue was not bounded")
	}
	req := <-s.dataQ
	if req.h.Cmd != CmdCarrierHealthReply || req.payload[0] != 3 {
		t.Fatal("reply retained borrowed receive-buffer memory")
	}
	for i := 0; i < 200; i++ {
		binary.BigEndian.PutUint64(payload, uint64(i+10))
		s.carrierHealth.rememberRequest(payload)
	}
	if s.carrierHealth.seenLen != carrierHealthReplaySlots {
		t.Fatal("replay memory exceeded bound")
	}
}

func TestCarrierHealthRequiresAuthenticationAndNegotiation(t *testing.T) {
	for _, authenticated := range []bool{false, true} {
		s := newSession(nil, "egress", 0, nil)
		if authenticated {
			s.markAuthenticated()
		}
		s.handleFrame(carrierHealthHeader(CmdCarrierHealth), make([]byte, carrierHealthPayloadSize))
		if !s.Closed() || len(s.dataQ) != 0 {
			t.Fatal("unnegotiated health frame accepted")
		}
	}
}

// A blackholed application response reports successful carrier writes, like a
// buffering HTTP upload adapter; only the authenticated echo can expose it.
type healthDropReplyConn struct {
	net.Conn
	drop atomic.Bool
	seen atomic.Bool
}

func (c *healthDropReplyConn) Write(p []byte) (int, error) {
	var forward []byte
	for offset := 0; offset < len(p); {
		if len(p)-offset < HeaderSize {
			return 0, errors.New("incomplete test frame")
		}
		h, err := DecodeHeader(p[offset : offset+HeaderSize])
		if err != nil {
			return 0, err
		}
		end := offset + HeaderSize + int(h.Length) + int(h.PadLen)
		if end > len(p) {
			return 0, io.ErrUnexpectedEOF
		}
		if h.Cmd == CmdCarrierHealthReply {
			c.seen.Store(true)
		}
		if h.Cmd != CmdCarrierHealthReply || !c.drop.Load() {
			forward = append(forward, p[offset:end]...)
		}
		offset = end
	}
	if len(forward) > 0 {
		if _, err := writeFull(c.Conn, forward); err != nil {
			return 0, err
		}
	}
	return len(p), nil
}

func TestCarrierHealthInitialPayloadBeforeSessionPublication(t *testing.T) {
	for _, drop := range []bool{false, true} {
		t.Run(map[bool]string{false: "roundtrip", true: "blackhole"}[drop], func(t *testing.T) {
			origin, wirePeer := net.Pipe()
			peer := &healthDropReplyConn{Conn: wirePeer}
			peer.drop.Store(drop)
			egress := newSession(peer, "egress", 0, nil)
			egress.token = "health-test"
			peerDone := make(chan struct{})
			go func() { defer close(peerDone); egress.readLoop() }()
			t.Cleanup(func() { origin.Close(); egress.Close(); awaitDone(t, peerDone) })
			s, err := authenticateOriginSessionContext(context.Background(), authDeadlineIgnoringConn{origin}, &Config{Token: "health-test"}, "test", TransportTLS, 150*time.Millisecond)
			if drop {
				if s != nil || !errors.Is(err, context.DeadlineExceeded) || !strings.Contains(err.Error(), "negotiate-carrier-health") {
					t.Fatalf("blackholed initial payload was published: session=%v error=%v", s, err)
				}
			} else {
				if err != nil {
					t.Fatal(err)
				}
				t.Cleanup(func() { s.Close(); reg.remove(s) })
				if !s.carrierHealth.supportsPayload() || s.carrierHealth.pending != nil || s.streamCount() != 0 {
					t.Fatal("session escaped without completed payload proof")
				}
			}
			if !peer.seen.Load() {
				t.Fatal("test did not reach full payload exchange")
			}
		})
	}
}

func TestCarrierHealthLegacyCapabilityEcho(t *testing.T) {
	a, b := net.Pipe()
	origin := newSession(a, "origin", 0, nil)
	origin.markAuthenticated()
	origin.fixedInitialWindow.Store(true)
	defer origin.Close()
	defer b.Close()
	a.SetDeadline(time.Now().Add(time.Second))
	peerDone := make(chan error, 1)
	go func() {
		s := &Session{conn: b}
		h, payload, err := readCarrierHealthFrame(s)
		if err == nil && h.Cmd != CmdPing {
			err = errors.New("expected capability Ping")
		}
		if err == nil {
			err = authRegressionWriteFrame(b, CmdPong, payload, 0)
		}
		peerDone <- err
	}()
	if err := negotiateCarrierHealth(origin); err != nil {
		t.Fatal(err)
	}
	if err := <-peerDone; err != nil {
		t.Fatal(err)
	}
	if origin.carrierHealth.mode != carrierHealthLegacy || origin.carrierHealth.supportsPayload() {
		t.Fatal("ordinary legacy echo enabled payload commands")
	}
}

func TestCarrierHealthOldestPeerUsesBoundedControlFallback(t *testing.T) {
	s := newSession(nil, "origin", 0, nil)
	defer s.Close()
	s.markAuthenticated()
	if err := negotiateCarrierHealth(s); err != nil {
		t.Fatal(err)
	}
	if !s.runCarrierHealth(time.Now().Add(carrierHealthInterval)) {
		t.Fatal("legacy carrier closed")
	}
	if len(s.dataQ) != 0 || len(s.bestEffortQ) != 1 {
		t.Fatal("legacy peer received an unsupported payload command")
	}
	req := <-s.bestEffortQ
	if req.h.Cmd != CmdPing || len(req.payload) != 8 {
		t.Fatal("legacy fallback is not an 8-byte Ping")
	}
	if !s.carrierHealth.accept(carrierHealthLegacy, req.payload, time.Now().Add(carrierHealthInterval+time.Second)) {
		t.Fatal("legacy heartbeat was not correlated")
	}
}

func healthTestWriteFrame(conn net.Conn, h Header, payload []byte) error {
	h.Length = uint32(len(payload))
	wire := make([]byte, HeaderSize+len(payload))
	h.encodeTo(wire)
	copy(wire[HeaderSize:], payload)
	_, err := writeFull(conn, wire)
	return err
}

func TestCarrierHealthNegotiationRejectsMismatchAndFlood(t *testing.T) {
	for _, scenario := range []string{"nonce", "prefix", "payload", "control-flood"} {
		t.Run(scenario, func(t *testing.T) {
			a, b := net.Pipe()
			origin := newSession(a, "origin", 0, nil)
			origin.markAuthenticated()
			origin.fixedInitialWindow.Store(true)
			t.Cleanup(origin.Close)
			t.Cleanup(func() { b.Close() })
			a.SetDeadline(time.Now().Add(time.Second))
			peerDone := make(chan struct{})
			go func() {
				defer close(peerDone)
				s := &Session{conn: b}
				_, payload, err := readCarrierHealthFrame(s)
				if err != nil {
					return
				}
				if scenario == "control-flood" {
					resize := make([]byte, 4)
					binary.BigEndian.PutUint32(resize, uint32(flowSettings.normalWindow))
					for i := 0; i < maxCarrierHealthFrames; i++ {
						if healthTestWriteFrame(b, ctrlHeader(CmdWindowResize, 0, 0), resize) != nil {
							return
						}
					}
					return
				}
				binary.BigEndian.PutUint32(payload, carrierHealthReplyPrefix)
				switch scenario {
				case "nonce":
					payload[7] ^= 1
				case "prefix":
					payload[0] ^= 1
				}
				if healthTestWriteFrame(b, ctrlHeader(CmdPong, 0, 0), payload) != nil || scenario != "payload" {
					return
				}
				_, payload, err = readCarrierHealthFrame(s)
				if err != nil {
					return
				}
				payload[len(payload)-1] ^= 1
				_ = healthTestWriteFrame(b, carrierHealthHeader(CmdCarrierHealthReply), payload)
			}()
			if err := negotiateCarrierHealth(origin); err == nil {
				t.Fatal("invalid capability/payload proof accepted")
			}
			origin.Close()
			b.Close()
			awaitDone(t, peerDone)
		})
	}
}
