package main

import (
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/tls"
	"encoding/binary"
	"encoding/hex"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"golang.org/x/net/http2"
)

// This filter is above the real WSS/XHTTP carrier, after TLS decryption. The
// test deliberately discards authenticated application replies while transport
// reads, writes and control Pongs remain working. It does not model an ISP or
// claim that an encrypted HTTP path is observable to an on-path adversary.
type healthTransportFilter struct {
	net.Conn
	buffer       []byte // owned by the single session reader
	legacy       bool   // immutable legacy capability reply emulation
	blackhole    atomic.Bool
	closed       atomic.Bool
	requests     atomic.Int64
	requestBytes atomic.Int64
	replies      atomic.Int64
	legacyPings  atomic.Int64
	droppedData  atomic.Int64
	droppedProof atomic.Int64
}

func (c *healthTransportFilter) Read(p []byte) (int, error) {
	if len(p) == 0 {
		return 0, nil
	}
	if len(c.buffer) == 0 {
		var header [HeaderSize]byte
		if _, err := io.ReadFull(c.Conn, header[:]); err != nil {
			return 0, err
		}
		h, err := DecodeHeader(header[:])
		if err != nil {
			return 0, err
		}
		frame := make([]byte, HeaderSize+int(h.Length)+int(h.PadLen))
		copy(frame, header[:])
		if _, err := io.ReadFull(c.Conn, frame[HeaderSize:]); err != nil {
			return 0, err
		}
		if h.Cmd == CmdCarrierHealth {
			c.requests.Add(1)
			c.requestBytes.Add(int64(h.Length))
		}
		if h.Cmd == CmdPing && h.Length == 8 {
			prefix := binary.BigEndian.Uint32(frame[HeaderSize:])
			if prefix != carrierHealthQueryPrefix && prefix != initialWindowQueryPrefix {
				c.legacyPings.Add(1)
			}
		}
		c.buffer = frame
	}
	n := copy(p, c.buffer)
	c.buffer = c.buffer[n:]
	return n, nil
}

func (c *healthTransportFilter) Write(p []byte) (int, error) {
	var forward []byte
	for offset := 0; offset < len(p); {
		if len(p)-offset < HeaderSize {
			return 0, io.ErrUnexpectedEOF
		}
		h, err := DecodeHeader(p[offset : offset+HeaderSize])
		if err != nil {
			return 0, err
		}
		end := offset + HeaderSize + int(h.Length) + int(h.PadLen)
		if end > len(p) {
			return 0, io.ErrUnexpectedEOF
		}
		frame := append([]byte(nil), p[offset:end]...)
		if c.legacy && h.Cmd == CmdPong && binary.BigEndian.Uint32(frame[HeaderSize:]) == carrierHealthReplyPrefix {
			// A genuine legacy implementation echoes GHC1 unchanged. Emulate
			// that on the actual transport without claiming new-peer coverage.
			binary.BigEndian.PutUint32(frame[HeaderSize:], carrierHealthQueryPrefix)
		}
		drop := false
		if h.Cmd == CmdCarrierHealthReply {
			c.replies.Add(1)
			if c.blackhole.Load() {
				c.droppedProof.Add(1)
				drop = true
			}
		}
		if h.Cmd == CmdData && c.blackhole.Load() {
			c.droppedData.Add(int64(h.Length))
			drop = true
		}
		if !drop {
			forward = append(forward, frame...)
		}
		offset = end
	}
	if len(forward) > 0 {
		if _, err := writeFull(c.Conn, forward); err != nil {
			return 0, err
		}
	}
	return len(p), nil
}

func (c *healthTransportFilter) Close() error {
	c.closed.Store(true)
	return c.Conn.Close()
}

type healthTransportPeer struct {
	filter  *healthTransportFilter
	session *Session
	path    string
}

type healthTransportHarness struct {
	cfg       *Config
	transport *originTransport
	endpoint  string
	target    string
	peers     chan healthTransportPeer
	posts     atomic.Int64
}

func newHealthTransportHarness(t *testing.T, kind string, legacy bool) *healthTransportHarness {
	t.Helper()
	const host = "health-recovery-loopback.example.com"
	target := managedTestListener(t, func(c net.Conn) {
		_, _ = io.Copy(c, c)
		_ = c.(*net.TCPConn).CloseWrite()
	})
	allow, err := ParseAllowList(target.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	dir := t.TempDir()
	cert, err := loadOrCreateCert(filepath.Join(dir, "test.crt"), filepath.Join(dir, "test.key"), host, false)
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(cert.Certificate[0])
	cfg := &Config{Mode: "origin", Transport: kind, XHTTPMode: "packet-up",
		Token: "health-recovery-local-shared-secret", WSHost: host, SNI: host,
		WSPath: "/health-shared-wss-seed", XHTTPPath: "/health-shared-xhttp-seed",
		UTLSProfile: "chrome", ECHMode: ECHModeOff, Fingerprint: hex.EncodeToString(sum[:]),
		PathRotation: time.Hour, PathCount: 3, PathGrace: 5 * time.Minute, allowList: allow}
	if err := validateRotationConfig(cfg); err != nil {
		t.Fatal(err)
	}
	harness := &healthTransportHarness{cfg: cfg, target: target.Addr().String(), peers: make(chan healthTransportPeer, 8)}
	serve := func(conn net.Conn, path string) {
		filter := &healthTransportFilter{Conn: conn, legacy: legacy}
		session := newSession(filter, "egress", 0, allow)
		session.token = cfg.Token
		harness.peers <- healthTransportPeer{filter, session, strings.TrimSuffix(path, "/")}
		session.readLoop()
	}
	var xhttp *xhttpServer
	xhttp = newXHTTPServer(cfg, func(conn net.Conn, _ string) {
		var path string
		xhttp.mu.Lock()
		for _, session := range xhttp.sessions {
			if session.app == conn {
				path = session.routeBase
				break
			}
		}
		xhttp.mu.Unlock()
		serve(conn, path)
	})
	t.Cleanup(xhttp.Close)
	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost {
			harness.posts.Add(1)
		}
		xhttp.ServeHTTP(w, r)
	})
	server := managedTestListener(t, func(raw net.Conn) {
		alpn := "http/1.1"
		if kind == TransportXHTTP {
			alpn = "h2"
		}
		_ = raw.SetDeadline(time.Now().Add(5 * time.Second))
		conn := tls.Server(raw, &tls.Config{Certificates: []tls.Certificate{cert}, MinVersion: tls.VersionTLS13, NextProtos: []string{alpn}})
		if err := conn.Handshake(); err != nil {
			return
		}
		_ = raw.SetDeadline(time.Time{})
		if kind == TransportXHTTP {
			(&http2.Server{}).ServeConn(conn, &http2.ServeConnOpts{Handler: handler})
			return
		}
		var path string
		ws, _, err := acceptServerWebSocketPaths(conn, host, cfg.Token, func(candidate string) bool {
			if !acceptsTransportPath(cfg, candidate, time.Now()) {
				return false
			}
			path = candidate
			return true
		})
		if err == nil {
			serve(ws, path)
		}
	})
	harness.endpoint = server.Addr().String()
	harness.transport, err = newOriginTransport(cfg)
	if err != nil {
		t.Fatal(err)
	}
	return harness
}

func awaitHealthTransport(t *testing.T, description string, condition func() bool) {
	t.Helper()
	deadline := time.NewTimer(5 * time.Second)
	defer deadline.Stop()
	tick := time.NewTicker(time.Millisecond)
	defer tick.Stop()
	for !condition() {
		select {
		case <-deadline.C:
			t.Fatalf("timed out waiting for %s", description)
		case <-tick.C:
		}
	}
}

func receiveHealthTransportPeer(t *testing.T, peers <-chan healthTransportPeer) healthTransportPeer {
	t.Helper()
	select {
	case peer := <-peers:
		return peer
	case <-time.After(5 * time.Second):
		t.Fatal("no accepted transport peer")
		return healthTransportPeer{}
	}
}

func healthTransportClientEcho(t *testing.T, session *Session, target string, label string) *net.TCPConn {
	t.Helper()
	client, edge := tcpTestPair(t)
	_ = edge.SetDeadline(time.Time{})
	_ = client.SetDeadline(time.Now().Add(5 * time.Second))
	if err := session.OpenStream(target, edge); err != nil {
		t.Fatal(err)
	}
	payload := bytes.Repeat([]byte(label), 2048)
	written := make(chan error, 1)
	go func() { _, err := writeFull(client, payload); written <- err }()
	reply := make([]byte, len(payload))
	if _, err := io.ReadFull(client, reply); err != nil {
		t.Fatal(err)
	}
	if err := <-written; err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(payload, reply) {
		t.Fatal("client payload corrupted")
	}
	return client
}

func TestCarrierHealthRealTransportBlackholePoolRecovery(t *testing.T) {
	for _, kind := range []string{TransportWSS, TransportXHTTP} {
		t.Run(kind, func(t *testing.T) {
			harness := newHealthTransportHarness(t, kind, false)
			done := make(chan struct{})
			ctx, cancel := context.WithCancel(context.Background())
			pool := newSessionPool(1, 1, done, func() (*Session, error) {
				session, _, err := harness.transport.dialAuthenticatedContext(ctx, harness.endpoint, harness.cfg)
				return session, err
			})
			t.Cleanup(func() {
				close(done)
				cancel()
				if s := pool.slots[0].current(); s != nil {
					s.Close()
				}
			})
			original, release, err := pool.Get()
			if err != nil {
				t.Fatal(err)
			}
			release()
			first := receiveHealthTransportPeer(t, harness.peers)
			if first.path == "" || !original.carrierHealth.supportsPayload() || first.filter.requests.Load() != 1 || first.filter.requestBytes.Load() != carrierHealthPayloadSize {
				t.Fatal("carrier published without negotiated initial payload proof over transport")
			}
			client := healthTransportClientEcho(t, original, harness.target, "verified-before-health-blackhole")
			first.filter.blackhole.Store(true)
			if _, err := writeFull(client, []byte("payload-that-must-not-return")); err != nil {
				t.Fatal(err)
			}
			awaitHealthTransport(t, "discarded target echo", func() bool { return first.filter.droppedData.Load() > 0 })
			_ = client.SetReadDeadline(time.Now().Add(30 * time.Millisecond))
			var one [1]byte
			if n, err := client.Read(one[:]); n != 0 || err == nil {
				t.Fatalf("payload blackhole not established: bytes=%d error=%v", n, err)
			} else if timeout, ok := err.(net.Error); !ok || !timeout.Timeout() {
				t.Fatalf("transport closed instead of remaining blackholed: %v", err)
			}
			_ = client.SetReadDeadline(time.Now().Add(5 * time.Second))
			// These are synthetic watchdog timestamps, not a 75-second soak.
			// Each probe still traverses actual TLS and WSS/XHTTP before expiry.
			now := time.Now().Add(time.Minute)
			for attempt := 0; attempt < carrierHealthFailures; attempt++ {
				previous := first.filter.requests.Load()
				if !original.runCarrierHealth(now) {
					t.Fatal("carrier failed before consecutive miss threshold")
				}
				awaitHealthTransport(t, "real transported health request", func() bool { return first.filter.requests.Load() == previous+1 })
				awaitHealthTransport(t, "discarded full health reply", func() bool { return first.filter.droppedProof.Load() == int64(attempt+1) })
				if original.Closed() || first.session.Closed() || first.filter.closed.Load() {
					t.Fatal("carrier socket closed before watchdog threshold")
				}
				// An unrelated authenticated control echo is also insufficient.
				ping := make([]byte, 8)
				binary.BigEndian.PutUint64(ping, uint64(attempt+12345))
				oldBytes := original.bytesIn.Load()
				if err := original.writeFrame(ctrlHeader(CmdPing, 0, 0), ping); err != nil {
					t.Fatal(err)
				}
				awaitHealthTransport(t, "unrelated control reply on open carrier", func() bool { return original.bytesIn.Load() > oldBytes })
				alive := original.runCarrierHealth(now.Add(carrierHealthTimeout))
				if alive != (attempt+1 < carrierHealthFailures) {
					t.Fatalf("attempt %d alive=%t", attempt+1, alive)
				}
				now = now.Add(carrierHealthInterval + carrierHealthTimeout)
			}
			if !original.Closed() {
				t.Fatal("failed carrier remained selectable")
			}
			quarantined := harness.transport.routeQuarantined(first.path, time.Now(), harness.endpoint)
			if !quarantined {
				t.Fatal("health failure did not quarantine the exact failing route")
			}
			// Wait for the pool's own background supervisor; do not manually
			// dial the replacement or have a new client trigger its creation.
			awaitHealthTransport(t, "automatic pool reconnection", func() bool {
				s := pool.slots[0].current()
				return s != nil && s != original
			})
			replacement, release, err := pool.Get()
			if err != nil {
				t.Fatal(err)
			}
			release()
			second := receiveHealthTransportPeer(t, harness.peers)
			if second.path == first.path {
				t.Fatal("pool reconnected on the quarantined path")
			}
			if _, ok := recoveryPathEpoch(harness.cfg, second.path, time.Now()); !ok {
				t.Fatal("replacement did not use a valid newly signed recovery route")
			}
			if !replacement.carrierHealth.supportsPayload() || second.filter.requests.Load() != 1 {
				t.Fatal("replacement published before full payload proof")
			}
			recoveredClient := healthTransportClientEcho(t, replacement, harness.target, "verified-after-signed-route-recovery")
			_ = recoveredClient.Close()
			_ = client.Close()
			if kind == TransportXHTTP && harness.posts.Load() == 0 {
				t.Fatal("test did not traverse packet-up HTTP POST transport")
			}
			t.Logf("transport=%s mode=%s real_client_echo_before_after=true initial_probe_bytes=%d lost_real_health_replies=%d automatic_pool_reconnect=true different_signed_route=true health_clock=accelerated_not_75s_soak", kind, harness.cfg.XHTTPMode, carrierHealthPayloadSize, first.filter.droppedProof.Load())
		})
	}
}

func TestCarrierHealthRealTransportLegacyCoverage(t *testing.T) {
	for _, kind := range []string{TransportWSS, TransportXHTTP} {
		t.Run(kind, func(t *testing.T) {
			harness := newHealthTransportHarness(t, kind, true)
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()
			session, _, err := harness.transport.dialAuthenticatedContext(ctx, harness.endpoint, harness.cfg)
			if err != nil {
				t.Fatal(err)
			}
			t.Cleanup(session.Close)
			peer := receiveHealthTransportPeer(t, harness.peers)
			if session.carrierHealth.supportsPayload() || peer.filter.requests.Load() != 0 {
				t.Fatal("legacy capability echo silently enabled full payload coverage")
			}
			client := healthTransportClientEcho(t, session, harness.target, "legacy-control-only-coverage")
			peer.filter.blackhole.Store(true)
			if _, err := fmt.Fprint(client, "blackholed-legacy-data"); err != nil {
				t.Fatal(err)
			}
			awaitHealthTransport(t, "legacy payload blackhole", func() bool { return peer.filter.droppedData.Load() > 0 })
			if !session.runCarrierHealth(time.Now().Add(carrierHealthInterval)) {
				t.Fatal("legacy heartbeat did not start")
			}
			awaitHealthTransport(t, "legacy control heartbeat exchange", func() bool {
				session.carrierHealth.mu.Lock()
				defer session.carrierHealth.mu.Unlock()
				return peer.filter.legacyPings.Load() > 0 && session.carrierHealth.pending == nil
			})
			if session.Closed() || peer.filter.requests.Load() != 0 || peer.filter.replies.Load() != 0 {
				t.Fatal("legacy control proof confused with full payload proof")
			}
			_ = client.Close()
			t.Logf("transport=%s legacy_reply_emulated=true control_heartbeat_works_during_payload_blackhole=true full_payload_coverage=false", kind)
		})
	}
}

// Opt in with UNUNKNOWNTUN_REALTIME_HEALTH_TEST=1. Unlike the fast tests above, this
// regression never calls runCarrierHealth or changes health-state timestamps:
// production keepalive timers must detect the payload blackhole. The two real
// transports run concurrently, so the group normally takes about 75-80 seconds.
func TestCarrierHealthRealtimeTransportRecovery(t *testing.T) {
	if os.Getenv("UNUNKNOWNTUN_REALTIME_HEALTH_TEST") != "1" {
		t.Skip("set UNUNKNOWNTUN_REALTIME_HEALTH_TEST=1 for the approximately 80-second production-clock recovery test")
	}
	for _, kind := range []string{TransportWSS, TransportXHTTP} {
		t.Run(kind, func(t *testing.T) {
			t.Parallel()
			harness := newHealthTransportHarness(t, kind, false)
			done := make(chan struct{})
			ctx, cancel := context.WithCancel(context.Background())
			pool := newSessionPool(1, 1, done, func() (*Session, error) {
				session, _, err := harness.transport.dialAuthenticatedContext(ctx, harness.endpoint, harness.cfg)
				return session, err
			})
			t.Cleanup(func() {
				close(done)
				cancel()
				if session := pool.slots[0].current(); session != nil {
					session.Close()
				}
			})
			original, release, err := pool.Get()
			if err != nil {
				t.Fatal(err)
			}
			release()
			first := receiveHealthTransportPeer(t, harness.peers)
			if first.path == "" || !original.carrierHealth.supportsPayload() || first.filter.requests.Load() != 1 {
				t.Fatal("initial carrier lacked its real full-payload proof")
			}
			client := healthTransportClientEcho(t, original, harness.target, "realtime-before-payload-blackhole")
			original.carrierHealth.mu.Lock()
			firstDue := original.carrierHealth.next
			alreadyPending := original.carrierHealth.pending != nil
			original.carrierHealth.mu.Unlock()
			if alreadyPending {
				t.Fatal("fixture setup unexpectedly ran into the first periodic probe")
			}
			started := time.Now()
			// Use the actual initial next-due timestamp, not an assumed setup
			// duration. Production polling can delay this bound, never hasten it.
			earliestFailure := firstDue.Add(carrierHealthTimeout + (carrierHealthFailures-1)*(carrierHealthInterval+carrierHealthTimeout))
			minimumElapsed := earliestFailure.Sub(started) - time.Second
			if minimumElapsed < 65*time.Second {
				t.Fatalf("fixture left insufficient real-clock proof interval: %s", minimumElapsed)
			}
			const maximumElapsed = 110 * time.Second
			budget, stopBudget := context.WithTimeout(context.Background(), maximumElapsed)
			// Closing carriers at the hard budget also unblocks OpenStream or
			// client IO if a broken replacement stalls those operations. The
			// failed flag below distinguishes this test guard from the watchdog.
			stopGuard := context.AfterFunc(budget, func() {
				cancel()
				original.Close()
				if session := pool.slots[0].current(); session != nil {
					session.Close()
				}
			})
			t.Cleanup(func() { stopGuard(); stopBudget() })
			first.filter.blackhole.Store(true)
			if _, err := writeFull(client, []byte("realtime-target-echo-must-be-dropped")); err != nil {
				t.Fatal(err)
			}
			awaitHealthTransport(t, "real-clock target payload blackhole", func() bool { return first.filter.droppedData.Load() > 0 })
			_ = client.SetReadDeadline(time.Now().Add(30 * time.Millisecond))
			var one [1]byte
			if n, err := client.Read(one[:]); n != 0 || err == nil {
				t.Fatalf("target echo was not blackholed: bytes=%d error=%v", n, err)
			} else if timeout, ok := err.(net.Error); !ok || !timeout.Timeout() {
				t.Fatalf("carrier closed instead of staying connected: %v", err)
			}
			_ = client.SetReadDeadline(time.Time{})
			// Confirm that control traffic still makes a real roundtrip, then
			// leave detection entirely to the production keepalive goroutine.
			beforeControl := original.bytesIn.Load()
			ping := make([]byte, 8)
			binary.BigEndian.PutUint64(ping, 43210)
			if err := original.writeFrame(ctrlHeader(CmdPing, 0, 0), ping); err != nil {
				t.Fatal(err)
			}
			awaitHealthTransport(t, "control Pong on blackholed real-clock carrier", func() bool { return original.bytesIn.Load() > beforeControl })
			t.Logf("transport=%s health_clock=production_real_time minimum_detection_seconds=%.3f maximum_total_seconds=110 waiting_for_production_keepalive=true", kind, minimumElapsed.Seconds())
			select {
			case <-original.done:
			case <-budget.Done():
				t.Fatal("production watchdog did not close the blackholed carrier within 110 seconds")
			}
			detectedAfter := time.Since(started)
			original.carrierHealth.mu.Lock()
			watchdogFailed := original.carrierHealth.failed
			misses := original.carrierHealth.failures
			original.carrierHealth.mu.Unlock()
			if !watchdogFailed || misses != carrierHealthFailures || detectedAfter < minimumElapsed || detectedAfter >= maximumElapsed {
				t.Fatalf("not a correctly timed production watchdog failure: failed=%t misses=%d wall=%s minimum=%s", watchdogFailed, misses, detectedAfter, minimumElapsed)
			}
			if first.filter.requests.Load() != 1+carrierHealthFailures || first.filter.droppedProof.Load() != carrierHealthFailures {
				t.Fatalf("missing real periodic payload probes: requests=%d discarded_replies=%d", first.filter.requests.Load(), first.filter.droppedProof.Load())
			}
			quarantined := harness.transport.routeQuarantined(first.path, time.Now(), harness.endpoint)
			if !quarantined {
				t.Fatal("real-clock health failure did not quarantine its route")
			}
			awaitHealthTransport(t, "automatic real-clock pool replacement", func() bool {
				session := pool.slots[0].current()
				return session != nil && session != original
			})
			replacement, release, err := pool.Get()
			if err != nil {
				t.Fatal(err)
			}
			release()
			second := receiveHealthTransportPeer(t, harness.peers)
			if second.path == first.path {
				t.Fatal("real-clock recovery reused its failed path")
			}
			if _, ok := recoveryPathEpoch(harness.cfg, second.path, time.Now()); !ok {
				t.Fatal("real-clock recovery did not use a valid signed route")
			}
			if !replacement.carrierHealth.supportsPayload() || second.filter.requests.Load() != 1 {
				t.Fatal("replacement escaped before its real initial payload proof")
			}
			recoveredClient := healthTransportClientEcho(t, replacement, harness.target, "realtime-after-signed-route-recovery")
			_ = recoveredClient.Close()
			_ = client.Close()
			totalElapsed := time.Since(started)
			if budget.Err() != nil || totalElapsed >= maximumElapsed {
				t.Fatalf("recovery exceeded its 110-second wall-clock budget: %s", totalElapsed)
			}
			if kind == TransportXHTTP && harness.posts.Load() == 0 {
				t.Fatal("real-clock test did not traverse packet-up POSTs")
			}
			t.Logf("transport=%s health_clock=production_real_time synthetic_ticks=0 wall_detection_seconds=%.3f wall_recovery_seconds=%.3f discarded_real_health_replies=%d automatic_pool_reconnect=true different_signed_route=true client_echo_before_after=true", kind, detectedAfter.Seconds(), totalElapsed.Seconds(), first.filter.droppedProof.Load())
		})
	}
}
