package main

import "log"

// Immutable metadata is published atomically because authentication starts
// the session reader and health watcher before the dial returns to its pool.
type carrierRoute struct {
	epoch     int64
	rotating  bool
	onFailure func()
}

func (s *Session) routeEpoch() (int64, bool) {
	r := s.route.Load()
	if r == nil || !r.rotating {
		return 0, false
	}
	return r.epoch, true
}

func (s *Session) setRouteEpoch(epoch int64) {
	s.route.Store(&carrierRoute{epoch: epoch, rotating: true})
}

func (s *Session) failCarrierHealth(reason string) {
	if s.Closed() {
		return
	}
	if r := s.route.Load(); r != nil && r.onFailure != nil {
		r.onFailure()
	}
	log.Printf("[%s] [carrier-health] %s; closing failed carrier for reconnect", s.side, reason)
	s.Close()
}
