package main

// Direct ICMP is a standalone encrypted IPv4 link. It deliberately owns only
// its TUN and explicit peer routes. Optional source rotation owns one isolated
// nftables NAT table; the host default route and existing firewall stay intact.
import (
	"bytes"
	"context"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"net/netip"
	"os"
	"os/signal"
	"path/filepath"
	"strings"
	"syscall"
	"time"
)

type DirectICMPConfig struct {
	Role               string                  `json:"role"`
	Interface          string                  `json:"interface"`
	TUNName            string                  `json:"tun_name"`
	LocalIP            string                  `json:"local_ip"`
	PeerIP             string                  `json:"peer_ip"`
	InnerLocalIP       string                  `json:"inner_local_ip"`
	InnerPeerIP        string                  `json:"inner_peer_ip"`
	LocalCIDRs         []string                `json:"local_cidrs,omitempty"`
	PeerCIDRs          []string                `json:"peer_cidrs,omitempty"`
	LocalPoolCIDR      string                  `json:"local_pool_cidr,omitempty"`
	PeerPoolCIDR       string                  `json:"peer_pool_cidr,omitempty"`
	SourceRotation     string                  `json:"source_rotation,omitempty"`
	KeyFile            string                  `json:"key_file"`
	MTU                int                     `json:"mtu"`
	PollMS             int                     `json:"poll_ms"`
	TimeoutSeconds     int                     `json:"timeout_seconds"`
	RekeySeconds       int                     `json:"rekey_seconds"`
	FECMode            string                  `json:"fec_mode,omitempty"`
	FECPercent         int                     `json:"fec_percent"`
	FECMaxPercent      int                     `json:"fec_max_percent,omitempty"`
	FECBlockMS         int                     `json:"fec_block_ms,omitempty"`
	PortForwards       []DirectICMPPortForward `json:"port_forwards,omitempty"`
	ForwardIdleSeconds int                     `json:"forward_idle_seconds,omitempty"`
	key                [32]byte
}

func (c *DirectICMPConfig) defaults() {
	if c.ForwardIdleSeconds == 0 {
		c.ForwardIdleSeconds = 180
	}
	// Omitted legacy configurations retain GDL1; only the new pair wizard
	// opts both peers into the versioned FEC protocol.
	if c.SourceRotation == "" {
		c.SourceRotation = "off"
	}
	if c.FECMode == "" {
		c.FECMode = "off"
	}
	if c.FECMaxPercent == 0 {
		c.FECMaxPercent = 25
	}
	if c.FECBlockMS == 0 {
		c.FECBlockMS = 20
	}

	if c.MTU == 0 {
		c.MTU = 1200
	}
	if c.PollMS == 0 {
		c.PollMS = 20
	}
	if c.TimeoutSeconds == 0 {
		c.TimeoutSeconds = 15
	}
	if c.RekeySeconds == 0 {
		c.RekeySeconds = 3600
	}
}

func directICMPPrivatePrefix(s string) (netip.Prefix, error) {
	p, err := netip.ParsePrefix(s)
	if err != nil || !p.Addr().Is4() || p.Masked() != p || p.String() != s || p.Bits() == 0 {
		return netip.Prefix{}, errors.New("require a canonical private IPv4 prefix")
	}
	for _, allowed := range []string{"10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"} {
		a := netip.MustParsePrefix(allowed)
		if p.Bits() >= a.Bits() && a.Contains(p.Addr()) {
			return p, nil
		}
	}
	return netip.Prefix{}, errors.New("only RFC1918 routed prefixes are accepted; public/default routes are not installed")
}

func (c *DirectICMPConfig) validate() error {
	if c == nil {
		return errors.New("[direct-icmp/config] missing configuration")
	}
	if c.Role != "origin" && c.Role != "egress" {
		return errors.New("[direct-icmp/config] role must be origin or egress")
	}
	if !greInterfaceName.MatchString(c.Interface) || !greInterfaceName.MatchString(c.TUNName) || c.Interface == "lo" || c.TUNName == "lo" || c.Interface == c.TUNName {
		return errors.New("[direct-icmp/config] distinct interface and TUN names required, 1..15 safe characters, not lo")
	}
	if c.MTU < 576 || c.MTU > 1400 {
		return errors.New("[direct-icmp/config] mtu must be 576..1400 and also fit the physical MTU with wire overhead")
	}
	if c.PollMS < 5 || c.PollMS > 1000 {
		return errors.New("[direct-icmp/config] poll_ms must be 5..1000")
	}
	if c.TimeoutSeconds < 5 || c.TimeoutSeconds > 300 {
		return errors.New("[direct-icmp/config] timeout_seconds must be 5..300")
	}
	if c.RekeySeconds < 60 || c.RekeySeconds > 86400 || c.RekeySeconds <= 2*c.TimeoutSeconds {
		return errors.New("[direct-icmp/config] rekey_seconds must be 60..86400 and greater than twice timeout_seconds")
	}
	if c.FECMode != "off" && c.FECMode != "fixed" && c.FECMode != "adaptive" {
		return errors.New("[direct-icmp/config] fec_mode must be off, fixed or adaptive")
	}
	if c.FECMaxPercent < 5 || c.FECMaxPercent > 50 || c.FECPercent < 0 || c.FECPercent > c.FECMaxPercent {
		return errors.New("[direct-icmp/config] fec_max_percent must be 5..50; fec_percent must be 0..fec_max_percent")
	}
	if c.FECBlockMS < 5 || c.FECBlockMS > 100 {
		return errors.New("[direct-icmp/config] fec_block_ms must be 5..100")
	}
	for field, s := range map[string]string{"local_ip": c.LocalIP, "peer_ip": c.PeerIP, "inner_local_ip": c.InnerLocalIP, "inner_peer_ip": c.InnerPeerIP} {
		if _, err := greUnicastIPv4(s); err != nil {
			return fmt.Errorf("[direct-icmp/config] %s: %w", field, err)
		}
	}
	local, peer := netip.MustParseAddr(c.InnerLocalIP), netip.MustParseAddr(c.InnerPeerIP)
	if !local.IsPrivate() || !peer.IsPrivate() || local == peer || c.LocalIP == c.PeerIP {
		return errors.New("[direct-icmp/config] distinct outer peers and distinct private inner IPv4 addresses required")
	}
	if c.LocalIP == c.InnerLocalIP || c.LocalIP == c.InnerPeerIP || c.PeerIP == c.InnerLocalIP || c.PeerIP == c.InnerPeerIP {
		return errors.New("[direct-icmp/config] outer and inner addresses must differ")
	}
	if !filepath.IsAbs(c.KeyFile) || filepath.Clean(c.KeyFile) != c.KeyFile || strings.IndexByte(c.KeyFile, 0) >= 0 {
		return errors.New("[direct-icmp/config] key_file must be a clean absolute path")
	}
	if len(c.LocalCIDRs) > 16 || len(c.PeerCIDRs) > 16 {
		return errors.New("[direct-icmp/config] at most 16 routed prefixes per side")
	}
	groups := [][]string{c.LocalCIDRs, c.PeerCIDRs}
	parsed := [2][]netip.Prefix{{netip.PrefixFrom(local, 32)}, {netip.PrefixFrom(peer, 32)}}
	for side, list := range groups {
		seen := map[string]bool{}
		for _, s := range list {
			p, err := directICMPPrivatePrefix(s)
			if err != nil {
				return fmt.Errorf("[direct-icmp/config] routed prefix: %w", err)
			}
			if seen[s] {
				return errors.New("[direct-icmp/config] duplicate routed prefix")
			}
			seen[s] = true
			if p.Contains(netip.MustParseAddr(c.LocalIP)) || p.Contains(netip.MustParseAddr(c.PeerIP)) {
				return errors.New("[direct-icmp/config] routed prefix overlaps an outer address")
			}
			for _, old := range parsed[side][1:] {
				if old.Overlaps(p) {
					return errors.New("[direct-icmp/config] overlapping routed prefixes on one side")
				}
			}
			parsed[side] = append(parsed[side], p)
		}
	}
	for _, l := range parsed[0] {
		for _, p := range parsed[1] {
			if l.Overlaps(p) {
				return errors.New("[direct-icmp/config] local and peer inner ranges overlap")
			}
		}
	}
	if err := c.validatePools(); err != nil {
		return err
	}
	return c.validatePortForwards()
}

func parseDirectICMPConfig(data []byte) (*DirectICMPConfig, error) {
	if len(data) > 16384 {
		return nil, errors.New("[direct-icmp/config] JSON exceeds 16 KiB")
	}
	d := json.NewDecoder(bytes.NewReader(data))
	tok, err := d.Token()
	if err != nil || tok != json.Delim('{') {
		return nil, errors.New("[direct-icmp/config] expected JSON object")
	}
	allowed := map[string]bool{"role": true, "interface": true, "tun_name": true, "local_ip": true, "peer_ip": true, "inner_local_ip": true, "inner_peer_ip": true, "local_cidrs": true, "peer_cidrs": true, "key_file": true, "mtu": true, "poll_ms": true, "timeout_seconds": true, "rekey_seconds": true, "fec_mode": true, "fec_percent": true, "fec_max_percent": true, "fec_block_ms": true, "local_pool_cidr": true, "peer_pool_cidr": true, "source_rotation": true}
	seen := map[string]bool{}
	allowed["port_forwards"] = true
	allowed["forward_idle_seconds"] = true
	for d.More() {
		t, err := d.Token()
		if err != nil {
			return nil, errors.New("[direct-icmp/config] invalid key")
		}
		k, ok := t.(string)
		if !ok || !allowed[k] || seen[k] {
			return nil, errors.New("[direct-icmp/config] unknown or duplicate field")
		}
		seen[k] = true
		var v json.RawMessage
		if err := d.Decode(&v); err != nil {
			return nil, errors.New("[direct-icmp/config] invalid JSON value")
		}
		if bytes.Equal(bytes.TrimSpace(v), []byte("null")) {
			return nil, errors.New("[direct-icmp/config] null fields are not accepted")
		}
	}
	if _, err := d.Token(); err != nil {
		return nil, errors.New("[direct-icmp/config] unterminated object")
	}
	if _, err := d.Token(); err != io.EOF {
		return nil, errors.New("[direct-icmp/config] trailing JSON")
	}
	c := DirectICMPConfig{FECMode: "off", FECPercent: 20, FECMaxPercent: 25, FECBlockMS: 20}
	if err := json.Unmarshal(data, &c); err != nil {
		return nil, fmt.Errorf("[direct-icmp/config] %w", err)
	}
	if (seen["fec_mode"] && c.FECMode == "") || (seen["fec_max_percent"] && c.FECMaxPercent == 0) || (seen["fec_block_ms"] && c.FECBlockMS == 0) {
		return nil, errors.New("[direct-icmp/config] explicit FEC mode/cap/deadline must not be empty or zero")
	}
	if seen["source_rotation"] && c.SourceRotation == "" {
		return nil, errors.New("[direct-icmp/config] explicit source_rotation must be off or round-robin")
	}
	if seen["forward_idle_seconds"] && c.ForwardIdleSeconds == 0 {
		return nil, errors.New("[direct-icmp/config] explicit forward_idle_seconds must be 10..3600")
	}
	c.defaults()
	if err := c.validate(); err != nil {
		return nil, err
	}
	return &c, nil
}

func loadDirectICMPConfig(path string) (*DirectICMPConfig, error) {
	f, err := openNativeICMPPrivateFile(path, 16384)
	if err != nil {
		return nil, fmt.Errorf("[direct-icmp/config/file] %w", err)
	}
	defer f.Close()
	data, err := io.ReadAll(io.LimitReader(f, 16385))
	if err != nil {
		return nil, err
	}
	c, err := parseDirectICMPConfig(data)
	if err != nil {
		return nil, err
	}
	k, err := openNativeICMPPrivateFile(c.KeyFile, 65)
	if err != nil {
		return nil, fmt.Errorf("[direct-icmp/key/file] %w", err)
	}
	defer k.Close()
	secret, err := io.ReadAll(io.LimitReader(k, 66))
	if err != nil {
		return nil, err
	}
	if len(secret) == 65 && secret[64] == '\n' {
		secret = secret[:64]
	}
	if len(secret) != 64 {
		return nil, errors.New("[direct-icmp/key] expected 64 hexadecimal characters, optionally one newline")
	}
	if _, err := hex.Decode(c.key[:], secret); err != nil {
		return nil, errors.New("[direct-icmp/key] invalid hexadecimal key")
	}
	if c.key == [32]byte{} {
		return nil, errors.New("[direct-icmp/key] all-zero key is forbidden; generate 32 random bytes")
	}
	return c, nil
}

func (c *DirectICMPConfig) engineConfig() directICMPEngineConfig {
	return directICMPEngineConfig{Initiator: c.Role == "origin", Key: c.key, MTU: c.MTU, PollInterval: time.Duration(c.PollMS) * time.Millisecond, DeadAfter: time.Duration(c.TimeoutSeconds) * time.Second, RekeyAfter: time.Duration(c.RekeySeconds) * time.Second, FECMode: c.FECMode, FECPercent: c.FECPercent, FECMaxPercent: c.FECMaxPercent, FECBlock: time.Duration(c.FECBlockMS) * time.Millisecond}
}

func directICMPAddressAllowed(ip netip.Addr, host string, ranges []string, pool string) bool {
	if pool != "" && directICMPPoolContainsHost(netip.MustParsePrefix(pool), ip) {
		return true
	}
	if ip.String() == host {
		return true
	}
	for _, p := range ranges {
		if netip.MustParsePrefix(p).Contains(ip) {
			return true
		}
	}
	return false
}

// Validate each complete IPv4 datagram before it crosses the TUN boundary.
// Fragments retain their IPv4 semantics; no transport header is assumed on them.
func validateDirectICMPInner(c *DirectICMPConfig, p []byte, receiving bool) error {
	if len(p) < 20 || len(p) > c.MTU || p[0]>>4 != 4 {
		return errors.New("invalid IPv4 packet size/version (IPv6 is unsupported)")
	}
	ihl := int(p[0]&15) * 4
	if ihl < 20 || ihl > len(p) || int(binary.BigEndian.Uint16(p[2:4])) != len(p) || p[8] == 0 || binary.BigEndian.Uint16(p[6:8])&0x8000 != 0 || greChecksum(p[:ihl]) != 0 {
		return errors.New("invalid IPv4 header/length/checksum")
	}
	flags := binary.BigEndian.Uint16(p[6:8])
	if flags&0x4000 != 0 && flags&0x3fff != 0 {
		return errors.New("IPv4 DF is incompatible with fragmentation")
	}
	if flags&0x2000 != 0 && (len(p)-ihl == 0 || (len(p)-ihl)%8 != 0) {
		return errors.New("invalid non-final IPv4 fragment length")
	}
	if flags&0x3fff != 0 && (len(p) == ihl || int(flags&0x1fff)*8+len(p)-ihl > 65535-ihl) {
		return errors.New("invalid IPv4 fragment extent")
	}
	src := netip.AddrFrom4([4]byte{p[12], p[13], p[14], p[15]})
	dst := netip.AddrFrom4([4]byte{p[16], p[17], p[18], p[19]})
	lh, ph, lc, pc := c.InnerLocalIP, c.InnerPeerIP, c.LocalCIDRs, c.PeerCIDRs
	lpool, ppool := c.LocalPoolCIDR, c.PeerPoolCIDR
	if receiving {
		lh, ph, lc, pc = ph, lh, pc, lc
		lpool, ppool = ppool, lpool
	}
	if !directICMPAddressAllowed(src, lh, lc, lpool) || !directICMPAddressAllowed(dst, ph, pc, ppool) {
		return errors.New("inner source/destination outside configured ranges")
	}
	if flags&0x3fff != 0 {
		return nil
	}
	payload := p[ihl:]
	switch p[9] {
	case 6:
		if len(payload) < 20 || int(payload[12]>>4)*4 < 20 || int(payload[12]>>4)*4 > len(payload) {
			return errors.New("invalid TCP header length")
		}
		if directICMPL4Checksum(p, ihl, 6) != 0 {
			return errors.New("invalid TCP checksum")
		}
	case 17:
		if len(payload) < 8 || int(binary.BigEndian.Uint16(payload[4:6])) != len(payload) {
			return errors.New("invalid UDP length")
		}
		if binary.BigEndian.Uint16(payload[6:8]) != 0 && directICMPL4Checksum(p, ihl, 17) != 0 {
			return errors.New("invalid UDP checksum")
		}
	case 1:
		if len(payload) < 8 || greChecksum(payload) != 0 {
			return errors.New("invalid ICMP checksum/length")
		}
	}
	return nil
}

func directICMPL4Checksum(p []byte, ihl int, protocol byte) uint16 {
	buf := make([]byte, 12+len(p)-ihl)
	copy(buf[:8], p[12:20])
	buf[9] = protocol
	binary.BigEndian.PutUint16(buf[10:12], uint16(len(p)-ihl))
	copy(buf[12:], p[ihl:])
	return greChecksum(buf)
}

// Clamp only a valid, unfragmented TCP SYN. Changing an existing MSS does not
// change packet length; recomputing the complete checksum handles IP options.
func clampDirectICMPMSS(p []byte, mtu int) error {
	ihl := int(p[0]&15) * 4
	if p[9] != 6 || binary.BigEndian.Uint16(p[6:8])&0x3fff != 0 {
		return nil
	}
	tcp := p[ihl:]
	if tcp[13]&2 == 0 {
		return nil
	}
	head := int(tcp[12]>>4) * 4
	changed := false
	for off := 20; off < head; {
		kind := tcp[off]
		if kind == 0 {
			break
		}
		if kind == 1 {
			off++
			continue
		}
		if off+2 > head || tcp[off+1] < 2 || off+int(tcp[off+1]) > head {
			return errors.New("malformed TCP options")
		}
		n := int(tcp[off+1])
		if kind == 2 {
			if n != 4 {
				return errors.New("malformed TCP MSS option")
			}
			max := uint16(mtu - ihl - 20)
			if binary.BigEndian.Uint16(tcp[off+2:off+4]) > max {
				binary.BigEndian.PutUint16(tcp[off+2:off+4], max)
				changed = true
			}
		}
		off += n
	}
	if changed {
		tcp[16], tcp[17] = 0, 0
		binary.BigEndian.PutUint16(tcp[16:18], directICMPL4Checksum(p, ihl, 6))
	}
	return nil
}

// Standalone invocation intentionally refuses explicit flags from other modes.
func runDirectICMPCommand(config, check string, visited []string) (bool, error) {
	if config == "" && check == "" {
		return false, nil
	}
	if config != "" && check != "" {
		return true, errors.New("[direct-icmp/cli] select run or offline check, not both")
	}
	for _, f := range visited {
		if f != "direct-icmp-config" && f != "check-direct-icmp-config" {
			return true, fmt.Errorf("[direct-icmp/cli] incompatible explicit flag -%s", f)
		}
	}
	if flag.NArg() != 0 {
		return true, errors.New("[direct-icmp/cli] unexpected positional arguments")
	}
	path := config
	if check != "" {
		path = check
	}
	c, err := loadDirectICMPConfig(path)
	if err != nil {
		return true, err
	}
	if check != "" {
		fmt.Println("[direct-icmp/config] PASS: private configuration/key and IPv4 policy validated offline; no network or route changes")
		return true, nil
	}
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()
	return true, runDirectICMP(ctx, c)
}
