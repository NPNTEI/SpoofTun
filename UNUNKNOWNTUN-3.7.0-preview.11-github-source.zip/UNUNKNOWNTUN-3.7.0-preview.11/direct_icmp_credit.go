package main

import "time"

// A 32-bit rolling Echo identifier/sequence pair is used instead of reusing a
// fixed identifier every 65536 packets. Credits expire using authenticated RTT
// samples, not the longer session-death timer, so loss cannot fill the window.
type directICMPEchoCredits struct {
	serial         uint32
	pending        map[uint32]time.Time
	deadAfter, rtt time.Duration
}

func newDirectICMPEchoCredits(seed uint32, deadAfter time.Duration) *directICMPEchoCredits {
	return &directICMPEchoCredits{serial: seed, pending: make(map[uint32]time.Time), deadAfter: deadAfter}
}

func (c *directICMPEchoCredits) deadline() time.Duration {
	if c.rtt == 0 {
		return c.deadAfter
	}
	d := 4 * c.rtt
	if d < 500*time.Millisecond {
		d = 500 * time.Millisecond
	}
	if d > c.deadAfter {
		d = c.deadAfter
	}
	return d
}

func echoCreditKey(id, seq uint16) uint32 { return uint32(id)<<16 | uint32(seq) }

func (c *directICMPEchoCredits) prune(now time.Time) {
	deadline := c.deadline()
	for key, sent := range c.pending {
		if now.Sub(sent) >= deadline {
			delete(c.pending, key)
		}
	}
}

func (c *directICMPEchoCredits) reserve(now time.Time) (id, seq uint16, ok bool) {
	c.prune(now)
	if len(c.pending) >= 128 {
		return 0, 0, false
	}
	for {
		c.serial++
		if _, exists := c.pending[c.serial]; !exists {
			break
		}
	}
	c.pending[c.serial] = now
	return uint16(c.serial >> 16), uint16(c.serial), true
}

func (c *directICMPEchoCredits) matches(id, seq uint16, now time.Time) bool {
	when, ok := c.pending[echoCreditKey(id, seq)]
	return ok && now.Sub(when) >= 0 && now.Sub(when) < c.deadline()
}

func (c *directICMPEchoCredits) cancel(id, seq uint16) { delete(c.pending, echoCreditKey(id, seq)) }

// Call only after Noise/AEAD authentication and replay validation succeed.
func (c *directICMPEchoCredits) acknowledge(id, seq uint16, now time.Time) time.Duration {
	key := echoCreditKey(id, seq)
	when, ok := c.pending[key]
	if !ok {
		return 0
	}
	delete(c.pending, key)
	sample := now.Sub(when)
	if sample <= 0 || sample > c.deadAfter {
		return 0
	}
	if c.rtt == 0 || sample > c.rtt {
		c.rtt = sample
	} else {
		c.rtt = (7*c.rtt + sample) / 8
	}
	return sample
}

// A sustained latency jump must get a fresh, full-deadline handshake window.
func (c *directICMPEchoCredits) resetEstimate() {
	c.rtt = 0
	clear(c.pending)
}
