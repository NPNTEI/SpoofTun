package main

import (
	"testing"
	"time"
)

func TestDirectICMPEchoCreditAuthenticatedRTTAndLoss(t *testing.T) {
	now := time.Unix(100, 0)
	c := newDirectICMPEchoCredits(10, 15*time.Second)
	id, seq, ok := c.reserve(now)
	if !ok {
		t.Fatal("nocredit")
	}
	if c.deadline() != 15*time.Second {
		t.Fatal("initialhandshake deadline shortened")
	}
	// Merely seeing a matching Echo (including automatic reflection) does not
	// consume it or establish an RTT sample. Runtime acknowledges only after AEAD.
	if !c.matches(id, seq, now.Add(20*time.Millisecond)) || c.rtt != 0 || len(c.pending) != 1 {
		t.Fatal("unverifiedreply alteredcredit")
	}
	c.acknowledge(id, seq, now.Add(20*time.Millisecond))
	if c.matches(id, seq, now.Add(21*time.Millisecond)) || c.deadline() != 500*time.Millisecond {
		t.Fatal("authreply didnotconsume/update")
	}
	for i := 0; i < 128; i++ {
		if _, _, ok := c.reserve(now.Add(30 * time.Millisecond)); !ok {
			t.Fatal("boundedwindow shrank")
		}
	}
	if _, _, ok := c.reserve(now.Add(40 * time.Millisecond)); ok {
		t.Fatal("windowbound bypass")
	}
	if _, _, ok := c.reserve(now.Add(531 * time.Millisecond)); !ok {
		t.Fatal("losscredits stuck forsessiontimeout")
	}
}

func TestDirectICMPEchoCreditHighLatencyAndReset(t *testing.T) {
	now := time.Unix(100, 0)
	c := newDirectICMPEchoCredits(1, 15*time.Second)
	id, seq, _ := c.reserve(now)
	c.acknowledge(id, seq, now.Add(2*time.Second))
	if c.deadline() != 8*time.Second {
		t.Fatal("highlatency notallowed")
	}
	id, seq, _ = c.reserve(now.Add(3 * time.Second))
	c.acknowledge(id, seq, now.Add(7*time.Second))
	if c.deadline() != 15*time.Second {
		t.Fatal("deadline mustcap atsessiontimeout")
	}
	_, _, _ = c.reserve(now.Add(8 * time.Second))
	c.resetEstimate()
	if len(c.pending) != 0 || c.rtt != 0 || c.deadline() != 15*time.Second {
		t.Fatal("deadlink cannotgetfreshhandshake")
	}
}

func TestDirectICMPEchoCreditSequenceWrapAndCancel(t *testing.T) {
	now := time.Unix(100, 0)
	c := newDirectICMPEchoCredits(0x12ffff, 15*time.Second)
	id, seq, ok := c.reserve(now)
	if !ok || id != 0x13 || seq != 0 {
		t.Fatal("identifier didnotadvance atsequencewrap")
	}
	if c.matches(0x12, seq, now.Add(time.Millisecond)) {
		t.Fatal("oldidentifier matchednewcredit")
	}
	c.cancel(id, seq)
	if c.matches(id, seq, now.Add(time.Millisecond)) {
		t.Fatal("failedsendcredit remained")
	}
	c.serial = ^uint32(0)
	id, seq, _ = c.reserve(now)
	if id != 0 || seq != 0 {
		t.Fatal("32bitwrap incorrect")
	}
	if c.matches(id, seq, now.Add(16*time.Second)) {
		t.Fatal("expiredreply accepted")
	}
}
