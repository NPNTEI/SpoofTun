package main

// Direct ICMP is a UNUNKNOWNTUN-only datagram protocol. Noise NNpsk0 authenticates
// ephemeral X25519 sessions using a private random 32-byte PSK. Every subsequent
// packet is ChaCha20-Poly1305 protected; no TLS or WebSocket layer is involved.
//
// The engine has a single owner (the runtime event loop). It does not route IP,
// mutate the host, or implement reliable delivery: inner TCP supplies its own
// reliability, while UDP/IP retain their ordinary datagram semantics.
import (
	"bytes"
	"crypto/ecdh"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"time"

	"github.com/flynn/noise"
)

const (
	directICMPHeaderSize  = 32
	directICMPControlSize = 4
	directICMPTagSize     = 16
	// Includes outer IPv4, ICMP Echo header, wire header, encrypted control and tag.
	directICMPNetworkOverhead      = 20 + 8 + directICMPHeaderSize + directICMPControlSize + directICMPTagSize
	directICMPQueueLimit           = 256
	directICMPBurst                = 16
	directICMPReplayBits           = 1024
	directICMPHello           byte = 1
	directICMPHelloReply      byte = 2
	directICMPPacket          byte = 3
	directICMPData            byte = 0
	directICMPConfirm         byte = 1
	directICMPAck             byte = 2
	directICMPMaxNonce             = uint64(1) << 48
)

var errDirectICMPInvalid = errors.New("invalid or unauthenticated Direct ICMP packet")
var errDirectICMPReplay = errors.New("replayed Direct ICMP packet")

type directICMPEngineConfig struct {
	Initiator                 bool
	Key                       [32]byte
	MTU                       int
	PollInterval              time.Duration
	DeadAfter                 time.Duration
	RekeyAfter                time.Duration
	FECMode                   string
	FECPercent, FECMaxPercent int
	FECBlock                  time.Duration
}

type DirectICMPEngineStats struct {
	Handshakes         uint64 `json:"handshakes"`
	Reconnects         uint64 `json:"reconnects"`
	Rekeys             uint64 `json:"rekeys"`
	Sent               uint64 `json:"sent"`
	Received           uint64 `json:"received"`
	Dropped            uint64 `json:"dropped"`
	AuthFailures       uint64 `json:"auth_failures"`
	Replays            uint64 `json:"replays"`
	Queued             int    `json:"queued"`
	Connected          bool   `json:"connected"`
	FECMode            string `json:"fec_mode"`
	FECPercent         int    `json:"fec_percent"`
	FECRawSamples      uint64 `json:"fec_raw_samples"`
	FECRawLost         uint64 `json:"fec_raw_lost"`
	FECResidualLost    uint64 `json:"fec_residual_lost"`
	FECRecovered       uint64 `json:"fec_recovered"`
	FECRepairPackets   uint64 `json:"fec_repair_packets"`
	FECSourcePackets   uint64 `json:"fec_source_packets"`
	FECFeedbackReports uint64 `json:"fec_feedback_reports"`
	FECFeedbackExpired uint64 `json:"fec_feedback_expired"`
	LocalSendFailures  uint64 `json:"local_send_failures"`
	WireSuccessful     uint64 `json:"wire_successful"`
	RateBurst          int    `json:"rate_burst"`
}

type directICMPReplayWindow struct {
	high        uint64
	bits        [directICMPReplayBits / 64]uint64
	initialized bool
}

func (w *directICMPReplayWindow) seen(n uint64) bool {
	if !w.initialized || n > w.high {
		return false
	}
	d := w.high - n
	return d >= directICMPReplayBits || w.bits[d/64]&(uint64(1)<<(d%64)) != 0
}
func (w *directICMPReplayWindow) mark(n uint64) {
	if !w.initialized {
		w.initialized = true
		w.high = n
		w.bits[0] = 1
		return
	}
	if n > w.high {
		d := n - w.high
		var shifted [directICMPReplayBits / 64]uint64
		if d < directICMPReplayBits {
			words, rem := int(d/64), uint(d%64)
			for i := len(shifted) - 1; i >= words; i-- {
				shifted[i] = w.bits[i-words] << rem
				if rem != 0 && i > words {
					shifted[i] |= w.bits[i-words-1] >> (64 - rem)
				}
			}
		}
		w.bits = shifted
		w.high = n
	}
	d := w.high - n
	if d < directICMPReplayBits {
		w.bits[d/64] |= uint64(1) << (d % 64)
	}
}

type directICMPSession struct {
	id                   [16]byte
	tx, rx               noise.Cipher
	nonce                uint64
	replay               directICMPReplayWindow
	created, lastReceive time.Time
	confirmed            bool
	remoteMore           bool
	remoteControlSeen    bool
	remoteControlNonce   uint64
	followupCredits      int
	fec                  *directICMPFECSession
}

type directICMPPending struct {
	id                [16]byte
	handshake         *noise.HandshakeState
	hello, reply      []byte
	session           *directICMPSession
	created, lastSent time.Time
}

type directICMPEngine struct {
	config                                        directICMPEngineConfig
	random                                        io.Reader
	active, previous                              *directICMPSession
	pending                                       *directICMPPending
	queue                                         [][]byte
	lastTick, lastPoll, lastNow, lastHelloAttempt time.Time
	stats                                         DirectICMPEngineStats
	everConnected                                 bool
	previousUntil                                 time.Time
	retired                                       [64][16]byte
	retiredCount, retiredNext                     int
}

func newDirectICMPEngine(c directICMPEngineConfig, now time.Time) (*directICMPEngine, error) {
	return newDirectICMPEngineRandom(c, now, rand.Reader)
}
func newDirectICMPEngineRandom(c directICMPEngineConfig, now time.Time, random io.Reader) (*directICMPEngine, error) {
	if c.Key == ([32]byte{}) {
		return nil, errors.New("Direct ICMP requires a nonzero random 32-byte PSK")
	}
	if c.MTU < 576 || c.MTU > 9000 {
		return nil, errors.New("Direct ICMP MTU must be 576..9000")
	}
	if c.PollInterval < time.Millisecond || c.PollInterval > time.Second {
		return nil, errors.New("Direct ICMP polling interval must be 1ms..1s")
	}
	if c.DeadAfter < time.Second || c.DeadAfter > 10*time.Minute {
		return nil, errors.New("Direct ICMP timeout must be 1s..10m")
	}
	if c.RekeyAfter < c.DeadAfter*2 || c.RekeyAfter > 24*time.Hour {
		return nil, errors.New("Direct ICMP rekey interval must be at least twice timeout and at most 24h")
	}
	if random == nil {
		return nil, errors.New("missing cryptographic random source")
	}
	if c.FECMode == "" {
		c.FECMode = "off"
	}
	if c.FECMode != "off" && c.FECMode != "fixed" && c.FECMode != "adaptive" {
		return nil, errors.New("invalid Direct ICMP FEC mode")
	}
	if c.FECMaxPercent == 0 {
		c.FECMaxPercent = 25
	}
	if c.FECBlock == 0 {
		c.FECBlock = 20 * time.Millisecond
	}
	if c.FECPercent < 0 || c.FECPercent > c.FECMaxPercent || c.FECMaxPercent < 5 || c.FECMaxPercent > 50 || c.FECBlock < 5*time.Millisecond || c.FECBlock > 100*time.Millisecond {
		return nil, errors.New("invalid Direct ICMP FEC bounds")
	}
	e := &directICMPEngine{config: c, random: random, lastNow: now}
	if c.Initiator {
		if err := e.begin(now); err != nil {
			return nil, err
		}
	}
	return e, nil
}
func (e *directICMPEngine) direction() byte {
	if e.config.Initiator {
		return 1
	}
	return 2
}
func directICMPHeader(kind, direction byte, id [16]byte, nonce uint64) []byte {
	b := make([]byte, directICMPHeaderSize)
	copy(b, "GDL1")
	b[4] = kind
	b[5] = direction
	copy(b[8:24], id[:])
	binary.BigEndian.PutUint64(b[24:], nonce)
	return b
}
func (e *directICMPEngine) handshake(id [16]byte) (*noise.HandshakeState, error) {
	prologue := append([]byte("UNUNKNOWNTUN-Direct-ICMP-"+e.protocolVersion()+"/"), id[:]...)
	var mtu [2]byte
	binary.BigEndian.PutUint16(mtu[:], uint16(e.config.MTU))
	prologue = append(prologue, mtu[:]...)
	return noise.NewHandshakeState(noise.Config{CipherSuite: noise.NewCipherSuite(noise.DH25519, noise.CipherChaChaPoly, noise.HashBLAKE2s), Random: e.random, Pattern: noise.HandshakeNN, Initiator: e.config.Initiator, Prologue: prologue, PresharedKey: e.config.Key[:], PresharedKeyPlacement: 0})
}
func (e *directICMPEngine) begin(now time.Time) error {
	p := &directICMPPending{created: now}
	if _, err := io.ReadFull(e.random, p.id[:]); err != nil {
		return fmt.Errorf("Direct ICMP random session: %w", err)
	}
	hs, err := e.handshake(p.id)
	if err != nil {
		return err
	}
	p.handshake = hs
	// A fixed 16-byte protocol payload makes request/reply lengths equal. The
	// random session and configuration MTU are also bound into the Noise transcript.
	body, _, _, err := hs.WriteMessage(nil, e.handshakePayload())
	if err != nil {
		return err
	}
	p.hello = append(e.header(directICMPHello, 1, p.id, 0), body...)
	e.pending = p
	return nil
}
func (e *directICMPEngine) makeSession(id [16]byte, first, second *noise.CipherState, now time.Time) (*directICMPSession, error) {
	// Split always returns initiator->responder first, responder->initiator second.
	tx, rx := first.Cipher(), second.Cipher()
	if !e.config.Initiator {
		tx, rx = rx, tx
	}
	s := &directICMPSession{id: id, tx: tx, rx: rx, created: now, lastReceive: now}
	if e.fecEnabled() {
		var err error
		s.fec, err = newDirectICMPFECSession(e.config, now)
		if err != nil {
			return nil, err
		}
	}
	return s, nil
}
func (e *directICMPEngine) Connected(now time.Time) bool {
	return e.active != nil && e.active.confirmed && now.Sub(e.active.lastReceive) < e.config.DeadAfter
}
func (e *directICMPEngine) Stats() DirectICMPEngineStats {
	s := e.stats
	s.Queued = len(e.queue)
	s.Connected = e.Connected(e.lastNow)
	s.FECMode = e.config.FECMode
	s.RateBurst = directICMPBurst
	if e.active != nil && e.active.fec != nil {
		s.FECPercent = e.active.fec.percent
		s.RateBurst = e.active.fec.burst
	}
	return s
}
func (e *directICMPEngine) Queue(inner []byte) error {
	if len(inner) == 0 || len(inner) > e.config.MTU {
		return errors.New("Direct ICMP inner packet outside configured MTU")
	}
	if len(e.queue) >= directICMPQueueLimit {
		e.stats.Dropped++
		return errors.New("Direct ICMP bounded packet queue is full")
	}
	e.queue = append(e.queue, append([]byte(nil), inner...))
	return nil
}
func (e *directICMPEngine) pop() []byte {
	if len(e.queue) == 0 {
		return nil
	}
	p := e.queue[0]
	e.queue[0] = nil
	e.queue = e.queue[1:]
	return p
}
func (e *directICMPEngine) dropQueue() { e.stats.Dropped += uint64(len(e.queue)); e.queue = nil }
func (e *directICMPEngine) expire(now time.Time) {
	e.lastNow = now
	if e.previous != nil && !now.Before(e.previousUntil) {
		e.previous = nil
	}
	if e.active != nil && now.Sub(e.active.lastReceive) >= e.config.DeadAfter {
		e.retire(e.active.id)
		e.active = nil
		e.previous = nil
		e.dropQueue()
	}
	if e.pending != nil && now.Sub(e.pending.created) >= e.config.DeadAfter {
		e.retire(e.pending.id)
		e.pending = nil
		if e.active == nil {
			e.dropQueue()
		}
	}
}

// A fixed-size retired-session ring prevents captured, previously accepted
// hellos from repeatedly occupying the single candidate slot. It is bounded;
// admission never allocates memory based on attacker-controlled identities.
func (e *directICMPEngine) retire(id [16]byte) {
	if e.isRetired(id) {
		return
	}
	e.retired[e.retiredNext] = id
	e.retiredNext = (e.retiredNext + 1) % len(e.retired)
	if e.retiredCount < len(e.retired) {
		e.retiredCount++
	}
}
func (e *directICMPEngine) isRetired(id [16]byte) bool {
	for i := 0; i < e.retiredCount; i++ {
		if e.retired[i] == id {
			return true
		}
	}
	return false
}
func (e *directICMPEngine) activate(s *directICMPSession, now time.Time) {
	if e.active == s {
		return
	}
	if e.active != nil {
		e.previous = e.active
		e.previousUntil = now.Add(e.config.DeadAfter)
		e.retire(e.active.id)
		e.stats.Rekeys++
	} else if e.everConnected {
		e.stats.Reconnects++
	}
	s.confirmed = true
	s.lastReceive = now
	e.lastPoll = now
	e.active = s
	e.stats.Handshakes++
	e.everConnected = true
	e.pending = nil
}
func (e *directICMPEngine) seal(s *directICMPSession, op byte, inner []byte) ([]byte, error) {
	if s.nonce >= directICMPMaxNonce {
		return nil, errors.New("Direct ICMP session nonce exhausted")
	}
	if len(inner) > e.config.MTU {
		return nil, errors.New("Direct ICMP packet exceeds MTU")
	}
	if s.fec != nil {
		return e.sealFEC(s, op, inner)
	}
	header := directICMPHeader(directICMPPacket, e.direction(), s.id, s.nonce)
	plain := make([]byte, e.config.MTU+directICMPControlSize)
	plain[0] = op
	if len(e.queue) > 0 {
		plain[1] = 1
	}
	binary.BigEndian.PutUint16(plain[2:4], uint16(len(inner)))
	copy(plain[4:], inner)
	out := s.tx.Encrypt(header, s.nonce, header, plain)
	s.nonce++ // Exactly once per AEAD operation, including failed network sends.
	e.stats.Sent++
	return out, nil
}
func (e *directICMPEngine) Tick(now time.Time) [][]byte {
	e.expire(now)
	if !e.config.Initiator {
		return nil
	} // An egress never sends unsolicited Echo replies.
	if !e.lastTick.IsZero() && now.Sub(e.lastTick) < e.config.PollInterval {
		return nil
	}
	e.lastTick = now
	out := make([][]byte, 0, directICMPBurst)
	if e.pending == nil && (e.active == nil || now.Sub(e.active.created) >= e.config.RekeyAfter || e.active.nonce >= directICMPMaxNonce-1024) {
		if err := e.begin(now); err != nil {
			e.stats.Dropped++
			return nil
		}
	}
	if p := e.pending; p != nil && (p.lastSent.IsZero() || now.Sub(p.lastSent) >= 250*time.Millisecond) {
		if p.session == nil {
			out = append(out, append([]byte(nil), p.hello...))
		} else if packet, err := e.seal(p.session, directICMPConfirm, nil); err == nil {
			out = append(out, packet)
		}
		p.lastSent = now
	}
	if e.active == nil {
		return out
	}
	// Poll only for known demand. Sending a packet or receiving a real payload
	// earns at most two one-shot follow-up credits; it does not create a timed
	// high-rate burst. Authenticated remoteMore drives bulk downlink polling.
	s := e.active
	if s.fec != nil {
		e.updateFEC(s, now)
	}
	demand := len(e.queue)
	if s.fec != nil {
		demand += len(s.fec.repairs)
	}
	if s.remoteMore {
		demand = directICMPBurst
	}
	if demand == 0 && s.followupCredits > 0 {
		demand = s.followupCredits
	}
	if demand == 0 && now.Sub(e.lastPoll) >= 250*time.Millisecond {
		demand = 1
	}
	limit := directICMPBurst
	if s.fec != nil {
		limit = s.fec.burst
		if s.fec.remoteBurst < limit {
			limit = s.fec.remoteBurst
		}
	}
	if demand > limit-len(out) {
		demand = limit - len(out)
	}
	for i := 0; i < demand; i++ {
		if s.fec != nil && len(s.fec.repairs) > 0 && s.fec.sendCredit < 100 && len(s.fec.pending) > 0 {
			break
		}
		var inner []byte
		if s.fec == nil || len(s.fec.repairs) == 0 {
			inner = e.pop()
		}
		if len(inner) > 0 {
			s.followupCredits = 2
		} else if s.followupCredits > 0 {
			s.followupCredits--
		}
		packet, err := e.seal(s, directICMPData, inner)
		if err != nil {
			e.stats.Dropped++
			break
		}
		out = append(out, packet)
		e.lastPoll = now
	}
	return out
}
func (e *directICMPEngine) reject(err error) ([][]byte, [][]byte, error) {
	if errors.Is(err, errDirectICMPReplay) {
		e.stats.Replays++
	} else {
		e.stats.AuthFailures++
	}
	return nil, nil, err
}
func (e *directICMPEngine) Receive(wire []byte, now time.Time) ([][]byte, [][]byte, error) {
	e.expire(now)
	if len(wire) < directICMPHeaderSize || len(wire) > e.MaxWireSize() || !bytes.Equal(wire[:4], []byte(e.wireMagic())) || wire[5] == e.direction() || wire[5] < 1 || wire[5] > 2 || wire[6] != 0 || wire[7] != 0 {
		return e.reject(errDirectICMPInvalid)
	}
	var id [16]byte
	copy(id[:], wire[8:24])
	nonce := binary.BigEndian.Uint64(wire[24:32])
	switch wire[4] {
	case directICMPHello:
		if e.config.Initiator || nonce != 0 || len(wire) != 96 {
			return e.reject(errDirectICMPInvalid)
		}
		if e.isRetired(id) {
			return e.reject(errDirectICMPReplay)
		}
		if e.active != nil && e.active.id == id {
			return e.reject(errDirectICMPReplay)
		}
		if e.previous != nil && e.previous.id == id {
			return e.reject(errDirectICMPReplay)
		}
		if p := e.pending; p != nil {
			if p.id == id && bytes.Equal(p.hello, wire) {
				return [][]byte{append([]byte(nil), p.reply...)}, nil, nil
			}
			// A replayed old hello cannot evict the authenticated candidate being
			// confirmed, nor the active session. Candidate state expires on its deadline.
			return e.reject(errDirectICMPInvalid)
		}
		if !e.lastHelloAttempt.IsZero() && now.Sub(e.lastHelloAttempt) < 100*time.Millisecond {
			return e.reject(errDirectICMPInvalid)
		}
		e.lastHelloAttempt = now
		hs, err := e.handshake(id)
		if err != nil {
			return e.reject(err)
		}
		plain, _, _, err := hs.ReadMessage(nil, wire[32:])
		if err != nil || !bytes.Equal(plain, e.handshakePayload()) {
			return e.reject(errDirectICMPInvalid)
		}
		body, cs1, cs2, err := hs.WriteMessage(nil, e.handshakePayload())
		if err != nil {
			return e.reject(err)
		}
		session, err := e.makeSession(id, cs1, cs2, now)
		if err != nil {
			return e.reject(err)
		}
		p := &directICMPPending{id: id, created: now, hello: append([]byte(nil), wire...), session: session}
		p.reply = append(e.header(directICMPHelloReply, 2, id, 0), body...)
		e.pending = p
		return [][]byte{append([]byte(nil), p.reply...)}, nil, nil
	case directICMPHelloReply:
		p := e.pending
		if !e.config.Initiator || p == nil || p.id != id || nonce != 0 || len(wire) != 96 {
			return e.reject(errDirectICMPInvalid)
		}
		if p.session != nil {
			if !bytes.Equal(p.reply, wire) {
				return e.reject(errDirectICMPInvalid)
			}
		} else {
			// Reject low-order ephemeral public keys before calling Noise. Flynn
			// rolls back AEAD failures but not every earlier DH error; preflight
			// ensures an invalid DH input cannot poison this pending transcript.
			private, err := ecdh.X25519().NewPrivateKey(p.handshake.LocalEphemeral().Private)
			if err != nil {
				return e.reject(errDirectICMPInvalid)
			}
			public, err := ecdh.X25519().NewPublicKey(wire[32:64])
			if err != nil {
				return e.reject(errDirectICMPInvalid)
			}
			if _, err = private.ECDH(public); err != nil {
				return e.reject(errDirectICMPInvalid)
			}
			// The library's failed ReadMessage state is rolled back, so tampering does
			// not prevent a subsequent authentic retransmission from completing.
			plain, cs1, cs2, err := p.handshake.ReadMessage(nil, wire[32:])
			if err != nil || !bytes.Equal(plain, e.handshakePayload()) {
				return e.reject(errDirectICMPInvalid)
			}
			p.session, err = e.makeSession(id, cs1, cs2, now)
			if err != nil {
				return e.reject(err)
			}
			p.reply = append([]byte(nil), wire...)
			p.handshake = nil
		}
		packet, err := e.seal(p.session, directICMPConfirm, nil)
		if err != nil {
			return e.reject(err)
		}
		p.lastSent = now
		return [][]byte{packet}, nil, nil
	case directICMPPacket:
		if len(wire) != e.MaxWireSize() || nonce >= directICMPMaxNonce {
			return e.reject(errDirectICMPInvalid)
		}
		var s *directICMPSession
		for _, candidate := range []*directICMPSession{e.active, e.previous} {
			if candidate != nil && candidate.id == id {
				s = candidate
				break
			}
		}
		if s == nil && e.pending != nil && e.pending.session != nil && e.pending.id == id {
			s = e.pending.session
		}
		if s == nil {
			return e.reject(errDirectICMPInvalid)
		}
		if s.replay.seen(nonce) {
			return e.reject(errDirectICMPReplay)
		}
		plain, err := s.rx.Decrypt(nil, nonce, wire[:32], wire[32:])
		if err != nil {
			return e.reject(errDirectICMPInvalid)
		}
		if s.fec != nil {
			return e.receiveFEC(s, nonce, plain, now)
		}
		n := int(binary.BigEndian.Uint16(plain[2:4]))
		op := plain[0]
		if plain[1] > 1 || n > e.config.MTU || (op != directICMPData && op != directICMPConfirm && op != directICMPAck) || ((op == directICMPConfirm || op == directICMPAck) && n != 0) {
			return e.reject(errDirectICMPInvalid)
		}
		for _, b := range plain[4+n:] {
			if b != 0 {
				return e.reject(errDirectICMPInvalid)
			}
		}
		if (e.config.Initiator && op == directICMPConfirm) || (!e.config.Initiator && op == directICMPAck) {
			return e.reject(errDirectICMPInvalid)
		}
		if !s.confirmed && ((e.config.Initiator && op != directICMPAck) || (!e.config.Initiator && op != directICMPConfirm)) {
			return e.reject(errDirectICMPInvalid)
		}
		// Only authenticated, semantically valid packets consume replay state.
		s.replay.mark(nonce)
		s.lastReceive = now
		e.stats.Received++
		if !s.confirmed {
			e.activate(s, now)
		}
		// Reordered older responses must not turn a cleared more flag back on.
		if !s.remoteControlSeen || nonce > s.remoteControlNonce {
			s.remoteControlSeen = true
			s.remoteControlNonce = nonce
			s.remoteMore = plain[1] != 0
		}
		if n > 0 {
			s.followupCredits = 2
		}
		var inner [][]byte
		if n > 0 {
			inner = [][]byte{append([]byte(nil), plain[4:4+n]...)}
		}
		if e.config.Initiator {
			return nil, inner, nil
		}
		responseOp := directICMPData
		var responseData []byte
		if op == directICMPConfirm {
			responseOp = directICMPAck
		} else {
			responseData = e.pop()
		}
		response, err := e.seal(s, responseOp, responseData)
		if err != nil {
			return nil, inner, err
		}
		return [][]byte{response}, inner, nil
	default:
		return e.reject(errDirectICMPInvalid)
	}
}
