package main

import (
	"bytes"
	"encoding/binary"
	"errors"
	"io"
	"testing"
	"time"
)

func directEnginePair(t *testing.T) (*directICMPEngine, *directICMPEngine, time.Time) {
	t.Helper()
	now := time.Unix(1700000000, 0)
	c := directICMPEngineConfig{Initiator: true, MTU: 1200, PollInterval: 20 * time.Millisecond, DeadAfter: 3 * time.Second, RekeyAfter: 10 * time.Second}
	for i := range c.Key {
		c.Key[i] = byte(i + 1)
	}
	a, err := newDirectICMPEngine(c, now)
	if err != nil {
		t.Fatal(err)
	}
	c.Initiator = false
	b, err := newDirectICMPEngine(c, now)
	if err != nil {
		t.Fatal(err)
	}
	return a, b, now
}
func directDeliver(t *testing.T, a, b *directICMPEngine, packets [][]byte, now time.Time) (toA, toB [][]byte) {
	t.Helper()
	for round := 0; len(packets) > 0; round++ {
		if round > 8 {
			t.Fatal("unbounded protocol response loop")
		}
		var replies [][]byte
		for _, p := range packets {
			out, inner, err := b.Receive(p, now)
			if err != nil {
				t.Fatal(err)
			}
			if len(out) > 1 {
				t.Fatal("response amplification")
			}
			toB = append(toB, inner...)
			replies = append(replies, out...)
		}
		packets = nil
		for _, p := range replies {
			out, inner, err := a.Receive(p, now)
			if err != nil {
				t.Fatal(err)
			}
			toA = append(toA, inner...)
			packets = append(packets, out...)
		}
	}
	return
}
func directConnected(t *testing.T) (*directICMPEngine, *directICMPEngine, time.Time) {
	t.Helper()
	a, b, now := directEnginePair(t)
	directDeliver(t, a, b, a.Tick(now), now)
	if !a.Connected(now) || !b.Connected(now) {
		t.Fatal("pair not connected")
	}
	return a, b, now
}
func directGet(t *testing.T, e *directICMPEngine, p []byte, now time.Time) []byte {
	t.Helper()
	out, _, err := e.Receive(p, now)
	if err != nil {
		t.Fatal(err)
	}
	if len(out) != 1 {
		t.Fatalf("wanted1response got%d", len(out))
	}
	return out[0]
}
func TestDirectICMPEngineHandshakeAndEncryptedBidirectionalData(t *testing.T) {
	a, b, now := directConnected(t)
	up := bytes.Repeat([]byte("private uplink!"), 30)
	down := bytes.Repeat([]byte("private downlink!"), 30)
	if err := a.Queue(up); err != nil {
		t.Fatal(err)
	}
	if err := b.Queue(down); err != nil {
		t.Fatal(err)
	}
	now = now.Add(20 * time.Millisecond)
	packets := a.Tick(now)
	if len(packets) != 1 {
		t.Fatalf("activeburst=%d", len(packets))
	}
	for _, p := range packets {
		if bytes.Contains(p, up) || bytes.Contains(p, down) {
			t.Fatal("plaintext exposed")
		}
	}
	gotA, gotB := directDeliver(t, a, b, packets, now)
	if len(gotA) != 1 || len(gotB) != 1 || !bytes.Equal(gotA[0], down) || !bytes.Equal(gotB[0], up) {
		t.Fatal("data didnotcross")
	}
	if a.stats.Handshakes != 1 || b.stats.Handshakes != 1 {
		t.Fatal("handshakecounter")
	}
}
func TestDirectICMPEngineWrongKeyAndConfigurationRejected(t *testing.T) {
	a, b, now := directEnginePair(t)
	b.config.Key[0] ^= 1
	out, inner, err := b.Receive(a.Tick(now)[0], now)
	if err == nil || len(out) != 0 || len(inner) != 0 || b.pending != nil {
		t.Fatal("wrongPSKaccepted")
	}
	a, b, now = directEnginePair(t)
	b.config.MTU = 1300
	if out, _, err = b.Receive(a.Tick(now)[0], now); err == nil || len(out) != 0 {
		t.Fatal("MTUmismatchaccepted")
	}
}
func TestDirectICMPEngineHandshakeLossRetransmission(t *testing.T) {
	for _, lost := range []string{"hello", "reply", "confirm", "ack"} {
		t.Run(lost, func(t *testing.T) {
			a, b, now := directEnginePair(t)
			hello := a.Tick(now)[0]
			var next []byte
			if lost == "hello" {
				now = now.Add(300 * time.Millisecond)
				hello = a.Tick(now)[0]
			}
			reply := directGet(t, b, hello, now)
			if lost == "reply" {
				now = now.Add(300 * time.Millisecond)
				reply = directGet(t, b, a.Tick(now)[0], now)
			}
			confirm := directGet(t, a, reply, now)
			if lost == "confirm" {
				now = now.Add(300 * time.Millisecond)
				confirm = a.Tick(now)[0]
			}
			ack := directGet(t, b, confirm, now)
			if lost == "ack" {
				now = now.Add(300 * time.Millisecond)
				next = a.Tick(now)[0]
				ack = directGet(t, b, next, now)
			}
			if _, _, err := a.Receive(ack, now); err != nil {
				t.Fatal(err)
			}
			if !a.Connected(now) || !b.Connected(now) {
				t.Fatal("lossrecoveryfailed")
			}
		})
	}
}
func TestDirectICMPEngineInvalidReplyDoesNotPoisonTranscript(t *testing.T) {
	for _, kind := range []string{"ciphertext", "zero_ephemeral", "low_order_ephemeral", "header"} {
		t.Run(kind, func(t *testing.T) {
			a, b, now := directEnginePair(t)
			reply := directGet(t, b, a.Tick(now)[0], now)
			bad := append([]byte(nil), reply...)
			switch kind {
			case "ciphertext":
				bad[len(bad)-1] ^= 1
			case "zero_ephemeral":
				clear(bad[32:64])
			case "low_order_ephemeral":
				clear(bad[32:64])
				bad[32] = 1
			case "header":
				bad[8] ^= 1
			}
			if _, _, err := a.Receive(bad, now); err == nil {
				t.Fatal("tamperaccepted")
			}
			directDeliver(t, a, b, [][]byte{directGet(t, a, reply, now)}, now)
			if !a.Connected(now) || !b.Connected(now) {
				t.Fatal("authenticretransmissionpoisoned")
			}
		})
	}
}
func TestDirectICMPEngineTamperThenValidDoesNotConsumeReplay(t *testing.T) {
	a, b, now := directConnected(t)
	_ = a.Queue([]byte("payload"))
	now = now.Add(time.Second)
	wire := a.Tick(now)[0]
	for _, at := range []int{8, 24, 31, 32, 100, len(wire) - 1} {
		bad := append([]byte(nil), wire...)
		bad[at] ^= 1
		if _, _, err := b.Receive(bad, now); err == nil {
			t.Fatalf("tamperaccepted%d", at)
		}
	}
	_, inner, err := b.Receive(wire, now)
	if err != nil || len(inner) != 1 {
		t.Fatal("validpacketconsumed", err)
	}
	if _, _, err = b.Receive(wire, now); !errors.Is(err, errDirectICMPReplay) {
		t.Fatal("replayaccepted", err)
	}
}
func TestDirectICMPEngineReorderingAndReplayWindow(t *testing.T) {
	a, b, now := directConnected(t)
	for i := 0; i < 16; i++ {
		_ = a.Queue([]byte{byte(i)})
	}
	now = now.Add(time.Second)
	wire := a.Tick(now)
	for i := len(wire) - 1; i >= 0; i-- {
		_, inner, err := b.Receive(wire[i], now)
		if err != nil || len(inner) != 1 || inner[0][0] != byte(i) {
			t.Fatalf("reorder%d:%v", i, err)
		}
	}
	for _, p := range wire {
		if _, _, err := b.Receive(p, now); !errors.Is(err, errDirectICMPReplay) {
			t.Fatal("replaynotrejected")
		}
	}
	var w directICMPReplayWindow
	for _, n := range []uint64{0, 64, 1024, 1030, 4000} {
		w.mark(n)
		if !w.seen(n) {
			t.Fatal("markmissing")
		}
	}
	if !w.seen(0) || w.seen(3999) {
		t.Fatal("oldorunorderedwindowincorrect")
	}
	w.mark(3999)
	if !w.seen(3999) {
		t.Fatal("unorderedmark")
	}
}
func TestDirectICMPEngineDirectionsAndReflectionRejected(t *testing.T) {
	a, b, now := directConnected(t)
	_ = a.Queue([]byte("x"))
	now = now.Add(time.Second)
	request := a.Tick(now)[0]
	if _, _, err := a.Receive(request, now); err == nil {
		t.Fatal("kernelEchoReflectionaccepted")
	}
	reply := directGet(t, b, request, now)
	if _, _, err := b.Receive(reply, now); err == nil {
		t.Fatal("replyreflectionaccepted")
	}
	altered := append([]byte(nil), reply...)
	altered[5] = 1
	if _, _, err := b.Receive(altered, now); err == nil {
		t.Fatal("directionbitunauthenticated")
	}
}
func TestDirectICMPEngineReconnectAfterBlackholeAndPeerRestart(t *testing.T) {
	for _, restart := range []string{"none", "origin", "egress"} {
		t.Run(restart, func(t *testing.T) {
			a, b, now := directConnected(t)
			old := a.active.id
			now = now.Add(4 * time.Second)
			if restart == "origin" {
				var err error
				a, err = newDirectICMPEngine(a.config, now)
				if err != nil {
					t.Fatal(err)
				}
			}
			if restart == "egress" {
				var err error
				b, err = newDirectICMPEngine(b.config, now)
				if err != nil {
					t.Fatal(err)
				}
			}
			directDeliver(t, a, b, a.Tick(now), now)
			if !a.Connected(now) || !b.Connected(now) || a.active.id == old {
				t.Fatal("reconnectfailed")
			}
		})
	}
}
func TestDirectICMPEngineRekeyKeepsOldUntilConfirmation(t *testing.T) {
	a, b, now := directConnected(t)
	oldA, oldB := a.active, b.active
	// Keep the old session alive while approaching the rekey deadline.
	for i := 0; i < 10; i++ {
		now = now.Add(time.Second)
		packets := a.Tick(now)
		if i < 9 {
			directDeliver(t, a, b, packets, now)
		} else {
			if a.active != oldA || b.active != oldB {
				t.Fatal("oldsessionreplacedbeforehandshake")
			}
			directDeliver(t, a, b, packets, now)
		}
	}
	if a.active == oldA || b.active == oldB || a.stats.Rekeys != 1 || b.stats.Rekeys != 1 {
		t.Fatal("rekeyfailed")
	}
	// A delayed datagram under the old key is allowed only during bounded grace.
	oldPacket, err := a.seal(oldA, directICMPData, []byte("delayed"))
	if err != nil {
		t.Fatal(err)
	}
	_, inner, err := b.Receive(oldPacket, now.Add(time.Second))
	if err != nil || len(inner) != 1 {
		t.Fatal("gracenotaccepted", err)
	}
	// Keep the new session alive, then verify old traffic cannot extend its grace.
	directDeliver(t, a, b, a.Tick(now.Add(2*time.Second)), now.Add(2*time.Second))
	expired, _ := a.seal(oldA, directICMPData, []byte("expired"))
	if _, _, err = b.Receive(expired, now.Add(3*time.Second)); err == nil {
		t.Fatal("oldkeygraceextended")
	}
}
func TestDirectICMPEngineReplayedHelloCannotReplaceLiveOrCandidate(t *testing.T) {
	a, b, now := directEnginePair(t)
	hello := a.Tick(now)[0]
	directDeliver(t, a, b, [][]byte{hello}, now)
	active := b.active
	if _, _, err := b.Receive(hello, now); err == nil || b.active != active {
		t.Fatal("activehelloreplay")
	}
	// Candidate hello expires, is retired, and cannot occupy state again.
	c, err := newDirectICMPEngine(a.config, now.Add(time.Second))
	if err != nil {
		t.Fatal(err)
	}
	candidate := c.Tick(now.Add(time.Second))[0]
	if _, _, err = b.Receive(candidate, now.Add(time.Second)); err != nil {
		t.Fatal(err)
	}
	b.Tick(now.Add(5 * time.Second))
	if _, _, err = b.Receive(candidate, now.Add(5*time.Second)); !errors.Is(err, errDirectICMPReplay) {
		t.Fatal("expiredcandidatehelloaccepted", err)
	}
	if b.pending != nil {
		t.Fatal("retiredhellocapturedstate")
	}
}
func TestDirectICMPEngineQueueBoundsCopyAndIdleBurst(t *testing.T) {
	a, b, now := directConnected(t)
	input := []byte("copy")
	for i := 0; i < directICMPQueueLimit; i++ {
		if err := a.Queue(input); err != nil {
			t.Fatal(err)
		}
	}
	input[0] = 'X'
	if err := a.Queue(input); err == nil {
		t.Fatal("queueunbounded")
	}
	if err := a.Queue(make([]byte, 1201)); err == nil {
		t.Fatal("oversizeaccepted")
	}
	if err := a.Queue(nil); err == nil {
		t.Fatal("emptyaccepted")
	}
	now = now.Add(time.Second)
	packets := a.Tick(now)
	if len(packets) > directICMPBurst {
		t.Fatal("unboundedburst")
	}
	_, inner := directDeliver(t, a, b, packets, now)
	if !bytes.Equal(inner[0], []byte("copy")) {
		t.Fatal("Queueheldcallerslice")
	}
	if len(a.Tick(now)) != 0 {
		t.Fatal("sameinstantflood")
	}
	a.dropQueue()
	a.active.followupCredits = 0
	a.active.remoteMore = false
	if len(a.Tick(now.Add(20*time.Millisecond))) != 0 {
		t.Fatal("idleflood")
	}
	if p := a.Tick(now.Add(300 * time.Millisecond)); len(p) != 1 {
		t.Fatalf("idlepoll%d", len(p))
	}
	if len(b.Tick(now.Add(time.Second))) != 0 {
		t.Fatal("unsolicitedegress")
	}
}
func TestDirectICMPEngineResponsesNeverAmplify(t *testing.T) {
	a, b, now := directEnginePair(t)
	hello := a.Tick(now)[0]
	reply := directGet(t, b, hello, now)
	if len(reply) > len(hello) {
		t.Fatal("handshakeamplification")
	}
	confirm := directGet(t, a, reply, now)
	ack := directGet(t, b, confirm, now)
	if len(ack) > len(confirm) {
		t.Fatal("confirmamplification")
	}
	_, _, _ = a.Receive(ack, now)
	_ = b.Queue(bytes.Repeat([]byte{1}, 1200))
	now = now.Add(time.Second)
	poll := a.Tick(now)[0]
	response := directGet(t, b, poll, now)
	if len(response) > len(poll) {
		t.Fatal("dataamplification")
	}
}
func TestDirectICMPEngineNonceExhaustionAndNoReuse(t *testing.T) {
	a, b, now := directConnected(t)
	seen := map[uint64]bool{}
	for i := 0; i < 100; i++ {
		p, err := a.seal(a.active, directICMPData, nil)
		if err != nil {
			t.Fatal(err)
		}
		n := binary.BigEndian.Uint64(p[24:])
		if seen[n] {
			t.Fatal("noncereuse")
		}
		seen[n] = true
	}
	a.active.nonce = directICMPMaxNonce
	if _, err := a.seal(a.active, directICMPData, nil); err == nil {
		t.Fatal("noncewrapped")
	}
	now = now.Add(time.Second)
	directDeliver(t, a, b, a.Tick(now), now)
	if !a.Connected(now) || a.active.nonce >= directICMPMaxNonce {
		t.Fatal("nonceexhaustionrekeyfailed")
	}
}
func TestDirectICMPEngineInvalidConstructor(t *testing.T) {
	a, _, now := directEnginePair(t)
	for name, change := range map[string]func(*directICMPEngineConfig){"key": func(c *directICMPEngineConfig) { c.Key = [32]byte{} }, "mtu": func(c *directICMPEngineConfig) { c.MTU = 1 }, "poll": func(c *directICMPEngineConfig) { c.PollInterval = 0 }, "timeout": func(c *directICMPEngineConfig) { c.DeadAfter = 0 }, "rekey": func(c *directICMPEngineConfig) { c.RekeyAfter = time.Second }} {
		t.Run(name, func(t *testing.T) {
			c := a.config
			change(&c)
			if _, err := newDirectICMPEngine(c, now); err == nil {
				t.Fatal("invalidaccepted")
			}
		})
	}
	if _, err := newDirectICMPEngineRandom(a.config, now, io.LimitReader(bytes.NewReader(nil), 0)); err == nil {
		t.Fatal("entropysourcefailureignored")
	}
}
func FuzzDirectICMPEngineWire(f *testing.F) {
	f.Add([]byte("GDL1"))
	f.Add(make([]byte, 1252))
	f.Fuzz(func(t *testing.T, p []byte) {
		a, b, now := directEnginePair(t)
		_, _, _ = b.Receive(p, now)
		_, _, _ = a.Receive(p, now)
	})
}

func TestDirectICMPEngineSinglePingDoesNotCauseEmptyBurst(t *testing.T) {
	a, b, start := directConnected(t)
	a.config.PollInterval = 5 * time.Millisecond
	b.config.PollInterval = 5 * time.Millisecond
	if err := a.Queue([]byte("ping")); err != nil {
		t.Fatal(err)
	}
	requests, replyCount := 0, 0
	for ms := 5; ms <= 1000; ms += 5 {
		now := start.Add(time.Duration(ms) * time.Millisecond)
		packets := a.Tick(now)
		requests += len(packets)
		if len(packets) > 2 {
			t.Fatalf("singleping produced%drequests at%dms", len(packets), ms)
		}
		toA, toB := directDeliver(t, a, b, packets, now)
		for range toB {
			if err := b.Queue([]byte("reply")); err != nil {
				t.Fatal(err)
			}
		}
		replyCount += len(toA)
	}
	if replyCount != 1 || requests > 9 {
		t.Fatalf("singleping requests=%d replies=%d", requests, replyCount)
	}
	idle := 0
	for ms := 1005; ms <= 2000; ms += 5 {
		now := start.Add(time.Duration(ms) * time.Millisecond)
		p := a.Tick(now)
		idle += len(p)
		directDeliver(t, a, b, p, now)
	}
	if idle > 4 {
		t.Fatalf("idle exceeds4polls/s:%d", idle)
	}
}

func TestDirectICMPEngineBulkDemandDrainsAndStops(t *testing.T) {
	a, b, start := directConnected(t)
	a.config.PollInterval = 5 * time.Millisecond
	b.config.PollInterval = 5 * time.Millisecond
	for i := 0; i < 64; i++ {
		if err := b.Queue([]byte{byte(i)}); err != nil {
			t.Fatal(err)
		}
	}
	delivered, requests := 0, 0
	for ms := 250; ms <= 400; ms += 5 {
		now := start.Add(time.Duration(ms) * time.Millisecond)
		p := a.Tick(now)
		requests += len(p)
		toA, _ := directDeliver(t, a, b, p, now)
		delivered += len(toA)
	}
	if delivered != 64 || requests > 68 {
		t.Fatalf("bulk delivered%d requests%d", delivered, requests)
	}
	if a.active.remoteMore || a.active.followupCredits != 0 {
		t.Fatal("drainedpeerleftburstactive")
	}
}

func TestDirectICMPEngineOldMoreFlagDoesNotReactivatePolling(t *testing.T) {
	a, b, now := directConnected(t)
	_ = b.Queue([]byte("first"))
	_ = b.Queue([]byte("last"))
	firstRequest, _ := a.seal(a.active, directICMPData, nil)
	secondRequest, _ := a.seal(a.active, directICMPData, nil)
	firstReply := directGet(t, b, firstRequest, now)
	secondReply := directGet(t, b, secondRequest, now)
	if _, _, err := a.Receive(secondReply, now); err != nil {
		t.Fatal(err)
	}
	if a.active.remoteMore {
		t.Fatal("lastreplyshouldclearmore")
	}
	if _, _, err := a.Receive(firstReply, now); err != nil {
		t.Fatal(err)
	}
	if a.active.remoteMore {
		t.Fatal("oldmoreflagreactivatedburst")
	}
}
