package main

// FEC protects authenticated datagrams, not a reliable byte stream. Each codec
// belongs to one Noise session and one direction. Callers must authenticate the
// entire frame before Decode and must not share a decoder across sessions.
import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"math/bits"
	"time"

	"github.com/klauspost/reedsolomon"
)

const (
	directICMPFECDataShards   = 8
	directICMPFECRepairShards = 4
	directICMPFECHeaderSize   = 16
	directICMPFECOverhead     = directICMPFECHeaderSize + 2
	directICMPFECMaxBlocks    = 64
	directICMPFECWindow       = 256
	directICMPFECMaxBlockID   = uint64(1)<<48 - 1
	directICMPFECSource       = byte(1)
	directICMPFECRepair       = byte(2)
)

var errDirectICMPFECFrame = errors.New("invalid Direct ICMP FEC frame")

type directICMPFECFrameInfo struct {
	Block       uint64
	Index       int
	DataCount   int
	RepairCount int
	Repair      bool
}

// Layout: kind, actual source count, repair count, shard index, block uint64,
// symbol size uint16, two reserved zero bytes, padded symbol. A source has zero
// counts because it leaves immediately, before the block's final size is known.
// Repairs announce that size. Unused positions in a partial block are all zero.
func directICMPFECFrameMetadata(frame []byte) (directICMPFECFrameInfo, error) {
	var m directICMPFECFrameInfo
	if len(frame) < directICMPFECOverhead+1 {
		return m, errDirectICMPFECFrame
	}
	size := int(binary.BigEndian.Uint16(frame[12:14]))
	if size < 3 || size > 9002 || len(frame) != directICMPFECHeaderSize+size || frame[14] != 0 || frame[15] != 0 {
		return m, errDirectICMPFECFrame
	}
	m = directICMPFECFrameInfo{Block: binary.BigEndian.Uint64(frame[4:12]), Index: int(frame[3]), DataCount: int(frame[1]), RepairCount: int(frame[2]), Repair: frame[0] == directICMPFECRepair}
	if m.Block == 0 || m.Block > directICMPFECMaxBlockID {
		return directICMPFECFrameInfo{}, errDirectICMPFECFrame
	}
	switch frame[0] {
	case directICMPFECSource:
		if m.DataCount != 0 || m.RepairCount != 0 || m.Index >= directICMPFECDataShards || !directICMPFECValidSymbol(frame[directICMPFECHeaderSize:], size-2) {
			return directICMPFECFrameInfo{}, errDirectICMPFECFrame
		}
	case directICMPFECRepair:
		if m.DataCount < 1 || m.DataCount > directICMPFECDataShards || m.RepairCount < 1 || m.RepairCount > directICMPFECRepairShards || m.Index < directICMPFECDataShards || m.Index >= directICMPFECDataShards+m.RepairCount {
			return directICMPFECFrameInfo{}, errDirectICMPFECFrame
		}
	default:
		return directICMPFECFrameInfo{}, errDirectICMPFECFrame
	}
	return m, nil
}

func directICMPFECValidSymbol(symbol []byte, mtu int) bool {
	if len(symbol) != mtu+2 {
		return false
	}
	n := int(binary.BigEndian.Uint16(symbol[:2]))
	if n == 0 || n > mtu {
		return false
	}
	for _, b := range symbol[n+2:] {
		if b != 0 {
			return false
		}
	}
	return true
}

func directICMPFECMakeFrame(block uint64, index, actual, repairs int, symbol []byte) []byte {
	f := make([]byte, directICMPFECHeaderSize+len(symbol))
	f[0] = directICMPFECSource
	if index >= directICMPFECDataShards {
		f[0], f[1], f[2] = directICMPFECRepair, byte(actual), byte(repairs)
	}
	f[3] = byte(index)
	binary.BigEndian.PutUint64(f[4:12], block)
	binary.BigEndian.PutUint16(f[12:14], uint16(len(symbol)))
	copy(f[directICMPFECHeaderSize:], symbol)
	return f
}

func directICMPFECCodecs() ([directICMPFECRepairShards]reedsolomon.Encoder, error) {
	var codecs [directICMPFECRepairShards]reedsolomon.Encoder
	for i := range codecs {
		// Small, fixed-size blocks never launch worker goroutines or grow their
		// shard count in response to network-provided metadata.
		c, err := reedsolomon.New(directICMPFECDataShards, i+1, reedsolomon.WithMaxGoroutines(1))
		if err != nil {
			return codecs, err
		}
		codecs[i] = c
	}
	return codecs, nil
}

type directICMPFECEncoderStats struct {
	Sources, Repairs         uint64
	SourceBytes, RepairBytes uint64
	Blocks                   uint64
	Percent, Credit          int
}

type directICMPFECEncoder struct {
	mtu, percent, credit int
	timeout              time.Duration
	block                uint64
	started              time.Time
	data                 [][]byte
	codecs               [directICMPFECRepairShards]reedsolomon.Encoder
	stats                directICMPFECEncoderStats
}

func newDirectICMPFECEncoder(mtu, percent int, blockTimeout time.Duration) (*directICMPFECEncoder, error) {
	if mtu < 1 || mtu > 9000 || percent < 0 || percent > 50 || blockTimeout < 5*time.Millisecond || blockTimeout > 100*time.Millisecond {
		return nil, errors.New("invalid Direct ICMP FEC encoder configuration")
	}
	cs, err := directICMPFECCodecs()
	if err != nil {
		return nil, err
	}
	return &directICMPFECEncoder{mtu: mtu, percent: percent, timeout: blockTimeout, block: 1, codecs: cs}, nil
}

func (e *directICMPFECEncoder) SetPercent(percent int) error {
	if percent < 0 || percent > 50 {
		return errors.New("Direct ICMP FEC percent must be 0..50")
	}
	e.percent = percent
	if percent == 0 {
		e.credit = 0
	}
	return nil
}

// Encode never withholds a source. Repairs returned alongside it may belong to
// the preceding expired block, so callers must preserve the frame metadata.
func (e *directICMPFECEncoder) Encode(data []byte, now time.Time) ([]byte, [][]byte, error) {
	if len(data) == 0 || len(data) > e.mtu || e.block > directICMPFECMaxBlockID {
		return nil, nil, errDirectICMPFECFrame
	}
	repairs, err := e.Flush(now)
	if err != nil || e.block > directICMPFECMaxBlockID {
		return nil, repairs, errDirectICMPFECFrame
	}
	if len(e.data) == 0 {
		e.started = now
	}
	symbol := make([]byte, e.mtu+2)
	binary.BigEndian.PutUint16(symbol, uint16(len(data)))
	copy(symbol[2:], data)
	source := directICMPFECMakeFrame(e.block, len(e.data), 0, 0, symbol)
	e.data = append(e.data, symbol)
	// Integer credit carries between blocks; a lone source cannot create one
	// repair every time. Because all frames are equally padded, this bounds
	// both emitted repair packet count and bytes by the configured percentage.
	// The caller additionally gates actual socket sends using successful-source
	// accounting, since a failed local send must not earn repair bandwidth.
	e.credit = min(directICMPFECRepairShards*100, e.credit+e.percent)
	e.stats.Sources++
	e.stats.SourceBytes += uint64(len(source))
	if len(e.data) == directICMPFECDataShards {
		more, closeErr := e.closeBlock()
		repairs = append(repairs, more...)
		if closeErr != nil {
			return source, repairs, closeErr
		}
	}
	return source, repairs, nil
}

// Flush closes only an expired nonempty block. It never emits idle traffic.
func (e *directICMPFECEncoder) Flush(now time.Time) ([][]byte, error) {
	if len(e.data) == 0 || now.Sub(e.started) < e.timeout {
		return nil, nil
	}
	return e.closeBlock()
}

func (e *directICMPFECEncoder) closeBlock() ([][]byte, error) {
	actual := len(e.data)
	r := min(directICMPFECRepairShards, e.credit/100)
	// More repairs than actual source packets are never useful or permitted.
	r = min(r, actual)
	var out [][]byte
	if r > 0 {
		shards := make([][]byte, directICMPFECDataShards+r)
		copy(shards, e.data)
		for i := actual; i < len(shards); i++ {
			shards[i] = make([]byte, e.mtu+2)
		}
		if err := e.codecs[r-1].Encode(shards); err != nil {
			return nil, fmt.Errorf("Direct ICMP FEC encode: %w", err)
		}
		for i := directICMPFECDataShards; i < len(shards); i++ {
			frame := directICMPFECMakeFrame(e.block, i, actual, r, shards[i])
			out = append(out, frame)
			e.stats.Repairs++
			e.stats.RepairBytes += uint64(len(frame))
		}
		e.credit -= r * 100
	}
	e.data = nil
	e.started = time.Time{}
	e.block++
	e.stats.Blocks++
	return out, nil
}

func (e *directICMPFECEncoder) Stats() directICMPFECEncoderStats {
	s := e.stats
	s.Percent, s.Credit = e.percent, e.credit
	return s
}

type directICMPFECDecoderStats struct {
	Sources, Repairs, Recovered, Duplicates, Expired, Evicted uint64
	Blocks, Retired, BufferedBytes                            int
}

type directICMPFECReceiveBlock struct {
	created         time.Time
	actual, repairs int
	sourceMask      uint8
	recoveredMask   uint8
	delivered       uint8
	shards          [directICMPFECDataShards + directICMPFECRepairShards][]byte
}

type directICMPFECDecoder struct {
	mtu, maxBlocks int
	ttl            time.Duration
	high           uint64
	blocks         map[uint64]*directICMPFECReceiveBlock
	retired        map[uint64]struct{}
	codecs         [directICMPFECRepairShards]reedsolomon.Encoder
	stats          directICMPFECDecoderStats
}

func newDirectICMPFECDecoder(mtu int, ttl time.Duration, maxBlocks int) (*directICMPFECDecoder, error) {
	if mtu < 1 || mtu > 9000 || ttl < 100*time.Millisecond || ttl > 30*time.Second || maxBlocks < 1 || maxBlocks > directICMPFECMaxBlocks {
		return nil, errors.New("invalid Direct ICMP FEC decoder configuration")
	}
	cs, err := directICMPFECCodecs()
	if err != nil {
		return nil, err
	}
	return &directICMPFECDecoder{mtu: mtu, ttl: ttl, maxBlocks: maxBlocks, blocks: make(map[uint64]*directICMPFECReceiveBlock), retired: make(map[uint64]struct{}), codecs: cs}, nil
}

// Expire leaves bounded tombstones: a late original cannot be delivered again
// after its reconstructed block has expired. IDs below the sliding window are
// permanently stale for this session, even after tombstones are discarded.
func (d *directICMPFECDecoder) Expire(now time.Time) {
	for id, b := range d.blocks {
		if now.Sub(b.created) >= d.ttl {
			delete(d.blocks, id)
			d.retired[id] = struct{}{}
			d.stats.Expired++
		}
	}
}

func (d *directICMPFECDecoder) advance(block uint64) {
	if block <= d.high {
		return
	}
	d.high = block
	if d.high < directICMPFECWindow {
		return
	}
	floor := d.high - directICMPFECWindow
	for id := range d.blocks {
		if id <= floor {
			delete(d.blocks, id)
			d.stats.Evicted++
		}
	}
	for id := range d.retired {
		if id <= floor {
			delete(d.retired, id)
		}
	}
}

func (d *directICMPFECDecoder) Decode(frame []byte, now time.Time) ([][]byte, error) {
	m, err := directICMPFECFrameMetadata(frame)
	if err != nil || len(frame) != d.mtu+directICMPFECOverhead {
		return nil, errDirectICMPFECFrame
	}
	d.Expire(now)
	if d.high >= directICMPFECWindow && m.Block <= d.high-directICMPFECWindow {
		d.stats.Duplicates++
		return nil, nil
	}
	if _, stale := d.retired[m.Block]; stale {
		d.stats.Duplicates++
		return nil, nil
	}
	b, exists := d.blocks[m.Block]
	if !exists {
		b = &directICMPFECReceiveBlock{created: now}
	}
	// Validate all cross-frame metadata before mutating the retained block.
	if m.Repair {
		if b.actual != 0 && (b.actual != m.DataCount || b.repairs != m.RepairCount) {
			return nil, errDirectICMPFECFrame
		}
		if b.sourceMask&^uint8((1<<m.DataCount)-1) != 0 {
			return nil, errDirectICMPFECFrame
		}
	} else if b.actual != 0 && m.Index >= b.actual {
		return nil, errDirectICMPFECFrame
	}
	symbol := frame[directICMPFECHeaderSize:]
	if old := b.shards[m.Index]; old != nil {
		if !bytes.Equal(old, symbol) {
			return nil, errDirectICMPFECFrame
		}
		if !m.Repair && b.sourceMask&(1<<m.Index) == 0 {
			// A late original confirms receipt but never redelivers recovered data.
			b.sourceMask |= 1 << m.Index
			d.stats.Sources++
		}
		d.stats.Duplicates++
		return nil, nil
	}
	// A candidate copy makes malformed reconstruction transactional. Existing
	// immutable shards are shared; only absent shards are written by the codec.
	candidate := *b
	candidate.shards[m.Index] = bytes.Clone(symbol)
	if m.Repair {
		candidate.actual, candidate.repairs = m.DataCount, m.RepairCount
	} else {
		candidate.sourceMask |= 1 << m.Index
	}
	var delivered [][]byte
	if !m.Repair && candidate.delivered&(1<<m.Index) == 0 {
		n := int(binary.BigEndian.Uint16(symbol[:2]))
		delivered = append(delivered, bytes.Clone(symbol[2:2+n]))
		candidate.delivered |= 1 << m.Index
	}
	recovered := uint64(0)
	if candidate.actual != 0 && bits.OnesCount8(candidate.delivered) < candidate.actual {
		available := 0
		shards := make([][]byte, directICMPFECDataShards+candidate.repairs)
		copy(shards, candidate.shards[:])
		for i := candidate.actual; i < directICMPFECDataShards; i++ {
			shards[i] = make([]byte, d.mtu+2)
		}
		for _, s := range shards {
			if s != nil {
				available++
			}
		}
		if available >= directICMPFECDataShards {
			codec := d.codecs[candidate.repairs-1]
			if err := codec.Reconstruct(shards); err != nil {
				return nil, errDirectICMPFECFrame
			}
			valid, verifyErr := codec.Verify(shards)
			if verifyErr != nil || !valid {
				return nil, errDirectICMPFECFrame
			}
			for i := 0; i < candidate.actual; i++ {
				if !directICMPFECValidSymbol(shards[i], d.mtu) {
					return nil, errDirectICMPFECFrame
				}
			}
			for i := 0; i < candidate.actual; i++ {
				if candidate.delivered&(1<<i) == 0 {
					n := int(binary.BigEndian.Uint16(shards[i][:2]))
					delivered = append(delivered, bytes.Clone(shards[i][2:2+n]))
					candidate.delivered |= 1 << i
					candidate.recoveredMask |= 1 << i
					recovered++
				}
			}
			// Retain only source shards and actually received repair shards.
			// Synthesized parity is not evidence of original network reception.
			for i := 0; i < candidate.actual; i++ {
				candidate.shards[i] = shards[i]
			}
		}
	}
	d.advance(m.Block)
	if !exists && len(d.blocks) >= d.maxBlocks {
		var oldest uint64
		for id, held := range d.blocks {
			if oldest == 0 || held.created.Before(d.blocks[oldest].created) || (held.created.Equal(d.blocks[oldest].created) && id < oldest) {
				oldest = id
			}
		}
		delete(d.blocks, oldest)
		d.retired[oldest] = struct{}{}
		d.stats.Evicted++
	}
	d.blocks[m.Block] = &candidate
	if m.Repair {
		d.stats.Repairs++
	} else {
		d.stats.Sources++
	}
	d.stats.Recovered += recovered
	return delivered, nil
}

func (d *directICMPFECDecoder) BlockMasks(block uint64) (sourceMask, recoveredMask uint8, actual int, ok bool) {
	if b := d.blocks[block]; b != nil {
		return b.sourceMask, b.recoveredMask, b.actual, true
	}
	return 0, 0, 0, false
}

func (d *directICMPFECDecoder) Stats() directICMPFECDecoderStats {
	s := d.stats
	s.Blocks, s.Retired = len(d.blocks), len(d.retired)
	for _, b := range d.blocks {
		for _, shard := range b.shards {
			s.BufferedBytes += len(shard)
		}
	}
	return s
}
