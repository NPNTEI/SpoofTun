package main

import (
	"encoding/json"
	"testing"
	"time"
)

func TestDirectICMPFECConfigLegacyAndExplicitDefaults(t *testing.T) {
	c := directRuntimeConfig()
	b, _ := json.Marshal(c)
	var doc map[string]any
	_ = json.Unmarshal(b, &doc)
	for _, key := range []string{"fec_mode", "fec_percent", "fec_max_percent", "fec_block_ms"} {
		delete(doc, key)
	}
	legacy, _ := json.Marshal(doc)
	got, err := parseDirectICMPConfig(legacy)
	if err != nil {
		t.Fatal(err)
	}
	if got.FECMode != "off" || got.FECPercent != 20 || got.FECMaxPercent != 25 || got.FECBlockMS != 20 {
		t.Fatalf("legacy defaults: %+v", got)
	}
	doc["fec_mode"] = "fixed"
	doc["fec_percent"] = 0
	fixed, _ := json.Marshal(doc)
	got, err = parseDirectICMPConfig(fixed)
	if err != nil {
		t.Fatal(err)
	}
	if got.FECMode != "fixed" || got.FECPercent != 0 {
		t.Fatal("explicit zero repair was not preserved")
	}
	roundtrip, _ := json.Marshal(got)
	again, err := parseDirectICMPConfig(roundtrip)
	if err != nil || again.FECPercent != 0 {
		t.Fatal("zero repair did not survive roundtrip", err)
	}
	doc["fec_mode"] = "adaptive"
	doc["fec_percent"] = 15
	doc["fec_max_percent"] = 30
	doc["fec_block_ms"] = 10
	data, _ := json.Marshal(doc)
	got, err = parseDirectICMPConfig(data)
	if err != nil {
		t.Fatal(err)
	}
	ec := got.engineConfig()
	if ec.FECMode != "adaptive" || ec.FECPercent != 15 || ec.FECMaxPercent != 30 || ec.FECBlock != 10*time.Millisecond {
		t.Fatal("FEC options not transferred to runtime")
	}
}

func TestDirectICMPFECConfigRejectsUnsafeOrAmbiguousValues(t *testing.T) {
	b, _ := json.Marshal(directRuntimeConfig())
	var baseline map[string]any
	_ = json.Unmarshal(b, &baseline)
	baseline["fec_mode"] = "adaptive"
	baseline["fec_percent"] = 20
	for _, tc := range []struct {
		key   string
		value any
	}{
		{"fec_mode", "auto"}, {"fec_mode", "Adaptive"}, {"fec_mode", ""},
		{"fec_percent", -1}, {"fec_percent", 26}, {"fec_percent", 1.5},
		{"fec_max_percent", 0}, {"fec_max_percent", 4}, {"fec_max_percent", 51},
		{"fec_block_ms", 0}, {"fec_block_ms", 4}, {"fec_block_ms", 101},
		{"fec_mode", nil}, {"fec_percent", nil}, {"fec_max_percent", nil}, {"fec_block_ms", nil},
	} {
		t.Run(tc.key, func(t *testing.T) {
			doc := make(map[string]any)
			for k, v := range baseline {
				doc[k] = v
			}
			doc[tc.key] = tc.value
			data, _ := json.Marshal(doc)
			if _, err := parseDirectICMPConfig(data); err == nil {
				t.Fatalf("accepted %s=%v", tc.key, tc.value)
			}
		})
	}
}
