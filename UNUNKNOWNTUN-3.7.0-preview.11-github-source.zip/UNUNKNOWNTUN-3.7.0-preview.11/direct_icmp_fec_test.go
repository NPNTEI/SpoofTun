package main

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"math/bits"
	"testing"
	"time"
)

func fecTestBlock(t *testing.T, actual, repairs int) ([][]byte, [][]byte, time.Time) {
	t.Helper()
	now := time.Unix(1000, 0)
	e, err := newDirectICMPFECEncoder(96, 0, 20*time.Millisecond)
	if err != nil {
		t.Fatal(err)
	}
	// Earned credit is seeded here to exhaustively exercise all shard geometries;
	// independent budget tests below verify only credit earned by real sources.
	e.credit = repairs * 100
	var frames, original [][]byte
	for i := 0; i < actual; i++ {
		payload := bytes.Repeat([]byte{byte(i + 1)}, 1+i*11)
		original = append(original, payload)
		src, parity, err := e.Encode(payload, now)
		if err != nil {
			t.Fatal(err)
		}
		frames = append(frames, src)
		frames = append(frames, parity...)
	}
	parity, err := e.Flush(now.Add(20 * time.Millisecond))
	if err != nil {
		t.Fatal(err)
	}
	frames = append(frames, parity...)
	if len(frames) != actual+repairs {
		t.Fatalf("wanted %d frames, got %d", actual+repairs, len(frames))
	}
	return frames, original, now
}

func TestDirectICMPFECAllRecoverableLossPatterns(t *testing.T) {
	for actual := 1; actual <= 8; actual++ {
		for repairs := 1; repairs <= min(actual, 4); repairs++ {
			t.Run(fmt.Sprintf("data%d-repair%d", actual, repairs), func(t *testing.T) {
				frames, original, now := fecTestBlock(t, actual, repairs)
				for lost := 0; lost < 1<<len(frames); lost++ {
					if bits.OnesCount(uint(lost)) > repairs {
						continue
					}
					d, err := newDirectICMPFECDecoder(96, time.Second, 8)
					if err != nil {
						t.Fatal(err)
					}
					seen := make(map[byte]int)
					// Reverse order includes parity-before-source and source reordering.
					for i := len(frames) - 1; i >= 0; i-- {
						if lost&(1<<i) != 0 {
							continue
						}
						for duplicate := 0; duplicate < 2; duplicate++ {
							out, err := d.Decode(frames[i], now)
							if err != nil {
								t.Fatalf("loss mask %x frame%d: %v", lost, i, err)
							}
							for _, payload := range out {
								id := payload[0]
								if id < 1 || int(id) > len(original) || !bytes.Equal(payload, original[id-1]) {
									t.Fatalf("loss mask %x: reconstructed wrong data %x", lost, payload)
								}
								seen[id]++
							}
						}
					}
					for i := range original {
						if seen[byte(i+1)] != 1 {
							t.Fatalf("loss mask %x: source%d delivered %d times", lost, i, seen[byte(i+1)])
						}
					}
					// Originals received after reconstruction must not redeliver.
					for _, frame := range frames[:actual] {
						out, err := d.Decode(frame, now.Add(10*time.Millisecond))
						if err != nil || len(out) != 0 {
							t.Fatalf("late original: %d outputs, %v", len(out), err)
						}
					}
				}
			})
		}
	}
}

func TestDirectICMPFECSourceIsImmediateAndTimeoutClosesPartial(t *testing.T) {
	now := time.Unix(1000, 0)
	e, _ := newDirectICMPFECEncoder(96, 20, 20*time.Millisecond)
	d, _ := newDirectICMPFECDecoder(96, time.Second, 8)
	for i := 0; i < 5; i++ {
		src, repairs, err := e.Encode([]byte{byte(i + 1)}, now)
		if err != nil || len(src) != 114 || len(repairs) != 0 {
			t.Fatalf("immediate source missing: %d/%d %v", len(src), len(repairs), err)
		}
		out, err := d.Decode(src, now)
		if err != nil || len(out) != 1 || !bytes.Equal(out[0], []byte{byte(i + 1)}) {
			t.Fatalf("source delayed until parity: %v %v", out, err)
		}
	}
	if r, _ := e.Flush(now.Add(19 * time.Millisecond)); len(r) != 0 {
		t.Fatal("block closed too early")
	}
	r, err := e.Flush(now.Add(20 * time.Millisecond))
	if err != nil || len(r) != 1 {
		t.Fatalf("partial flush: %d %v", len(r), err)
	}
	m, _ := directICMPFECFrameMetadata(r[0])
	if m.Block != 1 || m.DataCount != 5 || m.RepairCount != 1 {
		t.Fatalf("wrong partial metadata: %+v", m)
	}
	if r, _ := e.Flush(now.Add(time.Hour)); len(r) != 0 {
		t.Fatal("idle flush emitted traffic")
	}
	src, _, _ := e.Encode([]byte("next block"), now.Add(time.Hour))
	m, _ = directICMPFECFrameMetadata(src)
	if m.Block != 2 || m.Index != 0 {
		t.Fatalf("block ID reused: %+v", m)
	}
}

func TestDirectICMPFECBudgetNeverRoundsSparseBlocksUp(t *testing.T) {
	for _, percent := range []int{0, 1, 5, 20, 25, 50} {
		for _, partial := range []int{1, 2, 3, 5, 8} {
			t.Run(fmt.Sprintf("percent%d-block%d", percent, partial), func(t *testing.T) {
				now := time.Unix(1000, 0)
				e, _ := newDirectICMPFECEncoder(1200, percent, 20*time.Millisecond)
				for i := 0; i < 1000; i++ {
					if _, _, err := e.Encode([]byte{1}, now); err != nil {
						t.Fatal(err)
					}
					if (i+1)%partial == 0 {
						now = now.Add(20 * time.Millisecond)
						if _, err := e.Flush(now); err != nil {
							t.Fatal(err)
						}
					}
					s := e.Stats()
					if s.Repairs*100 > s.Sources*uint64(percent) || s.RepairBytes*100 > s.SourceBytes*uint64(percent) || s.Credit > 400 {
						t.Fatalf("overhead limit exceeded: %+v", s)
					}
				}
				if percent > 0 && e.Stats().Repairs == 0 {
					t.Fatal("sparse flows never earned any protection")
				}
			})
		}
	}
}

func TestDirectICMPFECAdaptiveBudgetUsesEarnedCreditOnly(t *testing.T) {
	e, _ := newDirectICMPFECEncoder(96, 20, 20*time.Millisecond)
	now := time.Unix(1000, 0)
	earned := uint64(0)
	for i := 0; i < 2000; i++ {
		percent := []int{0, 5, 10, 25, 50, 20}[i/37%6]
		if err := e.SetPercent(percent); err != nil {
			t.Fatal(err)
		}
		earned += uint64(percent)
		_, _, err := e.Encode([]byte("source"), now)
		if err != nil {
			t.Fatal(err)
		}
		now = now.Add(21 * time.Millisecond)
		if _, err := e.Flush(now); err != nil {
			t.Fatal(err)
		}
		if s := e.Stats(); s.Repairs*100 > earned || s.Repairs*100 > s.Sources*50 {
			t.Fatalf("adaptive credit invented bandwidth: %+v credit%d", s, earned)
		}
	}
	if err := e.SetPercent(51); err == nil {
		t.Fatal("accepted excessive percentage")
	}
}

func TestDirectICMPFECMalformedMetadataCannotPoisonBlock(t *testing.T) {
	frames, _, now := fecTestBlock(t, 5, 2)
	mutations := []func([]byte){
		func(f []byte) { f[0] = 3 },
		func(f []byte) { f[1] = 9 },
		func(f []byte) { f[2] = 5 },
		func(f []byte) { f[3] = 255 },
		func(f []byte) { clear(f[4:12]) },
		func(f []byte) { binary.BigEndian.PutUint64(f[4:12], directICMPFECMaxBlockID+1) },
		func(f []byte) { f[13]-- },
		func(f []byte) { f[14] = 1 },
		func(f []byte) { f[15] = 1 },
	}
	for n, mutate := range mutations {
		d, _ := newDirectICMPFECDecoder(96, time.Second, 8)
		f := bytes.Clone(frames[5])
		mutate(f)
		if _, err := d.Decode(f, now); err == nil {
			t.Fatalf("mutation%d accepted", n)
		}
		if s := d.Stats(); s.Blocks != 0 || s.BufferedBytes != 0 || d.high != 0 {
			t.Fatalf("mutation%d poisoned retained state: %+v", n, s)
		}
		if out, err := d.Decode(frames[0], now); err != nil || len(out) != 1 {
			t.Fatalf("mutation%d rejected next valid source", n)
		}
	}
	for _, pos := range []int{16, 17, len(frames[0]) - 1} {
		d, _ := newDirectICMPFECDecoder(96, time.Second, 8)
		f := bytes.Clone(frames[0])
		f[pos] = 255 // invalid length or nonzero canonical padding
		if _, err := d.Decode(f, now); err == nil || d.Stats().Blocks != 0 {
			t.Fatalf("malformed source position%d accepted", pos)
		}
	}
	for n := 0; n < len(frames[0]); n++ {
		if _, err := directICMPFECFrameMetadata(frames[0][:n]); err == nil {
			t.Fatalf("truncated frame length%d accepted", n)
		}
	}
}

func TestDirectICMPFECConflictingMetadataAndReconstructionAtomic(t *testing.T) {
	frames, _, now := fecTestBlock(t, 5, 2)
	d, _ := newDirectICMPFECDecoder(96, time.Second, 8)
	for _, f := range frames[:4] {
		if _, err := d.Decode(f, now); err != nil {
			t.Fatal(err)
		}
	}
	bad := bytes.Clone(frames[5])
	bad[1] = 3 // contradicts source index3 already received
	before := d.Stats()
	if _, err := d.Decode(bad, now); err == nil {
		t.Fatal("conflicting partial count accepted")
	}
	if d.Stats() != before {
		t.Fatal("metadata conflict mutated block")
	}
	bad = bytes.Clone(frames[5])
	bad[16] ^= 0xff // recovered length must fail validation
	if _, err := d.Decode(bad, now); err == nil {
		t.Fatal("malformed reconstruction accepted")
	}
	if d.Stats() != before {
		t.Fatal("malformed reconstruction poisoned block")
	}
	out, err := d.Decode(frames[5], now)
	if err != nil || len(out) != 1 || out[0][0] != 5 {
		t.Fatalf("valid repair after failed candidate did not recover: %v %v", out, err)
	}
	src, rec, actual, ok := d.BlockMasks(1)
	if !ok || src != 15 || rec != 16 || actual != 5 {
		t.Fatalf("wrong masks %x/%x/%d/%v", src, rec, actual, ok)
	}
	if out, err := d.Decode(frames[4], now); err != nil || len(out) != 0 {
		t.Fatal("late source redelivered")
	}
	src, rec, _, _ = d.BlockMasks(1)
	if src != 31 || rec != 16 {
		t.Fatal("late source not accounted separately from reconstruction")
	}
	bad = bytes.Clone(frames[6])
	bad[2] = 3
	if _, err := d.Decode(bad, now); err == nil {
		t.Fatal("conflicting repair count accepted")
	}
}

func TestDirectICMPFECExpiryEvictionAndWindowBoundExactlyOnce(t *testing.T) {
	frames, _, now := fecTestBlock(t, 1, 1)
	d, _ := newDirectICMPFECDecoder(96, 100*time.Millisecond, 2)
	if out, err := d.Decode(frames[1], now); err != nil || len(out) != 1 {
		t.Fatal("initial recovery failed")
	}
	d.Expire(now.Add(100 * time.Millisecond))
	if out, err := d.Decode(frames[0], now.Add(101*time.Millisecond)); err != nil || len(out) != 0 {
		t.Fatal("expired block redelivered")
	}
	for i := uint64(2); i < 1000; i++ {
		f := bytes.Clone(frames[0])
		binary.BigEndian.PutUint64(f[4:12], i)
		if out, err := d.Decode(f, now); err != nil || len(out) != 1 {
			t.Fatalf("block%d decode failed", i)
		}
		s := d.Stats()
		if s.Blocks > 2 || s.Retired > directICMPFECWindow || s.BufferedBytes > 2*12*98 {
			t.Fatalf("unbounded state %+v", s)
		}
	}
	if out, err := d.Decode(frames[0], now); err != nil || len(out) != 0 {
		t.Fatal("old original redelivered after tombstone expiry")
	}
	if d.Stats().Evicted == 0 || d.Stats().Expired != 1 {
		t.Fatal("eviction/expiry not recorded")
	}
}

func TestDirectICMPFECOwnershipAndSessionIsolation(t *testing.T) {
	now := time.Unix(1000, 0)
	e, _ := newDirectICMPFECEncoder(96, 50, 20*time.Millisecond)
	d1, _ := newDirectICMPFECDecoder(96, time.Second, 8)
	d2, _ := newDirectICMPFECDecoder(96, time.Second, 8)
	payload := []byte("session-owned")
	src, _, _ := e.Encode(payload, now)
	payload[0] ^= 0xff
	out, err := d1.Decode(src, now)
	if err != nil || len(out) != 1 || string(out[0]) != "session-owned" {
		t.Fatal("encoder retained mutable caller memory")
	}
	out[0][0] ^= 0xff
	if again, err := d1.Decode(src, now); err != nil || len(again) != 0 {
		t.Fatal("returned data aliases decoder state")
	}
	if out, err := d2.Decode(src, now); err != nil || len(out) != 1 {
		t.Fatal("separate sessions shared dedup state")
	}
	src[18] ^= 0xff
	if _, err := d1.Decode(src, now); err == nil {
		t.Fatal("conflicting duplicate or mutable retained input accepted")
	}
}

func TestDirectICMPFECConfigurationAndCounterBounds(t *testing.T) {
	for _, c := range []struct {
		mtu, percent int
		timeout      time.Duration
	}{{0, 20, 20 * time.Millisecond}, {9001, 20, 20 * time.Millisecond}, {96, -1, 20 * time.Millisecond}, {96, 51, 20 * time.Millisecond}, {96, 20, 4 * time.Millisecond}, {96, 20, 101 * time.Millisecond}} {
		if _, err := newDirectICMPFECEncoder(c.mtu, c.percent, c.timeout); err == nil {
			t.Fatalf("invalid encoder config accepted: %+v", c)
		}
	}
	for _, c := range []struct {
		mtu, max int
		ttl      time.Duration
	}{{0, 1, time.Second}, {9001, 1, time.Second}, {96, 0, time.Second}, {96, 65, time.Second}, {96, 1, 99 * time.Millisecond}, {96, 1, 31 * time.Second}} {
		if _, err := newDirectICMPFECDecoder(c.mtu, c.ttl, c.max); err == nil {
			t.Fatalf("invalid decoder config accepted: %+v", c)
		}
	}
	e, _ := newDirectICMPFECEncoder(96, 20, 20*time.Millisecond)
	now := time.Unix(1000, 0)
	for _, p := range [][]byte{nil, make([]byte, 97)} {
		if _, _, err := e.Encode(p, now); err == nil || e.Stats().Sources != 0 {
			t.Fatal("invalid source mutated encoder")
		}
	}
	e.block = directICMPFECMaxBlockID
	if _, _, err := e.Encode([]byte{1}, now); err != nil {
		t.Fatal(err)
	}
	if _, err := e.Flush(now.Add(20 * time.Millisecond)); err != nil {
		t.Fatal(err)
	}
	if _, _, err := e.Encode([]byte{1}, now.Add(time.Second)); err == nil {
		t.Fatal("block counter wrapped")
	}
}

func FuzzDirectICMPFECDecode(f *testing.F) {
	symbol := make([]byte, 98)
	binary.BigEndian.PutUint16(symbol, 1)
	symbol[2] = 42
	f.Add(directICMPFECMakeFrame(1, 0, 0, 0, symbol))
	f.Add([]byte("invalid"))
	f.Fuzz(func(t *testing.T, wire []byte) {
		d, _ := newDirectICMPFECDecoder(96, time.Second, 2)
		_, _ = d.Decode(wire, time.Unix(1000, 0))
		if s := d.Stats(); s.Blocks > 2 || s.BufferedBytes > 2*12*98 {
			t.Fatal("decoder exceeded memory cap")
		}
	})
}
