package main

import (
	"encoding/binary"
	"testing"
	"time"
)

// The sender key is deliberately available to this in-process fuzzer so it
// reaches semantic validation behind AEAD rather than merely failing tags.
func FuzzDirectICMPFECAuthenticatedWire(f *testing.F) {
	seed := make([]byte, 1200+directICMPControlSize+directICMPFECFrameExtra+directICMPFECFeedbackSize)
	seed[14] = directICMPBurst // feedback byte10 after the4-byte control header
	f.Add(append([]byte(nil), seed...))
	encoder, err := newDirectICMPFECEncoder(1200, 25, 20*time.Millisecond)
	if err != nil {
		f.Fatal(err)
	}
	frame, _, err := encoder.Encode([]byte("fuzz payload"), time.Unix(1, 0))
	if err != nil {
		f.Fatal(err)
	}
	binary.BigEndian.PutUint16(seed[2:4], uint16(len(frame)))
	copy(seed[36:], frame)
	f.Add(append([]byte(nil), seed...))
	f.Fuzz(func(t *testing.T, input []byte) {
		a, b, now := directFECPair(t, "fixed", 25)
		if len(input) > a.MaxWireSize() {
			return
		}
		plain := make([]byte, a.config.MTU+directICMPControlSize+directICMPFECFrameExtra+directICMPFECFeedbackSize)
		copy(plain, input)
		nonce := a.active.nonce
		header := a.header(directICMPPacket, a.direction(), a.active.id, nonce)
		wire := a.active.tx.Encrypt(header, nonce, header, plain)
		previous := b.active.replay.high
		out, inner, err := b.Receive(wire, now.Add(time.Millisecond))
		if err != nil {
			if len(out) > 0 || len(inner) > 0 || b.active.replay.high != previous {
				t.Fatal("invalid authenticated frame changed delivery/replay")
			}
			return
		}
		if len(out) > 1 || len(inner) > 8 {
			t.Fatal("unbounded response or decode amplification")
		}
		for _, p := range inner {
			if len(p) == 0 || len(p) > 1200 {
				t.Fatal("invalid reconstructed size")
			}
		}
		if _, _, err := b.Receive(wire, now.Add(2*time.Millisecond)); err == nil {
			t.Fatal("authenticated duplicate accepted")
		}
	})
}
