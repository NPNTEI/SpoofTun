package main

// FEC v2 feedback describes authenticated source symbols, before recovery. The
// sender intersects reports with successful local socket sends. In particular,
// a nonce gap, queue drop, missing Echo reply or expired feedback is NOT a WAN
// loss sample. Each session owns its bounded codec and feedback history.
import (
	"encoding/binary"
	"errors"
	"math/bits"
	"time"
)

const directICMPFECFeedbackSize = 32
const directICMPFECFeedbackBlocks = 512
const directICMPFECTxBlocks = 2048
const directICMPFECFrameExtra = 18

func directICMPNetworkOverheadFor(mode string) int {
	if mode == "fixed" || mode == "adaptive" {
		return directICMPNetworkOverhead + directICMPFECFrameExtra + directICMPFECFeedbackSize
	}
	return directICMPNetworkOverhead
}
func (e *directICMPEngine) fecEnabled() bool {
	return e.config.FECMode == "fixed" || e.config.FECMode == "adaptive"
}
func (e *directICMPEngine) NetworkOverhead() int {
	return directICMPNetworkOverheadFor(e.config.FECMode)
}
func (e *directICMPEngine) MaxWireSize() int { return e.config.MTU + e.NetworkOverhead() - 28 }
func (e *directICMPEngine) protocolVersion() string {
	if e.fecEnabled() {
		return "v2"
	}
	return "v1"
}
func (e *directICMPEngine) wireMagic() string {
	if e.fecEnabled() {
		return "GDL2"
	}
	return "GDL1"
}
func (e *directICMPEngine) handshakePayload() []byte {
	if e.fecEnabled() {
		return []byte("UNUNKNOWNTUN-L3-v002")
	}
	return []byte("UNUNKNOWNTUN-L3-v001")
}
func (e *directICMPEngine) header(kind, direction byte, id [16]byte, nonce uint64) []byte {
	b := directICMPHeader(kind, direction, id, nonce)
	copy(b, e.wireMagic())
	return b
}

type directICMPFECTxBlock struct {
	first, last   time.Time
	sent, sampled uint8
}
type directICMPFECRxBlock struct {
	first, lastReport            time.Time
	source, recovered, delivered uint8
}
type directICMPFECTxPending struct {
	block  uint64
	index  int
	repair bool
}
type directICMPFECSession struct {
	encoder                                                                               *directICMPFECEncoder
	decoder                                                                               *directICMPFECDecoder
	repairs                                                                               [][]byte
	tx                                                                                    map[uint64]*directICMPFECTxBlock
	rx                                                                                    map[uint64]*directICMPFECRxBlock
	pending                                                                               map[uint64]directICMPFECTxPending
	rxHigh                                                                                uint64
	sendCredit                                                                            int
	percent, burst, remoteBurst                                                           int
	samples, lost                                                                         uint64
	lastControl, sampleStart, lastPrune, lastDecrease, pressureUntil, remotePressureUntil time.Time
	healthy                                                                               int
	rtt, peerRTT, baseRTT                                                                 time.Duration
}

func newDirectICMPFECSession(c directICMPEngineConfig, now time.Time) (*directICMPFECSession, error) {
	percent := c.FECPercent
	if c.FECMode == "adaptive" {
		percent = 0
	}
	encoder, err := newDirectICMPFECEncoder(c.MTU, percent, c.FECBlock)
	if err != nil {
		return nil, err
	}
	decoder, err := newDirectICMPFECDecoder(c.MTU, 6*time.Second, directICMPFECMaxBlocks)
	if err != nil {
		return nil, err
	}
	return &directICMPFECSession{encoder: encoder, decoder: decoder, tx: make(map[uint64]*directICMPFECTxBlock), rx: make(map[uint64]*directICMPFECRxBlock), pending: make(map[uint64]directICMPFECTxPending), percent: percent, burst: directICMPBurst, remoteBurst: directICMPBurst, lastControl: now, sampleStart: now}, nil
}
func (f *directICMPFECSession) settle() time.Duration {
	rtt := f.rtt
	if f.peerRTT > rtt {
		rtt = f.peerRTT
	}
	d := 4 * rtt
	if d < 250*time.Millisecond {
		d = 250 * time.Millisecond
	}
	if d > 2*time.Second {
		d = 2 * time.Second
	}
	return d
}
func (f *directICMPFECSession) pressure(now time.Time) bool {
	return now.Before(f.pressureUntil) || now.Before(f.remotePressureUntil)
}

// ObserveRTT accepts only a response to an outstanding, authenticated Echo. It
// is not called for kernel-generated reflections or invalid packets.
func (e *directICMPEngine) ObserveRTT(d time.Duration) {
	if e.active == nil || e.active.fec == nil || d <= 0 || d > e.config.DeadAfter {
		return
	}
	f := e.active.fec
	if f.rtt == 0 {
		f.rtt = d
	} else {
		f.rtt = (7*f.rtt + d) / 8
	}
	if f.baseRTT == 0 || d < f.baseRTT {
		f.baseRTT = d
	}
	// A persistent queueing delay is a congestion signal, not a FEC request.
	threshold := f.baseRTT*2 + 20*time.Millisecond
	if f.rtt > threshold {
		f.pressureUntil = e.lastNow.Add(2 * time.Second)
	}
}

// TransmitResult must be called exactly once after each runtime send attempt,
// including attempts rejected locally by the bounded Echo-credit tracker.
func (e *directICMPEngine) TransmitResult(wire []byte, success bool, now time.Time) {
	if success {
		e.stats.WireSuccessful++
	} else {
		e.stats.LocalSendFailures++
	}
	if !e.fecEnabled() || len(wire) < 32 || wire[4] != directICMPPacket {
		return
	}
	var s *directICMPSession
	for _, c := range []*directICMPSession{e.active, e.previous} {
		if c != nil && string(c.id[:]) == string(wire[8:24]) {
			s = c
			break
		}
	}
	if s == nil && e.pending != nil && e.pending.session != nil && string(e.pending.id[:]) == string(wire[8:24]) {
		s = e.pending.session
	}
	if s == nil || s.fec == nil {
		return
	}
	f := s.fec
	nonce := binary.BigEndian.Uint64(wire[24:32])
	p, ok := f.pending[nonce]
	delete(f.pending, nonce)
	if !success {
		f.pressureUntil = now.Add(time.Second)
		return
	}
	if !ok || p.block == 0 {
		return
	}
	if p.repair {
		e.stats.FECRepairPackets++
		return
	}
	e.stats.FECSourcePackets++
	f.sendCredit += f.percent
	if f.sendCredit > 400 {
		f.sendCredit = 400
	}
	b := f.tx[p.block]
	if b == nil {
		return
	}
	b.sent |= 1 << p.index
	b.last = now
}
func (e *directICMPEngine) updateFEC(s *directICMPSession, now time.Time) {
	f := s.fec
	if f == nil {
		return
	}
	f.decoder.Expire(now)
	if f.lastPrune.IsZero() || now.Sub(f.lastPrune) >= 100*time.Millisecond {
		f.lastPrune = now
		for id, b := range f.tx {
			if now.Sub(b.last) > 6*time.Second {
				e.stats.FECFeedbackExpired += uint64(bits.OnesCount8(b.sent &^ b.sampled))
				delete(f.tx, id)
			}
		}
		for id, b := range f.rx {
			if now.Sub(b.first) > 6*time.Second {
				delete(f.rx, id)
			}
		}
	}
	queuePressure := len(e.queue) > directICMPQueueLimit*3/4
	if now.Sub(f.lastControl) >= time.Second {
		pressure := f.pressure(now)
		if pressure {
			f.burst /= 2
			if f.burst < 1 {
				f.burst = 1
			}
			f.healthy = 0
		} else if f.burst < directICMPBurst {
			f.burst++
		}
		if e.config.FECMode == "adaptive" {
			if pressure || queuePressure {
				f.percent = 0
				f.sendCredit = 0
				f.repairs = nil
				f.healthy = 0
			} else if f.samples >= 32 {
				// Target 1.5 times measured deadline loss, rounded up to 5 percent. This
				// bounded heuristic is deliberately conservative and not a bandwidth probe.
				target := int((f.lost*150 + f.samples - 1) / f.samples)
				target = ((target + 4) / 5) * 5
				if target > e.config.FECMaxPercent {
					target = e.config.FECMaxPercent
				}
				if target > f.percent {
					f.percent += 5
					if f.percent > target {
						f.percent = target
					}
					f.healthy = 0
				} else if target < f.percent {
					f.healthy++
					if f.healthy >= 3 {
						f.percent -= 5
						if f.percent < target {
							f.percent = target
						}
						f.healthy = 0
					}
				} else {
					f.healthy = 0
				}
			}
			_ = f.encoder.SetPercent(f.percent)
		}
		if f.samples >= 32 || now.Sub(f.sampleStart) >= 10*time.Second {
			f.samples = 0
			f.lost = 0
			f.sampleStart = now
		}
		f.lastControl = now
	}
	repairs, err := f.encoder.Flush(now)
	if err == nil {
		f.repairs = append(f.repairs, repairs...)
	}
	if len(f.pending) == 0 && f.sendCredit < 100 {
		f.repairs = nil
	}
	// Codec generates at most four repairs per closed block; this queue is also
	// bounded independently of sender demand and is drained before new sources.
	if len(f.repairs) > 32 {
		e.stats.Dropped += uint64(len(f.repairs) - 32)
		f.repairs = f.repairs[:32]
	}
}
func (f *directICMPFECSession) feedback(now time.Time) []byte {
	out := make([]byte, directICMPFECFeedbackSize)
	out[10] = byte(f.burst)
	if now.Before(f.pressureUntil) {
		out[11] = 1
	}
	binary.BigEndian.PutUint64(out[12:20], f.rxHigh)
	binary.BigEndian.PutUint32(out[20:24], uint32(f.rtt/time.Millisecond))
	var chosen uint64
	var oldest time.Time
	for id, b := range f.rx {
		if now.Sub(b.first) < f.settle() {
			continue
		}
		if chosen == 0 || b.lastReport.Before(oldest) || (b.lastReport.Equal(oldest) && id < chosen) {
			chosen = id
			oldest = b.lastReport
		}
	}
	if chosen != 0 {
		b := f.rx[chosen]
		binary.BigEndian.PutUint64(out[:8], chosen)
		out[8] = b.source
		out[9] = b.recovered
		out[24] = b.delivered
		b.lastReport = now
	}
	return out
}
func validateDirectICMPFECFeedback(m []byte) bool {
	if len(m) != 32 || m[10] < 1 || m[10] > directICMPBurst || m[11] > 1 {
		return false
	}
	id := binary.BigEndian.Uint64(m[:8])
	high := binary.BigEndian.Uint64(m[12:20])
	if id > high || high >= directICMPMaxNonce || (id == 0 && (m[8] != 0 || m[9] != 0 || m[24] != 0)) {
		return false
	}
	if binary.BigEndian.Uint32(m[20:24]) > 600000 {
		return false
	}
	if m[24]&^(m[8]|m[9]) != 0 {
		return false
	}
	for _, v := range m[25:] {
		if v != 0 {
			return false
		}
	}
	return true
}
func (e *directICMPEngine) acceptFeedback(s *directICMPSession, m []byte, now time.Time, newest bool) {
	f := s.fec
	if newest {
		f.remoteBurst = int(m[10])
		f.peerRTT = time.Duration(binary.BigEndian.Uint32(m[20:24])) * time.Millisecond
		if m[11] == 1 {
			f.remotePressureUntil = now.Add(time.Second)
		}
	}
	id := binary.BigEndian.Uint64(m[:8])
	if id == 0 {
		return
	}
	b := f.tx[id]
	if b == nil || now.Sub(b.last) < f.settle() {
		return
	}
	pending := b.sent &^ b.sampled
	if pending == 0 {
		return
	}
	n := uint64(bits.OnesCount8(pending))
	lost := uint64(bits.OnesCount8(pending &^ m[8]))
	residual := uint64(bits.OnesCount8(pending &^ m[24]))
	b.sampled |= pending
	f.samples += n
	f.lost += lost
	e.stats.FECRawSamples += n
	e.stats.FECRawLost += lost
	e.stats.FECResidualLost += residual
	e.stats.FECFeedbackReports++
}
func (e *directICMPEngine) observeSource(s *directICMPSession, frame []byte, now time.Time) {
	info, err := directICMPFECFrameMetadata(frame)
	if err != nil {
		return
	}
	f := s.fec
	// Fill only bounded interior holes proven by a later authenticated block.
	// History displaced before a report remains unknown; it is never called loss.
	if info.Block > f.rxHigh {
		low := f.rxHigh + 1
		if info.Block-low >= directICMPFECFeedbackBlocks {
			low = info.Block - directICMPFECFeedbackBlocks + 1
		}
		for id := low; id <= info.Block; id++ {
			if _, ok := f.rx[id]; !ok {
				f.rx[id] = &directICMPFECRxBlock{first: now}
			}
		}
		f.rxHigh = info.Block
	}
	if f.rxHigh-info.Block >= directICMPFECFeedbackBlocks {
		return
	}
	b := f.rx[info.Block]
	if b == nil {
		b = &directICMPFECRxBlock{first: now}
		f.rx[info.Block] = b
	}
	if !info.Repair {
		b.source |= 1 << info.Index
	}
	if source, recovered, _, ok := f.decoder.BlockMasks(info.Block); ok {
		b.source |= source
		b.recovered |= recovered
		b.delivered |= source | recovered
	}
	for id := range f.rx {
		if f.rxHigh-id >= directICMPFECFeedbackBlocks {
			delete(f.rx, id)
		}
	}
}
func (e *directICMPEngine) sealFEC(s *directICMPSession, op byte, inner []byte) ([]byte, error) {
	f := s.fec
	e.updateFEC(s, e.lastNow)
	var frame []byte
	var err error
	if op == directICMPData {
		if len(inner) > 0 {
			var repairs [][]byte
			frame, repairs, err = f.encoder.Encode(inner, e.lastNow)
			if err != nil {
				return nil, err
			}
			f.repairs = append(f.repairs, repairs...)
		} else if len(f.repairs) > 0 && f.sendCredit >= 100 {
			f.sendCredit -= 100
			frame = f.repairs[0]
			f.repairs[0] = nil
			f.repairs = f.repairs[1:]
		}
	}
	plain := make([]byte, e.config.MTU+directICMPControlSize+directICMPFECFrameExtra+directICMPFECFeedbackSize)
	plain[0] = op
	if len(e.queue) > 0 || len(f.repairs) > 0 {
		plain[1] = 1
	}
	binary.BigEndian.PutUint16(plain[2:4], uint16(len(frame)))
	copy(plain[4:36], f.feedback(e.lastNow))
	copy(plain[36:], frame)
	header := e.header(directICMPPacket, e.direction(), s.id, s.nonce)
	if len(f.pending) >= directICMPQueueLimit {
		return nil, errors.New("Direct ICMP send-result callbacks missing")
	}
	if len(frame) > 0 {
		info, _ := directICMPFECFrameMetadata(frame)
		f.pending[s.nonce] = directICMPFECTxPending{block: info.Block, index: info.Index, repair: info.Repair}
		if !info.Repair {
			if _, ok := f.tx[info.Block]; !ok {
				if len(f.tx) >= directICMPFECTxBlocks {
					var min uint64 = ^uint64(0)
					for id := range f.tx {
						if id < min {
							min = id
						}
					}
					b := f.tx[min]
					e.stats.FECFeedbackExpired += uint64(bits.OnesCount8(b.sent &^ b.sampled))
					delete(f.tx, min)
				}
				f.tx[info.Block] = &directICMPFECTxBlock{first: e.lastNow, last: e.lastNow}
			}
		}
	}
	out := s.tx.Encrypt(header, s.nonce, header, plain)
	s.nonce++
	e.stats.Sent++
	return out, nil
}
func (e *directICMPEngine) receiveFEC(s *directICMPSession, nonce uint64, plain []byte, now time.Time) ([][]byte, [][]byte, error) {
	n := int(binary.BigEndian.Uint16(plain[2:4]))
	op := plain[0]
	if plain[1] > 1 || n > e.config.MTU+directICMPFECFrameExtra || (op != directICMPData && op != directICMPConfirm && op != directICMPAck) || ((op == directICMPConfirm || op == directICMPAck) && n != 0) || !validateDirectICMPFECFeedback(plain[4:36]) {
		return e.reject(errDirectICMPInvalid)
	}
	for _, b := range plain[36+n:] {
		if b != 0 {
			return e.reject(errDirectICMPInvalid)
		}
	}
	if (e.config.Initiator && op == directICMPConfirm) || (!e.config.Initiator && op == directICMPAck) || (!s.confirmed && ((e.config.Initiator && op != directICMPAck) || (!e.config.Initiator && op != directICMPConfirm))) {
		return e.reject(errDirectICMPInvalid)
	}
	var inner [][]byte
	if n > 0 {
		var err error
		before := s.fec.decoder.Stats()
		inner, err = s.fec.decoder.Decode(plain[36:36+n], now)
		if err != nil {
			return e.reject(errDirectICMPInvalid)
		}
		e.stats.FECRecovered += s.fec.decoder.Stats().Recovered - before.Recovered
		e.observeSource(s, plain[36:36+n], now)
	}
	s.replay.mark(nonce)
	s.lastReceive = now
	e.stats.Received++
	if !s.confirmed {
		e.activate(s, now)
	}
	newest := !s.remoteControlSeen || nonce > s.remoteControlNonce
	e.acceptFeedback(s, plain[4:36], now, newest)
	if newest {
		s.remoteControlSeen = true
		s.remoteControlNonce = nonce
		s.remoteMore = plain[1] != 0
	}
	if len(inner) > 0 {
		s.followupCredits = 2
	}
	if e.config.Initiator {
		return nil, inner, nil
	}
	responseOp := directICMPData
	var data []byte
	e.updateFEC(s, now)
	if op == directICMPConfirm {
		responseOp = directICMPAck
	} else if len(s.fec.repairs) == 0 {
		data = e.pop()
	}
	response, err := e.seal(s, responseOp, data)
	if err != nil {
		return nil, inner, err
	}
	return [][]byte{response}, inner, nil
}
