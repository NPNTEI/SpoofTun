package main

import (
	"bytes"
	"encoding/binary"
	"testing"
	"time"
)

func directFECPair(t *testing.T, mode string, percent int) (*directICMPEngine, *directICMPEngine, time.Time) {
	t.Helper()
	now := time.Unix(1700000000, 0)
	c := directICMPEngineConfig{Initiator: true, MTU: 1200, PollInterval: 20 * time.Millisecond, DeadAfter: 3 * time.Second, RekeyAfter: 10 * time.Second, FECMode: mode, FECPercent: percent, FECMaxPercent: 25, FECBlock: 20 * time.Millisecond}
	for i := range c.Key {
		c.Key[i] = byte(i + 1)
	}
	a, err := newDirectICMPEngine(c, now)
	if err != nil {
		t.Fatal(err)
	}
	c.Initiator = false
	b, err := newDirectICMPEngine(c, now)
	if err != nil {
		t.Fatal(err)
	}
	directFECDeliver(t, a, b, a.Tick(now), now, nil, nil)
	if !a.Connected(now) || !b.Connected(now) {
		t.Fatal("handshake")
	}
	return a, b, now
}

type fecTestDrop func(*directICMPEngine, []byte) (networkDrop, localFail bool)

func directFECDeliver(t *testing.T, a, b *directICMPEngine, packets [][]byte, now time.Time, up, down fecTestDrop) (toA, toB [][]byte) {
	t.Helper()
	for round := 0; len(packets) > 0; round++ {
		if round > 8 {
			t.Fatal("amplification loop")
		}
		var replies [][]byte
		for _, p := range packets {
			drop, fail := false, false
			if up != nil {
				drop, fail = up(a, p)
			}
			a.TransmitResult(p, !fail, now)
			if drop || fail {
				continue
			}
			out, inner, err := b.Receive(p, now)
			if err != nil {
				t.Fatal(err)
			}
			if len(out) > 1 {
				t.Fatal("amplification")
			}
			replies = append(replies, out...)
			toB = append(toB, inner...)
		}
		packets = nil
		for _, p := range replies {
			drop, fail := false, false
			if down != nil {
				drop, fail = down(b, p)
			}
			b.TransmitResult(p, !fail, now)
			if drop || fail {
				continue
			}
			out, inner, err := a.Receive(p, now)
			if err != nil {
				t.Fatal(err)
			}
			packets = append(packets, out...)
			toA = append(toA, inner...)
		}
	}
	return
}
func fecTestInfo(e *directICMPEngine, p []byte) (directICMPFECTxPending, bool) {
	if len(p) < 32 || p[4] != directICMPPacket || e.active == nil || e.active.fec == nil {
		return directICMPFECTxPending{}, false
	}
	info, ok := e.active.fec.pending[binary.BigEndian.Uint64(p[24:32])]
	return info, ok
}
func TestDirectICMPFECWireModes(t *testing.T) {
	for _, mode := range []string{"fixed", "adaptive"} {
		a, b, now := directFECPair(t, mode, 20)
		if a.MaxWireSize() != 1302 || a.NetworkOverhead() != 130 {
			t.Fatalf("wire bounds %d %d", a.MaxWireSize(), a.NetworkOverhead())
		}
		_ = a.Queue(bytes.Repeat([]byte{77}, 1200))
		now = now.Add(20 * time.Millisecond)
		out := a.Tick(now)
		if string(out[0][:4]) != "GDL2" || bytes.Contains(out[0], bytes.Repeat([]byte{77}, 20)) {
			t.Fatal("wire plaintext/version")
		}
		_, got := directFECDeliver(t, a, b, out, now, nil, nil)
		if len(got) != 1 || len(got[0]) != 1200 {
			t.Fatal("MTU roundtrip")
		}
	}
	a, b, now := directEnginePair(t)
	b.config.FECMode = "adaptive"
	if _, _, err := b.Receive(a.Tick(now)[0], now); err == nil {
		t.Fatal("legacy accepted byv2")
	}
	a, b, now = directEnginePair(t)
	a.config.FECMode = "adaptive"
	a.pending = nil
	_ = a.begin(now)
	if _, _, err := b.Receive(a.Tick(now)[0], now); err == nil {
		t.Fatal("v2 accepted bylegacy")
	}
}
func TestDirectICMPFECFixedRecoversAndReportsRawLoss(t *testing.T) {
	a, b, now := directFECPair(t, "fixed", 25)
	drop := func(e *directICMPEngine, p []byte) (bool, bool) {
		i, ok := fecTestInfo(e, p)
		return ok && !i.repair && i.block == 1 && i.index == 2, false
	}
	for i := 0; i < 8; i++ {
		_ = a.Queue([]byte{byte(i + 1), 42})
	}
	var got [][]byte
	for tick := 0; tick < 100; tick++ {
		now = now.Add(20 * time.Millisecond)
		_, r := directFECDeliver(t, a, b, a.Tick(now), now, drop, nil)
		got = append(got, r...)
	}
	if len(got) != 8 {
		t.Fatalf("recovery delivered=%d stats=%+v", len(got), b.Stats())
	}
	seen := map[byte]bool{}
	for _, p := range got {
		if seen[p[0]] {
			t.Fatal("duplicate")
		}
		seen[p[0]] = true
	}
	if b.Stats().FECRecovered != 1 || a.Stats().FECRawLost != 1 || a.Stats().FECResidualLost != 0 || a.Stats().FECRawSamples != 8 {
		t.Fatalf("statsa=%+v b=%+v", a.Stats(), b.Stats())
	}
	if a.Stats().FECRepairPackets != 2 {
		t.Fatal("repair budget")
	}
}
func TestDirectICMPFECLocalFailuresNotWANLoss(t *testing.T) {
	a, b, now := directFECPair(t, "fixed", 25)
	fail := func(e *directICMPEngine, p []byte) (bool, bool) {
		i, ok := fecTestInfo(e, p)
		return false, ok && !i.repair && i.block == 1 && i.index == 2
	}
	for i := 0; i < 8; i++ {
		_ = a.Queue([]byte{byte(i + 1)})
	}
	for tick := 0; tick < 120; tick++ {
		now = now.Add(20 * time.Millisecond)
		directFECDeliver(t, a, b, a.Tick(now), now, fail, nil)
	}
	s := a.Stats()
	if s.LocalSendFailures != 1 || s.FECRawLost != 0 || s.FECRawSamples != 7 {
		t.Fatalf("local failure became loss %+v", s)
	}
}
func TestDirectICMPFECAdaptiveDirectionalLoss(t *testing.T) {
	a, b, now := directFECPair(t, "adaptive", 0)
	drop := func(e *directICMPEngine, p []byte) (bool, bool) {
		i, ok := fecTestInfo(e, p)
		return ok && !i.repair && i.index == 2 && i.block%2 == 0, false
	}
	for tick := 0; tick < 450; tick++ {
		for n := 0; n < 4; n++ {
			_ = a.Queue([]byte{byte(tick), byte(n), 1})
			_ = b.Queue([]byte{byte(tick), byte(n), 2})
		}
		now = now.Add(20 * time.Millisecond)
		directFECDeliver(t, a, b, a.Tick(now), now, drop, nil)
	}
	sa, sb := a.Stats(), b.Stats()
	if sa.FECRawSamples < 100 || sa.FECRawLost == 0 || sa.FECPercent == 0 || sa.FECPercent > 25 || sa.FECRepairPackets == 0 {
		t.Fatalf("adaptive didn't react %+v", sa)
	}
	if sb.FECRawLost != 0 || sb.FECPercent != 0 || sb.FECRepairPackets != 0 {
		t.Fatalf("opposite direction inherited loss %+v", sb)
	}
	if sb.FECRecovered == 0 {
		t.Fatalf("adaptive no recovery %+v", sb)
	}
}
func TestDirectICMPFECMissingFeedbackDoesNotIncreaseParity(t *testing.T) {
	a, b, now := directFECPair(t, "adaptive", 0)
	for tick := 0; tick < 90; tick++ {
		for n := 0; n < 4; n++ {
			_ = a.Queue([]byte{byte(tick), byte(n)})
		}
		now = now.Add(20 * time.Millisecond)
		directFECDeliver(t, a, b, a.Tick(now), now, nil, func(*directICMPEngine, []byte) (bool, bool) { return true, false })
	}
	if a.Stats().FECPercent != 0 || a.Stats().FECRawLost != 0 || a.Stats().FECRepairPackets != 0 {
		t.Fatal("silence classified as measured loss")
	}
}
func TestDirectICMPFECFeedbackAndSendHistoryBounded(t *testing.T) {
	a, b, now := directFECPair(t, "fixed", 25)
	for tick := 0; tick < 1000; tick++ {
		for n := 0; n < 16; n++ {
			_ = a.Queue([]byte{byte(tick), byte(n)})
		}
		now = now.Add(20 * time.Millisecond)
		directFECDeliver(t, a, b, a.Tick(now), now, nil, nil)
	}
	for _, e := range []*directICMPEngine{a, b} {
		f := e.active.fec
		if len(f.tx) > directICMPFECTxBlocks || len(f.rx) > directICMPFECFeedbackBlocks || len(f.pending) > directICMPQueueLimit || len(f.repairs) > 32 {
			t.Fatal("unbounded history")
		}
	}
}
func TestDirectICMPFECCongestionBackoffAndNoPressureEcho(t *testing.T) {
	a, b, now := directFECPair(t, "adaptive", 0)
	a.ObserveRTT(10 * time.Millisecond)
	for i := 0; i < 20; i++ {
		a.ObserveRTT(200 * time.Millisecond)
	}
	now = now.Add(time.Second)
	directFECDeliver(t, a, b, a.Tick(now), now, nil, nil)
	if a.Stats().RateBurst >= 16 {
		t.Fatal("no queueing-delaybackoff")
	}
	f := b.active.fec
	f.remotePressureUntil = now.Add(time.Second)
	f.pressureUntil = time.Time{}
	if f.feedback(now)[11] != 0 {
		t.Fatal("reflected congestion permanently latches")
	}
}

func TestDirectICMPFECPartialLocalFailuresRespectActualWireCap(t *testing.T) {
	a, b, now := directFECPair(t, "fixed", 25)
	fail := func(e *directICMPEngine, p []byte) (bool, bool) {
		i, ok := fecTestInfo(e, p)
		return false, ok && !i.repair && i.index%3 != 0
	}
	for tick := 0; tick < 100; tick++ {
		for n := 0; n < 8; n++ {
			_ = a.Queue([]byte{byte(tick), byte(n)})
		}
		now = now.Add(20 * time.Millisecond)
		directFECDeliver(t, a, b, a.Tick(now), now, fail, nil)
		s := a.Stats()
		if s.FECRepairPackets*100 > s.FECSourcePackets*25 {
			t.Fatalf("actual sends violate cap %+v", s)
		}
	}
	if a.Stats().FECSourcePackets < 10 {
		t.Fatal("unfunded repairs starved source queue")
	}
}
func TestDirectICMPFECAdaptiveLowRateAccumulatesSamples(t *testing.T) {
	a, b, now := directFECPair(t, "adaptive", 0)
	a.config.RekeyAfter = time.Hour
	b.config.RekeyAfter = time.Hour
	drop := func(e *directICMPEngine, p []byte) (bool, bool) {
		i, ok := fecTestInfo(e, p)
		return ok && !i.repair && i.block%5 == 0, false
	}
	for tick := 0; tick < 500; tick++ {
		if tick%10 == 0 {
			_ = a.Queue([]byte{byte(tick), 4})
		}
		now = now.Add(20 * time.Millisecond)
		directFECDeliver(t, a, b, a.Tick(now), now, drop, nil)
	}
	if a.Stats().FECRawSamples < 32 || a.Stats().FECPercent == 0 {
		t.Fatalf("lowrate never adapts %+v", a.Stats())
	}
}
func TestDirectICMPFECEntireInteriorBlockLost(t *testing.T) {
	a, b, now := directFECPair(t, "fixed", 0)
	drop := func(e *directICMPEngine, p []byte) (bool, bool) {
		i, ok := fecTestInfo(e, p)
		return ok && !i.repair && i.block == 2, false
	}
	for tick := 0; tick < 100; tick++ {
		if tick < 3 {
			for n := 0; n < 8; n++ {
				_ = a.Queue([]byte{byte(tick), byte(n)})
			}
		}
		now = now.Add(20 * time.Millisecond)
		directFECDeliver(t, a, b, a.Tick(now), now, drop, nil)
	}
	if a.Stats().FECRawSamples != 24 || a.Stats().FECRawLost != 8 {
		t.Fatalf("wholeblock not measured %+v", a.Stats())
	}
}
func TestDirectICMPFECReorderBeforeDeadlineIsNotLoss(t *testing.T) {
	a, b, now := directFECPair(t, "fixed", 0)
	for n := 0; n < 8; n++ {
		_ = a.Queue([]byte{byte(n), 2})
	}
	now = now.Add(20 * time.Millisecond)
	out := a.Tick(now)
	held := out[2]
	out = append(out[:2], out[3:]...)
	a.TransmitResult(held, true, now)
	directFECDeliver(t, a, b, out, now, nil, nil)
	now = now.Add(180 * time.Millisecond)
	reply, inner, err := b.Receive(held, now)
	if err != nil || len(inner) != 1 {
		t.Fatal("reorder rejected", err)
	}
	for _, p := range reply {
		b.TransmitResult(p, true, now)
		if _, _, err = a.Receive(p, now); err != nil {
			t.Fatal(err)
		}
	}
	for tick := 0; tick < 60; tick++ {
		now = now.Add(20 * time.Millisecond)
		directFECDeliver(t, a, b, a.Tick(now), now, nil, nil)
	}
	if a.Stats().FECRawSamples != 8 || a.Stats().FECRawLost != 0 {
		t.Fatalf("reordering calledloss %+v", a.Stats())
	}
}
func TestDirectICMPFECMalformedFeedbackDoesNotConsumeReplay(t *testing.T) {
	a, b, now := directFECPair(t, "fixed", 25)
	now = now.Add(20 * time.Millisecond)
	s := b.active
	nonce := s.nonce
	plain := make([]byte, b.MaxWireSize()-directICMPHeaderSize-directICMPTagSize)
	plain[0] = directICMPData
	copy(plain[4:36], s.fec.feedback(now))
	plain[14] = 0 // invalid zero burst in feedback
	header := b.header(directICMPPacket, b.direction(), s.id, nonce)
	bad := s.tx.Encrypt(header, nonce, header, plain)
	if _, _, err := a.Receive(bad, now); err == nil {
		t.Fatal("badfeedback accepted")
	}
	good, err := b.seal(s, directICMPData, nil)
	if err != nil {
		t.Fatal(err)
	}
	if _, _, err = a.Receive(good, now); err != nil {
		t.Fatal("invalid consumed replay", err)
	}
}
func TestDirectICMPFECExpiredDecoderCannotEraseFeedback(t *testing.T) {
	a, b, now := directFECPair(t, "fixed", 25)
	for n := 0; n < 8; n++ {
		_ = a.Queue([]byte{byte(n), 2})
	}
	now = now.Add(20 * time.Millisecond)
	out := a.Tick(now)
	directFECDeliver(t, a, b, out, now, nil, nil)
	f := b.active.fec
	original := f.rx[1].source
	f.decoder.Expire(now.Add(7 * time.Second))
	frame, _, err := a.active.fec.encoder.Encode([]byte{42}, now)
	if err != nil {
		t.Fatal(err)
	}
	binary.BigEndian.PutUint64(frame[4:12], 1)
	b.observeSource(b.active, frame, now.Add(7*time.Second))
	if f.rx[1].source != original {
		t.Fatal("expireddecoder erased authenticatedmask")
	}
}

func TestDirectICMPFECBidirectionalRekeyPreservesPacketIdentity(t *testing.T) {
	a, b, now := directFECPair(t, "fixed", 25)
	countsA, countsB := map[uint32]int{}, map[uint32]int{}
	for tick := 0; tick < 650; tick++ {
		if tick%2 == 0 {
			p := make([]byte, 40)
			binary.BigEndian.PutUint32(p, uint32(tick+1))
			_ = a.Queue(p)
			_ = b.Queue(p)
		}
		now = now.Add(20 * time.Millisecond)
		aa, bb := directFECDeliver(t, a, b, a.Tick(now), now, nil, nil)
		for _, p := range aa {
			countsA[binary.BigEndian.Uint32(p)]++
		}
		for _, p := range bb {
			countsB[binary.BigEndian.Uint32(p)]++
		}
	}
	if a.Stats().Rekeys == 0 || b.Stats().Rekeys == 0 {
		t.Fatal("rekey missing")
	}
	if len(countsA) != 325 || len(countsB) != 325 {
		t.Fatalf("rekeylostdata %d/%d", len(countsA), len(countsB))
	}
	for _, counts := range []map[uint32]int{countsA, countsB} {
		for _, n := range counts {
			if n != 1 {
				t.Fatal("duplicate at rekey")
			}
		}
	}
}
func TestDirectICMPFECFeedbackRTTSharedForReorderDeadline(t *testing.T) {
	a, b, now := directFECPair(t, "adaptive", 0)
	a.ObserveRTT(400 * time.Millisecond)
	now = now.Add(260 * time.Millisecond)
	directFECDeliver(t, a, b, a.Tick(now), now, nil, nil)
	if b.active.fec.settle() != 1600*time.Millisecond {
		t.Fatalf("reverse didn't learn authenticated RTT: %v", b.active.fec.settle())
	}
}
func TestDirectICMPFECPressureCancelsBufferedAdaptiveRepair(t *testing.T) {
	a, _, now := directFECPair(t, "adaptive", 0)
	f := a.active.fec
	f.percent = 25
	_ = f.encoder.SetPercent(25)
	f.sendCredit = 400
	f.repairs = [][]byte{{1}, {2}}
	f.pressureUntil = now.Add(2 * time.Second)
	a.updateFEC(a.active, now.Add(time.Second))
	if f.percent != 0 || f.sendCredit != 0 || len(f.repairs) != 0 {
		t.Fatal("pressure retained parity budget")
	}
}

func TestDirectICMPFECProducerQueueDoesNotThrottleSource(t *testing.T) {
	a, _, now := directFECPair(t, "adaptive", 0)
	for i := 0; i < directICMPQueueLimit; i++ {
		_ = a.Queue([]byte{1})
	}
	f := a.active.fec
	f.percent = 25
	_ = f.encoder.SetPercent(25)
	a.updateFEC(a.active, now.Add(time.Second))
	if f.burst != 16 || f.percent != 0 {
		t.Fatalf("producer backlog cut ownrate burst=%d percent=%d", f.burst, f.percent)
	}
	if f.feedback(now)[11] != 0 {
		t.Fatal("producer backlog propagated as WANcongestion")
	}
}
func TestDirectICMPFECSparseHighRTTFeedbackWithinEchoBudget(t *testing.T) {
	a, b, now := directFECPair(t, "adaptive", 0)
	for _, e := range []*directICMPEngine{a, b} {
		e.config.PollInterval = 5 * time.Millisecond
		e.config.FECBlock = 5 * time.Millisecond
		e.config.RekeyAfter = time.Hour
		e.active.fec.encoder.timeout = 5 * time.Millisecond
	}
	a.ObserveRTT(400 * time.Millisecond)
	type event struct {
		due      time.Time
		p        []byte
		response bool
		credit   uint64
	}
	var events []event
	credits := map[uint64]time.Time{}
	var next uint64
	for tick := 0; tick < 1200; tick++ {
		now = now.Add(5 * time.Millisecond)
		for id, expires := range credits {
			if !now.Before(expires) {
				delete(credits, id)
			}
		}
		retained := events[:0]
		var ready []event
		for _, ev := range events {
			if now.Before(ev.due) {
				retained = append(retained, ev)
			} else {
				ready = append(ready, ev)
			}
		}
		events = retained
		for _, ev := range ready {
			if ev.response {
				delete(credits, ev.credit)
				if _, _, err := a.Receive(ev.p, now); err != nil {
					t.Fatal(err)
				}
				a.ObserveRTT(400 * time.Millisecond)
			} else {
				out, _, err := b.Receive(ev.p, now)
				if err != nil {
					t.Fatal(err)
				}
				for _, p := range out {
					b.TransmitResult(p, true, now)
					events = append(events, event{now.Add(200 * time.Millisecond), p, true, ev.credit})
				}
			}
		}
		_ = a.Queue([]byte{byte(tick), 7})
		for _, p := range a.Tick(now) {
			if len(credits) >= 128 {
				a.TransmitResult(p, false, now)
				continue
			}
			next++
			credits[next] = now.Add(1600 * time.Millisecond)
			info, ok := fecTestInfo(a, p)
			drop := ok && !info.repair && info.block%10 == 0
			a.TransmitResult(p, true, now)
			if !drop {
				events = append(events, event{now.Add(200 * time.Millisecond), p, false, next})
			}
		}
	}
	if a.Stats().FECRawSamples < 100 || a.Stats().FECRawLost == 0 || a.Stats().FECRepairPackets == 0 {
		t.Fatalf("WAN RTT feedback starved %+v", a.Stats())
	}
}

func TestDirectICMPFECPacedPartialBlockUplinkRecovery(t *testing.T) {
	a, b, now := directFECPair(t, "fixed", 25)
	drop := func(e *directICMPEngine, p []byte) (bool, bool) {
		i, ok := fecTestInfo(e, p)
		return ok && !i.repair && i.index == 0 && i.block%4 == 0, false
	}
	var delivered int
	for tick := 0; tick < 500; tick++ {
		if tick < 300 && tick%5 != 0 {
			_ = a.Queue([]byte{byte(tick), 42})
		}
		now = now.Add(10 * time.Millisecond)
		_, out := directFECDeliver(t, a, b, a.Tick(now), now, drop, nil)
		delivered += len(out)
	}
	if a.Stats().FECRepairPackets == 0 || b.Stats().FECRecovered == 0 || delivered < 200 {
		t.Fatalf("partial uplink source=%+v receiver=%+v delivered=%d", a.Stats(), b.Stats(), delivered)
	}
}

func TestDirectICMPFECRetiredLateSourceSeparatesRawAndResidualLoss(t *testing.T) {
	a, b, now := directFECPair(t, "fixed", 0)
	for n := 0; n < 8; n++ {
		_ = a.Queue([]byte{byte(n), 2})
	}
	now = now.Add(20 * time.Millisecond)
	out := a.Tick(now)
	held := out[0]
	a.TransmitResult(held, true, now)
	directFECDeliver(t, a, b, out[1:], now, nil, nil)
	f := b.active.fec
	// Simulate a bounded decoder eviction while the longer feedback history is
	// still present. A valid source arrival is observed but is no longer decoded.
	f.decoder.Expire(now.Add(7 * time.Second))
	nonce := binary.BigEndian.Uint64(held[24:32])
	plain, err := b.active.rx.Decrypt(nil, nonce, held[:32], held[32:])
	if err != nil {
		t.Fatal(err)
	}
	frame := plain[36 : 36+int(binary.BigEndian.Uint16(plain[2:4]))]
	inner, err := f.decoder.Decode(frame, now.Add(time.Second))
	if err != nil || len(inner) != 0 {
		t.Fatal("retiredblock unexpectedly delivered")
	}
	b.observeSource(b.active, frame, now.Add(time.Second))
	if f.rx[1].source != 255 || f.rx[1].delivered != 254 {
		t.Fatalf("raw/delivery conflated %+v", f.rx[1])
	}
	a.acceptFeedback(a.active, f.feedback(now.Add(time.Second)), now.Add(time.Second), true)
	if a.Stats().FECRawLost != 0 || a.Stats().FECResidualLost != 1 {
		t.Fatalf("classification %+v", a.Stats())
	}
}
