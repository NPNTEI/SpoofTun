package main

// Port forwarding is part of the ICMP process lifecycle. The origin connects
// through its inner address; the egress connects only to its loopback service.
// No external relay process, NAT redirect or additional firewall rule is used.
import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/netip"
	"sync"
	"time"
)

type DirectICMPPortForward struct {
	Protocol string `json:"protocol"`
	Listen   string `json:"listen"`
	Target   string `json:"target"`
}

func (r *DirectICMPPortForward) UnmarshalJSON(data []byte) error {
	d := json.NewDecoder(bytes.NewReader(data))
	t, err := d.Token()
	if err != nil || t != json.Delim('{') {
		return errors.New("port_forwards entries must be objects")
	}
	values := map[string]string{}
	for d.More() {
		t, err := d.Token()
		if err != nil {
			return err
		}
		key, ok := t.(string)
		if !ok || (key != "protocol" && key != "listen" && key != "target") {
			return errors.New("unknown port_forwards field")
		}
		if _, exists := values[key]; exists {
			return errors.New("duplicate port_forwards field")
		}
		t, err = d.Token()
		value, ok := t.(string)
		if err != nil || !ok || value == "" || len(value) > 64 {
			return errors.New("port_forwards fields require nonempty strings of at most 64 bytes")
		}
		values[key] = value
	}
	if _, err = d.Token(); err != nil {
		return err
	}
	if _, err = d.Token(); err != io.EOF || len(values) != 3 {
		return errors.New("port_forwards requires exactly protocol, listen and target")
	}
	*r = DirectICMPPortForward{values["protocol"], values["listen"], values["target"]}
	return nil
}

func directICMPForwardAddress(s string) (netip.AddrPort, error) {
	a, err := netip.ParseAddrPort(s)
	if err != nil || !a.Addr().Is4() || a.String() != s || a.Port() < 1024 {
		return netip.AddrPort{}, errors.New("require literal canonical IPv4:port with port 1024..65535")
	}
	return a, nil
}

func (c *DirectICMPConfig) validatePortForwards() error {
	if c.ForwardIdleSeconds < 10 || c.ForwardIdleSeconds > 3600 {
		return errors.New("[direct-icmp/config] forward_idle_seconds must be 10..3600")
	}
	if len(c.PortForwards) > 32 {
		return errors.New("[direct-icmp/config] at most 32 TCP/UDP forwarding rules")
	}
	for i, r := range c.PortForwards {
		if r.Protocol != "tcp" && r.Protocol != "udp" {
			return errors.New("[direct-icmp/config] forward protocol must be tcp or udp")
		}
		listen, err := directICMPForwardAddress(r.Listen)
		if err != nil {
			return fmt.Errorf("[direct-icmp/config] forward listen: %w", err)
		}
		target, err := directICMPForwardAddress(r.Target)
		if err != nil {
			return fmt.Errorf("[direct-icmp/config] forward target: %w", err)
		}
		if c.Role == "origin" {
			if target.Addr().String() != c.InnerPeerIP || (listen.Addr().String() != "0.0.0.0" && listen.Addr().String() != "127.0.0.1" && listen.Addr().String() != c.InnerLocalIP) {
				return errors.New("[direct-icmp/config] origin forward must listen on wildcard, loopback or inner_local_ip and target inner_peer_ip")
			}
		} else if c.Role != "egress" || listen.Addr().String() != c.InnerLocalIP || target.Addr().String() != "127.0.0.1" {
			return errors.New("[direct-icmp/config] egress forward must listen on inner_local_ip and target 127.0.0.1")
		}
		for _, old := range c.PortForwards[:i] {
			a, _ := netip.ParseAddrPort(old.Listen)
			if old.Protocol == r.Protocol && a.Port() == listen.Port() && (a.Addr() == listen.Addr() || a.Addr().IsUnspecified() || listen.Addr().IsUnspecified()) {
				return errors.New("[direct-icmp/config] duplicate or overlapping forwarding listeners")
			}
		}
	}
	return nil
}

const directICMPForwardMaxFlows = 1024

// UDP has no delivery acknowledgement. A congested datagram socket must not
// hold the shared listener loop for the full (potentially one hour) idle time.
const directICMPForwardUDPWriteBudget = 250 * time.Millisecond

func directICMPForwardUDPWrite(conn net.Conn, payload []byte, idle time.Duration) error {
	if err := conn.SetWriteDeadline(time.Now().Add(min(idle, directICMPForwardUDPWriteBudget))); err != nil {
		return err
	}
	_, err := conn.Write(payload)
	return err
}

type directICMPForwardRuntime struct {
	ctx     context.Context
	cancel  context.CancelFunc
	idle    time.Duration
	source  net.IP
	mu      sync.Mutex
	closers map[io.Closer]struct{}
	failure error
	wg      sync.WaitGroup
	slots   chan struct{}
}

func startDirectICMPForwards(ctx context.Context, c *DirectICMPConfig) (*directICMPForwardRuntime, error) {
	if err := c.validatePortForwards(); err != nil {
		return nil, err
	}
	var source net.IP
	if c.Role == "origin" {
		source = net.ParseIP(c.InnerLocalIP).To4()
	}
	return startDirectICMPForwardRules(ctx, c.PortForwards, source, time.Duration(c.ForwardIdleSeconds)*time.Second)
}

// The internal constructor permits loopback integration tests without raw
// sockets or TUN privileges; production callers validate role/address policy.
func startDirectICMPForwardRules(ctx context.Context, rules []DirectICMPPortForward, source net.IP, idle time.Duration) (*directICMPForwardRuntime, error) {
	ctx, cancel := context.WithCancel(ctx)
	rt := &directICMPForwardRuntime{ctx: ctx, cancel: cancel, source: source, idle: idle, closers: make(map[io.Closer]struct{}), slots: make(chan struct{}, directICMPForwardMaxFlows)}
	var starts []func()
	for _, rule := range rules {
		rule := rule
		switch rule.Protocol {
		case "tcp":
			addr, err := net.ResolveTCPAddr("tcp4", rule.Listen)
			if err != nil {
				rt.Close()
				return nil, err
			}
			ln, err := net.ListenTCP("tcp4", addr)
			if err != nil {
				rt.Close()
				return nil, fmt.Errorf("[direct-icmp/forward] listen %s %s: %w", rule.Protocol, rule.Listen, err)
			}
			rt.track(ln)
			starts = append(starts, func() { rt.serveTCP(ln, rule.Target) })
		case "udp":
			addr, err := net.ResolveUDPAddr("udp4", rule.Listen)
			if err != nil {
				rt.Close()
				return nil, err
			}
			ln, err := net.ListenUDP("udp4", addr)
			if err != nil {
				rt.Close()
				return nil, fmt.Errorf("[direct-icmp/forward] listen %s %s: %w", rule.Protocol, rule.Listen, err)
			}
			rt.track(ln)
			starts = append(starts, func() { rt.serveUDP(ln, rule.Target) })
		default:
			rt.Close()
			return nil, errors.New("[direct-icmp/forward] unsupported protocol")
		}
	}
	if err := ctx.Err(); err != nil {
		rt.Close()
		return nil, err
	}
	for _, start := range starts {
		rt.wg.Add(1)
		go func() { defer rt.wg.Done(); start() }()
	}
	rt.wg.Add(1)
	go func() { defer rt.wg.Done(); <-ctx.Done(); rt.stop() }()
	return rt, nil
}

func (rt *directICMPForwardRuntime) track(c io.Closer) bool {
	rt.mu.Lock()
	defer rt.mu.Unlock()
	if rt.ctx.Err() != nil {
		c.Close()
		return false
	}
	rt.closers[c] = struct{}{}
	return true
}

func (rt *directICMPForwardRuntime) untrack(c io.Closer) {
	rt.mu.Lock()
	delete(rt.closers, c)
	rt.mu.Unlock()
	c.Close()
}

func (rt *directICMPForwardRuntime) stop() {
	rt.cancel()
	rt.mu.Lock()
	defer rt.mu.Unlock()
	for c := range rt.closers {
		c.Close()
	}
}

func (rt *directICMPForwardRuntime) Close() { rt.stop(); rt.wg.Wait() }

func (rt *directICMPForwardRuntime) Err() error {
	rt.mu.Lock()
	defer rt.mu.Unlock()
	return rt.failure
}

func (rt *directICMPForwardRuntime) fail(err error) {
	rt.mu.Lock()
	if rt.ctx.Err() == nil && rt.failure == nil {
		rt.failure = fmt.Errorf("[direct-icmp/forward] listener failed: %w", err)
	}
	rt.mu.Unlock()
	rt.stop()
}

func (rt *directICMPForwardRuntime) acquire() bool {
	select {
	case rt.slots <- struct{}{}:
		return true
	default:
		return false
	}
}

func (rt *directICMPForwardRuntime) serveTCP(ln *net.TCPListener, target string) {
	for {
		client, err := ln.AcceptTCP()
		if err != nil {
			rt.fail(err)
			return
		}
		if !rt.acquire() {
			client.Close()
			continue
		}
		if !rt.track(client) {
			<-rt.slots
			return
		}
		rt.wg.Add(1)
		go func() {
			defer rt.wg.Done()
			defer func() { <-rt.slots }()
			defer rt.untrack(client)
			dialer := net.Dialer{Timeout: min(rt.idle, 10*time.Second), KeepAlive: 30 * time.Second}
			if rt.source != nil {
				dialer.LocalAddr = &net.TCPAddr{IP: rt.source}
			}
			conn, err := dialer.DialContext(rt.ctx, "tcp4", target)
			if err != nil {
				return
			}
			if !rt.track(conn) {
				return
			}
			defer rt.untrack(conn)
			peer := conn.(*net.TCPConn)
			var deadlineMu sync.Mutex
			touch := func() {
				deadlineMu.Lock()
				defer deadlineMu.Unlock()
				deadline := time.Now().Add(rt.idle)
				client.SetDeadline(deadline)
				peer.SetDeadline(deadline)
			}
			touch()
			copyOne := func(dst, src *net.TCPConn) {
				buf := make([]byte, 32*1024)
				for {
					n, readErr := src.Read(buf)
					if n > 0 {
						touch()
						if _, err := dst.Write(buf[:n]); err != nil {
							client.Close()
							peer.Close()
							return
						}
						touch()
					}
					if readErr != nil {
						if errors.Is(readErr, io.EOF) {
							dst.CloseWrite()
						} else {
							client.Close()
							peer.Close()
						}
						return
					}
				}
			}
			done := make(chan struct{})
			go func() { defer close(done); copyOne(peer, client) }()
			copyOne(client, peer)
			<-done
		}()
	}
}

type directICMPUDPAssociation struct {
	conn   *net.UDPConn
	client *net.UDPAddr
}

func (rt *directICMPForwardRuntime) serveUDP(ln *net.UDPConn, target string) {
	remote, err := net.ResolveUDPAddr("udp4", target)
	if err != nil {
		rt.fail(err)
		return
	}
	var mu sync.Mutex
	var replyMu sync.Mutex
	associations := map[string]*directICMPUDPAssociation{}
	remove := func(key string, a *directICMPUDPAssociation) {
		mu.Lock()
		defer mu.Unlock()
		if associations[key] == a {
			delete(associations, key)
		}
	}
	buf := make([]byte, 65535)
	for {
		n, client, err := ln.ReadFromUDP(buf)
		if err != nil {
			rt.fail(err)
			return
		}
		key := client.String()
		mu.Lock()
		a := associations[key]
		if a == nil && rt.acquire() {
			conn, err := net.DialUDP("udp4", &net.UDPAddr{IP: rt.source}, remote)
			if err != nil {
				<-rt.slots
			} else if !rt.track(conn) {
				<-rt.slots
			} else {
				a = &directICMPUDPAssociation{conn: conn, client: client}
				associations[key] = a
				conn.SetReadDeadline(time.Now().Add(rt.idle))
				rt.wg.Add(1)
				go func(a *directICMPUDPAssociation) {
					defer rt.wg.Done()
					defer func() { <-rt.slots }()
					defer rt.untrack(a.conn)
					defer remove(key, a)
					reply := make([]byte, 65535)
					for {
						n, err := a.conn.Read(reply)
						if err != nil {
							return
						}
						a.conn.SetReadDeadline(time.Now().Add(rt.idle))
						// Only this association's client receives its target's reply.
						// Serialise setting the shared socket's write deadline with
						// its write, so other clients cannot extend a blocked write.
						replyMu.Lock()
						ln.SetWriteDeadline(time.Now().Add(min(rt.idle, directICMPForwardUDPWriteBudget)))
						_, err = ln.WriteToUDP(reply[:n], a.client)
						replyMu.Unlock()
						if err != nil {
							return
						}
					}
				}(a)
			}
		}
		if a != nil {
			a.conn.SetReadDeadline(time.Now().Add(rt.idle))
		}
		mu.Unlock()
		if a != nil {
			if err := directICMPForwardUDPWrite(a.conn, buf[:n], rt.idle); err != nil {
				remove(key, a)
				a.conn.Close()
			}
		}
	}
}
