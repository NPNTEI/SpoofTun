package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"runtime"
	"strings"
	"sync"
	"testing"
	"time"
)

func TestDirectICMPForwardConfig(t *testing.T) {
	c := directRuntimeConfig()
	c.PortForwards = []DirectICMPPortForward{{"tcp", "0.0.0.0:12055", c.InnerPeerIP + ":28082"}, {"udp", "0.0.0.0:12055", c.InnerPeerIP + ":28082"}}
	b, _ := json.Marshal(c)
	got, err := parseDirectICMPConfig(b)
	if err != nil || len(got.PortForwards) != 2 || got.PortForwards[1].Protocol != "udp" || got.ForwardIdleSeconds != 180 {
		t.Fatalf("forward inventory not preserved: %v %v", got, err)
	}
	base := directRuntimeConfig()
	base.ForwardIdleSeconds = 0
	b, _ = json.Marshal(base)
	got, err = parseDirectICMPConfig(b)
	if err != nil || got.ForwardIdleSeconds != 180 {
		t.Fatal("legacy idle default", err)
	}
	for _, bad := range []string{
		`"forward_idle_seconds":0`, `"forward_idle_seconds":9`, `"forward_idle_seconds":3601`, `"port_forwards":null`,
		`"port_forwards":[null]`, `"port_forwards":[{}]`,
		`"port_forwards":[{"protocol":"tcp","listen":"0.0.0.0:12055","target":"10.238.0.2:28082","protocol":"udp"}]`,
		`"port_forwards":[{"protocol":"tcp","listen":"0.0.0.0:12055","target":"10.238.0.2:28082","extra":1}]`,
		`"port_forwards":[{"protocol":"tcp","listen":null,"target":"10.238.0.2:28082"}]`,
	} {
		input := strings.TrimSuffix(string(b), "}") + "," + bad + "}"
		if _, err := parseDirectICMPConfig([]byte(input)); err == nil {
			t.Errorf("accepted %s", bad)
		}
	}
	for name, change := range map[string]func(*DirectICMPConfig){
		"hostname":      func(c *DirectICMPConfig) { c.PortForwards[0].Listen = "localhost:12055" },
		"ipv6":          func(c *DirectICMPConfig) { c.PortForwards[0].Listen = "[::1]:12055" },
		"low_port":      func(c *DirectICMPConfig) { c.PortForwards[0].Listen = "0.0.0.0:443" },
		"zero_port":     func(c *DirectICMPConfig) { c.PortForwards[0].Target = c.InnerPeerIP + ":0" },
		"leading_zero":  func(c *DirectICMPConfig) { c.PortForwards[0].Listen = "0.0.0.0:012055" },
		"public_listen": func(c *DirectICMPConfig) { c.PortForwards[0].Listen = "192.0.2.1:12055" },
		"public_target": func(c *DirectICMPConfig) { c.PortForwards[0].Target = "192.0.2.2:28082" },
		"bad_protocol":  func(c *DirectICMPConfig) { c.PortForwards[0].Protocol = "tcp+udp" },
		"collision": func(c *DirectICMPConfig) {
			c.PortForwards = append(c.PortForwards, DirectICMPPortForward{"tcp", "127.0.0.1:12055", c.InnerPeerIP + ":28082"})
		},
		"too_many": func(c *DirectICMPConfig) { c.PortForwards = make([]DirectICMPPortForward, 33) },
	} {
		t.Run(name, func(t *testing.T) {
			c := directRuntimeConfig()
			c.PortForwards = []DirectICMPPortForward{{"tcp", "0.0.0.0:12055", c.InnerPeerIP + ":28082"}}
			change(c)
			if c.validate() == nil {
				t.Fatal("accepted invalid forward")
			}
		})
	}
	c.Role = "egress"
	c.PortForwards = []DirectICMPPortForward{{"tcp", c.InnerLocalIP + ":28082", "127.0.0.1:18082"}}
	if err := c.validate(); err != nil {
		t.Fatal(err)
	}
	c.PortForwards[0].Listen = "0.0.0.0:28082"
	if c.validate() == nil {
		t.Fatal("egress must not expose backend relay publicly")
	}
	c.PortForwards[0].Listen = c.InnerLocalIP + ":28082"
	c.PortForwards[0].Target = "10.238.0.99:18082"
	if c.validate() == nil {
		t.Fatal("egress must target loopback")
	}
}

func forwardTestAddress(t *testing.T, rt *directICMPForwardRuntime, protocol string) string {
	t.Helper()
	rt.mu.Lock()
	defer rt.mu.Unlock()
	for c := range rt.closers {
		if ln, ok := c.(*net.TCPListener); ok && protocol == "tcp" {
			return ln.Addr().String()
		}
		if ln, ok := c.(*net.UDPConn); ok && protocol == "udp" {
			return ln.LocalAddr().String()
		}
	}
	t.Fatal("listener missing")
	return ""
}

func forwardTestWait(t *testing.T, fn func() bool) {
	t.Helper()
	until := time.Now().Add(3 * time.Second)
	for !fn() {
		if time.Now().After(until) {
			t.Fatal("timed out waiting for forward state")
		}
		time.Sleep(5 * time.Millisecond)
	}
}

func TestDirectICMPForwardTCPHalfCloseConcurrent(t *testing.T) {
	backend, err := net.Listen("tcp4", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer backend.Close()
	var handlers sync.WaitGroup
	accepted := make(chan struct{})
	go func() {
		defer close(accepted)
		for {
			conn, err := backend.Accept()
			if err != nil {
				return
			}
			handlers.Add(1)
			go func() {
				defer handlers.Done()
				defer conn.Close()
				conn.SetDeadline(time.Now().Add(5 * time.Second))
				data, err := io.ReadAll(conn)
				if err == nil {
					conn.Write(append([]byte("reply:"), data...))
				}
			}()
		}
	}()
	rt, err := startDirectICMPForwardRules(context.Background(), []DirectICMPPortForward{{"tcp", "127.0.0.1:0", backend.Addr().String()}}, net.ParseIP("127.0.0.1"), 3*time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer rt.Close()
	address := forwardTestAddress(t, rt, "tcp")
	var clients sync.WaitGroup
	for i := 0; i < 8; i++ {
		clients.Add(1)
		go func(i int) {
			defer clients.Done()
			conn, err := net.DialTimeout("tcp4", address, time.Second)
			if err != nil {
				t.Error(err)
				return
			}
			defer conn.Close()
			conn.SetDeadline(time.Now().Add(5 * time.Second))
			payload := bytes.Repeat([]byte(fmt.Sprintf("client-%d\x00", i)), 32768)
			if _, err := conn.Write(payload); err != nil {
				t.Error(err)
				return
			}
			if err := conn.(*net.TCPConn).CloseWrite(); err != nil {
				t.Error(err)
				return
			}
			got, err := io.ReadAll(conn)
			if err != nil || !bytes.Equal(got, append([]byte("reply:"), payload...)) {
				t.Errorf("halfclose roundtrip failed: size=%d err=%v", len(got), err)
			}
		}(i)
	}
	clients.Wait()
	backend.Close()
	<-accepted
	handlers.Wait()
	forwardTestWait(t, func() bool { return len(rt.slots) == 0 })
}

func TestDirectICMPForwardTCPIdleAndCancel(t *testing.T) {
	backend, _ := net.Listen("tcp4", "127.0.0.1:0")
	defer backend.Close()
	server := make(chan net.Conn, 2)
	go func() {
		for {
			conn, err := backend.Accept()
			if err != nil {
				return
			}
			server <- conn
		}
	}()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	rt, err := startDirectICMPForwardRules(ctx, []DirectICMPPortForward{{"tcp", "127.0.0.1:0", backend.Addr().String()}}, nil, 120*time.Millisecond)
	if err != nil {
		t.Fatal(err)
	}
	defer rt.Close()
	address := forwardTestAddress(t, rt, "tcp")
	for i := 0; i < 2; i++ {
		client, err := net.Dial("tcp4", address)
		if err != nil {
			t.Fatal(err)
		}
		var peer net.Conn
		select {
		case peer = <-server:
		case <-time.After(2 * time.Second):
			t.Fatal("backend not reached")
		}
		if i == 1 {
			cancel()
		}
		client.SetReadDeadline(time.Now().Add(time.Second))
		_, err = client.Read(make([]byte, 1))
		client.Close()
		peer.Close()
		if err == nil {
			t.Fatal("idle/cancel did not close flow")
		}
		if ne, ok := err.(net.Error); ok && ne.Timeout() {
			t.Fatal("flow survived until client deadline")
		}
		forwardTestWait(t, func() bool { return len(rt.slots) == 0 })
	}
	if err := rt.Err(); err != nil {
		t.Fatal("normal cancel reported failure", err)
	}
}

func TestDirectICMPForwardUDPMultipleClientsIdleAndCancel(t *testing.T) {
	backend, err := net.ListenUDP("udp4", &net.UDPAddr{IP: net.ParseIP("127.0.0.1")})
	if err != nil {
		t.Fatal(err)
	}
	defer backend.Close()
	done := make(chan struct{})
	go func() {
		defer close(done)
		buf := make([]byte, 65535)
		for {
			n, a, err := backend.ReadFromUDP(buf)
			if err != nil {
				return
			}
			backend.WriteToUDP(buf[:n], a)
		}
	}()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	rt, err := startDirectICMPForwardRules(ctx, []DirectICMPPortForward{{"udp", "127.0.0.1:0", backend.LocalAddr().String()}}, net.ParseIP("127.0.0.1"), 200*time.Millisecond)
	if err != nil {
		t.Fatal(err)
	}
	defer rt.Close()
	addr, _ := net.ResolveUDPAddr("udp4", forwardTestAddress(t, rt, "udp"))
	var clients sync.WaitGroup
	for i := 0; i < 8; i++ {
		clients.Add(1)
		go func(i int) {
			defer clients.Done()
			conn, err := net.DialUDP("udp4", nil, addr)
			if err != nil {
				t.Error(err)
				return
			}
			defer conn.Close()
			payloads := [][]byte{nil, []byte(fmt.Sprintf("client-%d\x00\xff", i)), bytes.Repeat([]byte{byte(i)}, 8192)}
			for _, payload := range payloads {
				conn.SetDeadline(time.Now().Add(2 * time.Second))
				if _, err := conn.Write(payload); err != nil {
					t.Error(err)
					return
				}
				buf := make([]byte, 65535)
				n, err := conn.Read(buf)
				if err != nil || !bytes.Equal(buf[:n], payload) {
					t.Errorf("UDP client %d payload %d bytes failed: %v", i, len(payload), err)
				}
			}
		}(i)
	}
	clients.Wait()
	forwardTestWait(t, func() bool { return len(rt.slots) == 0 })
	// Expiry must release capacity and allow a fresh association.
	client, _ := net.DialUDP("udp4", nil, addr)
	defer client.Close()
	client.SetDeadline(time.Now().Add(time.Second))
	client.Write([]byte("after-idle"))
	buf := make([]byte, 32)
	n, err := client.Read(buf)
	if err != nil || string(buf[:n]) != "after-idle" {
		t.Fatal("association not recreated", err)
	}
	// Activity extends an idle deadline; it is not an absolute flow lifetime.
	for i := 0; i < 4; i++ {
		time.Sleep(80 * time.Millisecond)
		client.SetDeadline(time.Now().Add(time.Second))
		client.Write([]byte("still-active"))
		n, err = client.Read(buf)
		if err != nil || string(buf[:n]) != "still-active" {
			t.Fatal("active UDP association expired", err)
		}
	}
	forwardTestWait(t, func() bool { return len(rt.slots) == 0 })
	client.SetDeadline(time.Now().Add(time.Second))
	client.Write([]byte("same-client-new-flow"))
	n, err = client.Read(buf)
	if err != nil || string(buf[:n]) != "same-client-new-flow" {
		t.Fatal("expired association not recreated for same client", err)
	}
	cancel()
	rt.Close()
	if len(rt.slots) != 0 || rt.Err() != nil {
		t.Fatal("cancel leaked UDP flow or reported fatal error")
	}
	backend.Close()
	<-done
}

func TestDirectICMPForwardUDPLargeDatagram(t *testing.T) {
	if runtime.GOOS != "linux" {
		t.Skip("60000-byte UDP exceeds the default datagram limit on macOS")
	}
	// One outstanding large datagram verifies preservation without requiring
	// a small default kernel receive queue to absorb an eight-client 480KB burst.
	// There are deliberately no retries: delivery and content must both match.
	backend, err := net.ListenUDP("udp4", &net.UDPAddr{IP: net.ParseIP("127.0.0.1")})
	if err != nil {
		t.Fatal(err)
	}
	defer backend.Close()
	done := make(chan error, 1)
	go func() {
		buf := make([]byte, 65535)
		backend.SetDeadline(time.Now().Add(3 * time.Second))
		n, source, err := backend.ReadFromUDP(buf)
		if err == nil {
			_, err = backend.WriteToUDP(buf[:n], source)
		}
		done <- err
	}()
	rt, err := startDirectICMPForwardRules(context.Background(), []DirectICMPPortForward{{"udp", "127.0.0.1:0", backend.LocalAddr().String()}}, net.ParseIP("127.0.0.1"), 2*time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer rt.Close()
	addr, _ := net.ResolveUDPAddr("udp4", forwardTestAddress(t, rt, "udp"))
	client, err := net.DialUDP("udp4", nil, addr)
	if err != nil {
		t.Fatal(err)
	}
	defer client.Close()
	client.SetDeadline(time.Now().Add(3 * time.Second))
	payload := bytes.Repeat([]byte{0, 17, 128, 255}, 15000)
	if _, err := client.Write(payload); err != nil {
		t.Fatal(err)
	}
	got := make([]byte, 65535)
	n, err := client.Read(got)
	if err != nil || !bytes.Equal(got[:n], payload) {
		t.Fatalf("60000-byte datagram changed/lost: received=%d error=%v", n, err)
	}
	if err := <-done; err != nil {
		t.Fatal(err)
	}
}

func TestDirectICMPForwardStartupRollbackAndFatalListener(t *testing.T) {
	occupied, _ := net.Listen("tcp4", "127.0.0.1:0")
	defer occupied.Close()
	free, _ := net.Listen("tcp4", "127.0.0.1:0")
	address := free.Addr().String()
	free.Close()
	rules := []DirectICMPPortForward{{"tcp", address, "127.0.0.1:18082"}, {"tcp", occupied.Addr().String(), "127.0.0.1:18082"}}
	if rt, err := startDirectICMPForwardRules(context.Background(), rules, nil, time.Second); err == nil {
		rt.Close()
		t.Fatal("bind conflict accepted")
	}
	probe, err := net.Listen("tcp4", address)
	if err != nil {
		t.Fatal("startup failure leaked earlier listener", err)
	}
	probe.Close()
	rt, err := startDirectICMPForwardRules(context.Background(), rules[:1], nil, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer rt.Close()
	rt.mu.Lock()
	for c := range rt.closers {
		c.Close()
	}
	rt.mu.Unlock()
	forwardTestWait(t, func() bool { return rt.Err() != nil })
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if rt, err := startDirectICMPForwardRules(ctx, rules[:1], nil, time.Second); err == nil {
		rt.Close()
		t.Fatal("cancelled start accepted")
	}
}

func TestDirectICMPForwardUDPAdmissionAndNoUnsolicitedReply(t *testing.T) {
	backend, err := net.ListenUDP("udp4", &net.UDPAddr{IP: net.ParseIP("127.0.0.1")})
	if err != nil {
		t.Fatal(err)
	}
	defer backend.Close()
	rt, err := startDirectICMPForwardRules(context.Background(), []DirectICMPPortForward{{"udp", "127.0.0.1:0", backend.LocalAddr().String()}}, nil, time.Second)
	if err != nil {
		t.Fatal(err)
	}
	defer rt.Close()
	// Reserve all but one slot; real UDP admission must enforce the shared cap.
	for i := 0; i < directICMPForwardMaxFlows-1; i++ {
		rt.slots <- struct{}{}
	}
	addr, _ := net.ResolveUDPAddr("udp4", forwardTestAddress(t, rt, "udp"))
	first, _ := net.DialUDP("udp4", nil, addr)
	defer first.Close()
	second, _ := net.DialUDP("udp4", nil, addr)
	defer second.Close()
	first.Write([]byte("first"))
	backend.SetReadDeadline(time.Now().Add(time.Second))
	buf := make([]byte, 64)
	n, association, err := backend.ReadFromUDP(buf)
	if err != nil || string(buf[:n]) != "first" {
		t.Fatal("first association not admitted", err)
	}
	second.Write([]byte("second"))
	backend.SetReadDeadline(time.Now().Add(80 * time.Millisecond))
	if _, _, err := backend.ReadFromUDP(buf); err == nil {
		t.Fatal("association cap bypassed")
	}
	// An unrelated sender cannot inject a reply into a connected association.
	rogue, _ := net.ListenUDP("udp4", &net.UDPAddr{IP: net.ParseIP("127.0.0.1")})
	defer rogue.Close()
	rogue.WriteToUDP([]byte("unsolicited"), association)
	first.SetReadDeadline(time.Now().Add(80 * time.Millisecond))
	if _, err := first.Read(buf); err == nil {
		t.Fatal("unsolicited target accepted")
	}
	backend.WriteToUDP([]byte("real-reply"), association)
	first.SetReadDeadline(time.Now().Add(time.Second))
	n, err = first.Read(buf)
	if err != nil || string(buf[:n]) != "real-reply" {
		t.Fatal("correct target reply lost", err)
	}
	<-rt.slots
	second.Write([]byte("retry"))
	backend.SetReadDeadline(time.Now().Add(time.Second))
	n, _, err = backend.ReadFromUDP(buf)
	if err != nil || string(buf[:n]) != "retry" {
		t.Fatal("released capacity not reused", err)
	}
}

func TestDirectICMPForwardUDPBlockedWriteIsBounded(t *testing.T) {
	// A pipe deterministically supplies socket backpressure: the peer does not
	// read. The same net.Conn write-deadline contract is used by UDP sockets.
	conn, peer := net.Pipe()
	defer conn.Close()
	defer peer.Close()
	conn.SetReadDeadline(time.Now().Add(2 * time.Second))
	start := time.Now()
	err := directICMPForwardUDPWrite(conn, []byte("blocked datagram"), time.Hour)
	if ne, ok := err.(net.Error); !ok || !ne.Timeout() {
		t.Fatalf("congested write did not time out: %v", err)
	}
	if elapsed := time.Since(start); elapsed > time.Second {
		t.Fatalf("listener blocked for %s instead of the datagram write budget", elapsed)
	}
	// A write timeout must not shorten the independent association read-idle
	// deadline; a delayed response remains readable after that write budget.
	done := make(chan error, 1)
	go func() { _, err := peer.Write([]byte("reply")); done <- err }()
	buf := make([]byte, 5)
	if _, err := io.ReadFull(conn, buf); err != nil || string(buf) != "reply" {
		t.Fatalf("write budget incorrectly expired reads: %q %v", buf, err)
	}
	if err := <-done; err != nil {
		t.Fatal(err)
	}
}
