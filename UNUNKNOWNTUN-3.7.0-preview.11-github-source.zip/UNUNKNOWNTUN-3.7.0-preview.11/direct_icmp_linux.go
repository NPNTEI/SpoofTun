//go:build linux

package main

import (
	"context"
	"crypto/rand"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net"
	"net/netip"
	"strconv"
	"time"

	"golang.org/x/sys/unix"
)

// Reject existing non-default routes that intersect any route we would create.
// Local routed subnets may already exist; we never change or claim those routes.
func directICMPCheckRoutes(data []byte, c *DirectICMPConfig) error {
	if err := greCheckRoutes(data, c.InnerLocalIP, c.InnerPeerIP); err != nil {
		return err
	}
	var routes []struct {
		Dst string `json:"dst"`
	}
	if err := json.Unmarshal(data, &routes); err != nil {
		return err
	}
	for _, route := range routes {
		if route.Dst == "default" || route.Dst == "0.0.0.0/0" {
			continue
		}
		p, err := netip.ParsePrefix(route.Dst)
		if err != nil {
			a, e := netip.ParseAddr(route.Dst)
			if e != nil {
				return errors.New("[direct-icmp/routes] unreadable route destination")
			}
			p = netip.PrefixFrom(a, 32)
		}
		prefixes := append([]string{}, c.PeerCIDRs...)
		if c.LocalPoolCIDR != "" {
			prefixes = append(prefixes, c.LocalPoolCIDR, c.PeerPoolCIDR)
		}
		for _, s := range prefixes {
			if p.Overlaps(netip.MustParsePrefix(s)) {
				return fmt.Errorf("[direct-icmp/routes] owned peer route or assigned pool overlaps existing route %s", route.Dst)
			}
		}
	}
	return nil
}

// Resources are nonpersistent and exclusively owned; closing the TUN fd also
// removes only that device's connected routes, including partial setup failures.
func setupDirectICMPLinux(ctx context.Context, c *DirectICMPConfig) (tunFD, rawFD int, err error) {
	tunFD, rawFD = -1, -1
	defer func() {
		if err != nil {
			if rawFD >= 0 {
				_ = unix.Close(rawFD)
			}
			if tunFD >= 0 {
				_ = unix.Close(tunFD)
			}
		}
	}()
	if err = c.validate(); err != nil {
		return
	}
	if err = ctx.Err(); err != nil {
		return
	}
	ipPath, e := greTrustedIPExecutable()
	if e != nil {
		err = e
		return
	}
	iface, e := net.InterfaceByName(c.Interface)
	if e != nil {
		err = fmt.Errorf("[direct-icmp/interface] %w", e)
		return
	}
	if iface.Flags&net.FlagUp == 0 || iface.Flags&(net.FlagLoopback|net.FlagPointToPoint) != 0 {
		err = errors.New("[direct-icmp/interface] physical interface must be up, non-loopback and not point-to-point")
		return
	}
	overhead := directICMPNetworkOverheadFor(c.FECMode)
	if c.MTU+overhead > iface.MTU {
		err = fmt.Errorf("[direct-icmp/mtu] configured MTU plus %d-byte overhead exceeds physical MTU %d", overhead, iface.MTU)
		return
	}
	addresses, e := iface.Addrs()
	if e != nil {
		err = e
		return
	}
	assigned := false
	for _, a := range addresses {
		p, e := netip.ParsePrefix(a.String())
		if e == nil && p.Addr().String() == c.LocalIP {
			assigned = true
		}
	}
	if !assigned {
		err = errors.New("[direct-icmp/interface] local_ip must be assigned to the selected interface; arbitrary source spoofing is unsupported")
		return
	}
	if _, e := net.InterfaceByName(c.TUNName); e == nil {
		err = errors.New("[direct-icmp/interface] requested TUN already exists; choose a distinct name")
		return
	}
	rules, e := greRunIPContext(ctx, ipPath, "-j", "-4", "rule", "show")
	if e != nil {
		err = e
		return
	}
	if err = greCheckRules(rules); err != nil {
		return
	}
	routes, e := greRunIPContext(ctx, ipPath, "-j", "-4", "route", "show", "table", "all")
	if e != nil {
		err = e
		return
	}
	if err = directICMPCheckRoutes(routes, c); err != nil {
		return
	}
	route, e := greRunIPContext(ctx, ipPath, "-j", "-4", "route", "get", c.PeerIP, "from", c.LocalIP)
	if e != nil {
		err = e
		return
	}
	if err = greCheckOuterRoute(route, &GREConfig{Interface: c.Interface, LocalIP: c.LocalIP}); err != nil {
		return
	}
	if err = ctx.Err(); err != nil {
		return
	}
	rawFD, err = unix.Socket(unix.AF_INET, unix.SOCK_RAW|unix.SOCK_NONBLOCK|unix.SOCK_CLOEXEC, unix.IPPROTO_ICMP)
	if err != nil {
		err = fmt.Errorf("[direct-icmp/raw] CAP_NET_RAW required: %w", err)
		return
	}
	for _, o := range []struct{ level, name, value int }{{unix.IPPROTO_IP, unix.IP_HDRINCL, 1}, {unix.SOL_SOCKET, unix.SO_RCVBUF, 512 * 1024}, {unix.SOL_SOCKET, unix.SO_SNDBUF, 512 * 1024}} {
		if err = unix.SetsockoptInt(rawFD, o.level, o.name, o.value); err != nil {
			return
		}
	}
	if err = unix.SetsockoptString(rawFD, unix.SOL_SOCKET, unix.SO_BINDTODEVICE, c.Interface); err != nil {
		return
	}
	if err = unix.Bind(rawFD, &unix.SockaddrInet4{Addr: netip.MustParseAddr(c.LocalIP).As4()}); err != nil {
		return
	}
	tunFD, err = unix.Open("/dev/net/tun", unix.O_RDWR|unix.O_NONBLOCK|unix.O_CLOEXEC, 0)
	if err != nil {
		err = fmt.Errorf("[direct-icmp/tun] Linux TUN and CAP_NET_ADMIN required: %w", err)
		return
	}
	ifr, e := unix.NewIfreq(c.TUNName)
	if e != nil {
		err = e
		return
	}
	ifr.SetUint16(unix.IFF_TUN | unix.IFF_NO_PI | unix.IFF_TUN_EXCL)
	if err = unix.IoctlIfreq(tunFD, unix.TUNSETIFF, ifr); err != nil {
		return
	}
	if ifr.Name() != c.TUNName {
		err = errors.New("[direct-icmp/tun] unexpected interface name")
		return
	}
	if err = unix.IoctlSetInt(tunFD, unix.TUNSETOFFLOAD, 0); err != nil {
		return
	}
	commands := [][]string{{"-4", "address", "add", c.InnerLocalIP + "/32", "peer", c.InnerPeerIP + "/32", "dev", c.TUNName, "noprefixroute"}, {"link", "set", "dev", c.TUNName, "mtu", strconv.Itoa(c.MTU), "up"}, {"-4", "route", "add", c.InnerPeerIP + "/32", "dev", c.TUNName, "src", c.InnerLocalIP, "scope", "link"}}
	for _, host := range directICMPPoolHosts(c.LocalPoolCIDR) {
		if host != c.InnerLocalIP {
			commands = append(commands, []string{"-4", "address", "add", host + "/32", "dev", c.TUNName, "noprefixroute"})
		}
	}
	peerRoutes := append([]string{}, c.PeerCIDRs...)
	if c.PeerPoolCIDR != "" {
		peerRoutes = append(peerRoutes, c.PeerPoolCIDR)
	}
	for _, p := range peerRoutes {
		if p != c.InnerPeerIP+"/32" {
			commands = append(commands, []string{"-4", "route", "add", p, "dev", c.TUNName, "src", c.InnerLocalIP, "scope", "link"})
		}
	}
	for _, args := range commands {
		if _, err = greRunIPContext(ctx, ipPath, args...); err != nil {
			return
		}
	}
	err = ctx.Err()
	return
}

func runDirectICMP(ctx context.Context, c *DirectICMPConfig) error {
	engine, err := newDirectICMPEngine(c.engineConfig(), time.Now())
	if err != nil {
		return err
	}
	tunFD, rawFD, err := setupDirectICMPLinux(ctx, c)
	if err != nil {
		return err
	}
	defer unix.Close(tunFD)
	defer unix.Close(rawFD)
	cleanupPool, err := installDirectICMPPoolNAT(ctx, c)
	if err != nil {
		return err
	}
	defer cleanupPool()
	forwards, err := startDirectICMPForwards(ctx, c)
	if err != nil {
		return err
	}
	defer forwards.Close()
	var idbuf [4]byte
	if _, err := rand.Read(idbuf[:]); err != nil {
		return err
	}
	peer := unix.SockaddrInet4{Addr: netip.MustParseAddr(c.PeerIP).As4()}
	// ICMP responses must echo a still-outstanding identifier/sequence. Entries
	// are consumed only after engine authentication, so kernel automatic echoes
	// cannot eat the legitimate response to the same request.
	credits := newDirectICMPEchoCredits(binary.BigEndian.Uint32(idbuf[:]), time.Duration(c.TimeoutSeconds)*time.Second)
	var sent, received, rejected, dropped uint64
	var lastSendFailureLog time.Time
	send := func(payload []byte, id, seq uint16) (ok bool, sendErr error) {
		// Sealing consumes a nonce even if the kernel refuses the packet.
		// Report actual socket acceptance, never infer WAN loss from nonce gaps.
		defer func() { engine.TransmitResult(payload, ok, time.Now()) }()
		p := wrapDirectICMP(c, payload, id, seq)
		err := unix.Sendto(rawFD, p, unix.MSG_DONTWAIT, &peer)
		if directICMPRecoverableSendError(err) {
			dropped++
			if !greWouldBlock(err) && time.Since(lastSendFailureLog) >= 5*time.Second {
				log.Printf("[direct-icmp/send] temporary network failure (%v); preserving TUN and retrying through normal bounded polling", err)
				lastSendFailureLog = time.Now()
			}
			return false, nil
		}
		if err != nil {
			return false, fmt.Errorf("[direct-icmp/send] %w", err)
		}
		sent++
		return true, nil
	}
	sendOrigin := func(payload []byte, now time.Time) error {
		id, seq, reserved := credits.reserve(now)
		if !reserved {
			engine.TransmitResult(payload, false, now)
			dropped++
			return nil
		}
		ok, err := send(payload, id, seq)
		if err != nil || !ok {
			credits.cancel(id, seq)
		}
		return err
	}
	log.Printf("[direct-icmp] started role=%s device=%s inner=%s peer=%s mtu=%d fec=%s repair_cap=%d%%; encrypted IPv4, no TLS certificate or WebSocket", c.Role, c.TUNName, c.InnerLocalIP, c.InnerPeerIP, c.MTU, c.FECMode, c.FECMaxPercent)
	fds := []unix.PollFd{{Fd: int32(tunFD), Events: unix.POLLIN}, {Fd: int32(rawFD), Events: unix.POLLIN}}
	innerBuf := make([]byte, c.MTU+1)
	outerBuf := make([]byte, c.MTU+engine.NetworkOverhead())
	lastStats := time.Now()
	wasConnected := false
	var rawRate nativeICMPRate
	var rawResume time.Time
	for {
		if err := forwards.Err(); err != nil {
			return err
		}
		if err := ctx.Err(); err != nil {
			log.Printf("[direct-icmp] stopped; owned TUN/routes removed; engine=%+v", engine.Stats())
			return nil
		}
		now := time.Now()
		credits.prune(now)
		for _, payload := range engine.Tick(now) {
			if c.Role != "origin" {
				return errors.New("[direct-icmp/protocol] responder attempted unsolicited send")
			}
			if err := sendOrigin(payload, now); err != nil {
				return err
			}
		}
		connected := engine.Connected(now)
		if connected != wasConnected {
			if connected {
				log.Printf("[direct-icmp] connected; authenticated peer active")
			} else {
				credits.resetEstimate()
				log.Printf("[direct-icmp] disconnected; waiting for authenticated recovery")
			}
			wasConnected = connected
		}
		if now.Sub(lastStats) >= 10*time.Second {
			log.Printf("[direct-icmp/stats] connected=%t sent=%d received=%d rejected=%d dropped=%d engine=%+v", connected, sent, received, rejected, dropped, engine.Stats())
			lastStats = now
		}
		fds[1].Events = unix.POLLIN
		if now.Before(rawResume) {
			fds[1].Events = 0
		}
		waitMS := c.PollMS
		if waitMS > 20 {
			waitMS = 20
		}
		_, err := unix.Poll(fds, waitMS)
		if errors.Is(err, unix.EINTR) {
			continue
		}
		if err != nil {
			return fmt.Errorf("[direct-icmp/poll] %w", err)
		}
		if ctx.Err() != nil {
			continue
		}
		for _, fd := range fds {
			if fd.Revents&(unix.POLLERR|unix.POLLHUP|unix.POLLNVAL) != 0 {
				return errors.New("[direct-icmp/descriptor] packet descriptor became unavailable")
			}
		}
		if fds[0].Revents&unix.POLLIN != 0 {
			for batch := 0; batch < 32; batch++ {
				n, err := unix.Read(tunFD, innerBuf)
				if greWouldBlock(err) {
					break
				}
				if err != nil {
					return err
				}
				if n == 0 {
					return errors.New("[direct-icmp/tun] unexpected EOF")
				}
				if err := validateDirectICMPInner(c, innerBuf[:n], false); err != nil {
					rejected++
					continue
				}
				if err := clampDirectICMPMSS(innerBuf[:n], c.MTU); err != nil {
					rejected++
					continue
				}
				if err := engine.Queue(innerBuf[:n]); err != nil {
					dropped++
				}
			}
		}
		if fds[1].Revents&unix.POLLIN != 0 {
			for batch := 0; batch < 64; batch++ {
				if !rawRate.allow(time.Now(), 8000, 128) {
					rawResume = time.Now().Add(2 * time.Millisecond)
					break
				}
				n, _, flags, _, err := unix.Recvmsg(rawFD, outerBuf, nil, unix.MSG_DONTWAIT|unix.MSG_TRUNC)
				if greWouldBlock(err) {
					break
				}
				if err != nil {
					return err
				}
				if n > len(outerBuf) || flags&unix.MSG_TRUNC != 0 {
					rejected++
					continue
				}
				payload, id, seq, err := unwrapDirectICMP(c, outerBuf[:n])
				if err != nil {
					rejected++
					continue
				}
				if c.Role == "origin" {
					if !credits.matches(id, seq, time.Now()) {
						rejected++
						continue
					}
				}
				out, inner, err := engine.Receive(payload, time.Now())
				if err != nil {
					rejected++
					continue
				}
				if c.Role == "origin" {
					engine.ObserveRTT(credits.acknowledge(id, seq, time.Now()))
				}
				received++
				if c.Role == "egress" && len(out) > 1 {
					return errors.New("[direct-icmp/protocol] responder amplification rejected")
				}
				for _, reply := range out {
					if c.Role == "origin" {
						if err := sendOrigin(reply, time.Now()); err != nil {
							return err
						}
					} else {
						if _, err := send(reply, id, seq); err != nil {
							return err
						}
					}
				}
				for _, packet := range inner {
					if err := validateDirectICMPInner(c, packet, true); err != nil {
						rejected++
						continue
					}
					if err := clampDirectICMPMSS(packet, c.MTU); err != nil {
						rejected++
						continue
					}
					written, err := unix.Write(tunFD, packet)
					if greWouldBlock(err) || errors.Is(err, unix.ENOBUFS) {
						dropped++
						continue
					}
					if err != nil {
						return err
					}
					if written != len(packet) {
						return errors.New("[direct-icmp/tun] short packet write")
					}
				}
			}
		}
	}
}

// A temporary route/interface outage must not destroy the TUN and all inner
// connections. Authentication timeout/rehandshake still runs while sends fail.
func directICMPRecoverableSendError(err error) bool {
	return greWouldBlock(err) || errors.Is(err, unix.ENOBUFS) ||
		errors.Is(err, unix.ENETUNREACH) || errors.Is(err, unix.EHOSTUNREACH) ||
		errors.Is(err, unix.ENETDOWN)
}
