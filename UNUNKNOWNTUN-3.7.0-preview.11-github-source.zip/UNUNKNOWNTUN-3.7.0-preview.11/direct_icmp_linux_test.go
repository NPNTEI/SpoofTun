//go:build linux

package main

import (
	"context"
	"testing"
)

func TestDirectICMPRouteOwnership(t *testing.T) {
	c := directRuntimeConfig()
	c.LocalCIDRs = []string{"10.20.0.0/24"}
	c.PeerCIDRs = []string{"10.21.0.0/24"}
	allowed := []byte(`[{"dst":"default","gateway":"192.0.2.254","dev":"eth0"},{"dst":"192.0.2.0/24","dev":"eth0"},{"dst":"10.20.0.0/24","dev":"lan0"}]`)
	if err := directICMPCheckRoutes(allowed, c); err != nil {
		t.Fatalf("localprefix shouldnotbeclaimed: %v", err)
	}
	for _, bad := range []string{`[]`, `null`, `[{"dst":"10.21.0.0/25"}]`, `[{"dst":"10.0.0.0/8"}]`, `[{"dst":"10.238.0.1"}]`, `[{"dst":"10.238.0.2"}]`, `[{"dst":"unreadable"}]`, `[{"dst":"default"},{"dst":"10.21.0.5"}]`} {
		if directICMPCheckRoutes([]byte(bad), c) == nil {
			t.Fatalf("accepted conflicting routes %s", bad)
		}
	}
}

func TestDirectICMPSetupCancelledBeforeMutation(t *testing.T) {
	c := directRuntimeConfig()
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	tun, raw, err := setupDirectICMPLinux(ctx, c)
	if err == nil || tun != -1 || raw != -1 {
		t.Fatalf("cancelled setup allocated resources: %d %d %v", tun, raw, err)
	}
}
