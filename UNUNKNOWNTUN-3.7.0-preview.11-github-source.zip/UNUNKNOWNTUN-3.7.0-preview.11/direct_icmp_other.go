//go:build !linux

package main

import (
	"context"
	"errors"
)

func runDirectICMP(ctx context.Context, c *DirectICMPConfig) error {
	return errors.New("[direct-icmp/platform] Direct ICMP requires Linux TUN, iproute2, CAP_NET_ADMIN and CAP_NET_RAW; offline configuration checking is available here")
}
