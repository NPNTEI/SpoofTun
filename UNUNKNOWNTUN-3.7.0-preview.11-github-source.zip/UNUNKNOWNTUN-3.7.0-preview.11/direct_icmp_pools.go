package main

import (
	"errors"
	"fmt"
	"net/netip"
)

func directICMPPoolPrefix(s string) (netip.Prefix, error) {
	p, err := directICMPPrivatePrefix(s)
	if err != nil || p.Bits() < 26 || p.Bits() > 30 {
		return netip.Prefix{}, errors.New("pool must be canonical RFC1918 IPv4 /26../30 (2..62 usable hosts)")
	}
	return p, nil
}

func directICMPPoolContainsHost(p netip.Prefix, ip netip.Addr) bool {
	return p.Contains(ip) && ip != p.Addr() && p.Contains(ip.Next())
}

func directICMPPoolHosts(s string) []string {
	if s == "" {
		return nil
	}
	p := netip.MustParsePrefix(s)
	result := make([]string, 0, (1<<(32-p.Bits()))-2)
	for a := p.Addr().Next(); directICMPPoolContainsHost(p, a); a = a.Next() {
		result = append(result, a.String())
	}
	return result
}

func (c *DirectICMPConfig) validatePools() error {
	if c.SourceRotation != "off" && c.SourceRotation != "round-robin" {
		return errors.New("[direct-icmp/pool] source_rotation must be off or round-robin")
	}
	if c.LocalPoolCIDR == "" && c.PeerPoolCIDR == "" {
		if c.SourceRotation != "off" {
			return errors.New("[direct-icmp/pool] round-robin requires both local_pool_cidr and peer_pool_cidr")
		}
		return nil
	}
	local, err := directICMPPoolPrefix(c.LocalPoolCIDR)
	if err != nil {
		return fmt.Errorf("[direct-icmp/pool] local_pool_cidr: %w", err)
	}
	peer, err := directICMPPoolPrefix(c.PeerPoolCIDR)
	if err != nil {
		return fmt.Errorf("[direct-icmp/pool] peer_pool_cidr: %w", err)
	}
	if local.Overlaps(peer) || !directICMPPoolContainsHost(local, netip.MustParseAddr(c.InnerLocalIP)) || !directICMPPoolContainsHost(peer, netip.MustParseAddr(c.InnerPeerIP)) {
		return errors.New("[direct-icmp/pool] pools must be disjoint and contain their corresponding usable inner host addresses")
	}
	for _, pool := range []netip.Prefix{local, peer} {
		for _, outer := range []string{c.LocalIP, c.PeerIP} {
			if pool.Contains(netip.MustParseAddr(outer)) {
				return errors.New("[direct-icmp/pool] pool overlaps outer address")
			}
		}
		for _, group := range [][]string{c.LocalCIDRs, c.PeerCIDRs} {
			for _, routed := range group {
				if pool.Overlaps(netip.MustParsePrefix(routed)) {
					return errors.New("[direct-icmp/pool] assigned pools and routed CIDRs must not overlap")
				}
			}
		}
	}
	return nil
}
