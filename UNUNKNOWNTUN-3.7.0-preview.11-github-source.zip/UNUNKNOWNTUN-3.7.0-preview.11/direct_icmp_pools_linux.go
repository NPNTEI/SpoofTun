//go:build linux

package main

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"io"
	"os"
	"syscall"

	"errors"
	"fmt"
	"golang.org/x/sys/unix"
	"log"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

func directICMPPoolTable(c *DirectICMPConfig) string {
	sum := sha256.Sum256([]byte(c.TUNName))
	return fmt.Sprintf("gdt_icmp_%x", sum[:8])
}

// NAT chains evaluate only the initial packet. Conntrack preserves the chosen
// source and reverse translation for the entire TCP/UDP/ICMP flow. This never
// changes the outer ICMP source or creates per-packet TCP address changes.
func directICMPPoolRules(c *DirectICMPConfig) (string, error) {
	if err := c.validate(); err != nil {
		return "", err
	}
	if c.SourceRotation != "round-robin" {
		return "", nil
	}
	pool := directICMPPoolHosts(c.LocalPoolCIDR)
	entries := make([]string, 0, len(pool))
	for i, ip := range pool {
		entries = append(entries, fmt.Sprintf("%d : %s", i, ip))
	}
	src := append([]string{c.LocalPoolCIDR}, c.LocalCIDRs...)
	dst := append([]string{c.PeerPoolCIDR}, c.PeerCIDRs...)
	table := directICMPPoolTable(c)
	return "create table ip " + table + "\n" +
		"add chain ip " + table + " prerouting { type nat hook prerouting priority -110; policy accept; }\n" +
		"add chain ip " + table + " postrouting { type nat hook postrouting priority 90; policy accept; }\n" +
		"add rule ip " + table + " postrouting oifname \"" + c.TUNName + "\" ip saddr { " + strings.Join(src, ", ") +
		" } ip daddr { " + strings.Join(dst, ", ") + " } snat to numgen inc mod " + fmt.Sprint(len(pool)) +
		" map { " + strings.Join(entries, ", ") + " }\n", nil
}

func directICMPTrustedNFT() (string, error) {
	for _, candidate := range []string{"/usr/sbin/nft", "/sbin/nft", "/usr/bin/nft", "/bin/nft"} {
		path, err := filepath.EvalSymlinks(candidate)
		if err == nil && greCheckTrustedPath(path) == nil {
			return path, nil
		}
	}
	return "", errors.New("[direct-icmp/round-robin] trusted nft executable required; install the nftables package or select source_rotation=off")
}

func directICMPExecNFT(parent context.Context, path, script string, args ...string) (string, error) {
	ctx, cancel := context.WithTimeout(parent, 5*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, path, args...)
	cmd.Env = []string{"PATH=/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL=C"}
	cmd.Stdin = strings.NewReader(script)
	var output greBoundedOutput
	cmd.Stdout, cmd.Stderr = &output, &output
	if err := cmd.Run(); err != nil {
		detail := strings.TrimSpace(output.String())
		if len(detail) > 1024 {
			detail = detail[:1024]
		}
		return "", fmt.Errorf("[direct-icmp/round-robin] nft transaction failed: %w (%s)", err, detail)
	}
	if output.exceeded {
		return "", errors.New("[direct-icmp/round-robin] nft output exceeded limit")
	}
	return output.String(), nil
}

func directICMPRunNFT(ctx context.Context, path, script string) error {
	_, err := directICMPExecNFT(ctx, path, script, "-f", "-")
	return err
}

func installDirectICMPPoolNAT(ctx context.Context, c *DirectICMPConfig) (func(), error) {
	rules, err := directICMPPoolRules(c)
	if err != nil || rules == "" {
		return func() {}, err
	}
	path, err := directICMPTrustedNFT()
	if err != nil {
		return nil, err
	}
	table := directICMPPoolTable(c)
	lease, err := directICMPOpenPoolLease(table)
	if err != nil {
		return nil, err
	}
	installed := false
	defer func() {
		if !installed {
			lease.Close()
		}
	}()
	// An exclusive, root-only lease outlives a crash. A stale table is reclaimed
	// only when its marker matches that lease; an unrelated table is untouched.
	oldMarker, err := directICMPPoolTableMarker(ctx, path, table)
	if err != nil {
		return nil, err
	}
	if oldMarker != "" {
		if err := directICMPCheckPoolLease(lease, table, oldMarker); err != nil {
			return nil, err
		}
		if err := directICMPRunNFT(ctx, path, "delete table ip "+table+"\n"); err != nil {
			return nil, err
		}
		log.Printf("[direct-icmp/round-robin] reclaimed owned table after previous process exit: %s", table)
	}
	token := make([]byte, 16)
	if _, err = rand.Read(token); err != nil {
		return nil, err
	}
	marker := "ununknowntun-icmp-rr:v1:" + hex.EncodeToString(token)
	state, _ := json.Marshal(directICMPPoolLease{Table: table, Marker: marker})
	if err := lease.Truncate(0); err != nil {
		return nil, err
	}
	if _, err := lease.WriteAt(state, 0); err != nil {
		return nil, err
	}
	if err := lease.Sync(); err != nil {
		return nil, err
	}
	rules = strings.Replace(rules, "create table ip "+table+"\n", "create table ip "+table+" { comment \""+marker+"\"; }\n", 1)
	// Atomic create refuses any existing table; no host ruleset is ever flushed.
	if err := directICMPRunNFT(ctx, path, rules); err != nil {
		return nil, err
	}
	installed = true
	log.Printf("[direct-icmp/round-robin] source pool=%s peer pool=%s hosts=%d table=%s; address pinned per conntrack flow", c.LocalPoolCIDR, c.PeerPoolCIDR, len(directICMPPoolHosts(c.LocalPoolCIDR)), table)
	return func() {
		defer lease.Close()
		current, err := directICMPPoolTableMarker(context.Background(), path, table)
		if err == nil && current == marker {
			err = directICMPRunNFT(context.Background(), path, "delete table ip "+table+"\n")
		} else if err == nil && current != "" {
			err = errors.New("table ownership changed; refusing cleanup")
		}
		if err != nil {
			log.Printf("[direct-icmp/round-robin] owned table cleanup failed: %v", err)
			return
		}
		// Keep the lock inode stable: unlinking a flock file can admit two owners.
		if err = lease.Truncate(0); err == nil {
			err = lease.Sync()
		}
		if err != nil {
			log.Printf("[direct-icmp/round-robin] lease cleanup failed: %v", err)
		}
	}, nil
}

type directICMPPoolLease struct {
	Table  string `json:"table"`
	Marker string `json:"marker"`
}

func directICMPOpenPoolLease(table string) (*os.File, error) {
	const directory = "/run/ununknowntun-icmp-rr"
	if err := os.Mkdir(directory, 0700); err != nil && !errors.Is(err, os.ErrExist) {
		return nil, err
	}
	info, err := os.Lstat(directory)
	if err != nil {
		return nil, err
	}
	st, ok := info.Sys().(*syscall.Stat_t)
	if !ok || st.Uid != 0 || !info.IsDir() || info.Mode().Perm() != 0700 {
		return nil, errors.New("[direct-icmp/round-robin] lease directory must be a root-owned private directory")
	}
	// The namespace identity prevents two independent local namespaces sharing
	// the same TUN name from taking each other's lock or ownership marker.
	ns, err := os.Stat("/proc/self/ns/net")
	if err != nil {
		return nil, err
	}
	nsStat, ok := ns.Sys().(*syscall.Stat_t)
	if !ok {
		return nil, errors.New("network namespace identity unavailable")
	}
	name := filepath.Join(directory, fmt.Sprintf("%d-%s.lock", nsStat.Ino, table))
	fd, err := unix.Open(name, unix.O_RDWR|unix.O_CREAT|unix.O_CLOEXEC|unix.O_NOFOLLOW, 0600)
	if err != nil {
		return nil, err
	}
	f := os.NewFile(uintptr(fd), name)
	valid := false
	defer func() {
		if !valid {
			f.Close()
		}
	}()
	info, err = f.Stat()
	if err != nil {
		return nil, err
	}
	st, ok = info.Sys().(*syscall.Stat_t)
	if !ok || st.Uid != 0 || st.Nlink != 1 || !info.Mode().IsRegular() || info.Mode().Perm() != 0600 {
		return nil, errors.New("[direct-icmp/round-robin] unsafe lease file")
	}
	if err := unix.Flock(fd, unix.LOCK_EX|unix.LOCK_NB); err != nil {
		return nil, fmt.Errorf("[direct-icmp/round-robin] another process owns this namespace/TUN lease: %w", err)
	}
	valid = true
	return f, nil
}

func directICMPCheckPoolLease(lease io.ReaderAt, table, marker string) error {
	data := make([]byte, 513)
	n, err := lease.ReadAt(data, 0)
	if err != nil && !errors.Is(err, io.EOF) {
		return err
	}
	var stored directICMPPoolLease
	if n > 512 || json.Unmarshal(data[:n], &stored) != nil || stored.Table != table || stored.Marker != marker || !directICMPValidPoolMarker(marker) {
		return errors.New("[direct-icmp/round-robin] existing nft table is not proven owned by this process lease; refusing deletion")
	}
	return nil
}

func directICMPValidPoolMarker(marker string) bool {
	const prefix = "ununknowntun-icmp-rr:v1:"
	if !strings.HasPrefix(marker, prefix) || len(marker) != len(prefix)+32 {
		return false
	}
	_, err := hex.DecodeString(strings.TrimPrefix(marker, prefix))
	return err == nil
}

func directICMPPoolTableMarker(ctx context.Context, path, table string) (string, error) {
	all, err := directICMPExecNFT(ctx, path, "", "-j", "list", "tables")
	if err != nil {
		return "", err
	}
	found, _, err := directICMPParseTableMarker(all, table)
	if err != nil || !found {
		return "", err
	}
	detail, err := directICMPExecNFT(ctx, path, "", "-j", "list", "table", "ip", table)
	if err != nil {
		return "", err
	}
	found, marker, err := directICMPParseTableMarker(detail, table)
	if err != nil {
		return "", err
	}
	if !found || marker == "" {
		return "unowned", nil
	}
	return marker, nil
}

func directICMPParseTableMarker(document, name string) (bool, string, error) {
	var data struct {
		NFTables []struct {
			Table *struct {
				Family  string `json:"family"`
				Name    string `json:"name"`
				Comment string `json:"comment"`
			} `json:"table"`
		} `json:"nftables"`
	}
	if err := json.Unmarshal([]byte(document), &data); err != nil {
		return false, "", err
	}
	for _, item := range data.NFTables {
		if item.Table != nil && item.Table.Family == "ip" && item.Table.Name == name {
			return true, item.Table.Comment, nil
		}
	}
	return false, "", nil
}
