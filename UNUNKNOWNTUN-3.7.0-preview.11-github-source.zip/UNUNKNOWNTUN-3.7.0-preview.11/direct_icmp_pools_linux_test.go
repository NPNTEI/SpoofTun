//go:build linux

package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"testing"

	"golang.org/x/sys/unix"
)

func TestDirectICMPPoolRoutesAreOwned(t *testing.T) {
	c := directPoolConfig()
	for _, route := range []string{"10.238.1.2/32", "10.238.2.2/32", "10.238.1.0/30", "10.238.0.0/16"} {
		data := []byte(fmt.Sprintf(`[{"dst":"default"},{"dst":%q}]`, route))
		if directICMPCheckRoutes(data, c) == nil {
			t.Fatalf("accepted existing route intersecting assigned pool: %s", route)
		}
	}
	if err := directICMPCheckRoutes([]byte(`[{"dst":"default"},{"dst":"192.0.2.0/24"}]`), c); err != nil {
		t.Fatal(err)
	}
}

func TestDirectICMPRoundRobinRuleScope(t *testing.T) {
	c := directPoolConfig()
	rules, err := directICMPPoolRules(c)
	if err != nil {
		t.Fatal(err)
	}
	for _, fragment := range []string{"create table ip gdt_icmp_", "type nat hook postrouting", `oifname "gdic0"`, "ip saddr { 10.238.1.0/30 }", "ip daddr { 10.238.2.0/30 }", "snat to numgen inc mod 2 map { 0 : 10.238.1.1, 1 : 10.238.1.2 }"} {
		if !strings.Contains(rules, fragment) {
			t.Fatalf("missing restrictive NAT component %q", fragment)
		}
	}
	for _, forbidden := range []string{"flush", "delete", "masquerade", "0.0.0.0/0", "192.0.2.1", "192.0.2.2"} {
		if strings.Contains(rules, forbidden) {
			t.Fatalf("unsafe or outer-address NAT component %q", forbidden)
		}
	}
	c.SourceRotation = "off"
	if rules, err := directICMPPoolRules(c); err != nil || rules != "" {
		t.Fatal("off mode generated firewall mutation")
	}
	c.SourceRotation, c.TUNName = "round-robin", "bad;flush"
	if _, err := directICMPPoolRules(c); err == nil {
		t.Fatal("unsafe interface accepted")
	}
}

func TestDirectICMPTemporarySendFailurePreservesRuntime(t *testing.T) {
	for _, err := range []error{unix.EAGAIN, unix.ENOBUFS, unix.ENETUNREACH, unix.EHOSTUNREACH, unix.ENETDOWN, fmt.Errorf("send: %w", unix.EHOSTUNREACH)} {
		if !directICMPRecoverableSendError(err) {
			t.Fatalf("temporary route/socket fault would tear down TUN: %v", err)
		}
	}
	for _, err := range []error{nil, unix.EPERM, unix.EBADF, unix.EINVAL, errors.New("unknown")} {
		if directICMPRecoverableSendError(err) {
			t.Fatalf("fatal/programming error hidden: %v", err)
		}
	}
}

func TestDirectICMPStalePoolOwnershipRequiresPrivateMarker(t *testing.T) {
	table := "gdt_icmp_test"
	marker := "ununknowntun-icmp-rr:v1:0123456789abcdef0123456789abcdef"
	valid, _ := json.Marshal(directICMPPoolLease{Table: table, Marker: marker})
	if err := directICMPCheckPoolLease(bytes.NewReader(valid), table, marker); err != nil {
		t.Fatal(err)
	}
	for _, data := range [][]byte{nil, []byte("bad json"), []byte(`{"table":"wrong","marker":"` + marker + `"}`), bytes.Repeat([]byte("x"), 513)} {
		if directICMPCheckPoolLease(bytes.NewReader(data), table, marker) == nil {
			t.Fatal("unowned table accepted")
		}
	}
	for _, wrong := range []string{"unowned", "", marker + "0", "ununknowntun-icmp-rr:v1:zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz"} {
		if directICMPCheckPoolLease(bytes.NewReader(valid), table, wrong) == nil {
			t.Fatal("invalid marker accepted")
		}
	}
	doc := `{"nftables":[{"metainfo":{}},{"table":{"family":"ip6","name":"` + table + `","comment":"wrong"}},{"table":{"family":"ip","name":"` + table + `","comment":"` + marker + `"}}]}`
	found, got, err := directICMPParseTableMarker(doc, table)
	if err != nil || !found || got != marker {
		t.Fatalf("marker parse: %v %v %v", found, got, err)
	}
	found, _, err = directICMPParseTableMarker(doc, "missing")
	if err != nil || found {
		t.Fatal("adopted unrelated table")
	}
}
