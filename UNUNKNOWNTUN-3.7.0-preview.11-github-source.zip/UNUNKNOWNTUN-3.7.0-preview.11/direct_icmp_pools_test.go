package main

import (
	"encoding/json"
	"testing"
)

func directPoolConfig() *DirectICMPConfig {
	c := directRuntimeConfig()
	c.LocalPoolCIDR, c.PeerPoolCIDR = "10.238.1.0/30", "10.238.2.0/30"
	c.InnerLocalIP, c.InnerPeerIP = "10.238.1.1", "10.238.2.1"
	c.SourceRotation = "round-robin"
	return c
}

func TestDirectICMPPoolsRoundTripAndBounds(t *testing.T) {
	c := directPoolConfig()
	data, _ := json.Marshal(c)
	got, err := parseDirectICMPConfig(data)
	if err != nil || got.LocalPoolCIDR != c.LocalPoolCIDR || got.PeerPoolCIDR != c.PeerPoolCIDR || got.SourceRotation != "round-robin" {
		t.Fatalf("round trip: %+v %v", got, err)
	}
	for prefix, count := range map[string]int{"10.2.3.0/26": 62, "172.16.1.0/28": 14, "192.168.3.0/30": 2} {
		if _, err := directICMPPoolPrefix(prefix); err != nil {
			t.Fatal(err)
		}
		hosts := directICMPPoolHosts(prefix)
		if len(hosts) != count {
			t.Fatalf("%s: got %d hosts", prefix, len(hosts))
		}
	}
	for _, prefix := range []string{"10.0.0.0/8", "10.1.0.0/25", "10.1.0.0/31", "10.1.0.1/32", "10.1.0.1/28", "192.0.2.0/28", "0.0.0.0/0", "fd00::/120"} {
		if _, err := directICMPPoolPrefix(prefix); err == nil {
			t.Fatalf("accepted unsafe/unbounded pool %s", prefix)
		}
	}
}

func TestDirectICMPPoolsRejectConflicts(t *testing.T) {
	mutations := map[string]func(*DirectICMPConfig){
		"missing-local":     func(c *DirectICMPConfig) { c.LocalPoolCIDR = "" },
		"missing-peer":      func(c *DirectICMPConfig) { c.PeerPoolCIDR = "" },
		"overlap":           func(c *DirectICMPConfig) { c.PeerPoolCIDR = c.LocalPoolCIDR },
		"network-host":      func(c *DirectICMPConfig) { c.InnerLocalIP = "10.238.1.0" },
		"broadcast-host":    func(c *DirectICMPConfig) { c.InnerPeerIP = "10.238.2.3" },
		"host-outside":      func(c *DirectICMPConfig) { c.InnerLocalIP = "10.240.0.1" },
		"outer-overlap":     func(c *DirectICMPConfig) { c.LocalIP = "10.238.1.2" },
		"local-lan-overlap": func(c *DirectICMPConfig) { c.LocalCIDRs = []string{"10.238.1.0/24"} },
		"peer-lan-overlap":  func(c *DirectICMPConfig) { c.PeerCIDRs = []string{"10.238.2.0/30"} },
		"unknown-mode":      func(c *DirectICMPConfig) { c.SourceRotation = "random" },
	}
	for name, mutate := range mutations {
		t.Run(name, func(t *testing.T) {
			c := directPoolConfig()
			mutate(c)
			if err := c.validate(); err == nil {
				t.Fatal("accepted invalid/conflicting pools")
			}
		})
	}
	c := directRuntimeConfig()
	if err := c.validate(); err != nil {
		t.Fatalf("legacy config changed: %v", err)
	}
	c.SourceRotation = "round-robin"
	if c.validate() == nil {
		t.Fatal("rotation without pool accepted")
	}
	c = directPoolConfig()
	c.SourceRotation = "off"
	if err := c.validate(); err != nil {
		t.Fatal("assigned pools with no rotation should work", err)
	}
}

func TestDirectICMPPoolInnerBoundary(t *testing.T) {
	c := directPoolConfig()
	for _, src := range directICMPPoolHosts(c.LocalPoolCIDR) {
		for _, dst := range directICMPPoolHosts(c.PeerPoolCIDR) {
			p := directRuntimeIPv4(src, dst, 253, []byte("pool payload"))
			if err := validateDirectICMPInner(c, p, false); err != nil {
				t.Fatalf("valid pool packet: %v", err)
			}
			if err := validateDirectICMPInner(c, p, true); err == nil {
				t.Fatal("wrong-direction pool packet accepted")
			}
			reply := directRuntimeIPv4(dst, src, 253, []byte("reply"))
			if err := validateDirectICMPInner(c, reply, true); err != nil {
				t.Fatalf("valid pool reply: %v", err)
			}
		}
	}
	for _, src := range []string{"10.238.1.0", "10.238.1.3", "10.238.1.4", "10.238.2.2"} {
		if validateDirectICMPInner(c, directRuntimeIPv4(src, c.InnerPeerIP, 253, nil), false) == nil {
			t.Fatalf("invalid source admitted: %s", src)
		}
	}
}
