package main

import (
	"encoding/binary"
	"testing"
	"time"
)

func TestDirectICMPReviewFailedRekeyKeepsWorkingSession(t *testing.T) {
	a, b, now := directConnected(t)
	old := a.active.id
	a.active.created = now.Add(-a.config.RekeyAfter)
	for i := 0; i < 15; i++ {
		now = now.Add(300 * time.Millisecond)
		_ = a.Queue([]byte{byte(i)})
		var accepted [][]byte
		for _, p := range a.Tick(now) {
			if p[4] != directICMPHello {
				accepted = append(accepted, p)
			}
		}
		_, inner := directDeliver(t, a, b, accepted, now)
		if len(inner) != 1 || inner[0][0] != byte(i) || !a.Connected(now) || !b.Connected(now) || a.active.id != old || b.active.id != old {
			t.Fatal("failedrekey broke existingdata", i)
		}
	}
	// A fresh attempt completes when the blocked candidate handshake can pass.
	now = now.Add(300 * time.Millisecond)
	directDeliver(t, a, b, a.Tick(now), now)
	if !a.Connected(now) || !b.Connected(now) || a.active.id == old || b.active.id != a.active.id {
		t.Fatal("candidate recovery failed")
	}
}

func TestDirectICMPReviewOldTrafficCannotExtendNewSessionOrGrace(t *testing.T) {
	a, b, now := directConnected(t)
	old := a.active
	a.active.created = now.Add(-a.config.RekeyAfter)
	now = now.Add(time.Second)
	directDeliver(t, a, b, a.Tick(now), now)
	if a.previous != old || b.previous == nil {
		t.Fatal("no oldsession grace")
	}
	for _, offset := range []time.Duration{time.Second, 2 * time.Second} {
		p, err := a.seal(old, directICMPData, []byte("old"))
		if err != nil {
			t.Fatal(err)
		}
		if _, inner, err := b.Receive(p, now.Add(offset)); err != nil || len(inner) != 1 {
			t.Fatal("valid in-grace data rejected", err)
		}
	}
	p, err := a.seal(old, directICMPData, []byte("expired"))
	if err != nil {
		t.Fatal(err)
	}
	if _, _, err := b.Receive(p, now.Add(3100*time.Millisecond)); err == nil || b.active != nil || b.previous != nil {
		t.Fatal("oldtraffic extended newliveness orgrace")
	}
}

func TestDirectICMPReviewForgedHighNonceCannotAdvanceReplay(t *testing.T) {
	a, b, now := directConnected(t)
	_ = a.Queue([]byte("valid"))
	now = now.Add(time.Second)
	p := a.Tick(now)[0]
	bad := append([]byte{}, p...)
	binary.BigEndian.PutUint64(bad[24:32], directICMPMaxNonce-1)
	before := b.active.replay.high
	if _, _, err := b.Receive(bad, now); err == nil || b.active.replay.high != before {
		t.Fatal("unauthenticated highnonce consumedwindow")
	}
	if _, inner, err := b.Receive(p, now); err != nil || len(inner) != 1 {
		t.Fatal("forgery suppressedvalidpacket", err)
	}
}
