package main

import (
	"encoding/binary"
	"encoding/json"
	"net/netip"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func directRuntimeConfig() *DirectICMPConfig {
	c := &DirectICMPConfig{Role: "origin", Interface: "eth0", TUNName: "gdic0", LocalIP: "192.0.2.1", PeerIP: "192.0.2.2", InnerLocalIP: "10.238.0.1", InnerPeerIP: "10.238.0.2", KeyFile: "/root/gdic/key"}
	c.defaults()
	return c
}

func directRuntimeIPv4(src, dst string, proto byte, payload []byte) []byte {
	p := make([]byte, 20+len(payload))
	p[0] = 0x45
	p[8] = 64
	p[9] = proto
	binary.BigEndian.PutUint16(p[2:4], uint16(len(p)))
	for i, addr := range []string{src, dst} {
		v := netip.MustParseAddr(addr).As4()
		copy(p[12+i*4:16+i*4], v[:])
	}
	copy(p[20:], payload)
	binary.BigEndian.PutUint16(p[10:12], greChecksum(p[:20]))
	return p
}

func directRuntimeTCP(c *DirectICMPConfig, mss uint16) []byte {
	payload := make([]byte, 24)
	binary.BigEndian.PutUint16(payload[:2], 12345)
	binary.BigEndian.PutUint16(payload[2:4], 443)
	payload[12] = 6 << 4
	payload[13] = 2
	payload[20] = 2
	payload[21] = 4
	binary.BigEndian.PutUint16(payload[22:24], mss)
	p := directRuntimeIPv4(c.InnerLocalIP, c.InnerPeerIP, 6, payload)
	binary.BigEndian.PutUint16(p[36:38], directICMPL4Checksum(p, 20, 6))
	return p
}

func TestDirectICMPConfigStrictAndDefaults(t *testing.T) {
	c := directRuntimeConfig()
	b, _ := json.Marshal(c)
	got, err := parseDirectICMPConfig(b)
	if err != nil {
		t.Fatal(err)
	}
	if got.MTU != 1200 || got.PollMS != 20 || got.TimeoutSeconds != 15 || got.RekeySeconds != 3600 {
		t.Fatal("unexpected defaults")
	}
	for _, bad := range []string{strings.TrimSuffix(string(b), "}") + `,"role":"origin"}`, strings.TrimSuffix(string(b), "}") + `,"Role":"origin"}`, strings.TrimSuffix(string(b), "}") + `,"extra":1}`, strings.TrimSuffix(string(b), "}") + `,"local_cidrs":null}`, string(b) + `{}`, `[]`, strings.Repeat(" ", 16385)} {
		if _, err := parseDirectICMPConfig([]byte(bad)); err == nil {
			t.Fatalf("accepted invalid config: %.80s", bad)
		}
	}
	mutations := map[string]func(*DirectICMPConfig){
		"role": func(c *DirectICMPConfig) { c.Role = "client" }, "interface": func(c *DirectICMPConfig) { c.Interface = "eth0;id" }, "tun": func(c *DirectICMPConfig) { c.TUNName = c.Interface }, "mtu": func(c *DirectICMPConfig) { c.MTU = 1401 }, "poll": func(c *DirectICMPConfig) { c.PollMS = 1 }, "timeout": func(c *DirectICMPConfig) { c.TimeoutSeconds = 301 }, "rekey": func(c *DirectICMPConfig) { c.RekeySeconds = 20 }, "outer": func(c *DirectICMPConfig) { c.LocalIP = "127.0.0.1" }, "same": func(c *DirectICMPConfig) { c.PeerIP = c.LocalIP }, "inner": func(c *DirectICMPConfig) { c.InnerLocalIP = "192.0.2.4" }, "ipv6": func(c *DirectICMPConfig) { c.InnerPeerIP = "fd00::2" }, "key": func(c *DirectICMPConfig) { c.KeyFile = "relative" }, "default": func(c *DirectICMPConfig) { c.PeerCIDRs = []string{"0.0.0.0/0"} }, "public": func(c *DirectICMPConfig) { c.PeerCIDRs = []string{"192.0.2.0/24"} }, "uncanonical": func(c *DirectICMPConfig) { c.PeerCIDRs = []string{"10.9.0.1/24"} }, "cross-overlap": func(c *DirectICMPConfig) { c.PeerCIDRs = []string{"10.238.0.0/24"} }, "duplicate": func(c *DirectICMPConfig) { c.PeerCIDRs = []string{"10.10.0.0/24", "10.10.0.0/24"} }, "within-overlap": func(c *DirectICMPConfig) { c.PeerCIDRs = []string{"10.10.0.0/24", "10.10.0.0/25"} }, "outerprefix": func(c *DirectICMPConfig) { c.LocalIP = "10.11.0.1"; c.PeerCIDRs = []string{"10.11.0.0/24"} },
	}
	for name, change := range mutations {
		t.Run(name, func(t *testing.T) {
			c := directRuntimeConfig()
			change(c)
			if c.validate() == nil {
				t.Fatal("accepted invalid config")
			}
		})
	}
	c.LocalCIDRs = []string{"10.8.0.0/24"}
	c.PeerCIDRs = []string{"10.9.0.0/24"}
	if err := c.validate(); err != nil {
		t.Fatal(err)
	}
}

func TestDirectICMPPrivateConfigAndKey(t *testing.T) {
	dir, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	key := filepath.Join(dir, "key")
	cfg := filepath.Join(dir, "config.json")
	c := directRuntimeConfig()
	c.KeyFile = key
	b, _ := json.Marshal(c)
	if err := os.WriteFile(key, []byte(strings.Repeat("ab", 32)+"\n"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(cfg, b, 0600); err != nil {
		t.Fatal(err)
	}
	got, err := loadDirectICMPConfig(cfg)
	if err != nil {
		t.Fatal(err)
	}
	if got.key[0] != 0xab {
		t.Fatal("key not decoded")
	}
	if err := os.Chmod(key, 0644); err != nil {
		t.Fatal(err)
	}
	if _, err := loadDirectICMPConfig(cfg); err == nil {
		t.Fatal("accepted public keyfile")
	}
	_ = os.Chmod(key, 0600)
	for _, bad := range []string{strings.Repeat("00", 32), strings.Repeat("ab", 31), strings.Repeat("ab", 32) + " ", strings.Repeat("gg", 32)} {
		_ = os.WriteFile(key, []byte(bad), 0600)
		if _, err := loadDirectICMPConfig(cfg); err == nil {
			t.Fatal("accepted invalid key")
		}
	}
	_ = os.WriteFile(key, []byte(strings.Repeat("ab", 32)), 0600)
	link := filepath.Join(dir, "link")
	if err := os.Symlink(key, link); err != nil {
		t.Fatal(err)
	}
	c.KeyFile = link
	b, _ = json.Marshal(c)
	_ = os.WriteFile(cfg, b, 0600)
	if _, err := loadDirectICMPConfig(cfg); err == nil {
		t.Fatal("accepted symlink key")
	}
}

func TestDirectICMPFullIPv4AndMSS(t *testing.T) {
	c := directRuntimeConfig()
	p := directRuntimeTCP(c, 1460)
	if err := validateDirectICMPInner(c, p, false); err != nil {
		t.Fatal(err)
	}
	if err := clampDirectICMPMSS(p, c.MTU); err != nil {
		t.Fatal(err)
	}
	if got := binary.BigEndian.Uint16(p[42:44]); got != 1160 {
		t.Fatalf("MSS=%d", got)
	}
	if err := validateDirectICMPInner(c, p, false); err != nil {
		t.Fatalf("MSS checksum broken: %v", err)
	}
	if err := validateDirectICMPInner(c, p, true); err == nil {
		t.Fatal("wrongdirection accepted")
	}
	u := make([]byte, 11)
	binary.BigEndian.PutUint16(u[:2], 1234)
	binary.BigEndian.PutUint16(u[2:4], 53)
	binary.BigEndian.PutUint16(u[4:6], uint16(len(u)))
	copy(u[8:], "udp")
	udp := directRuntimeIPv4(c.InnerLocalIP, c.InnerPeerIP, 17, u)
	binary.BigEndian.PutUint16(udp[26:28], directICMPL4Checksum(udp, 20, 17))
	if err := validateDirectICMPInner(c, udp, false); err != nil {
		t.Fatal(err)
	}
	ic := make([]byte, 13)
	ic[0] = 8
	copy(ic[8:], "hello")
	binary.BigEndian.PutUint16(ic[2:4], greChecksum(ic))
	icmp := directRuntimeIPv4(c.InnerLocalIP, c.InnerPeerIP, 1, ic)
	if err := validateDirectICMPInner(c, icmp, false); err != nil {
		t.Fatal(err)
	}
	for _, original := range [][]byte{p, udp, icmp} {
		bad := append([]byte{}, original...)
		bad[len(bad)-1] ^= 1
		if err := validateDirectICMPInner(c, bad, false); err == nil {
			t.Fatal("corruptL4 checksum accepted")
		}
	}
	for _, proto := range []byte{47, 132} {
		p := directRuntimeIPv4(c.InnerLocalIP, c.InnerPeerIP, proto, []byte{1, 2, 3})
		if err := validateDirectICMPInner(c, p, false); err != nil {
			t.Fatal("otherIPv4 protocol rejected", err)
		}
	}
	c.LocalCIDRs = []string{"10.8.0.0/24"}
	c.PeerCIDRs = []string{"10.9.0.0/24"}
	routed := directRuntimeIPv4("10.8.0.5", "10.9.0.6", 47, []byte{1, 2})
	if err := validateDirectICMPInner(c, routed, false); err != nil {
		t.Fatal(err)
	}
	outside := directRuntimeIPv4("10.7.0.5", "10.9.0.6", 47, []byte{1, 2})
	if err := validateDirectICMPInner(c, outside, false); err == nil {
		t.Fatal("unauthorizedinner source accepted")
	}
}

func TestDirectICMPFragmentsAndOptions(t *testing.T) {
	c := directRuntimeConfig()
	for _, flags := range []uint16{0x2000, 0x0002} {
		p := directRuntimeIPv4(c.InnerLocalIP, c.InnerPeerIP, 6, make([]byte, 16))
		binary.BigEndian.PutUint16(p[6:8], flags)
		p[10], p[11] = 0, 0
		binary.BigEndian.PutUint16(p[10:12], greChecksum(p[:20]))
		if err := validateDirectICMPInner(c, p, false); err != nil {
			t.Fatal(err)
		}
		if err := clampDirectICMPMSS(p, c.MTU); err != nil {
			t.Fatal(err)
		}
	}
	p := directRuntimeIPv4(c.InnerLocalIP, c.InnerPeerIP, 6, make([]byte, 15))
	binary.BigEndian.PutUint16(p[6:8], 0x2000)
	p[10], p[11] = 0, 0
	binary.BigEndian.PutUint16(p[10:12], greChecksum(p[:20]))
	if validateDirectICMPInner(c, p, false) == nil {
		t.Fatal("invalidfragment accepted")
	}
	p = directRuntimeTCP(c, 1460)
	p = append(append(append([]byte{}, p[:20]...), 1, 1, 1, 0), p[20:]...)
	p[0] = 0x46
	binary.BigEndian.PutUint16(p[2:4], uint16(len(p)))
	p[10], p[11] = 0, 0
	binary.BigEndian.PutUint16(p[10:12], greChecksum(p[:24]))
	if err := validateDirectICMPInner(c, p, false); err != nil {
		t.Fatal(err)
	}
	if err := clampDirectICMPMSS(p, c.MTU); err != nil {
		t.Fatal(err)
	}
	if err := validateDirectICMPInner(c, p, false); err != nil {
		t.Fatal(err)
	}
	if binary.BigEndian.Uint16(p[46:48]) != 1156 {
		t.Fatal("IPoptions MSS budget wrong")
	}
	p = directRuntimeTCP(c, 1460)
	p[41] = 1
	p[36], p[37] = 0, 0
	binary.BigEndian.PutUint16(p[36:38], directICMPL4Checksum(p, 20, 6))
	if clampDirectICMPMSS(p, c.MTU) == nil {
		t.Fatal("badMSSoptions accepted")
	}
}

func TestDirectICMPOuterIdentityDirectionAndChecksums(t *testing.T) {
	a := directRuntimeConfig()
	b := *a
	b.Role = "egress"
	b.LocalIP, b.PeerIP = a.PeerIP, a.LocalIP
	p := wrapDirectICMP(a, []byte("payload"), 431, 51)
	payload, id, seq, err := unwrapDirectICMP(&b, p)
	if err != nil || string(payload) != "payload" || id != 431 || seq != 51 {
		t.Fatalf("unwrap: %s %d %d %v", payload, id, seq, err)
	}
	if _, _, _, err := unwrapDirectICMP(a, p); err == nil {
		t.Fatal("ownrequest accepted")
	}
	for _, i := range []int{0, 2, 8, 9, 12, 16, 20, 21, 22, 28} {
		bad := append([]byte{}, p...)
		bad[i] ^= 1
		if _, _, _, err := unwrapDirectICMP(&b, bad); err == nil {
			t.Fatalf("corrupt offset %d accepted", i)
		}
	}
	r := wrapDirectICMP(&b, []byte("reply"), id, seq)
	if _, _, _, err := unwrapDirectICMP(a, r); err != nil {
		t.Fatal(err)
	}
}

func TestDirectICMPCommandRejectsModeMixing(t *testing.T) {
	for _, flags := range [][]string{{"mode"}, {"transport"}, {"version"}, {"token-file"}, {"stats"}} {
		handled, err := runDirectICMPCommand("/missing", "", flags)
		if !handled || err == nil || !strings.Contains(err.Error(), "incompatible") {
			t.Fatal(flags, handled, err)
		}
	}
	if handled, err := runDirectICMPCommand("", "", nil); handled || err != nil {
		t.Fatal("claimedunrelatedcommand")
	}
	if _, err := runDirectICMPCommand("/run", "/check", nil); err == nil {
		t.Fatal("mixedactions accepted")
	}
}

func FuzzDirectICMPInnerBoundary(f *testing.F) {
	c := directRuntimeConfig()
	f.Add(directRuntimeTCP(c, 1460))
	f.Add([]byte{})
	f.Add(make([]byte, 20))
	f.Fuzz(func(t *testing.T, p []byte) {
		if validateDirectICMPInner(c, p, false) == nil {
			q := append([]byte{}, p...)
			_ = clampDirectICMPMSS(q, c.MTU)
		}
	})
}
