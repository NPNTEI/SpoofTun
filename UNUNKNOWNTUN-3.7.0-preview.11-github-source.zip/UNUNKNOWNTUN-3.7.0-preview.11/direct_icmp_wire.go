package main

import (
	"encoding/binary"
	"errors"
	"net/netip"
)

func wrapDirectICMP(c *DirectICMPConfig, payload []byte, id, seq uint16) []byte {
	p := make([]byte, 28+len(payload))
	p[0] = 0x45
	p[8] = 64
	p[9] = 1
	binary.BigEndian.PutUint16(p[2:4], uint16(len(p)))
	binary.BigEndian.PutUint16(p[4:6], seq)
	binary.BigEndian.PutUint16(p[6:8], 0x4000)
	src, dst := netip.MustParseAddr(c.LocalIP).As4(), netip.MustParseAddr(c.PeerIP).As4()
	copy(p[12:16], src[:])
	copy(p[16:20], dst[:])
	binary.BigEndian.PutUint16(p[10:12], greChecksum(p[:20]))
	if c.Role == "origin" {
		p[20] = 8
	}
	binary.BigEndian.PutUint16(p[24:26], id)
	binary.BigEndian.PutUint16(p[26:28], seq)
	copy(p[28:], payload)
	binary.BigEndian.PutUint16(p[22:24], greChecksum(p[20:]))
	return p
}

func unwrapDirectICMP(c *DirectICMPConfig, p []byte) (payload []byte, id, seq uint16, err error) {
	if len(p) < 28 || len(p) > c.MTU+directICMPNetworkOverheadFor(c.FECMode) || p[0] != 0x45 || p[8] == 0 || p[9] != 1 || int(binary.BigEndian.Uint16(p[2:4])) != len(p) || binary.BigEndian.Uint16(p[6:8])&0xbfff != 0 || greChecksum(p[:20]) != 0 {
		return nil, 0, 0, errors.New("invalid outer IPv4 ICMP envelope")
	}
	if !greSameIP(p[12:16], c.PeerIP) || !greSameIP(p[16:20], c.LocalIP) {
		return nil, 0, 0, ErrGREIdentityMismatch
	}
	want := byte(8)
	if c.Role == "origin" {
		want = 0
	}
	if p[20] != want || p[21] != 0 || greChecksum(p[20:]) != 0 {
		return nil, 0, 0, errors.New("invalid ICMP direction/code/checksum")
	}
	return p[28:], binary.BigEndian.Uint16(p[24:26]), binary.BigEndian.Uint16(p[26:28]), nil
}
