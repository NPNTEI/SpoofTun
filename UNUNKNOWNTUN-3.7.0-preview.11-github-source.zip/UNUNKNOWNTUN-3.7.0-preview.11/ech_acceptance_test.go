package main

import (
	"bytes"
	"context"
	"crypto/ecdh"
	"crypto/rand"
	"crypto/tls"
	"encoding/binary"
	"fmt"
	"io"
	"net"
	"net/http"
	"path/filepath"
	"sync/atomic"
	"testing"
	"time"

	"golang.org/x/crypto/cryptobyte"
	"golang.org/x/net/http2"
)

// This is a real accepted ECH handshake, not GREASE, DNS parsing alone, or a
// successful ordinary TLS connection. The only DNS response is a local mock;
// the configured carrier authenticates against a loopback TLS server that owns
// the corresponding ECH private key. No public CDN or resolver is contacted.
func TestStrictECHAcceptedCarrierAuthentication(t *testing.T) {
	const innerHost = "private-tunnel.example.test"
	const outerHost = "public-cover.example.test"
	const resolver = "https://resolver.example.test/dns-query"
	const token = "strict-ech-local-auth-token-0123456789abcdef"
	echKey, err := ecdh.X25519().GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	configBuilder := cryptobyte.NewBuilder(nil)
	configBuilder.AddUint16(0xfe0d) // ECHConfig version supported by uTLS and Go.
	configBuilder.AddUint16LengthPrefixed(func(b *cryptobyte.Builder) {
		b.AddUint8(73)
		b.AddUint16(0x0020) // DHKEM(X25519, HKDF-SHA256)
		b.AddUint16LengthPrefixed(func(b *cryptobyte.Builder) { b.AddBytes(echKey.PublicKey().Bytes()) })
		b.AddUint16LengthPrefixed(func(b *cryptobyte.Builder) {
			b.AddUint16(0x0001) // HKDF-SHA256
			b.AddUint16(0x0001) // AES-128-GCM
		})
		b.AddUint8(64)
		b.AddUint8LengthPrefixed(func(b *cryptobyte.Builder) { b.AddBytes([]byte(outerHost)) })
		b.AddUint16(0) // extensions
	})
	echConfig := configBuilder.BytesOrPanic()
	listBuilder := cryptobyte.NewBuilder(nil)
	listBuilder.AddUint16LengthPrefixed(func(b *cryptobyte.Builder) { b.AddBytes(echConfig) })
	echList := listBuilder.BytesOrPanic()

	previous := http.DefaultTransport
	defer func() { http.DefaultTransport = previous }()
	var discoveries atomic.Int32
	http.DefaultTransport = probeRoundTripper(func(r *http.Request) (*http.Response, error) {
		if r.URL.String() != resolver || r.Method != http.MethodPost {
			return nil, fmt.Errorf("unexpected DNS request: %s %s", r.Method, r.URL)
		}
		query, err := io.ReadAll(r.Body)
		if err != nil || len(query) < 12 {
			return nil, fmt.Errorf("invalid local DNS query: %v", err)
		}
		discoveries.Add(1)
		response := append([]byte(nil), query...)
		binary.BigEndian.PutUint16(response[2:4], 0x8180)
		binary.BigEndian.PutUint16(response[6:8], 1)
		rdata := []byte{0, 1, 0}                        // HTTPS priority 1, target name ".".
		rdata = binary.BigEndian.AppendUint16(rdata, 5) // ech service parameter
		rdata = binary.BigEndian.AppendUint16(rdata, uint16(len(echList)))
		rdata = append(rdata, echList...)
		response = append(response, 0xc0, 0x0c, 0, 65, 0, 1, 0, 0, 0, 60)
		response = binary.BigEndian.AppendUint16(response, uint16(len(rdata)))
		response = append(response, rdata...)
		return &http.Response{StatusCode: http.StatusOK, Header: make(http.Header), Body: io.NopCloser(bytes.NewReader(response))}, nil
	})

	for _, mode := range []string{TransportWSS, TransportXHTTP} {
		t.Run(mode, func(t *testing.T) {
			dir := t.TempDir()
			certPath := filepath.Join(dir, "inner.crt")
			cert, err := loadOrCreateCert(certPath, filepath.Join(dir, "inner.key"), innerHost, false)
			if err != nil {
				t.Fatal(err)
			}
			cfg := &Config{Mode: "origin", Transport: mode, Token: token, SNI: innerHost, WSHost: innerHost,
				WSPath: "/ech/wss-abcdefghijkl", XHTTPPath: "/ech/xhttp-abcdefghijkl", XHTTPMode: "packet-up",
				UTLSProfile: "chrome", ECHMode: ECHModeStrict, ECHDoH: resolver, TLSMinVersion: "1.3", CAFile: certPath}
			limiter := NewAdaptiveRateLimiter(10, 5)
			xhttp := newXHTTPServer(cfg, func(c net.Conn, ip string) { dispatchEgressConn(c, ip, cfg, limiter) })
			defer xhttp.Close()
			alpn := "http/1.1"
			if mode == TransportXHTTP {
				alpn = "h2"
			}
			accepted := make(chan tls.ConnectionState, 2)
			serverErrors := make(chan error, 2)
			serverFinished := make(chan struct{}, 2)
			server := managedTestListener(t, func(raw net.Conn) {
				defer func() { serverFinished <- struct{}{} }()
				_ = raw.SetDeadline(time.Now().Add(5 * time.Second))
				conn := tls.Server(raw, &tls.Config{Certificates: []tls.Certificate{cert}, MinVersion: tls.VersionTLS13,
					NextProtos: []string{alpn}, EncryptedClientHelloKeys: []tls.EncryptedClientHelloKey{
						{Config: echConfig, PrivateKey: echKey.Bytes(), SendAsRetry: true},
					}})
				if err := conn.Handshake(); err != nil {
					serverErrors <- err
					return
				}
				accepted <- conn.ConnectionState()
				_ = raw.SetDeadline(time.Time{})
				if mode == TransportXHTTP {
					(&http2.Server{}).ServeConn(conn, &http2.ServeConnOpts{Handler: xhttp})
					return
				}
				ws, ip, err := acceptServerWebSocket(conn, innerHost, cfg.WSPath, token)
				if err != nil {
					serverErrors <- err
					return
				}
				dispatchEgressConn(ws, ip, cfg, limiter)
			})
			cfg.Connect = server.Addr().String()
			streams, memory := activeStreams.Load(), memoryBudget.Load()
			queries := discoveries.Load()
			endpoint, actual, err := checkTunnelContext(context.Background(), cfg, 5*time.Second)
			if err != nil {
				t.Fatal(err)
			}
			if endpoint != cfg.Connect || actual != mode+"-ech" || discoveries.Load() != queries+1 {
				t.Fatalf("unexpected ECH probe result: endpoint=%s transport=%s DNS queries=%d", endpoint, actual, discoveries.Load()-queries)
			}
			select {
			case state := <-accepted:
				if !state.ECHAccepted || state.ServerName != innerHost || state.Version != tls.VersionTLS13 || state.NegotiatedProtocol != alpn {
					t.Fatalf("server did not accept the real inner ECH handshake: accepted=%t SNI=%q version=%x ALPN=%q", state.ECHAccepted, state.ServerName, state.Version, state.NegotiatedProtocol)
				}
			case err := <-serverErrors:
				t.Fatalf("local ECH server failed: %v", err)
			case <-time.After(time.Second):
				t.Fatal("no independently observed ECH server state")
			}
			select {
			case <-serverFinished:
			case <-time.After(2 * time.Second):
				t.Fatal("ECH diagnostic probe left its carrier open")
			}
			waitForStreamBaseline(t, streams, memory)
		})
	}
}
