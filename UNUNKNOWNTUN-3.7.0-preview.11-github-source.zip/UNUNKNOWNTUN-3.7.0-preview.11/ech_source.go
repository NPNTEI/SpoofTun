package main

// ECH discovery descriptors identify where to obtain an ECHConfigList. They do
// not change the TLS inner SNI, HTTP Host, or tunnel dial address, and do not
// carry a TLS ClientHello inside DNS.
import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/base64"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"mime"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"

	"golang.org/x/crypto/cryptobyte"
)

const echSourceTimeout = 8 * time.Second

type echSourceSpec struct {
	auto     bool
	config   []byte
	domain   string
	resolver *url.URL
}

func validECHSourceName(name string) bool {
	if len(name) == 0 || len(name) > 253 || net.ParseIP(name) != nil {
		return false
	}
	for _, label := range strings.Split(name, ".") {
		if len(label) == 0 || len(label) > 63 || label[0] == '-' || label[len(label)-1] == '-' {
			return false
		}
		for _, c := range label {
			if !(c >= 'a' && c <= 'z' || c >= '0' && c <= '9' || c == '-') {
				return false
			}
		}
	}
	return true
}

// validateManualECHConfig validates framing and fields, including whether this
// release's uTLS HPKE implementation has a usable config. Acceptance and TLS
// identity are still checked by the real handshake, never inferred from DNS.
func validateManualECHConfig(data []byte) error {
	if len(data) < 6 || len(data) > 65537 || int(binary.BigEndian.Uint16(data[:2])) != len(data)-2 {
		return errors.New("invalid ECHConfigList length")
	}
	list := cryptobyte.String(data[2:])
	usable := false
	for !list.Empty() {
		var version uint16
		var body cryptobyte.String
		if !list.ReadUint16(&version) || !list.ReadUint16LengthPrefixed(&body) {
			return errors.New("truncated ECHConfig")
		}
		if version != 0xfe0d {
			continue
		}
		var id, maximum uint8
		var kem uint16
		var key, suites, publicName, extensions cryptobyte.String
		if !body.ReadUint8(&id) || !body.ReadUint16(&kem) || !body.ReadUint16LengthPrefixed(&key) ||
			!body.ReadUint16LengthPrefixed(&suites) || !body.ReadUint8(&maximum) ||
			!body.ReadUint8LengthPrefixed(&publicName) || !body.ReadUint16LengthPrefixed(&extensions) || !body.Empty() {
			return errors.New("malformed ECHConfig contents")
		}
		if len(key) == 0 || len(suites) == 0 || len(suites)%4 != 0 || !validECHSourceName(strings.ToLower(string(publicName))) {
			return errors.New("invalid ECH public key, cipher suites or public name")
		}
		cipherOK := false
		for !suites.Empty() {
			var kdf, aead uint16
			if !suites.ReadUint16(&kdf) || !suites.ReadUint16(&aead) {
				return errors.New("malformed ECH cipher suites")
			}
			cipherOK = cipherOK || kdf == 1 && (aead == 1 || aead == 2 || aead == 3)
		}
		mandatory := false
		seen := map[uint16]bool{}
		for !extensions.Empty() {
			var kind uint16
			var value cryptobyte.String
			if !extensions.ReadUint16(&kind) || !extensions.ReadUint16LengthPrefixed(&value) || seen[kind] {
				return errors.New("malformed or duplicate ECH extension")
			}
			seen[kind] = true
			mandatory = mandatory || kind&0x8000 != 0
		}
		usable = usable || kem == 0x0020 && len(key) == 32 && cipherOK && !mandatory
	}
	if !usable {
		return errors.New("ECHConfigList contains no supported X25519 ECH configuration")
	}
	return nil
}

func parseECHSource(serverName, source string) (echSourceSpec, error) {
	var result echSourceSpec
	source = strings.TrimSpace(source)
	if source == "" || source == "auto" {
		result.auto = true
		return result, nil
	}
	if len(source) > 90000 || strings.ContainsAny(source, "\r\n\x00\t ") {
		return result, errors.New("ECH source is too large or contains whitespace/control characters")
	}
	if !strings.Contains(source, "://") {
		data, err := base64.StdEncoding.Strict().DecodeString(strings.TrimPrefix(source, "base64:"))
		if err != nil {
			return result, errors.New("ECH source must be auto, a base64 ECHConfigList, or [domain+]udp://IP / tcp://IP / https://resolver/dns-query")
		}
		if err := validateManualECHConfig(data); err != nil {
			return result, fmt.Errorf("manual ECH config: %w", err)
		}
		result.config = data
		return result, nil
	}
	result.domain = canonicalHost(serverName)
	resolverText := source
	// '+' within a DoH URL is not the domain separator. Only inspect the
	// prefix before the URI scheme marker.
	if plus := strings.Index(source[:strings.Index(source, "://")], "+"); plus >= 0 {
		result.domain = strings.TrimSuffix(strings.ToLower(source[:plus]), ".")
		resolverText = source[plus+1:]
	}
	if !validECHSourceName(result.domain) {
		return result, errors.New("ECH discovery requires a DNS server name or an explicit domain+resolver descriptor")
	}
	u, err := url.Parse(resolverText)
	if err != nil || u == nil || u.Host == "" || u.User != nil || u.Fragment != "" || u.Opaque != "" {
		return result, errors.New("invalid ECH resolver URL; credentials and fragments are not allowed")
	}
	if u.Scheme != "udp" && u.Scheme != "tcp" && u.Scheme != "https" {
		return result, errors.New("ECH resolver protocol must be udp, tcp or https")
	}
	port := u.Port()
	if strings.HasSuffix(u.Host, ":") {
		return result, errors.New("ECH resolver port cannot be empty")
	}
	if port != "" {
		n, err := strconv.Atoi(port)
		if err != nil || n < 1 || n > 65535 {
			return result, errors.New("ECH resolver port must be 1-65535")
		}
	}
	host := u.Hostname()
	if u.Scheme == "https" {
		if net.ParseIP(host) == nil && !validECHSourceName(strings.ToLower(host)) {
			return result, errors.New("invalid DoH resolver hostname")
		}
		if u.Path == "" {
			u.Path = "/dns-query"
		}
	} else {
		if net.ParseIP(host) == nil || u.Path != "" || u.RawQuery != "" || u.ForceQuery {
			return result, errors.New("UDP/TCP ECH resolver must be a literal IPv4/IPv6 address without a path or query")
		}
		if port == "" {
			u.Host = net.JoinHostPort(host, "53")
		}
	}
	result.resolver = u
	return result, nil
}

func resolveECHSourceContext(ctx context.Context, serverName, source, doh string) ([]byte, string, error) {
	spec, err := parseECHSource(serverName, source)
	if err != nil {
		return nil, "", fmt.Errorf("[ech-source] %w", err)
	}
	if spec.auto {
		return fetchECHConfigContext(ctx, serverName, doh)
	}
	if err := ctx.Err(); err != nil {
		return nil, "", fmt.Errorf("[ech-source] %w", err)
	}
	if len(spec.config) != 0 {
		return spec.config, "manual ECHConfigList", nil
	}
	// A single bounded budget covers queries, alias traversal and TCP retry.
	ctx, cancel := context.WithTimeout(ctx, echSourceTimeout)
	defer cancel()
	name := spec.domain
	seen := map[string]bool{}
	for depth := 0; depth < 4; depth++ {
		if seen[name] {
			return nil, "", errors.New("[ech-discovery] DNS alias loop")
		}
		seen[name] = true
		query, id, err := makeECHSourceQuery(name)
		if err != nil {
			return nil, "", fmt.Errorf("[ech-discovery] %w", err)
		}
		message, err := exchangeECHSourceQuery(ctx, spec.resolver, query)
		if err != nil {
			// Do not include the resolver URL: DoH query parameters may be private.
			return nil, "", fmt.Errorf("[ech-discovery/%s] resolver request failed: %w", spec.resolver.Scheme, err)
		}
		config, alias, err := parseECHSourceResponse(message, id, name)
		if err == nil {
			if err := validateManualECHConfig(config); err != nil {
				return nil, "", fmt.Errorf("[ech-discovery] invalid ECH response: %w", err)
			}
			return config, "manual " + spec.resolver.Scheme + " resolver", nil
		}
		if alias == "" {
			return nil, "", fmt.Errorf("[ech-discovery] %w", err)
		}
		name = alias
	}
	return nil, "", errors.New("[ech-discovery] DNS alias depth exceeded")
}

func makeECHSourceQuery(name string) ([]byte, uint16, error) {
	wire, err := encodeDNSName(name)
	if err != nil {
		return nil, 0, err
	}
	message := make([]byte, 12, 12+len(wire)+4)
	if _, err := rand.Read(message[:2]); err != nil {
		return nil, 0, err
	}
	binary.BigEndian.PutUint16(message[2:4], 0x0100)
	binary.BigEndian.PutUint16(message[4:6], 1)
	message = append(message, wire...)
	message = append(message, 0, 65, 0, 1)
	return message, binary.BigEndian.Uint16(message[:2]), nil
}

func exchangeECHSourceQuery(ctx context.Context, resolver *url.URL, query []byte) ([]byte, error) {
	if resolver.Scheme == "https" {
		request, err := http.NewRequestWithContext(ctx, http.MethodPost, resolver.String(), bytes.NewReader(query))
		if err != nil {
			return nil, errors.New("invalid DoH request")
		}
		request.Header.Set("Content-Type", "application/dns-message")
		request.Header.Set("Accept", "application/dns-message")
		client := &http.Client{Timeout: echSourceTimeout, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
		response, err := client.Do(request)
		if err != nil {
			// *url.Error includes the full URL. Preserve its cause only.
			var urlErr *url.Error
			if errors.As(err, &urlErr) {
				return nil, urlErr.Err
			}
			return nil, err
		}
		defer response.Body.Close()
		if response.StatusCode != http.StatusOK {
			return nil, fmt.Errorf("DoH HTTP status %d", response.StatusCode)
		}
		kind, _, err := mime.ParseMediaType(response.Header.Get("Content-Type"))
		if err != nil || kind != "application/dns-message" {
			return nil, errors.New("DoH response Content-Type is not application/dns-message")
		}
		data, err := io.ReadAll(io.LimitReader(response.Body, 65536))
		if err != nil {
			return nil, err
		}
		if len(data) > 65535 {
			return nil, errors.New("DoH response exceeds DNS message limit")
		}
		return data, nil
	}
	data, err := exchangeECHSourceSocket(ctx, resolver.Scheme, resolver.Host, query)
	if err != nil {
		return nil, err
	}
	// Retry only an ID-matching response with TC set. Plain UDP DNS is not
	// cryptographically authenticated; the eventual TLS ECH check still is.
	if resolver.Scheme == "udp" && len(data) >= 4 && binary.BigEndian.Uint16(data[:2]) == binary.BigEndian.Uint16(query[:2]) &&
		binary.BigEndian.Uint16(data[2:4])&0x8200 == 0x8200 {
		return exchangeECHSourceSocket(ctx, "tcp", resolver.Host, query)
	}
	return data, nil
}

func exchangeECHSourceSocket(ctx context.Context, network, address string, query []byte) ([]byte, error) {
	conn, err := (&net.Dialer{Timeout: echSourceTimeout}).DialContext(ctx, network, address)
	if err != nil {
		return nil, err
	}
	defer conn.Close()
	stop := context.AfterFunc(ctx, func() { _ = conn.Close() })
	defer stop()
	deadline := time.Now().Add(echSourceTimeout)
	if earlier, ok := ctx.Deadline(); ok && earlier.Before(deadline) {
		deadline = earlier
	}
	if err := conn.SetDeadline(deadline); err != nil {
		return nil, err
	}
	if network == "tcp" {
		packet := binary.BigEndian.AppendUint16(nil, uint16(len(query)))
		packet = append(packet, query...)
		if _, err := writeFull(conn, packet); err != nil {
			return nil, err
		}
		var header [2]byte
		if _, err := io.ReadFull(conn, header[:]); err != nil {
			return nil, err
		}
		data := make([]byte, int(binary.BigEndian.Uint16(header[:])))
		if _, err := io.ReadFull(conn, data); err != nil {
			return nil, err
		}
		return data, nil
	}
	if n, err := conn.Write(query); err != nil || n != len(query) {
		if err == nil {
			err = io.ErrShortWrite
		}
		return nil, err
	}
	data := make([]byte, 65535)
	n, err := conn.Read(data)
	return data[:n], err
}

// Only answer records associated with the requested name (and its explicit
// CNAME chain) can supply ECH. Authority/additional records cannot substitute a
// different host's key. No DNSSEC authenticity is claimed for plaintext DNS.
func parseECHSourceResponse(message []byte, id uint16, name string) ([]byte, string, error) {
	if len(message) < 12 || len(message) > 65535 || binary.BigEndian.Uint16(message[:2]) != id {
		return nil, "", errors.New("DNS response length or ID mismatch")
	}
	flags := binary.BigEndian.Uint16(message[2:4])
	if flags&0x8000 == 0 || flags&0x7800 != 0 || flags&0x0200 != 0 || flags&0xf != 0 {
		return nil, "", fmt.Errorf("DNS response rejected (flags 0x%04x)", flags)
	}
	if binary.BigEndian.Uint16(message[4:6]) != 1 {
		return nil, "", errors.New("DNS response must contain one matching question")
	}
	question, at, err := decodeDNSName(message, 12)
	if err != nil || canonicalHost(question) != name || at+4 > len(message) || binary.BigEndian.Uint16(message[at:at+2]) != 65 || binary.BigEndian.Uint16(message[at+2:at+4]) != 1 {
		return nil, "", errors.New("DNS response question mismatch")
	}
	at += 4
	type record struct {
		owner       string
		kind, class uint16
		start, end  int
	}
	answers := []record{}
	count := int(binary.BigEndian.Uint16(message[6:8]))
	all := count + int(binary.BigEndian.Uint16(message[8:10])) + int(binary.BigEndian.Uint16(message[10:12]))
	for i := 0; i < all; i++ {
		owner, next, err := decodeDNSName(message, at)
		if err != nil || next+10 > len(message) {
			return nil, "", errors.New("malformed DNS record")
		}
		r := record{canonicalHost(owner), binary.BigEndian.Uint16(message[next : next+2]), binary.BigEndian.Uint16(message[next+2 : next+4]), next + 10, next + 10 + int(binary.BigEndian.Uint16(message[next+8:next+10]))}
		if r.end > len(message) {
			return nil, "", errors.New("truncated DNS record")
		}
		if i < count {
			answers = append(answers, r)
		}
		at = r.end
	}
	if at != len(message) {
		return nil, "", errors.New("trailing DNS response data")
	}
	current := name
	visited := map[string]bool{}
	for depth := 0; depth < 4; depth++ {
		if visited[current] {
			return nil, "", errors.New("DNS CNAME loop")
		}
		visited[current] = true
		alias := ""
		var config []byte
		bestPriority := 65536
		for _, r := range answers {
			if r.owner != current || r.class != 1 {
				continue
			}
			if r.kind == 5 {
				value, end, err := decodeDNSName(message, r.start)
				value = canonicalHost(value)
				if err != nil || end != r.end || !validECHSourceName(value) || alias != "" && alias != value {
					return nil, "", errors.New("invalid DNS CNAME")
				}
				alias = value
				continue
			}
			if r.kind != 65 {
				continue
			}
			if r.end-r.start < 3 {
				return nil, "", errors.New("short DNS HTTPS record")
			}
			priority := int(binary.BigEndian.Uint16(message[r.start : r.start+2]))
			target, params, err := decodeDNSName(message, r.start+2)
			if err != nil || params > r.end {
				return nil, "", errors.New("invalid HTTPS target")
			}
			if priority == 0 {
				target = canonicalHost(target)
				if !validECHSourceName(target) || params != r.end || alias != "" && alias != target {
					return nil, "", errors.New("invalid HTTPS alias")
				}
				alias = target
				continue
			}
			lastKey := -1
			for params < r.end {
				if params+4 > r.end {
					return nil, "", errors.New("truncated HTTPS parameter")
				}
				key, size := int(binary.BigEndian.Uint16(message[params:params+2])), int(binary.BigEndian.Uint16(message[params+2:params+4]))
				params += 4
				if key <= lastKey || params+size > r.end {
					return nil, "", errors.New("invalid or duplicate HTTPS parameter")
				}
				lastKey = key
				if key == 5 && priority < bestPriority {
					config = append([]byte(nil), message[params:params+size]...)
					bestPriority = priority
				}
				params += size
			}
		}
		if alias != "" && config != nil {
			return nil, "", errors.New("conflicting DNS alias and ECH service records")
		}
		if config != nil {
			return config, "", nil
		}
		if alias == "" {
			if current != name {
				return nil, current, errors.New("ECH alias requires a follow-up query")
			}
			return nil, "", errors.New("DNS HTTPS answer contains no ECH configuration")
		}
		current = alias
	}
	return nil, "", errors.New("DNS CNAME depth exceeded")
}
