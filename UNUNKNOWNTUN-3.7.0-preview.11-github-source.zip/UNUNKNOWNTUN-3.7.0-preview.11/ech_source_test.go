package main

import (
	"bytes"
	"context"
	"crypto/ecdh"
	"crypto/rand"
	"crypto/tls"
	"encoding/base64"
	"encoding/binary"
	"fmt"
	"io"
	"net"
	"net/http"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"golang.org/x/crypto/cryptobyte"
	"golang.org/x/net/http2"
)

func sourceECHFixture() []byte {
	b := cryptobyte.NewBuilder(nil)
	b.AddUint16LengthPrefixed(func(b *cryptobyte.Builder) {
		b.AddUint16(0xfe0d)
		b.AddUint16LengthPrefixed(func(b *cryptobyte.Builder) {
			b.AddUint8(1)
			b.AddUint16(0x20)
			b.AddUint16LengthPrefixed(func(b *cryptobyte.Builder) { b.AddBytes(bytes.Repeat([]byte{7}, 32)) })
			b.AddUint16LengthPrefixed(func(b *cryptobyte.Builder) { b.AddUint16(1); b.AddUint16(1) })
			b.AddUint8(64)
			b.AddUint8LengthPrefixed(func(b *cryptobyte.Builder) { b.AddBytes([]byte("public.example.test")) })
			b.AddUint16(0)
		})
	})
	return b.BytesOrPanic()
}

func sourceECHResponse(query []byte, owner string) []byte {
	response := append([]byte(nil), query...)
	binary.BigEndian.PutUint16(response[2:4], 0x8180)
	binary.BigEndian.PutUint16(response[6:8], 1)
	name, _ := encodeDNSName(owner)
	response = append(response, name...)
	response = append(response, 0, 65, 0, 1, 0, 0, 0, 60)
	rdata := []byte{0, 1, 0, 0, 5}
	config := sourceECHFixture()
	rdata = binary.BigEndian.AppendUint16(rdata, uint16(len(config)))
	rdata = append(rdata, config...)
	response = binary.BigEndian.AppendUint16(response, uint16(len(rdata)))
	return append(response, rdata...)
}

func TestECHSourceParsing(t *testing.T) {
	for _, input := range []string{"", "auto"} {
		s, err := parseECHSource("inner.example.test", input)
		if err != nil || !s.auto {
			t.Fatalf("auto %q: %#v %v", input, s, err)
		}
	}
	for _, input := range []string{"udp://9.9.9.9", "cloudflare-ech.com+udp://9.9.9.9", "tcp://[::1]:8053", "outer.example+https://resolver.example/dns-query"} {
		s, err := parseECHSource("inner.example.test", input)
		if err != nil || s.resolver == nil {
			t.Fatalf("descriptor %q: %v", input, err)
		}
	}
	s, err := parseECHSource("inner.example.test", "cloudflare-ech.com+udp://9.9.9.9")
	if err != nil || s.domain != "cloudflare-ech.com" || s.resolver.Host != "9.9.9.9:53" {
		t.Fatalf("sample descriptor incorrectly split: %#v %v", s, err)
	}
	for _, input := range []string{"http://resolver.example/dns-query", "udp://resolver.example", "udp://9.9.9.9/x", "udp://9.9.9.9:0", "udp://9.9.9.9:65536", "udp://9.9.9.9:", "udp://user:pass@9.9.9.9", "bad_name+udp://9.9.9.9", "https://user:pass@resolver.example/dns-query", "https://resolver.example/#fragment", "udp://9.9.9.9\n-x", "AAAA", "AAL+DQ=="} {
		if _, err := parseECHSource("inner.example.test", input); err == nil {
			t.Errorf("accepted invalid source %q", input)
		}
	}
	if _, err := parseECHSource("127.0.0.1", "udp://9.9.9.9"); err == nil {
		t.Fatal("IP silently used as ECH lookup name")
	}
}

func TestECHManualBase64NoNetwork(t *testing.T) {
	want := sourceECHFixture()
	input := base64.StdEncoding.EncodeToString(want)
	for _, source := range []string{input, "base64:" + input} {
		got, label, err := resolveECHSourceContext(context.Background(), "inner.example.test", source, "unused")
		if err != nil || !bytes.Equal(want, got) || label != "manual ECHConfigList" {
			t.Fatalf("manual: %x %q %v", got, label, err)
		}
	}
	for cut := 0; cut < len(want); cut++ {
		if err := validateManualECHConfig(want[:cut]); err == nil {
			t.Fatalf("accepted truncation at %d", cut)
		}
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, _, err := resolveECHSourceContext(ctx, "inner.example.test", input, ""); err == nil {
		t.Fatal("ignored canceled context")
	}
}

func TestECHSourceResponseRejectsUnrelatedAndMalformed(t *testing.T) {
	query, id, err := makeECHSourceQuery("config.example.test")
	if err != nil {
		t.Fatal(err)
	}
	good := sourceECHResponse(query, "config.example.test")
	if got, _, err := parseECHSourceResponse(good, id, "config.example.test"); err != nil || !bytes.Equal(got, sourceECHFixture()) {
		t.Fatalf("good: %x %v", got, err)
	}
	for cut := 0; cut < len(good); cut++ {
		if _, _, err := parseECHSourceResponse(good[:cut], id, "config.example.test"); err == nil {
			t.Fatalf("accepted cut at %d", cut)
		}
	}
	for _, mutate := range []func([]byte) []byte{
		func(b []byte) []byte { b[0] ^= 1; return b },
		func(b []byte) []byte { b[2] |= 2; return b },
		func(b []byte) []byte { b[3] |= 3; return b },
		func(b []byte) []byte { b[12+1] = 'x'; return b },
		func(b []byte) []byte {
			binary.BigEndian.PutUint16(b[6:8], 0)
			binary.BigEndian.PutUint16(b[10:12], 1)
			return b
		},
		func(b []byte) []byte { return append(b, 0) },
	} {
		if _, _, err := parseECHSourceResponse(mutate(append([]byte(nil), good...)), id, "config.example.test"); err == nil {
			t.Fatal("accepted mutated DNS response")
		}
	}
	if _, _, err := parseECHSourceResponse(sourceECHResponse(query, "unrelated.example.test"), id, "config.example.test"); err == nil {
		t.Fatal("accepted unrelated owner's ECH")
	}
}

func TestECHSourceAliasAndDuplicateParameters(t *testing.T) {
	query, id, _ := makeECHSourceQuery("alias.example.test")
	response := append([]byte(nil), query...)
	binary.BigEndian.PutUint16(response[2:4], 0x8180)
	binary.BigEndian.PutUint16(response[6:8], 1)
	target, _ := encodeDNSName("config.example.test")
	response = append(response, 0xc0, 0x0c, 0, 5, 0, 1, 0, 0, 0, 60)
	response = binary.BigEndian.AppendUint16(response, uint16(len(target)))
	response = append(response, target...)
	_, alias, err := parseECHSourceResponse(response, id, "alias.example.test")
	if err == nil || alias != "config.example.test" {
		t.Fatalf("alias followup = %q %v", alias, err)
	}
	service := sourceECHResponse(query, "config.example.test")
	response = append(response, service[len(query):]...)
	binary.BigEndian.PutUint16(response[6:8], 2)
	config, alias, err := parseECHSourceResponse(response, id, "alias.example.test")
	if err != nil || alias != "" || !bytes.Equal(config, sourceECHFixture()) {
		t.Fatalf("in-message CNAME: %q %v", alias, err)
	}
	// A duplicate ech SvcParam cannot override the first.
	duplicate := sourceECHResponse(query, "alias.example.test")
	_, recordAt, _ := decodeDNSName(duplicate, len(query))
	length := binary.BigEndian.Uint16(duplicate[recordAt+8 : recordAt+10])
	duplicate = append(duplicate, 0, 5, 0, 0)
	binary.BigEndian.PutUint16(duplicate[recordAt+8:recordAt+10], length+4)
	if _, _, err := parseECHSourceResponse(duplicate, id, "alias.example.test"); err == nil {
		t.Fatal("accepted duplicate ech SvcParam")
	}
}

func TestECHSourceUDPAndTCPFallback(t *testing.T) {
	for _, truncated := range []bool{false, true} {
		t.Run(fmt.Sprint(truncated), func(t *testing.T) {
			tcp, err := net.Listen("tcp4", "127.0.0.1:0")
			if err != nil {
				t.Fatal(err)
			}
			defer tcp.Close()
			udp, err := net.ListenPacket("udp4", tcp.Addr().String())
			if err != nil {
				t.Fatal(err)
			}
			defer udp.Close()
			serverErr := make(chan error, 2)
			go func() {
				_ = udp.SetDeadline(time.Now().Add(2 * time.Second))
				buf := make([]byte, 2048)
				n, addr, err := udp.ReadFrom(buf)
				if err != nil {
					serverErr <- err
					return
				}
				response := sourceECHResponse(buf[:n], "config.example.test")
				if truncated {
					response = append([]byte(nil), buf[:n]...)
					binary.BigEndian.PutUint16(response[2:4], 0x8380)
				}
				_, err = udp.WriteTo(response, addr)
				serverErr <- err
			}()
			if truncated {
				go func() {
					_ = tcp.(*net.TCPListener).SetDeadline(time.Now().Add(2 * time.Second))
					conn, err := tcp.Accept()
					if err != nil {
						serverErr <- err
						return
					}
					defer conn.Close()
					_ = conn.SetDeadline(time.Now().Add(2 * time.Second))
					var size [2]byte
					_, err = io.ReadFull(conn, size[:])
					if err != nil {
						serverErr <- err
						return
					}
					query := make([]byte, binary.BigEndian.Uint16(size[:]))
					_, err = io.ReadFull(conn, query)
					if err != nil {
						serverErr <- err
						return
					}
					response := sourceECHResponse(query, "config.example.test")
					_, err = writeFull(conn, append(binary.BigEndian.AppendUint16(nil, uint16(len(response))), response...))
					serverErr <- err
				}()
			}
			config, label, err := resolveECHSourceContext(context.Background(), "inner.example.test", "config.example.test+udp://"+tcp.Addr().String(), "")
			if err != nil || !bytes.Equal(config, sourceECHFixture()) || label != "manual udp resolver" {
				t.Fatalf("UDP truncated=%t: %s %v", truncated, label, err)
			}
			if err := <-serverErr; err != nil {
				t.Fatal(err)
			}
			if truncated {
				if err := <-serverErr; err != nil {
					t.Fatal(err)
				}
			}
		})
	}
}

func TestECHSourceDoHAndPrivateError(t *testing.T) {
	previous := http.DefaultTransport
	defer func() { http.DefaultTransport = previous }()
	const descriptor = "config.example.test+https://resolver.example.test/dns-query?key=private-fixture"
	http.DefaultTransport = probeRoundTripper(func(r *http.Request) (*http.Response, error) {
		query, _ := io.ReadAll(r.Body)
		name, _, _ := decodeDNSName(query, 12)
		if name != "config.example.test" {
			t.Errorf("query name = %q", name)
		}
		return &http.Response{StatusCode: 200, Header: http.Header{"Content-Type": []string{"application/dns-message"}}, Body: io.NopCloser(bytes.NewReader(sourceECHResponse(query, name)))}, nil
	})
	got, _, err := resolveECHSourceContext(context.Background(), "inner.example.test", descriptor, "")
	if err != nil || !bytes.Equal(got, sourceECHFixture()) {
		t.Fatalf("DoH: %v", err)
	}
	http.DefaultTransport = probeRoundTripper(func(r *http.Request) (*http.Response, error) { return nil, fmt.Errorf("synthetic request failure") })
	_, _, err = resolveECHSourceContext(context.Background(), "inner.example.test", descriptor, "")
	if err == nil || strings.Contains(err.Error(), "private-fixture") {
		t.Fatalf("private URL leaked: %v", err)
	}
}

// Independently observe ECHAccepted on a real local TLS server. Parsing a
// manual list or getting a success from an ordinary TLS handshake is not proof.
func TestECHManualSourceAcceptedCarrier(t *testing.T) {
	const inner = "inner.manual.example.test"
	const token = "manual-ech-token-0123456789abcdef"
	key, err := ecdh.X25519().GenerateKey(rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	b := cryptobyte.NewBuilder(nil)
	b.AddUint16(0xfe0d)
	b.AddUint16LengthPrefixed(func(b *cryptobyte.Builder) {
		b.AddUint8(11)
		b.AddUint16(0x20)
		b.AddUint16LengthPrefixed(func(b *cryptobyte.Builder) { b.AddBytes(key.PublicKey().Bytes()) })
		b.AddUint16LengthPrefixed(func(b *cryptobyte.Builder) { b.AddUint16(1); b.AddUint16(1) })
		b.AddUint8(64)
		b.AddUint8LengthPrefixed(func(b *cryptobyte.Builder) { b.AddBytes([]byte("outer.manual.example.test")) })
		b.AddUint16(0)
	})
	config := b.BytesOrPanic()
	list := binary.BigEndian.AppendUint16(nil, uint16(len(config)))
	list = append(list, config...)
	for _, transport := range []string{TransportWSS, TransportXHTTP} {
		t.Run(transport, func(t *testing.T) {
			directory := t.TempDir()
			certFile := filepath.Join(directory, "inner.pem")
			cert, err := loadOrCreateCert(certFile, filepath.Join(directory, "inner.key"), inner, false)
			if err != nil {
				t.Fatal(err)
			}
			cfg := &Config{Mode: "origin", Transport: transport, Token: token, SNI: inner, WSHost: inner,
				WSPath: "/manual/ech-websocket", XHTTPPath: "/manual/ech-xhttp", XHTTPMode: "packet-up",
				UTLSProfile: "chrome", ECHMode: ECHModeStrict, ECHSource: base64.StdEncoding.EncodeToString(list),
				ECHDoH: "https://must-not-be-queried.invalid/dns-query", TLSMinVersion: "1.3", CAFile: certFile}
			limiter := NewAdaptiveRateLimiter(10, 5)
			xhttp := newXHTTPServer(cfg, func(c net.Conn, ip string) { dispatchEgressConn(c, ip, cfg, limiter) })
			defer xhttp.Close()
			alpn := "http/1.1"
			if transport == TransportXHTTP {
				alpn = "h2"
			}
			accepted := make(chan tls.ConnectionState, 1)
			serverErrors := make(chan error, 1)
			finished := make(chan struct{}, 1)
			server := managedTestListener(t, func(raw net.Conn) {
				defer func() { finished <- struct{}{} }()
				defer raw.Close()
				_ = raw.SetDeadline(time.Now().Add(5 * time.Second))
				conn := tls.Server(raw, &tls.Config{Certificates: []tls.Certificate{cert}, MinVersion: tls.VersionTLS13,
					NextProtos: []string{alpn}, EncryptedClientHelloKeys: []tls.EncryptedClientHelloKey{{Config: config, PrivateKey: key.Bytes(), SendAsRetry: true}}})
				if err := conn.Handshake(); err != nil {
					serverErrors <- err
					return
				}
				accepted <- conn.ConnectionState()
				_ = raw.SetDeadline(time.Time{})
				if transport == TransportXHTTP {
					(&http2.Server{}).ServeConn(conn, &http2.ServeConnOpts{Handler: xhttp})
					return
				}
				ws, ip, err := acceptServerWebSocket(conn, inner, cfg.WSPath, token)
				if err != nil {
					serverErrors <- err
					return
				}
				dispatchEgressConn(ws, ip, cfg, limiter)
			})
			cfg.Connect = server.Addr().String()
			streams, memory := activeStreams.Load(), memoryBudget.Load()
			_, label, err := checkTunnelContext(context.Background(), cfg, 5*time.Second)
			if err != nil {
				t.Fatal(err)
			}
			if label != transport+"-ech" {
				t.Fatalf("manual ECH label %q", label)
			}
			select {
			case state := <-accepted:
				if !state.ECHAccepted || state.ServerName != inner || state.NegotiatedProtocol != alpn {
					t.Fatalf("ECH not actually accepted: %+v", state)
				}
			case err := <-serverErrors:
				t.Fatal(err)
			case <-time.After(time.Second):
				t.Fatal("no independently observed ECH acceptance")
			}
			select {
			case <-finished:
			case <-time.After(2 * time.Second):
				t.Fatal("manual ECH carrier did not close")
			}
			waitForStreamBaseline(t, streams, memory)
		})
	}
}
