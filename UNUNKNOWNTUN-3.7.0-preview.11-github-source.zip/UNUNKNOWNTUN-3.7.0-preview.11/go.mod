module ununknowntun

go 1.26.10

require (
	github.com/flynn/noise v1.1.0
	github.com/klauspost/reedsolomon v1.14.2
	github.com/refraction-networking/utls v1.8.2
	golang.org/x/crypto v0.57.0
	golang.org/x/net v0.60.0
	golang.org/x/sys v0.48.0
)

require (
	github.com/andybalholm/brotli v1.0.6 // indirect
	github.com/klauspost/compress v1.18.7 // indirect
	github.com/klauspost/cpuid/v2 v2.3.0 // indirect
	golang.org/x/text v0.42.0 // indirect
)
