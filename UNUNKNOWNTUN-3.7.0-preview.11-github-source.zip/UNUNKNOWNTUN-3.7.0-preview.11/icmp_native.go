package main

// Native ICMP v1 is an independent, exact-peer, authenticated IPv4 underlay.
// It transports only the configured inner TCP carrier; TLS and the UNUNKNOWNTUN
// token remain required above it. It is not ping camouflage or a reflector.
import (
	"bytes"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/netip"
	"path/filepath"
	"sync/atomic"
	"time"
)

const (
	nativeICMPOverhead        = 96 // IPv4 20 + ICMP 8 + native header 36 + HMAC 32.
	nativeICMPQueueLimit      = 256
	nativeICMPCredits         = 64
	nativeICMPExpiry          = 5 * time.Second
	icmpHello            byte = 1
	icmpChallenge        byte = 2
	icmpConfirm          byte = 3
	icmpReady            byte = 4
	icmpData             byte = 5
)

type NativeICMPConfig struct {
	Interface    string `json:"interface"`
	TUNName      string `json:"tun_name"`
	LocalIP      string `json:"local_ip"`
	PeerIP       string `json:"peer_ip"`
	InnerLocalIP string `json:"inner_local_ip"`
	InnerPeerIP  string `json:"inner_peer_ip"`
	MTU          int    `json:"mtu"`
	CarrierPort  int    `json:"carrier_port"`
	Authorized   bool   `json:"authorized"`
	KeyFile      string `json:"key_file"`
	PollMS       int    `json:"poll_ms"`
	Role         string `json:"-"`
	key          [32]byte
	keyLoaded    bool
}

func (c *NativeICMPConfig) GREConfig() *GREConfig {
	if c == nil {
		return nil
	}
	return &GREConfig{Interface: c.Interface, TUNName: c.TUNName, LocalIP: c.LocalIP, PeerIP: c.PeerIP,
		SourceIP: c.LocalIP, ExpectedPeerSourceIP: c.PeerIP, InnerLocalIP: c.InnerLocalIP,
		InnerPeerIP: c.InnerPeerIP, MTU: c.MTU, CarrierPort: c.CarrierPort, Authorized: c.Authorized, Role: c.Role}
}

func (c *NativeICMPConfig) validate() error {
	if c == nil {
		return errors.New("[icmp/config] missing configuration")
	}
	if err := c.GREConfig().validate(); err != nil {
		return fmt.Errorf("[icmp/config] %w", err)
	}
	if c.PollMS < 5 || c.PollMS > 1000 {
		return errors.New("[icmp/config] poll_ms must be 5..1000")
	}
	if !filepath.IsAbs(c.KeyFile) || filepath.Clean(c.KeyFile) != c.KeyFile || bytes.IndexByte([]byte(c.KeyFile), 0) >= 0 {
		return errors.New("[icmp/config] key_file must be a clean absolute path")
	}
	return nil
}

func loadNativeICMPConfig(path, role string) (*NativeICMPConfig, error) {
	f, err := openNativeICMPPrivateFile(path, 16384)
	if err != nil {
		return nil, fmt.Errorf("[icmp/config/file] %w", err)
	}
	defer f.Close()
	data, err := io.ReadAll(io.LimitReader(f, 16385))
	if err != nil {
		return nil, fmt.Errorf("[icmp/config/file] %w", err)
	}
	c, err := parseNativeICMPConfig(data, role)
	if err != nil {
		return nil, err
	}
	if err := c.loadKey(); err != nil {
		return nil, err
	}
	return c, nil
}

func parseNativeICMPConfig(data []byte, role string) (*NativeICMPConfig, error) {
	if len(data) > 16384 {
		return nil, errors.New("[icmp/config] JSON exceeds 16 KiB")
	}
	d := json.NewDecoder(bytes.NewReader(data))
	t, err := d.Token()
	if err != nil || t != json.Delim('{') {
		return nil, errors.New("[icmp/config] expected JSON object")
	}
	allowed := map[string]bool{"interface": true, "tun_name": true, "local_ip": true, "peer_ip": true,
		"inner_local_ip": true, "inner_peer_ip": true, "mtu": true, "carrier_port": true, "authorized": true, "key_file": true, "poll_ms": true}
	seen := make(map[string]bool)
	for d.More() {
		t, err := d.Token()
		if err != nil {
			return nil, fmt.Errorf("[icmp/config] JSON key: %w", err)
		}
		key, ok := t.(string)
		if !ok || !allowed[key] || seen[key] {
			return nil, errors.New("[icmp/config] duplicate or unknown field")
		}
		seen[key] = true
		var value json.RawMessage
		if err := d.Decode(&value); err != nil {
			return nil, fmt.Errorf("[icmp/config] JSON value: %w", err)
		}
		if bytes.Equal(bytes.TrimSpace(value), []byte("null")) {
			return nil, errors.New("[icmp/config] null is not accepted")
		}
	}
	if t, err = d.Token(); err != nil || t != json.Delim('}') {
		return nil, errors.New("[icmp/config] incomplete object")
	}
	if _, err = d.Token(); err != io.EOF {
		return nil, errors.New("[icmp/config] trailing JSON")
	}
	var c NativeICMPConfig
	if err := json.Unmarshal(data, &c); err != nil {
		return nil, fmt.Errorf("[icmp/config] %w", err)
	}
	if !seen["poll_ms"] {
		c.PollMS = 20
	}
	c.Role = role
	if err := c.validate(); err != nil {
		return nil, err
	}
	return &c, nil
}

func (c *NativeICMPConfig) loadKey() error {
	f, err := openNativeICMPPrivateFile(c.KeyFile, 65)
	if err != nil {
		return fmt.Errorf("[icmp/key/file] %w", err)
	}
	defer f.Close()
	data, err := io.ReadAll(io.LimitReader(f, 66))
	if err != nil {
		return errors.New("[icmp/key] unreadable key")
	}
	if len(data) == 65 && data[64] == '\n' {
		data = data[:64]
	}
	if len(data) != 64 {
		return errors.New("[icmp/key] require exactly 64 lowercase hex characters (32 random bytes), optional final LF")
	}
	for _, value := range data {
		if !(value >= '0' && value <= '9' || value >= 'a' && value <= 'f') {
			return errors.New("[icmp/key] require lowercase hexadecimal key")
		}
	}
	if _, err := hex.Decode(c.key[:], data); err != nil {
		return errors.New("[icmp/key] invalid hexadecimal key")
	}
	if c.key == ([32]byte{}) {
		return errors.New("[icmp/key] all-zero key is not permitted")
	}
	c.keyLoaded = true
	return nil
}

type nativeICMPFrame struct {
	kind     byte
	session  [16]byte
	sequence uint64
	body     []byte
}

func nativeICMPKind(kind byte, request bool, n int) bool {
	if request {
		return (kind == icmpHello && n == 0) || (kind == icmpConfirm && n == 16) || (kind == icmpData && (n == 0 || n >= 40))
	}
	return (kind == icmpChallenge && n == 16) || (kind == icmpReady && n == 0) || (kind == icmpData && (n == 0 || n >= 40))
}

func nativeICMPMAC(key []byte, packet []byte) []byte {
	m := hmac.New(sha256.New, key)
	m.Write([]byte("ununknowntun-native-icmp-v1\x00"))
	m.Write(packet[12:20])               // Bind exact source and destination, not mutable IP TTL/ID.
	m.Write(packet[20:22])               // Bind ICMP type/code, excluding checksum.
	m.Write(packet[24 : len(packet)-32]) // Identifier/sequence + native header/body.
	return m.Sum(nil)
}

func encodeNativeICMP(c *NativeICMPConfig, f nativeICMPFrame) ([]byte, error) {
	if err := c.validate(); err != nil {
		return nil, err
	}
	request := c.Role == "origin"
	if !c.keyLoaded || f.session == ([16]byte{}) || f.sequence == 0 || len(f.body) > c.MTU || !nativeICMPKind(f.kind, request, len(f.body)) {
		return nil, errors.New("[icmp/wire] invalid frame or unloaded key")
	}
	if f.kind == icmpData && len(f.body) > 0 {
		if err := validateGREInner(c.GREConfig(), f.body, false); err != nil {
			return nil, err
		}
	}
	p := make([]byte, nativeICMPOverhead+len(f.body))
	p[0] = 0x45
	binary.BigEndian.PutUint16(p[2:4], uint16(len(p)))
	binary.BigEndian.PutUint16(p[4:6], uint16(f.sequence))
	binary.BigEndian.PutUint16(p[6:8], 0x4000)
	p[8] = 64
	p[9] = 1
	src, dst := netip.MustParseAddr(c.LocalIP).As4(), netip.MustParseAddr(c.PeerIP).As4()
	copy(p[12:16], src[:])
	copy(p[16:20], dst[:])
	binary.BigEndian.PutUint16(p[10:12], greChecksum(p[:20]))
	if request {
		p[20] = 8
	}
	copy(p[24:26], f.session[:2])
	binary.BigEndian.PutUint16(p[26:28], uint16(f.sequence))
	copy(p[28:32], "GDI1")
	p[32] = 1
	p[33] = 2
	if request {
		p[33] = 1
	}
	p[34] = f.kind
	copy(p[36:52], f.session[:])
	binary.BigEndian.PutUint64(p[52:60], f.sequence)
	binary.BigEndian.PutUint16(p[60:62], uint16(len(f.body)))
	copy(p[64:], f.body)
	copy(p[len(p)-32:], nativeICMPMAC(c.key[:], p))
	binary.BigEndian.PutUint16(p[22:24], greChecksum(p[20:]))
	return p, nil
}

func decodeNativeICMP(c *NativeICMPConfig, p []byte) (nativeICMPFrame, error) {
	var f nativeICMPFrame
	if err := c.validate(); err != nil {
		return f, err
	}
	if !c.keyLoaded {
		return f, errors.New("[icmp/wire] unloaded key")
	}
	if err := greIPv4Header(p, 1, c.MTU+nativeICMPOverhead); err != nil {
		return f, err
	}
	if len(p) < nativeICMPOverhead {
		return f, errors.New("[icmp/wire] truncated native header")
	}
	if !greSameIP(p[12:16], c.PeerIP) || !greSameIP(p[16:20], c.LocalIP) {
		return f, fmt.Errorf("[icmp/wire] %w", ErrGREIdentityMismatch)
	}
	request := c.Role == "egress"
	wantType, wantDirection := byte(0), byte(2)
	if request {
		wantType, wantDirection = 8, 1
	}
	if p[20] != wantType || p[21] != 0 || greChecksum(p[20:]) != 0 || !bytes.Equal(p[28:32], []byte("GDI1")) || p[32] != 1 || p[33] != wantDirection || p[35] != 0 || p[62] != 0 || p[63] != 0 {
		return f, errors.New("[icmp/wire] wrong direction, header or checksum (automatic kernel echoes are not native replies)")
	}
	f.kind = p[34]
	copy(f.session[:], p[36:52])
	f.sequence = binary.BigEndian.Uint64(p[52:60])
	n := int(binary.BigEndian.Uint16(p[60:62]))
	if n != len(p)-nativeICMPOverhead || f.session == ([16]byte{}) || f.sequence == 0 || !bytes.Equal(p[24:26], f.session[:2]) || binary.BigEndian.Uint16(p[26:28]) != uint16(f.sequence) || !nativeICMPKind(f.kind, request, n) {
		return f, errors.New("[icmp/wire] invalid length, correlation or kind")
	}
	if !hmac.Equal(p[len(p)-32:], nativeICMPMAC(c.key[:], p)) {
		return f, errors.New("[icmp/wire] authentication failed")
	}
	f.body = p[64 : len(p)-32]
	if f.kind == icmpData && len(f.body) > 0 {
		if err := validateGREInner(c.GREConfig(), f.body, true); err != nil {
			return f, err
		}
	}
	return f, nil
}

// A 64-packet sliding replay window permits bounded reordering, never duplicates.
type nativeICMPReplay struct{ highest, bits uint64 }

func (r *nativeICMPReplay) accept(sequence uint64) bool {
	if sequence == 0 {
		return false
	}
	if sequence > r.highest {
		shift := sequence - r.highest
		if shift >= 64 {
			r.bits = 0
		} else {
			r.bits <<= shift
		}
		r.highest = sequence
		r.bits |= 1
		return true
	}
	delta := r.highest - sequence
	if delta >= 64 || r.bits&(uint64(1)<<delta) != 0 {
		return false
	}
	r.bits |= uint64(1) << delta
	return true
}

type nativeICMPQueued struct {
	body []byte
	at   time.Time
}
type nativeICMPQueue struct {
	items       [nativeICMPQueueLimit]nativeICMPQueued
	head, count int
}

func (q *nativeICMPQueue) push(body []byte, now time.Time) bool {
	if q.count == len(q.items) {
		return false
	}
	q.items[(q.head+q.count)%len(q.items)] = nativeICMPQueued{append([]byte(nil), body...), now}
	q.count++
	return true
}
func (q *nativeICMPQueue) pop(now time.Time) (body []byte, dropped uint64) {
	for q.count > 0 {
		item := q.items[q.head]
		q.items[q.head] = nativeICMPQueued{}
		q.head = (q.head + 1) % len(q.items)
		q.count--
		if now.Sub(item.at) > nativeICMPExpiry {
			dropped++
			continue
		}
		return item.body, dropped
	}
	return nil, dropped
}
func (q *nativeICMPQueue) clear() uint64 { n := uint64(q.count); *q = nativeICMPQueue{}; return n }

type nativeICMPPending struct {
	kind byte
	at   time.Time
}
type nativeICMPSession struct {
	id, challenge [16]byte
	replay        nativeICMPReplay
	expires       time.Time
}
type nativeICMPRate struct {
	tokens float64
	at     time.Time
}

func (r *nativeICMPRate) allow(now time.Time, rate, burst float64) bool {
	if r.at.IsZero() {
		r.tokens = burst
		r.at = now
	}
	if now.After(r.at) {
		r.tokens += now.Sub(r.at).Seconds() * rate
		if r.tokens > burst {
			r.tokens = burst
		}
		r.at = now
	}
	if r.tokens < 1 {
		return false
	}
	r.tokens--
	return true
}

type nativeICMPEngine struct {
	config                       NativeICMPConfig
	random                       io.Reader
	session                      [16]byte
	challenge                    [16]byte
	sequence                     uint64
	phase                        byte
	phaseAt, lastReply, nextPoll time.Time
	pending                      map[uint64]nativeICMPPending
	active, candidate            *nativeICMPSession
	queue                        nativeICMPQueue
	receiveRate                  nativeICMPRate
	dropped                      atomic.Uint64
}

func newNativeICMPEngine(c *NativeICMPConfig, now time.Time, random io.Reader) (*nativeICMPEngine, error) {
	if err := c.validate(); err != nil {
		return nil, err
	}
	if !c.keyLoaded {
		return nil, errors.New("[icmp/key] key not loaded")
	}
	if random == nil {
		random = rand.Reader
	}
	e := &nativeICMPEngine{config: *c, random: random, phase: icmpHello, phaseAt: now, lastReply: now, pending: make(map[uint64]nativeICMPPending)}
	if c.Role == "origin" {
		if _, err := io.ReadFull(random, e.session[:]); err != nil {
			return nil, err
		}
		if e.session == ([16]byte{}) {
			return nil, errors.New("[icmp/random] zero session nonce")
		}
	}
	return e, nil
}

func (e *nativeICMPEngine) enqueue(inner []byte, now time.Time) error {
	if err := validateGREInner(e.config.GREConfig(), inner, false); err != nil {
		return err
	}
	if !e.queue.push(inner, now) {
		e.dropped.Add(1)
	}
	return nil
}

func (e *nativeICMPEngine) outgoing(now time.Time) ([]byte, error) {
	if e.config.Role != "origin" || now.Before(e.nextPoll) {
		return nil, nil
	}
	e.nextPoll = now.Add(time.Duration(e.config.PollMS) * time.Millisecond)
	for seq, p := range e.pending {
		if now.Sub(p.at) >= nativeICMPExpiry {
			delete(e.pending, seq)
		}
	}
	if (e.phase == icmpData && now.Sub(e.lastReply) >= nativeICMPExpiry) || (e.phase == icmpConfirm && now.Sub(e.phaseAt) >= nativeICMPExpiry) {
		e.phase = icmpHello
		e.phaseAt = now
		clear(e.pending)
	}
	if len(e.pending) >= nativeICMPCredits {
		return nil, nil
	}
	if e.sequence == ^uint64(0) {
		return nil, errors.New("[icmp/sequence] sequence exhausted; restart underlay")
	}
	e.sequence++
	f := nativeICMPFrame{kind: e.phase, session: e.session, sequence: e.sequence}
	if e.phase == icmpConfirm {
		f.body = e.challenge[:]
	}
	if e.phase == icmpData {
		var drops uint64
		f.body, drops = e.queue.pop(now)
		e.dropped.Add(drops)
	}
	packet, err := encodeNativeICMP(&e.config, f)
	if err != nil {
		return nil, err
	}
	e.pending[f.sequence] = nativeICMPPending{f.kind, now}
	return packet, nil
}

func (e *nativeICMPEngine) receive(packet []byte, now time.Time) (inner, reply []byte, err error) {
	f, err := decodeNativeICMP(&e.config, packet)
	if err != nil {
		return nil, nil, err
	}
	if !e.receiveRate.allow(now, 200, 32) {
		return nil, nil, errors.New("[icmp/rate] authenticated peer rate exceeded")
	}
	if e.config.Role == "origin" {
		pending, ok := e.pending[f.sequence]
		if !ok || f.session != e.session || now.Sub(pending.at) >= nativeICMPExpiry {
			return nil, nil, errors.New("[icmp/replay] unsolicited, expired or consumed reply")
		}
		want := icmpData
		if pending.kind == icmpHello {
			want = icmpChallenge
		}
		if pending.kind == icmpConfirm {
			want = icmpReady
		}
		if f.kind != want {
			return nil, nil, errors.New("[icmp/correlation] reply kind does not match request")
		}
		delete(e.pending, f.sequence)
		if f.kind == icmpChallenge && e.phase == icmpHello {
			copy(e.challenge[:], f.body)
			e.phase = icmpConfirm
			e.phaseAt = now
			clear(e.pending)
		} else if f.kind == icmpReady && e.phase == icmpConfirm {
			e.phase = icmpData
			e.phaseAt = now
			e.lastReply = now
			clear(e.pending)
		} else if f.kind == icmpData && e.phase == icmpData {
			e.lastReply = now
			return f.body, nil, nil
		}
		return nil, nil, nil
	}
	response := nativeICMPFrame{session: f.session, sequence: f.sequence}
	if e.active != nil && f.session == e.active.id {
		if f.kind == icmpConfirm && !hmac.Equal(f.body, e.active.challenge[:]) {
			return nil, nil, errors.New("[icmp/session] wrong confirmation")
		}
		if !e.active.replay.accept(f.sequence) {
			return nil, nil, errors.New("[icmp/replay] duplicate or old request")
		}
		switch f.kind {
		case icmpHello:
			response.kind = icmpChallenge
			response.body = e.active.challenge[:]
		case icmpConfirm:
			response.kind = icmpReady
		case icmpData:
			response.kind = icmpData
			inner = f.body
			var drops uint64
			response.body, drops = e.queue.pop(now)
			e.dropped.Add(drops)
		default:
			return nil, nil, errors.New("[icmp/session] invalid active request")
		}
	} else {
		if e.candidate != nil && !now.Before(e.candidate.expires) {
			e.candidate = nil
		}
		if f.kind == icmpHello {
			if e.candidate == nil {
				e.candidate = &nativeICMPSession{id: f.session, expires: now.Add(3 * time.Second)}
				if _, err := io.ReadFull(e.random, e.candidate.challenge[:]); err != nil {
					e.candidate = nil
					return nil, nil, err
				}
				if e.candidate.challenge == ([16]byte{}) {
					e.candidate = nil
					return nil, nil, errors.New("[icmp/random] zero challenge")
				}
			}
			if f.session != e.candidate.id || !e.candidate.replay.accept(f.sequence) {
				return nil, nil, errors.New("[icmp/session] competing or replayed hello")
			}
			response.kind = icmpChallenge
			response.body = e.candidate.challenge[:]
		} else if f.kind == icmpConfirm && e.candidate != nil && f.session == e.candidate.id && hmac.Equal(f.body, e.candidate.challenge[:]) && e.candidate.replay.accept(f.sequence) {
			e.active = e.candidate
			e.candidate = nil
			e.dropped.Add(e.queue.clear())
			response.kind = icmpReady
		} else {
			return nil, nil, errors.New("[icmp/session] no confirmed session")
		}
	}
	// Exactly one reply per accepted request, immediately consuming that credit.
	// Empty responses are valid; no unsolicited egress transmission is possible.
	reply, err = encodeNativeICMP(&e.config, response)
	return inner, reply, err
}
