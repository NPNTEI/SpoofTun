//go:build !linux && !darwin

package main

import (
	"errors"
	"os"
)

func openNativeICMPPrivateFile(path string, limit int64) (*os.File, error) {
	return nil, errors.New("[icmp/platform] secure native ICMP configuration is supported on Linux/Darwin only; activation requires Linux")
}
