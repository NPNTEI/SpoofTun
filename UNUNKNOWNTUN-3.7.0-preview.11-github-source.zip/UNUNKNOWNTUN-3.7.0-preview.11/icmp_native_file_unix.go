//go:build linux || darwin

package main

import (
	"errors"
	"os"
	"path/filepath"
	"strings"

	"golang.org/x/sys/unix"
)

func openNativeICMPPrivateFile(path string, limit int64) (*os.File, error) {
	if !filepath.IsAbs(path) || filepath.Clean(path) != path || path == "/" || strings.IndexByte(path, 0) >= 0 || limit < 0 {
		return nil, errors.New("require a clean absolute private-file path and nonnegative size limit")
	}
	// Walk by descriptor: O_NOFOLLOW on only the final component would still
	// allow a symlinked parent to redirect the private configuration or key.
	parts := strings.Split(strings.TrimPrefix(path, "/"), "/")
	parent, err := unix.Open("/", unix.O_RDONLY|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)
	if err != nil {
		return nil, errors.New("cannot open private-file parent")
	}
	for _, part := range parts[:len(parts)-1] {
		next, openErr := unix.Openat(parent, part, unix.O_RDONLY|unix.O_DIRECTORY|unix.O_NOFOLLOW|unix.O_CLOEXEC, 0)
		_ = unix.Close(parent)
		if openErr != nil {
			return nil, errors.New("private-file parents must be real directories, without symlinks")
		}
		parent = next
	}
	fd, err := unix.Openat(parent, parts[len(parts)-1], unix.O_RDONLY|unix.O_NONBLOCK|unix.O_NOFOLLOW|unix.O_CLOEXEC, 0)
	_ = unix.Close(parent)
	if err != nil {
		return nil, errors.New("cannot securely open private file (no symlinks allowed)")
	}
	var st unix.Stat_t
	if err := unix.Fstat(fd, &st); err != nil {
		_ = unix.Close(fd)
		return nil, err
	}
	if st.Mode&unix.S_IFMT != unix.S_IFREG || st.Mode&07777 != 0600 || st.Nlink != 1 || st.Uid != uint32(os.Geteuid()) || st.Size > limit {
		_ = unix.Close(fd)
		return nil, errors.New("require effective-user-owned regular single-link file, mode 0600, within size bound; no symlinks")
	}
	f := os.NewFile(uintptr(fd), path)
	if f == nil {
		_ = unix.Close(fd)
		return nil, errors.New("cannot adopt configuration descriptor")
	}
	return f, nil
}
