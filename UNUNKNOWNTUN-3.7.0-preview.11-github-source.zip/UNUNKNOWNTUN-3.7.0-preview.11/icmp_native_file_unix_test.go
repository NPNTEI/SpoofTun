//go:build linux || darwin

package main

import (
	"bytes"
	"io"
	"os"
	"path/filepath"
	"testing"
	"time"

	"golang.org/x/sys/unix"
)

func nativePrivateFileDirectory(t *testing.T) string {
	t.Helper()
	directory, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	return directory
}

func TestNativeICMPPrivateFileRejectsAncestorSymlinksAndUncleanPaths(t *testing.T) {
	directory := nativePrivateFileDirectory(t)
	real := filepath.Join(directory, "real")
	if err := os.Mkdir(real, 0700); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(real, "private")
	if err := os.WriteFile(path, []byte("private fixture"), 0600); err != nil {
		t.Fatal(err)
	}
	alias := filepath.Join(directory, "alias")
	if err := os.Symlink(real, alias); err != nil {
		t.Fatal(err)
	}
	for _, bad := range []string{filepath.Join(alias, "private"), real + "/../real/private", real + "//private", "relative", "/", path + "\x00"} {
		if file, err := openNativeICMPPrivateFile(bad, 100); err == nil {
			_ = file.Close()
			t.Fatalf("accepted redirected/unclean path %q", bad)
		}
	}
	file, err := openNativeICMPPrivateFile(path, 100)
	if err != nil {
		t.Fatal(err)
	}
	defer file.Close()
	got, err := io.ReadAll(file)
	if err != nil || string(got) != "private fixture" {
		t.Fatalf("bounded regular file: %q %v", got, err)
	}
}

func TestNativeICMPPrivateFileRequiresExactModeAndPreservesSizeLimit(t *testing.T) {
	directory := nativePrivateFileDirectory(t)
	path := filepath.Join(directory, "private")
	data := bytes.Repeat([]byte{0x42}, 1024*1024)
	if err := os.WriteFile(path, data, 0600); err != nil {
		t.Fatal(err)
	}
	for _, mode := range []os.FileMode{0000, 0200, 0400, 0700, 0640, 0644, 0600 | os.ModeSetuid, 0600 | os.ModeSetgid, 0600 | os.ModeSticky} {
		if err := os.Chmod(path, mode); err != nil {
			t.Fatal(err)
		}
		info, err := os.Stat(path)
		if err != nil {
			t.Fatal(err)
		}
		if info.Mode()&(os.ModePerm|os.ModeSetuid|os.ModeSetgid|os.ModeSticky) == 0600 {
			// Some restricted filesystems silently strip set-ID bits. There is
			// no unsafe on-disk mode to reject in that case.
			t.Logf("filesystem did not retain requested special mode %v", mode)
			continue
		}
		if file, err := openNativeICMPPrivateFile(path, int64(len(data))); err == nil {
			_ = file.Close()
			t.Fatalf("accepted non-0600 mode %v", mode)
		}
	}
	if err := os.Chmod(path, 0600); err != nil {
		t.Fatal(err)
	}
	for _, limit := range []int64{-1, 65, int64(len(data) - 1)} {
		if file, err := openNativeICMPPrivateFile(path, limit); err == nil {
			_ = file.Close()
			t.Fatalf("ignored size limit %d", limit)
		}
	}
	// Native check's CA snapshot uses the same helper with a 1 MiB limit.
	file, err := openNativeICMPPrivateFile(path, int64(len(data)))
	if err != nil {
		t.Fatal(err)
	}
	defer file.Close()
	got, err := io.ReadAll(file)
	if err != nil || !bytes.Equal(got, data) {
		t.Fatal("1 MiB private CA-like file no longer supported")
	}
}

func TestNativeICMPPrivateFileFIFORejectionIsNonblocking(t *testing.T) {
	directory := nativePrivateFileDirectory(t)
	path := filepath.Join(directory, "fifo")
	if err := unix.Mkfifo(path, 0600); err != nil {
		t.Fatal(err)
	}
	start := time.Now()
	if file, err := openNativeICMPPrivateFile(path, 65); err == nil {
		_ = file.Close()
		t.Fatal("accepted FIFO")
	}
	if time.Since(start) > time.Second {
		t.Fatal("FIFO rejection blocked")
	}
}
