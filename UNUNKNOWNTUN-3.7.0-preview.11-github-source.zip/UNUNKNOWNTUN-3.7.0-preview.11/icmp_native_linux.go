//go:build linux

package main

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/netip"
	"strconv"
	"sync"
	"sync/atomic"
	"time"

	"golang.org/x/sys/unix"
)

type linuxNativeICMPUnderlay struct {
	config                  NativeICMPConfig
	engine                  *nativeICMPEngine
	tunFD, rawFD            int
	peer                    unix.SockaddrInet4
	stop, finished          chan struct{}
	errors                  chan error
	closeOnce               sync.Once
	closeErr                error
	sent, received, dropped atomic.Uint64
	rejections              greRejectionCounters
}

// Setup creates only an exclusive nonpersistent TUN, its two /32 addresses and
// exact peer /32 route. There is no GRE socket, source spoof, default route,
// firewall change, forwarding enablement, module load or host sysctl mutation.
func startNativeICMPUnderlayContext(ctx context.Context, c *NativeICMPConfig) (greUnderlay, error) {
	if err := ctx.Err(); err != nil {
		return nil, fmt.Errorf("[icmp/setup-cancelled] %w", err)
	}
	if err := c.validate(); err != nil {
		return nil, err
	}
	copyConfig := *c
	c = &copyConfig
	if !c.keyLoaded {
		if err := c.loadKey(); err != nil {
			return nil, err
		}
	}
	engine, err := newNativeICMPEngine(c, time.Now(), nil)
	if err != nil {
		return nil, err
	}
	ipPath, err := greTrustedIPExecutable()
	if err != nil {
		return nil, fmt.Errorf("[icmp/setup] %w", err)
	}
	iface, err := net.InterfaceByName(c.Interface)
	if err != nil {
		return nil, fmt.Errorf("[icmp/interface] %w", err)
	}
	if iface.Flags&net.FlagUp == 0 || iface.Flags&(net.FlagLoopback|net.FlagPointToPoint) != 0 {
		return nil, errors.New("[icmp/interface] physical interface must be up, non-loopback and not point-to-point")
	}
	if c.MTU+nativeICMPOverhead > iface.MTU {
		return nil, fmt.Errorf("[icmp/mtu] inner MTU plus %d-byte ICMP overhead exceeds physical MTU %d", nativeICMPOverhead, iface.MTU)
	}
	addresses, err := iface.Addrs()
	if err != nil {
		return nil, fmt.Errorf("[icmp/interface-addresses] %w", err)
	}
	assigned := false
	for _, address := range addresses {
		prefix, err := netip.ParsePrefix(address.String())
		if err == nil && prefix.Addr().String() == c.LocalIP {
			assigned = true
		}
	}
	if !assigned {
		return nil, errors.New("[icmp/interface-addresses] exact local_ip must be assigned to the physical interface; source spoof is not supported")
	}
	interfaces, err := net.Interfaces()
	if err != nil {
		return nil, err
	}
	for _, existing := range interfaces {
		if existing.Name == c.TUNName {
			return nil, errors.New("[icmp/interface-conflict] requested TUN already exists; it will not be adopted or changed")
		}
	}
	rules, err := greRunIPContext(ctx, ipPath, "-j", "-4", "rule", "show")
	if err != nil {
		return nil, err
	}
	if err := greCheckRules(rules); err != nil {
		return nil, err
	}
	routes, err := greRunIPContext(ctx, ipPath, "-j", "-4", "route", "show", "table", "all")
	if err != nil {
		return nil, err
	}
	if err := greCheckRoutes(routes, c.InnerLocalIP, c.InnerPeerIP); err != nil {
		return nil, err
	}
	route, err := greRunIPContext(ctx, ipPath, "-j", "-4", "route", "get", c.PeerIP, "from", c.LocalIP)
	if err != nil {
		return nil, err
	}
	if err := greCheckOuterRoute(route, c.GREConfig()); err != nil {
		return nil, err
	}
	u := &linuxNativeICMPUnderlay{config: *c, engine: engine, tunFD: -1, rawFD: -1, stop: make(chan struct{}), finished: make(chan struct{}), errors: make(chan error, 1)}
	started := false
	defer func() {
		if !started {
			if u.rawFD >= 0 {
				_ = unix.Close(u.rawFD)
			}
			if u.tunFD >= 0 {
				_ = unix.Close(u.tunFD)
			}
		}
	}()
	if err := ctx.Err(); err != nil {
		return nil, fmt.Errorf("[icmp/setup-cancelled] %w", err)
	}
	u.rawFD, err = unix.Socket(unix.AF_INET, unix.SOCK_RAW|unix.SOCK_NONBLOCK|unix.SOCK_CLOEXEC, unix.IPPROTO_ICMP)
	if err != nil {
		return nil, fmt.Errorf("[icmp/raw-socket] CAP_NET_RAW and authorized native ICMP reachability required: %w", err)
	}
	for _, option := range []struct{ level, name, value int }{{unix.IPPROTO_IP, unix.IP_HDRINCL, 1}, {unix.SOL_SOCKET, unix.SO_RCVBUF, 256 * 1024}, {unix.SOL_SOCKET, unix.SO_SNDBUF, 256 * 1024}} {
		if err := unix.SetsockoptInt(u.rawFD, option.level, option.name, option.value); err != nil {
			return nil, fmt.Errorf("[icmp/socket-option] %w", err)
		}
	}
	if err := unix.SetsockoptString(u.rawFD, unix.SOL_SOCKET, unix.SO_BINDTODEVICE, c.Interface); err != nil {
		return nil, fmt.Errorf("[icmp/socket-interface] %w", err)
	}
	local := netip.MustParseAddr(c.LocalIP).As4()
	if err := unix.Bind(u.rawFD, &unix.SockaddrInet4{Addr: local}); err != nil {
		return nil, fmt.Errorf("[icmp/socket-bind] %w", err)
	}
	u.peer.Addr = netip.MustParseAddr(c.PeerIP).As4()
	if err := ctx.Err(); err != nil {
		return nil, fmt.Errorf("[icmp/setup-cancelled] %w", err)
	}
	u.tunFD, err = unix.Open("/dev/net/tun", unix.O_RDWR|unix.O_NONBLOCK|unix.O_CLOEXEC, 0)
	if err != nil {
		return nil, fmt.Errorf("[icmp/tun-open] Linux TUN and CAP_NET_ADMIN required: %w", err)
	}
	ifr, err := unix.NewIfreq(c.TUNName)
	if err != nil {
		return nil, err
	}
	ifr.SetUint16(unix.IFF_TUN | unix.IFF_NO_PI | unix.IFF_TUN_EXCL)
	if err := ctx.Err(); err != nil {
		return nil, fmt.Errorf("[icmp/setup-cancelled] %w", err)
	}
	if err := unix.IoctlIfreq(u.tunFD, unix.TUNSETIFF, ifr); err != nil {
		return nil, fmt.Errorf("[icmp/tun-create] exclusive owned TUN creation failed: %w", err)
	}
	if ifr.Name() != c.TUNName {
		return nil, errors.New("[icmp/tun-create] unexpected interface name")
	}
	if err := unix.IoctlSetInt(u.tunFD, unix.TUNSETOFFLOAD, 0); err != nil {
		return nil, fmt.Errorf("[icmp/tun-offload] %w", err)
	}
	for _, args := range [][]string{
		{"-4", "address", "add", c.InnerLocalIP + "/32", "peer", c.InnerPeerIP + "/32", "dev", c.TUNName, "noprefixroute"},
		{"link", "set", "dev", c.TUNName, "mtu", strconv.Itoa(c.MTU), "up"},
		{"-4", "route", "add", c.InnerPeerIP + "/32", "dev", c.TUNName, "src", c.InnerLocalIP, "scope", "link"},
	} {
		if _, err := greRunIPContext(ctx, ipPath, args...); err != nil {
			return nil, err
		}
	}
	if err := ctx.Err(); err != nil {
		return nil, fmt.Errorf("[icmp/setup-cancelled] %w", err)
	}
	started = true
	go u.run(ctx)
	return u, nil
}

func (u *linuxNativeICMPUnderlay) Errors() <-chan error { return u.errors }
func (u *linuxNativeICMPUnderlay) Stats() GREStats {
	s := u.rejections.snapshot()
	s.Sent = u.sent.Load()
	s.Received = u.received.Load()
	s.Dropped = u.dropped.Load() + u.engine.dropped.Load()
	return s
}
func (u *linuxNativeICMPUnderlay) Close() error {
	u.closeOnce.Do(func() { close(u.stop) })
	<-u.finished
	return u.closeErr
}

func (u *linuxNativeICMPUnderlay) run(ctx context.Context) {
	defer func() { u.closeErr = errors.Join(unix.Close(u.rawFD), unix.Close(u.tunFD)); close(u.finished) }()
	fail := func(stage string, err error) {
		select {
		case u.errors <- fmt.Errorf("[icmp/%s] %w", stage, err):
		default:
		}
	}
	send := func(packet []byte) bool {
		if len(packet) == 0 {
			return true
		}
		err := unix.Sendto(u.rawFD, packet, unix.MSG_DONTWAIT, &u.peer)
		if greWouldBlock(err) || errors.Is(err, unix.ENOBUFS) {
			u.dropped.Add(1)
			return true
		}
		if err != nil {
			fail("raw-send", err)
			return false
		}
		u.sent.Add(1)
		return true
	}
	innerBuffer := make([]byte, u.config.MTU+1)
	outerBuffer := make([]byte, u.config.MTU+nativeICMPOverhead)
	var rawRate nativeICMPRate
	var rawResume time.Time
	fds := []unix.PollFd{{Fd: int32(u.tunFD), Events: unix.POLLIN}, {Fd: int32(u.rawFD), Events: unix.POLLIN}}
	for {
		select {
		case <-ctx.Done():
			return
		case <-u.stop:
			return
		default:
		}
		now := time.Now()
		timeout := 100 * time.Millisecond
		if u.config.Role == "origin" {
			until := u.engine.nextPoll.Sub(now)
			if until < 0 {
				until = 0
			}
			if until < timeout {
				timeout = until
			}
		}
		fds[1].Events = unix.POLLIN
		if now.Before(rawResume) {
			fds[1].Events = 0
			if delay := rawResume.Sub(now); delay < timeout {
				timeout = delay
			}
		}
		milliseconds := int((timeout + time.Millisecond - 1) / time.Millisecond)
		_, err := unix.Poll(fds, milliseconds)
		if errors.Is(err, unix.EINTR) {
			continue
		}
		if err != nil {
			fail("poll", err)
			return
		}
		select {
		case <-ctx.Done():
			return
		case <-u.stop:
			return
		default:
		}
		for _, fd := range fds {
			if fd.Revents&(unix.POLLERR|unix.POLLHUP|unix.POLLNVAL) != 0 {
				fail("descriptor", fmt.Errorf("unavailable packet descriptor: flags=%d", fd.Revents))
				return
			}
		}
		if fds[0].Revents&unix.POLLIN != 0 {
			for batch := 0; batch < 32; batch++ {
				n, err := unix.Read(u.tunFD, innerBuffer)
				if greWouldBlock(err) {
					break
				}
				if err != nil {
					fail("tun-read", err)
					return
				}
				if n == 0 {
					fail("tun-read", errors.New("unexpected end of TUN stream"))
					return
				}
				if n > u.config.MTU {
					u.rejections.rejectTX()
					continue
				}
				if err := u.engine.enqueue(innerBuffer[:n], time.Now()); err != nil {
					u.rejections.rejectTX()
				}
			}
		}
		if fds[1].Revents&unix.POLLIN != 0 {
			for batch := 0; batch < 32; batch++ {
				if !rawRate.allow(time.Now(), 1000, 64) {
					rawResume = time.Now().Add(2 * time.Millisecond)
					break
				}
				n, _, flags, _, err := unix.Recvmsg(u.rawFD, outerBuffer, nil, unix.MSG_DONTWAIT|unix.MSG_TRUNC)
				if greWouldBlock(err) {
					break
				}
				if err != nil {
					fail("raw-receive", err)
					return
				}
				if n > len(outerBuffer) || flags&unix.MSG_TRUNC != 0 {
					u.rejections.rejectRX(nil, true)
					continue
				}
				inner, reply, err := u.engine.receive(outerBuffer[:n], time.Now())
				if err != nil {
					u.rejections.rejectRX(err, false)
					continue
				}
				u.received.Add(1)
				if len(inner) > 0 {
					written, err := unix.Write(u.tunFD, inner)
					if greWouldBlock(err) || errors.Is(err, unix.ENOBUFS) {
						u.dropped.Add(1)
					} else if err != nil {
						fail("tun-write", err)
						return
					} else if written != len(inner) {
						fail("tun-write", errors.New("short inner packet write"))
						return
					}
				}
				if !send(reply) {
					return
				}
			}
		}
		packet, err := u.engine.outgoing(time.Now())
		if err != nil {
			fail("protocol", err)
			return
		}
		if !send(packet) {
			return
		}
	}
}
