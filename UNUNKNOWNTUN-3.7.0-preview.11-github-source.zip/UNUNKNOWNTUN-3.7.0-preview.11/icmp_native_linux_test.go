//go:build linux

package main

import (
	"bytes"
	"context"
	"golang.org/x/sys/unix"
	"sync"
	"testing"
	"time"
)

// Only local pipes: no network socket, TUN, route or privileged action.
func TestNativeICMPLinuxCancellationClosesOwnedDescriptors(t *testing.T) {
	_, c := nativeICMPTestPair()
	engine, err := newNativeICMPEngine(c, time.Now(), bytes.NewReader(bytes.Repeat([]byte{3}, 32)))
	if err != nil {
		t.Fatal(err)
	}
	tun, raw := make([]int, 2), make([]int, 2)
	if err := unix.Pipe2(tun, unix.O_NONBLOCK|unix.O_CLOEXEC); err != nil {
		t.Fatal(err)
	}
	defer unix.Close(tun[1])
	if err := unix.Pipe2(raw, unix.O_NONBLOCK|unix.O_CLOEXEC); err != nil {
		unix.Close(tun[0])
		t.Fatal(err)
	}
	defer unix.Close(raw[1])
	u := &linuxNativeICMPUnderlay{config: *c, engine: engine, tunFD: tun[0], rawFD: raw[0], stop: make(chan struct{}), finished: make(chan struct{}), errors: make(chan error, 1)}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	go u.run(ctx)
	time.Sleep(10 * time.Millisecond)
	cancel()
	select {
	case <-u.finished:
	case <-time.After(time.Second):
		t.Fatal("context cancellation did not stop owned worker")
	}
	var wg sync.WaitGroup
	for i := 0; i < 8; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if err := u.Close(); err != nil {
				t.Error(err)
			}
		}()
	}
	wg.Wait()
	if u.Stats() != (GREStats{}) {
		t.Fatal("idle worker generated packet counters")
	}
	for _, fd := range []int{tun[0], raw[0]} {
		if _, err := unix.FcntlInt(uintptr(fd), unix.F_GETFD, 0); err != unix.EBADF {
			t.Fatalf("descriptor retained after cancellation: %v", err)
		}
	}
}
