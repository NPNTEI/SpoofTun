//go:build !linux

package main

import (
	"context"
	"errors"
)

func startNativeICMPUnderlayContext(ctx context.Context, c *NativeICMPConfig) (greUnderlay, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	return nil, errors.New("[icmp/platform] native ICMP/TUN underlay requires Linux; no network state changed")
}
