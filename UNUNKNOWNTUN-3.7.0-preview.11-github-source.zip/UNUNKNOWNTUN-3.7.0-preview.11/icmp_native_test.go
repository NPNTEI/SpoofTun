package main

import (
	"bytes"
	"context"
	"encoding/binary"
	"encoding/json"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func nativeICMPTestPair() (*NativeICMPConfig, *NativeICMPConfig) {
	a, b := greTestConfigPair()
	convert := func(g *GREConfig) *NativeICMPConfig {
		c := &NativeICMPConfig{Interface: g.Interface, TUNName: g.TUNName, LocalIP: g.LocalIP, PeerIP: g.PeerIP, InnerLocalIP: g.InnerLocalIP, InnerPeerIP: g.InnerPeerIP, MTU: 1200, CarrierPort: g.CarrierPort, Authorized: true, KeyFile: "/tmp/ununknowntun-native-icmp-test.key", PollMS: 20, Role: g.Role, keyLoaded: true}
		for i := range c.key {
			c.key[i] = byte(i + 1)
		}
		return c
	}
	return convert(a), convert(b)
}

func nativeICMPTestFrame(c *NativeICMPConfig, kind byte, seq uint64, body []byte) nativeICMPFrame {
	f := nativeICMPFrame{kind: kind, sequence: seq, body: body}
	copy(f.session[:], bytes.Repeat([]byte{1}, 16))
	return f
}
func nativeICMPEncoded(t *testing.T, c *NativeICMPConfig, f nativeICMPFrame) []byte {
	t.Helper()
	p, err := encodeNativeICMP(c, f)
	if err != nil {
		t.Fatal(err)
	}
	return p
}
func nativeICMPFixICMP(p []byte) {
	p[22], p[23] = 0, 0
	binary.BigEndian.PutUint16(p[22:24], greTestChecksum(p[20:]))
}

func TestNativeICMPConfigStrictAndNoSpoof(t *testing.T) {
	c, _ := nativeICMPTestPair()
	data, _ := json.Marshal(c)
	got, err := parseNativeICMPConfig(data, "origin")
	if err != nil {
		t.Fatal(err)
	}
	if g := got.GREConfig(); g.SourceIP != c.LocalIP || g.ExpectedPeerSourceIP != c.PeerIP {
		t.Fatal("adapter enabled source spoof")
	}
	if (*NativeICMPConfig)(nil).GREConfig() != nil {
		t.Fatal("nil adapter")
	}
	var fields map[string]any
	_ = json.Unmarshal(data, &fields)
	delete(fields, "poll_ms")
	defaulted, _ := json.Marshal(fields)
	got, err = parseNativeICMPConfig(defaulted, "origin")
	if err != nil || got.PollMS != 20 {
		t.Fatalf("default poll: %v %v", got, err)
	}
	for _, field := range []string{"source_ip", "expected_peer_source_ip", "Interface", "unknown"} {
		bad := append(append([]byte(nil), data[:len(data)-1]...), []byte(`,"`+field+`":"192.0.2.99"}`)...)
		if _, err := parseNativeICMPConfig(bad, "origin"); err == nil {
			t.Fatalf("accepted %s", field)
		}
	}
	for _, bad := range []string{`[]`, `null`, string(data) + `{}`, strings.Replace(string(data), `"poll_ms":20`, `"poll_ms":20,"poll_ms":21`, 1), strings.Replace(string(data), `"poll_ms":20`, `"poll_ms":null`, 1), strings.Replace(string(data), `"poll_ms":20`, `"poll_ms":"20"`, 1), strings.Repeat(" ", 16385)} {
		if _, err := parseNativeICMPConfig([]byte(bad), "origin"); err == nil {
			t.Fatalf("accepted invalid JSON %.100s", bad)
		}
	}
	for name, mutate := range map[string]func(*NativeICMPConfig){
		"authorization": func(c *NativeICMPConfig) { c.Authorized = false }, "role": func(c *NativeICMPConfig) { c.Role = "relay" }, "mtu": func(c *NativeICMPConfig) { c.MTU = 1401 },
		"peer": func(c *NativeICMPConfig) { c.PeerIP = "example.com" }, "same-peer": func(c *NativeICMPConfig) { c.PeerIP = c.LocalIP }, "inner": func(c *NativeICMPConfig) { c.InnerPeerIP = "8.8.8.8" },
		"low-poll": func(c *NativeICMPConfig) { c.PollMS = 4 }, "high-poll": func(c *NativeICMPConfig) { c.PollMS = 1001 }, "key-relative": func(c *NativeICMPConfig) { c.KeyFile = "key" },
		"key-clean": func(c *NativeICMPConfig) { c.KeyFile = "/tmp/../key" }, "interface": func(c *NativeICMPConfig) { c.Interface = "lo" }, "port": func(c *NativeICMPConfig) { c.CarrierPort = 80 },
	} {
		t.Run(name, func(t *testing.T) {
			copy := *c
			mutate(&copy)
			if copy.validate() == nil {
				t.Fatal("accepted unsafe config")
			}
		})
	}
}

func TestNativeICMPPrivateKeyAndConfigFiles(t *testing.T) {
	c, _ := nativeICMPTestPair()
	dir, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	c.KeyFile = filepath.Join(dir, "icmp.key")
	configPath := filepath.Join(dir, "icmp.json")
	key := strings.Repeat("ab", 32) + "\n"
	if err := os.WriteFile(c.KeyFile, []byte(key), 0600); err != nil {
		t.Fatal(err)
	}
	data, _ := json.Marshal(c)
	if err := os.WriteFile(configPath, data, 0600); err != nil {
		t.Fatal(err)
	}
	loaded, err := loadNativeICMPConfig(configPath, "origin")
	if err != nil || !loaded.keyLoaded || loaded.key[0] != 0xab {
		t.Fatalf("load: %v %v", loaded, err)
	}
	for _, bad := range []string{strings.Repeat("0", 64), "short", strings.Repeat("x", 64), strings.Repeat("AB", 32), strings.Repeat("aB", 32), key + "\n"} {
		if err := os.WriteFile(c.KeyFile, []byte(bad), 0600); err != nil {
			t.Fatal(err)
		}
		if _, err := loadNativeICMPConfig(configPath, "origin"); err == nil {
			t.Fatal("accepted invalid secret")
		}
	}
	if err := os.WriteFile(c.KeyFile, []byte(strings.TrimSuffix(key, "\n")), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := loadNativeICMPConfig(configPath, "origin"); err != nil {
		t.Fatalf("valid lowercase key without optional LF rejected: %v", err)
	}
	_ = os.WriteFile(c.KeyFile, []byte(key), 0600)
	if err := os.Chmod(c.KeyFile, 0644); err != nil {
		t.Fatal(err)
	}
	if _, err := loadNativeICMPConfig(configPath, "origin"); err == nil {
		t.Fatal("accepted exposed key")
	}
	_ = os.Chmod(c.KeyFile, 0600)
	link := filepath.Join(dir, "hardlink")
	if err := os.Link(c.KeyFile, link); err != nil {
		t.Fatal(err)
	}
	if _, err := loadNativeICMPConfig(configPath, "origin"); err == nil {
		t.Fatal("accepted hardlinked key")
	}
	_ = os.Remove(link)
	symlink := filepath.Join(dir, "symlink")
	if err := os.Symlink(c.KeyFile, symlink); err != nil {
		t.Fatal(err)
	}
	c.KeyFile = symlink
	data, _ = json.Marshal(c)
	_ = os.WriteFile(configPath, data, 0600)
	if _, err := loadNativeICMPConfig(configPath, "origin"); err == nil {
		t.Fatal("accepted symlink key")
	}
	if _, err := loadNativeICMPConfig(symlink, "origin"); err == nil {
		t.Fatal("accepted symlink config")
	}
}

func TestNativeICMPWireRoundTripAndExactPeers(t *testing.T) {
	a, b := nativeICMPTestPair()
	for _, pair := range [][2]*NativeICMPConfig{{a, b}, {b, a}} {
		for _, body := range [][]byte{nil, greTestInner(pair[0].GREConfig(), []byte("odd")), greTestInner(pair[0].GREConfig(), bytes.Repeat([]byte{0x42}, 1160))} {
			p := nativeICMPEncoded(t, pair[0], nativeICMPTestFrame(pair[0], icmpData, 0x10001, body))
			if len(p) != nativeICMPOverhead+len(body) || p[9] != 1 || greTestChecksum(p[:20]) != 0 || greTestChecksum(p[20:]) != 0 {
				t.Fatal("wire/checksum mismatch")
			}
			wantType := byte(0)
			if pair[0].Role == "origin" {
				wantType = 8
			}
			if p[20] != wantType || p[21] != 0 {
				t.Fatal("not ICMP echo request/reply")
			}
			if !greSameIP(p[12:16], pair[0].LocalIP) || !greSameIP(p[16:20], pair[0].PeerIP) {
				t.Fatal("outer address was spoofed")
			}
			f, err := decodeNativeICMP(pair[1], p)
			if err != nil || !bytes.Equal(f.body, body) || f.sequence != 0x10001 {
				t.Fatalf("decode %v", err)
			}
		}
	}
}

func TestNativeICMPRejectsKernelAutoEcho(t *testing.T) {
	a, _ := nativeICMPTestPair()
	p := nativeICMPEncoded(t, a, nativeICMPTestFrame(a, icmpHello, 1, nil))
	src := append([]byte(nil), p[12:16]...)
	copy(p[12:16], p[16:20])
	copy(p[16:20], src)
	p[20] = 0
	greTestFixIPv4(p)
	nativeICMPFixICMP(p)
	if _, err := decodeNativeICMP(a, p); err == nil {
		t.Fatal("kernel reflected request accepted as authenticated reply")
	}
	// Even changing the visible direction cannot fix the authenticated type/IPs.
	p[33] = 2
	p[34] = icmpReady
	nativeICMPFixICMP(p)
	if _, err := decodeNativeICMP(a, p); err == nil {
		t.Fatal("forged autoecho direction accepted")
	}
}

func TestNativeICMPWireRejectsTamperAndBounds(t *testing.T) {
	a, b := nativeICMPTestPair()
	valid := nativeICMPEncoded(t, a, nativeICMPTestFrame(a, icmpData, 7, greTestInner(a.GREConfig(), []byte("payload"))))
	for name, edit := range map[string]func([]byte) []byte{
		"short": func(p []byte) []byte { return p[:30] }, "truncated": func(p []byte) []byte { return p[:len(p)-1] }, "extra": func(p []byte) []byte { return append(p, 0) },
		"outer-source": func(p []byte) []byte { p[15] ^= 1; greTestFixIPv4(p); return p }, "outer-protocol": func(p []byte) []byte { p[9] = 47; greTestFixIPv4(p); return p },
		"icmp-type": func(p []byte) []byte { p[20] = 0; nativeICMPFixICMP(p); return p }, "icmp-code": func(p []byte) []byte { p[21] = 1; nativeICMPFixICMP(p); return p },
		"identifier": func(p []byte) []byte { p[24] ^= 1; nativeICMPFixICMP(p); return p }, "sequence": func(p []byte) []byte { p[27] ^= 1; nativeICMPFixICMP(p); return p },
		"reserved": func(p []byte) []byte { p[63] = 1; nativeICMPFixICMP(p); return p }, "length": func(p []byte) []byte { p[61]++; nativeICMPFixICMP(p); return p },
		"mac": func(p []byte) []byte { p[len(p)-1] ^= 1; nativeICMPFixICMP(p); return p }, "body": func(p []byte) []byte { p[85] ^= 1; nativeICMPFixICMP(p); return p },
	} {
		t.Run(name, func(t *testing.T) {
			if _, err := decodeNativeICMP(b, edit(append([]byte(nil), valid...))); err == nil {
				t.Fatal("accepted malformed wire")
			}
		})
	}
	wrongKey := *b
	wrongKey.key[0] ^= 1
	if _, err := decodeNativeICMP(&wrongKey, valid); err == nil {
		t.Fatal("wrong key accepted")
	}
	wrongInner := greTestInner(a.GREConfig(), nil)
	wrongInner[19] ^= 1
	greTestFixIPv4(wrongInner)
	greTestFixTCP(wrongInner)
	if _, err := encodeNativeICMP(a, nativeICMPTestFrame(a, icmpData, 1, wrongInner)); err == nil {
		t.Fatal("arbitrary inner target accepted")
	}
	if _, err := encodeNativeICMP(a, nativeICMPTestFrame(a, icmpData, 1, make([]byte, a.MTU+1))); err == nil {
		t.Fatal("oversized body")
	}
}

func nativeICMPEngines(t *testing.T) (*nativeICMPEngine, *nativeICMPEngine, time.Time) {
	t.Helper()
	a, b := nativeICMPTestPair()
	now := time.Unix(100, 0)
	o, err := newNativeICMPEngine(a, now, bytes.NewReader(bytes.Repeat([]byte{1}, 128)))
	if err != nil {
		t.Fatal(err)
	}
	var challenges []byte
	for value := byte(2); value < 10; value++ {
		challenges = append(challenges, bytes.Repeat([]byte{value}, 16)...)
	}
	e, err := newNativeICMPEngine(b, now, bytes.NewReader(challenges))
	if err != nil {
		t.Fatal(err)
	}
	return o, e, now
}
func nativeICMPTick(t *testing.T, o, e *nativeICMPEngine, now time.Time) ([]byte, []byte, []byte) {
	t.Helper()
	p, err := o.outgoing(now)
	if err != nil || len(p) == 0 {
		t.Fatalf("request: %v", err)
	}
	up, r, err := e.receive(p, now)
	if err != nil || len(r) == 0 {
		t.Fatalf("reply: %v", err)
	}
	down, _, err := o.receive(r, now)
	if err != nil {
		t.Fatal(err)
	}
	return up, down, p
}
func nativeICMPHandshake(t *testing.T, o, e *nativeICMPEngine, now time.Time) time.Time {
	t.Helper()
	nativeICMPTick(t, o, e, now)
	now = now.Add(20 * time.Millisecond)
	nativeICMPTick(t, o, e, now)
	if o.phase != icmpData || e.active == nil {
		t.Fatal("handshake not confirmed")
	}
	return now.Add(20 * time.Millisecond)
}

func TestNativeICMPSessionPayloadFIFOAndIdle(t *testing.T) {
	o, e, now := nativeICMPEngines(t)
	now = nativeICMPHandshake(t, o, e, now)
	for i := 0; i < 8; i++ {
		for _, engine := range []*nativeICMPEngine{o, e} {
			if err := engine.enqueue(greTestInner(engine.config.GREConfig(), []byte{byte(i)}), now); err != nil {
				t.Fatal(err)
			}
		}
	}
	for i := 0; i < 20; i++ {
		up, down, _ := nativeICMPTick(t, o, e, now)
		if i < 8 {
			if up[len(up)-1] != byte(i) || down[len(down)-1] != byte(i) {
				t.Fatal("FIFO payload changed")
			}
		} else if len(up) > 0 || len(down) > 0 {
			t.Fatal("idle peer generated client data")
		}
		now = now.Add(20 * time.Millisecond)
	}
	if o.queue.count != 0 || e.queue.count != 0 || len(o.pending) != 0 {
		t.Fatal("unbounded retained data")
	}
}

func TestNativeICMPReplayCorrelationAndLateReplies(t *testing.T) {
	o, e, now := nativeICMPEngines(t)
	now = nativeICMPHandshake(t, o, e, now)
	p, _ := o.outgoing(now)
	_, reply, err := e.receive(p, now)
	if err != nil {
		t.Fatal(err)
	}
	if _, _, err := e.receive(p, now); err == nil {
		t.Fatal("request replay created another reply credit")
	}
	if _, _, err := o.receive(reply, now); err != nil {
		t.Fatal(err)
	}
	if _, _, err := o.receive(reply, now); err == nil {
		t.Fatal("reply replay accepted")
	}
	now = now.Add(20 * time.Millisecond)
	p, _ = o.outgoing(now)
	_, reply, err = e.receive(p, now)
	if err != nil {
		t.Fatal(err)
	}
	if _, _, err := o.receive(reply, now.Add(nativeICMPExpiry)); err == nil {
		t.Fatal("expired reply accepted")
	}
	forged := nativeICMPTestFrame(&e.config, icmpData, 9999, nil)
	forged.session = o.session
	if _, _, err := o.receive(nativeICMPEncoded(t, &e.config, forged), now); err == nil {
		t.Fatal("unsolicited signed reply accepted")
	}
}

func TestNativeICMPSessionReplacementNeedsFreshChallenge(t *testing.T) {
	o, e, now := nativeICMPEngines(t)
	hello, _ := o.outgoing(now)
	_, challenge, err := e.receive(hello, now)
	if err != nil {
		t.Fatal(err)
	}
	_, _, err = o.receive(challenge, now)
	if err != nil {
		t.Fatal(err)
	}
	now = now.Add(20 * time.Millisecond)
	oldConfirm, _ := o.outgoing(now)
	_, ready, err := e.receive(oldConfirm, now)
	if err != nil {
		t.Fatal(err)
	}
	_, _, _ = o.receive(ready, now)
	other, err := newNativeICMPEngine(&o.config, now, bytes.NewReader(bytes.Repeat([]byte{9}, 16)))
	if err != nil {
		t.Fatal(err)
	}
	now = now.Add(20 * time.Millisecond)
	nativeICMPHandshake(t, other, e, now)
	active := e.active.id
	// An old hello may receive a new challenge, but cannot activate old data.
	now = now.Add(time.Second)
	_, _, _ = e.receive(hello, now)
	if _, _, err := e.receive(oldConfirm, now); err == nil {
		t.Fatal("captured old confirmation replaced current session")
	}
	if e.active.id != active {
		t.Fatal("unauthenticated replacement changed active session")
	}
}

func TestNativeICMPQueueCreditExpiryAndRateBounds(t *testing.T) {
	o, e, now := nativeICMPEngines(t)
	now = nativeICMPHandshake(t, o, e, now)
	inner := greTestInner(o.config.GREConfig(), nil)
	for i := 0; i < nativeICMPQueueLimit+10; i++ {
		if err := o.enqueue(inner, now); err != nil {
			t.Fatal(err)
		}
	}
	if o.queue.count != nativeICMPQueueLimit || o.dropped.Load() != 10 {
		t.Fatal("queue is not bounded")
	}
	o.config.PollMS = 5
	for i := 0; i < 100; i++ {
		_, err := o.outgoing(now.Add(time.Duration(i) * 5 * time.Millisecond))
		if err != nil {
			t.Fatal(err)
		}
	}
	if len(o.pending) != nativeICMPCredits {
		t.Fatalf("pending=%d", len(o.pending))
	}
	_, _ = o.outgoing(now.Add(6 * time.Second))
	if len(o.pending) > 1 || o.phase != icmpHello {
		t.Fatal("lost peer did not expire credits/re-negotiate")
	}
	var q nativeICMPQueue
	q.push([]byte{1}, now)
	q.push([]byte{2}, now.Add(6*time.Second))
	body, drops := q.pop(now.Add(6 * time.Second))
	if drops != 1 || !bytes.Equal(body, []byte{2}) {
		t.Fatal("queue TTL/FIFO broken")
	}
	var rate nativeICMPRate
	for i := 0; i < 32; i++ {
		if !rate.allow(now, 200, 32) {
			t.Fatal("early rate rejection")
		}
	}
	if rate.allow(now, 200, 32) {
		t.Fatal("unbounded burst")
	}
	if !rate.allow(now.Add(time.Second), 200, 32) {
		t.Fatal("rate never recovered")
	}
}

func TestNativeICMPReplayWindowReordering(t *testing.T) {
	var r nativeICMPReplay
	for _, n := range []uint64{5, 7, 6, 100, 99} {
		if !r.accept(n) {
			t.Fatalf("rejected fresh sequence %d", n)
		}
	}
	for _, n := range []uint64{0, 5, 7, 99, 100} {
		if r.accept(n) {
			t.Fatalf("accepted replay %d", n)
		}
	}
}

func TestNativeICMPPreCanceledSetupHasNoSideEffects(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := startNativeICMPUnderlayContext(ctx, nil); !errors.Is(err, context.Canceled) {
		t.Fatalf("expected cancellation before platform/setup: %v", err)
	}
}

func FuzzNativeICMPDecode(f *testing.F) {
	a, b := nativeICMPTestPair()
	p, _ := encodeNativeICMP(a, nativeICMPTestFrame(a, icmpHello, 1, nil))
	f.Add(p)
	f.Add([]byte{0})
	f.Fuzz(func(t *testing.T, p []byte) {
		if len(p) > 65536 {
			t.Skip()
		}
		_, _ = decodeNativeICMP(b, p)
	})
}
