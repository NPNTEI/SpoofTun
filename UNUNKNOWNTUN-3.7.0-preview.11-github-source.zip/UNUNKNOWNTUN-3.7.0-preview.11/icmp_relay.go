package main

// This adapter transports bounded Echo requests over an existing authenticated
// UNUNKNOWNTUN TCP stream. It is not an ICMP carrier, arbitrary IP relay, or TUN.
import (
	"bytes"
	"context"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/netip"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	icmpRelayMaxFrame        = 512
	icmpRelayMaxPayload      = 256
	icmpRelayMaxProbes       = 10
	icmpRelayMaxClients      = 4
	icmpRelayLifetime        = 120 * time.Second
	icmpRelayChallenge  byte = 1
	icmpRelayAuth       byte = 2
	icmpRelayReady      byte = 3
	icmpRelayRequest    byte = 4
	icmpRelayResponse   byte = 5
)

type icmpRelayConfig struct {
	Role         string `json:"role"`
	Target       string `json:"target"`
	KeyFile      string `json:"key_file"`
	Authorized   bool   `json:"authorized"`
	TimeoutMS    int    `json:"timeout_ms"`
	Listen       string `json:"listen"`
	Connect      string `json:"connect"`
	Count        int    `json:"count"`
	IntervalMS   int    `json:"interval_ms"`
	PayloadBytes int    `json:"payload_bytes"`
	address      netip.Addr
	key          [32]byte
}

// ICMPPingResult reports actual matched Echo replies, not carrier health or an
// HTTP/TLS connection check. A failed probe returns this partial result + error.
type ICMPPingResult struct {
	Target   string          `json:"target"`
	Sent     int             `json:"sent"`
	Received int             `json:"received"`
	Replies  []ICMPPingReply `json:"replies"`
	Scope    string          `json:"scope"`
}

type ICMPPingReply struct {
	Sequence  int     `json:"sequence"`
	Bytes     int     `json:"bytes"`
	RTTMS     float64 `json:"round_trip_ms"`
	ICMPRTTMS float64 `json:"icmp_rtt_ms"`
}

func CheckICMPRelayConfig(path string) error {
	_, err := loadICMPRelayConfig(path)
	return err
}

func loadICMPRelayConfig(path string) (icmpRelayConfig, error) {
	var c icmpRelayConfig
	b, err := readICMPPrivateFile(path, 16384)
	if err != nil {
		return c, fmt.Errorf("[icmp/config] %w", err)
	}
	// Decode each field once: encoding/json normally silently accepts duplicates.
	d := json.NewDecoder(bytes.NewReader(b))
	tok, err := d.Token()
	if err != nil || tok != json.Delim('{') {
		return c, errors.New("[icmp/config] require a JSON object")
	}
	fields := make(map[string]json.RawMessage)
	for d.More() {
		t, err := d.Token()
		if err != nil {
			return c, errors.New("[icmp/config] invalid JSON field")
		}
		name, ok := t.(string)
		if !ok {
			return c, errors.New("[icmp/config] invalid JSON field")
		}
		switch name {
		case "role", "target", "key_file", "authorized", "timeout_ms", "listen", "connect", "count", "interval_ms", "payload_bytes":
		default:
			return c, fmt.Errorf("[icmp/config] unknown field %q", name)
		}
		if _, exists := fields[name]; exists {
			return c, fmt.Errorf("[icmp/config] duplicate field %q", name)
		}
		var v json.RawMessage
		if err := d.Decode(&v); err != nil {
			return c, errors.New("[icmp/config] invalid JSON value")
		}
		if bytes.Equal(bytes.TrimSpace(v), []byte("null")) {
			return c, fmt.Errorf("[icmp/config] null field %q", name)
		}
		fields[name] = v
	}
	if _, err = d.Token(); err != nil {
		return c, errors.New("[icmp/config] incomplete JSON")
	}
	var extra any
	if err = d.Decode(&extra); err != io.EOF {
		return c, errors.New("[icmp/config] trailing JSON")
	}
	strict := json.NewDecoder(bytes.NewReader(b))
	strict.DisallowUnknownFields()
	if err := strict.Decode(&c); err != nil {
		return c, fmt.Errorf("[icmp/config] invalid schema: %w", err)
	}
	if c.Role != "origin" && c.Role != "egress" {
		return c, errors.New("[icmp/config] role must be origin or egress")
	}
	if !c.Authorized {
		return c, errors.New("[icmp/config] authorized:true is required for this single approved target")
	}
	c.address, err = netip.ParseAddr(c.Target)
	if err != nil || !icmpRelayTargetAllowed(c.address) || c.address.String() != c.Target {
		return c, errors.New("[icmp/config] target must be one canonical unicast IPv4 (not loopback, link-local, multicast, or reserved)")
	}
	if _, ok := fields["timeout_ms"]; !ok {
		c.TimeoutMS = 3000
	}
	if c.TimeoutMS < 250 || c.TimeoutMS > 10000 {
		return c, errors.New("[icmp/config] timeout_ms must be 250..10000")
	}
	if c.Role == "egress" {
		for _, name := range []string{"connect", "count", "interval_ms", "payload_bytes"} {
			if _, ok := fields[name]; ok {
				return c, fmt.Errorf("[icmp/config] %s is origin-only", name)
			}
		}
		if err := icmpRelayLoopbackEndpoint(c.Listen); err != nil {
			return c, fmt.Errorf("[icmp/config] listen: %w", err)
		}
	} else {
		if _, ok := fields["listen"]; ok {
			return c, errors.New("[icmp/config] listen is egress-only")
		}
		if err := icmpRelayLoopbackEndpoint(c.Connect); err != nil {
			return c, fmt.Errorf("[icmp/config] connect: %w", err)
		}
		if _, ok := fields["count"]; !ok {
			c.Count = 4
		}
		if _, ok := fields["interval_ms"]; !ok {
			c.IntervalMS = 1000
		}
		if _, ok := fields["payload_bytes"]; !ok {
			c.PayloadBytes = 32
		}
		if c.Count < 1 || c.Count > icmpRelayMaxProbes {
			return c, errors.New("[icmp/config] count must be 1..10")
		}
		if c.IntervalMS < 1000 || c.IntervalMS > 10000 {
			return c, errors.New("[icmp/config] interval_ms must be 1000..10000")
		}
		if c.PayloadBytes < 16 || c.PayloadBytes > icmpRelayMaxPayload {
			return c, errors.New("[icmp/config] payload_bytes must be 16..256")
		}
	}
	if !filepath.IsAbs(c.KeyFile) {
		return c, errors.New("[icmp/config] key_file must be absolute")
	}
	keyText, err := readICMPPrivateFile(c.KeyFile, 65)
	if err != nil {
		return c, fmt.Errorf("[icmp/config] key_file: %w", err)
	}
	keyText = bytes.TrimSuffix(keyText, []byte{'\n'})
	if len(keyText) != 64 || strings.ToLower(string(keyText)) != string(keyText) {
		return c, errors.New("[icmp/config] key_file must contain 64 lowercase hex characters, optionally followed by one LF")
	}
	key, err := hex.DecodeString(string(keyText))
	if err != nil {
		return c, errors.New("[icmp/config] key_file must contain 64 lowercase hex characters")
	}
	copy(c.key[:], key)
	return c, nil
}

func icmpRelayTargetAllowed(a netip.Addr) bool {
	if !a.Is4() || a.IsLoopback() || a.IsLinkLocalUnicast() || a.IsMulticast() || a.IsUnspecified() {
		return false
	}
	b := a.As4()
	return b[0] != 0 && b[0] < 224
}

func icmpRelayLoopbackEndpoint(s string) error {
	host, port, err := net.SplitHostPort(s)
	if err != nil {
		return errors.New("require canonical loopback IPv4:port (1024..65535)")
	}
	a, err := netip.ParseAddr(host)
	n, nerr := strconv.Atoi(port)
	if err != nil || !a.Is4() || !a.IsLoopback() || a.String() != host || nerr != nil || n < 1024 || n > 65535 || strconv.Itoa(n) != port {
		return errors.New("require canonical loopback IPv4:port (1024..65535)")
	}
	return nil
}

func readICMPPrivateFile(path string, limit int64) ([]byte, error) {
	f, err := openICMPPrivateFile(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	b, err := io.ReadAll(io.LimitReader(f, limit+1))
	if err != nil {
		return nil, errors.New("cannot read private file")
	}
	if int64(len(b)) > limit {
		return nil, errors.New("private file exceeds size limit")
	}
	return b, nil
}

type icmpRelayPinger interface {
	Echo(context.Context, uint16, []byte) (time.Duration, error)
	Close() error
}

type icmpRelayServer struct {
	config   icmpRelayConfig
	pinger   icmpRelayPinger
	serial   chan struct{}
	nextSend time.Time // accessed only while serial is held
}

// RunICMPRelay starts only a loopback TCP adapter. The raw socket is opened
// first, so missing Linux/CAP_NET_RAW never leaves a deceptively live listener.
func RunICMPRelay(ctx context.Context, configPath string) error {
	c, err := loadICMPRelayConfig(configPath)
	if err != nil {
		return err
	}
	if c.Role != "egress" {
		return errors.New("[icmp/relay] requires role egress")
	}
	pinger, err := newICMPRelayPinger(c.address)
	if err != nil {
		return err
	}
	defer pinger.Close()
	listener, err := (&net.ListenConfig{}).Listen(ctx, "tcp4", c.Listen)
	if err != nil {
		return fmt.Errorf("[icmp/relay] loopback listen: %w", err)
	}
	defer listener.Close()
	ctx, cancel := context.WithCancel(ctx)
	defer cancel()
	go func() { <-ctx.Done(); _ = listener.Close() }()
	s := &icmpRelayServer{config: c, pinger: pinger, serial: make(chan struct{}, 1)}
	slots := make(chan struct{}, icmpRelayMaxClients)
	var wg sync.WaitGroup
	defer wg.Wait()
	for {
		conn, err := listener.Accept()
		if err != nil {
			cancel()
			if ctx.Err() != nil && errors.Is(err, net.ErrClosed) {
				return nil
			}
			return fmt.Errorf("[icmp/relay] accept: %w", err)
		}
		if addr, ok := conn.RemoteAddr().(*net.TCPAddr); !ok || !addr.IP.IsLoopback() {
			_ = conn.Close()
			continue
		}
		select {
		case slots <- struct{}{}:
			wg.Add(1)
			go func() { defer wg.Done(); defer func() { <-slots }(); _ = s.serve(ctx, conn) }()
		default:
			_ = conn.Close()
		}
	}
}

func (s *icmpRelayServer) echo(ctx context.Context, seq uint16, data []byte) (time.Duration, error) {
	select {
	case s.serial <- struct{}{}:
		defer func() { <-s.serial }()
	case <-ctx.Done():
		return 0, ctx.Err()
	}
	if delay := time.Until(s.nextSend); delay > 0 {
		if err := icmpRelayWait(ctx, delay); err != nil {
			return 0, err
		}
	}
	if err := ctx.Err(); err != nil {
		return 0, err
	}
	s.nextSend = time.Now().Add(time.Second)
	return s.pinger.Echo(ctx, seq, data)
}

func (s *icmpRelayServer) serve(parent context.Context, conn net.Conn) error {
	ctx, cancel := context.WithTimeout(parent, icmpRelayLifetime)
	defer cancel()
	defer conn.Close()
	go func() { <-ctx.Done(); _ = conn.Close() }()
	_ = conn.SetDeadline(icmpRelayDeadline(ctx, 5*time.Second))
	session, err := icmpRelayServerAuth(conn, s.config)
	if err != nil {
		return err
	}
	seen := make(map[[16]byte]bool, icmpRelayMaxProbes)
	for seq := uint32(1); seq <= icmpRelayMaxProbes; seq++ {
		_ = conn.SetDeadline(icmpRelayDeadline(ctx, 15*time.Second))
		body, err := icmpRelayRead(conn, icmpRelayRequest)
		if err != nil {
			return err
		}
		req, err := icmpRelayDecodeRequest(body, s.config.key, session)
		if err != nil || req.sequence != seq || seen[req.nonce] {
			return errors.New("[icmp/relay] invalid, replayed, or out-of-order request")
		}
		seen[req.nonce] = true
		probeCtx, stop := context.WithTimeout(ctx, time.Duration(s.config.TimeoutMS)*time.Millisecond)
		rtt, echoErr := s.echo(probeCtx, uint16(seq), append(append([]byte(nil), req.nonce[:]...), req.payload...))
		stop()
		status := byte(0)
		if echoErr != nil {
			status = 2
			if errors.Is(echoErr, context.DeadlineExceeded) || errors.Is(echoErr, context.Canceled) {
				status = 1
			}
			rtt = 0
		}
		_ = conn.SetWriteDeadline(icmpRelayDeadline(ctx, 2*time.Second))
		response := icmpRelayEncodeResponse(req, status, rtt, s.config.key, session)
		if err := icmpRelayWrite(conn, icmpRelayResponse, response); err != nil {
			return err
		}
		if echoErr != nil {
			return echoErr
		}
	}
	return nil
}

func RunICMPPing(ctx context.Context, configPath string) (ICMPPingResult, error) {
	c, err := loadICMPRelayConfig(configPath)
	if err != nil {
		return ICMPPingResult{}, err
	}
	if c.Role != "origin" {
		return ICMPPingResult{}, errors.New("[icmp/ping] requires role origin")
	}
	result := icmpRelayEmptyResult(c)
	conn, err := (&net.Dialer{Timeout: time.Duration(c.TimeoutMS) * time.Millisecond}).DialContext(ctx, "tcp4", c.Connect)
	if err != nil {
		return result, fmt.Errorf("[icmp/ping] local UNUNKNOWNTUN stream: %w", err)
	}
	return icmpRelayPingConn(ctx, conn, c)
}

func icmpRelayEmptyResult(c icmpRelayConfig) ICMPPingResult {
	return ICMPPingResult{Target: c.Target, Replies: []ICMPPingReply{}, Scope: "real IPv4 ICMP Echo from egress to the single configured target; round_trip_ms includes the adapter stream, icmp_rtt_ms is egress-to-target only; no TUN or system ping"}
}

func icmpRelayPingConn(parent context.Context, conn net.Conn, c icmpRelayConfig) (ICMPPingResult, error) {
	result := icmpRelayEmptyResult(c)
	ctx, cancel := context.WithTimeout(parent, icmpRelayLifetime)
	defer cancel()
	defer conn.Close()
	go func() { <-ctx.Done(); _ = conn.Close() }()
	timeout := time.Duration(c.TimeoutMS) * time.Millisecond
	_ = conn.SetDeadline(icmpRelayDeadline(ctx, timeout))
	session, err := icmpRelayClientAuth(conn, c)
	if err != nil {
		return result, fmt.Errorf("[icmp/ping] adapter authentication failed: %w", err)
	}
	for seq := 1; seq <= c.Count; seq++ {
		if seq > 1 {
			if err := icmpRelayWait(ctx, time.Duration(c.IntervalMS)*time.Millisecond); err != nil {
				return result, err
			}
		}
		req := icmpRelayProbe{sequence: uint32(seq), payload: make([]byte, c.PayloadBytes)}
		if _, err := rand.Read(req.nonce[:]); err != nil {
			return result, err
		}
		if _, err := rand.Read(req.payload); err != nil {
			return result, err
		}
		_ = conn.SetDeadline(icmpRelayDeadline(ctx, timeout))
		start := time.Now()
		result.Sent++ // one submitted probe, never automatically retried
		if err := icmpRelayWrite(conn, icmpRelayRequest, icmpRelayEncodeRequest(req, c.key, session)); err != nil {
			return result, fmt.Errorf("[icmp/ping] probe %d stream write failed (not retried): %w", seq, err)
		}
		body, err := icmpRelayRead(conn, icmpRelayResponse)
		if err != nil {
			return result, fmt.Errorf("[icmp/ping] probe %d no confirmed reply (not retried): %w", seq, err)
		}
		rtt, err := icmpRelayDecodeResponse(body, req, c.key, session)
		if err != nil {
			return result, fmt.Errorf("[icmp/ping] probe %d: %w", seq, err)
		}
		if rtt > timeout {
			return result, errors.New("[icmp/ping] invalid reply timing")
		}
		result.Received++
		result.Replies = append(result.Replies, ICMPPingReply{Sequence: seq, Bytes: len(req.payload), RTTMS: float64(time.Since(start)) / float64(time.Millisecond), ICMPRTTMS: float64(rtt) / float64(time.Millisecond)})
	}
	return result, nil
}

func icmpRelayDeadline(ctx context.Context, d time.Duration) time.Time {
	deadline := time.Now().Add(d)
	if limit, ok := ctx.Deadline(); ok && limit.Before(deadline) {
		return limit
	}
	return deadline
}

func icmpRelayWait(ctx context.Context, d time.Duration) error {
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-t.C:
		return nil
	case <-ctx.Done():
		return ctx.Err()
	}
}

func icmpRelayRead(r io.Reader, kind byte) ([]byte, error) {
	var header [8]byte
	if _, err := io.ReadFull(r, header[:]); err != nil {
		return nil, err
	}
	length := int(binary.BigEndian.Uint16(header[6:]))
	if string(header[:4]) != "GIC1" || header[4] != kind || header[5] != 0 || length > icmpRelayMaxFrame {
		return nil, errors.New("invalid ICMP adapter frame/version/size")
	}
	body := make([]byte, length)
	if _, err := io.ReadFull(r, body); err != nil {
		return nil, err
	}
	return body, nil
}

func icmpRelayWrite(w io.Writer, kind byte, body []byte) error {
	if len(body) > icmpRelayMaxFrame {
		return errors.New("oversized ICMP adapter frame")
	}
	frame := make([]byte, 8+len(body))
	copy(frame, "GIC1")
	frame[4] = kind
	binary.BigEndian.PutUint16(frame[6:8], uint16(len(body)))
	copy(frame[8:], body)
	for len(frame) > 0 {
		n, err := w.Write(frame)
		if err != nil {
			return err
		}
		if n <= 0 || n > len(frame) {
			return io.ErrShortWrite
		}
		frame = frame[n:]
	}
	return nil
}

func icmpRelayMAC(key [32]byte, label string, session, body []byte) []byte {
	h := hmac.New(sha256.New, key[:])
	h.Write([]byte("UNUNKNOWNTUN-ICMP-v1/" + label + "\x00"))
	h.Write(session)
	h.Write(body)
	return h.Sum(nil)
}

func icmpRelayServerAuth(conn net.Conn, c icmpRelayConfig) ([]byte, error) {
	challenge := make([]byte, 32)
	if _, err := rand.Read(challenge); err != nil {
		return nil, err
	}
	if err := icmpRelayWrite(conn, icmpRelayChallenge, challenge); err != nil {
		return nil, err
	}
	auth, err := icmpRelayRead(conn, icmpRelayAuth)
	if err != nil {
		return nil, err
	}
	if len(auth) != 68 {
		return nil, errors.New("invalid adapter authentication")
	}
	target := c.address.As4()
	session := append(append(append([]byte(nil), challenge...), auth[:32]...), target[:]...)
	if !hmac.Equal(auth[32:36], target[:]) || !hmac.Equal(auth[36:], icmpRelayMAC(c.key, "client-auth", session, nil)) {
		return nil, errors.New("invalid adapter authentication")
	}
	if err := icmpRelayWrite(conn, icmpRelayReady, icmpRelayMAC(c.key, "server-auth", session, nil)); err != nil {
		return nil, err
	}
	return session, nil
}

func icmpRelayClientAuth(conn net.Conn, c icmpRelayConfig) ([]byte, error) {
	challenge, err := icmpRelayRead(conn, icmpRelayChallenge)
	if err != nil {
		return nil, err
	}
	if len(challenge) != 32 {
		return nil, errors.New("invalid adapter challenge")
	}
	clientNonce := make([]byte, 32)
	if _, err := rand.Read(clientNonce); err != nil {
		return nil, err
	}
	target := c.address.As4()
	session := append(append(append([]byte(nil), challenge...), clientNonce...), target[:]...)
	auth := append(append(append([]byte(nil), clientNonce...), target[:]...), icmpRelayMAC(c.key, "client-auth", session, nil)...)
	if err := icmpRelayWrite(conn, icmpRelayAuth, auth); err != nil {
		return nil, err
	}
	ack, err := icmpRelayRead(conn, icmpRelayReady)
	if err != nil {
		return nil, err
	}
	if !hmac.Equal(ack, icmpRelayMAC(c.key, "server-auth", session, nil)) {
		return nil, errors.New("invalid adapter server authentication")
	}
	return session, nil
}

type icmpRelayProbe struct {
	sequence uint32
	nonce    [16]byte
	payload  []byte
}

func icmpRelayEncodeRequest(p icmpRelayProbe, key [32]byte, session []byte) []byte {
	b := make([]byte, 22+len(p.payload))
	binary.BigEndian.PutUint32(b, p.sequence)
	copy(b[4:20], p.nonce[:])
	binary.BigEndian.PutUint16(b[20:22], uint16(len(p.payload)))
	copy(b[22:], p.payload)
	return append(b, icmpRelayMAC(key, "request", session, b)...)
}

func icmpRelayDecodeRequest(b []byte, key [32]byte, session []byte) (icmpRelayProbe, error) {
	var p icmpRelayProbe
	if len(b) < 22+16+32 || len(b) > 22+icmpRelayMaxPayload+32 {
		return p, errors.New("invalid request size")
	}
	end := len(b) - 32
	n := int(binary.BigEndian.Uint16(b[20:22]))
	if n != end-22 || !hmac.Equal(b[end:], icmpRelayMAC(key, "request", session, b[:end])) {
		return p, errors.New("invalid request authentication or length")
	}
	p.sequence = binary.BigEndian.Uint32(b)
	copy(p.nonce[:], b[4:20])
	p.payload = append([]byte(nil), b[22:end]...)
	return p, nil
}

func icmpRelayEncodeResponse(p icmpRelayProbe, status byte, rtt time.Duration, key [32]byte, session []byte) []byte {
	b := make([]byte, 31+len(p.payload))
	binary.BigEndian.PutUint32(b, p.sequence)
	copy(b[4:20], p.nonce[:])
	b[20] = status
	binary.BigEndian.PutUint64(b[21:29], uint64(rtt))
	binary.BigEndian.PutUint16(b[29:31], uint16(len(p.payload)))
	copy(b[31:], p.payload)
	return append(b, icmpRelayMAC(key, "response", session, b)...)
}

func icmpRelayDecodeResponse(b []byte, expected icmpRelayProbe, key [32]byte, session []byte) (time.Duration, error) {
	if len(b) != 31+len(expected.payload)+32 {
		return 0, errors.New("invalid reply size")
	}
	end := len(b) - 32
	if !hmac.Equal(b[end:], icmpRelayMAC(key, "response", session, b[:end])) {
		return 0, errors.New("invalid reply authentication")
	}
	if binary.BigEndian.Uint32(b) != expected.sequence || !hmac.Equal(b[4:20], expected.nonce[:]) || int(binary.BigEndian.Uint16(b[29:31])) != len(expected.payload) || !hmac.Equal(b[31:end], expected.payload) {
		return 0, errors.New("mismatched or replayed reply")
	}
	if b[20] == 1 {
		return 0, errors.New("no matching ICMP Echo reply before deadline")
	}
	if b[20] != 0 {
		return 0, errors.New("egress ICMP operation failed; check target ACL, route and raw-socket permissions")
	}
	rtt := binary.BigEndian.Uint64(b[21:29])
	if rtt > uint64(10*time.Second) {
		return 0, errors.New("invalid reply timing")
	}
	return time.Duration(rtt), nil
}

func icmpRelayChecksum(b []byte) uint16 {
	var sum uint32
	for len(b) >= 2 {
		sum += uint32(binary.BigEndian.Uint16(b))
		b = b[2:]
	}
	if len(b) != 0 {
		sum += uint32(b[0]) << 8
	}
	for sum>>16 != 0 {
		sum = sum&0xffff + sum>>16
	}
	return ^uint16(sum)
}

func icmpRelayEchoPacket(id, seq uint16, data []byte) []byte {
	b := make([]byte, 8+len(data))
	b[0] = 8
	binary.BigEndian.PutUint16(b[4:6], id)
	binary.BigEndian.PutUint16(b[6:8], seq)
	copy(b[8:], data)
	binary.BigEndian.PutUint16(b[2:4], icmpRelayChecksum(b))
	return b
}

// Linux raw IPv4 sockets include the outer header. Never interpret a locally
// observed request, error, unrelated source, old nonce, or corrupted echo as proof.
func icmpRelayMatchIPv4Reply(packet []byte, target netip.Addr, id, seq uint16, data []byte) bool {
	if len(packet) < 20 || packet[0]>>4 != 4 || packet[9] != 1 {
		return false
	}
	i := int(packet[0]&15) * 4
	if i < 20 || i > 60 || i > len(packet) || int(binary.BigEndian.Uint16(packet[2:4])) != len(packet) || binary.BigEndian.Uint16(packet[6:8])&0x3fff != 0 {
		return false
	}
	targetBytes := target.As4()
	if !bytes.Equal(packet[12:16], targetBytes[:]) {
		return false
	}
	b := packet[i:]
	return len(b) == 8+len(data) && b[0] == 0 && b[1] == 0 && binary.BigEndian.Uint16(b[4:6]) == id && binary.BigEndian.Uint16(b[6:8]) == seq && icmpRelayChecksum(b) == 0 && hmac.Equal(b[8:], data)
}
