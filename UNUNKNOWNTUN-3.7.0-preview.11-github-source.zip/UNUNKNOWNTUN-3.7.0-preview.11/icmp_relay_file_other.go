//go:build !linux && !darwin

package main

import (
	"errors"
	"os"
)

func openICMPPrivateFile(string) (*os.File, error) {
	return nil, errors.New("[icmp/config] secure private-file loading is supported on Linux and macOS only")
}
