//go:build linux || darwin

package main

import (
	"errors"
	"os"
	"path/filepath"
	"strings"

	"golang.org/x/sys/unix"
)

// Walk directories by descriptor so no path component can redirect credentials
// through a symlink. O_NONBLOCK prevents a replaced FIFO from hanging startup.
func openICMPPrivateFile(path string) (*os.File, error) {
	if !filepath.IsAbs(path) || filepath.Clean(path) != path {
		return nil, errors.New("require a clean absolute private-file path")
	}
	parts := strings.Split(strings.TrimPrefix(path, "/"), "/")
	fd, err := unix.Open("/", unix.O_RDONLY|unix.O_DIRECTORY|unix.O_CLOEXEC, 0)
	if err != nil {
		return nil, errors.New("cannot open private-file parent")
	}
	for _, part := range parts[:len(parts)-1] {
		next, openErr := unix.Openat(fd, part, unix.O_RDONLY|unix.O_DIRECTORY|unix.O_NOFOLLOW|unix.O_CLOEXEC, 0)
		_ = unix.Close(fd)
		if openErr != nil {
			return nil, errors.New("private-file parents must be real directories, without symlinks")
		}
		fd = next
	}
	fileFD, err := unix.Openat(fd, parts[len(parts)-1], unix.O_RDONLY|unix.O_NONBLOCK|unix.O_NOFOLLOW|unix.O_CLOEXEC, 0)
	_ = unix.Close(fd)
	if err != nil {
		return nil, errors.New("cannot securely open private file (no symlinks allowed)")
	}
	var st unix.Stat_t
	if err := unix.Fstat(fileFD, &st); err != nil || st.Mode&unix.S_IFMT != unix.S_IFREG || st.Mode&07777 != 0600 || st.Uid != uint32(os.Geteuid()) || st.Nlink != 1 {
		_ = unix.Close(fileFD)
		return nil, errors.New("require an effective-user-owned regular file, mode 0600, and exactly one hard link")
	}
	f := os.NewFile(uintptr(fileFD), path)
	if f == nil {
		_ = unix.Close(fileFD)
		return nil, errors.New("cannot adopt private-file descriptor")
	}
	return f, nil
}
