//go:build linux || darwin

package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"golang.org/x/sys/unix"
)

func icmpRelayTestPrivateFiles(t *testing.T) (string, string, map[string]any) {
	t.Helper()
	dir, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	key := filepath.Join(dir, "icmp.key")
	if err := os.WriteFile(key, []byte(strings.Repeat("12", 32)+"\n"), 0600); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(dir, "config.json")
	return path, key, map[string]any{"role": "origin", "target": "192.0.2.10", "key_file": key, "authorized": true, "connect": "127.0.0.1:2000"}
}

func icmpRelayWriteTestConfig(t *testing.T, path string, c map[string]any) {
	t.Helper()
	b, err := json.Marshal(c)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, b, 0600); err != nil {
		t.Fatal(err)
	}
}

func TestICMPRelayConfigStrictnessAndDefaults(t *testing.T) {
	path, _, c := icmpRelayTestPrivateFiles(t)
	icmpRelayWriteTestConfig(t, path, c)
	got, err := loadICMPRelayConfig(path)
	if err != nil || got.Count != 4 || got.IntervalMS != 1000 || got.TimeoutMS != 3000 || got.PayloadBytes != 32 {
		t.Fatal("valid defaults failed", err)
	}
	for name, change := range map[string]func(map[string]any){
		"authorization": func(c map[string]any) { c["authorized"] = false }, "null": func(c map[string]any) { c["count"] = nil },
		"bool number": func(c map[string]any) { c["count"] = true }, "zero count": func(c map[string]any) { c["count"] = 0 },
		"count": func(c map[string]any) { c["count"] = 11 }, "interval": func(c map[string]any) { c["interval_ms"] = 999 },
		"payload": func(c map[string]any) { c["payload_bytes"] = 257 }, "timeout": func(c map[string]any) { c["timeout_ms"] = 249 },
		"wrong role": func(c map[string]any) { c["role"] = "both" }, "listen on origin": func(c map[string]any) { c["listen"] = "" },
		"unknown": func(c map[string]any) { c["foo"] = 0 }, "case variant": func(c map[string]any) { c["Count"] = 1 },
		"relative key": func(c map[string]any) { c["key_file"] = "icmp.key" }, "forbidden target": func(c map[string]any) { c["target"] = "127.0.0.1" },
	} {
		t.Run(name, func(t *testing.T) {
			path, _, c := icmpRelayTestPrivateFiles(t)
			change(c)
			icmpRelayWriteTestConfig(t, path, c)
			if CheckICMPRelayConfig(path) == nil {
				t.Fatal("invalid config accepted")
			}
		})
	}
	for _, raw := range []string{`{"role":"origin","role":"egress"}`, `{"role":"origin"} {}`, `[]`, `{"authorized":null}`} {
		if err := os.WriteFile(path, []byte(raw), 0600); err != nil {
			t.Fatal(err)
		}
		if CheckICMPRelayConfig(path) == nil {
			t.Fatal("malformed config accepted")
		}
	}
	path, _, c = icmpRelayTestPrivateFiles(t)
	delete(c, "connect")
	c["role"] = "egress"
	c["listen"] = "127.0.0.1:2000"
	icmpRelayWriteTestConfig(t, path, c)
	if err := CheckICMPRelayConfig(path); err != nil {
		t.Fatal(err)
	}
	c["count"] = 0
	icmpRelayWriteTestConfig(t, path, c)
	if CheckICMPRelayConfig(path) == nil {
		t.Fatal("origin field accepted on egress")
	}
}

func TestICMPRelayPrivateFileAndKeyRejections(t *testing.T) {
	for _, keyText := range []string{strings.Repeat("AB", 32), strings.Repeat("12", 31), strings.Repeat("12", 32) + "\n\n", strings.Repeat("zz", 32), strings.Repeat("12", 32) + " "} {
		path, key, c := icmpRelayTestPrivateFiles(t)
		icmpRelayWriteTestConfig(t, path, c)
		if err := os.WriteFile(key, []byte(keyText), 0600); err != nil {
			t.Fatal(err)
		}
		if CheckICMPRelayConfig(path) == nil {
			t.Fatal("malformed key accepted")
		}
	}
	for _, mode := range []os.FileMode{0400, 0644, 0660, 0700} {
		path, _, c := icmpRelayTestPrivateFiles(t)
		icmpRelayWriteTestConfig(t, path, c)
		if err := os.Chmod(path, mode); err != nil {
			t.Fatal(err)
		}
		if CheckICMPRelayConfig(path) == nil {
			t.Fatal("wrong file mode accepted", mode)
		}
	}
	path, key, c := icmpRelayTestPrivateFiles(t)
	icmpRelayWriteTestConfig(t, path, c)
	if err := os.Link(key, key+".hard"); err != nil {
		t.Fatal(err)
	}
	if CheckICMPRelayConfig(path) == nil {
		t.Fatal("hardlinked key accepted")
	}
	path, key, c = icmpRelayTestPrivateFiles(t)
	icmpRelayWriteTestConfig(t, path, c)
	if err := os.Symlink(key, key+".sym"); err != nil {
		t.Fatal(err)
	}
	c["key_file"] = key + ".sym"
	icmpRelayWriteTestConfig(t, path, c)
	if CheckICMPRelayConfig(path) == nil {
		t.Fatal("symlink key accepted")
	}
	path, _, c = icmpRelayTestPrivateFiles(t)
	icmpRelayWriteTestConfig(t, path, c)
	dir := filepath.Dir(path)
	link := dir + "-symlink"
	if err := os.Symlink(dir, link); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = os.Remove(link) })
	if CheckICMPRelayConfig(filepath.Join(link, "config.json")) == nil {
		t.Fatal("symlink parent accepted")
	}
	if err := os.WriteFile(path, make([]byte, 16385), 0600); err != nil {
		t.Fatal(err)
	}
	if CheckICMPRelayConfig(path) == nil {
		t.Fatal("oversized config accepted")
	}
}

func TestICMPRelayPrivateFIFOIsNonblocking(t *testing.T) {
	dir, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(dir, "fifo")
	if err := unix.Mkfifo(path, 0600); err != nil {
		t.Fatal(err)
	}
	start := time.Now()
	if _, err := openICMPPrivateFile(path); err == nil {
		t.Fatal("FIFO accepted")
	}
	if time.Since(start) > time.Second {
		t.Fatal("FIFO open blocked")
	}
}
