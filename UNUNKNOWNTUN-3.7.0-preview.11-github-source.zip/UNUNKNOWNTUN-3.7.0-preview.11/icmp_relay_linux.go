//go:build linux

package main

import (
	"context"
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"net/netip"
	"time"

	"golang.org/x/sys/unix"
)

type icmpRelayRawPinger struct {
	fd     int
	target netip.Addr
}

func newICMPRelayPinger(target netip.Addr) (icmpRelayPinger, error) {
	if !icmpRelayTargetAllowed(target) {
		return nil, errors.New("[icmp/relay] raw-socket target is not allowed")
	}
	fd, err := unix.Socket(unix.AF_INET, unix.SOCK_RAW|unix.SOCK_NONBLOCK|unix.SOCK_CLOEXEC, unix.IPPROTO_ICMP)
	if err != nil {
		if errors.Is(err, unix.EPERM) || errors.Is(err, unix.EACCES) {
			return nil, errors.New("[icmp/relay] Linux denied the raw ICMP socket; grant CAP_NET_RAW only to the dedicated egress adapter service (the main WSS tunnel and origin ping do not need it)")
		}
		return nil, fmt.Errorf("[icmp/relay] open raw ICMP socket: %w", err)
	}
	if err := unix.SetsockoptInt(fd, unix.IPPROTO_IP, unix.IP_TTL, 64); err != nil {
		_ = unix.Close(fd)
		return nil, fmt.Errorf("[icmp/relay] set bounded ICMP TTL: %w", err)
	}
	return &icmpRelayRawPinger{fd: fd, target: target}, nil
}

func (p *icmpRelayRawPinger) Close() error { return unix.Close(p.fd) }

func (p *icmpRelayRawPinger) Echo(ctx context.Context, seq uint16, data []byte) (time.Duration, error) {
	if len(data) < 16+16 || len(data) > 16+icmpRelayMaxPayload {
		return 0, errors.New("[icmp/relay] invalid echo payload size")
	}
	if _, ok := ctx.Deadline(); !ok {
		return 0, errors.New("[icmp/relay] raw echo requires a deadline")
	}
	if err := ctx.Err(); err != nil {
		return 0, err
	}
	var idBytes [2]byte
	if _, err := rand.Read(idBytes[:]); err != nil {
		return 0, err
	}
	id := binary.BigEndian.Uint16(idBytes[:])
	packet := icmpRelayEchoPacket(id, seq, data)
	start := time.Now()
	// Exactly one send. EINTR/EAGAIN is an error, never an implicit duplicate retry.
	if err := unix.Sendto(p.fd, packet, 0, &unix.SockaddrInet4{Addr: p.target.As4()}); err != nil {
		return 0, fmt.Errorf("[icmp/relay] send ICMP echo: %w", err)
	}
	var buf [2048]byte
	for {
		if err := ctx.Err(); err != nil {
			return 0, err
		}
		deadline, _ := ctx.Deadline()
		remaining := time.Until(deadline)
		if remaining <= 0 {
			return 0, context.DeadlineExceeded
		}
		waitMS := int((remaining + time.Millisecond - 1) / time.Millisecond)
		if waitMS > 100 {
			waitMS = 100
		}
		fds := []unix.PollFd{{Fd: int32(p.fd), Events: unix.POLLIN}}
		_, err := unix.Poll(fds, waitMS)
		if errors.Is(err, unix.EINTR) {
			continue
		}
		if err != nil {
			return 0, fmt.Errorf("[icmp/relay] wait for echo: %w", err)
		}
		if fds[0].Revents&(unix.POLLERR|unix.POLLHUP|unix.POLLNVAL) != 0 {
			return 0, errors.New("[icmp/relay] raw ICMP socket became unavailable")
		}
		if fds[0].Revents&unix.POLLIN == 0 {
			continue
		}
		n, _, flags, from, err := unix.Recvmsg(p.fd, buf[:], nil, 0)
		if errors.Is(err, unix.EAGAIN) || errors.Is(err, unix.EWOULDBLOCK) || errors.Is(err, unix.EINTR) {
			continue
		}
		if err != nil {
			return 0, fmt.Errorf("[icmp/relay] receive echo: %w", err)
		}
		if flags&unix.MSG_TRUNC != 0 || n > len(buf) {
			continue
		}
		source, ok := from.(*unix.SockaddrInet4)
		if !ok || source.Addr != p.target.As4() {
			continue
		}
		if icmpRelayMatchIPv4Reply(buf[:n], p.target, id, seq, data) {
			if err := ctx.Err(); err != nil {
				return 0, err
			}
			return time.Since(start), nil
		}
	}
}
