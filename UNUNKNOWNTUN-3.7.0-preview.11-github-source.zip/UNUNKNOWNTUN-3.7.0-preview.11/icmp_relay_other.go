//go:build !linux

package main

import (
	"errors"
	"net/netip"
)

func newICMPRelayPinger(netip.Addr) (icmpRelayPinger, error) {
	return nil, errors.New("[icmp/relay] the egress raw ICMP adapter requires Linux and CAP_NET_RAW; the origin ping client needs neither raw privileges nor a TUN device")
}
