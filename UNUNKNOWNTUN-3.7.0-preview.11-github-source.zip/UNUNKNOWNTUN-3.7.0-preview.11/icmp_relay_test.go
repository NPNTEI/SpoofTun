package main

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"net/netip"
	"sync"
	"testing"
	"time"
)

func icmpRelayTestConfig() icmpRelayConfig {
	c := icmpRelayConfig{Role: "origin", Target: "192.0.2.10", TimeoutMS: 1000, Count: 1, IntervalMS: 1000, PayloadBytes: 32, address: netip.MustParseAddr("192.0.2.10")}
	for i := range c.key {
		c.key[i] = byte(i + 1)
	}
	return c
}

type icmpRelayFakePinger struct {
	mu      sync.Mutex
	sends   []time.Time
	data    [][]byte
	timeout bool
}

func (p *icmpRelayFakePinger) Echo(ctx context.Context, _ uint16, data []byte) (time.Duration, error) {
	p.mu.Lock()
	p.sends = append(p.sends, time.Now())
	p.data = append(p.data, append([]byte(nil), data...))
	p.mu.Unlock()
	if p.timeout {
		<-ctx.Done()
		return 0, ctx.Err()
	}
	return 2 * time.Millisecond, nil
}
func (p *icmpRelayFakePinger) Close() error { return nil }
func (p *icmpRelayFakePinger) calls() int   { p.mu.Lock(); defer p.mu.Unlock(); return len(p.sends) }

func TestICMPRelayFrameBounds(t *testing.T) {
	var out bytes.Buffer
	if err := icmpRelayWrite(&out, icmpRelayRequest, bytes.Repeat([]byte{9}, icmpRelayMaxFrame)); err != nil {
		t.Fatal(err)
	}
	got, err := icmpRelayRead(&out, icmpRelayRequest)
	if err != nil || len(got) != icmpRelayMaxFrame {
		t.Fatal("valid bounded frame rejected", err)
	}
	if err := icmpRelayWrite(io.Discard, icmpRelayRequest, make([]byte, icmpRelayMaxFrame+1)); err == nil {
		t.Fatal("oversized write accepted")
	}
	for _, b := range [][]byte{
		{'G', 'I', 'C', '2', 4, 0, 0, 0}, {'G', 'I', 'C', '1', 5, 0, 0, 0}, {'G', 'I', 'C', '1', 4, 1, 0, 0},
		{'G', 'I', 'C', '1', 4, 0, 2, 1}, {'G', 'I', 'C', '1', 4, 0, 0, 2, 1},
	} {
		if _, err := icmpRelayRead(bytes.NewReader(b), icmpRelayRequest); err == nil {
			t.Fatal("malformed frame accepted")
		}
	}
}

func TestICMPRelayProtocolMACPayloadNonceAndSession(t *testing.T) {
	c := icmpRelayTestConfig()
	p := icmpRelayProbe{sequence: 1, payload: bytes.Repeat([]byte{0x62}, 32)}
	p.nonce[0] = 7
	session := bytes.Repeat([]byte{1}, 68)
	b := icmpRelayEncodeRequest(p, c.key, session)
	decoded, err := icmpRelayDecodeRequest(b, c.key, session)
	if err != nil || decoded.sequence != p.sequence || decoded.nonce != p.nonce || !bytes.Equal(decoded.payload, p.payload) {
		t.Fatal("request roundtrip failed", err)
	}
	for _, n := range []int{0, 4, 20, 22, len(b) - 1} {
		bad := append([]byte(nil), b...)
		bad[n] ^= 1
		if _, err := icmpRelayDecodeRequest(bad, c.key, session); err == nil {
			t.Fatal("tampered request accepted", n)
		}
	}
	otherSession := append([]byte(nil), session...)
	otherSession[0] ^= 1
	if _, err := icmpRelayDecodeRequest(b, c.key, otherSession); err == nil {
		t.Fatal("cross-session replay accepted")
	}
	for _, size := range []int{0, 15, 257} {
		bad := p
		bad.payload = make([]byte, size)
		if _, err := icmpRelayDecodeRequest(icmpRelayEncodeRequest(bad, c.key, session), c.key, session); err == nil {
			t.Fatal("invalid payload size accepted", size)
		}
	}
	r := icmpRelayEncodeResponse(p, 0, 2*time.Millisecond, c.key, session)
	if got, err := icmpRelayDecodeResponse(r, p, c.key, session); err != nil || got != 2*time.Millisecond {
		t.Fatal("reply roundtrip failed", err)
	}
	for _, change := range []func(*icmpRelayProbe){func(p *icmpRelayProbe) { p.sequence++ }, func(p *icmpRelayProbe) { p.nonce[0]++ }, func(p *icmpRelayProbe) { p.payload = bytes.Repeat([]byte{4}, 32) }} {
		bad := p
		change(&bad)
		if _, err := icmpRelayDecodeResponse(r, bad, c.key, session); err == nil {
			t.Fatal("mismatched reply accepted")
		}
	}
	if _, err := icmpRelayDecodeResponse(r, p, c.key, otherSession); err == nil {
		t.Fatal("cross-session response accepted")
	}
	for _, status := range []byte{1, 2, 3, 255} {
		if _, err := icmpRelayDecodeResponse(icmpRelayEncodeResponse(p, status, 0, c.key, session), p, c.key, session); err == nil {
			t.Fatal("unsuccessful echo counted as success")
		}
	}
}

func TestICMPRelayFakeEchoThroughAuthenticatedStream(t *testing.T) {
	c := icmpRelayTestConfig()
	c.Count = 2
	pinger := &icmpRelayFakePinger{}
	s := &icmpRelayServer{config: c, pinger: pinger, serial: make(chan struct{}, 1)}
	server, client := net.Pipe()
	done := make(chan error, 1)
	go func() { done <- s.serve(context.Background(), server) }()
	result, err := icmpRelayPingConn(context.Background(), client, c)
	if err != nil || result.Sent != 2 || result.Received != 2 || len(result.Replies) != 2 || result.Replies[0].ICMPRTTMS != 2 {
		t.Fatal("authenticated echo failed", result, err)
	}
	<-done
	if pinger.calls() != 2 || len(pinger.data[0]) != 16+c.PayloadBytes || bytes.Equal(pinger.data[0], pinger.data[1]) {
		t.Fatal("echo freshness/bounds failed")
	}
}

func TestICMPRelayWrongKeyAndTargetNeverSend(t *testing.T) {
	for _, kind := range []string{"key", "target"} {
		t.Run(kind, func(t *testing.T) {
			c := icmpRelayTestConfig()
			clientConfig := c
			if kind == "key" {
				clientConfig.key[0] ^= 1
			} else {
				clientConfig.address = netip.MustParseAddr("192.0.2.11")
			}
			pinger := &icmpRelayFakePinger{}
			s := &icmpRelayServer{config: c, pinger: pinger, serial: make(chan struct{}, 1)}
			server, client := net.Pipe()
			done := make(chan error, 1)
			go func() { done <- s.serve(context.Background(), server) }()
			result, err := icmpRelayPingConn(context.Background(), client, clientConfig)
			if err == nil || result.Received != 0 || result.Sent != 0 {
				t.Fatal("invalid authentication accepted")
			}
			<-done
			if pinger.calls() != 0 {
				t.Fatal("raw packet sent before authentication")
			}
		})
	}
}

func TestICMPRelayDuplicateSequenceOrNonceNeverResends(t *testing.T) {
	for _, kind := range []string{"sequence", "nonce"} {
		t.Run(kind, func(t *testing.T) {
			c := icmpRelayTestConfig()
			pinger := &icmpRelayFakePinger{}
			s := &icmpRelayServer{config: c, pinger: pinger, serial: make(chan struct{}, 1)}
			server, client := net.Pipe()
			defer client.Close()
			done := make(chan error, 1)
			go func() { done <- s.serve(context.Background(), server) }()
			_ = client.SetDeadline(time.Now().Add(time.Second))
			session, err := icmpRelayClientAuth(client, c)
			if err != nil {
				t.Fatal(err)
			}
			p := icmpRelayProbe{sequence: 1, payload: make([]byte, 32)}
			p.nonce[0] = 1
			if err := icmpRelayWrite(client, icmpRelayRequest, icmpRelayEncodeRequest(p, c.key, session)); err != nil {
				t.Fatal(err)
			}
			if _, err := icmpRelayRead(client, icmpRelayResponse); err != nil {
				t.Fatal(err)
			}
			if kind == "nonce" {
				p.sequence = 2
			} else {
				p.nonce[0] = 2
			}
			if err := icmpRelayWrite(client, icmpRelayRequest, icmpRelayEncodeRequest(p, c.key, session)); err != nil {
				t.Fatal(err)
			}
			if _, err := icmpRelayRead(client, icmpRelayResponse); err == nil {
				t.Fatal("replay got response")
			}
			if err := <-done; err == nil {
				t.Fatal("replay accepted")
			}
			if pinger.calls() != 1 {
				t.Fatal("duplicate raw probe sent")
			}
		})
	}
}

func TestICMPRelayDeadlineDoesNotRetryOrCountSuccess(t *testing.T) {
	c := icmpRelayTestConfig()
	c.TimeoutMS = 250
	c.Count = 4
	pinger := &icmpRelayFakePinger{timeout: true}
	s := &icmpRelayServer{config: c, pinger: pinger, serial: make(chan struct{}, 1)}
	server, client := net.Pipe()
	done := make(chan error, 1)
	go func() { done <- s.serve(context.Background(), server) }()
	start := time.Now()
	result, err := icmpRelayPingConn(context.Background(), client, c)
	if err == nil || result.Sent != 1 || result.Received != 0 || pinger.calls() != 1 {
		t.Fatal("timeout retried or falsely successful", result, err)
	}
	<-done
	if time.Since(start) > time.Second {
		t.Fatal("deadline not bounded")
	}
}

func TestICMPRelayRateAndCancelledQueue(t *testing.T) {
	pinger := &icmpRelayFakePinger{}
	s := &icmpRelayServer{pinger: pinger, serial: make(chan struct{}, 1)}
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	var wg sync.WaitGroup
	for i := 0; i < 3; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if _, err := s.echo(ctx, 1, make([]byte, 48)); err != nil {
				t.Error(err)
			}
		}()
	}
	wg.Wait()
	if pinger.calls() != 3 {
		t.Fatal("missing probes")
	}
	for i := 1; i < 3; i++ {
		if pinger.sends[i].Sub(pinger.sends[i-1]) < 990*time.Millisecond {
			t.Fatal("aggregate packet rate exceeded")
		}
	}
	s.serial <- struct{}{}
	short, stop := context.WithTimeout(context.Background(), 20*time.Millisecond)
	defer stop()
	if _, err := s.echo(short, 1, make([]byte, 48)); !errors.Is(err, context.DeadlineExceeded) {
		t.Fatal("queued probe ignored cancellation", err)
	}
	<-s.serial
	if pinger.calls() != 3 {
		t.Fatal("cancelled queue sent raw packet")
	}
}

func TestICMPRelayCancelledHandshake(t *testing.T) {
	c := icmpRelayTestConfig()
	pinger := &icmpRelayFakePinger{}
	s := &icmpRelayServer{config: c, pinger: pinger, serial: make(chan struct{}, 1)}
	server, client := net.Pipe()
	defer client.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Millisecond)
	defer cancel()
	if err := s.serve(ctx, server); err == nil {
		t.Fatal("cancelled handshake succeeded")
	}
	if pinger.calls() != 0 {
		t.Fatal("unauthenticated packet sent")
	}
}

func icmpRelayTestIPv4Reply(target netip.Addr, id, seq uint16, data []byte) []byte {
	b := make([]byte, 20)
	b[0] = 0x45
	b[9] = 1
	b[8] = 64
	source := target.As4()
	copy(b[12:16], source[:])
	copy(b[16:20], []byte{192, 0, 2, 1})
	echo := icmpRelayEchoPacket(id, seq, data)
	echo[0] = 0
	echo[2] = 0
	echo[3] = 0
	binary.BigEndian.PutUint16(echo[2:4], icmpRelayChecksum(echo))
	b = append(b, echo...)
	binary.BigEndian.PutUint16(b[2:4], uint16(len(b)))
	binary.BigEndian.PutUint16(b[10:12], icmpRelayChecksum(b[:20]))
	return b
}

func TestICMPRelayRawReplyIdentityAndNoise(t *testing.T) {
	target := netip.MustParseAddr("192.0.2.10")
	data := bytes.Repeat([]byte{42}, 48)
	good := icmpRelayTestIPv4Reply(target, 71, 2, data)
	if !icmpRelayMatchIPv4Reply(good, target, 71, 2, data) {
		t.Fatal("valid echo rejected")
	}
	for name, change := range map[string]func([]byte){
		"source": func(b []byte) { b[12] ^= 1 }, "nonreply": func(b []byte) { b[20] = 8 }, "code": func(b []byte) { b[21] = 1 },
		"id": func(b []byte) { b[25] ^= 1 }, "sequence": func(b []byte) { b[27] ^= 1 }, "nonce": func(b []byte) { b[28] ^= 1 },
		"payload": func(b []byte) { b[len(b)-1] ^= 1 }, "fragment": func(b []byte) { b[6] = 0x20 },
		"length": func(b []byte) { b[3]-- }, "protocol": func(b []byte) { b[9] = 17 }, "header": func(b []byte) { b[0] = 0x4f },
	} {
		t.Run(name, func(t *testing.T) {
			b := append([]byte(nil), good...)
			change(b)
			// A valid checksum must not allow a wrong identity or payload to pass.
			b[22] = 0
			b[23] = 0
			binary.BigEndian.PutUint16(b[22:24], icmpRelayChecksum(b[20:]))
			if icmpRelayMatchIPv4Reply(b, target, 71, 2, data) {
				t.Fatal("unrelated echo counted as proof")
			}
		})
	}
	corrupt := append([]byte(nil), good...)
	corrupt[22] ^= 1
	if icmpRelayMatchIPv4Reply(corrupt, target, 71, 2, data) {
		t.Fatal("corrupted checksum accepted")
	}
	if icmpRelayMatchIPv4Reply(good, target, 71, 3, data) {
		t.Fatal("old duplicate sequence accepted")
	}
	fresh := append([]byte(nil), data...)
	fresh[0]++
	if icmpRelayMatchIPv4Reply(good, target, 71, 2, fresh) {
		t.Fatal("old duplicate nonce accepted")
	}
	for n := 0; n < len(good); n++ {
		if icmpRelayMatchIPv4Reply(good[:n], target, 71, 2, data) {
			t.Fatal("truncated reply accepted")
		}
	}
}

func TestICMPRelayTargetAndEndpointACL(t *testing.T) {
	for _, target := range []string{"0.0.0.0", "0.1.2.3", "127.0.0.1", "127.9.8.7", "169.254.1.1", "224.0.0.1", "239.1.2.3", "240.0.0.1", "255.255.255.255", "::1", "::ffff:192.0.2.1"} {
		if icmpRelayTargetAllowed(netip.MustParseAddr(target)) {
			t.Fatal("unsafe target allowed", target)
		}
	}
	for _, target := range []string{"192.0.2.1", "10.0.0.1", "198.51.100.2", "203.0.113.2", "1.1.1.1"} {
		if !icmpRelayTargetAllowed(netip.MustParseAddr(target)) {
			t.Fatal("explicit unicast target denied", target)
		}
	}
	for _, endpoint := range []string{"0.0.0.0:2000", "localhost:2000", "[::1]:2000", "127.0.0.1:80", "127.0.0.1:65536", "127.0.0.1:02000", "127.0.0.01:2000"} {
		if icmpRelayLoopbackEndpoint(endpoint) == nil {
			t.Fatal("unsafe endpoint allowed", endpoint)
		}
	}
	if err := icmpRelayLoopbackEndpoint("127.0.0.1:2000"); err != nil {
		t.Fatal(err)
	}
}
