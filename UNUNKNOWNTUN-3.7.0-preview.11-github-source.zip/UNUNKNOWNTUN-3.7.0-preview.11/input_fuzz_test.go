package main

import "testing"

// Exercise untrusted resolver bytes without any DNS/network request.
func FuzzECHWireParsers(f *testing.F) {
	f.Add([]byte{}, uint16(0))
	f.Add([]byte{0, 1, 0x81, 0x80, 0, 0, 0, 0, 0, 0, 0, 0}, uint16(1))
	f.Add([]byte{0, 1, 0x81, 0x80, 0, 1, 0, 0, 0, 0, 0, 0, 0xc0, 12}, uint16(1))
	f.Fuzz(func(t *testing.T, data []byte, id uint16) {
		if len(data) > 65535 {
			return
		}
		config, _, err := parseECHDNSResponse(data, id)
		if err == nil && !validECHConfigList(config) {
			t.Fatal("accepted invalid ECH config framing")
		}
		config, _, err = parseECHSourceResponse(data, id, "fixture.example")
		if err == nil && !validECHConfigList(config) {
			t.Fatal("accepted invalid source ECH config framing")
		}
	})
}

func FuzzTransportInputParsers(f *testing.F) {
	f.Add("/assets/test", "100-1000", "1-3ms")
	f.Add("/gdt-r/", "0", "0ms")
	f.Add("\x00/../?", "9999999999999999999999", "-1ms")
	f.Fuzz(func(t *testing.T, route, padding, interval string) {
		if len(route)+len(padding)+len(interval) > 8192 {
			return
		}
		_ = validateXHTTPPath(route)
		_, _ = parseBytePadding(padding)
		_, _ = parseTLSFragmentSettings("hello", padding, interval, ECHModeOff)
		p, err := parseXHTTPPadding(padding)
		if err == nil && (p.min < 0 || p.max > xhttpMaxPaddingBytes || p.min > p.max) {
			t.Fatal("accepted out-of-bounds HTTP padding")
		}
	})
}
