package main

import (
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"encoding/hex"
	"fmt"
	"io"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// All endpoints are loopback. This measures correctness through the actual
// uTLS + WSS (including retired-name aliases) + authenticated mux + TCP target; it is not a WAN benchmark.
func managedTestListener(t *testing.T, handle func(net.Conn)) net.Listener {
	t.Helper()
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	var mu sync.Mutex
	connections := make(map[net.Conn]struct{})
	var handlers sync.WaitGroup
	accepted := make(chan struct{})
	go func() {
		defer close(accepted)
		for {
			conn, err := ln.Accept()
			if err != nil {
				return
			}
			mu.Lock()
			connections[conn] = struct{}{}
			mu.Unlock()
			handlers.Add(1)
			go func() {
				defer handlers.Done()
				defer conn.Close()
				defer func() { mu.Lock(); delete(connections, conn); mu.Unlock() }()
				handle(conn)
			}()
		}
	}()
	t.Cleanup(func() {
		ln.Close()
		awaitDone(t, accepted)
		mu.Lock()
		for conn := range connections {
			conn.Close()
		}
		mu.Unlock()
		done := make(chan struct{})
		go func() { handlers.Wait(); close(done) }()
		awaitDone(t, done)
	})
	return ln
}

func localTestTunnel(t *testing.T, mode string) (*Session, string) {
	t.Helper()
	const host = "tunnel.example.com"
	const token = "test-only-token-0123456789abcdef"
	target := managedTestListener(t, func(conn net.Conn) {
		_, _ = io.Copy(conn, conn)
		_ = conn.(*net.TCPConn).CloseWrite()
	})
	allow, err := ParseAllowList(target.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	dir := t.TempDir()
	cert, err := loadOrCreateCert(filepath.Join(dir, "test.crt"), filepath.Join(dir, "test.key"), host, false)
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(cert.Certificate[0])
	cfg := &Config{Transport: mode, Token: token, WSHost: host, SNI: host,
		WSPath: "/assets/0123456789abcdef0123456789abcdef", H2Path: "/grpc/0123456789abcdef0123456789abcdef",
		Fingerprint: hex.EncodeToString(sum[:]), UTLSProfile: "chrome", ECHMode: ECHModeOff, allowList: allow, PadRatio: 0.05}
	limiter := NewAdaptiveRateLimiter(10, 5)
	server := managedTestListener(t, func(conn net.Conn) {
		alpn := "http/1.1"
		conn.SetDeadline(time.Now().Add(10 * time.Second))
		tlsConn := tls.Server(conn, &tls.Config{Certificates: []tls.Certificate{cert}, MinVersion: tls.VersionTLS13, NextProtos: []string{alpn}})
		if err := tlsConn.Handshake(); err != nil {
			t.Errorf("test TLS handshake: %v", err)
			return
		}
		conn.SetDeadline(time.Time{})
		{
			ws, ip, err := acceptServerWebSocket(tlsConn, host, cfg.WSPath, token)
			if err != nil {
				t.Errorf("test WSS upgrade: %v", err)
				return
			}
			dispatchEgressConn(ws, ip, cfg, limiter)
		}
	})
	transport, err := newOriginTransport(cfg)
	if err != nil {
		t.Fatal(err)
	}
	conn, label, err := transport.dial(server.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	sess, err := authenticateOriginSession(conn, cfg, server.Addr().String(), label)
	if err != nil {
		conn.Close()
		t.Fatal(err)
	}
	t.Cleanup(sess.Close)
	return sess, target.Addr().String()
}

func waitForStreamBaseline(t *testing.T, streams, memory int64) {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	for time.Now().Before(deadline) {
		if activeStreams.Load() == streams && memoryBudget.Load() == memory {
			return
		}
		time.Sleep(10 * time.Millisecond)
	}
	t.Fatalf("stream cleanup failed: streams %d -> %d, queued bytes %d -> %d", streams, activeStreams.Load(), memory, memoryBudget.Load())
}

func TestLocalTunnelDataAndChurn(t *testing.T) {
	duration := 750 * time.Millisecond
	if value := os.Getenv("UNUNKNOWNTUN_SOAK_SECONDS"); value != "" {
		seconds, err := strconv.Atoi(value)
		if err != nil || seconds < 1 || seconds > 3600 {
			t.Fatal("UNUNKNOWNTUN_SOAK_SECONDS must be 1..3600")
		}
		duration = time.Duration(seconds) * time.Second
	}
	for _, mode := range []string{TransportWSS, TransportAuto, TransportH2} {
		t.Run(mode, func(t *testing.T) {
			baselineStreams, baselineMemory := activeStreams.Load(), memoryBudget.Load()
			sess, target := localTestTunnel(t, mode)
			const workers, payloadSize = 32, 64 * 1024
			clients := make([]*net.TCPConn, workers)
			for i := range clients {
				client, edge := tcpTestPair(t)
				edge.SetDeadline(time.Time{})
				client.SetDeadline(time.Now().Add(duration + 30*time.Second))
				if err := sess.OpenStream(target, edge); err != nil {
					t.Fatal(err)
				}
				clients[i] = client
			}
			var verified atomic.Uint64
			errors := make(chan error, workers)
			var wg sync.WaitGroup
			start := time.Now()
			for i, client := range clients {
				wg.Add(1)
				go func() {
					defer wg.Done()
					defer client.Close()
					data := make([]byte, payloadSize)
					rand.Read(data)
					expected := sha256.Sum256(data)
					reply := make([]byte, len(data))
					for first := true; first || time.Since(start) < duration; first = false {
						if _, err := writeFull(client, data); err != nil {
							errors <- err
							return
						}
						if i == workers-1 {
							time.Sleep(10 * time.Millisecond)
						} // one slow consumer alongside bulk streams
						if _, err := io.ReadFull(client, reply); err != nil {
							errors <- err
							return
						}
						if sha256.Sum256(reply) != expected {
							errors <- fmt.Errorf("worker %d: payload corrupted", i)
							return
						}
						verified.Add(uint64(len(data)))
					}
					// Exercise FIN in each direction; closing a TCP writer must
					// preserve the response reader and eventually deliver EOF.
					if err := client.CloseWrite(); err != nil {
						errors <- err
						return
					}
					if extra, err := io.ReadAll(client); err != nil || len(extra) != 0 {
						errors <- fmt.Errorf("half-close: extra=%d error=%v", len(extra), err)
					}
				}()
			}
			wg.Wait()
			close(errors)
			for err := range errors {
				t.Error(err)
			}
			if t.Failed() {
				return
			}
			t.Logf("transport=%s parallel_streams=%d duration=%s verified_payload_bytes_each_direction=%d corruption=0 transfer_errors=0", mode, workers, time.Since(start).Round(time.Millisecond), verified.Load())
			waitForStreamBaseline(t, baselineStreams, baselineMemory)
			// Repeated stream setup followed by an abrupt application reset.
			for i := 0; i < 100; i++ {
				client, edge := tcpTestPair(t)
				edge.SetDeadline(time.Time{})
				if err := sess.OpenStream(target, edge); err != nil {
					t.Fatal(err)
				}
				client.Write([]byte("cancel-mid-request"))
				client.SetLinger(0)
				client.Close()
			}
			waitForStreamBaseline(t, baselineStreams, baselineMemory)
			if sess.Closed() {
				t.Fatal("resetting one stream killed its carrier")
			}
			t.Log("abrupt_stream_resets=100 carrier_survived=true active_streams_and_queued_memory_returned_to_baseline=true")
		})
	}
}
