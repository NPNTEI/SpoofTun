package main

import (
	"testing"
	"time"
)

// Shared lifecycle assertion. Legacy gRPC adapter tests were retired with the
// removed transport; WSS, XHTTP and session lifecycle tests remain active.
func awaitDone(t *testing.T, ch <-chan struct{}) {
	t.Helper()
	select {
	case <-ch:
	case <-time.After(2 * time.Second):
		t.Fatal("transport goroutine did not exit after Close")
	}
}
