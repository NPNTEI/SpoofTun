package main

import (
	"bytes"
	"crypto/sha256"
	"crypto/tls"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net"
	"path/filepath"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	utls "github.com/refraction-networking/utls"
)

func TestWebSocketClientHelloOffersOnlyHTTP11(t *testing.T) {
	profiles := []struct {
		name string
		id   utls.ClientHelloID
	}{
		{name: "chrome", id: utls.HelloChrome_Auto},
		{name: "firefox", id: utls.HelloFirefox_Auto},
		{name: "ios", id: utls.HelloIOS_Auto},
	}

	for _, profile := range profiles {
		t.Run(profile.name, func(t *testing.T) {
			clientRaw, serverRaw := net.Pipe()
			defer clientRaw.Close()
			defer serverRaw.Close()

			conn := utls.UClient(clientRaw, &utls.Config{
				ServerName: "tunnel.example.com",
			}, profile.id)
			if err := prepareWebSocketClientHello(conn); err != nil {
				t.Fatal(err)
			}
			got := conn.HandshakeState.Hello.AlpnProtocols
			if len(got) != 1 || got[0] != "http/1.1" {
				t.Fatalf("ALPN protocols = %q, want [http/1.1]", got)
			}
		})
	}
}

func TestRandomProbeIntervalRangeAndVariability(t *testing.T) {
	seen := make(map[time.Duration]struct{})
	for i := 0; i < 2048; i++ {
		d := randomProbeInterval()
		if d < probeMinInterval || d > probeMaxInterval {
			t.Fatalf("probe interval %s is outside [%s, %s]", d, probeMinInterval, probeMaxInterval)
		}
		seen[d] = struct{}{}
	}
	if len(seen) < 128 {
		t.Fatalf("probe interval lacks variability: only %d distinct samples", len(seen))
	}
}

func TestRandomIdleKeepaliveIntervalRangeAndVariability(t *testing.T) {
	seen := make(map[time.Duration]struct{})
	for i := 0; i < 2048; i++ {
		d := randomIdleKeepaliveInterval()
		if d < idleKeepaliveMin || d > idleKeepaliveMax {
			t.Fatalf("idle keepalive interval %s is outside [%s, %s]", d, idleKeepaliveMin, idleKeepaliveMax)
		}
		seen[d] = struct{}{}
	}
	if len(seen) < 1024 {
		t.Fatalf("idle keepalive interval lacks variability: only %d distinct samples", len(seen))
	}
}

func TestIdleKeepaliveIsSuppressedByRealTraffic(t *testing.T) {
	interval := 30 * time.Second
	now := time.Unix(1000, 0)
	if due, wait := idleKeepaliveDue(now, now.Add(-10*time.Second), interval); due || wait != 20*time.Second {
		t.Fatalf("active flow decision = due:%t wait:%s, want due:false wait:20s", due, wait)
	}
	if due, wait := idleKeepaliveDue(now, now.Add(-interval), interval); !due || wait != 0 {
		t.Fatalf("idle flow decision = due:%t wait:%s, want due:true wait:0", due, wait)
	}
}

func TestHealthMonitorIsWireSilent(t *testing.T) {
	for _, side := range []string{"origin", "egress"} {
		t.Run(side, func(t *testing.T) {
			local, peer := net.Pipe()
			defer peer.Close()
			sess := newSession(local, side, 0, nil)
			defer sess.Close()
			sess.markAuthenticated()
			go sess.keepalive()

			if err := peer.SetReadDeadline(time.Now().Add(probeMaxInterval + 250*time.Millisecond)); err != nil {
				t.Fatal(err)
			}
			var one [1]byte
			if _, err := peer.Read(one[:]); err == nil {
				t.Fatal("health monitor unexpectedly emitted application traffic")
			} else if netErr, ok := err.(net.Error); !ok || !netErr.Timeout() {
				t.Fatalf("waiting for wire-silent health monitor: %v", err)
			}
		})
	}
}

func TestTCPTelemetryTracksRTTAndRetransmits(t *testing.T) {
	var telemetry tcpTelemetry
	telemetry.observe(kernelTCPInfo{
		rtt:          40 * time.Millisecond,
		dataSegments: 100,
		totalRetrans: 10,
	})
	telemetry.observe(kernelTCPInfo{
		rtt:          44 * time.Millisecond,
		dataSegments: 110,
		totalRetrans: 12,
	})

	health := telemetry.snapshot()
	if !health.available || health.packets != 10 || health.loss != 20 {
		t.Fatalf("unexpected TCP telemetry: %+v", health)
	}
	if health.rtt < 40*time.Millisecond || health.rtt > 44*time.Millisecond {
		t.Fatalf("unexpected RTT EWMA: %s", health.rtt)
	}

	telemetry.observe(kernelTCPInfo{
		rtt:          44 * time.Millisecond,
		rto:          4 * time.Second,
		dataSegments: 111,
		totalRetrans: 13,
		unacked:      1,
		backoff:      1,
	})
	if !telemetry.snapshot().stalled {
		t.Fatal("TCP backoff was not reported as a stalled link")
	}
}

func TestDropDetectorRequiresSustainedBadHealth(t *testing.T) {
	sess := newSession(discardNetConn{}, "origin", 0, nil)
	defer sess.Close()
	sess.memoryUsage = func() float64 { return 10 }
	nextRecovery := time.Time{}
	now := time.Now()

	for i := 0; i < flowSettings.badSamples; i++ {
		sess.telemetry.observe(kernelTCPInfo{
			rtt:          40 * time.Millisecond,
			rto:          4 * time.Second,
			dataSegments: uint32(100 + i),
			unacked:      1,
			backoff:      1,
		})
		if !sess.runHealthCycle(now.Add(time.Duration(i)*time.Second), &nextRecovery) {
			t.Fatal("health cycle closed the session")
		}
		if i < flowSettings.badSamples-1 && sess.windowDegraded.Load() {
			t.Fatalf("window degraded after only %d bad sample(s)", i+1)
		}
	}
	if !sess.windowDegraded.Load() {
		t.Fatal("window did not degrade after the configured bad-health streak")
	}
	if got := sess.localWindow.Load(); got != flowSettings.degradedWindow {
		t.Fatalf("degraded window = %d, want %d", got, flowSettings.degradedWindow)
	}

	for i := 0; i < flowSettings.goodSamples; i++ {
		sess.telemetry.observe(kernelTCPInfo{
			rtt:          40 * time.Millisecond,
			dataSegments: uint32(1000 + i*100),
		})
		recoveryAt := nextRecovery.Add(time.Millisecond)
		if !sess.runHealthCycle(recoveryAt, &nextRecovery) {
			t.Fatal("healthy recovery cycle closed the session")
		}
		if i < flowSettings.goodSamples-1 && !sess.windowDegraded.Load() {
			t.Fatalf("window recovered after only %d healthy check(s)", i+1)
		}
	}
	if sess.windowDegraded.Load() {
		t.Fatal("window did not recover after the configured healthy streak")
	}
	if got := sess.localWindow.Load(); got != flowSettings.normalWindow {
		t.Fatalf("recovered window = %d, want %d", got, flowSettings.normalWindow)
	}
}

func TestReceiveCreditReturnsAtQuarterWindow(t *testing.T) {
	st := newStream(99, nil)
	st.setInitialWindows(flowSettings.degradedWindow, flowSettings.degradedWindow)
	chunk := MaxFramePayload
	for i := 0; i < 3; i++ {
		if !st.consumeRecv(chunk) {
			t.Fatal("failed to consume receive credit")
		}
		if got := st.releaseRecv(chunk); got != 0 {
			t.Fatalf("credit returned too early after chunk %d: %d", i+1, got)
		}
	}
	if !st.consumeRecv(chunk) {
		t.Fatal("failed to consume fourth receive chunk")
	}
	if got, want := st.releaseRecv(chunk), int64(4*chunk); got != want {
		t.Fatalf("quarter-window credit = %d, want %d", got, want)
	}
}

func TestNormalCmdClosePreservesBufferedData(t *testing.T) {
	sess := newSession(nil, "test", 0, nil)
	defer sess.Close()
	sess.markAuthenticated()
	st := newStream(42, sess)
	st.state.Store(StateOpen)
	if err := sess.registerStream(st.id, st); err != nil {
		t.Fatal(err)
	}
	payload := bytes.Repeat([]byte("response-data-"), 4096)
	if !st.rbuf.Push(payload) {
		t.Fatal("failed to queue test payload")
	}

	sess.handleFrame(ctrlHeader(CmdClose, st.id, 0), nil)
	if sess.getStream(st.id) == nil {
		t.Fatal("normal CmdClose removed the stream before buffered data drained")
	}
	chunk, _, ok := st.rbuf.Pop()
	defer chunk.release()
	got := chunk.data
	if !ok || !bytes.Equal(got, payload) {
		t.Fatalf("buffered data was truncated: got %d bytes, want %d", len(got), len(payload))
	}
}

func TestResetCmdCloseDiscardsStream(t *testing.T) {
	sess := newSession(nil, "test", 0, nil)
	defer sess.Close()
	sess.markAuthenticated()
	st := newStream(43, sess)
	st.state.Store(StateOpen)
	if err := sess.registerStream(st.id, st); err != nil {
		t.Fatal(err)
	}
	sess.handleFrame(ctrlHeader(CmdClose, st.id, FlagRST), nil)
	if sess.getStream(st.id) != nil {
		t.Fatal("reset CmdClose did not remove the stream")
	}
}

func TestLateDataForClosingStreamDoesNotCloseSession(t *testing.T) {
	sess := newSession(nil, "origin", 0, nil)
	defer sess.Close()
	sess.markAuthenticated()

	st := newStream(44, sess)
	if err := sess.registerStream(st.id, st); err != nil {
		t.Fatal(err)
	}
	// Reproduce the teardown window: resetAndUnregister changes state before
	// it removes the stream from the session map.
	st.state.Store(StateClosed)

	sess.handleFrame(dataHeader(st.id, 0), []byte("late data"))

	if sess.Closed() {
		t.Fatal("late data for a closing stream closed the whole session")
	}
	if sess.getStream(st.id) != nil {
		t.Fatal("closing stream remained registered after its late data was ignored")
	}
}

func TestEarlyDataResetsOnlyAffectedStream(t *testing.T) {
	sess := newSession(nil, "origin", 0, nil)
	defer sess.Close()
	sess.markAuthenticated()

	st := newStream(46, sess)
	if err := sess.registerStream(st.id, st); err != nil {
		t.Fatal(err)
	}

	sess.handleFrame(dataHeader(st.id, 0), []byte("too early"))

	if sess.Closed() {
		t.Fatal("early stream data closed the whole multiplexed session")
	}
	if sess.getStream(st.id) != nil {
		t.Fatal("stream that sent early data was not reset and removed")
	}
}

func TestConcurrentLateDataAndLocalResetKeepsSessionAlive(t *testing.T) {
	sess := newSession(discardNetConn{}, "origin", 0, nil)
	defer sess.Close()
	sess.markAuthenticated()

	for i := 0; i < 2000; i++ {
		st := newStream(uint64(1000+i*2), sess)
		st.state.Store(StateOpen)
		if err := sess.registerStream(st.id, st); err != nil {
			t.Fatal(err)
		}

		resetDone := make(chan struct{})
		go func() {
			st.resetAndUnregister()
			close(resetDone)
		}()
		sess.handleFrame(dataHeader(st.id, 0), []byte("in flight"))
		<-resetDone

		if sess.Closed() {
			t.Fatalf("iteration %d: one stream reset closed the session", i)
		}
	}
}

func TestWebSocketRoundTrip(t *testing.T) {
	serverRaw, clientRaw := net.Pipe()
	defer serverRaw.Close()
	defer clientRaw.Close()
	deadline := time.Now().Add(5 * time.Second)
	_ = serverRaw.SetDeadline(deadline)
	_ = clientRaw.SetDeadline(deadline)

	const (
		host  = "tunnel.example.com"
		path  = "/api/v1/sync/0123456789abcdef0123456789abcdef"
		token = "0123456789abcdef0123456789abcdef"
	)
	serverDone := make(chan error, 1)
	go func() {
		server, _, err := acceptServerWebSocket(serverRaw, host, path, token)
		if err != nil {
			serverDone <- err
			return
		}
		payload := make([]byte, 96*1024)
		if _, err := io.ReadFull(server, payload); err != nil {
			serverDone <- err
			return
		}
		if !bytes.Equal(payload, bytes.Repeat([]byte{0xA5}, len(payload))) {
			serverDone <- io.ErrUnexpectedEOF
			return
		}
		_, err = server.Write([]byte("ack"))
		serverDone <- err
	}()

	client, err := clientWebSocket(clientRaw, host, path, token)
	if err != nil {
		t.Fatal(err)
	}
	payload := bytes.Repeat([]byte{0xA5}, 96*1024)
	if _, err := client.Write(payload); err != nil {
		t.Fatal(err)
	}
	ack := make([]byte, 3)
	if _, err := io.ReadFull(client, ack); err != nil {
		t.Fatal(err)
	}
	if string(ack) != "ack" {
		t.Fatalf("unexpected response %q", ack)
	}
	if err := <-serverDone; err != nil {
		t.Fatal(err)
	}
}

func TestWebSocketPreAuthRejectsWrongToken(t *testing.T) {
	serverRaw, clientRaw := net.Pipe()
	defer serverRaw.Close()
	defer clientRaw.Close()
	deadline := time.Now().Add(5 * time.Second)
	_ = serverRaw.SetDeadline(deadline)
	_ = clientRaw.SetDeadline(deadline)
	const host = "tunnel.example.com"
	const path = "/assets/0123456789abcdef0123456789abcdef"
	serverDone := make(chan error, 1)
	go func() {
		_, _, err := acceptServerWebSocket(serverRaw, host, path, "correct-token-0123456789")
		serverDone <- err
	}()
	if _, err := clientWebSocket(clientRaw, host, path, "wrong-token-01234567890"); err == nil {
		t.Fatal("WebSocket pre-auth accepted the wrong token")
	}
	if err := <-serverDone; err == nil {
		t.Fatal("server did not reject the wrong token")
	}
}

func TestUTLSWSSHandshakeAndData(t *testing.T) {
	for _, profile := range []string{"chrome", "firefox", "ios"} {
		t.Run(profile, func(t *testing.T) { testUTLSWSSProfile(t, profile) })
	}
}

func testUTLSWSSProfile(t *testing.T, profile string) {
	const (
		host  = "tunnel.example.com"
		path  = "/cdn/assets/0123456789abcdef0123456789abcdef"
		token = "0123456789abcdef0123456789abcdef"
	)
	temp := t.TempDir()
	cert, err := loadOrCreateCert(filepath.Join(temp, "server.crt"), filepath.Join(temp, "server.key"), host, false)
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(cert.Certificate[0])
	fingerprint := hex.EncodeToString(sum[:])

	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()
	serverDone := make(chan error, 1)
	go func() {
		raw, err := ln.Accept()
		if err != nil {
			serverDone <- err
			return
		}
		serverTLS := tls.Server(raw, &tls.Config{
			Certificates: []tls.Certificate{cert},
			MinVersion:   tls.VersionTLS13,
			MaxVersion:   tls.VersionTLS13,
			NextProtos:   []string{"h2", "http/1.1"},
		})
		if err := serverTLS.Handshake(); err != nil {
			serverDone <- err
			return
		}
		if got := serverTLS.ConnectionState().NegotiatedProtocol; got != "http/1.1" {
			serverDone <- fmt.Errorf("negotiated ALPN %q, want http/1.1", got)
			return
		}
		server, _, err := acceptServerWebSocket(serverTLS, host, path, token)
		if err != nil {
			serverDone <- err
			return
		}
		buf := make([]byte, 5)
		if _, err := io.ReadFull(server, buf); err != nil {
			serverDone <- err
			return
		}
		if string(buf) != "probe" {
			serverDone <- io.ErrUnexpectedEOF
			return
		}
		_, err = server.Write([]byte("ready"))
		serverDone <- err
	}()

	transport, err := newOriginTransport(&Config{
		Transport:   TransportWSS,
		Token:       token,
		Fingerprint: fingerprint,
		SNI:         host,
		WSHost:      host,
		WSPath:      path,
		UTLSProfile: profile,
	})
	if err != nil {
		t.Fatal(err)
	}
	client, transportLabel, err := transport.dial(ln.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	if transportLabel != "wss" {
		t.Fatalf("unexpected transport label %q", transportLabel)
	}
	defer client.Close()
	tracked, ok := client.(*trackedNetConn)
	if !ok || tracked.tcp == nil {
		t.Fatal("origin transport did not retain its TCP socket for telemetry")
	}
	assertKernelTCPInfo(t, tracked.tcp)
	if _, err := client.Write([]byte("probe")); err != nil {
		t.Fatal(err)
	}
	reply := make([]byte, 5)
	if _, err := io.ReadFull(client, reply); err != nil {
		t.Fatal(err)
	}
	if string(reply) != "ready" {
		t.Fatalf("unexpected WSS reply %q", reply)
	}
	if err := <-serverDone; err != nil {
		t.Fatal(err)
	}
}

func TestParseECHFromHTTPSRecord(t *testing.T) {
	const queryID = 0x1234
	name, err := encodeDNSName("tunnel.example.com")
	if err != nil {
		t.Fatal(err)
	}
	message := make([]byte, 12)
	binary.BigEndian.PutUint16(message[0:2], queryID)
	binary.BigEndian.PutUint16(message[2:4], 0x8180)
	binary.BigEndian.PutUint16(message[4:6], 1)
	binary.BigEndian.PutUint16(message[6:8], 1)
	message = append(message, name...)
	message = append(message, 0, 65, 0, 1)

	echConfig := []byte{0, 2, 0xfe, 0x0d}
	rdata := []byte{0, 1, 0}
	var parameter [4]byte
	binary.BigEndian.PutUint16(parameter[0:2], 5)
	binary.BigEndian.PutUint16(parameter[2:4], uint16(len(echConfig)))
	rdata = append(rdata, parameter[:]...)
	rdata = append(rdata, echConfig...)
	message = append(message, 0xc0, 0x0c, 0, 65, 0, 1, 0, 0, 0, 60)
	var rdataLength [2]byte
	binary.BigEndian.PutUint16(rdataLength[:], uint16(len(rdata)))
	message = append(message, rdataLength[:]...)
	message = append(message, rdata...)

	got, alias, err := parseECHDNSResponse(message, queryID)
	if err != nil {
		t.Fatal(err)
	}
	if alias != "" {
		t.Fatalf("unexpected alias %q", alias)
	}
	if !bytes.Equal(got, echConfig) {
		t.Fatalf("ECH config = %x, want %x", got, echConfig)
	}
}

func TestAdaptiveSessionPoolStartsStaggeredAndScales(t *testing.T) {
	done := make(chan struct{})
	defer close(done)
	var dials atomic.Int64
	dialTimes := make(chan time.Time, 4)
	dial := func() (*Session, error) {
		dials.Add(1)
		dialTimes <- time.Now()
		return newSession(nil, "origin", 0, nil), nil
	}
	pool := newSessionPool(2, 4, done, dial)
	deadline := time.Now().Add(3 * time.Second)
	for time.Now().Before(deadline) {
		if dials.Load() >= 2 &&
			pool.slots[0].current() != nil &&
			pool.slots[1].current() != nil {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if got := dials.Load(); got != 2 {
		t.Fatalf("initial dial count = %d, want 2", got)
	}
	if pool.slots[0].current() == nil || pool.slots[1].current() == nil {
		t.Fatal("initial adaptive sessions were not installed before the deadline")
	}
	first, second := <-dialTimes, <-dialTimes
	if second.Sub(first) < 100*time.Millisecond {
		t.Fatalf("session startup was not staggered: %s", second.Sub(first))
	}

	// Queue pressure on every active carrier makes Get activate exactly one
	// additional slot. No writer is attached, so the synthetic pressure stays.
	for i := 0; i < 2; i++ {
		sess := pool.slots[i].current()
		if sess == nil {
			t.Fatal("initial adaptive session is missing")
		}
		for j := 0; j < DataQueueDepth/4; j++ {
			sess.dataQ <- frameRequest{}
		}
	}
	pool.lastGrow.Store(time.Now().Add(-poolGrowPause).UnixNano())
	sess, release, err := pool.Get()
	if err != nil || sess == nil {
		t.Fatalf("Get failed under queue pressure: %v", err)
	}
	release()
	deadline = time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) {
		if dials.Load() >= 3 && pool.slots[2].current() != nil {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	if got := dials.Load(); got != 3 || pool.desired.Load() != 3 {
		t.Fatalf("adaptive growth = dials:%d desired:%d, want 3/3", got, pool.desired.Load())
	}
	if pool.slots[2].current() == nil {
		t.Fatal("grown adaptive session was not installed before the deadline")
	}

	for i := 0; i < 2; i++ {
		sess := pool.slots[i].current()
		for len(sess.dataQ) > 0 {
			<-sess.dataQ
		}
	}
	if !pool.retireOne() || pool.desired.Load() != 2 {
		t.Fatalf("idle retirement left desired=%d, want 2", pool.desired.Load())
	}
	for _, slot := range pool.slots {
		if current := slot.current(); current != nil {
			current.Close()
		}
	}
}

func TestPoolHasShrinkHeadroom(t *testing.T) {
	tests := []struct {
		name                      string
		desired, minimum, healthy int
		streams, maxQueue         int
		degraded, want            bool
	}{
		{name: "continuous low traffic", desired: 8, minimum: 2, healthy: 8, streams: 30, want: true},
		{name: "half-capacity boundary", desired: 3, minimum: 2, healthy: 3, streams: 32, want: true},
		{name: "above low-water mark", desired: 3, minimum: 2, healthy: 3, streams: 33, want: false},
		{name: "queue still active", desired: 8, minimum: 2, healthy: 8, streams: 20, maxQueue: 1, want: false},
		{name: "degraded carrier", desired: 8, minimum: 2, healthy: 8, streams: 20, degraded: true, want: false},
		{name: "idle degraded carriers", desired: 8, minimum: 2, healthy: 8, streams: 0, degraded: true, want: true},
		{name: "already at minimum", desired: 2, minimum: 2, healthy: 2, streams: 0, want: false},
		{name: "unavailable excess slot", desired: 8, minimum: 2, healthy: 7, streams: 60, want: true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := poolHasShrinkHeadroom(tt.desired, tt.minimum, tt.healthy, tt.streams, tt.maxQueue, tt.degraded)
			if got != tt.want {
				t.Fatalf("poolHasShrinkHeadroom() = %t, want %t", got, tt.want)
			}
		})
	}
}

func TestAdaptiveSessionPoolDoesNotGrowForIdleDegradation(t *testing.T) {
	sessions := []*Session{
		newSession(nil, "origin", 0, nil),
		newSession(nil, "origin", 0, nil),
	}
	defer func() {
		for _, sess := range sessions {
			sess.Close()
		}
	}()
	sessions[0].windowDegraded.Store(true)

	pool := &SessionPool{min: 2}
	pool.desired.Store(2)
	for _, sess := range sessions {
		pool.slots = append(pool.slots, &sessionSlot{sess: sess})
	}
	pool.slots = append(pool.slots, &sessionSlot{reconnectCh: make(chan struct{}, 1)})
	now := time.Now()
	pool.lastGrow.Store(now.Add(-poolGrowPause).UnixNano())
	pool.scaleOnce(now)
	if got := pool.desired.Load(); got != 2 {
		t.Fatalf("idle degradation grew desired=%d, want 2", got)
	}
}

func TestAdaptiveSessionPoolScalesDownWhenIdleAndDegraded(t *testing.T) {
	sessions := make([]*Session, 8)
	pool := &SessionPool{min: 2}
	pool.desired.Store(8)
	for i := range sessions {
		sessions[i] = newSession(nil, "origin", 0, nil)
		pool.slots = append(pool.slots, &sessionSlot{sess: sessions[i]})
	}
	defer func() {
		for _, sess := range sessions {
			sess.Close()
		}
	}()
	sessions[3].windowDegraded.Store(true)

	now := time.Now()
	pool.lastPressure.Store(now.Add(-poolIdleShrink).UnixNano())
	pool.scaleOnce(now)
	if got := pool.desired.Load(); got != 7 {
		t.Fatalf("idle degraded scale-down left desired=%d, want 7", got)
	}
	if pool.slots[7].current() != nil {
		t.Fatal("retired idle degraded excess carrier is still active")
	}
}

func TestAdaptiveSessionPoolStillGrowsForActiveDegradation(t *testing.T) {
	sessions := []*Session{
		newSession(nil, "origin", 0, nil),
		newSession(nil, "origin", 0, nil),
	}
	defer func() {
		for _, sess := range sessions {
			sess.Close()
		}
	}()
	sessions[0].windowDegraded.Store(true)
	stream := newStream(1, sessions[0])
	sessions[0].streams[1] = stream
	activeStreams.Add(1)

	pool := &SessionPool{min: 2}
	pool.desired.Store(2)
	for _, sess := range sessions {
		pool.slots = append(pool.slots, &sessionSlot{sess: sess})
	}
	pool.slots = append(pool.slots, &sessionSlot{reconnectCh: make(chan struct{}, 1)})
	now := time.Now()
	pool.lastGrow.Store(now.Add(-poolGrowPause).UnixNano())
	pool.scaleOnce(now)
	if got := pool.desired.Load(); got != 3 {
		t.Fatalf("active degradation left desired=%d, want growth to 3", got)
	}
}

func TestAdaptiveSessionPoolScalesDownWithContinuousLowTraffic(t *testing.T) {
	sessions := []*Session{
		newSession(nil, "origin", 0, nil),
		newSession(nil, "origin", 0, nil),
		newSession(nil, "origin", 0, nil),
	}
	defer func() {
		for _, sess := range sessions {
			sess.Close()
		}
	}()
	for i := 0; i < 20; i++ {
		sess := sessions[i%2]
		id := uint64(i + 1)
		sess.streams[id] = newStream(id, sess)
	}
	activeStreams.Add(20)

	pool := &SessionPool{min: 2}
	pool.desired.Store(3)
	for _, sess := range sessions {
		pool.slots = append(pool.slots, &sessionSlot{sess: sess})
	}
	now := time.Now()
	pool.lastPressure.Store(now.Add(-poolIdleShrink).UnixNano())
	pool.scaleOnce(now)
	if got := pool.desired.Load(); got != 2 {
		t.Fatalf("low-traffic scale-down left desired=%d, want 2", got)
	}
	if pool.slots[2].current() != nil {
		t.Fatal("retired low-traffic carrier is still active")
	}
	if got := time.Unix(0, pool.lastPressure.Load()); got.Before(now) {
		t.Fatalf("scale-down cooldown was not reset: %s < %s", got, now)
	}
}

func TestAdaptiveSessionPoolDrainsBusyRetiredCarrier(t *testing.T) {
	done := make(chan struct{})
	close(done)
	sessions := []*Session{
		newSession(nil, "origin", 0, nil),
		newSession(nil, "origin", 0, nil),
		newSession(nil, "origin", 0, nil),
	}
	defer func() {
		for _, sess := range sessions {
			sess.Close()
		}
	}()
	stream := newStream(1, sessions[2])
	sessions[2].streams[1] = stream
	activeStreams.Add(1)

	pool := &SessionPool{min: 2, done: done}
	pool.desired.Store(3)
	for _, sess := range sessions {
		pool.slots = append(pool.slots, &sessionSlot{sess: sess})
	}
	if !pool.retireOne() {
		t.Fatal("busy carrier was not excluded for draining")
	}
	if got := pool.desired.Load(); got != 2 {
		t.Fatalf("draining scale-down left desired=%d, want 2", got)
	}
	if pool.slots[2].current() == nil {
		t.Fatal("busy retired carrier was closed before its stream drained")
	}
}

func TestEndToEndHalfCloseDoesNotTruncate(t *testing.T) {
	targetListener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer targetListener.Close()
	targetDone := make(chan error, 1)
	go func() {
		conn, err := targetListener.Accept()
		if err != nil {
			targetDone <- err
			return
		}
		defer conn.Close()
		_, err = io.Copy(conn, conn)
		if tcp, ok := conn.(*net.TCPConn); ok {
			_ = tcp.CloseWrite()
		}
		targetDone <- err
	}()

	allow, err := ParseAllowList(targetListener.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	tunnelOrigin, tunnelEgress := net.Pipe()
	origin := newSession(tunnelOrigin, "origin", 0, nil)
	egress := newSession(tunnelEgress, "egress", 0, allow)
	defer origin.Close()
	defer egress.Close()
	origin.markAuthenticated()
	egress.markAuthenticated()
	go origin.readLoop()
	go egress.readLoop()

	localListener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	accepted := make(chan net.Conn, 1)
	go func() {
		conn, _ := localListener.Accept()
		accepted <- conn
	}()
	userRaw, err := net.Dial("tcp", localListener.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer userRaw.Close()
	local := <-accepted
	_ = localListener.Close()
	if local == nil {
		t.Fatal("local accept failed")
	}
	if err := origin.OpenStream(targetListener.Addr().String(), local); err != nil {
		t.Fatal(err)
	}

	user := userRaw.(*net.TCPConn)
	_ = user.SetDeadline(time.Now().Add(20 * time.Second))
	payload := bytes.Repeat([]byte("half-close-integrity-"), 220000)
	readResult := make(chan []byte, 1)
	readErr := make(chan error, 1)
	go func() {
		got, err := io.ReadAll(user)
		readResult <- got
		readErr <- err
	}()
	if _, err := writeFull(user, payload); err != nil {
		t.Fatal(err)
	}
	if err := user.CloseWrite(); err != nil {
		t.Fatal(err)
	}
	got := <-readResult
	if err := <-readErr; err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(got, payload) {
		t.Fatalf("half-close truncated data: got %d bytes, want %d", len(got), len(payload))
	}
	if err := <-targetDone; err != nil {
		t.Fatal(err)
	}
}

func TestParseAddressListPreservesFailoverOrder(t *testing.T) {
	got, err := parseAddressList("example.com:443, example.com:8443,example.com:443", "-connect", false)
	if err != nil {
		t.Fatal(err)
	}
	want := []string{"example.com:443", "example.com:8443"}
	if len(got) != len(want) {
		t.Fatalf("got %v, want %v", got, want)
	}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("got %v, want %v", got, want)
		}
	}
}

// slowReaderTestConn deterministically applies local-write backpressure after
// an initial prefix. Keep real TCP and its CloseWrite/EOF semantics, without
// depending on OS-specific tiny receive-window throughput during recovery.
type slowReaderTestConn struct {
	*net.TCPConn
	prefix  int
	resume  <-chan struct{}
	blocked chan struct{}
	once    sync.Once
}

func (c *slowReaderTestConn) Write(p []byte) (int, error) {
	if c.prefix > 0 {
		n := len(p)
		if n > c.prefix {
			n = c.prefix
		}
		written, err := c.TCPConn.Write(p[:n])
		c.prefix -= written
		return written, err
	}
	c.once.Do(func() { close(c.blocked) })
	<-c.resume
	return c.TCPConn.Write(p)
}

func TestSlowLocalReaderIsThrottledNotTruncated(t *testing.T) {
	oldTunnel, oldEdge := tunnelWriteTimeout.Load(), edgeWriteTimeout.Load()
	tunnelWriteTimeout.Store(int64(2 * time.Second))
	edgeWriteTimeout.Store(int64(DefaultEdgeWriteTimeout))
	t.Cleanup(func() {
		tunnelWriteTimeout.Store(oldTunnel)
		edgeWriteTimeout.Store(oldEdge)
	})

	const payloadSize = 8 << 20
	payload := bytes.Repeat([]byte("ununknowntun-payload"), payloadSize/16)
	targetListener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer targetListener.Close()
	go func() {
		conn, err := targetListener.Accept()
		if err != nil {
			return
		}
		defer conn.Close()
		_, _ = writeFull(conn, payload)
		if tc, ok := conn.(*net.TCPConn); ok {
			_ = tc.CloseWrite()
		}
	}()

	allow, err := ParseAllowList(targetListener.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	tunnelOrigin, tunnelEgress := net.Pipe()
	origin := newSession(tunnelOrigin, "origin", 0, nil)
	egress := newSession(tunnelEgress, "egress", 0, allow)
	defer origin.Close()
	defer egress.Close()
	origin.markAuthenticated()
	egress.markAuthenticated()
	go origin.readLoop()
	go egress.readLoop()

	localListener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	accepted := make(chan net.Conn, 1)
	go func() {
		c, _ := localListener.Accept()
		accepted <- c
	}()
	userRaw, err := net.Dial("tcp", localListener.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer userRaw.Close()
	local := <-accepted
	_ = localListener.Close()
	if local == nil {
		t.Fatal("local accept failed")
	}
	user := userRaw.(*net.TCPConn)
	resume := make(chan struct{})
	var resumeOnce sync.Once
	release := func() { resumeOnce.Do(func() { close(resume) }) }
	defer release()
	stalledLocal := &slowReaderTestConn{TCPConn: local.(*net.TCPConn), prefix: 4096,
		resume: resume, blocked: make(chan struct{})}

	if err := origin.OpenStream(targetListener.Addr().String(), stalledLocal); err != nil {
		t.Fatal(err)
	}
	head := make([]byte, 4096)
	_ = user.SetReadDeadline(time.Now().Add(10 * time.Second))
	n, err := io.ReadFull(user, head)
	if err != nil {
		t.Fatalf("initial read failed: %v", err)
	}
	select {
	case <-stalledLocal.blocked:
	case <-time.After(2 * time.Second):
		t.Fatal("fixture did not apply local-write backpressure")
	}
	time.Sleep(3 * tunnelWriteDeadline())
	if origin.Closed() || egress.Closed() || origin.streamCount() != 1 {
		t.Fatal("slow reader lost its live carrier/stream during backpressure")
	}
	release()
	_ = user.SetReadDeadline(time.Now().Add(30 * time.Second))
	rest, readErr := io.ReadAll(user)
	got := int64(n) + int64(len(rest))
	if readErr != nil {
		t.Fatalf("slow-reader recovery failed: %v (%d of %d bytes)", readErr, got, len(payload))
	}
	if got != int64(len(payload)) {
		t.Fatalf("stalled reader was truncated: %d of %d bytes", got, len(payload))
	}
	if !bytes.Equal(head[:n], payload[:n]) || !bytes.Equal(rest, payload[n:]) {
		t.Fatal("slow-reader recovery changed payload bytes")
	}
}

func TestEdgeWriteTimeoutIsHonouredWhenExplicitlyEnabled(t *testing.T) {
	oldEdge := edgeWriteTimeout.Load()
	edgeWriteTimeout.Store(int64(time.Second))
	t.Cleanup(func() { edgeWriteTimeout.Store(oldEdge) })

	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()
	accepted := make(chan net.Conn, 1)
	go func() {
		c, _ := ln.Accept()
		accepted <- c
	}()
	peer, err := net.Dial("tcp", ln.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer peer.Close()
	local := <-accepted
	if tc, ok := local.(*net.TCPConn); ok {
		_ = tc.SetWriteBuffer(4096)
	}
	if tc, ok := peer.(*net.TCPConn); ok {
		_ = tc.SetReadBuffer(4096)
	}

	sess := newSession(discardNetConn{}, "origin", 0, nil)
	defer sess.Close()
	sess.markAuthenticated()
	st := newStream(21, sess)
	st.state.Store(StateOpen)
	st.setConn(local)
	if err := sess.registerStream(st.id, st); err != nil {
		t.Fatal(err)
	}
	for i := 0; i < 64; i++ {
		if !st.rbuf.Push(bytes.Repeat([]byte{0x7A}, MaxFramePayload)) {
			break
		}
	}
	done := make(chan struct{})
	go func() {
		st.pumpToConn()
		close(done)
	}()
	select {
	case <-done:
	case <-time.After(15 * time.Second):
		t.Fatal("pumpToConn ignored the configured edge write timeout")
	}
}

func TestRegisterStreamRefusesClosedSession(t *testing.T) {
	sess := newSession(discardNetConn{}, "egress", 0, nil)
	sess.markAuthenticated()
	sess.Close()
	before := activeStreams.Load()
	st := newStream(7, sess)
	if err := sess.registerStream(7, st); err == nil {
		t.Fatal("registerStream accepted a stream on a closed session")
	}
	st.Close()
	if leaked := activeStreams.Load() - before; leaked != 0 {
		t.Fatalf("closed-session registration leaked %d slot(s)", leaked)
	}
}

func TestAbortedStreamResetsTheLocalSocket(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()
	accepted := make(chan net.Conn, 1)
	go func() { c, _ := ln.Accept(); accepted <- c }()
	peer, err := net.Dial("tcp", ln.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer peer.Close()
	local := <-accepted
	sess := newSession(discardNetConn{}, "origin", 0, nil)
	defer sess.Close()
	st := newStream(11, sess)
	st.setConn(local)
	st.abort()
	_ = peer.SetReadDeadline(time.Now().Add(5 * time.Second))
	buf := make([]byte, 1)
	_, err = peer.Read(buf)
	if err == nil || errors.Is(err, io.EOF) {
		t.Fatalf("aborted stream produced %v, want a reset", err)
	}
}

func TestFinishedStreamClosesGracefully(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()
	accepted := make(chan net.Conn, 1)
	go func() { c, _ := ln.Accept(); accepted <- c }()
	peer, err := net.Dial("tcp", ln.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer peer.Close()
	local := <-accepted
	sess := newSession(discardNetConn{}, "origin", 0, nil)
	defer sess.Close()
	st := newStream(12, sess)
	st.setConn(local)
	st.Close()
	_ = peer.SetReadDeadline(time.Now().Add(5 * time.Second))
	buf := make([]byte, 1)
	if _, err := peer.Read(buf); !errors.Is(err, io.EOF) {
		t.Fatalf("graceful close produced %v, want EOF", err)
	}
}

func TestUnderlyingTCPConnSeesThroughTLS(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()
	accepted := make(chan net.Conn, 1)
	go func() { c, _ := ln.Accept(); accepted <- c }()
	raw, err := net.Dial("tcp", ln.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer raw.Close()
	server := <-accepted
	defer server.Close()
	wrapped := tls.Server(server, &tls.Config{})
	if got := underlyingTCPConn(wrapped); got == nil {
		t.Fatal("underlyingTCPConn returned nil for tls.Conn")
	}
	if got := underlyingTCPConn(&trackedNetConn{Conn: wrapped, tcp: server.(*net.TCPConn)}); got == nil {
		t.Fatal("underlyingTCPConn returned nil for trackedNetConn")
	}
	if got := underlyingTCPConn(discardNetConn{}); got != nil {
		t.Fatal("underlyingTCPConn invented a non-TCP socket")
	}
}

func TestTransportPreAuthRejectsReplayedNonce(t *testing.T) {
	const host, path, token = "tunnel.example.com", "/assets/0123456789abcdef", "0123456789abcdef0123456789abcdef"
	now := time.Now()
	header, err := makeWebSocketAuthorization(token, host, path, now)
	if err != nil {
		t.Fatal(err)
	}
	nonce, ok := validWebSocketAuthorization(header, token, host, path, now)
	if !ok {
		t.Fatal("fresh authorization did not validate")
	}
	cache := newNonceCache()
	if !cache.admit(nonce, now) || cache.admit(nonce, now.Add(time.Minute)) {
		t.Fatal("nonce replay cache did not reject reuse")
	}
	if !cache.admit(nonce, now.Add(3*webSocketAuthSkew)) {
		t.Fatal("nonce did not expire")
	}
}

func TestReconnectBackoffTightensWhileThePoolIsCold(t *testing.T) {
	cold := &sessionSlot{anyAlive: func() bool { return false }}
	if got := cold.backoffCeiling(); got != reconnectMaxCold {
		t.Fatalf("cold ceiling = %s, want %s", got, reconnectMaxCold)
	}
	warm := &sessionSlot{anyAlive: func() bool { return true }}
	if got := warm.backoffCeiling(); got != reconnectMax {
		t.Fatalf("warm ceiling = %s, want %s", got, reconnectMax)
	}
}

func TestRegistryTrafficTotalsSurviveReconnects(t *testing.T) {
	r := &registry{set: make(map[*Session]struct{})}
	sess := newSession(discardNetConn{}, "origin", 0, nil)
	defer sess.Close()
	if !r.add(sess) {
		t.Fatal("registry refused session")
	}
	sess.bytesIn.Add(4096)
	sess.bytesOut.Add(8192)
	r.remove(sess)
	if _, _, in, out := r.stats(); in != 4096 || out != 8192 {
		t.Fatalf("retired totals = in:%d out:%d", in, out)
	}
}

func TestFormatRTTKeepsSubMillisecondLinksLegible(t *testing.T) {
	if got := formatRTT(820 * time.Microsecond); got == "0s" {
		t.Fatalf("sub-millisecond RTT rendered as %q", got)
	}
	if got := formatRTT(42 * time.Millisecond); got != "42ms" {
		t.Fatalf("formatRTT = %q, want 42ms", got)
	}
}

type discardNetConn struct{}

func (discardNetConn) Read([]byte) (int, error)         { return 0, io.EOF }
func (discardNetConn) Write(p []byte) (int, error)      { return len(p), nil }
func (discardNetConn) Close() error                     { return nil }
func (discardNetConn) LocalAddr() net.Addr              { return testAddr("local") }
func (discardNetConn) RemoteAddr() net.Addr             { return testAddr("remote") }
func (discardNetConn) SetDeadline(time.Time) error      { return nil }
func (discardNetConn) SetReadDeadline(time.Time) error  { return nil }
func (discardNetConn) SetWriteDeadline(time.Time) error { return nil }

type testAddr string

func (a testAddr) Network() string { return "test" }
func (a testAddr) String() string  { return string(a) }

func BenchmarkWebSocketClientFrame32KB(b *testing.B) {
	conn := newWebSocketConn(discardNetConn{}, true)
	payload := bytes.Repeat([]byte{0x5A}, 32*1024)
	b.SetBytes(int64(len(payload)))
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if _, err := conn.Write(payload); err != nil {
			b.Fatal(err)
		}
	}
}
