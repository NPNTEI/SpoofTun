package main

import (
	"sync"
	"sync/atomic"
	"testing"
)

// These tests intentionally use tiny frames and small budgets: a reader that
// stops consuming must not amplify a few payload bytes into unbounded storage.
func receiveBudgetTestLimits(t *testing.T, global, stream int64) int64 {
	t.Helper()
	before := memoryBudget.Load()
	oldGlobal, oldStream := maxMemoryBudget.Load(), maxStreamMemory.Load()
	maxMemoryBudget.Store(before + global)
	maxStreamMemory.Store(stream)
	t.Cleanup(func() {
		maxMemoryBudget.Store(oldGlobal)
		maxStreamMemory.Store(oldStream)
		if got := memoryBudget.Load(); got != before {
			t.Errorf("receive reservation leaked: baseline=%d current=%d", before, got)
		}
	})
	return before
}

func TestReceiveBudgetCountsPaddedBackingStorage(t *testing.T) {
	before := receiveBudgetTestLimits(t, 256<<10, 256<<10)
	b := newStreamBuffer()
	t.Cleanup(b.Close)
	owner := acquireReceiveBuffer(MaxFramePayload + MaxPadding)
	chunk := receivedChunk{data: owner.data[:1:1], owner: owner}
	charge := receiveChunkCharge(chunk)
	if !b.push(chunk) {
		owner.release()
		t.Fatal("padded frame rejected with ample memory")
	}
	if got := b.Size(); got != 1 {
		t.Fatalf("flow-control size=%d, want only 1 payload byte", got)
	}
	if got := memoryBudget.Load() - before; got < int64(cap(owner.data)) || got != charge+b.queueCharge {
		t.Fatalf("backing storage not fully charged: got=%d capacity=%d", got, cap(owner.data))
	}
	b.Close()
	if b.retained.Load() != 0 || memoryBudget.Load() != before {
		t.Fatal("padded storage remained reserved after close")
	}
}

func TestReceiveBudgetBoundsTinyFragments(t *testing.T) {
	const limit = 64 << 10
	before := receiveBudgetTestLimits(t, limit, limit)
	b := newStreamBuffer()
	t.Cleanup(b.Close)
	accepted := 0
	for i := 0; i < 1024; i++ {
		owner := acquireReceiveBuffer(1)
		if !b.push(receivedChunk{data: owner.data, owner: owner}) {
			owner.release() // rejection retains caller ownership
			break
		}
		accepted++
		if got := memoryBudget.Load() - before; got > limit || b.retained.Load() > limit {
			t.Fatalf("budget exceeded: global=%d stream=%d", got, b.retained.Load())
		}
	}
	if accepted == 0 || accepted >= 64 {
		t.Fatalf("tiny frames did not consume backing-capacity budget: accepted=%d", accepted)
	}
	if b.Size() != int64(accepted) {
		t.Fatal("payload bytes were confused with memory reservation")
	}
	b.Close()
	b.Close()
	if b.retained.Load() != 0 || memoryBudget.Load() != before {
		t.Fatal("tiny frame teardown leaked or double-freed its budget")
	}
}

func TestReceiveBudgetDefaultAllowsFullPaddedWindow(t *testing.T) {
	before := receiveBudgetTestLimits(t, DefaultStreamMemory, DefaultStreamMemory)
	b := newStreamBuffer()
	t.Cleanup(b.Close)
	var written int64
	for written < DefaultNormalWindowSize {
		n := ReadChunkSize
		if int64(n) > DefaultNormalWindowSize-written {
			n = int(DefaultNormalWindowSize - written)
		}
		owner := acquireReceiveBuffer(n + MaxPadding)
		if !b.push(receivedChunk{data: owner.data[:n], owner: owner}) {
			owner.release()
			t.Fatalf("default budget rejected normal full-window backpressure after %d of %d payload bytes", written, DefaultNormalWindowSize)
		}
		written += int64(n)
	}
	if b.Size() != DefaultNormalWindowSize || b.retained.Load() > DefaultStreamMemory {
		t.Fatal("full-window payload or retained storage accounting is wrong")
	}
	// Let one writer own a frame while all remaining data stays queued.
	// Both queues and that blocked write still fit the same reservation.
	chunk, _, ok := b.Pop()
	if !ok {
		t.Fatal("full-window pop failed")
	}
	chunk.release()
	b.Close()
	if memoryBudget.Load() != before {
		t.Fatal("full-window teardown leaked a reservation")
	}
}

func TestReceiveBudgetIncludesQueueCapacityAndOwnerMetadata(t *testing.T) {
	before := receiveBudgetTestLimits(t, 64<<10, 64<<10)
	b := newStreamBuffer()
	t.Cleanup(b.Close)
	var payloadStorage int64
	accepted := 0
	for i := 0; i < 2048; i++ {
		owner := testOwnedBuffer(1)
		chunk := receivedChunk{data: owner.data, owner: owner}
		if !b.push(chunk) {
			owner.release()
			break
		}
		accepted++
		payloadStorage += receiveChunkCharge(chunk)
		want := payloadStorage + receiveQueueCharge(cap(b.queue))
		if got := memoryBudget.Load() - before; got != want || b.retained.Load() != want {
			t.Fatalf("metadata charge mismatch: got=%d retained=%d want=%d", got, b.retained.Load(), want)
		}
	}
	if accepted < 4 || accepted >= 1024 {
		t.Fatalf("unexpected metadata-limited fragment count: %d", accepted)
	}
}

func TestReceiveBudgetFollowsInFlightWriterLease(t *testing.T) {
	before := receiveBudgetTestLimits(t, 64<<10, 64<<10)
	b := newStreamBuffer()
	t.Cleanup(b.Close)
	owner := testOwnedBuffer(4096)
	if !b.push(receivedChunk{data: owner.data, owner: owner}) {
		t.Fatal("push failed")
	}
	chunk, _, ok := b.Pop()
	if !ok {
		t.Fatal("pop failed")
	}
	t.Cleanup(chunk.release)
	if b.Size() != 0 || cap(b.queue) > 4 {
		t.Fatal("empty queue retained payload bytes or a large array")
	}
	if got := memoryBudget.Load() - before; got != chunk.budget+b.queueCharge || got < 4096 {
		t.Fatalf("blocked writer escaped its reservation: %d", got)
	}
	b.Close()
	b.Close()
	if memoryBudget.Load()-before != chunk.budget || b.retained.Load() != chunk.budget {
		t.Fatal("queue close released a writer-owned reservation")
	}
}

func TestReceiveBudgetDetachesOwnerlessSubslice(t *testing.T) {
	receiveBudgetTestLimits(t, 64<<10, 64<<10)
	b := newStreamBuffer()
	t.Cleanup(b.Close)
	hiddenBacking := make([]byte, 1<<20)
	hiddenBacking[0] = 42
	if !b.Push(hiddenBacking[:1:1]) {
		t.Fatal("push failed")
	}
	hiddenBacking[0] = 99
	chunk, _, ok := b.Pop()
	if !ok {
		t.Fatal("pop failed")
	}
	t.Cleanup(chunk.release)
	if chunk.data[0] != 42 || chunk.owner == nil || cap(chunk.owner.data) > 4096 {
		t.Fatal("ownerless tiny slice retained its hidden large backing allocation")
	}
}

func TestReceiveBudgetReservationIsAtomic(t *testing.T) {
	const limit = 997
	before := receiveBudgetTestLimits(t, limit, limit)
	var wg sync.WaitGroup
	var overLimit atomic.Bool
	for i := 0; i < 32; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := 0; j < 1000; j++ {
				if reserveReceiveMemory(73) {
					if memoryBudget.Load()-before > limit {
						overLimit.Store(true)
					}
					memoryBudget.Add(-73)
				}
			}
		}()
	}
	wg.Wait()
	if overLimit.Load() {
		t.Fatal("concurrent receive reservations exceeded their hard limit")
	}
}
