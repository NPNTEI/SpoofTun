package main

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"time"
)

func effectiveMuxMode(mode string) string {
	if mode == "off" {
		return "off"
	}
	return "on"
}

// Local FINs only prove that this endpoint drained its queues. The peer may
// still be delivering our final upload to a slow target after it sent its own
// FIN. Its existing CmdClose is the completion acknowledgement; waiting here
// prevents closing the dedicated carrier from aborting those queued bytes.
func (s *Session) waitExclusivePeerCompletion() {
	timer := time.NewTimer(halfCloseGrace)
	defer timer.Stop()
	select {
	case <-s.exclusivePeerDone:
	case <-s.done:
	case <-timer.C:
	}
}

// exclusiveSessionPool creates a fresh authenticated carrier for each client.
// The capacity covers both in-flight handshakes and established carriers, so a
// slow endpoint or many waiting clients cannot cause an unbounded dial storm.
// Unlike the adaptive MUX-on pool it has no idle prewarming or reconnect loop.
type exclusiveSessionPool struct {
	dial        func() (*Session, error)
	done        <-chan struct{}
	tokens      chan struct{}
	waitTimeout time.Duration
	mu          sync.Mutex
	sessions    map[*Session]struct{}
	stopped     bool
}

func newExclusiveSessionPool(maximum int, done <-chan struct{}, dial func() (*Session, error)) *exclusiveSessionPool {
	if maximum < 1 {
		maximum = 1
	}
	p := &exclusiveSessionPool{
		dial: dial, done: done, tokens: make(chan struct{}, maximum),
		waitTimeout: openTimeout, sessions: make(map[*Session]struct{}),
	}
	go func() {
		<-done
		p.mu.Lock()
		p.stopped = true
		p.mu.Unlock()
		// Carriers already handed to a client belong to the shared registry's
		// graceful drain. Closing them here would abort active transfers as
		// soon as main closes done, before its drainTimeout can run. Pending
		// dials are still discarded by the done selects in getContext.
	}()
	return p
}

func (p *exclusiveSessionPool) Get() (*Session, func(), error) {
	return p.getContext(context.Background())
}

func (p *exclusiveSessionPool) getContext(ctx context.Context) (*Session, func(), error) {
	// Queueing has a separate limit from the transport/authentication timeout.
	// A client must not spend an arbitrary period waiting behind long-lived
	// connections when -sessions is exhausted.
	queueTimer := time.NewTimer(p.waitTimeout)
	defer queueTimer.Stop()
	select {
	case <-p.done:
		return nil, nil, errors.New("MUX-off pool is shutting down")
	case <-ctx.Done():
		return nil, nil, ctx.Err()
	case p.tokens <- struct{}{}:
	case <-queueTimer.C:
		return nil, nil, fmt.Errorf("MUX-off carrier limit reached (%d); no slot available within %s", cap(p.tokens), p.waitTimeout)
	}

	p.mu.Lock()
	stopped := p.stopped
	p.mu.Unlock()
	select {
	case <-p.done:
		stopped = true
	default:
	}
	if stopped || ctx.Err() != nil {
		<-p.tokens
		if ctx.Err() != nil {
			return nil, nil, ctx.Err()
		}
		return nil, nil, errors.New("MUX-off pool is shutting down")
	}

	type dialResult struct {
		sess    *Session
		release func()
		err     error
	}
	result := make(chan dialResult)
	// Transport dials already carry TCP/TLS/authentication deadlines. Keep the
	// capacity token until a canceled in-flight dial really exits, but let the
	// waiting client/shutdown return immediately. A late carrier is closed.
	go func() {
		sess, err := p.dial()
		var releaseOnce sync.Once
		release := func() {
			releaseOnce.Do(func() {
				if sess != nil {
					sess.Close()
					p.mu.Lock()
					delete(p.sessions, sess)
					p.mu.Unlock()
				}
				<-p.tokens
			})
		}
		if err == nil && sess == nil {
			err = errors.New("dial returned no carrier")
		}
		if err == nil {
			sess.singleStream.Store(true)
			p.mu.Lock()
			if p.stopped {
				err = errors.New("MUX-off pool is shutting down")
			} else {
				p.sessions[sess] = struct{}{}
			}
			p.mu.Unlock()
		}
		if err != nil {
			release()
		}
		select {
		case result <- dialResult{sess: sess, release: release, err: err}:
		case <-ctx.Done():
			release()
		case <-p.done:
			release()
		}
	}()
	select {
	case r := <-result:
		if r.err != nil {
			return nil, nil, r.err
		}
		// Shutdown/cancellation can race a ready result in the select above.
		select {
		case <-p.done:
			r.release()
			return nil, nil, errors.New("MUX-off pool is shutting down")
		default:
		}
		if err := ctx.Err(); err != nil {
			r.release()
			return nil, nil, err
		}
		return r.sess, r.release, nil
	case <-ctx.Done():
		return nil, nil, ctx.Err()
	case <-p.done:
		return nil, nil, errors.New("MUX-off pool is shutting down")
	}
}
