package main

import (
	"context"
	"crypto/sha256"
	"crypto/tls"
	"encoding/hex"
	"errors"
	"io"
	"net"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func TestExclusivePoolBoundedCarriersAndFreshReuse(t *testing.T) {
	done := make(chan struct{})
	defer close(done)
	var dials atomic.Int64
	p := newExclusiveSessionPool(2, done, func() (*Session, error) {
		dials.Add(1)
		return newSession(nil, "origin", 0, nil), nil
	})
	p.waitTimeout = 25 * time.Millisecond
	first, releaseFirst, err := p.Get()
	if err != nil {
		t.Fatal(err)
	}
	defer releaseFirst()
	second, releaseSecond, err := p.Get()
	if err != nil {
		t.Fatal(err)
	}
	defer releaseSecond()
	if first == second || !first.singleStream.Load() || !second.singleStream.Load() {
		t.Fatal("exclusive clients did not get distinct single-stream carriers")
	}
	if _, _, err := p.Get(); err == nil || !strings.Contains(err.Error(), "carrier limit reached (2)") {
		t.Fatalf("third client should have a descriptive bounded-queue error, got %v", err)
	}
	if dials.Load() != 2 {
		t.Fatalf("capacity exhausted but %d carriers were dialed", dials.Load())
	}
	releaseFirst()
	releaseFirst() // An error path and completion may both attempt cleanup.
	if !first.Closed() || second.Closed() {
		t.Fatal("releasing one client did not close only its own carrier")
	}
	third, releaseThird, err := p.Get()
	if err != nil {
		t.Fatal(err)
	}
	defer releaseThird()
	if third == first || third == second || dials.Load() != 3 {
		t.Fatal("MUX-off reused a carrier across client lifetimes")
	}
	releaseSecond()
	releaseThird()
	if len(p.tokens) != 0 {
		t.Fatal("exclusive carrier capacity leaked")
	}
}

func TestExclusivePoolCancellationAndShutdownDuringDial(t *testing.T) {
	for _, stopPool := range []bool{false, true} {
		name := "context-cancellation"
		if stopPool {
			name = "shutdown"
		}
		t.Run(name, func(t *testing.T) {
			done, started, finishDial := make(chan struct{}), make(chan struct{}), make(chan struct{})
			var stopOnce sync.Once
			stop := func() { stopOnce.Do(func() { close(done) }) }
			defer stop()
			lateSession := make(chan *Session, 1)
			p := newExclusiveSessionPool(1, done, func() (*Session, error) {
				close(started)
				<-finishDial
				sess := newSession(nil, "origin", 0, nil)
				lateSession <- sess
				return sess, nil
			})
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			result := make(chan error, 1)
			go func() {
				_, release, err := p.getContext(ctx)
				if release != nil {
					release()
				}
				result <- err
			}()
			awaitDone(t, started)
			if stopPool {
				stop()
			} else {
				cancel()
			}
			select {
			case err := <-result:
				if err == nil {
					t.Fatal("canceled client unexpectedly received a carrier")
				}
			case <-time.After(time.Second):
				t.Fatal("cancellation waited for the network dial")
			}
			if len(p.tokens) != 1 {
				t.Fatal("in-flight canceled dial stopped counting against capacity")
			}
			close(finishDial)
			sess := <-lateSession
			deadline := time.Now().Add(time.Second)
			for time.Now().Before(deadline) && (!sess.Closed() || len(p.tokens) != 0) {
				time.Sleep(time.Millisecond)
			}
			if !sess.Closed() || len(p.tokens) != 0 {
				t.Fatal("late authenticated carrier or capacity leaked after cancellation")
			}
		})
	}
}

func TestExclusivePoolFailureAndWaitingCancellation(t *testing.T) {
	done := make(chan struct{})
	defer close(done)
	var fail atomic.Bool
	fail.Store(true)
	var failed *Session
	p := newExclusiveSessionPool(1, done, func() (*Session, error) {
		sess := newSession(nil, "origin", 0, nil)
		if fail.Load() {
			failed = sess
			return sess, errors.New("test authentication failure")
		}
		return sess, nil
	})
	if _, _, err := p.Get(); err == nil || !failed.Closed() || len(p.tokens) != 0 {
		t.Fatalf("failed dial did not clean up its carrier: %v", err)
	}
	fail.Store(false)
	sess, release, err := p.Get()
	if err != nil {
		t.Fatal(err)
	}
	defer release()
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Millisecond)
	defer cancel()
	if _, _, err := p.getContext(ctx); !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("waiting cancellation = %v", err)
	}
	if sess.Closed() || len(p.tokens) != 1 {
		t.Fatal("canceling queued client affected established carrier")
	}
}

func TestExclusiveSessionPreservesGlobalStreamLimit(t *testing.T) {
	baseline := activeStreams.Load()
	previousLimit := maxStreamsGlobal.Load()
	maxStreamsGlobal.Store(baseline + 1)
	defer maxStreamsGlobal.Store(previousLimit)
	first, second := newSession(nil, "origin", 0, nil), newSession(nil, "origin", 0, nil)
	defer first.Close()
	defer second.Close()
	first.singleStream.Store(true)
	second.singleStream.Store(true)
	if err := first.registerStream(1, newStream(1, first)); err != nil {
		t.Fatal(err)
	}
	rejected := newStream(3, first)
	if err := first.registerStream(3, rejected); err == nil || !strings.Contains(err.Error(), "MUX is off") {
		t.Fatalf("same carrier accepted a second client: %v", err)
	}
	if rejected.ctx.Err() == nil {
		t.Fatal("rejected stream context leaked")
	}
	if err := second.registerStream(1, newStream(1, second)); err == nil || !strings.Contains(err.Error(), "global stream limit") {
		t.Fatalf("exclusive carrier bypassed global stream cap: %v", err)
	}
	first.getStream(1).abort()
	first.removeStream(1)
	if err := first.registerStream(5, newStream(5, first)); err == nil || !strings.Contains(err.Error(), "MUX is off") {
		t.Fatalf("carrier accepted another client after first stream ended: %v", err)
	}
	first.Close()
	second.Close()
	if activeStreams.Load() != baseline {
		t.Fatal("exclusive rejection leaked active-stream accounting")
	}
}

func TestExclusivePoolShutdownPreservesRegistryDrain(t *testing.T) {
	baselineStreams, baselineMemory := activeStreams.Load(), memoryBudget.Load()
	done := make(chan struct{})
	p := newExclusiveSessionPool(1, done, func() (*Session, error) {
		return newSession(nil, "origin", 0, nil), nil
	})
	sess, release, err := p.Get()
	if err != nil {
		close(done)
		t.Fatal(err)
	}
	defer release()
	st := newStream(1, sess)
	if err := sess.registerStream(1, st); err != nil {
		close(done)
		t.Fatal(err)
	}
	close(done)
	deadline := time.Now().Add(time.Second)
	for time.Now().Before(deadline) {
		p.mu.Lock()
		stopped := p.stopped
		p.mu.Unlock()
		if stopped {
			break
		}
		time.Sleep(time.Millisecond)
	}
	if sess.Closed() || st.ctx.Err() != nil {
		t.Fatal("pool shutdown aborted a transfer before the registry drain")
	}
	if _, _, err := p.Get(); err == nil {
		t.Fatal("draining pool accepted a new client")
	}
	// main owns the deadline and eventually calls registry.shutdown; emulate
	// its per-session close without poisoning the process-wide test registry.
	sess.Close()
	awaitDone(t, st.ctx.Done())
	release()
	waitForStreamBaseline(t, baselineStreams, baselineMemory)
	if !sess.Closed() || len(p.tokens) != 0 {
		t.Fatal("shutdown leaked a live exclusive carrier")
	}
}

func TestExclusiveGracefulCarrierWaitsForPeerDrainAcknowledgement(t *testing.T) {
	baseline := activeStreams.Load()
	sess := newSession(nil, "origin", 0, nil)
	defer sess.Close()
	sess.singleStream.Store(true)
	sess.markAuthenticated()
	st := newStream(1, sess)
	st.state.Store(StateOpen)
	if err := sess.registerStream(st.id, st); err != nil {
		t.Fatal(err)
	}
	st.markRemoteFin() // The target half-closes before the client upload ends.
	st.markLocalFin()
	if !st.graceful.Load() || st.ctx.Err() == nil {
		t.Fatal("local stream did not complete gracefully")
	}
	if sess.streamCount() != 1 || activeStreams.Load() != baseline+1 {
		t.Fatal("peer-undelivered stream disappeared from graceful-drain accounting")
	}
	completed := make(chan struct{})
	go func() { sess.waitExclusivePeerCompletion(); close(completed) }()
	sess.handleFrame(ctrlHeader(CmdClose, 3, 0), nil)
	select {
	case <-completed:
		t.Fatal("wrong stream acknowledgement released carrier")
	case <-time.After(10 * time.Millisecond):
	}
	sess.handleFrame(ctrlHeader(CmdClose, st.id, 0), nil)
	awaitDone(t, completed)
	sess.Close()
	if activeStreams.Load() != baseline {
		t.Fatal("completed exclusive carrier leaked stream accounting")
	}
}

// This goes through real runOrigin listeners and WSS/authentication. Three
// clients remain active together, verifying MUX-off creates three physical
// carriers while explicit and legacy/default MUX-on share one carrier.
func TestRunOriginMuxModesUseExpectedCarriers(t *testing.T) {
	for _, mode := range []string{"off", "on", ""} {
		name := mode
		if name == "" {
			name = "legacy-default-on"
		}
		t.Run(name, func(t *testing.T) {
			const host = "mux-test.example.com"
			const token = "mux-network-integration-0123456789abcdef"
			baselineStreams, baselineMemory := activeStreams.Load(), memoryBudget.Load()
			t.Cleanup(func() { waitForStreamBaseline(t, baselineStreams, baselineMemory) })
			target := managedTestListener(t, func(c net.Conn) {
				_, _ = io.Copy(c, c)
				_ = c.(*net.TCPConn).CloseWrite()
			})
			allow, err := ParseAllowList(target.Addr().String())
			if err != nil {
				t.Fatal(err)
			}
			dir := t.TempDir()
			cert, err := loadOrCreateCert(filepath.Join(dir, "server.crt"), filepath.Join(dir, "server.key"), host, false)
			if err != nil {
				t.Fatal(err)
			}
			sum := sha256.Sum256(cert.Certificate[0])
			maximum := 1
			if mode == "off" {
				maximum = 3
			}
			cfg := &Config{Mode: "origin", Transport: TransportWSS, Token: token, SNI: host, WSHost: host,
				WSPath: "/mux-integration", UTLSProfile: "chrome", Fingerprint: hex.EncodeToString(sum[:]),
				MinSessions: 1, Sessions: maximum, Target: target.Addr().String(), allowList: allow, MuxMode: mode}
			var carriers atomic.Int64
			limiter := NewAdaptiveRateLimiter(10, 5)
			frontend := managedTestListener(t, func(raw net.Conn) {
				_ = raw.SetDeadline(time.Now().Add(5 * time.Second))
				conn := tls.Server(raw, &tls.Config{Certificates: []tls.Certificate{cert},
					MinVersion: tls.VersionTLS13, NextProtos: []string{"http/1.1"}})
				if err := conn.Handshake(); err != nil {
					return
				}
				ws, ip, err := acceptServerWebSocket(conn, host, cfg.WSPath, token)
				if err != nil {
					return
				}
				_ = raw.SetDeadline(time.Time{})
				carriers.Add(1)
				dispatchEgressConn(ws, ip, cfg, limiter)
			})
			cfg.Connect = frontend.Addr().String()
			reserve, err := net.Listen("tcp", "127.0.0.1:0")
			if err != nil {
				t.Fatal(err)
			}
			cfg.Listen = reserve.Addr().String()
			reserve.Close()
			stop, exited := make(chan struct{}), make(chan struct{})
			var stopOnce sync.Once
			stopOrigin := func() { stopOnce.Do(func() { close(stop) }) }
			originResult := make(chan error, 1)
			go func() { defer close(exited); originResult <- runOrigin(cfg, stop) }()
			t.Cleanup(func() {
				stopOrigin()
				reg.mu.Lock()
				var owned []*Session
				for sess := range reg.set {
					if sess.token == token {
						owned = append(owned, sess)
					}
				}
				reg.mu.Unlock()
				for _, sess := range owned {
					sess.Close()
				}
				awaitDone(t, exited)
			})
			clients := make([]*net.TCPConn, 0, 3)
			defer func() {
				for _, c := range clients {
					c.Close()
				}
			}()
			for i := 0; i < 3; i++ {
				var conn net.Conn
				deadline := time.Now().Add(5 * time.Second)
				for time.Now().Before(deadline) {
					conn, err = net.DialTimeout("tcp", cfg.Listen, 100*time.Millisecond)
					if err == nil {
						break
					}
					time.Sleep(10 * time.Millisecond)
				}
				if err != nil {
					t.Fatal(err)
				}
				client := conn.(*net.TCPConn)
				clients = append(clients, client)
				_ = client.SetDeadline(time.Now().Add(10 * time.Second))
				payload := []byte("parallel-client-payload")
				if _, err := client.Write(payload); err != nil {
					t.Fatal(err)
				}
				response := make([]byte, len(payload))
				if _, err := io.ReadFull(client, response); err != nil || string(response) != string(payload) {
					t.Fatalf("client %d echo: %q, %v", i, response, err)
				}
			}
			if got := carriers.Load(); got != int64(maximum) {
				t.Fatalf("mux=%q with three active clients used %d carriers, want %d", mode, got, maximum)
			}
			for _, client := range clients {
				if err := client.CloseWrite(); err != nil {
					t.Fatal(err)
				}
				if extra, err := io.ReadAll(client); err != nil || len(extra) != 0 {
					t.Fatalf("half-close did not drain: extra=%d error=%v", len(extra), err)
				}
				client.Close()
			}
			waitForStreamBaseline(t, baselineStreams, baselineMemory)
			stopOrigin()
			awaitDone(t, exited)
			if err := <-originResult; err != nil {
				t.Fatal(err)
			}
		})
	}
}
