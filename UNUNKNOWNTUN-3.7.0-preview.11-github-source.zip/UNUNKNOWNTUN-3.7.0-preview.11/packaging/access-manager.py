#!/usr/bin/env python3
"""Local root-side customer manager. Never reads or exports the tunnel token.

Configuration is root-owned; the running Go service alone owns accounting state.
All public customer listeners are metered in the Go origin, including CDN paths.
"""
import argparse
import copy
import decimal
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import secrets
import shlex
import shutil
import socket
import subprocess
import sys
import tempfile
import time

GB = 1_000_000_000
MAX_BYTES = 9_000_000_000_000_000
ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,47}$")
ROUTE_RE = re.compile(r"^/[A-Za-z0-9/_-]{15,511}$")
BEGIN = "    # UNUNKNOWNTUN_CUSTOMERS_BEGIN"
END = "    # UNUNKNOWNTUN_CUSTOMERS_END"
MARKER = "    # UNUNKNOWNTUN_CUSTOMER_ROUTES"


def gb_to_bytes(value):
    try:
        number = decimal.Decimal(str(value))
        scaled = number * GB
        if not number.is_finite() or number < 0 or scaled > MAX_BYTES or scaled != scaled.to_integral_value():
            raise ValueError()
        return int(scaled)
    except (decimal.InvalidOperation, ValueError, OverflowError):
        raise ValueError("Enter a non-negative GB amount (0 = unlimited, 1 GB = 1,000,000,000 bytes).") from None


def port_number(value):
    if not re.fullmatch(r"[0-9]{1,5}", str(value)) or not 1 <= int(value) <= 65535:
        raise ValueError("Port must be a number from 1 to 65535.")
    return int(value)


def account_id(value):
    if not ID_RE.fullmatch(value) or "--" in value:
        raise ValueError("Use 1-48 lowercase letters, numbers and single hyphens.")
    return value


def customer_name(value):
    if not value or not value.isprintable() or len(value) > 120 or len(value.encode("utf-8")) > 256:
        raise ValueError("Name must be 1-120 printable characters and at most 256 UTF-8 bytes.")
    return value


def prompt(label, default=None, validate=lambda x: x):
    while True:
        try:
            answer = input(label + (f" [{default}]" if default is not None else "") + ": ").strip()
        except (EOFError, KeyboardInterrupt):
            raise SystemExit("\nCancelled; previous settings are retained.")
        if answer.lower() in ("cancel", "q"):
            raise SystemExit("Cancelled; previous settings are retained.")
        try:
            return validate(answer if answer else (str(default) if default is not None else ""))
        except ValueError as exc:
            print(f"Invalid input: {exc}", file=sys.stderr)


def read_env(path):
    result = {}
    for line in path.read_text().splitlines():
        if "=" not in line or line.startswith("#"):
            continue
        key, value = line.split("=", 1)
        if not re.fullmatch(r"[A-Z_][A-Z0-9_]*", key):
            continue
        parts = shlex.split(value)
        result[key] = parts[0] if parts else ""
    return result


def load_json(path):
    with path.open() as stream:
        return json.load(stream)


def atomic_write(path, data, mode=0o640, owner=None):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, name = tempfile.mkstemp(prefix="." + path.name + ".", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data.encode() if isinstance(data, str) else data)
            stream.flush()
            os.fsync(stream.fileno())
            os.fchmod(stream.fileno(), mode)
            if owner is not None:
                os.fchown(stream.fileno(), *owner)
            elif path.exists():
                old = path.stat()
                os.fchown(stream.fileno(), old.st_uid, old.st_gid)
        os.replace(name, path)
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def encoded_json(data):
    return json.dumps(data, ensure_ascii=False, indent=2) + "\n"


def listeners(config):
    return {int(address.rsplit(":", 1)[1]) for account in config["accounts"]
            for address in account["listen"].split(",")}


def build_routes(site, config, routes, original_path, entry_transport="ws"):
    """Generate exact, opaque customer paths with URI rewriting for the Xray inbound."""
    if not ROUTE_RE.fullmatch(original_path):
        raise ValueError("Invalid original WebSocket path in tunnel metadata.")
    if entry_transport not in ("ws", "xhttp"):
        raise ValueError("Unknown Iran client entry transport; no customer routes changed.")
    block = [BEGIN]
    for account in config["accounts"]:
        route = routes.get(account["id"])
        if not route or not account["enabled"]:
            continue
        if not ROUTE_RE.fullmatch(route):
            raise ValueError("Invalid customer WebSocket path.")
        address = account["listen"]
        if "," in address or not re.fullmatch(r"127\.0\.0\.1:[0-9]{1,5}", address):
            raise ValueError("A proxied customer must have one private loopback listener.")
        block.extend([
            f"    location {'^~ ' + route.rstrip('/') + '/' if entry_transport == 'xhttp' else '= ' + route} {{",
            "        access_log off;",
            f"        proxy_pass http://{address}{original_path.rstrip('/') + '/' if entry_transport == 'xhttp' else original_path};",
            "        proxy_http_version 1.1;",
            "        proxy_set_header Host $host;",
            "        proxy_set_header Authorization $http_authorization;" if entry_transport == "xhttp" else "        proxy_set_header Upgrade $http_upgrade;",
            '        proxy_set_header Connection "";' if entry_transport == "xhttp" else '        proxy_set_header Connection "upgrade";',
            "        client_max_body_size 2m;",
            '        gzip off;\n        proxy_set_header Accept-Encoding "";' if entry_transport == "xhttp" else "        # WebSocket upgrade",
            "        proxy_cache off;",
            '        add_header Cache-Control "no-store" always;',
            "        proxy_buffering off;",
            "        proxy_request_buffering off;",
            "        proxy_read_timeout 86400s;",
            "        proxy_send_timeout 86400s;",
            "    }",
        ])
    block.append(END)
    replacement = "\n".join(block)
    if BEGIN in site:
        if site.count(BEGIN) != 1 or site.count(END) != 1:
            raise ValueError("Invalid customer route markers in the managed Nginx site.")
        before, tail = site.split(BEGIN, 1)
        _, after = tail.split(END, 1)
        return before + replacement + after
    if site.count(MARKER) != 1:
        raise ValueError("This Nginx site needs the 3.2 installer customer-route marker before customers can be added.")
    return site.replace(MARKER, MARKER + "\n" + replacement, 1)


class Manager:
    def __init__(self, config_dir, state_dir, install_dir=Path("/opt/ununknowntun")):
        self.directory = Path(config_dir)
        self.id = account_id(self.directory.name)
        self.state_dir = Path(state_dir)
        self.install_dir = Path(install_dir)
        self.env = read_env(self.directory / "deployment.env")
        if self.env.get("ROLE") != "origin":
            raise ValueError("Customer access is managed on the Iran server.")
        self.path = self.directory / "access.json"
        self.routes_path = self.directory / "access-routes.json"
        self.config = load_json(self.path)
        self.routes = load_json(self.routes_path) if self.routes_path.exists() else {}
        self.proxied = self.env.get("IRAN_PROXY_PROVIDER", "none") != "none"

    def account(self, selected):
        for item in self.config["accounts"]:
            if item["id"] == selected:
                return item
        raise ValueError("Customer ID was not found.")

    def choose(self, supplied=None):
        if supplied:
            return self.account(supplied)
        self.show()
        return prompt("Customer ID", validate=self.account)

    def status(self):
        path = self.state_dir / "access-state.json.status.json"
        try:
            with path.open() as stream:
                status = json.load(stream)
                stamp = os.fstat(stream.fileno()).st_mtime_ns
        except FileNotFoundError:
            return {}
        except (OSError, ValueError) as exc:
            return {"running": False, "error": f"Accounting status cannot be read: {exc}", "_fresh": False}
        if not isinstance(status, dict):
            return {"running": False, "error": "Accounting status is invalid.", "_fresh": False}
        status["_mtime_ns"] = stamp
        status["_fresh"] = -5_000_000_000 <= time.time_ns() - stamp <= 5_000_000_000
        return status

    def show(self):
        status = self.status()
        active = self.run("systemctl", "is-active", "--quiet", "ununknowntun@" + self.id, check=False).returncode == 0
        total_used = status.get("total_used_bytes", 0)
        total_quota = self.config["total_quota_bytes"]
        print(f"Tunnel: {self.id} | Total: {self.format_quota(total_quota)} | Used: {total_used / GB:.6f} GB")
        by_id = {item["id"]: item for item in status.get("accounts", [])}
        print("ID                  NAME                     QUOTA          USED GB      REMAINING GB  STATUS")
        for item in self.config["accounts"]:
            usage = by_id.get(item["id"], {})
            used = usage.get("used_bytes", 0)
            remaining = "unlimited" if not item["quota_bytes"] else f"{max(0, item['quota_bytes'] - used) / GB:.6f}"
            label = "disabled" if not item["enabled"] else "exhausted" if usage.get("blocked") else "active"
            if not active or (status and not status.get("running")):
                label = "stopped"
            elif not status.get("_fresh"):
                label = "status stale" if status else "status unavailable"
            elif status.get("error"):
                label = "blocked"
            print(f"{item['id']:<19} {item['name'][:24]:<24} {self.format_quota(item['quota_bytes']):<14} {used / GB:<12.6f} {remaining:<13} {label}")
        if status:
            print(f"Upload + download counted together. Snapshot: {status.get('updated_at', 'unknown')}")
            if not status.get("_fresh") or not active:
                print("Usage above is the last known snapshot; it is not a live reading.")
            if status.get("error"):
                print(f"Accounting blocked: {status['error']}")
        else:
            print("Accounting status has not been written yet. Start the tunnel to obtain usage.")

    @staticmethod
    def format_quota(value):
        return "unlimited" if value == 0 else f"{value / GB:g} GB"

    def available_port(self, value):
        port = port_number(value)
        if port in listeners(self.config):
            raise ValueError(f"Port {port} already belongs to a customer in this tunnel.")
        for registered in self.directory.parent.glob("*/ports.list"):
            if str(port) in registered.read_text().splitlines():
                raise ValueError(f"Port {port} is reserved by tunnel {registered.parent.name}.")
        for path in self.directory.parent.glob("*/access.json"):
            if port in listeners(load_json(path)):
                raise ValueError(f"Port {port} is reserved by another customer.")
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as probe:
            try:
                probe.bind(("127.0.0.1" if self.proxied else "0.0.0.0", port))
            except OSError:
                raise ValueError(f"Port {port} is already occupied. Choose another port.") from None
        return port

    def next_port(self):
        for number in range(19100 if self.proxied else 21000, 65536):
            try:
                return self.available_port(number)
            except ValueError:
                pass
        raise ValueError("No free customer port was found.")

    def add(self):
        print("Quota belongs to this entry port/path, not an Xray UUID. Another known entry can use a different allowance; limit or disable the default entry before distributing customer access.")
        def new_id(value):
            value = account_id(value)
            if any(item["id"] == value for item in self.config["accounts"]):
                raise ValueError("This ID already exists; choose a new one or edit the existing customer.")
            return value
        selected = prompt("Customer ID", validate=new_id)
        name = prompt("Customer name", selected, customer_name)
        quota = prompt("Customer quota in GB (0 = unlimited)", "100", gb_to_bytes)
        port = self.next_port() if self.proxied else prompt("Customer port", self.next_port(), self.available_port)
        item = {"id": selected, "name": name, "listen": f"{'127.0.0.1' if self.proxied else '0.0.0.0'}:{port}", "quota_bytes": quota, "enabled": True}
        config, routes = copy.deepcopy(self.config), dict(self.routes)
        config["accounts"].append(item)
        if self.proxied:
            routes[selected] = "/gdt-c/" + secrets.token_hex(24)
        self.commit(config, routes, public_ports=[] if self.proxied else [port])
        self.export(selected)

    def set_quota(self, supplied=None):
        item = self.choose(supplied)
        quota = prompt("New lifetime quota in GB (0 = unlimited; usage is retained)", str(decimal.Decimal(item["quota_bytes"]) / GB), gb_to_bytes)
        config = copy.deepcopy(self.config)
        next(x for x in config["accounts"] if x["id"] == item["id"])["quota_bytes"] = quota
        self.commit(config, self.routes)

    def total_quota(self):
        quota = prompt("Total tunnel quota in GB (0 = unlimited; usage is retained)", str(decimal.Decimal(self.config["total_quota_bytes"]) / GB), gb_to_bytes)
        config = copy.deepcopy(self.config)
        config["total_quota_bytes"] = quota
        self.commit(config, self.routes)

    def edit_ports(self, supplied=None, supplied_ports=None):
        if self.proxied:
            raise ValueError("Proxied customers share HTTPS ports; their private ports are automatic. Use the tunnel HTTPS-port menu for public ports.")
        item = self.choose(supplied)
        current = {int(x.rsplit(":", 1)[1]) for x in item["listen"].split(",")}
        def validate(value):
            ports = [port_number(x.strip()) for x in value.split(",")]
            if len(set(ports)) != len(ports):
                raise ValueError("A port appears more than once.")
            for port in ports:
                if port not in current:
                    self.available_port(port)
            return ports
        ports = validate(supplied_ports) if supplied_ports else prompt("New customer port(s), separated by commas", ",".join(str(x) for x in sorted(current)), validate)
        config = copy.deepcopy(self.config)
        next(x for x in config["accounts"] if x["id"] == item["id"])["listen"] = ",".join(f"0.0.0.0:{x}" for x in ports)
        self.commit(config, self.routes, public_ports=[x for x in ports if x not in current])
        self.export(item["id"])

    def toggle(self, supplied=None, enabled=False):
        item = self.choose(supplied)
        config = copy.deepcopy(self.config)
        next(x for x in config["accounts"] if x["id"] == item["id"])["enabled"] = enabled
        self.commit(config, self.routes)

    def export(self, supplied=None):
        item = self.choose(supplied)
        domain = self.env.get("IRAN_ENTRY_DOMAIN", "")
        payload = {"format": "UNUNKNOWNTUN_CUSTOMER_ENDPOINT_V1", "customer": item["name"],
                   "address": domain if self.proxied else self.env.get("IRAN_IP", ""),
                   "quota_gb": str(decimal.Decimal(item["quota_bytes"]) / GB),
                   "quota_note": "0 = unlimited; upload + download share the allowance; tunnel total allowance also applies",
                   "enabled": item["enabled"],
                   "authentication": "Use the Xray protocol and client credentials supplied separately by your provider. A port is not a password."}
        if self.proxied:
            path = self.routes.get(item["id"], self.env.get("IRAN_ENTRY_PATH", "") if item["id"] == "default" else "")
            if not path:
                raise ValueError("Customer route metadata is missing.")
            entry_transport = self.env.get("IRAN_ENTRY_TRANSPORT", "ws")
            payload.update(ports=[port_number(x) for x in self.env["IRAN_ENTRY_PORTS"].split(",")], transport="xhttp" if entry_transport == "xhttp" else "websocket", tls=True, sni=domain, host=domain, path=path)
            if entry_transport == "xhttp":
                payload.update(xhttp_mode="packet-up", compatibility="Experimental Xray client entry; configure matching inbound separately and test real payload traffic.")
        else:
            payload.update(ports=[port_number(x.rsplit(":", 1)[1]) for x in item["listen"].split(",")], transport="match the dedicated Xray inbound")
        exports = self.directory / "customer-exports"
        exports.mkdir(mode=0o700, exist_ok=True)
        path = exports / (item["id"] + ".json")
        atomic_write(path, encoded_json(payload), mode=0o600)
        print(encoded_json(payload), end="")
        print(f"Customer connection file: {path}")
        print("Share only this file plus the intended Xray client credentials; no server login or tunnel pairing token is included.")

    def run(self, *args, check=True):
        return subprocess.run(args, check=check, text=True, capture_output=True)

    def reload(self):
        service = "ununknowntun@" + self.id
        if self.run("systemctl", "is-active", "--quiet", service, check=False).returncode != 0:
            print("Tunnel is stopped. Saved configuration will apply on its next start.")
            return False
        requested_at = time.time_ns()
        self.run("systemctl", "kill", "--kill-who=main", "--signal=HUP", service)
        wanted = hashlib.sha256(self.path.read_bytes()).hexdigest()
        for _ in range(100):
            status = self.status()
            if (status.get("config_revision") == wanted and status.get("running") and
                    not status.get("error") and status.get("_fresh") and
                    status.get("_mtime_ns", 0) >= requested_at):
                if self.run("systemctl", "is-active", "--quiet", service, check=False).returncode == 0:
                    return True
                raise RuntimeError("The tunnel stopped while applying customer settings.")
            time.sleep(0.1)
        raise RuntimeError("The service did not acknowledge the new customer configuration.")

    def commit(self, config, routes, public_ports=()):
        old_config, old_routes = self.path.read_bytes(), self.routes_path.read_bytes() if self.routes_path.exists() else b"{}\n"
        auxiliary = {}
        for name in ("ports.list", "firewall-owned.ports", "deployment.env"):
            path = self.directory / name
            auxiliary[path] = path.read_bytes() if path.exists() else None
        site = None
        old_site = None
        if self.proxied:
            site = Path(self.env.get("NGINX_SITE", ""))
            if site.parent != Path("/etc/nginx/sites-available") or not site.name.startswith("ununknowntun-") or site.suffix != ".conf":
                raise ValueError("Managed Nginx site path is invalid.")
            old_site = site.read_bytes()
            new_site = build_routes(old_site.decode(), config, routes, self.env["IRAN_ENTRY_PATH"], self.env.get("IRAN_ENTRY_TRANSPORT", "ws"))
        (self.install_dir / "backups").mkdir(mode=0o700, parents=True, exist_ok=True)
        backup = Path(tempfile.mkdtemp(prefix=f"customers-{self.id}-", dir=self.install_dir / "backups"))
        os.chmod(backup, 0o700)
        atomic_write(backup / "access.json", old_config, mode=0o600)
        atomic_write(backup / "access-routes.json", old_routes, mode=0o600)
        for path, content in auxiliary.items():
            if content is not None:
                atomic_write(backup / path.name, content, mode=0o600)
        if old_site is not None:
            atomic_write(backup / "nginx.conf", old_site, mode=0o600)
        added_rules = []
        removed_rules = []
        try:
            atomic_write(self.path, encoded_json(config))
            atomic_write(self.routes_path, encoded_json(routes), mode=0o600)
            if site:
                atomic_write(site, new_site, mode=0o644)
                self.run("nginx", "-t")
            self.reload()
            if site:
                self.run("systemctl", "reload", "nginx")
            if public_ports and shutil.which("ufw"):
                status = self.run("ufw", "status", check=False)
                if "Status: active" in status.stdout:
                    for port in public_ports:
                        result = self.run("ufw", "allow", "proto", "tcp", "from", "0.0.0.0/0", "to", "0.0.0.0/0", "port", str(port))
                        if "Rule added" in result.stdout or "Rules updated" in result.stdout:
                            added_rules.append(port)
            registry = self.directory / "ports.list"
            existing = {int(x) for x in registry.read_text().splitlines() if x.isdigit()} if registry.exists() else set()
            registered = (existing - listeners(self.config)) | listeners(config)
            released = listeners(self.config) - registered
            atomic_write(self.directory / "ports.list", "".join(f"{x}\n" for x in sorted(registered)))
            owned_path = self.directory / "firewall-owned.ports"
            owned = set(owned_path.read_text().splitlines()) if owned_path.exists() else set()
            for port in sorted(released):
                if str(port) not in owned:
                    continue
                if not shutil.which("ufw"):
                    raise RuntimeError(f"Cannot safely release owned firewall port {port}: UFW is unavailable.")
                self.run("ufw", "--force", "delete", "allow", "proto", "tcp", "from", "0.0.0.0/0", "to", "0.0.0.0/0", "port", str(port))
                removed_rules.append(port)
            if added_rules or removed_rules:
                next_owned = (owned | {str(x) for x in added_rules}) - {str(x) for x in removed_rules}
                atomic_write(owned_path, "".join(x + "\n" for x in sorted(next_owned, key=int)))
            if not self.proxied:
                default = next((item for item in config["accounts"] if item["id"] == "default"), None)
                if default:
                    ports = ",".join(str(int(x.rsplit(":", 1)[1])) for x in default["listen"].split(","))
                    env_path = self.directory / "deployment.env"
                    lines = env_path.read_text().splitlines()
                    for key in ("LOCAL_PORTS", "IRAN_ENTRY_PORTS"):
                        lines = [line for line in lines if not line.startswith(key + "=")]
                        lines.append(key + "=" + shlex.quote(ports))
                    atomic_write(env_path, "\n".join(lines) + "\n")
        except BaseException:
            recovery_errors = []
            def recover(label, operation):
                try:
                    operation()
                    return True
                except Exception as error:
                    recovery_errors.append(f"{label}: {error}")
                    return False
            restored_config = recover("restore customer configuration", lambda: atomic_write(self.path, old_config))
            recover("restore customer routes", lambda: atomic_write(self.routes_path, old_routes, mode=0o600))
            for path, content in auxiliary.items():
                if content is None:
                    if path.exists():
                        recover(f"remove new {path.name}", lambda path=path: path.unlink())
                else:
                    recover(f"restore {path.name}", lambda path=path, content=content: atomic_write(path, content))
            if site:
                restored_site = recover("restore Nginx configuration", lambda: atomic_write(site, old_site, mode=0o644))
            for port in added_rules:
                recover(f"remove new firewall rule {port}", lambda port=port: self.run("ufw", "--force", "delete", "allow", "proto", "tcp", "from", "0.0.0.0/0", "to", "0.0.0.0/0", "port", str(port)))
            for port in removed_rules:
                recover(f"restore firewall rule {port}", lambda port=port: self.run("ufw", "allow", "proto", "tcp", "from", "0.0.0.0/0", "to", "0.0.0.0/0", "port", str(port)))
            confirmed = restored_config and recover("confirm restored customer configuration", self.reload)
            if not confirmed:
                service = "ununknowntun@" + self.id
                stopped = recover("stop affected tunnel", lambda: self.run("systemctl", "stop", service))
                if stopped:
                    print(f"Stopped {service} because previous customer limits could not be safely restored.", file=sys.stderr)
            if site and restored_site:
                def restore_nginx():
                    self.run("nginx", "-t")
                    self.run("systemctl", "reload", "nginx")
                recover("reload restored Nginx configuration", restore_nginx)
            if recovery_errors:
                print(f"Recovery needs attention: {'; '.join(recovery_errors)}. Backup: {backup}", file=sys.stderr)
            else:
                print(f"Previous customer settings restored. Backup: {backup}", file=sys.stderr)
            raise
        self.config, self.routes = config, routes
        self.env = read_env(self.directory / "deployment.env")
        print(f"Customer settings applied. Usage was retained. Recovery copy: {backup}")


def initial_config(config_dir, local_ports, total_gb, proxied):
    directory = Path(config_dir)
    path = directory / "access.json"
    if path.exists():
        raise ValueError("Customer configuration already exists; use customer management to edit it.")
    ports = [port_number(x) for x in local_ports.split(",")]
    if len(set(ports)) != len(ports):
        raise ValueError("Duplicate initial customer ports.")
    host = "127.0.0.1" if proxied else "0.0.0.0"
    config = {"version": 1, "total_quota_bytes": gb_to_bytes(total_gb), "accounts": [
        {"id": "default", "name": "Default access", "listen": ",".join(f"{host}:{x}" for x in ports), "quota_bytes": 0, "enabled": True}]}
    service_user = pwd.getpwnam("ununknowntun")
    atomic_write(path, encoded_json(config), owner=(0, service_user.pw_gid))
    atomic_write(directory / "access-routes.json", "{}\n", mode=0o600)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("init", "list", "add", "quota", "total-quota", "disable", "enable", "export", "ports", "menu"))
    parser.add_argument("--config-dir", required=True)
    parser.add_argument("--state-dir")
    parser.add_argument("--customer")
    parser.add_argument("--ports")
    parser.add_argument("--quota-gb", default="0")
    parser.add_argument("--proxied", action="store_true")
    args = parser.parse_args()
    if os.geteuid() != 0:
        parser.error("Run customer management as root.")
    if args.action == "init":
        initial_config(args.config_dir, args.ports or "", args.quota_gb, args.proxied)
        return
    if not args.state_dir:
        parser.error("--state-dir is required")
    with open("/run/ununknowntun-installer.lock", "a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            parser.error("Another tunnel configuration operation is running; retry after it finishes.")
        manager = Manager(args.config_dir, args.state_dir)
        action = args.action
        while True:
            if action == "menu":
                print("\n1) Customers and usage\n2) Add customer port/access\n3) Change customer quota\n4) Disable customer\n5) Enable customer\n6) Export customer connection\n7) Total tunnel quota\n8) Change customer port\n0) Exit")
                choice = prompt("Option", "1", lambda x: x if x in "012345678" and len(x) == 1 else (_ for _ in ()).throw(ValueError("Choose 0-8.")))
                if choice == "0":
                    return
                selected = {"1": "list", "2": "add", "3": "quota", "4": "disable", "5": "enable", "6": "export", "7": "total-quota", "8": "ports"}[choice]
            else:
                selected = action
            try:
                if selected == "list": manager.show()
                elif selected == "add": manager.add()
                elif selected == "quota": manager.set_quota(args.customer)
                elif selected == "total-quota": manager.total_quota()
                elif selected == "disable": manager.toggle(args.customer, False)
                elif selected == "enable": manager.toggle(args.customer, True)
                elif selected == "export": manager.export(args.customer)
                elif selected == "ports": manager.edit_ports(args.customer, args.ports)
            except (ValueError, RuntimeError, OSError, subprocess.CalledProcessError) as exc:
                print(f"Could not apply customer operation: {exc}", file=sys.stderr)
                if action != "menu":
                    raise SystemExit(1)
            if action != "menu":
                return


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, subprocess.CalledProcessError) as error:
        print(f"Customer manager: {error}", file=sys.stderr)
        sys.exit(1)
