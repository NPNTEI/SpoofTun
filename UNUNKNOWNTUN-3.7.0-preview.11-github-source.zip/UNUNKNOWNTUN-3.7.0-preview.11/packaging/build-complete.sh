#!/usr/bin/env bash
# BUILD HOST ONLY. This script builds/tests files; it does not install services.
set -Eeuo pipefail
umask 022
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="${1:-$ROOT_DIR/release}"
GO_BIN="${GO_BIN:-go}"
command -v "$GO_BIN" >/dev/null || { echo 'Go 1.26.10+ is required; use a supported, security-patched toolchain.' >&2; exit 1; }
command -v python3 >/dev/null
[[ "$("$GO_BIN" env GOOS)" == linux ]] || { echo 'The complete test/race/build pipeline requires a Linux build host.' >&2; exit 1; }
mkdir -p "$OUT_DIR/bin"
cd "$ROOT_DIR"
"$GO_BIN" mod verify
"$GO_BIN" test -buildvcs=false -count=1 -timeout=180s ./...
"$GO_BIN" vet -buildvcs=false ./...
CGO_ENABLED=1 "$GO_BIN" test -race -buildvcs=false -count=1 -timeout=240s ./...
python3 "$ROOT_DIR/packaging/test-full-installer.py"
python3 "$ROOT_DIR/packaging/test-ui-installer.py"
python3 "$ROOT_DIR/packaging/test-package-preview.py"
python3 "$ROOT_DIR/packaging/test-access-manager.py"
python3 "$ROOT_DIR/packaging/test-manager.py"
python3 "$ROOT_DIR/packaging/test-upgrade.py"
python3 "$ROOT_DIR/packaging/test-tunnel-editor.py"
python3 "$ROOT_DIR/packaging/test-editor-tls.py"
python3 "$ROOT_DIR/packaging/test-editor-safety.py"
python3 "$ROOT_DIR/packaging/test-editor-integration.py"
python3 "$ROOT_DIR/packaging/test-transport-profiles.py"
python3 "$ROOT_DIR/packaging/test-entry-migrations.py"
python3 "$ROOT_DIR/packaging/test-tunnel-doctor.py"
python3 "$ROOT_DIR/packaging/test-cdn-endpoints.py"
python3 "$ROOT_DIR/packaging/test-cdn-control.py"
python3 "$ROOT_DIR/packaging/test-cdn-delete.py"
python3 "$ROOT_DIR/packaging/test-scanner-engine.py"
python3 "$ROOT_DIR/packaging/test-scanner-console.py"
python3 "$ROOT_DIR/packaging/test-scanner-rounds.py"
python3 "$ROOT_DIR/packaging/test-scanner-integration.py"
python3 "$ROOT_DIR/packaging/test-advanced-editor.py"
python3 "$ROOT_DIR/packaging/test-advanced-installer.py"
python3 "$ROOT_DIR/packaging/test-resilience-installer.py"
python3 "$ROOT_DIR/packaging/test-spoof-pair.py"
python3 "$ROOT_DIR/packaging/test-spoof-installer.py"
python3 "$ROOT_DIR/packaging/test-icmp-pair.py"
python3 "$ROOT_DIR/packaging/test-icmp-installer.py"
python3 "$ROOT_DIR/packaging/test-direct-icmp-pair.py"
python3 "$ROOT_DIR/packaging/test-direct-icmp-setup.py"
python3 "$ROOT_DIR/packaging/test-direct-icmp-installer.py"
python3 "$ROOT_DIR/packaging/test-direct-icmp-console.py"
python3 "$ROOT_DIR/tests/test-gre-wire-check.py"
python3 -I "$ROOT_DIR/tests/spoof-systemd-lab.py" --self-test
python3 -I "$ROOT_DIR/tests/icmp-netns-lab.py" --self-test
python3 -I "$ROOT_DIR/tests/icmp-wss-lab.py" --self-test
python3 -I "$ROOT_DIR/tests/direct-icmp-systemd-lab.py" --self-test
python3 -I "$ROOT_DIR/tests/direct-icmp-systemd-pools-lab.py" --self-test
python3 -I "$ROOT_DIR/tests/direct-icmp-forward-lab.py" --self-test
python3 -I "$ROOT_DIR/tests/direct-icmp-console-lab.py" --self-test
python3 "$ROOT_DIR/ui/run-tests.py"
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 GOAMD64=v1 "$GO_BIN" build \
  -trimpath -buildvcs=false -ldflags='-s -w -buildid=' -o "$OUT_DIR/bin/ununknowntun-linux-amd64" .
CGO_ENABLED=0 GOOS=linux GOARCH=arm64 "$GO_BIN" build \
  -trimpath -buildvcs=false -ldflags='-s -w -buildid=' -o "$OUT_DIR/bin/ununknowntun-linux-arm64" .
if [[ -n "${UNUNKNOWNTUN_TEST_NGINX:-}" ]]; then
  native_arch="$("$GO_BIN" env GOARCH)"
  [[ "$native_arch" == amd64 || "$native_arch" == arm64 ]] || { echo 'Nginx integration needs an amd64/arm64 Linux build host.' >&2; exit 1; }
  python3 "$ROOT_DIR/tests/nginx_integration.py" --binary "$OUT_DIR/bin/ununknowntun-linux-$native_arch" --nginx "$UNUNKNOWNTUN_TEST_NGINX"
fi
python3 "$ROOT_DIR/packaging/render-complete.py" "$OUT_DIR"
echo 'Build complete. This does not certify a real Iran-to-foreign network path.'
