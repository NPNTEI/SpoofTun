#!/usr/bin/env python3
"""Opt-in Cloudflare scanning, guarded edits and per-tunnel systemd scheduling.

Scanning uses certificate + carrier authentication, NOT target payload or speed.
Only the selected managed origin can be edited; stopped services stay stopped.
"""
import argparse
import contextlib
import datetime
import fcntl
import importlib.util
import ipaddress
import json
import math
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import tempfile
import uuid


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(filename))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


scanner = module("cdn_scanner", "cdn-endpoints.py")
editor = module("cdn_editor", "tunnel-editor.py")
MARKER = "# Managed by UNUNKNOWNTUN CDN controller v1\n"


def run(*args, check=True):
    return subprocess.run(args, check=check, capture_output=True, text=True,
                          timeout=45, env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"})


@contextlib.contextmanager
def lock(path, inherited=None):
    if inherited is not None:
        if inherited != 9 or os.fstat(inherited).st_ino != Path(path).stat().st_ino or os.fstat(inherited).st_dev != Path(path).stat().st_dev:
            raise ValueError("Invalid inherited installation lock.")
        fcntl.flock(inherited, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield
        return  # Parent retains ownership; never unlock its descriptor.
    with open(path, "a") as handle:
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise ValueError("Another scan or edit is running; try again later.") from error
        yield


def profile_for_verify(directory):
    directory = Path(directory)
    env = scanner.parse_env(scanner.read_small(directory / "deployment.env"))
    flags = scanner.parse_flags(scanner.read_small(directory / "run.sh"))
    if env.get("ROLE") != "origin" or flags.get("mode") != "origin":
        raise ValueError("Run this check on the connection-initiating origin.")
    if flags.get("token-file") != str(directory / "token") or flags.get("token") or flags.get("spoof-config"):
        raise ValueError("This check requires the managed tunnel token and a non-GRE carrier.")
    return {"provider": env.get("FOREIGN_PROXY_PROVIDER"), "current_endpoint": flags.get("connect", "").split(",")[0],
            "flags": flags, "token_file": str(directory / "token"), "binary": "/usr/local/bin/ununknowntun"}


def verify(directory):
    profile = profile_for_verify(directory)
    outcome = scanner.probe_endpoint(profile, profile["current_endpoint"], 20)
    if not outcome["ok"]:
        raise RuntimeError("Configured carrier probe failed at " + outcome["stage"] + ": " + outcome["reason"])
    print("[PASS] Actual configured TLS/carrier/token authenticated. Target payload was not tested.")


def apply_candidate(instance, profile, report, reload_profile, probe=scanner.probe_endpoint, background=False):
    """Caller holds global edit lock. Failed post-check rolls back via editor."""
    fresh = reload_profile()
    if fresh["revision"] != profile["revision"]:
        raise ValueError("Tunnel or scan settings changed during scanning; result discarded.")
    if report.get("local_error"):
        raise ValueError("A local core/configuration error invalidated this scan; no endpoint change applied.")
    if not report.get("changed"):
        return False
    host, port = scanner.validate_endpoint(report["selected_endpoint"])
    _, old_port = scanner.validate_endpoint(profile["current_endpoint"])
    if port != old_port:
        raise ValueError("Scanner cannot change the paired HTTPS port.")
    # Report data is not authority: verify membership and certificate/auth again.
    if not any(row["endpoint"] == report["selected_endpoint"] and row.get("fully_authenticated") is True
               for row in report["results"]):
        raise ValueError("Selected endpoint lacks a completed authentication result.")
    scanner._cf_network(host)
    plan = instance.plan("connect_host", host, emit=False)
    plan["background"] = background
    def post_validate():
        updated = reload_profile()
        result = probe(updated, updated["current_endpoint"], 20)
        if not result["ok"]:
            raise RuntimeError("Post-change " + result["stage"] + " check failed; reverting endpoint.")
    instance.commit(plan, post_validate=post_validate)
    return True


def scan(directory, periodic=False, inherited=None, preview=False):
    directory = Path(directory)
    if preview and (periodic or inherited is not None):
        raise ValueError("Preview is a manual read-only scan, not a periodic or initial apply operation.")
    instance = editor.Editor(directory, Path("/var/lib/ununknowntun") / directory.name)
    with lock("/run/ununknowntun-cdn-" + directory.name + ".lock"):
        profile = scanner.load_profile(directory)
        if periodic and (not profile["settings"]["enabled"] or not instance.active()):
            print("Automatic scan skipped: disabled or selected tunnel stopped.")
            return
        if inherited is not None and instance.active():
            raise ValueError("Initial setup scan requires a stopped new service.")
        print("Scanning bounded Cloudflare candidates; existing traffic is unchanged during probing.", flush=True)
        if preview:
            print("Preview only: endpoint and services will not be changed.", flush=True)
        else:
            print("Scan-and-apply: an authenticated improvement may restart this selected tunnel; established traffic may briefly reconnect.", flush=True)
        report = scanner.scan_profile(profile, progress=lambda event: scanner.print_progress(event, sys.stdout))
        with lock("/run/ununknowntun-installer.lock", inherited):
            if periodic and not instance.active():
                raise ValueError("Tunnel was stopped during scan; no endpoint change applied.")
            if preview:
                if scanner.load_profile(directory)["revision"] != profile["revision"]:
                    raise ValueError("Tunnel or scan settings changed during scanning; result discarded.")
                applied = False
            else:
                applied = apply_candidate(instance, profile, report, lambda: scanner.load_profile(directory), background=periodic)
            report["configuration_changed"] = applied
            report["preview_only"] = preview
            if applied:
                report["verdict"] = "authenticated-replacement-applied"
                report["reason"] = "Selected endpoint saved; post-change carrier authentication succeeded."
            editor.access.atomic_write(directory / "cdn-last-report.json", json.dumps(report, indent=2) + "\n", mode=0o600)
        print(report["reason"])
        if preview and report.get("changed"):
            print("Proposed endpoint: " + report["selected_endpoint"] + ". Run Scan-and-apply to recheck and apply; this preview is not an approval cache.")
        print("Current endpoint authenticated: " + ("yes" if report.get("current_authenticated") else "no") +
              "; authenticated alternatives: " + str(report.get("authenticated_candidates", 0)))
        for failure in scanner.failure_summary(report):
            print(str(failure["attempts"]) + " failed sample(s): " + failure["stage"] + " — " + failure["reason"])
        if report.get("timed_out"):
            print("Maximum scan budget reached; incomplete candidates cannot win. Increase the budget or reduce candidates/samples in scanner settings.")
        if scanner.rotation_probe_limited(profile, report):
            print("Rotating paths: each probe has a fresh route cursor and a bounded deadline. A timeout may occur before later/overlap paths are reached; it is not proof that this IP is unusable. Increase per-probe time (up to 20s), reduce candidates, or use a longer manual core check. Automatic replacement still requires every authentication sample plus a post-change check.")
        if not report.get("current_authenticated") and not report.get("authenticated_candidates"):
            print("No working carrier was certified. Check Host/path, paired settings, origin service and CDN proxy status; this does not prove IP filtering.")
        print("No target-payload, throughput or censorship-resistance guarantee. Full private report: " + str(directory / "cdn-last-report.json"))


def rounds_profile(profile):
    """Same Cloudflare/carrier eligibility as automatic scans; no scoring changes."""
    if profile.get("provider") != "cloudflare":
        raise ValueError("Guided tunnel scanning requires a Cloudflare origin profile.")
    flags = profile.get("flags", {})
    if flags.get("transport", "wss") not in ("wss", "xhttp") or flags.get("spoof-config"):
        raise ValueError("Guided Cloudflare scanning requires WSS/XHTTP without a native spoof underlay.")
    for key in ("sni", "ws-host"):
        value = flags.get(key)
        if not value:
            raise ValueError("The tunnel's TLS SNI and HTTP Host must be configured before scanning.")
        scanner.validate_endpoint(value)
    _, port = scanner.validate_endpoint(profile["current_endpoint"])
    if port not in scanner.CF_PORTS:
        raise ValueError("The configured port is not a supported Cloudflare HTTPS port.")
    settings = scanner.validate_settings(profile["settings"])
    scanner.preflight_profile(profile)
    return port, flags["sni"], settings


def trusted_round_helpers():
    """Use the installed stdlib scanner; never import a writable root helper."""
    console = Path(os.path.abspath(__file__)).with_name("scanner-console.py")
    for helper in (console, console.with_name("scanner-engine.py")):
        info = helper.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o022:
            raise ValueError("Guided scanner helpers must be regular, trusted, non-writable files.")
        if os.geteuid() == 0:
            for parent in helper.parents:
                info = parent.lstat()
                if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
                    raise ValueError("Root scanner helpers require trusted parent directories.")
    return console


def launch_round_console(port, sni, selected_output, report_dir):
    console = trusted_round_helpers()
    argv = [sys.executable, "-I", str(console), "rounds", "--port", str(port),
            "--sni", sni, "--authorized", "--selected-output", str(selected_output),
            "--report-dir", str(report_dir)]
    environment = {key: value for key, value in os.environ.items()
                   if not key.startswith(("PYTHON", "LD_", "DYLD_", "BASH_FUNC_"))
                   and key not in {"BASH_ENV", "ENV", "SHELLOPTS", "BASHOPTS", "UNUNKNOWNTUN_TOKEN", "V7_TOKEN"}}
    environment["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
    previous = signal.getsignal(signal.SIGINT)
    # The child receives Ctrl+C to stop its current round and offer selection.
    # A caught handler resets on exec, unlike SIG_IGN, which the child inherits.
    signal.signal(signal.SIGINT, lambda *_: None)
    try:
        # No process-wide timeout: the user may run as many rounds as needed.
        # Individual scanner probes and the subsequent carrier probes are bounded.
        return subprocess.run(argv, check=False, env=environment).returncode
    finally:
        signal.signal(signal.SIGINT, previous)


def authenticate_selection(profile, endpoint, settings, probe=None):
    """Every configured actual-carrier sample must pass; generic ping cannot win."""
    probe = probe or scanner.probe_endpoint
    times, failures, attempts, local_error = [], [], 0, False
    for index in range(settings["samples"]):
        attempts += 1
        limit = settings["probe_timeout_seconds"]
        print(f"[AUTH {index + 1}/{settings['samples']}] {endpoint}: actual configured tunnel authentication", flush=True)
        try:
            outcome = probe(profile, endpoint, limit)
            elapsed = outcome.get("elapsed_ms") if isinstance(outcome, dict) else None
            if (isinstance(outcome, dict) and outcome.get("ok") is True and
                    isinstance(elapsed, (float, int)) and not isinstance(elapsed, bool) and
                    math.isfinite(elapsed) and 0 <= elapsed <= limit * 1000):
                times.append(float(elapsed))
                continue
            if isinstance(outcome, dict) and outcome.get("ok") is True:
                stage, reason = "timeout", "Carrier probe exceeded its deadline or returned an invalid latency; sample was not certified."
            else:
                stage, reason = scanner.classify_failure("local" if not isinstance(outcome, dict) or outcome.get("stage") == "local" else str(outcome.get("stage", "")) + " " + str(outcome.get("reason", "")))
        except (OSError, ValueError, subprocess.SubprocessError):
            stage, reason = "local", "The actual carrier probe could not complete; this sample was not certified."
        failures.append({"stage": stage, "reason": reason})
        if stage == "local":
            local_error = True
            break
    record = {"endpoint": endpoint, "attempts": attempts, "successes": len(times),
              "fully_authenticated": len(times) == settings["samples"],
              "loss_percent": round((1 - len(times) / attempts) * 100, 1) if attempts else 100.0,
              "failures": failures}
    record.update(scanner.latency_stats(times))
    return record, local_error


def rounds(directory):
    """Manual IP choice, authenticated and committed through the existing editor."""
    directory = Path(directory)
    instance = editor.Editor(directory, Path("/var/lib/ununknowntun") / directory.name)
    with lock("/run/ununknowntun-cdn-" + directory.name + ".lock"):
        profile = scanner.load_profile(directory)
        port, sni, settings = rounds_profile(profile)
        trusted_round_helpers()
        console = module("round_console_helpers", "scanner-console.py")
        reports = instance.state_dir / "scanner-reports"
        os.close(console._dir_fd(reports, create=True, private=True))
        session_dir = reports / ("rounds-" + uuid.uuid4().hex)
        os.close(console._dir_fd(session_dir, create=True, private=True))
        report = {"schema": 1, "mode": "manual-guided-rounds",
                  "time_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  "provider": "cloudflare", "current_endpoint": scanner.normalize_endpoint(profile["current_endpoint"]),
                  "selected_endpoint": None, "changed": False, "configuration_changed": False,
                  "automatic_policy_changed": False, "improvement_threshold_bypassed": True,
                  "target_payload_tested": False, "local_preflight_passed": True,
                  "samples_per_endpoint": settings["samples"], "results": [], "local_error": False,
                  "cancelled": False, "verdict": "not-applied", "reports_directory": str(session_dir),
                  "reason": "No endpoint change was applied."}
        print(f"Guided tunnel scan: port {port} and SNI inherited from this tunnel. Automatic scanning settings stay unchanged.", flush=True)
        print("The IP you select will require every actual tunnel authentication sample and a post-change check. Applying it may briefly reconnect this tunnel.", flush=True)
        try:
            with tempfile.TemporaryDirectory(prefix=".selection-", dir=session_dir) as temporary:
                selected_output = Path(temporary) / "selected-ip"
                status = launch_round_console(port, sni, selected_output, session_dir)
                if status != 0:
                    report.update(cancelled=status in (130, -signal.SIGINT), verdict="cancelled" if status in (2, 130, -signal.SIGINT) else "scanner-failed",
                                  reason="Scanner finished without an accepted selection; endpoint retained.")
                    return 130 if report["cancelled"] else 2 if status == 2 else 1
                # Reject stale choices before spending authentication requests.
                if scanner.load_profile(directory)["revision"] != profile["revision"]:
                    raise ValueError("Tunnel or scan settings changed during scanning; result discarded.")
                raw = console.read_text(selected_output, maximum=64, secret=True)
                if raw != raw.strip() + "\n":
                    raise ValueError("Scanner returned an invalid selected-IP file.")
                chosen = str(ipaddress.IPv4Address(raw.strip()))
                scanner._cf_network(chosen)
                endpoint = scanner.address(chosen, port)
                report["selected_endpoint"] = endpoint
                result, report["local_error"] = authenticate_selection(profile, endpoint, settings)
                report["results"] = [result]
                if not result["fully_authenticated"] or report["local_error"]:
                    report.update(verdict="authentication-failed", reason="Selected IP did not pass every configured carrier authentication sample; endpoint retained.")
                    print(report["reason"], flush=True)
                    return 1
                report["changed"] = endpoint != report["current_endpoint"]
                # Interaction/probes never hold the global lock. The existing
                # editor rechecks the revision under this final mutation lock.
                with lock("/run/ununknowntun-installer.lock"):
                    applied = apply_candidate(instance, profile, report, lambda: scanner.load_profile(directory),
                                              probe=scanner.probe_endpoint)
                report.update(configuration_changed=applied,
                              verdict="manual-authenticated-replacement-applied" if applied else "current-authenticated-retained",
                              reason="Selected endpoint saved and post-change authentication passed." if applied else "Selected endpoint already matches the configured endpoint; authentication passed.")
                print(report["reason"], flush=True)
                return 0
        except KeyboardInterrupt:
            report.update(cancelled=True, verdict="cancelled", reason="Operation cancelled; uncommitted changes were discarded or rolled back.")
            raise
        except (OSError, ValueError, RuntimeError, subprocess.SubprocessError, EOFError):
            report.update(verdict="not-applied", reason="Selection, configuration revision or transactional validation failed; no new endpoint was committed.")
            raise
        finally:
            encoded = json.dumps(report, indent=2, allow_nan=False) + "\n"
            console.private_write(session_dir / "controller-result.json", encoded, private_parent=True)
            editor.access.atomic_write(directory / "cdn-rounds-last-report.json", encoded, mode=0o600)
            print("Full private round reports: " + str(session_dir), flush=True)


def unit_texts(tunnel_id, settings):
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,47}", tunnel_id) or "--" in tunnel_id:
        raise ValueError("Invalid tunnel ID.")
    settings = scanner.validate_settings(settings)
    service = MARKER + "[Unit]\nDescription=UNUNKNOWNTUN authenticated CDN scan " + tunnel_id + "\nAfter=network-online.target\n\n[Service]\nType=oneshot\nExecStart=/usr/bin/python3 /opt/ununknowntun/share/cdn-control.py scan --periodic --config-dir /etc/ununknowntun/tunnels/" + tunnel_id + "\nTimeoutStartSec=750\nUMask=0077\nNice=10\n"
    # OnUnitInactiveSec prevents overlapping runs; Persistent=false avoids a
    # catch-up restart when a machine boots after extended downtime.
    timer = MARKER + "[Unit]\nDescription=UNUNKNOWNTUN opt-in CDN scan timer " + tunnel_id + "\n\n[Timer]\nOnBootSec=10min\nOnUnitInactiveSec=" + str(settings["interval_hours"]) + "h\nRandomizedDelaySec=60\nPersistent=false\n\n[Install]\nWantedBy=timers.target\n"
    return service, timer


def schedule(directory, disable=False, unit_dir=Path("/etc/systemd/system"), runner=run):
    directory = Path(directory)
    settings = scanner.load_settings(directory / "cdn-endpoints.json") if not disable else dict(scanner.DEFAULT_SETTINGS)
    if not disable and settings["enabled"]:
        profile = profile_for_verify(directory)
        if profile["provider"] != "cloudflare" or profile["flags"].get("transport", "wss") not in ("wss", "xhttp"):
            raise ValueError("Automatic CDN scanning requires a Cloudflare origin using WSS/XHTTP.")
    name = "ununknowntun-cdn-" + directory.name
    service, timer = unit_texts(directory.name, settings)
    paths = [unit_dir / (name + ".service"), unit_dir / (name + ".timer")]
    snapshots = {}
    for path in paths:
        if path.is_symlink() or (path.exists() and not path.read_text().startswith(MARKER)):
            raise ValueError("Unrelated scheduler file exists; it was not changed.")
        snapshots[path] = path.read_bytes() if path.exists() else None
    old_enabled = runner("systemctl", "is-enabled", name + ".timer", check=False).stdout.strip()
    if old_enabled not in {"enabled", "enabled-runtime", "disabled", "not-found"}:
        raise ValueError("Unmanaged scheduler enable state; no changes applied: " + old_enabled)
    old_active = runner("systemctl", "is-active", "--quiet", name + ".timer", check=False).returncode == 0
    try:
        if disable or not settings["enabled"]:
            if paths[1].exists(): runner("systemctl", "disable", "--now", name + ".timer")
            if paths[0].exists(): runner("systemctl", "stop", name + ".service")
            print("Automatic CDN updates disabled for " + directory.name + ".")
            return
        for path, content in zip(paths, (service, timer)):
            editor.access.atomic_write(path, content, mode=0o644)
        runner("systemctl", "daemon-reload")
        runner("systemctl", "enable", name + ".timer")
        runner("systemctl", "restart", name + ".timer")
    except BaseException as original:
        recovery_errors = []
        def recover(label, operation):
            try:
                result = operation()
                if result is not None and getattr(result, "returncode", 0):
                    raise RuntimeError("Recovery command failed.")
            except Exception:
                recovery_errors.append(label)
        # Attempt every recovery step even if a command times out or a file
        # restore fails. Never knowingly re-enable a partially restored timer.
        if paths[1].exists() or old_active or old_enabled in ("enabled", "enabled-runtime"):
            recover("stop timer", lambda: runner("systemctl", "stop", name + ".timer"))
            recover("disable timer", lambda: runner("systemctl", "disable", name + ".timer"))
        for path, content in snapshots.items():
            def restore(path=path, content=content):
                if content is None:
                    if path.exists(): path.unlink()  # exact owned file created above
                else: editor.access.atomic_write(path, content, mode=0o644)
            recover("restore " + path.name, restore)
        recover("reload scheduler", lambda: runner("systemctl", "daemon-reload"))
        # Clear any persistent link created by the failed update before restoring
        # a runtime-only enable. Never promote runtime state across reboots.
        if not recovery_errors:
            if old_enabled == "enabled":
                recover("restore persistent enable", lambda: runner("systemctl", "enable", name + ".timer", check=False))
            elif old_enabled == "enabled-runtime":
                recover("restore runtime enable", lambda: runner("systemctl", "enable", "--runtime", name + ".timer", check=False))
            if not recovery_errors:
                recover("restore timer activity", lambda: runner("systemctl", "start" if old_active else "stop", name + ".timer", check=False))
        if recovery_errors:
            recover("final disable timer", lambda: runner("systemctl", "disable", "--now", name + ".timer"))
            raise RuntimeError("Scheduler update failed and recovery was incomplete (" + ", ".join(recovery_errors) + "); automatic updates must be checked manually. Tunnel settings were not changed.") from original
        raise
    print("Automatic scans enabled every " + str(settings["interval_hours"]) + " hours. Only this origin can be restarted after authenticated improvement.")


def menu(directory):
    path = directory / "cdn-endpoints.json"
    value = scanner.load_settings(path) if path.exists() else dict(scanner.DEFAULT_SETTINGS)
    env = scanner.parse_env(scanner.read_small(directory / "deployment.env"))
    if env.get("ROLE") != "origin" or env.get("FOREIGN_PROXY_PROVIDER") != "cloudflare":
        raise ValueError("Built-in scheduled scanning is only for a Cloudflare origin. Use Edit for manual addresses on any CDN.")
    print("Cloudflare scan settings. No scan starts until you choose Scan or enable the timer.")
    def integer(key, label, low, high):
        while True:
            raw = input(label + " [" + str(value[key]) + "]: ").strip()
            if not raw: return
            if raw.isascii() and raw.isdigit() and low <= int(raw) <= high:
                value[key] = int(raw); return
            print("Enter a whole number from " + str(low) + " to " + str(high) + ". Earlier answers retained.")
    integer("duration_seconds", "Maximum scan seconds", 10, 600)
    integer("max_candidates", "Maximum candidate IPs", 1, 128)
    integer("samples", "Authentication samples per candidate", 1, 3)
    integer("probe_timeout_seconds", "Per-probe timeout seconds", 1, 20)
    integer("minimum_improvement_percent", "Minimum latency improvement percent", 0, 90)
    integer("interval_hours", "Automatic scan interval hours", 1, 168)
    while True:
        raw = input("Candidate list: enter official, or comma-separated Cloudflare IPs/CIDRs [keep]: ").strip()
        if not raw: break
        candidate = dict(value, candidate_source="official" if raw == "official" else "manual", candidates=[] if raw == "official" else [x.strip() for x in raw.split(",")])
        try: value = scanner.validate_settings(candidate); break
        except ValueError as error: print(str(error))
    while True:
        raw = input("Enable automatic update? y/n [" + ("y" if value["enabled"] else "n") + "]: ").strip().lower()
        if not raw: break
        if raw in ("y", "n"): value["enabled"] = raw == "y"; break
        print("Enter y or n.")
    value = scanner.validate_settings(value)
    before = path.read_bytes() if path.exists() else None
    editor.access.atomic_write(path, json.dumps(value, indent=2) + "\n", mode=0o600)
    try: schedule(directory)
    except BaseException:
        if before is None: path.unlink()
        else: editor.access.atomic_write(path, before, mode=0o600)
        raise
    print("Saved. Run ununknowntunctl cdn-scan " + directory.name + " to scan now.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("menu", "scan", "preview", "rounds", "status", "schedule", "unschedule", "verify"))
    parser.add_argument("--config-dir", required=True)
    parser.add_argument("--periodic", action="store_true")
    parser.add_argument("--initial-lock-fd", type=int)
    args = parser.parse_args()
    if args.periodic and args.action != "scan":
        parser.error("--periodic is only valid for scan.")
    if args.initial_lock_fd is not None and args.action not in ("scan", "schedule", "unschedule"):
        parser.error("--initial-lock-fd is only valid for installer scan/schedule/unschedule.")
    directory = Path(args.config_dir)
    if os.geteuid() != 0: parser.error("Run as root.")
    if directory.parent != Path("/etc/ununknowntun/tunnels") or directory.is_symlink() or not directory.is_dir():
        parser.error("Select an existing managed tunnel directory.")
    editor.access.account_id(directory.name)
    for path in (directory, directory / "run.sh", directory / "deployment.env", directory / "token"):
        info = path.lstat()
        if path.is_symlink() or info.st_uid != 0 or info.st_mode & 0o022:
            parser.error("Unsafe managed ownership/permissions.")
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    if args.action == "verify": verify(directory)
    elif args.action == "rounds": return rounds(directory)
    elif args.action in ("scan", "preview"): scan(directory, args.periodic, args.initial_lock_fd, preview=args.action == "preview")
    elif args.action == "status":
        path = directory / "cdn-endpoints.json"
        print(json.dumps(scanner.load_settings(path) if path.exists() else scanner.DEFAULT_SETTINGS, indent=2))
        result = run("systemctl", "is-active", "ununknowntun-cdn-" + directory.name + ".timer", check=False)
        print("Timer: " + result.stdout.strip())
    elif args.action in ("schedule", "unschedule"):
        with lock("/run/ununknowntun-installer.lock", args.initial_lock_fd):
            schedule(directory, disable=args.action == "unschedule")
    else:
        with lock("/run/ununknowntun-installer.lock"): menu(directory)


if __name__ == "__main__":
    try: sys.exit(main() or 0)
    except (ValueError, OSError, RuntimeError, subprocess.SubprocessError, KeyboardInterrupt, EOFError) as error:
        print("CDN controller stopped: " + str(error), file=sys.stderr)
        sys.exit(1)
