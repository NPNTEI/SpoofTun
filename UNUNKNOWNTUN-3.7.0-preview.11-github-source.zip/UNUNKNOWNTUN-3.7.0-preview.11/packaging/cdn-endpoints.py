#!/usr/bin/env python3
"""Bounded Cloudflare endpoint discovery using the actual UNUNKNOWNTUN carrier.

This helper never edits a tunnel, restarts a service, or installs a timer. Its
selection is a proposal for the transactional manager, which must recheck the
configuration revision and probe after a change before committing it.

IP-list parsing and latency statistics are adapted from SIKDPI Scanner 0.2.1,
Copyright (c) 2026 SIKDPI contributors, MIT. The full notice is preserved below.
Unlike that scanner's generic TLS probes, every success here requires the real
core's certificate verification, chosen handshake, carrier and authentication.
"""
import argparse
import datetime
import hashlib
import ipaddress
import json
import math
import os
from pathlib import Path
import random
import re
import shlex
import stat
import subprocess
import sys
import time

SIKDPI_LICENSE = """MIT License
Copyright (c) 2026 SIKDPI contributors
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

# Official public IPv4 list, verified 2026-10-04. No hidden network download.
# Source: https://www.cloudflare.com/ips-v4/
# A listed address is a candidate, never a promise of reachability or service.
CF_SOURCE = "https://www.cloudflare.com/ips-v4/"
CF_SNAPSHOT_DATE = "2026-10-04"
CF_IPV4 = tuple(ipaddress.ip_network(value) for value in (
    "173.245.48.0/20", "103.21.244.0/22", "103.22.200.0/22",
    "103.31.4.0/22", "141.101.64.0/18", "108.162.192.0/18",
    "190.93.240.0/20", "188.114.96.0/20", "197.234.240.0/22",
    "198.41.128.0/17", "162.158.0.0/15", "104.16.0.0/13",
    "104.24.0.0/14", "172.64.0.0/13", "131.0.72.0/22",
))
CF_PORTS = {443, 2053, 2083, 2087, 2096, 8443}
MAX_FILE = 1024 * 1024
MAX_CANDIDATES = 128
DEFAULT_SETTINGS = {
    "schema": 1, "enabled": False, "duration_seconds": 300,
    "max_candidates": 64, "samples": 2, "probe_timeout_seconds": 6,
    "minimum_improvement_percent": 15, "interval_hours": 8,
    "candidate_source": "official", "candidates": [],
}
PROBE_FLAGS = (
    "transport", "sni", "ws-host", "ws-path", "xhttp-path", "xhttp-mode",
    "utls-profile", "ech-mode", "ech-doh", "ech-config", "tls-fragment",
    "tls-fragment-size", "tls-fragment-interval", "tls-min-version", "mux",
    "padding-bytes", "xhttp-padding-bytes", "ca", "fingerprint", "system-ca",
    "path-rotation", "path-count", "path-grace", "path-legacy",
)


class EndpointError(ValueError):
    pass


def _integer(value, name, minimum, maximum):
    if isinstance(value, bool) or not isinstance(value, int) or not minimum <= value <= maximum:
        raise EndpointError(f"{name} must be a whole number from {minimum} to {maximum}.")
    return value


def validate_endpoint(value, default_port=443):
    """Normalize one IPv4, IPv6 or DNS host, optionally followed by a port."""
    if not isinstance(value, str) or not value or value != value.strip() or len(value) > 300:
        raise EndpointError("Endpoint must be one IP or domain, optionally with a port.")
    if any(ord(c) < 33 for c in value) or any(c in value for c in "/@?#\\$`;\"'"):
        raise EndpointError("Use an IP/domain, not a URL, range, shell expression or credential.")
    _integer(default_port, "Default port", 1, 65535)
    host, port = value, default_port
    if value.startswith("["):
        match = re.fullmatch(r"\[([^]]+)\](?::([0-9]+))?", value)
        if not match:
            raise EndpointError("Use [IPv6]:port for an explicit IPv6 port.")
        host, port = match[1], int(match[2]) if match[2] else default_port
        try:
            if ipaddress.ip_address(host).version != 6:
                raise ValueError
        except ValueError as error:
            raise EndpointError("Brackets are reserved for IPv6 addresses.") from error
    elif value.count(":") == 1:
        host, raw_port = value.rsplit(":", 1)
        if not raw_port.isascii() or not raw_port.isdigit():
            raise EndpointError("Endpoint port must be numeric.")
        port = int(raw_port)
    _integer(port, "Endpoint port", 1, 65535)
    if "%" in host:
        raise EndpointError("Scoped IPv6 addresses are not supported.")
    try:
        host = str(ipaddress.ip_address(host))
    except ValueError:
        if ":" in host:
            raise EndpointError("Invalid IPv6 address.")
        try:
            host = host.encode("idna").decode("ascii").lower()
        except UnicodeError as error:
            raise EndpointError("Invalid domain name.") from error
        labels = host.split(".")
        if len(host) > 253 or len(labels) < 2 or all(label.isdigit() for label in labels) or any(
            not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label)
            for label in labels
        ):
            raise EndpointError("Invalid IP address or fully qualified domain name.")
    return host, port


def address(host, port):
    return ("[" + host + "]" if ":" in host else host) + ":" + str(port)


def normalize_endpoint(value, default_port=443):
    return address(*validate_endpoint(value, default_port))


def _cf_network(value):
    try:
        network = ipaddress.ip_network(value, strict=False)
    except (TypeError, ValueError) as error:
        raise EndpointError("Candidates must be Cloudflare IPv4 addresses or CIDRs.") from error
    if network.version != 4 or not any(network.subnet_of(parent) for parent in CF_IPV4):
        raise EndpointError("Candidate is outside the official Cloudflare IPv4 snapshot.")
    return network


def validate_settings(value):
    if not isinstance(value, dict) or set(value) - set(DEFAULT_SETTINGS):
        raise EndpointError("Unknown endpoint-scanner setting or invalid settings object.")
    result = dict(DEFAULT_SETTINGS)
    result.update(value)
    result["candidates"] = list(result["candidates"]) if isinstance(result["candidates"], list) else result["candidates"]
    if result["schema"] != 1 or isinstance(result["schema"], bool):
        raise EndpointError("Unsupported endpoint-scanner settings schema.")
    if not isinstance(result["enabled"], bool):
        raise EndpointError("Automatic endpoint updates must be explicitly true or false.")
    for name, minimum, maximum in (
        ("duration_seconds", 1, 600), ("max_candidates", 1, MAX_CANDIDATES),
        ("samples", 1, 3), ("probe_timeout_seconds", 1, 20),
        ("minimum_improvement_percent", 0, 95), ("interval_hours", 1, 168),
    ):
        _integer(result[name], name, minimum, maximum)
    if result["candidate_source"] not in ("official", "manual"):
        raise EndpointError("Candidate source must be official or manual.")
    raw = result["candidates"]
    if not isinstance(raw, list) or len(raw) > MAX_CANDIDATES or any(not isinstance(item, str) or len(item) > 32 for item in raw):
        raise EndpointError("Provide at most 128 explicit Cloudflare IPv4 addresses or CIDRs.")
    if result["candidate_source"] == "manual" and not raw:
        raise EndpointError("Manual scanning needs at least one Cloudflare IPv4/CIDR candidate.")
    normalized = []
    for item in raw:
        network = _cf_network(item)
        canonical = str(network.network_address) if network.prefixlen == 32 else str(network)
        if canonical not in normalized:
            normalized.append(canonical)
    result["candidates"] = normalized
    return result


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise EndpointError("Duplicate JSON setting.")
        result[key] = value
    return result


def read_small(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise EndpointError("A required managed file is missing, not regular, or a symlink.")
    with path.open("rb") as stream:
        raw = stream.read(MAX_FILE + 1)
    if len(raw) > MAX_FILE:
        raise EndpointError("Managed file exceeds the size limit.")
    try:
        return raw.decode("utf-8")
    except UnicodeError as error:
        raise EndpointError("Managed file must contain UTF-8 text.") from error


def load_settings(path):
    try:
        value = json.loads(read_small(path), object_pairs_hook=_unique_object)
    except json.JSONDecodeError as error:
        raise EndpointError("Scanner settings are not valid JSON.") from error
    return validate_settings(value)


def candidate_addresses(settings, rng=None):
    """Bounded, interleaved sampling; never expands a large CIDR in memory.

    Parsing/deduplication is adapted from SIKDPI parse_ip_input. Unlike the
    original first-N policy, large ranges are sampled across their full extent.
    """
    settings = validate_settings(settings)
    rng = rng or random.SystemRandom()
    networks = list(CF_IPV4) if settings["candidate_source"] == "official" else [_cf_network(item) for item in settings["candidates"]]
    rng.shuffle(networks)
    buckets = []
    for network in networks:
        first = 1 if network.prefixlen < 31 else 0
        stop = network.num_addresses - 1 if network.prefixlen < 31 else network.num_addresses
        count = min(settings["max_candidates"], stop - first)
        offsets = rng.sample(range(first, stop), count)
        # Materialize only this bounded sample; do not retain a generator that
        # would capture the loop's next network through late binding.
        buckets.append(iter([str(ipaddress.ip_address(int(network.network_address) + offset)) for offset in offsets]))
    seen, result = set(), []
    while buckets and len(result) < settings["max_candidates"]:
        remaining = []
        for bucket in buckets:
            item = next(bucket, None)
            if item is None:
                continue
            remaining.append(bucket)
            if item not in seen:
                seen.add(item)
                result.append(item)
                if len(result) == settings["max_candidates"]:
                    break
        buckets = remaining
    return result


def latency_stats(times):
    """SIKDPI latency statistics, represented with finite JSON values only."""
    if not times:
        return {"avg_ms": None, "min_ms": None, "max_ms": None, "jitter_ms": None, "stddev_ms": None}
    average = sum(times) / len(times)
    variance = sum((value - average) ** 2 for value in times) / len(times)
    jitter = sum(abs(times[index] - times[index - 1]) for index in range(1, len(times))) / (len(times) - 1) if len(times) > 1 else 0.0
    return {"avg_ms": round(average, 2), "min_ms": round(min(times), 2), "max_ms": round(max(times), 2), "jitter_ms": round(jitter, 2), "stddev_ms": round(variance ** .5, 2)}


def classify_failure(text):
    """Return only fixed, non-secret diagnostics, never raw core output."""
    text = str(text).lower()
    if any(value in text for value in ("flag provided but not defined", "unknown flag", "core could not be started", "probe could not complete", "[config]", "[probe/config]", "[path/config]", "[session/config]")) or text == "local":
        return "local", "The local core or configuration could not run this probe; check core version and managed settings before scanning again."
    if "certificate" in text or "x509" in text:
        return "tls-certificate", "Certificate name, trust or expiry validation failed; verification was not bypassed."
    if "ech" in text:
        return "ech", "ECH discovery or strict acceptance failed; inspect resolver and TLS-terminator ECH support."
    if any(value in text for value in ("deadline", "timed out", "timeout")):
        return "timeout", "The actual carrier timed out; routing, filtering, buffering or a slow peer may be responsible."
    for code in (401, 403, 404, 429, 502, 503, 504, 525, 526):
        if re.search(r"(?<![0-9])" + str(code) + r"(?![0-9])", text):
            return "http", f"HTTP {code}: check CDN policy, Host/path, token, clock and origin health; status alone does not identify the cause."
    if "auth" in text or "token" in text:
        return "authentication", "Carrier authentication failed; verify paired credentials and clock without sharing the token."
    if "refused" in text:
        return "tcp", "The connection was refused; check the listener, port and rejecting network policy."
    if any(value in text for value in ("resolve", "no such host", "dns")):
        return "dns", "Name resolution failed; check the configured domain and resolver."
    if "tls" in text or "handshake" in text:
        return "tls", "TLS handshake failed with the configured SNI, fingerprint and TLS policy."
    return "carrier", "The configured carrier did not authenticate; use the tunnel doctor locally for additional stage diagnostics."


def probe_command(profile, endpoint, timeout):
    """Validate local inputs and construct a no-shell carrier command."""
    flags = profile["flags"]
    binary = str(profile["binary"])
    token_file = str(profile["token_file"])
    if not os.path.isabs(binary) or not os.path.isabs(token_file):
        raise EndpointError("Core binary and token file must use absolute paths.")
    # Root must never execute a mutable untrusted helper supplied through data.
    try:
        executable = Path(binary).stat()
    except OSError as error:
        raise EndpointError("The selected core binary is unavailable.") from error
    if Path(binary).is_symlink() or not stat.S_ISREG(executable.st_mode) or not os.access(binary, os.X_OK):
        raise EndpointError("The selected core binary is not an executable regular file.")
    if os.geteuid() == 0 and (executable.st_uid != 0 or executable.st_mode & 0o022):
        raise EndpointError("Root probes require a root-owned core that is not group/world writable.")
    try:
        token = read_small(token_file).strip()
    except OSError as error:
        raise EndpointError("The selected tunnel token file is unavailable.") from error
    if not 16 <= len(token.encode("utf-8")) <= 512:
        raise EndpointError("The selected tunnel token has an invalid length.")
    args = [binary, "-check-tunnel", "-mode", "origin", "-probe-timeout", f"{timeout:.3f}s", "-connect", endpoint, "-token-file", token_file]
    for key in PROBE_FLAGS:
        value = flags.get(key)
        if value is not None and value != "":
            if not isinstance(value, str) or any(ord(c) < 32 for c in value):
                raise EndpointError("Invalid managed carrier flag.")
            if key in ("system-ca", "path-legacy"):
                if value not in ("true", "false"):
                    raise EndpointError("Boolean probe flag must be true or false.")
                args.append("-" + key + "=" + value)
            else:
                args.extend(["-" + key, value])
    if not any(flags.get(key) for key in ("ca", "fingerprint", "system-ca")):
        args.append("-system-ca")
    elif sum((bool(flags.get("ca")), bool(flags.get("fingerprint")), flags.get("system-ca") == "true")) != 1:
        raise EndpointError("Choose exactly one certificate verifier: system CA, CA file or certificate fingerprint.")
    if flags.get("fingerprint") and not re.fullmatch(r"[a-fA-F0-9]{64}", flags["fingerprint"]):
        raise EndpointError("Certificate fingerprint must be exactly 64 hexadecimal characters.")
    if flags.get("ca") and not Path(flags["ca"]).is_file():
        raise EndpointError("The selected certificate CA file is unavailable.")
    return args


def probe_environment():
    environment = os.environ.copy()
    for name in tuple(environment):
        if name.upper() in {"UNUNKNOWNTUN_TOKEN", "V7_TOKEN", "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY"}:
            environment.pop(name, None)
    return environment


def preflight_profile(profile, timeout=3):
    """Local-only capability check, before spending the scan budget on IPs.

    Help must advertise the same flags that the scanner is about to use. This
    catches a mismatched/old installed core once, instead of labelling every
    candidate unhealthy. Neither the launcher nor a network probe is executed.
    """
    args = probe_command(profile, profile["current_endpoint"], 1)
    try:
        result = subprocess.run([args[0], "-h"], capture_output=True, text=True,
                                env=probe_environment(), timeout=timeout, check=False)
    except (OSError, subprocess.SubprocessError) as error:
        raise EndpointError("Local scanner preflight could not start the core help check; check the installed core before scanning.") from error
    if result.returncode not in (0, 2):
        raise EndpointError("The installed core did not return supported command-line help; no candidate was probed.")
    advertised = set(re.findall(r"(?m)^\s+(-[a-z][a-z0-9-]*)(?:\s|$)", (result.stdout + "\n" + result.stderr)[:262144]))
    required = {value.split("=", 1)[0] for value in args[1:] if value.startswith("-")}
    # Values such as padding ranges never begin with '-' in validated profiles.
    # Derive flag positions from the known vocabulary, not arbitrary flag values.
    required &= {"-check-tunnel", "-mode", "-probe-timeout", "-connect", "-token-file", "-system-ca"} | {"-" + key for key in PROBE_FLAGS}
    if not required.issubset(advertised):
        missing = ", ".join(sorted(required - advertised))
        raise EndpointError("Installed core lacks required scanner options: " + missing + ". Upgrade this managed core; no candidate was probed.")
    return {"local_core_compatible": True, "network_requests": False}


def core_probe(profile, endpoint, timeout):
    """One real-core invocation; no shell/listener/target stream or raw logs."""
    args = probe_command(profile, endpoint, timeout)
    began = time.monotonic()
    try:
        result = subprocess.run(args, capture_output=True, text=True, env=probe_environment(), timeout=timeout, check=False)
    except subprocess.TimeoutExpired:
        return {"ok": False, "elapsed_ms": round((time.monotonic() - began) * 1000, 2), "stage": "timeout", "reason": "The bounded actual-carrier probe exceeded its deadline."}
    except OSError:
        return {"ok": False, "elapsed_ms": 0, "stage": "local", "reason": "The selected core could not be started; no tunnel configuration was changed."}
    elapsed = round((time.monotonic() - began) * 1000, 2)
    if result.returncode == 0:
        return {"ok": True, "elapsed_ms": elapsed, "stage": "authenticated-carrier", "reason": "Certificate, selected handshake, carrier and tunnel authentication passed; target payload was not tested."}
    # Only categorical text leaves this function; no token, route, key, resolver
    # query, private path or raw response can enter the shareable JSON report.
    stage, reason = classify_failure((result.stdout + "\n" + result.stderr)[:16384])
    return {"ok": False, "elapsed_ms": elapsed, "stage": stage, "reason": reason}


def probe_endpoint(profile, endpoint, timeout):
    """Public post-change health hook for the transactional manager."""
    endpoint = normalize_endpoint(endpoint)
    if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not math.isfinite(timeout) or not .05 <= timeout <= 20:
        raise EndpointError("Probe timeout must be from 0.05 to 20 seconds.")
    return core_probe(profile, endpoint, timeout)


def scan_profile(profile, probe=None, clock=None, rng=None, progress=None):
    """Return a proposed endpoint without changing configuration or services.

    profile: provider, current_endpoint, binary, token_file, flags, settings.
    probe(profile, endpoint, timeout_seconds) returns ok/elapsed_ms/stage/reason.
    Injected probes must honor their deadline; production subprocesses are killed
    at the deadline. Scans are sequential: no uncancelable worker pool survives.
    """
    if not isinstance(profile, dict) or profile.get("provider") != "cloudflare":
        raise EndpointError("Automatic scanning is available only for the Cloudflare profile.")
    flags = profile.get("flags", {})
    if not isinstance(flags, dict) or flags.get("transport", "wss") not in ("wss", "xhttp") or flags.get("spoof-config"):
        raise EndpointError("Cloudflare scanning requires WS/XHTTP without the separate native spoof underlay.")
    for name in ("sni", "ws-host"):
        if not flags.get(name):
            raise EndpointError("The original TLS SNI and HTTP Host must be configured before scanning.")
        validate_endpoint(flags[name])
    current = normalize_endpoint(profile.get("current_endpoint", ""))
    _, port = validate_endpoint(current)
    if port not in CF_PORTS:
        raise EndpointError("The selected port is not a supported Cloudflare HTTPS profile port.")
    settings = validate_settings(profile.get("settings", {}))
    production_probe = probe is None
    probe = probe or core_probe
    clock = clock or time.monotonic
    started = clock()
    deadline = started + settings["duration_seconds"]
    if production_probe:
        preflight_profile(profile, min(3, settings["duration_seconds"]))
    candidates = [address(ip, port) for ip in candidate_addresses(settings, rng)]
    endpoints = [current] + [item for item in candidates if item != current]
    report = {
        "schema": 1, "time_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "provider": "cloudflare", "current_endpoint": current, "selected_endpoint": current,
        "changed": False, "timed_out": False, "local_error": False, "authenticated_candidates": 0,
        "target_payload_tested": False, "configuration_changed": False,
        "automatic_updates_enabled": settings["enabled"], "results": [],
        "local_preflight_passed": production_probe, "planned_endpoints": len(endpoints),
        "samples_per_endpoint": settings["samples"], "maximum_seconds": settings["duration_seconds"],
        "range_source": CF_SOURCE, "range_snapshot_date": CF_SNAPSHOT_DATE,
        "reason": "No fully authenticated replacement was found; the current endpoint is retained.",
    }
    def emit(event, **fields):
        if progress is not None:
            progress(dict(event=event, completed=len(report["results"]), total=len(endpoints),
                          elapsed_seconds=round(max(0, clock() - started), 1), **fields))
    emit("started")
    for index, endpoint in enumerate(endpoints):
        times, attempts, failures = [], 0, []
        emit("probing", position=index + 1, baseline=index == 0)
        for _ in range(settings["samples"]):
            remaining = deadline - clock()
            if remaining < .05:
                report["timed_out"] = True
                break
            attempts += 1
            probe_limit = min(settings["probe_timeout_seconds"], remaining)
            try:
                outcome = probe(profile, endpoint, probe_limit)
                if not isinstance(outcome, dict):
                    raise EndpointError("Probe returned an invalid result.")
                elapsed = outcome.get("elapsed_ms")
                if clock() > deadline:
                    report["timed_out"] = True
                    failures.append({"stage": "timeout", "reason": "Probe completed after the total scan deadline; this sample was not certified."})
                    break
                if outcome.get("ok") is True and isinstance(elapsed, (float, int)) and not isinstance(elapsed, bool) and math.isfinite(elapsed) and 0 <= elapsed <= probe_limit * 1000:
                    times.append(float(elapsed))
                else:
                    # Callbacks may be user-authored. Classify their messages;
                    # never expose arbitrary callback text or private data.
                    stage, reason = classify_failure("local" if outcome.get("stage") == "local" else str(outcome.get("stage", "")) + " " + str(outcome.get("reason", "")))
                    failures.append({"stage": stage, "reason": reason})
                    report["local_error"] = stage == "local"
            except (OSError, ValueError, subprocess.SubprocessError):
                failures.append({"stage": "local", "reason": "The probe could not complete; no candidate was certified by this attempt."})
                report["local_error"] = True
            if report["local_error"]:
                break
        record = {"endpoint": endpoint, "attempts": attempts, "successes": len(times), "fully_authenticated": len(times) == settings["samples"], "loss_percent": round((1 - len(times) / attempts) * 100, 1) if attempts else 100.0, "failures": failures}
        record.update(latency_stats(times))
        report["results"].append(record)
        emit("completed", position=index + 1, successes=len(times), attempts=attempts,
             fully_authenticated=record["fully_authenticated"])
        if report["local_error"]:
            break
        if report["timed_out"] or clock() >= deadline:
            report["timed_out"] = True
            break
    current_result = report["results"][0] if report["results"] else None
    healthy = current_result and current_result["fully_authenticated"]
    successful = [row for row in report["results"] if row["endpoint"] != current and row["fully_authenticated"]]
    report["authenticated_candidates"] = len(successful)
    if report["local_error"]:
        report["reason"] = "A local core/configuration error stopped the scan; all replacement proposals were discarded and the current endpoint is retained."
    elif successful:
        best = min(successful, key=lambda row: (row["loss_percent"], row["avg_ms"], row["jitter_ms"]))
        threshold = current_result["avg_ms"] * (1 - settings["minimum_improvement_percent"] / 100) if healthy else None
        if not healthy or best["avg_ms"] < threshold:
            report.update(selected_endpoint=best["endpoint"], changed=True, reason="A fully authenticated candidate passed the improvement threshold; transactional apply and a post-change probe are still required.")
        else:
            report["reason"] = "The current endpoint authenticated and no candidate exceeded the configured improvement threshold; it is retained."
    report["elapsed_seconds"] = round(max(0, clock() - started), 3)
    report["current_authenticated"] = bool(healthy)
    report["completed_endpoints"] = sum(row["attempts"] == settings["samples"] for row in report["results"])
    report["failure_summary"] = failure_summary(report)
    report["rotation_probe_may_be_incomplete"] = rotation_probe_limited(profile, report)
    if report["rotation_probe_may_be_incomplete"]:
        report["rotation_probe_note"] = "Each bounded probe starts a fresh route cursor. A timeout may occur before later/overlap routes are tried; no all-path reachability verdict is available. Increase per-probe time or use a longer manual core check; do not bypass authentication."
    report["verdict"] = "replacement-proposed" if report["changed"] else "current-retained"
    report["note"] = "Handshake latency is not throughput, client-payload success or a guarantee of long-term filtering resistance. Duration is a maximum budget, not a forced scan length."
    emit("finished", authenticated_candidates=len(successful), timed_out=report["timed_out"])
    return report


def rotation_probe_limited(profile, report):
    return profile.get("flags", {}).get("path-rotation", "0") not in ("", "0", "0s") and any(
        item.get("stage") == "timeout" for item in failure_summary(report))


def failure_summary(report):
    """Aggregate categorical failures; no arbitrary probe text is returned."""
    counts = {}
    for row in report.get("results", []):
        for item in row.get("failures", []):
            stage, reason = classify_failure("local" if item.get("stage") == "local" else str(item.get("stage", "")) + " " + str(item.get("reason", "")))
            key = (stage, reason)
            counts[key] = counts.get(key, 0) + 1
    return [{"stage": stage, "reason": reason, "attempts": count}
            for (stage, reason), count in sorted(counts.items(), key=lambda item: (-item[1], item[0]))]


def print_progress(event, stream=None):
    stream = stream or sys.stderr
    if event["event"] == "started":
        print("[SCAN] Local checks passed. Testing the current endpoint first, then bounded candidates.", file=stream, flush=True)
    elif event["event"] == "probing":
        label = "current endpoint" if event["baseline"] else "candidate"
        print(f"[SCAN {event['position']}/{event['total']}] Testing {label}; elapsed {event['elapsed_seconds']:.1f}s", file=stream, flush=True)
    elif event["event"] == "completed":
        result = "authenticated" if event["fully_authenticated"] else "not certified"
        print(f"  {result}: {event['successes']}/{event['attempts']} successful samples", file=stream, flush=True)
    elif event["event"] == "finished":
        print(f"[SCAN] Finished: {event['authenticated_candidates']} authenticated alternatives; budget exhausted={event['timed_out']}.", file=stream, flush=True)


def parse_env(text):
    values = {}
    wanted = {"ROLE", "FOREIGN_PROXY_PROVIDER", "FOREIGN_PORTS"}
    for line in text.splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        match = re.fullmatch(r"([A-Z][A-Z0-9_]*)=(.*)", line)
        if not match:
            raise EndpointError("Malformed managed deployment metadata.")
        key, raw = match.groups()
        if key not in wanted:
            continue
        if key in values or "$" in raw or "`" in raw:
            raise EndpointError("Duplicate or executable managed metadata is not supported.")
        parsed = shlex.split(raw)
        if len(parsed) > 1:
            raise EndpointError("Unsupported managed metadata quoting.")
        values[key] = parsed[0] if parsed else ""
    return values


def parse_flags(text):
    flags = {}
    for line in text.splitlines():
        if not re.match(r"\s+-[a-z]", line):
            continue
        parts = shlex.split(line.strip().removesuffix("\\").strip())
        if len(parts) == 1 and "=" in parts[0]:
            parts = parts[0].split("=", 1)
        if len(parts) not in (1, 2) or not re.fullmatch(r"-[a-z][a-z0-9-]*", parts[0]):
            raise EndpointError("Unsupported managed launch flag layout; no shell was executed.")
        key = parts[0][1:]
        value = parts[1] if len(parts) == 2 else "true"
        if key in flags or any(ord(c) < 32 for c in value) or "$" in value or "`" in value:
            raise EndpointError("Duplicate, dynamic or invalid managed launch flag.")
        flags[key] = value
    return flags


def load_profile(config_dir, settings_path=None, binary=None):
    directory = Path(config_dir)
    if directory.is_symlink() or not directory.is_dir():
        raise EndpointError("Select one regular managed tunnel directory.")
    env_text = read_small(directory / "deployment.env")
    launch_text = read_small(directory / "run.sh")
    env, flags = parse_env(env_text), parse_flags(launch_text)
    if env.get("ROLE") != "origin" or flags.get("mode") != "origin":
        raise EndpointError("Run endpoint discovery on the connection-initiating origin, not egress.")
    explicit_settings = settings_path is not None
    settings_path = Path(settings_path) if explicit_settings else directory / "cdn-endpoints.json"
    # Earlier managed installations may not have visited scanner setup yet.
    # Defaults are read-only and opt-in scheduling remains disabled. An explicit
    # missing path or any symlink still fails closed.
    settings = load_settings(settings_path) if explicit_settings or settings_path.exists() or settings_path.is_symlink() else validate_settings({})
    connections = flags.get("connect", "").split(",")
    if not connections or not connections[0]:
        raise EndpointError("The managed launcher has no configured endpoint.")
    token_file = str(directory / "token")
    if flags.get("token-file", token_file) != token_file or flags.get("token"):
        raise EndpointError("Scanning requires this tunnel's own token file, not an inline or unrelated token.")
    # Include every source that controls the scan/probe. The manager can compare
    # this revision under its lock before applying any proposed endpoint.
    token_text = read_small(token_file)
    revision = hashlib.sha256((env_text + "\0" + launch_text + "\0" + json.dumps(settings, sort_keys=True) + "\0" + token_text).encode()).hexdigest()
    return {"provider": env.get("FOREIGN_PROXY_PROVIDER"), "current_endpoint": connections[0], "original_endpoints": connections, "binary": str(binary or "/usr/local/bin/ununknowntun"), "flags": flags, "token_file": token_file, "settings": settings, "revision": revision}


def write_report(path, report):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("scan", "check-settings"))
    selection = parser.add_mutually_exclusive_group(required=True)
    selection.add_argument("--id", help="installed tunnel ID under /etc/ununknowntun/tunnels")
    selection.add_argument("--config-dir", help="managed tunnel directory; never executes its launcher")
    parser.add_argument("--settings", help="settings JSON; default is cdn-endpoints.json in the tunnel directory")
    parser.add_argument("--binary", default="/usr/local/bin/ununknowntun")
    parser.add_argument("--output", help="new private report file; existing paths are never overwritten")
    args = parser.parse_args(argv)
    try:
        if args.id and not re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}", args.id):
            raise EndpointError("Invalid managed tunnel ID.")
        directory = Path("/etc/ununknowntun/tunnels") / args.id if args.id else Path(args.config_dir)
        profile = load_profile(directory, args.settings, args.binary)
        if args.action == "check-settings":
            report = {"schema": 1, "verdict": "settings-checked-no-network", "settings": profile["settings"], "revision": profile["revision"]}
        else:
            report = scan_profile(profile, progress=print_progress)
            report["revision"] = profile["revision"]
        if args.output:
            write_report(args.output, report)
        print(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False))
        return 0
    except (EndpointError, OSError, ValueError) as error:
        message = str(error) if isinstance(error, EndpointError) else "A managed file could not be safely read or a private report could not be created."
        print(json.dumps({"verdict": "configuration-error", "error": message}), file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("Scan cancelled; no endpoint or service was changed.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
