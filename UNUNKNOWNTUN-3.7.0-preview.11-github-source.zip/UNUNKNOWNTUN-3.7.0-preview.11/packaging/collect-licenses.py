#!/usr/bin/env python3
"""BUILD HOST ONLY: retain notices for the Go runtime and linked modules."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
out = Path(sys.argv[1]).resolve()
go = os.environ.get("GO_BIN", "go")
metadata = subprocess.check_output([go, "version", "-m", str(out / "bin/ununknowntun-linux-amd64")], text=True)
linked = {line.strip().split()[1] for line in metadata.splitlines() if line.strip().startswith("dep\t")}
raw = subprocess.check_output([go, "list", "-m", "-json", "all"], cwd=root, text=True)
decoder = json.JSONDecoder()
modules = {}
while raw.strip():
    item, end = decoder.raw_decode(raw.lstrip())
    raw = raw.lstrip()[end:]
    modules[item["Path"]] = item
licenses = out / "THIRD_PARTY_LICENSES"
licenses.mkdir(exist_ok=True)
copied = []
goroot = Path(subprocess.check_output([go, "env", "GOROOT"], text=True).strip())
shutil.copyfile(goroot / "LICENSE", licenses / "GO-LICENSE")
copied.append("Go runtime and standard library: GO-LICENSE")
for name in sorted(linked):
    module = modules[name]
    directory = Path(module["Dir"])
    target = licenses / (name.replace("/", "__") + "@" + module["Version"])
    found = []
    for path in sorted(directory.rglob("*")):
        if path.is_file() and path.name.upper().startswith(("LICENSE", "LICENCE", "COPYING", "NOTICE")):
            destination = target / path.relative_to(directory)
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, destination)
            found.append(str(destination.relative_to(licenses)))
    if not found:
        raise SystemExit("No license/notice found for linked module: " + name)
    copied.extend(found)
(licenses / "INDEX.txt").write_text(
    "Third-party notices retained from the exact linked module source versions.\n"
    "These licenses cover their respective components, not the UNUNKNOWNTUN project itself.\n\n" +
    "\n".join(copied) + "\n")
print(f"Retained Go runtime notices and licenses from {len(linked)} linked modules.")
