#!/usr/bin/env python3
"""Narrow, fail-closed TLS helpers for the UNUNKNOWNTUN tunnel editor.

These functions never reload Nginx, alter a service, or write a site. The caller
owns transactional installation of the returned text and certificate paths.
Only public certificate metadata and public keys are captured from OpenSSL.
"""
import datetime
import ipaddress
import os
from pathlib import Path
import re
import stat
import subprocess


class TLSEditError(ValueError):
    """A user-correctable TLS or managed-site validation failure."""


def validate_domain(value):
    """Return a lower-case ASCII DNS name; accept already encoded IDNA only."""
    if not isinstance(value, str) or not value or len(value) > 253:
        raise TLSEditError("Enter a DNS domain such as tunnel.example.com.")
    domain = value.lower()
    if not re.fullmatch(r"[a-z0-9.-]+", domain) or "." not in domain:
        raise TLSEditError("Use a DNS domain without a scheme, path, wildcard, or whitespace.")
    labels = domain.split(".")
    if any(not label or len(label) > 63 or label.startswith("-") or label.endswith("-") for label in labels):
        raise TLSEditError("The domain has an empty or invalid DNS label.")
    try:
        ipaddress.ip_address(domain)
    except ValueError:
        pass
    else:
        raise TLSEditError("Use a domain, not an IP address, for TLS.")
    # Also reject ambiguous numeric hosts (including legacy octal-like forms).
    if all(label.isdecimal() for label in labels):
        raise TLSEditError("Use a DNS domain, not a numeric IP-like address.")
    return domain


def _safe_path(value, *, must_exist=False, directory=False):
    value = os.fspath(value)
    if not isinstance(value, str) or not re.fullmatch(r"/[A-Za-z0-9_.+/-]+", value):
        raise TLSEditError("Certificate and webroot paths must be absolute and contain no whitespace or shell/Nginx syntax.")
    if any(part in (".", "..") for part in value.split("/")):
        raise TLSEditError("Use an absolute path without dot-directory components.")
    if must_exist:
        try:
            details = os.stat(value)  # Let's Encrypt's regular-file symlinks are intentional.
        except OSError as exc:
            raise TLSEditError("The certificate, key, or webroot path does not exist or cannot be read.") from exc
        expected = stat.S_ISDIR(details.st_mode) if directory else stat.S_ISREG(details.st_mode)
        if not expected or not os.access(value, os.R_OK) or (not directory and details.st_size == 0):
            raise TLSEditError("The certificate/key must be a nonempty readable regular file; the webroot must be a readable directory.")
    return value


def _tokens(text):
    """Small Nginx lexer with source offsets, so unrelated text stays verbatim."""
    if not isinstance(text, str) or "\x00" in text:
        raise TLSEditError("Invalid managed Nginx site text.")
    result, index = [], 0
    while index < len(text):
        if text[index].isspace():
            index += 1
            continue
        if text[index] == "#":
            newline = text.find("\n", index)
            index = len(text) if newline < 0 else newline + 1
            continue
        begin = index
        char = text[index]
        if char in "{};":
            result.append((char, begin, index + 1))
            index += 1
            continue
        if char in "\"'":
            quote = char
            index += 1
            while index < len(text) and text[index] != quote:
                if text[index] == "\\":
                    index += 1
                index += 1
            if index >= len(text):
                raise TLSEditError("Unterminated quote in the managed Nginx site.")
            index += 1
        else:
            while index < len(text) and not text[index].isspace() and text[index] not in "{};#":
                if text[index] == "\\":
                    index += 1
                index += 1
        result.append((text[begin:index], begin, index))
    return result


def _layout(text):
    """Read only an isolated site made of server blocks, not global config."""
    stack, pending, servers = [], [], []
    for token in _tokens(text):
        value = token[0]
        if value == "{":
            if not pending:
                raise TLSEditError("Unexpected Nginx block in managed site.")
            if not stack:
                if len(pending) != 1 or pending[0][0] != "server":
                    raise TLSEditError("Only isolated server blocks may be edited automatically.")
                servers.append([])
            elif pending[0][0] == "server":
                raise TLSEditError("Nested server block is not a managed site layout.")
            stack.append(pending[0][0])
            pending = []
        elif value == "}":
            if pending or not stack:
                raise TLSEditError("Unbalanced or incomplete managed Nginx site.")
            stack.pop()
        elif value == ";":
            if not pending or not stack:
                raise TLSEditError("Unexpected directive outside a managed server block.")
            name = pending[0][0]
            if name == "include":
                raise TLSEditError("This site includes external configuration; automatic editing cannot verify its TLS ownership.")
            if name in ("server_name", "ssl_certificate", "ssl_certificate_key"):
                if len(stack) != 1 or len(pending) != 2:
                    raise TLSEditError("Ambiguous server name or TLS certificate directive; review the site manually.")
            if len(stack) == 1:
                servers[-1].append((name, pending[1:]))
            pending = []
        else:
            pending.append(token)
    if stack or pending or not servers:
        raise TLSEditError("Unbalanced, incomplete, or empty managed Nginx site.")
    for server in servers:
        names = [arguments for name, arguments in server if name == "server_name"]
        if len(names) != 1:
            raise TLSEditError("Each managed server must have exactly one explicit server_name.")
        validate_domain(_literal(names[0][0][0]))
        if not any(name == "listen" for name, _ in server):
            raise TLSEditError("Managed server has no explicit listener.")
        certs = [arguments for name, arguments in server if name == "ssl_certificate"]
        keys = [arguments for name, arguments in server if name == "ssl_certificate_key"]
        if len(certs) > 1 or len(keys) > 1 or bool(certs) != bool(keys):
            raise TLSEditError("Ambiguous or incomplete TLS certificate pair in managed server.")
    return servers


def _literal(token):
    if len(token) >= 2 and token[0] in "\"'" and token[-1] == token[0]:
        token = token[1:-1]
    if "\\" in token:
        raise TLSEditError("Escaped values in TLS directives require manual review.")
    return token


def certificate_paths(site_text):
    """Extract a unique static certificate/key pair without opening either file."""
    pairs = []
    for server in _layout(site_text):
        fields = {name: arguments for name, arguments in server if name.startswith("ssl_certificate")}
        if "ssl_certificate" in fields:
            pairs.append((_safe_path(_literal(fields["ssl_certificate"][0][0])),
                          _safe_path(_literal(fields["ssl_certificate_key"][0][0]))))
    if len(set(pairs)) != 1:
        raise TLSEditError("The managed site must use one unambiguous TLS certificate/key pair.")
    return pairs[0]


def _run(runner, args, message):
    try:
        result = runner(args, capture_output=True, text=True, check=False)
    except (OSError, subprocess.SubprocessError) as exc:
        raise TLSEditError(message) from exc
    if result.returncode:
        # Never echo command output: a third-party hook or malformed key must not
        # cause private key text to reach the terminal/logs.
        raise TLSEditError(message)
    return result.stdout


def _check_hostname(runner, domain, cert_path):
    # Never parse human-readable SAN text: a crafted URI SAN can contain text
    # resembling DNS metadata. The deployment OpenSSL must support checkhost;
    # old macOS LibreSSL fails closed, just as the existing Linux installer does.
    result = _run(runner, ["openssl", "x509", "-in", cert_path, "-noout", "-checkhost", domain],
                  "Certificate hostname verification failed; install OpenSSL with x509 -checkhost support or select a certificate covering this domain.")
    if result.strip() != "Hostname " + domain + " does match certificate":
        raise TLSEditError("The certificate does not cover " + domain + ".")


def validate_certificate(domain, cert_path, key_path, runner=subprocess.run):
    """Validate time, DNS hostname, and matching public keys (no private text)."""
    domain = validate_domain(domain)
    cert_path = _safe_path(cert_path, must_exist=True)
    key_path = _safe_path(key_path, must_exist=True)
    _run(runner, ["openssl", "x509", "-in", cert_path, "-noout", "-checkend", "86400"], "The certificate is invalid or expires within 24 hours.")
    starts = _run(runner, ["openssl", "x509", "-in", cert_path, "-noout", "-startdate"], "Cannot inspect certificate start time.")
    try:
        if not starts.startswith("notBefore="):
            raise ValueError("missing notBefore")
        not_before = datetime.datetime.strptime(starts.strip().split("=", 1)[1], "%b %d %H:%M:%S %Y GMT").replace(tzinfo=datetime.timezone.utc)
    except ValueError as exc:
        raise TLSEditError("Cannot safely parse the certificate start time.") from exc
    if not_before > datetime.datetime.now(datetime.timezone.utc):
        raise TLSEditError("The certificate is not valid yet; check its start date and the server clock.")
    _check_hostname(runner, domain, cert_path)
    cert_public = _run(runner, ["openssl", "x509", "-in", cert_path, "-pubkey", "-noout"], "Cannot read the certificate public key.")
    key_public = _run(runner, ["openssl", "pkey", "-in", key_path, "-passin", "pass:", "-pubout"], "Cannot read the key's public key; use a matching unencrypted private key.")
    marker = r"-----BEGIN PUBLIC KEY-----\s*([A-Za-z0-9+/=\s]+)\s*-----END PUBLIC KEY-----"
    cert_match, key_match = re.fullmatch(marker, cert_public.strip()), re.fullmatch(marker, key_public.strip())
    if not cert_match or not key_match or re.sub(r"\s", "", cert_match[1]) != re.sub(r"\s", "", key_match[1]):
        raise TLSEditError("The certificate and private key do not match.")
    return cert_path, key_path


def rewrite_site(site_text, old_domain, new_domain, cert_path=None, key_path=None):
    """Replace just validated server-name/certificate tokens, never route text."""
    old_domain, new_domain = validate_domain(old_domain), validate_domain(new_domain)
    if (cert_path is None) != (key_path is None):
        raise TLSEditError("Provide both the certificate and its private key.")
    if cert_path is not None:
        cert_path, key_path = _safe_path(cert_path), _safe_path(key_path)
    servers = _layout(site_text)
    certificate_paths(site_text)
    replacements = []
    for server in servers:
        for name, arguments in server:
            if name not in ("server_name", "ssl_certificate", "ssl_certificate_key"):
                continue
            token, begin, end = arguments[0]
            if name == "server_name":
                if validate_domain(_literal(token)) != old_domain:
                    raise TLSEditError("A server_name belongs to a different domain; no site changes were made.")
                replacement = new_domain
            elif cert_path is not None:
                replacement = cert_path if name == "ssl_certificate" else key_path
            else:
                continue
            if len(token) >= 2 and token[0] in "\"'" and token[-1] == token[0]:
                replacement = token[0] + replacement + token[0]
            replacements.append((begin, end, replacement))
    for begin, end, replacement in sorted(replacements, reverse=True):
        site_text = site_text[:begin] + replacement + site_text[end:]
    return site_text


def issue_certificate(domain, email, webroot, runner=subprocess.run):
    """Use only an already-served HTTP webroot; never replace a live Nginx site.

    Existing Nginx/HTTP challenge routing must be verified by the caller first.
    Certbot writes its own certificate storage; the caller installs no new site
    until validation succeeds. No Nginx plugin or reload hooks are requested.
    """
    domain = validate_domain(domain)
    if not isinstance(email, str) or not re.fullmatch(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,63}", email):
        raise TLSEditError("Enter a valid email address for certificate issuance.")
    webroot = _safe_path(webroot, must_exist=True, directory=True)
    _run(runner, ["certbot", "--config", "/dev/null", "certonly", "--webroot", "-w", webroot,
                  "-d", domain, "--cert-name", domain, "--non-interactive", "--agree-tos",
                  "--email", email, "--keep-until-expiring", "--no-directory-hooks",
                  "--pre-hook", "", "--post-hook", "", "--deploy-hook", ""],
         "Certificate issuance failed. You can select an existing valid certificate instead. Allow HTTP port 80 and /.well-known/acme-challenge/ to reach this webroot without cache or challenges; a CDN forced to HTTPS before the new certificate exists needs temporary HTTP/Auto origin bootstrap settings.")
    base = Path("/etc/letsencrypt/live") / domain
    return validate_certificate(domain, str(base / "fullchain.pem"), str(base / "privkey.pem"), runner=runner)
