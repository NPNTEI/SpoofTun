#!/usr/bin/env bash
# DESTINATION: run "foreign" only on the FOREIGN server and "iran" only on the IRAN server.
set -Eeuo pipefail

VERSION="__VERSION__"
RELEASE_LABEL="__VERSION__"
SERVICE="ununknowntun"
INSTALL_DIR="/opt/ununknowntun"
BASE_CONFIG_DIR="/etc/ununknowntun"
TUNNELS_DIR="$BASE_CONFIG_DIR/tunnels"
CONFIG_DIR="$BASE_CONFIG_DIR"
BIN_PATH="/usr/local/bin/ununknowntun"
CTL_PATH="/usr/local/bin/ununknowntunctl"
UNIT_PATH="/etc/systemd/system/ununknowntun@.service"
LOCK_PATH="/run/ununknowntun-installer.lock"
NGINX_SITE_DIR="/etc/nginx/sites-available"
NGINX_ENABLED_DIR="/etc/nginx/sites-enabled"
DECOY_DIR="/var/www/ununknowntun-decoy"
CERTBOT_HOOK_DIR="/etc/letsencrypt/renewal-hooks/deploy"
CERTBOT_RENEWAL_DIR="/etc/letsencrypt/renewal"
SCRIPT_PATH="$(readlink -f "${BASH_SOURCE[0]}")"
AMD64_SHA256="__AMD64_SHA256__"
ARM64_SHA256="__ARM64_SHA256__"
TX_ACTIVE=0
TX_SERVICE_TOUCHED=0
TX_NGINX_TOUCHED=0
TX_CERTBOT_TIMER_TOUCHED=0
TX_DIR=""
ORIGIN_CA_PATH=""
LOCAL_TLS_CA_PATH="/etc/ssl/certs/ca-certificates.crt"
SERVICE_INVOCATION=""
CURRENT_TUNNEL_ID=""
CURRENT_TUNNEL_NAME=""
TUNNEL_STATE_DIR=""
TUNNEL_IS_NEW=0
PROXY_PROVIDER_NONE="none"
PROXY_PROVIDER_CLOUDFLARE="cloudflare"
PROXY_PROVIDER_ARVAN="arvan"
declare -a TX_PATHS=() TX_PRESENT=() TX_UFW_PORTS=()

RED=$'\033[0;31m'
GREEN=$'\033[0;32m'
YELLOW=$'\033[1;33m'
CYAN=$'\033[0;36m'
RESET=$'\033[0m'

info() { printf '%s[+]%s %s\n' "$GREEN" "$RESET" "$*"; }
warn() { printf '%s[!]%s %s\n' "$YELLOW" "$RESET" "$*" >&2; }
die() { printf '%s[x]%s %s\n' "$RED" "$RESET" "$*" >&2; exit 1; }
pass() { printf '%s[PASS]%s %s\n' "$GREEN" "$RESET" "$*"; }
fail() { printf '%s[FAIL]%s %s\n' "$RED" "$RESET" "$*" >&2; }

on_error() {
    local line="$1"
    printf '%s[x]%s Error on line %s. Check: journalctl -u ununknowntun -n 80 --no-pager\n' "$RED" "$RESET" "$line" >&2
}
trap 'on_error "$LINENO"' ERR

# Only installer-owned files are registered. Never snapshot, stop, or rewrite Xray.
transaction_snapshot() {
    local path="$1" index="${#TX_PATHS[@]}"
    [[ "$path" == /* && "$path" != / && "$path" != "$INSTALL_DIR" ]] || die "Unsafe snapshot path."
    TX_PATHS+=("$path")
    if [[ -e "$path" || -L "$path" ]]; then
        cp -a -- "$path" "$TX_DIR/files/$index"
        TX_PRESENT+=(1)
    else
        TX_PRESENT+=(0)
    fi
    printf '%s\t%q\n' "${TX_PRESENT[$index]}" "$path" >> "$TX_DIR/manifest"
}

transaction_begin() {
    local role="$1" domain="${2:-}"
    install -d -m 0700 "$INSTALL_DIR/backups"
    TX_DIR="$(mktemp -d "$INSTALL_DIR/backups/transaction.XXXXXXXX")"
    chmod 0700 "$TX_DIR"
    mkdir -m 0700 "$TX_DIR/files" "$TX_DIR/failed"
    TX_UNUNKNOWNTUN_ACTIVE="$(systemctl is-active "$SERVICE" 2>/dev/null || true)"
    TX_UNUNKNOWNTUN_ENABLED="$(systemctl is-enabled "$SERVICE" 2>/dev/null || true)"
    TX_NGINX_ACTIVE="$(systemctl is-active nginx 2>/dev/null || true)"
    TX_NGINX_ENABLED="$(systemctl is-enabled nginx 2>/dev/null || true)"
    TX_CERTBOT_TIMER_ACTIVE="$(systemctl is-active certbot.timer 2>/dev/null || true)"
    TX_CERTBOT_TIMER_ENABLED="$(systemctl is-enabled certbot.timer 2>/dev/null || true)"
    TX_PATHS=(); TX_PRESENT=(); TX_UFW_PORTS=()
    transaction_snapshot "$CONFIG_DIR"
    transaction_snapshot "$BIN_PATH"
    transaction_snapshot "$CTL_PATH"
    transaction_snapshot "$UNIT_PATH"
    transaction_snapshot "$INSTALL_DIR/share"
    # Only newly created accounting directories are rollback-owned. Never
    # restore an old traffic ledger and thereby refund already-consumed bytes.
    if [[ -n "$TUNNEL_STATE_DIR" && ! -e "$TUNNEL_STATE_DIR" ]]; then
        transaction_snapshot "$TUNNEL_STATE_DIR"
    fi
    if [[ -n "$domain" ]]; then
        transaction_snapshot "$NGINX_SITE_DIR/ununknowntun-$domain.conf"
        transaction_snapshot "$NGINX_ENABLED_DIR/ununknowntun-$domain.conf"
        transaction_snapshot "$DECOY_DIR"
        transaction_snapshot "$CERTBOT_HOOK_DIR/ununknowntun-nginx-reload"
        transaction_snapshot "$CERTBOT_RENEWAL_DIR/$domain.conf"
    fi
    TX_ACTIVE=1
    info "Protected installation snapshot: $TX_DIR"
}

restore_enabled_state() {
    case "$2" in
        enabled) systemctl enable "$1" >/dev/null 2>&1 ;;
        enabled-runtime) systemctl enable --runtime "$1" >/dev/null 2>&1 ;;
        disabled|not-found|masked|static|indirect|"") systemctl disable "$1" >/dev/null 2>&1 || true ;;
    esac
}

transaction_rollback() {
    [[ "$TX_ACTIVE" == 1 ]] || return 0
    TX_ACTIVE=0
    local index path port restore_failed=0 file_restore_failed=0
    warn "Installation did not commit; restoring the previous UNUNKNOWNTUN configuration."
    if [[ "$TX_SERVICE_TOUCHED" == 1 ]]; then
        systemctl stop "$SERVICE" >/dev/null 2>&1 || true
    fi
    for ((index=${#TX_PATHS[@]}-1; index>=0; index--)); do
        path="${TX_PATHS[$index]}"
        if [[ -e "$path" || -L "$path" ]]; then
            mv -- "$path" "$TX_DIR/failed/$index" || { restore_failed=1; file_restore_failed=1; continue; }
        fi
        if [[ "${TX_PRESENT[$index]}" == 1 ]]; then
            cp -a -- "$TX_DIR/files/$index" "$path" || { restore_failed=1; file_restore_failed=1; }
        fi
    done
    for port in "${TX_UFW_PORTS[@]-}"; do
        [[ -n "$port" ]] || continue
        LC_ALL=C ufw --force delete allow proto tcp from 0.0.0.0/0 to 0.0.0.0/0 port "$port" >/dev/null 2>&1 || restore_failed=1
    done
    # Never load a partly restored launcher/unit/site. Keep other live Nginx
    # workers untouched and retain both snapshots for explicit recovery.
    if [[ "$TX_SERVICE_TOUCHED" == 1 && "$file_restore_failed" == 0 ]]; then
        systemctl daemon-reload || restore_failed=1
        restore_enabled_state "$SERVICE" "$TX_UNUNKNOWNTUN_ENABLED" || restore_failed=1
        if [[ "$TX_UNUNKNOWNTUN_ACTIVE" == active && "$restore_failed" == 0 ]]; then
            systemctl restart "$SERVICE" || restore_failed=1
        fi
    fi
    if [[ "$TX_NGINX_TOUCHED" == 1 && "$file_restore_failed" == 0 ]]; then
        restore_enabled_state nginx "$TX_NGINX_ENABLED" || restore_failed=1
        if [[ "$TX_NGINX_ACTIVE" == active ]]; then
            if nginx -t; then
                systemctl reload nginx || systemctl start nginx || restore_failed=1
            else
                restore_failed=1
            fi
        else
            systemctl stop nginx >/dev/null 2>&1 || true
        fi
    fi
    if [[ "$TX_CERTBOT_TIMER_TOUCHED" == 1 ]]; then
        restore_enabled_state certbot.timer "$TX_CERTBOT_TIMER_ENABLED"
        if [[ "$TX_CERTBOT_TIMER_ACTIVE" == active ]]; then
            systemctl start certbot.timer || restore_failed=1
        else
            systemctl stop certbot.timer >/dev/null 2>&1 || restore_failed=1
        fi
    fi
    if (( restore_failed )); then
        warn "Rollback needs manual attention. Original and failed files are retained in $TX_DIR."
    else
        warn "Previous managed files/service state restored; recovery files retained in $TX_DIR."
    fi
    warn "Dependencies, service account, and issued certificates are retained. Xray was not modified."
}

transaction_commit() {
    TX_ACTIVE=0
    info "Installation committed. Protected recovery snapshot: $TX_DIR"
}

installer_exit() {
    local status="$1"
    if [[ "$TX_ACTIVE" == 1 && "$status" == 0 ]]; then status=1; fi
    trap - EXIT ERR HUP INT TERM
    set +e
    transaction_rollback
    exit "$status"
}
trap 'installer_exit "$?"' EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM

acquire_install_lock() {
    command -v flock >/dev/null 2>&1 || die "flock is required (util-linux); no installation changes made."
    exec 9> "$LOCK_PATH"
    flock -n 9 || die "Another UNUNKNOWNTUN installation is running. Stop and retry after it finishes."
}

require_root() {
    [[ ${EUID:-$(id -u)} -eq 0 ]] || die "This installer must be run as root."
    command -v systemctl >/dev/null 2>&1 || die "This installer requires systemd."
}

detect_os() {
    [[ -r /etc/os-release ]] || die "The operating system could not be detected. Ubuntu or Debian is required."
    local os_id
    # Read os-release inside command substitution so distribution variables
    # such as VERSION cannot overwrite the installer's release VERSION.
    # shellcheck disable=SC1091
    os_id="$(. /etc/os-release; printf '%s' "${ID:-}")"
    case "$os_id" in
        ubuntu|debian) ;;
        *) die "This release only supports Ubuntu and Debian (ID=${os_id:-unknown})." ;;
    esac
}

ask() {
    local __name="$1" prompt="$2" default="${3:-}" _ask_reply
    if [[ -n "$default" ]]; then
        read -r -p "$prompt [$default]: " _ask_reply || die "Input closed; installation cancelled."
        _ask_reply="${_ask_reply:-$default}"
    else
        read -r -p "$prompt: " _ask_reply || die "Input closed; installation cancelled."
    fi
    printf -v "$__name" '%s' "$_ask_reply"
}

yes_no() {
    local prompt="$1" default="${2:-y}" answer
    while true; do
        ask answer "$prompt (y/n)" "$default"
        case "$answer" in
            [Yy]|[Yy][Ee][Ss]) return 0 ;;
            [Nn]|[Nn][Oo]) return 1 ;;
            *) warn "Enter y for yes or n for no; previous answers are retained." ;;
        esac
    done
}

# Read directly into the caller's variable: no subshell and no loss of earlier
# answers. Validators report failure instead of exiting the entire installer.
ask_valid() {
    local field_name="$1" field_prompt="$2" field_default="$3" validator="$4" message="$5"
    while true; do
        ask "$field_name" "$field_prompt" "$field_default"
        "$validator" "${!field_name}" && return 0
        warn "$message Please correct this value; previous answers are retained."
    done
}

valid_name() { [[ -n "$1" && "$1" != *$'\n'* && "$1" != *$'\r'* && "$1" != *'='* ]]; }
valid_email() { [[ "$1" =~ ^[^[:space:]@]+@[^[:space:]@]+\.[^[:space:]@]+$ ]]; }
valid_cert_path() { [[ "$1" =~ ^/[A-Za-z0-9_./-]+$ ]]; }
valid_sessions() { [[ "$1" =~ ^[0-9]{1,2}$ ]] && (( 10#$1 >= 2 && 10#$1 <= 32 )); }
valid_padding() { [[ "$1" =~ ^(0(\.[0-9]{1,2})?|1(\.0{1,2})?)$ ]]; }
valid_two_choices() { [[ "$1" == 1 || "$1" == 2 ]]; }
valid_three_choices() { [[ "$1" == 1 || "$1" == 2 || "$1" == 3 ]]; }
valid_byte_padding() { [[ "$1" =~ ^(0|[1-9][0-9]{0,3})(-(0|[1-9][0-9]{0,3}))?$ ]] && (( 10#${BASH_REMATCH[1]} <= 10#${BASH_REMATCH[3]:-${BASH_REMATCH[1]}} && 10#${BASH_REMATCH[3]:-${BASH_REMATCH[1]}} <= 1024 )); }
valid_http_padding() { [[ "$1" =~ ^(0|[1-9][0-9]{0,3})(-(0|[1-9][0-9]{0,3}))?$ ]] && (( 10#${BASH_REMATCH[1]} <= 10#${BASH_REMATCH[3]:-${BASH_REMATCH[1]}} && 10#${BASH_REMATCH[3]:-${BASH_REMATCH[1]}} <= 4096 )); }
valid_scan_seconds() { [[ "$1" =~ ^[0-9]{1,3}$ ]] && (( 10#$1 >= 10 && 10#$1 <= 600 )); }
valid_scan_count() { [[ "$1" =~ ^[0-9]{1,3}$ ]] && (( 10#$1 >= 1 && 10#$1 <= 128 )); }
valid_scan_hours() { [[ "$1" =~ ^[0-9]{1,3}$ ]] && (( 10#$1 >= 1 && 10#$1 <= 168 )); }
valid_dial_host() {
    [[ "$1" != *%* ]] || return 1
    valid_domain "$1" && return 0
    python3 - "$1" <<'PY'
import ipaddress,sys
try:
    value=ipaddress.ip_address(sys.argv[1])
    assert not (value.is_unspecified or value.is_multicast or value.is_loopback or value.is_link_local)
except (ValueError,AssertionError): sys.exit(1)
PY
}
valid_profile_value() {
    python3 - "$1" "$2" <<'ECH_SOURCE_VALIDATE'
__PROFILE_VALIDATION_SOURCE__
ECH_SOURCE_VALIDATE
}
valid_ech_source() { valid_profile_value ech "$1"; }
validate_peer_path_profile() {
    # Check values before interpolating them into the JSON profile.
    [[ "$PEER_PATH_ROTATION" =~ ^(0|[1-9][0-9]{0,6}[smh])$ && "$PEER_PATH_GRACE" =~ ^(0|[1-9][0-9]{0,6}[smh])$ && "$PEER_PATH_COUNT" =~ ^[2-8]$ && "$PEER_PATH_LEGACY" =~ ^(true|false)$ ]] || return 1
    valid_profile_value path-profile "{\"interval\":\"$PEER_PATH_ROTATION\",\"count\":\"$PEER_PATH_COUNT\",\"grace\":\"$PEER_PATH_GRACE\",\"legacy\":\"$PEER_PATH_LEGACY\"}"
}
valid_four_choices() { [[ "$1" =~ ^[1-4]$ ]]; }
valid_fragment_size() { [[ "$1" =~ ^([1-9][0-9]{0,3})-([1-9][0-9]{0,3})$ ]] && (( 10#${BASH_REMATCH[1]} >= 16 && 10#${BASH_REMATCH[1]} <= 10#${BASH_REMATCH[2]} && 10#${BASH_REMATCH[2]} <= 4096 )); }
valid_fragment_interval() { [[ "$1" =~ ^([0-9]{1,3})-([0-9]{1,3})ms$ ]] && (( 10#${BASH_REMATCH[1]} <= 10#${BASH_REMATCH[2]} && 10#${BASH_REMATCH[2]} <= 20 )); }
valid_main_choice() { [[ "$1" =~ ^(10|[0-9])$ ]]; }
valid_five_choices() { [[ "$1" =~ ^[1-5]$ ]]; }
valid_manage_choice() { [[ "$1" =~ ^([1-9]|1[0-9]|2[0-4])$ ]]; }
valid_quota_gb() {
    python3 - "$1" <<'PY'
import decimal, sys
try:
    value = decimal.Decimal(sys.argv[1])
    scaled = value * 1_000_000_000
    valid = value.is_finite() and value >= 0 and scaled <= 9_000_000_000_000_000 and scaled == scaled.to_integral_value()
except (decimal.InvalidOperation, ValueError, OverflowError):
    valid = False
sys.exit(0 if valid else 1)
PY
}

retry_step() {
    local label="$1"; shift
    while ! "$@"; do
        warn "$label failed. Fix the reported issue, then retry this step; all answers are retained."
        yes_no "Retry $label now?" y || die "Cancelled during $label."
    done
}

ask_ports() {
    local field_name="$1" field_prompt="$2" field_default="$3" provider="${4:-none}" allowed="${5--}" reserved="${6:-}" value port seen
    while true; do
        ask value "$field_prompt" "$field_default"
        value="$(normalize_ports "$value")" || { warn "Use port numbers from 1 to 65535 separated by commas."; continue; }
        seen=0
        for port in ${value//,/ }; do
            if [[ ",$reserved," == *",$port,"* ]]; then
                warn "Port $port is reserved by this installation; choose a different port."; seen=1
            elif [[ "$provider" =~ ^(arvan|fastly)$ && "$port" != 443 ]]; then
                warn "This CDN compatibility profile uses HTTPS port 443. Use 443."; seen=1
            elif [[ "$provider" == cloudflare && ! "$port" =~ ^(443|2053|2083|2087|2096|8443)$ ]]; then
                warn "Cloudflare HTTPS proxy does not accept port $port. Choose 443, 2053, 2083, 2087, 2096, or 8443."; seen=1
            elif [[ "$allowed" == '' ]] && port_reserved_by_other_tunnel "$port"; then
                warn "Port $port belongs to another tunnel; choose a different port."; seen=1
            fi
        done
        (( seen == 0 )) || continue
        if [[ "$allowed" != - ]]; then
            check_port_conflicts "$value" "$allowed" "$field_prompt" || {
                [[ "$allowed" != '' ]] || warn "Suggested free port: $(next_free_port 2053 || true)"
                continue
            }
        fi
        printf -v "$field_name" '%s' "$value"
        return 0
    done
}

lower_ascii() {
    printf '%s' "$1" | LC_ALL=C tr '[:upper:]' '[:lower:]'
}

valid_domain() {
    local value
    value="$(lower_ascii "$1")"
    [[ ${#value} -le 253 && "$value" == *.* && "$value" != .* && "$value" != *. && "$value" != *..* && "$value" =~ ^[a-z0-9.-]+$ ]] || return 1
    local label
    for label in ${value//./ }; do
        [[ ${#label} -le 63 && "$label" != -* && "$label" != *- ]] || return 1
    done
}

valid_port() {
    [[ "$1" =~ ^[0-9]{1,5}$ ]] && (( 10#$1 >= 1 && 10#$1 <= 65535 ))
}

valid_ipv4() {
    local value="$1" octet old_ifs="$IFS"
    local -a octets
    IFS='.' read -ra octets <<< "$value"
    IFS="$old_ifs"
    [[ ${#octets[@]} -eq 4 ]] || return 1
    for octet in "${octets[@]}"; do
        [[ "$octet" =~ ^[0-9]{1,3}$ ]] || return 1
        (( 10#$octet >= 0 && 10#$octet <= 255 )) || return 1
    done
}

valid_public_ipv4() {
    local value="$1" first second rest
    valid_ipv4 "$value" || return 1
    IFS='.' read -r first second rest <<< "$value"
    first=$((10#$first)); second=$((10#$second))
    (( first >= 1 && first <= 223 )) || return 1
    (( first == 10 || first == 127 || (first == 169 && second == 254) || (first == 192 && second == 168) )) && return 1
    (( first == 172 && second >= 16 && second <= 31 )) && return 1
    (( first == 100 && second >= 64 && second <= 127 )) && return 1
    return 0
}

detect_public_ipv4() {
    local value
    value="$(ip -4 route get 1.1.1.1 2>/dev/null | sed -nE 's/.* src ([0-9.]+).*/\1/p' | head -n1)"
    if valid_public_ipv4 "$value"; then
        printf '%s' "$value"
        return 0
    fi
    value="$(curl --noproxy '*' -4fsS --connect-timeout 5 --max-time 8 https://api.ipify.org 2>/dev/null || true)"
    valid_public_ipv4 "$value" || return 1
    printf '%s' "$value"
}

domain_points_to_ipv4() {
    local domain="$1" expected="$2"
    getent ahostsv4 "$domain" 2>/dev/null | awk '{print $1}' | grep -Fxq "$expected"
}

domain_has_ipv4() {
    getent ahostsv4 "$1" 2>/dev/null | awk '{print $1}' | grep -Eq '^[0-9]+(\.[0-9]+){3}$'
}

domain_is_proxied_from_ipv4() {
    local domain="$1" origin_ip="$2" resolved
    resolved="$(getent ahostsv4 "$domain" 2>/dev/null | awk '{print $1}' | sort -u)"
    [[ -n "$resolved" ]] || return 1
    ! printf '%s\n' "$resolved" | grep -Fxq "$origin_ip"
}

proxy_default_ports() {
    case "$1" in
        cloudflare) printf '443' ;;
        arvan|fastly|nginx) printf '443' ;;
        none) printf '443,8443,2053' ;;
        *) return 1 ;;
    esac
}

proxy_summary() {
    case "$1" in
        cloudflare) printf 'Cloudflare proxy' ;;
        arvan) printf 'ArvanCloud proxy' ;;
        fastly) printf 'Fastly proxy (experimental XHTTP profile)' ;;
        nginx) printf 'Nginx on Iran / direct DNS / no CDN' ;;
        none) printf 'direct / no proxy' ;;
        *) printf 'unknown' ;;
    esac
}

transport_summary() {
    case "${transport:-wss}" in
        xhttp) printf 'XHTTP packet-up + TLS (experimental; no gRPC)' ;;
        auto) printf 'Legacy HTTP/2 with WSS fallback' ;;
        h2) printf 'Legacy HTTP/2' ;;
        *) printf 'Normal WSS + verified TLS' ;;
    esac
}

show_proxy_guidance() {
    local provider="$1" domain="$2" path="$3"
    [[ "$provider" != none && "$provider" != nginx ]] || return 0
    printf '\nCDN settings for %s (%s):\n' "$domain" "$(proxy_summary "$provider")"
    printf '  Origin protocol HTTPS; origin port 443; origin address = this server IP.\n'
    printf '  Preserve Host and TLS SNI = %s.\n' "$domain"
    printf '  Bypass caching, redirects and browser/JavaScript challenges for %s.\n' "$path"
    if [[ "${path_rotation:-0}" != 0 ]]; then
        printf '  Also forward the complete /gdt-r/ prefix unchanged for coordinated rotating paths.\n'
    fi
    if [[ "${transport:-wss}" == xhttp ]]; then
        printf '  Forward GET/POST and Authorization unchanged under the entire path prefix.\n'
        printf '  Disable response/request buffering and caching; allow streaming downloads and POST uploads.\n'
        printf '  XHTTP is experimental on this CDN: a successful website/TLS check is not a traffic test.\n'
    else
        printf '  Enable WebSockets; forward Authorization and Upgrade unchanged.\n'
    fi
    printf '  Keep origin certificate verification enabled.\n'
    printf '  ACME: forward /.well-known/acme-challenge/ to origin HTTP port 80 without caching.\n'
}

ask_target_port() {
    local suggestion="$1" reserved="$2"
    while true; do
        ask_valid target_port "Dedicated Panel/Xray inbound port on the foreign server" "$suggestion" valid_port "Use a port from 1 to 65535."
        target_port="$((10#$target_port))"
        [[ ",$reserved," != *",$target_port,"* ]] || { warn "Port $target_port is reserved for Nginx or another backend."; continue; }
        port_reserved_by_other_tunnel "$target_port" && { warn "Port $target_port belongs to another tunnel. Create a separate Xray inbound."; continue; }
        tcp_probe 127.0.0.1 "$target_port" 3 && return 0
        warn "Nothing accepts connections on 127.0.0.1:$target_port. Create/enable that dedicated inbound in your panel, then enter the same port to recheck or a corrected port."
    done
}

select_backend_ports() {
    local reserved="$1" candidate
    candidate=18080
    while true; do
        backend_port="$(next_free_port "$candidate" 18998)" || die "No free internal backend port was found."
        [[ ",$reserved," == *",$backend_port,"* ]] || break
        candidate=$((backend_port + 1))
    done
    h2_backend_port=""  # Retained metadata argument only; no retired gRPC listener.
    info "Free internal HTTP/WSS/XHTTP backend: $backend_port. No gRPC backend is allocated."
}

# Confirms the actual authenticated upgrade, not merely a cached CDN homepage.
# The confidential token goes through an inherited descriptor, never argv.
probe_websocket_path() {
    local domain="$1" connect_host="$2" port="$3" path="$4" secret="$5" ca="$6" min_tls="${7:-1.3}" probe_mode="${8:-ws}"
    python3 - "$domain" "$connect_host" "$port" "$path" "$ca" "$min_tls" "$probe_mode" 3<<< "$secret" <<'WS_PROBE'
import base64, hashlib, hmac, os, socket, ssl, sys, time, uuid
domain, host, port, path, ca, minimum, mode = sys.argv[1:]
if mode == "xhttp":
    path = path.rstrip("/") + "/" + str(uuid.uuid4())
token = os.fdopen(3).read().rstrip("\n")
encode = lambda data: base64.urlsafe_b64encode(data).decode().rstrip("=")
stamp, nonce = str(int(time.time())), encode(os.urandom(18))
signature = encode(hmac.new(token.encode(), f"{stamp}\n{nonce}\n{domain.lower().rstrip('.')}\n{path}".encode(), hashlib.sha256).digest())
key = base64.b64encode(os.urandom(16)).decode()
expected = base64.b64encode(hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest()).decode()
try:
    ctx = ssl.create_default_context(cafile=ca)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2 if minimum == "1.2" else ssl.TLSVersion.TLSv1_3
    ctx.set_alpn_protocols(["http/1.1"])
    with socket.create_connection((host, int(port)), timeout=10) as raw:
        with ctx.wrap_socket(raw, server_hostname=domain) as conn:
            auth_header = f"Authorization: Bearer {stamp}.{nonce}.{signature}\r\n" if token else ""
            request = (f"GET {path} HTTP/1.1\r\nHost: {domain}\r\nUpgrade: websocket\r\n"
                       f"Connection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n"
                       f"{auth_header}\r\n")
            if mode == "xhttp":
                request = f"GET {path} HTTP/1.1\r\nHost: {domain}\r\nConnection: close\r\n{auth_header}\r\n"
            conn.sendall(request.encode())
            response = b""
            while b"\r\n\r\n" not in response and len(response) < 16384:
                block = conn.recv(1024)
                if not block:
                    break
                response += block
            lines = response.split(b"\r\n")
            status = lines[0].decode("ascii", "replace")[:160]
            headers = {}
            for line in lines[1:]:
                if not line:
                    break
                if b":" in line:
                    name, value = line.split(b":", 1)
                    headers[name.strip().lower()] = value.strip().decode("ascii", "replace")
            if mode == "xhttp":
                if status.split()[1:2] != ["200"] or "text/event-stream" not in headers.get(b"content-type", "") or "no-store" not in headers.get(b"cache-control", ""):
                    raise ValueError(f"expected authenticated XHTTP download headers, received {status or 'no response'}; check prefix, Host/SNI, Authorization, CDN cache/challenges and clock")
                print(f"[PASS] XHTTP HTTP route accepted through {host}:{port}; {conn.version()} and certificate verified. UNUNKNOWNTUN payload authentication is not tested by this probe.")
            elif (status.split()[1:2] != ["101"] or headers.get(b"sec-websocket-accept") != expected
                    or headers.get(b"upgrade", "").lower() != "websocket"):
                raise ValueError(f"expected authenticated WebSocket 101, received {status or 'no response'}; check WebSockets, Host/SNI, Authorization, path, cache/WAF rules and clock")
            else:
                kind = "Authenticated WebSocket" if token else "Client-entry WebSocket"
                print(f"[PASS] {kind} upgrade through {host}:{port}; {conn.version()} and certificate verified.")
except (OSError, ValueError, ssl.SSLError) as error:
    print(f"[FAIL] {mode} route {host}:{port}: {error}", file=sys.stderr)
    sys.exit(1)
WS_PROBE
}

normalize_ports() {
    local input="$1" item output="" seen="," old_ifs="$IFS"
    IFS=',' read -ra parts <<< "$input"
    IFS="$old_ifs"
    for item in "${parts[@]}"; do
        item="${item//[[:space:]]/}"
        valid_port "$item" || return 1
        item="$((10#$item))"
        if [[ "$seen" != *",$item,"* ]]; then
            output+="${output:+,}$item"
            seen+="$item,"
        fi
    done
    [[ -n "$output" ]] || return 1
    printf '%s' "$output"
}

valid_ws_path() {
    [[ ${#1} -ge 16 && ${#1} -le 512 && "$1" =~ ^/[A-Za-z0-9/_-]+$ && "$1" != /gdt-r/* ]]
}

valid_xhttp_path() {
    [[ ${#1} -ge 16 && ${#1} -le 512 && "$1" =~ ^/[A-Za-z0-9/_-]+$ && "$1" != *//* && "$1" != /gdt-r/* ]]
}

valid_transport_seed() {
    if [[ "${path_rotation:-0}" != 0 ]]; then valid_xhttp_path "$1"; else valid_ws_path "$1"; fi
}

valid_token() {
    [[ ${#1} -ge 16 && ${#1} -le 512 && "$1" != *$'\n'* && "$1" != *$'\r'* ]]
}

valid_tunnel_id() {
    [[ "$1" =~ ^[a-z0-9][a-z0-9-]{0,47}$ && "$1" != *--* ]]
}

tunnel_count() {
    local count=0 directory
    [[ -d "$TUNNELS_DIR" ]] || { printf '0'; return; }
    for directory in "$TUNNELS_DIR"/*; do
        [[ -d "$directory" && -f "$directory/deployment.env" ]] || continue
        count=$((count + 1))
    done
    printf '%s' "$count"
}

list_tunnels_compact() {
    local directory id name role provider state
    [[ -d "$TUNNELS_DIR" ]] || { echo "No tunnels are registered."; return; }
    printf '%-18s %-24s %-9s %-12s %-10s\n' "ID" "NAME" "ROLE" "PROXY" "SERVICE"
    for directory in "$TUNNELS_DIR"/*; do
        [[ -d "$directory" && -f "$directory/deployment.env" ]] || continue
        id="${directory##*/}"
        name="$(sed -n 's/^TUNNEL_NAME=//p' "$directory/deployment.env" | head -n1)"
        role="$(sed -n 's/^ROLE=//p' "$directory/deployment.env" | head -n1)"
        provider="$(sed -n 's/^FOREIGN_PROXY_PROVIDER=//p' "$directory/deployment.env" | head -n1)"
        state="$(systemctl is-active "ununknowntun@$id" 2>/dev/null || true)"
        printf '%-18s %-24.24s %-9s %-12s %-10s\n' "$id" "${name:-$id}" "${role:-unknown}" "${provider:-none}" "${state:-unknown}"
    done
}

prepare_tunnel_context() {
    local mode="$1" suggested_id="${2:-tunnel-$(( $(tunnel_count) + 1 ))}" suggested_name="${3:-}" id name
    if [[ "$mode" == existing ]]; then
        list_tunnels_compact
    fi
    while true; do
        ask id "Tunnel ID (lowercase letters, numbers, hyphens)" "$suggested_id"
        id="$(lower_ascii "$id")"
        valid_tunnel_id "$id" || { warn "Use 1-48 lowercase letters, numbers, or single hyphens."; continue; }
        if [[ "$mode" == new && -d "$TUNNELS_DIR/$id" ]]; then
            warn "Tunnel '$id' already exists. Choose another ID or use Manage."
            continue
        fi
        if [[ "$mode" == existing && ! -f "$TUNNELS_DIR/$id/deployment.env" ]]; then
            warn "Tunnel '$id' was not found."
            continue
        fi
        break
    done
    if [[ "$mode" == new ]]; then
        ask_valid name "Friendly tunnel name" "${suggested_name:-$id}" valid_name "Use a nonempty name without '=' or control characters."
        CURRENT_TUNNEL_NAME="$name"
        TUNNEL_IS_NEW=1
    else
        CURRENT_TUNNEL_NAME="$(sed -n 's/^TUNNEL_NAME=//p' "$TUNNELS_DIR/$id/deployment.env" | head -n1)"
        TUNNEL_IS_NEW=0
    fi
    CURRENT_TUNNEL_ID="$id"
    CONFIG_DIR="$TUNNELS_DIR/$id"
    TUNNEL_STATE_DIR="/var/lib/ununknowntun/$id"
    SERVICE="ununknowntun@$id"
}

select_proxy_provider() {
    local __name="$1" label="$2" choice
    printf '\n%s proxy mode:\n' "$label"
    printf '  1) No proxy / direct\n'
    printf '  2) Cloudflare proxy\n'
    printf '  3) ArvanCloud proxy\n'
    printf '  4) Fastly proxy (experimental; XHTTP profile only)\n'
    if [[ "$__name" == iran_provider ]]; then
        printf '  5) Nginx on Iran, direct HTTPS (no CDN; existing WS/XHTTP inbound required)\n'
        ask_valid choice "Select an option" "1" valid_five_choices "Select 1, 2, 3, 4, or 5."
    else
        ask_valid choice "Select an option" "1" valid_four_choices "Select 1, 2, 3, or 4."
    fi
    case "$choice" in
        1) printf -v "$__name" '%s' "$PROXY_PROVIDER_NONE" ;;
        2)
            printf -v "$__name" '%s' "$PROXY_PROVIDER_CLOUDFLARE"
            warn "Cloudflare: use Full (strict) origin TLS; bypass cache and browser challenges only for the tunnel path."
            ;;
        3)
            printf -v "$__name" '%s' "$PROXY_PROVIDER_ARVAN"
            warn "ArvanCloud: enable WebSockets, use HTTPS to origin on port 443, preserve Host/SNI, and bypass caching/security challenges for the tunnel path. WSS is used without requiring gRPC settings."
            ;;
        4) printf -v "$__name" '%s' fastly; warn "Fastly is an experimental XHTTP profile, not live-CDN certification. Use verified HTTPS to origin, streaming responses and cache bypass." ;;
        5) [[ "$__name" == iran_provider ]] || return 1; printf -v "$__name" '%s' nginx; warn "Standalone Nginx terminates HTTPS on Iran. It requires a matching dedicated WS/XHTTP Xray inbound; raw TCP clients are NOT converted automatically. Keep the entry domain DNS-only." ;;
        *) die "Invalid proxy selection." ;;
    esac
}

valid_five_choices() { [[ "$1" =~ ^[1-5]$ ]]; }

valid_rotation_hours() { [[ "$1" =~ ^[0-9]{1,3}$ ]] && (( 10#$1 >= 1 && 10#$1 <= 168 )); }
valid_path_count() { [[ "$1" =~ ^[2-8]$ ]]; }
valid_grace_minutes() { [[ "$1" =~ ^[0-9]{1,2}$ ]] && (( 10#$1 <= 60 )); }

select_path_profile() {
    local hours minutes
    path_rotation=0; path_count=3; path_grace=5m; path_legacy=false
    if yes_no "Rotate authenticated tunnel paths automatically on BOTH peers?" n; then
        ask_valid hours "Generate a fresh matching path set every N hours" 2 valid_rotation_hours "Use 1-168 hours."
        ask_valid path_count "Simultaneous paths per set (automatic reconnect failover)" 3 valid_path_count "Use 2-8 paths."
        ask_valid minutes "Previous/next path-set overlap in minutes" 5 valid_grace_minutes "Use 0-60 minutes."
        path_rotation="$((10#$hours))h"; path_grace="$((10#$minutes))m"
        [[ "$((10#$minutes))" != 0 ]] || path_grace=0
        warn "Both peers need 3.7 and the SAME token, base path and rotation profile. Keep system clocks synchronized. Path failure triggers another authenticated path; it does not prove filtering, and a broken client connection cannot be made lossless."
        warn "CDN rules must forward /gdt-r/ without rewriting, caching or browser challenges. Existing connections drain; the static path is disabled unless migration overlap is explicitly enabled in Manage/Edit."
    fi
}

select_session_renewal() {
    local hours
    session_renewal=0
    [[ "${mux_mode:-on}" == on ]] || return 0
    if yes_no "Renew tunnel carriers gradually (old streams get up to 2 minutes to drain)?" n; then
        ask_valid hours "Renew carriers every N hours" 2 valid_rotation_hours "Use 1-168 hours."
        session_renewal="$((10#$hours))h"
    fi
    info "Adaptive sessions stay between the configured minimum and maximum. Rotation also triggers gradual renewal; old carriers drain for up to 2 minutes, then remaining streams are interrupted so later renewal is not blocked. This does not create public IP addresses."
}

select_tunnel_profile() {
    local choice
    printf '\nTunnel type:\n  1) Normal tunnel (WSS + TLS)\n  2) XHTTP + TLS (packet-up; experimental)\n'
    while true; do
        ask_valid choice "Select tunnel type" "1" valid_two_choices "Select 1 or 2."
        transport=wss; [[ "$choice" != 2 ]] || transport=xhttp
        if [[ "$transport" != xhttp && "$foreign_provider" == fastly ]]; then
            warn "The Fastly product profile requires XHTTP. Choose 2; other answers are retained."
            continue
        fi
        break
    done
    select_mux_profile
    xhttp_mode=packet-up
    if [[ "$transport" == xhttp ]]; then
        printf '\nXHTTP mode:\n  1) Auto (conservative packet-up)\n  2) Stream up\n  3) Stream one (requires full-duplex CDN support)\n  4) Packet up\n'
        ask_valid choice "XHTTP mode (must match the paired server)" 4 valid_four_choices "Select 1-4."
        case "$choice" in 1) xhttp_mode=auto;; 2) xhttp_mode=stream-up;; 3) xhttp_mode=stream-one;; 4) xhttp_mode=packet-up;; esac
        warn "Streaming modes are experimental. They need both peers on 3.6 and a real payload test through the selected CDN."
    fi
}

select_mux_profile() {
    local choice
    printf '\nMUX:\n  1) On: share sessions between connections\n  2) Off: isolated tunnel session per client connection (more resources; sessions limit controls concurrency)\n'
    ask_valid choice "MUX mode" 1 valid_two_choices "Select 1 or 2."
    mux_mode=on; [[ "$choice" != 2 ]] || mux_mode=off
}

select_entry_profile() {
    local choice
    entry_transport=ws
    [[ "$iran_provider" != none ]] || return 0
    printf '\nIran client entry (independent of the inter-server tunnel):\n  1) Existing Xray WebSocket inbound\n  2) Xray XHTTP packet-up inbound (experimental)\n'
    while true; do
        ask_valid choice "Client entry type" 1 valid_two_choices "Select 1 or 2."
        if [[ "$iran_provider" == fastly && "$choice" != 2 ]]; then
            warn "This Fastly profile requires a matching Xray XHTTP packet-up inbound. Choose 2, or correct the Iran provider selection."
            continue
        fi
        [[ "$choice" != 2 ]] || entry_transport=xhttp
        break
    done
    warn "The installer does not modify Xray. Configure the dedicated foreign inbound with the selected client entry transport, no inbound TLS, and the displayed path."
}

validate_selected_profile() {
    if [[ "${foreign_provider:-none}" == fastly && "${transport:-wss}" != xhttp ]]; then
        fail "Fastly foreign proxy requires the XHTTP carrier in this release. Correct the proxy selection, or cancel and create an XHTTP pair; the installer will not silently change the paired protocol."
        return 1
    fi
    if [[ "${iran_provider:-none}" == fastly && "${entry_transport:-ws}" != xhttp ]]; then
        fail "Fastly Iran entry requires an explicitly configured Xray XHTTP packet-up inbound. Correct the Iran proxy/entry settings before installation."
        return 1
    fi
    return 0
}

select_tls_handshake_profile() {
    local choice
    printf '\nTLS handshake:\n  1) ECH OFF\n  2) ECH ON (strict; no silent fallback)\n  3) ECH OFF + TLS ClientHello fragmentation (experimental)\n'
    while true; do
        ask_valid choice "TLS handshake mode" 1 valid_three_choices "Select 1, 2 or 3."
        ech_mode=off; tls_fragment=off; ech_source=auto
        if [[ "$choice" == 2 ]]; then
            ech_mode=strict
            warn "ECH requires TLS 1.3 and a valid DNS HTTPS ECH configuration. Only a successful strict handshake proves acceptance."
            warn "Any provider may be selected, but its real TLS terminator must support ECH. Ordinary managed Nginx has no ECH keys. Unsupported endpoints fail closed, with no silent downgrade."
            if ! yes_no "Discover ECH automatically from TLS SNI using verified DoH?" y; then
                ask_valid ech_source "ECHConfigList base64 OR domain+resolver (example cloudflare-ech.com+udp://9.9.9.9)" "" valid_ech_source "Use a base64 config or a resolver descriptor, without spaces or shell characters."
            fi
        elif [[ "$choice" == 3 ]]; then
            tls_fragment=hello
            warn "Experimental preset only, not a guaranteed censorship fix. Fragmentation affects ClientHello, not blocked IP routing."
            ask_valid fragment_size "Fragment size range in bytes" "100-200" valid_fragment_size "Use MIN-MAX with 16 <= MIN <= MAX <= 4096."
            ask_valid fragment_interval "Fragment delay range" "1-3ms" valid_fragment_interval "Use MIN-MAXms with 0 <= MIN <= MAX <= 20."
        fi
        return 0
    done
}

select_padding_profile() {
    padding_bytes=0; xhttp_padding=0
    if yes_no "Add random data-frame padding bytes? (extra traffic; no DPI guarantee)" n; then
        ask_valid padding_bytes "Padding bytes (number or MIN-MAX)" 100-1000 valid_byte_padding "Use a number/range within 0-1024. Zero disables padding."
    fi
    if [[ "${transport:-wss}" == xhttp ]] && yes_no "Add XHTTP request/response header padding?" n; then
        ask_valid xhttp_padding "XHTTP xPaddingBytes (number or MIN-MAX)" 100-1000 valid_http_padding "Use a number/range within 0-4096."
    fi
}

select_dial_profile() {
    local choice
    dial_host=""; tls_sni="$domain"; http_host="${http_host:-$domain}"; clean_scan=no; scan_auto=no
    scan_seconds=300; scan_count=64; scan_hours=8
    if [[ "$foreign_provider" != none ]]; then
        printf '\nCDN connection address:\n  1) Use my tunnel domain\n  2) Supply a clean IP or clean domain (Host/SNI stay separate)\n'
        [[ "$foreign_provider" != cloudflare ]] || printf '  3) Scan Cloudflare addresses with actual tunnel authentication\n'
        while true; do
            ask_valid choice "Connection address" 1 valid_three_choices "Choose a listed option."
            [[ "$choice" != 3 || "$foreign_provider" == cloudflare ]] && break
            warn "Built-in scanning is Cloudflare only; manual addresses work with all providers."
        done
        [[ "$choice" != 2 ]] || ask_valid dial_host "Clean IP/domain (without scheme or port)" "" valid_dial_host "Enter a valid IP or domain; ports are configured separately."
        if [[ "$choice" == 3 ]]; then
            clean_scan=yes
            ask_valid scan_seconds "Maximum scan duration, seconds" 300 valid_scan_seconds "Use 10-600 seconds."
            ask_valid scan_count "Maximum candidate IPs" 64 valid_scan_count "Use 1-128."
        fi
        if yes_no "Customize TLS SNI and HTTP Host? (CDN must allow this pairing)" n; then
            ask_valid tls_sni "TLS SNI / certificate name" "$domain" valid_domain "Enter a valid domain. TLS verification remains enabled."
            warn "HTTP Host must already match the paired egress ws-host AND its CDN/Nginx route. Change both peers with Edit/signed update before using a different Host."
            ask_valid http_host "Exact HTTP Host configured on the paired egress" "$http_host" valid_domain "Enter the domain configured on the paired endpoint and CDN."
        fi
        if [[ "$foreign_provider" == cloudflare ]] && yes_no "Enable periodic authenticated clean-IP scans and automatic update?" n; then
            scan_auto=yes
            ask_valid scan_hours "Scan interval in hours" 8 valid_scan_hours "Use 1-168 hours."
        fi
    fi
}

write_cdn_settings() {
    [[ "$foreign_provider" == cloudflare ]] || return 0
    python3 - "$CONFIG_DIR/cdn-endpoints.json" "$scan_auto" "$scan_seconds" "$scan_count" "$scan_hours" <<'PY'
import json,os,sys,tempfile
value={"schema":1,"enabled":sys.argv[2]=="yes","duration_seconds":int(sys.argv[3]),"max_candidates":int(sys.argv[4]),"samples":2,"probe_timeout_seconds":6,"minimum_improvement_percent":15,"interval_hours":int(sys.argv[5]),"candidate_source":"official","candidates":[]}
if os.path.islink(sys.argv[1]): raise SystemExit('Refusing scanner-settings symlink.')
fd,stage=tempfile.mkstemp(prefix='.cdn-settings-',dir=os.path.dirname(sys.argv[1]))
try:
    with os.fdopen(fd,"w") as out: json.dump(value,out,indent=2)
    os.replace(stage,sys.argv[1])
finally:
    if os.path.exists(stage): os.unlink(stage)
PY
}

port_reserved_by_other_tunnel() {
    local port="$1" file owner
    [[ -d "$TUNNELS_DIR" ]] || return 1
    for file in "$TUNNELS_DIR"/*/ports.list; do
        [[ -f "$file" ]] || continue
        owner="${file%/ports.list}"; owner="${owner##*/}"
        [[ "$owner" == "$CURRENT_TUNNEL_ID" ]] && continue
        grep -Fxq "$port" "$file" && return 0
    done
    return 1
}

next_free_port() {
    local start="$1" end="${2:-65535}" port
    for ((port=start; port<=end; port++)); do
        port_reserved_by_other_tunnel "$port" && continue
        port_is_listening "$port" && continue
        printf '%s' "$port"
        return 0
    done
    return 1
}

discover_xray_loopback_ports() {
    ss -H -ltnp 2>/dev/null | awk '
        /xray/ && $4 ~ /^(127\.0\.0\.1|\[::1\]):[0-9]+$/ {
            address=$4; sub(/^.*:/, "", address); print address
        }' | sort -nu
}

have_command() {
    command -v "$1" >/dev/null 2>&1
}

tcp_probe() {
    local host="$1" port="$2" timeout_seconds="${3:-6}"
    timeout "$timeout_seconds" bash -c 'exec 3<>/dev/tcp/$1/$2' _ "$host" "$port" >/dev/null 2>&1
}

port_is_listening() {
    local port="$1"
    ss -H -ltn "sport = :$port" 2>/dev/null | grep -q .
}

show_firewall_diagnostics() {
    echo "----- Firewall summary -----"
    if have_command ufw; then
        ufw status verbose 2>/dev/null | sed -n '1,35p' || true
    else
        echo "UFW: not installed"
    fi
    if have_command iptables; then
        iptables -S INPUT 2>/dev/null | sed -n '1,35p' || true
    fi
    if have_command nft; then
        nft list ruleset 2>/dev/null | grep -Ei 'hook input|policy (drop|reject)|dport|drop|reject' | head -n 50 || true
    fi
}

preflight_header() {
    local role="$1" foreign_provider="${2:-none}" iran_provider="${3:-none}"
    printf '\n%s=== Reverse Tunnel Preflight: %s ===%s\n' "$CYAN" "$role" "$RESET"
    echo "Required traffic direction: Iran -> foreign server."
    echo "Foreign route: $(proxy_summary "$foreign_provider")."
    echo "Iran client entry: $(proxy_summary "$iran_provider")."
    echo "Clients connect to the Iran entry port; traffic exits through the foreign server."
}

preflight_base() {
    local failures=0
    [[ ${EUID:-$(id -u)} -eq 0 ]] && pass "Running as root." || { fail "Root access is required."; failures=$((failures + 1)); }
    have_command systemctl && pass "systemd is available." || { fail "systemd is required."; failures=$((failures + 1)); }
    have_command ss && pass "Socket inspection is available." || { fail "The iproute2 package is required."; failures=$((failures + 1)); }
    have_command getent && pass "DNS resolver tooling is available." || { fail "The libc resolver tools are required."; failures=$((failures + 1)); }
    if timedatectl show -p NTPSynchronized --value 2>/dev/null | grep -qx true; then
        pass "System clock is synchronized."
    else
        warn "System clock synchronization is not confirmed. Existing time services are unchanged; correct clock drift before TLS testing."
    fi
    return "$failures"
}

ensure_preflight_tools() {
    local missing=0 tool
    local -a packages=()
    for tool in ss getent timeout openssl curl python3; do
        have_command "$tool" || missing=1
    done
    (( missing == 0 )) && return 0
    have_command ss || packages+=(iproute2)
    have_command getent || packages+=(libc-bin)
    have_command timeout || packages+=(coreutils)
    have_command openssl || packages+=(openssl)
    have_command curl || packages+=(curl)
    have_command python3 || packages+=(python3)
    [[ -s /etc/ssl/certs/ca-certificates.crt || -s "$CONFIG_DIR/ca-bundle.pem" ]] || packages+=(ca-certificates)
    info "Installing required preflight tools..."
    apt-get -o Acquire::Retries=2 -o Acquire::http::Timeout=20 -o Acquire::https::Timeout=20 update
    DEBIAN_FRONTEND=noninteractive apt-get -o Acquire::Retries=2 install --no-upgrade -y "${packages[@]}"
    for tool in ss getent timeout openssl curl python3; do
        have_command "$tool" || die "Required preflight command is unavailable after installation: $tool"
    done
}

preflight_foreign_inputs() {
    local domain="$1" direct_ip="$2" ports="$3" backend_port="$4" h2_backend_port="$5" target_port="$6" provider="${7:-none}" failures=0
    preflight_header "FOREIGN / EGRESS" "$provider" none
    preflight_base || failures=$((failures + $?))
    if [[ "$provider" == none ]] && domain_points_to_ipv4 "$domain" "$direct_ip"; then
        pass "Direct A record points to this server: $domain -> $direct_ip"
    elif [[ "$provider" != none ]] && domain_is_proxied_from_ipv4 "$domain" "$direct_ip"; then
        pass "$domain resolves through $(proxy_summary "$provider") instead of exposing $direct_ip."
    else
        if [[ "$provider" == none ]]; then
            fail "$domain does not resolve directly to $direct_ip. Set it to DNS-only/direct and retry."
        else
            fail "$domain does not appear to be proxied by $(proxy_summary "$provider"). Enable the selected proxy and wait for DNS propagation."
        fi
        failures=$((failures + 1))
    fi
    if tcp_probe 127.0.0.1 "$target_port" 3; then
        pass "Foreign target accepts TCP on the exact forwarding address 127.0.0.1:$target_port."
        if ss -H -ltn "sport = :$target_port" 2>/dev/null | awk '{print $4}' | grep -Eq '^(127\.0\.0\.1|\[::1\]):'; then
            pass "Foreign inbound is restricted to loopback."
        else
            warn "Foreign inbound port $target_port is not loopback-only. Set its panel Listen IP to 127.0.0.1 to prevent direct public access."
        fi
    else
        fail "Cannot connect to 127.0.0.1:$target_port. Create a separate loopback inbound; do not change the existing Native Reverse inbound."
        failures=$((failures + 1))
    fi
    port_reserved_by_other_tunnel "$backend_port" && { fail "Backend port $backend_port belongs to another tunnel."; failures=$((failures + 1)); }
    port_reserved_by_other_tunnel "$target_port" && { fail "Target port $target_port belongs to another tunnel."; failures=$((failures + 1)); }
    check_port_conflicts "80,$ports" 'nginx' "Nginx/WSS" || failures=$((failures + 1))
    check_port_conflicts "$backend_port" '' "Go backend" || failures=$((failures + 1))
    (( failures == 0 )) || {
        show_firewall_diagnostics
        fail "Foreign preflight failed. No tunnel service was installed or replaced."
        return 1
    }
    pass "Foreign prerequisites are ready."
}

preflight_origin_path() {
    local domain="$1" direct_ip="$2" ports="$3" local_ports="$4" foreign_provider="${5:-none}" iran_provider="${6:-none}" failures=0 port body connect_host curl_tls=--tlsv1.3
    local -a tls_options=(-tls1_3)
    if [[ "$foreign_provider" == arvan ]]; then tls_options=(-min_protocol TLSv1.2); curl_tls=--tlsv1.2; fi
    preflight_header "IRAN / ORIGIN" "$foreign_provider" "$iran_provider"
    preflight_base || failures=$((failures + $?))
    if [[ "${clean_scan:-no}" == yes || -n "${dial_host:-}" || "${tls_sni:-$domain}" != "$domain" || "${http_host:-$domain}" != "$domain" ]]; then
        warn "Custom CDN address/handshake: ordinary domain probes are deferred. The actual configured core must authenticate before service activation."
        check_port_conflicts "$local_ports" '' "Iran client entry/backend" || failures=$((failures + 1))
        (( failures == 0 ))
        return
    fi
    if [[ "$foreign_provider" == none ]] && domain_points_to_ipv4 "$domain" "$direct_ip"; then
        pass "Foreign domain is direct: $domain -> $direct_ip"
        connect_host="$direct_ip"
    elif [[ "$foreign_provider" != none ]] && domain_is_proxied_from_ipv4 "$domain" "$direct_ip"; then
        pass "Foreign domain is routed through $(proxy_summary "$foreign_provider")."
        connect_host="$domain"
    else
        fail "Foreign DNS state does not match the selected $(proxy_summary "$foreign_provider") mode."
        failures=$((failures + 1))
        connect_host="$direct_ip"
    fi
    for port in ${ports//,/ }; do
        if tcp_probe "$connect_host" "$port" 7; then
            pass "TCP path Iran -> $connect_host:$port is open."
        else
            fail "TCP path Iran -> $connect_host:$port is blocked or timed out."
            failures=$((failures + 1))
            continue
        fi
        if [[ "${ech_mode:-off}" == strict || "${tls_fragment:-off}" == hello ]]; then
            warn "Ordinary OpenSSL/curl cannot reproduce the selected ECH/fragment handshake. Deferring TLS certificate, ECH acceptance and tunnel authentication to the actual UNUNKNOWNTUN startup probe; TCP success alone is not validation."
            continue
        fi
        if echo | timeout 10 openssl s_client -CAfile "$ORIGIN_CA_PATH" -connect "$connect_host:$port" -servername "$domain" -verify_hostname "$domain" -verify_return_error "${tls_options[@]}" >/dev/null 2>&1; then
            pass "Verified TLS certificate and SNI on $connect_host:$port for $domain."
        else
            fail "TLS certificate/SNI validation failed on $connect_host:$port for $domain."
            failures=$((failures + 1))
        fi
        if have_command curl; then
            if [[ "$foreign_provider" == none ]]; then
                body="$(curl --cacert "$ORIGIN_CA_PATH" --noproxy '*' -4fsS "$curl_tls" --connect-timeout 7 --max-time 12 --resolve "$domain:$port:$direct_ip" "https://$domain:$port/" 2>/dev/null || true)"
            else
                body="$(curl --cacert "$ORIGIN_CA_PATH" --noproxy '*' -4fsS "$curl_tls" --connect-timeout 7 --max-time 12 "https://$domain:$port/" 2>/dev/null || true)"
            fi
            if [[ -n "$body" ]]; then
                pass "HTTPS decoy endpoint responds on $connect_host:$port with host $domain."
            else
                fail "HTTPS endpoint did not return a response on $domain:$port."
                failures=$((failures + 1))
            fi
        fi
    done
    for port in ${local_ports//,/ }; do
        port_reserved_by_other_tunnel "$port" && { fail "Iran entry/backend port $port belongs to another tunnel."; failures=$((failures + 1)); }
    done
    check_port_conflicts "$local_ports" '' "Iran client entry/backend" || failures=$((failures + 1))
    (( failures == 0 )) || {
        show_firewall_diagnostics
        echo "If every local rule is correct but TCP still times out, open the port in the provider/datacenter firewall."
        fail "Iran-to-foreign preflight failed. The reverse tunnel was not started."
        return 1
    }
    pass "Both endpoints satisfy the network requirements for the reverse tunnel."
}

verify_foreign_reverse_endpoint() {
    local domain="$1" ports="$2" failures=0 port body
    printf '\n%s=== Foreign Endpoint Verification ===%s\n' "$CYAN" "$RESET"
    for port in ${ports//,/ }; do
        body="$(curl --cacert "$LOCAL_TLS_CA_PATH" --noproxy '*' -4fsS --tlsv1.2 --connect-timeout 7 --max-time 12 --resolve "$domain:$port:127.0.0.1" "https://$domain:$port/" 2>/dev/null || true)"
        if [[ -n "$body" ]]; then
            pass "Local HTTPS front end responds with the correct certificate on $domain:$port."
        else
            fail "Local ORIGIN leg $domain:$port failed. Check origin certificate, hostname, LOCAL_TLS_CA_PATH and Nginx listener. A CDN edge certificate cannot repair a missing/untrusted origin certificate. Run ununknowntunctl doctor for separate origin/edge evidence."
            failures=$((failures + 1))
        fi
    done
    (( failures == 0 )) || { fail "Foreign endpoint verification failed. Fix the reported network issue before retrying."; return 1; }
}

verify_origin_reverse_tunnel() {
    local expected_sessions="$1" established h2_established fatal live logs invocation_now probe_pid=""
    printf '\n%s=== Reverse Tunnel Soak Test ===%s\n' "$CYAN" "$RESET"
    [[ "$SERVICE_INVOCATION" =~ ^[0-9a-fA-F]{32}$ ]] || { fail "Cannot identify the new systemd invocation for health validation."; return 1; }
    info "Testing persistent reverse sessions for 20 seconds..."
    if [[ "${mux_mode:-on}" == off ]]; then
        info "MUX is OFF: opening one bounded local test connection to trigger a dedicated authenticated session. This is not Xray client authentication."
        python3 - "${local_ports%%,*}" <<'MUX_PROBE' &
import socket, sys, time
try:
    with socket.create_connection(("127.0.0.1", int(sys.argv[1])), timeout=5) as conn:
        time.sleep(25)
except OSError as error:
    print("Local dedicated-session probe failed: " + str(error), file=sys.stderr)
MUX_PROBE
        probe_pid=$!
    fi
    sleep 20
    if [[ -n "$probe_pid" ]]; then kill "$probe_pid" 2>/dev/null || true; wait "$probe_pid" 2>/dev/null || true; fi
    if ! systemctl is-active --quiet "$SERVICE"; then
        journalctl "_SYSTEMD_INVOCATION_ID=$SERVICE_INVOCATION" --no-pager || true
        fail "The reverse origin service stopped during validation."
        return 1
    fi

    invocation_now="$(systemctl show "$SERVICE" -p InvocationID --value)"
    [[ "$invocation_now" == "$SERVICE_INVOCATION" ]] || { fail "The service restarted during validation; refusing stale health results."; return 1; }
    logs="$(journalctl "_SYSTEMD_INVOCATION_ID=$SERVICE_INVOCATION" --no-pager 2>/dev/null)"
    fatal="$(printf '%s\n' "$logs" | grep -Ec 'protocol state violation|egress rejected token|authentication failed|certificate fingerprint mismatch|unsupported protocol version' || true)"
    if (( fatal > 0 )); then
        printf '%s\n' "$logs" | tail -n 80
        fail "Authentication or protocol validation failed."
        return 1
    fi

    established="$(printf '%s\n' "$logs" | grep -c 'tunnel session established' || true)"
    h2_established="$(printf '%s\n' "$logs" | grep -c 'tunnel session established.*via h2' || true)"
    live="$(printf '%s\n' "$logs" | sed -nE '/\[stats\]/s/.*sessions=([0-9]+).*/\1/p' | tail -n1)"
    [[ -n "$live" ]] || live=0

    if [[ "${mux_mode:-on}" == off ]]; then
        if (( established < 1 )); then
            printf '%s\n' "$logs" | tail -n 80
            fail "No authenticated dedicated session was observed. Check the reported TLS/ECH/HTTP/authentication stage."
            return 1
        fi
        pass "MUX OFF: a dedicated tunnel session authenticated in this invocation. Idle sessions may correctly return to zero."
        warn "Use a real Xray client to test payload transfer and the independent Iran client-entry protocol."
        return 0
    fi
    if (( live < 1 )); then
        printf '%s\n' "$logs" | tail -n 80
        fail "No reverse session remained alive at the end of validation."
        return 1
    fi
    if [[ "${transport:-auto}" == xhttp ]]; then
        pass "XHTTP session observed; live-CDN interoperability still requires a real payload test."
    elif [[ "${transport:-auto}" == wss ]]; then
        pass "Normal WSS session observed."
    elif (( h2_established < 1 )); then
        warn "No HTTP/2 session was established in this invocation. Auto transport is running with WSS fallback; HTTP/2 is not validated."
    else
        pass "$h2_established HTTP/2 session event(s) observed in this invocation (not an end-to-end traffic test)."
    fi
    pass "$live of $expected_sessions minimum session(s) live at the end of the soak test."
    warn "Only transport session health is validated. Test a real Xray client before switching production traffic."
    if (( live < expected_sessions )); then
        warn "The adaptive pool has not reached its minimum yet; monitor it with: ununknowntunctl health"
    fi
    if (( established > expected_sessions )); then
        warn "$established connection event(s) were observed; the path reconnected during validation."
    fi
}

random_hex() {
    local bytes="$1"
    if command -v openssl >/dev/null 2>&1; then
        openssl rand -hex "$bytes"
    else
        od -An -N "$bytes" -tx1 /dev/urandom | tr -d ' \n'
    fi
}

pair_id_from_token() {
    printf '%s' "$1" | sha256sum | awk '{print substr($1,1,16)}'
}

random_u8() {
    od -An -N 1 -tu1 /dev/urandom | tr -d ' \n'
}

random_ws_path() {
    local path="" segment_count segment_bytes i
    segment_count=$((2 + $(random_u8) % 3))
    for ((i = 0; i < segment_count; i++)); do
        segment_bytes=$((4 + $(random_u8) % 11))
        path+="/$(random_hex "$segment_bytes")"
    done
    printf '%s' "$path"
}

backup_file() {
    local file="$1"
    if [[ -e "$file" || -L "$file" ]]; then
        cp -a "$file" "$file.backup-$(date -u +%Y%m%dT%H%M%SZ)"
    fi
}

backup_existing_install() {
    local stamp backup_dir
    stamp="$(date -u +%Y%m%dT%H%M%SZ)"
    backup_dir="$INSTALL_DIR/backups/$stamp"
    install -d -o root -g root -m 0700 "$backup_dir"
    if [[ -d "$CONFIG_DIR" ]]; then
        cp -a "$CONFIG_DIR" "$backup_dir/config"
    fi
    if [[ -f "$BIN_PATH" ]]; then
        cp -a "$BIN_PATH" "$backup_dir/ununknowntun"
    fi
    if [[ -f "$UNIT_PATH" ]]; then
        cp -a "$UNIT_PATH" "$backup_dir/ununknowntun.service"
    fi
    printf '%s\n' "$backup_dir" > "$INSTALL_DIR/latest-backup"
    chmod 0600 "$INSTALL_DIR/latest-backup"
    info "Existing installation backup: $backup_dir"
}

extract_embedded_binary() {
    local arch="$1" output="$2" begin end expected
    case "$arch" in
        amd64)
            begin="__UNUNKNOWNTUN_AMD64_BEGIN__"
            end="__UNUNKNOWNTUN_AMD64_END__"
            expected="$AMD64_SHA256"
            ;;
        arm64)
            begin="__UNUNKNOWNTUN_ARM64_BEGIN__"
            end="__UNUNKNOWNTUN_ARM64_END__"
            expected="$ARM64_SHA256"
            ;;
        *) return 1 ;;
    esac
    sed -n "/^${begin}$/,/^${end}$/p" "$SCRIPT_PATH" | sed '1d;$d' | base64 -d > "$output" || return 1
    [[ -s "$output" ]] || return 1
    local got
    got="$(sha256sum "$output" | awk '{print $1}')"
    [[ "$got" == "$expected" ]] || return 1
    chmod 0755 "$output"
}

copy_binary_from_foreign() {
    local arch="$1" output="$2" ssh_host ssh_port ssh_user
    warn "The embedded binary could not be extracted; fallback transfer from the foreign server is enabled."
    ask ssh_host "Foreign server SSH IP address or hostname"
    ask_valid ssh_port "Foreign server SSH port" "22" valid_port "Invalid SSH port."
    ask ssh_user "Foreign server SSH user" "root"
    command -v scp >/dev/null 2>&1 || die "scp is not installed. Copy the installer from the foreign server to Iran and run it again."
    scp -P "$ssh_port" "$ssh_user@$ssh_host:$INSTALL_DIR/share/ununknowntun-linux-$arch" "$output"
    chmod 0755 "$output"
}

install_binary() {
    local role="$1" machine arch temp expected got
    machine="$(uname -m)"
    case "$machine" in
        x86_64|amd64) arch="amd64" ;;
        aarch64|arm64) arch="arm64" ;;
        *) die "Unsupported architecture: $machine. amd64 or arm64 is required." ;;
    esac
    # Same filesystem as the destination: verified rename is atomic, including
    # upgrades while the old executable is still mapped by a running service.
    temp="$(mktemp "$(dirname "$BIN_PATH")/.ununknowntun-new.XXXXXXXX")"
    if ! extract_embedded_binary "$arch" "$temp"; then
        [[ "$role" == "origin" ]] || die "The embedded binary is invalid. Download the installer package again."
        copy_binary_from_foreign "$arch" "$temp"
    fi
    case "$arch" in amd64) expected="$AMD64_SHA256" ;; arm64) expected="$ARM64_SHA256" ;; esac
    got="$(sha256sum "$temp" | awk '{print $1}')"
    [[ "$got" == "$expected" ]] || { rm -f -- "$temp"; die "Replacement binary checksum is incorrect."; }
    "$temp" -version | grep -F "$VERSION" >/dev/null || { rm -f -- "$temp"; die "Replacement binary version is incorrect."; }
    chown root:root "$temp"
    chmod 0755 "$temp"
    mv -f -- "$temp" "$BIN_PATH"
    info "UNUNKNOWNTUN $VERSION for $arch was installed. Go is not required on the server."
}

ensure_service_user() {
    if ! id -u ununknowntun >/dev/null 2>&1; then
        useradd --system --home-dir /var/lib/ununknowntun --create-home --shell /usr/sbin/nologin ununknowntun
    fi
    install -d -o root -g root -m 0755 "$BASE_CONFIG_DIR" "$TUNNELS_DIR"
    install -d -o root -g ununknowntun -m 0750 "$CONFIG_DIR"
    install -d -o root -g root -m 0755 "$INSTALL_DIR" "$INSTALL_DIR/share"
    install -d -o ununknowntun -g ununknowntun -m 0750 /var/lib/ununknowntun "$TUNNEL_STATE_DIR"
}

install_service_unit() {
    backup_file "$UNIT_PATH"
    cat > "$UNIT_PATH" <<'UNIT'
[Unit]
Description=UNUNKNOWNTUN V3 reverse tunnel instance %i
Wants=network-online.target
After=network-online.target
StartLimitIntervalSec=60
StartLimitBurst=10

[Service]
Type=simple
User=ununknowntun
Group=ununknowntun
ExecStart=/etc/ununknowntun/tunnels/%i/run.sh
Restart=always
RestartSec=2
TimeoutStopSec=20
KillSignal=SIGTERM
LimitNOFILE=1048576
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
NoNewPrivileges=true
PrivateTmp=true
PrivateDevices=true
ProtectSystem=strict
ReadWritePaths=/var/lib/ununknowntun/%i
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
RestrictSUIDSGID=true
LockPersonality=true
RestrictAddressFamilies=AF_INET AF_INET6

[Install]
WantedBy=multi-user.target
UNIT
    systemctl daemon-reload
}

migrate_legacy_install_if_needed() {
    [[ -f "$BASE_CONFIG_DIR/run.sh" ]] || return 0
    [[ -f "$TUNNELS_DIR/legacy/deployment.env" ]] && return 0
    yes_no "A legacy single-tunnel installation was found. Import it as tunnel 'legacy' now?" y ||
        die "Migration is required before adding independent tunnel instances."

    local backup="$INSTALL_DIR/backups/legacy-migration-$(date -u +%Y%m%dT%H%M%SZ)" file role ports="" old_active old_enabled
    old_active="$(systemctl is-active ununknowntun.service 2>/dev/null || true)"
    old_enabled="$(systemctl is-enabled ununknowntun.service 2>/dev/null || true)"
    install -d -m 0700 "$backup" "$TUNNELS_DIR/legacy"
    cp -a "$BASE_CONFIG_DIR/run.sh" "$backup/"
    [[ ! -f "$BASE_CONFIG_DIR/token" ]] || cp -a "$BASE_CONFIG_DIR/token" "$backup/"
    [[ ! -f "$BASE_CONFIG_DIR/deployment.env" ]] || cp -a "$BASE_CONFIG_DIR/deployment.env" "$backup/"
    [[ ! -f "$BASE_CONFIG_DIR/peer.env" ]] || cp -a "$BASE_CONFIG_DIR/peer.env" "$backup/"
    [[ ! -f "$BASE_CONFIG_DIR/client-info.txt" ]] || cp -a "$BASE_CONFIG_DIR/client-info.txt" "$backup/"
    [[ ! -f /etc/systemd/system/ununknowntun.service ]] || cp -a /etc/systemd/system/ununknowntun.service "$backup/"

    for file in run.sh token deployment.env peer.env client-info.txt ca-bundle.pem; do
        [[ ! -f "$BASE_CONFIG_DIR/$file" ]] || cp -a "$BASE_CONFIG_DIR/$file" "$TUNNELS_DIR/legacy/$file"
    done
    sed -i.bak "s|$BASE_CONFIG_DIR/token|$TUNNELS_DIR/legacy/token|g; s|$BASE_CONFIG_DIR/ca-bundle.pem|$TUNNELS_DIR/legacy/ca-bundle.pem|g" "$TUNNELS_DIR/legacy/run.sh"
    role="$(sed -nE 's/^[[:space:]]*-mode[[:space:]]+(origin|egress).*/\1/p' "$TUNNELS_DIR/legacy/run.sh" | head -n1)"
    [[ -n "$role" ]] || role=unknown
    if [[ ! -f "$TUNNELS_DIR/legacy/deployment.env" ]]; then
        printf 'ROLE=%s\n' "$role" > "$TUNNELS_DIR/legacy/deployment.env"
    fi
    grep -q '^TUNNEL_ID=' "$TUNNELS_DIR/legacy/deployment.env" || printf 'TUNNEL_ID=legacy\n' >> "$TUNNELS_DIR/legacy/deployment.env"
    grep -q '^TUNNEL_NAME=' "$TUNNELS_DIR/legacy/deployment.env" || printf 'TUNNEL_NAME=%q\n' "Migrated legacy tunnel" >> "$TUNNELS_DIR/legacy/deployment.env"
    grep -q '^FOREIGN_PROXY_PROVIDER=' "$TUNNELS_DIR/legacy/deployment.env" || printf 'FOREIGN_PROXY_PROVIDER=none\n' >> "$TUNNELS_DIR/legacy/deployment.env"
    grep -q '^IRAN_PROXY_PROVIDER=' "$TUNNELS_DIR/legacy/deployment.env" || printf 'IRAN_PROXY_PROVIDER=none\n' >> "$TUNNELS_DIR/legacy/deployment.env"
    grep -q '^IRAN_IP=' "$TUNNELS_DIR/legacy/deployment.env" || printf 'IRAN_IP=\n' >> "$TUNNELS_DIR/legacy/deployment.env"
    grep -q '^NGINX_SITE=' "$TUNNELS_DIR/legacy/deployment.env" || printf 'NGINX_SITE=\n' >> "$TUNNELS_DIR/legacy/deployment.env"
    ports="$(sed -nE 's/^(FOREIGN_PORTS|LOCAL_PORTS)=//p' "$TUNNELS_DIR/legacy/deployment.env" 2>/dev/null | tr ',' '\n' | sort -nu || true)"
    printf '%s\n' "$ports" | sed '/^$/d' > "$TUNNELS_DIR/legacy/ports.list"
    chown -R root:ununknowntun "$TUNNELS_DIR/legacy" 2>/dev/null || true
    chmod 0750 "$TUNNELS_DIR/legacy" "$TUNNELS_DIR/legacy/run.sh"
    [[ ! -f "$TUNNELS_DIR/legacy/token" ]] || chmod 0640 "$TUNNELS_DIR/legacy/token"

    CURRENT_TUNNEL_ID=legacy
    CURRENT_TUNNEL_NAME="Migrated legacy tunnel"
    CONFIG_DIR="$TUNNELS_DIR/legacy"
    TUNNEL_STATE_DIR=/var/lib/ununknowntun/legacy
    SERVICE=ununknowntun@legacy
    ensure_service_user
    chown -R root:ununknowntun "$TUNNELS_DIR/legacy"
    install_service_unit
    install_manager
    systemctl disable --now ununknowntun.service >/dev/null 2>&1 || true
    if ! systemctl enable --now ununknowntun@legacy || ! systemctl is-active --quiet ununknowntun@legacy; then
        systemctl disable --now ununknowntun@legacy >/dev/null 2>&1 || true
        restore_enabled_state ununknowntun.service "$old_enabled"
        if [[ "$old_active" == active ]]; then systemctl start ununknowntun.service || true; fi
        mv -- "$TUNNELS_DIR/legacy" "$backup/failed-legacy"
        die "Legacy migration failed; the previous service was restored. Backup: $backup"
    fi
    info "Legacy tunnel imported as 'legacy'. Backup: $backup"
    CURRENT_TUNNEL_ID=""; CURRENT_TUNNEL_NAME=""; CONFIG_DIR="$BASE_CONFIG_DIR"; TUNNEL_STATE_DIR=""; SERVICE=ununknowntun
}

install_manager() {
    cat > "$CTL_PATH" <<'CTL'
#!/usr/bin/env bash
set -Eeuo pipefail
BASE_CONFIG_DIR="/etc/ununknowntun"
TUNNELS_DIR="$BASE_CONFIG_DIR/tunnels"
INSTALL_DIR="/opt/ununknowntun"

need_root() {
    [[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "This command must be run as root." >&2; exit 1; }
}

valid_id() {
    [[ "$1" =~ ^[a-z0-9][a-z0-9-]{0,47}$ && "$1" != *--* ]]
}

list_tunnels() {
    local directory id name role foreign_proxy iran_proxy state
    printf '%-18s %-24s %-9s %-12s %-12s %-10s\n' ID NAME ROLE FOREIGN_PROXY IRAN_PROXY SERVICE
    [[ -d "$TUNNELS_DIR" ]] || return 0
    for directory in "$TUNNELS_DIR"/*; do
        [[ -f "$directory/deployment.env" ]] || continue
        # Files are generated root-only by the installer.
        # shellcheck disable=SC1090
        . "$directory/deployment.env"
        id="${directory##*/}"
        name="${TUNNEL_NAME:-$id}"
        role="${ROLE:-unknown}"
        foreign_proxy="${FOREIGN_PROXY_PROVIDER:-none}"
        iran_proxy="${IRAN_PROXY_PROVIDER:-none}"
        state="$(systemctl is-active "ununknowntun@$id" 2>/dev/null || true)"
        printf '%-18s %-24.24s %-9s %-12s %-12s %-10s\n' "$id" "$name" "$role" "$foreign_proxy" "$iran_proxy" "${state:-unknown}"
    done
}

select_id() {
    local supplied="${1:-}" directory count=0 only="" answer
    if [[ -n "$supplied" ]]; then
        valid_id "$supplied" && [[ -f "$TUNNELS_DIR/$supplied/deployment.env" ]] || {
            echo "Tunnel '$supplied' was not found." >&2; exit 1;
        }
        printf '%s' "$supplied"
        return
    fi
    for directory in "$TUNNELS_DIR"/*; do
        [[ -f "$directory/deployment.env" ]] || continue
        count=$((count + 1)); only="${directory##*/}"
    done
    (( count > 0 )) || { echo "No tunnels are registered." >&2; exit 1; }
    if (( count == 1 )); then
        printf '%s' "$only"
        return
    fi
    list_tunnels >&2
    while true; do
        read -r -p "Tunnel ID (q cancels): " answer || return 1
        [[ "$answer" != q && "$answer" != cancel ]] || return 1
        if valid_id "$answer" && [[ -f "$TUNNELS_DIR/$answer/deployment.env" ]]; then
            printf '%s' "$answer"
            return 0
        fi
        echo "Tunnel '$answer' was not found; choose one of the listed IDs." >&2
    done
}

show_health() {
    local id="$1" service="ununknowntun@$1" config="$TUNNELS_DIR/$1"
    echo "===== UNUNKNOWNTUN HEALTH: $id ====="
    printf 'service: '
    systemctl is-active "$service" 2>/dev/null || true
    systemctl show "$service" -p MainPID -p NRestarts -p ActiveEnterTimestamp --no-pager 2>/dev/null || true
    local pid invocation
    pid="$(systemctl show "$service" -p MainPID --value 2>/dev/null || true)"
    if [[ "$pid" =~ ^[1-9][0-9]*$ ]]; then
        ps -p "$pid" -o pid,%cpu,%mem,rss,etime,cmd --no-headers 2>/dev/null || true
    fi
    invocation="$(systemctl show "$service" -p InvocationID --value 2>/dev/null || true)"
    if [[ "$invocation" =~ ^[0-9a-fA-F]{32}$ ]]; then
        echo "latest stats (current invocation only):"
        journalctl "_SYSTEMD_INVOCATION_ID=$invocation" --no-pager 2>/dev/null | grep -F '[stats]' | tail -n 3 || true
        echo "latest detector/rate events (current invocation only):"
        journalctl "_SYSTEMD_INVOCATION_ID=$invocation" --no-pager 2>/dev/null | grep -E '\[drop-detector\]|\[adaptive-rate\]' | tail -n 5 || true
    else
        echo "No active invocation; previous logs are not health evidence."
    fi
    echo "declared ports:"
    cat "$config/ports.list" 2>/dev/null || true
    echo "process listeners:"
    [[ ! "$pid" =~ ^[1-9][0-9]*$ ]] || ss -lntp 2>/dev/null | grep -F "pid=$pid," || true
}

valid_public_ipv4() {
    local value="$1" first second octet old_ifs="$IFS"; local -a parts
    [[ "$value" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || return 1
    IFS='.' read -ra parts <<< "$value"; IFS="$old_ifs"
    [[ ${#parts[@]} -eq 4 ]] || return 1
    for octet in "${parts[@]}"; do [[ "$octet" =~ ^(0|[1-9][0-9]{0,2})$ ]] && ((10#$octet <= 255)) || return 1; done
    first=$((10#${parts[0]})); second=$((10#${parts[1]}))
    (( first >= 1 && first <= 223 )) || return 1
    case "$value" in 10.*|127.*|169.254.*|192.168.*) return 1;; esac
    (( first == 172 && second >= 16 && second <= 31 )) && return 1
    (( first == 100 && second >= 64 && second <= 127 )) && return 1
    return 0
}

valid_port() {
    [[ "$1" =~ ^[0-9]{1,5}$ ]] && ((10#$1 >= 1 && 10#$1 <= 65535))
}

normalize_ports() {
    local input="$1" item output="" seen="," old_ifs="$IFS"; local -a parts
    IFS=',' read -ra parts <<< "$input"; IFS="$old_ifs"
    for item in "${parts[@]}"; do
        item="${item//[[:space:]]/}"
        valid_port "$item" || return 1
        item="$((10#$item))"
        [[ "$seen" != *",$item,"* ]] || return 1
        output+="${output:+,}$item"; seen+="$item,"
    done
    [[ -n "$output" ]] || return 1
    printf '%s' "$output"
}

replace_env_value() {
    local file="$1" key="$2" value="$3" temp
    temp="$(mktemp "${file}.XXXXXX")"
    awk -v key="$key" -v value="$value" 'BEGIN{done=0} index($0,key "=")==1 {print key "=" value; done=1; next} {print} END{if(!done) print key "=" value}' "$file" > "$temp"
    chmod --reference="$file" "$temp" 2>/dev/null || chmod 0640 "$temp"
    chown --reference="$file" "$temp" 2>/dev/null || true
    mv -f "$temp" "$file"
}

replace_run_flag() {
    local file="$1" flag="$2" value="$3" temp line found=0
    temp="$(mktemp "${file}.XXXXXX")"
    while IFS= read -r line || [[ -n "$line" ]]; do
        if [[ "$line" == "  -$flag "* ]]; then
            printf '  -%s %s \\\n' "$flag" "$value" >> "$temp"
            found=1
        else
            printf '%s\n' "$line" >> "$temp"
        fi
    done < "$file"
    (( found == 1 )) || { rm -f "$temp"; echo "Launch flag -$flag was not found." >&2; return 1; }
    chmod --reference="$file" "$temp" 2>/dev/null || chmod 0750 "$temp"
    chown --reference="$file" "$temp" 2>/dev/null || true
    mv -f "$temp" "$file"
}

emit_update_code() {
    local id="$1" field="$2" previous="$3" config="$TUNNELS_DIR/$1" value
    # shellcheck disable=SC1090
    . "$config/deployment.env"
    case "$field" in IRAN_IP|FOREIGN_IP|FOREIGN_PORTS) value="${!field}";; *) return 1;; esac
    printf 'FORMAT=UNUNKNOWNTUN_UPDATE_V2\nPAIR_ID=%s\nFIELD=%s\nPREVIOUS=%s\nVALUE=%s\n' \
        "${PAIR_ID:-}" "$field" "$previous" "$value" | base64 | tr -d '\n'
    echo
}

refresh_peer_env() {
    local config="$1"
    [[ -f "$config/peer.env" ]] || return 0
    . "$config/deployment.env"
    replace_env_value "$config/peer.env" FOREIGN_IP "$FOREIGN_IP" || return
    replace_env_value "$config/peer.env" PORTS "$FOREIGN_PORTS" || return
    chmod 0600 "$config/peer.env"
}

refresh_client_info() {
    local config="$1" temp address entry
    [[ -f "$config/client-info.txt" ]] || return 0
    . "$config/deployment.env"
    address="${IRAN_IP:-}"; entry="${IRAN_ENTRY_PORTS:-${LOCAL_PORTS:-}}"
    [[ "${IRAN_PROXY_PROVIDER:-none}" == none ]] || address="${IRAN_ENTRY_DOMAIN:-}"
    temp="$(mktemp "$config/client-info.txt.XXXXXX")" || return
    awk -v ip="${FOREIGN_IP:-}" -v ports="${FOREIGN_PORTS:-}" -v domain="${FOREIGN_DOMAIN:-}" \
        -v local_ports="${LOCAL_PORTS:-}" -v address="$address" -v entry="$entry" '
        /^Direct foreign IP:/ {print "Direct foreign IP: " ip; next}
        /^Public HTTPS ports:/ {print "Public HTTPS ports: " ports; next}
        /^Foreign HTTP\/2\/WSS:/ {print "Foreign HTTP/2/WSS: " domain " ports " ports; next}
        /^Iran internal listeners:/ {print "Iran internal listeners: " local_ports; next}
        /^Iran client address:/ {print "Iran client address: " address; next}
        /^  Address   =/ {print "  Address   = " address; next}
        /^  Port      =.*\(or one of:/ {split(entry, p, ","); print "  Port      = " p[1] "   (or one of: " entry ")"; next}
        {print}
    ' "$config/client-info.txt" > "$temp" || return
    chmod 0640 "$temp" || return
    chown --reference="$config/client-info.txt" "$temp" 2>/dev/null || true
    mv -f "$temp" "$config/client-info.txt"
}

manager_lock() {
    exec 9>/run/ununknowntun-installer.lock
    flock -n 9 || { echo "Another configuration operation is running; retry when it finishes." >&2; return 1; }
}

customer_command() {
    local action="$1" id="$2" selected="${3:-}"; local -a args
    args=("$INSTALL_DIR/share/access-manager.py" "$action" --config-dir "$TUNNELS_DIR/$id" --state-dir "/var/lib/ununknowntun/$id")
    [[ -z "$selected" ]] || args+=(--customer "$selected")
    [[ -z "${4:-}" ]] || args+=(--ports "$4")
    python3 "${args[@]}"
}

perform_metadata_change() {
    local id="$1" field="$2" value="$3" config="$TUNNELS_DIR/$1" old connects="" port host
    . "$config/deployment.env"
    old="${!field:-}"
    replace_env_value "$config/deployment.env" "$field" "$value" || return
    if [[ "$field" == FOREIGN_IP ]]; then FOREIGN_IP="$value"; fi
    if [[ "$field" == FOREIGN_PORTS ]]; then FOREIGN_PORTS="$value"; fi
    if [[ "${ROLE:-}" == origin && ( "$field" == FOREIGN_PORTS || ( "$field" == FOREIGN_IP && "${FOREIGN_PROXY_PROVIDER:-none}" == none ) ) ]]; then
        host="$FOREIGN_IP"
        [[ "${FOREIGN_PROXY_PROVIDER:-none}" == none ]] || host="$FOREIGN_DOMAIN"
        for port in ${FOREIGN_PORTS//,/ }; do connects+="${connects:+,}$host:$port"; done
        replace_run_flag "$config/run.sh" connect "$connects" || return
        systemctl restart "ununknowntun@$id" || return
        systemctl is-active --quiet "ununknowntun@$id" || return
    fi
    refresh_client_info "$config" || return
    refresh_peer_env "$config" || return
    rebuild_ports_file "$config"
}

apply_metadata_change() {
    local id="$1" field="$2" value="$3" config="$TUNNELS_DIR/$1" backup
    install -d -m 0700 "$INSTALL_DIR/backups" || return
    backup="$(mktemp -d "$INSTALL_DIR/backups/update-$id-XXXXXX")" || return
    cp -a "$config" "$backup/config" || return
    if ! perform_metadata_change "$id" "$field" "$value"; then
        if ! cp -a "$backup/config/." "$config/"; then
            echo "Automatic restore failed; do not restart with partial settings. Restore backup: $backup" >&2
            return 1
        fi
        systemctl restart "ununknowntun@$id" || echo "Previous configuration restored; service restart needs attention." >&2
        echo "Change failed; previous settings restored. Backup: $backup" >&2
        return 1
    fi
    echo "Recoverable backup: $backup"
}

find_config_by_pair() {
    local pair_id="$1" env_file registered
    for env_file in "$TUNNELS_DIR"/*/deployment.env; do
        [[ -f "$env_file" ]] || continue
        registered="$(sed -n 's/^PAIR_ID=//p' "$env_file" | head -n1)"
        if [[ -n "$registered" && "$registered" == "$pair_id" ]]; then
            printf '%s' "${env_file%/deployment.env}"
            return 0
        fi
    done
    return 1
}

edit_ip() {
    local id="$1" config="$TUNNELS_DIR/$1" choice new_ip old_ip field
    # shellcheck disable=SC1090
    . "$config/deployment.env"
    printf '1) Change Iran public IP\n2) Change foreign public IP\n'
    while true; do
        read -r -p "Select an option [1] (q cancels): " choice || return 1
        choice="${choice:-1}"
        case "$choice" in 1) field=IRAN_IP; break;; 2) field=FOREIGN_IP; break;; q|cancel) return 0;; *) echo "Choose 1 or 2." >&2;; esac
    done
    old_ip="${!field:-}"
    while true; do
        read -r -p "New public IPv4 (q cancels): " new_ip || return 1
        [[ "$new_ip" != q && "$new_ip" != cancel ]] || return 0
        valid_public_ipv4 "$new_ip" && break
        echo "Invalid public IPv4; enter the corrected address." >&2
    done
    apply_metadata_change "$id" "$field" "$new_ip" || return
    echo "Local metadata updated. Update DNS records before relying on the new address."
    echo "Paste this synchronization code on the paired server with: ununknowntunctl apply-update"
    emit_update_code "$id" "$field" "$old_ip"
}

apply_update() {
    local code temp key value pair_id="" format="" field="" previous="" changed="" config id seen="," current
    read -r -p "Synchronization code: " code || return 1; code="${code//[[:space:]]/}"
    [[ ${#code} -le 8192 ]] || { echo "Code is too long." >&2; return 1; }
    temp="$(mktemp)"; printf '%s' "$code" | base64 -d > "$temp" 2>/dev/null || { rm -f "$temp"; echo "Invalid code." >&2; return 1; }
    while IFS='=' read -r key value; do
        [[ "$seen" != *",$key,"* ]] || { rm -f "$temp"; echo "Duplicate code field." >&2; return 1; }; seen+="$key,"
        case "$key" in FORMAT) format="$value";; PAIR_ID) pair_id="$value";; FIELD) field="$value";; PREVIOUS) previous="$value";; VALUE) changed="$value";; *) rm -f "$temp"; echo "Unknown code field." >&2; return 1;; esac
    done < "$temp"; rm -f "$temp"
    [[ "$format" == UNUNKNOWNTUN_UPDATE_V2 && "$pair_id" =~ ^[a-f0-9]{16}$ && "$seen" == *",PREVIOUS,"* ]] || { echo "Generate a new single-change synchronization code with version 3.2 or later." >&2; return 1; }
    config="$(find_config_by_pair "$pair_id" || true)"
    [[ -n "$config" ]] || { echo "The matching paired tunnel was not found." >&2; return 1; }
    id="${config##*/}"
    case "$field" in
        IRAN_IP|FOREIGN_IP) valid_public_ipv4 "$changed" || { echo "Invalid IP in code." >&2; return 1; };;
        FOREIGN_PORTS) changed="$(normalize_ports "$changed")" || { echo "Invalid ports in code." >&2; return 1; };;
        *) echo "Invalid change field." >&2; return 1;;
    esac
    . "$config/deployment.env"
    current="${!field:-}"
    [[ "$current" == "$previous" || "$current" == "$changed" ]] || { echo "This field changed since the code was made; refusing a stale update." >&2; return 1; }
    [[ "$field" != FOREIGN_PORTS || "${ROLE:-}" == origin ]] || { echo "Foreign port changes must be made locally through edit-ports." >&2; return 1; }
    apply_metadata_change "$id" "$field" "$changed" || return
    echo "Tunnel '$id' synchronized. Verify DNS and run: ununknowntunctl test $id"
}

port_used_elsewhere() {
    local port="$1" excluded="$2" file owner
    for file in "$TUNNELS_DIR"/*/ports.list; do
        [[ -f "$file" ]] || continue
        owner="${file%/ports.list}"; owner="${owner##*/}"
        [[ "$owner" == "$excluded" ]] && continue
        grep -Fxq "$port" "$file" && return 0
    done
    return 1
}

rebuild_ports_file() {
    local config="$1" value port temp; local -a values
    # shellcheck disable=SC1090
    . "$config/deployment.env"
    temp="$(mktemp "$config/ports.list.XXXXXX")" || return
    if [[ "${ROLE:-}" == egress ]]; then
        values=("${FOREIGN_PORTS:-}" "${WSS_BACKEND_PORT:-}" "${H2_BACKEND_PORT:-}" "${TARGET_PORT:-}")
    else
        values=("${LOCAL_PORTS:-}" "${IRAN_ENTRY_PORTS:-}")
    fi
    for value in "${values[@]}"; do
        for port in ${value//,/ }; do valid_port "$port" && printf '%s\n' "$port" >> "$temp"; done
    done
    if [[ -f "$config/access.json" ]]; then
        python3 - "$config/access.json" >> "$temp" <<'PY'
import json, sys
with open(sys.argv[1]) as stream:
    for account in json.load(stream)["accounts"]:
        for address in account["listen"].split(","):
            print(int(address.rsplit(":", 1)[1]))
PY
        [[ $? -eq 0 ]] || { rm -f "$temp"; return 1; }
    fi
    sort -nu -o "$temp" "$temp" || return
    chmod 0640 "$temp"
    [[ ! -f "$config/ports.list" ]] || chown --reference="$config/ports.list" "$temp" 2>/dev/null || true
    mv -f "$temp" "$config/ports.list"
}

prompt_managed_ports() {
    local label="$1" old="$2" provider="$3" mode="$4" id="$5" answer ports port bad
    while true; do
        read -r -p "$label [$old] (q cancels): " answer || return 1
        [[ "$answer" != q && "$answer" != cancel ]] || return 1
        ports="$(normalize_ports "${answer:-$old}")" || { echo "Enter unique ports from 1 to 65535, separated by commas." >&2; continue; }
        bad=0
        for port in ${ports//,/ }; do
            if [[ "$mode" == https ]]; then
                if [[ "$port" == 80 || "$port" == "${WSS_BACKEND_PORT:-}" || "$port" == "${H2_BACKEND_PORT:-}" || "$port" == "${TARGET_PORT:-}" ]]; then
                    echo "Port $port is reserved for ACME or a private backend." >&2; bad=1; break
                fi
                if [[ "$provider" =~ ^(arvan|fastly)$ && "$port" != 443 ]]; then echo "The Arvan/Fastly HTTPS compatibility profile uses port 443." >&2; bad=1; break; fi
                if [[ "$provider" == cloudflare && ",443,2053,2083,2087,2096,8443," != *",$port,"* ]]; then echo "Port $port is not a supported Cloudflare HTTPS port." >&2; bad=1; break; fi
            elif [[ ",$old," != *",$port,"* ]]; then
                if port_used_elsewhere "$port" "$id"; then echo "Port $port belongs to another tunnel." >&2; bad=1; break; fi
                if ss -H -ltn "sport = :$port" 2>/dev/null | grep -q .; then echo "Port $port is already listening." >&2; bad=1; break; fi
            fi
        done
        (( bad == 0 )) || continue
        printf '%s' "$ports"
        return 0
    done
}

open_managed_ports() {
    local config="$1" ports="$2" port result
    command -v ufw >/dev/null 2>&1 || return 0
    ufw status 2>/dev/null | head -n1 | grep -q 'Status: active' || return 0
    for port in ${ports//,/ }; do
        result="$(LC_ALL=C ufw allow proto tcp from 0.0.0.0/0 to 0.0.0.0/0 port "$port")"
        if [[ "$result" == *"Rule added"* || "$result" == *"Rules updated"* ]]; then
            printf '%s\n' "$port" >> "$config/firewall-owned.ports"
        fi
    done
    [[ ! -f "$config/firewall-owned.ports" ]] || sort -nu -o "$config/firewall-owned.ports" "$config/firewall-owned.ports"
}

replace_nginx_ssl_ports() {
    local site="$1" ports="$2" temp line inserted=0 port backup
    [[ "$site" == /etc/nginx/sites-available/ununknowntun-*.conf && -f "$site" ]] || { echo "Managed Nginx site was not found." >&2; return 1; }
    backup="${site}.ports-backup-$(date -u +%Y%m%dT%H%M%SZ)"
    cp -a "$site" "$backup"
    temp="$(mktemp "${site}.XXXXXX")"
    while IFS= read -r line || [[ -n "$line" ]]; do
        if [[ "$line" =~ ^[[:space:]]*listen[[:space:]][0-9]+[[:space:]]+ssl[[:space:]]+http2\;[[:space:]]*$ ]]; then
            if (( inserted == 0 )); then
                for port in ${ports//,/ }; do printf '    listen %s ssl http2;\n' "$port" >> "$temp"; done
                inserted=1
            fi
            continue
        fi
        printf '%s\n' "$line" >> "$temp"
    done < "$site"
    (( inserted == 1 )) || { rm -f "$temp"; echo "No managed SSL listeners were found." >&2; return 1; }
    chmod --reference="$site" "$temp" 2>/dev/null || chmod 0644 "$temp"
    chown --reference="$site" "$temp" 2>/dev/null || true
    mv -f "$temp" "$site"
    if ! nginx -t; then
        cp -a "$backup" "$site"
        echo "Nginx rejected the new ports; previous configuration restored." >&2
        return 1
    fi
    if ! systemctl reload nginx; then
        cp -a "$backup" "$site"
        systemctl reload nginx || true
        echo "Nginx reload failed; previous listener configuration restored." >&2
        return 1
    fi
}

edit_ports() {
    local id="$1" config="$TUNNELS_DIR/$1" choice new_ports old_ports listens="" port site backup supplied="${2:-}"
    # shellcheck disable=SC1090
    . "$config/deployment.env"
    if [[ "${ROLE:-}" == origin && "${IRAN_PROXY_PROVIDER:-none}" == none && -f "$config/access.json" ]]; then
        # The helper owns the configuration lock and keeps every listener metered.
        customer_command ports "$id" default "$supplied"
        return
    fi
    manager_lock || return
    backup="$INSTALL_DIR/backups/ports-$id-$(date -u +%Y%m%dT%H%M%SZ)"
    install -d -m 0700 "$backup"
    cp -a "$config" "$backup/config"
    if [[ "${ROLE:-}" == egress ]]; then
        old_ports="${FOREIGN_PORTS:-}"
        new_ports="$(prompt_managed_ports 'New foreign HTTPS ports' "$old_ports" "${FOREIGN_PROXY_PROVIDER:-none}" https "$id")" || return
        site="${NGINX_SITE:-}"
        replace_nginx_ssl_ports "$site" "$new_ports"
        replace_env_value "$config/deployment.env" FOREIGN_PORTS "$new_ports"
        open_managed_ports "$config" "$new_ports"
        rebuild_ports_file "$config"
        refresh_client_info "$config"
        echo "Foreign ports updated. Apply this code on the paired Iran server:"
        refresh_peer_env "$config"
        emit_update_code "$id" FOREIGN_PORTS "$old_ports"
        echo "Recoverable backup: $backup"
        return
    fi
    if [[ "${IRAN_PROXY_PROVIDER:-none}" == none ]]; then
        old_ports="${LOCAL_PORTS:-}"
        new_ports="$(prompt_managed_ports 'New Iran client entry ports' "$old_ports" none direct "$id")" || return
        for port in ${new_ports//,/ }; do
            if [[ ",$old_ports," != *",$port,"* ]]; then
                port_used_elsewhere "$port" "$id" && { echo "Port $port belongs to another tunnel." >&2; exit 1; }
                ss -H -ltn "sport = :$port" 2>/dev/null | grep -q . && { echo "Port $port is already listening." >&2; exit 1; }
            fi
            listens+="${listens:+,}0.0.0.0:$port"
        done
        replace_run_flag "$config/run.sh" listen "$listens"
        replace_env_value "$config/deployment.env" LOCAL_PORTS "$new_ports"
        replace_env_value "$config/deployment.env" IRAN_ENTRY_PORTS "$new_ports"
        open_managed_ports "$config" "$new_ports"
        rebuild_ports_file "$config"
        if ! systemctl restart "ununknowntun@$id" || ! systemctl is-active --quiet "ununknowntun@$id"; then
            cp -a "$backup/config/." "$config/"
            systemctl restart "ununknowntun@$id" || true
            echo "New ports failed; previous configuration restored." >&2
            exit 1
        fi
    else
        old_ports="${IRAN_ENTRY_PORTS:-}"
        new_ports="$(prompt_managed_ports 'New public Iran proxy HTTPS ports' "$old_ports" "${IRAN_PROXY_PROVIDER:-none}" https "$id")" || return
        site="${NGINX_SITE:-}"
        replace_nginx_ssl_ports "$site" "$new_ports"
        replace_env_value "$config/deployment.env" IRAN_ENTRY_PORTS "$new_ports"
        open_managed_ports "$config" "$new_ports"
        rebuild_ports_file "$config"
    fi
    refresh_peer_env "$config"
    refresh_client_info "$config"
    echo "Tunnel '$id' ports updated. Recoverable backup: $backup"
}

site_referenced_elsewhere() {
    local site="$1" excluded="$2" file registered
    for file in "$TUNNELS_DIR"/*/deployment.env; do
        [[ -f "$file" && "$file" != "$TUNNELS_DIR/$excluded/deployment.env" ]] || continue
        registered="$(unset NGINX_SITE; . "$file" || exit 2; printf '%s' "${NGINX_SITE:-}")" || return 2
        [[ "$registered" != "$site" ]] || return 0
    done
    return 1
}

perform_delete_steps() {
    # The variables below are local to delete_tunnel's isolated transaction.
    if [[ "$cdn_present" == 1 ]]; then
        cdn_touched=1
        python3 "$INSTALL_DIR/share/cdn-control.py" unschedule --config-dir "$config" --initial-lock-fd 9 || return
    fi
    stop_attempted=1
    systemctl stop "ununknowntun@$id" || return
    if systemctl is-active --quiet "ununknowntun@$id"; then
        echo "The service is still active; removal refused." >&2
        return 1
    fi
    systemctl disable "ununknowntun@$id" || return
    if [[ "$remove_site" == 1 ]]; then
        site_changed=1
        if [[ -e "$site_link" || -L "$site_link" ]]; then mv "$site_link" "$backup/nginx-enabled/" || return; fi
        if [[ -e "$site" || -L "$site" ]]; then mv "$site" "$backup/nginx-available/" || return; fi
        nginx -t || return
        systemctl reload nginx || return
    fi
    mv "$config" "$backup/removed-config" || return
    if [[ -d "$state_dir" ]]; then mv "$state_dir" "$backup/state" || return; fi
}

restore_deleted_tunnel() {
    local failed=0
    if [[ -d "$backup/removed-config" || ! -d "$config" ]]; then
        install -d -m 0750 "$config" && cp -a "$backup/config/." "$config/" || failed=1
    fi
    if [[ -d "$backup/state" ]]; then
        if [[ -d "$state_dir" ]]; then cp -a "$backup/state/." "$state_dir/" || failed=1
        else cp -a "$backup/state" "$state_dir" || failed=1; fi
    fi
    if [[ "$site_changed" == 1 ]]; then
        if [[ -e "$backup/nginx-available/${site##*/}" || -L "$backup/nginx-available/${site##*/}" ]]; then
            mv "$backup/nginx-available/${site##*/}" "$site" || failed=1
        fi
        if [[ -e "$backup/nginx-enabled/${site_link##*/}" || -L "$backup/nginx-enabled/${site_link##*/}" ]]; then
            mv "$backup/nginx-enabled/${site_link##*/}" "$site_link" || failed=1
        fi
        nginx -t && systemctl reload nginx || failed=1
    fi
    if [[ "$stop_attempted" == 1 ]]; then
        case "$was_enabled" in
            enabled) systemctl enable "ununknowntun@$id" || failed=1;;
            enabled-runtime) systemctl enable --runtime "ununknowntun@$id" || failed=1;;
            disabled) systemctl disable "ununknowntun@$id" || failed=1;;
        esac
        if [[ "$was_active" == 1 ]]; then
            if [[ "$failed" == 0 ]]; then systemctl start "ununknowntun@$id" || failed=1; fi
        else
            systemctl stop "ununknowntun@$id" || failed=1
        fi
    fi
    if [[ "${cdn_touched:-0}" == 1 && "$failed" == 0 ]]; then
        case "$cdn_was_enabled" in
            enabled) systemctl enable "ununknowntun-cdn-$id.timer" || failed=1 ;;
            enabled-runtime) systemctl enable --runtime "ununknowntun-cdn-$id.timer" || failed=1 ;;
            *) systemctl disable "ununknowntun-cdn-$id.timer" || failed=1 ;;
        esac
        if [[ "$cdn_was_active" == 1 ]]; then systemctl start "ununknowntun-cdn-$id.timer" || failed=1
        else systemctl stop "ununknowntun-cdn-$id.timer" || failed=1; fi
    fi
    if [[ "$failed" != 0 ]]; then
        echo "Recovery needs attention; retained backup: $backup" >&2
    else
        echo "Removal cancelled; configuration and previous service state restored. Backup: $backup" >&2
    fi
    return "$failed"
}

delete_tunnel() {
    (
        local id="$1" config="$TUNNELS_DIR/$1" confirm backup site site_link state_dir="/var/lib/ununknowntun/$1"
        local was_active=0 was_enabled remove_site=0 site_changed=0 stop_attempted=0 shared_status
        local cdn_present=0 cdn_touched=0 cdn_was_enabled=disabled cdn_was_active=0
        . "$config/deployment.env"
        echo "This removes only tunnel '$id'. Shared binaries, Nginx, and other tunnels remain."
        read -r -p "Type the tunnel ID to confirm: " confirm || return 1
        [[ "$confirm" == "$id" ]] || { echo "Cancelled."; return 0; }
        if [[ -e "/etc/systemd/system/ununknowntun-cdn-$id.timer" ]]; then
            [[ ! -L "/etc/systemd/system/ununknowntun-cdn-$id.timer" ]] && head -n1 "/etc/systemd/system/ununknowntun-cdn-$id.timer" | grep -qx '# Managed by UNUNKNOWNTUN CDN controller v1' || { echo 'Unrelated scheduler exists; removal refused.' >&2; return 1; }
            cdn_present=1
            cdn_was_enabled="$(systemctl is-enabled "ununknowntun-cdn-$id.timer" 2>/dev/null || true)"
            systemctl is-active --quiet "ununknowntun-cdn-$id.timer" && cdn_was_active=1
        fi
        systemctl is-active --quiet "ununknowntun@$id" && was_active=1
        was_enabled="$(systemctl is-enabled "ununknowntun@$id" 2>/dev/null || true)"
        site="${NGINX_SITE:-}"; site_link="/etc/nginx/sites-enabled/${site##*/}"
        if [[ "$site" == /etc/nginx/sites-available/ununknowntun-*.conf ]]; then
            if site_referenced_elsewhere "$site" "$id"; then
                echo "Nginx site is referenced by another tunnel; it will be retained."
            else
                shared_status=$?
                [[ "$shared_status" == 1 ]] || { echo "Cannot verify other tunnel references; removal refused." >&2; return 1; }
                remove_site=1
                command -v nginx >/dev/null 2>&1 || { echo "Nginx is required to safely validate this removal." >&2; return 1; }
            fi
        fi
        install -d -m 0700 "$INSTALL_DIR/backups" || return
        backup="$(mktemp -d "$INSTALL_DIR/backups/deleted-$id-XXXXXX")" || return
        install -d -m 0700 "$backup/nginx-available" "$backup/nginx-enabled" || return
        cp -a "$config" "$backup/config" || return
        printf 'present=%s\nenabled=%s\nactive=%s\n' "$cdn_present" "$cdn_was_enabled" "$cdn_was_active" > "$backup/cdn-timer-state.txt"
        trap 'restore_deleted_tunnel; exit 130' INT
        trap 'restore_deleted_tunnel; exit 143' TERM
        if ! perform_delete_steps; then
            restore_deleted_tunnel || true
            return 1
        fi
        trap - INT TERM
        echo "Tunnel '$id' removed. Recoverable backup: $backup"
        echo "Certificates were retained because they may be shared or renewed externally."
        echo "Firewall rules were retained for other services; review them manually if needed."
    )
}

test_tunnel() {
    local id="$1" config="$TUNNELS_DIR/$1" first_port test_host setting invocation logs
    local -a settings=() tls_args=()
    /usr/local/bin/ununknowntun -version
    systemctl is-active "ununknowntun@$id" || true
    # shellcheck disable=SC1090
    . "$config/deployment.env"
    if [[ "${ROLE:-}" == origin ]]; then
        # Read only named, non-secret flags. Never execute/source the launcher,
        # and do not infer the actual handshake from a CDN-provider label.
        while IFS= read -r -d '' setting; do settings+=("$setting"); done < <(python3 - "$config/run.sh" "${CA_PATH:-}" <<'DIAGNOSTIC_FLAGS'
import re, shlex, sys
from pathlib import Path
source = Path(sys.argv[1]).read_text()
for name, fallback in (("ech-mode", "off"), ("tls-fragment", "off"), ("tls-min-version", "1.3"), ("ca", sys.argv[2]), ("mux", "on"), ("transport", "auto")):
    values = re.findall(r"(?m)^[ \t]*-" + re.escape(name) + r"[ \t]+(.+?)[ \t]*(?:\\)?$", source)
    if len(values) > 1:
        raise SystemExit("Duplicate diagnostic flag: -" + name)
    value = shlex.split(values[0].strip().rstrip("\\").strip()) if values else [fallback]
    if len(value) != 1 or any(ord(c) < 32 for c in value[0]):
        raise SystemExit("Unsupported diagnostic flag layout: -" + name)
    sys.stdout.write(value[0] + "\0")
DIAGNOSTIC_FLAGS
)
        [[ ${#settings[@]} == 6 ]] || { echo "Could not read actual launch settings safely; no TLS probe performed." >&2; return 1; }
        printf 'Configured carrier=%s, ECH=%s, fragment=%s, minimum TLS=%s, MUX=%s\n' "${settings[5]}" "${settings[0]}" "${settings[1]}" "${settings[2]}" "${settings[4]}"
        first_port="${FOREIGN_PORTS%%,*}"
        if [[ "${FOREIGN_PROXY_PROVIDER:-none}" == none ]]; then test_host="$FOREIGN_IP"; else test_host="$FOREIGN_DOMAIN"; fi
        if [[ "${settings[0]}" == strict || "${settings[1]}" != off ]]; then
            echo "Plain OpenSSL probe skipped: it cannot reproduce the configured ECH/fragment handshake. Use actual UNUNKNOWNTUN stage logs below; this command does not certify ECH acceptance or network health."
        else
            echo "Bounded ordinary TLS/certificate probe only (not tunnel authentication, ECH acceptance, or payload validation):"
            case "${settings[2]}" in
                1.2) tls_args=(-min_protocol TLSv1.2) ;;
                1.3) tls_args=(-min_protocol TLSv1.3) ;;
                *) echo "Unknown minimum TLS version; refusing an unrepresentative probe." >&2; return 1 ;;
            esac
            [[ -z "${settings[3]}" ]] || tls_args+=(-CAfile "${settings[3]}")
            if ! echo | timeout 8 openssl s_client -connect "$test_host:$first_port" -servername "$FOREIGN_DOMAIN" -verify_hostname "$FOREIGN_DOMAIN" -verify_return_error "${tls_args[@]}" -brief 2>&1 | head -n 12; then
                echo "Ordinary TLS probe failed; inspect its error. This is not proof of a firewall, token, or tunnel defect." >&2
            fi
        fi
        invocation="$(systemctl show "ununknowntun@$id" -p InvocationID --value 2>/dev/null || true)"
        if [[ "$invocation" =~ ^[0-9a-fA-F]{32}$ ]]; then
            echo "Recent actual-core evidence from the current service invocation only (historical events, not a fresh end-to-end test):"
            logs="$(journalctl "_SYSTEMD_INVOCATION_ID=$invocation" -n 80 --no-pager 2>/dev/null || true)"
            printf '%s\n' "$logs" | grep -E '\[stats\]|session established|connect failed|no tunnel session|open stream failed|\[stage=|\[config\]|\[fatal\]' | tail -n 20 || true
        else
            echo "No current service invocation is available; previous logs are not health evidence."
        fi
        if [[ "${settings[4]}" == off ]]; then
            echo "MUX OFF: zero idle sessions is expected, not proof of success or failure. Connect one real client to trigger a fresh dedicated session, then inspect its stage logs and upload/download."
        else
            echo "A service or session being active is not an end-to-end traffic test. Verify a real client upload and download."
        fi
    elif command -v nginx >/dev/null 2>&1; then
        nginx -t
    fi
}

command_name="${1:-help}"
case "$command_name" in
    ui|direct-icmp-manage)
        need_root
        shift
        [[ "$command_name" != direct-icmp-manage ]] || set -- --icmp-manage "$@"
        # Only launch the existing interface. No manager lock, install or probe.
        /usr/bin/python3 -I - "$INSTALL_DIR/share/ununknowntun-ui.py" "$@" 3<&0 <<'UI_LAUNCH'
import os
from pathlib import Path
import stat
import sys

def trusted(path):
    path = Path(path)
    for item in (path, *path.parents):
        info = item.lstat()
        if info.st_uid != 0 or info.st_mode & 0o022 or stat.S_ISLNK(info.st_mode):
            raise SystemExit("Unsafe UI ownership, permissions or symlink; refused.")
    if not stat.S_ISREG(path.stat().st_mode):
        raise SystemExit("Expected a regular UI file; refused.")

ui = Path(sys.argv[1])
trusted(ui)
runtime = Path("/usr/bin/python3").resolve(strict=True)
trusted(runtime)
env = {key: value for key, value in os.environ.items()
       if not key.startswith(("PYTHON", "LD_", "DYLD_", "BASH_FUNC_"))
       and key not in {"BASH_ENV", "ENV", "SHELLOPTS", "BASHOPTS", "UNUNKNOWNTUN_TOKEN", "V7_TOKEN"}}
env["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
os.dup2(3, 0)
os.close(3)
os.execve(str(runtime), [str(runtime), "-I", str(ui), *sys.argv[2:]], env)
UI_LAUNCH
        ;;
    list) need_root; list_tunnels ;;
    status) need_root; id="$(select_id "${2:-}")"; systemctl status "ununknowntun@$id" --no-pager -l ;;
    health) need_root; id="$(select_id "${2:-}")"; show_health "$id" ;;
    monitor)
        need_root
        id="$(select_id "${2:-}")"
        while true; do
            clear || true
            date
            show_health "$id"
            echo
            echo "Press Ctrl+C to exit."
            sleep 2
        done
        ;;
    start|stop|restart)
        need_root
        id="$(select_id "${2:-}")"
        manager_lock
        systemctl "$command_name" "ununknowntun@$id"
        systemctl is-active "ununknowntun@$id" || true
        ;;
    logs) need_root; id="$(select_id "${2:-}")"; journalctl -u "ununknowntun@$id" -f -n 100 ;;
    config) need_root; id="$(select_id "${2:-}")"; cat "$TUNNELS_DIR/$id/run.sh" ;;
    info) need_root; id="$(select_id "${2:-}")"; cat "$TUNNELS_DIR/$id/client-info.txt" 2>/dev/null || echo "The client information file has not been created yet." ;;
    ports) need_root; id="$(select_id "${2:-}")"; cat "$TUNNELS_DIR/$id/ports.list" 2>/dev/null || true ;;
    peer-code)
        need_root
        id="$(select_id "${2:-}")"
        [[ -r "$TUNNELS_DIR/$id/peer.env" ]] || { echo "This command is only available on the foreign side." >&2; exit 1; }
        base64 < "$TUNNELS_DIR/$id/peer.env" | tr -d '\n'
        echo
        ;;
    test) need_root; id="$(select_id "${2:-}")"; test_tunnel "$id" ;;
    doctor|scan)
        need_root; id="$(select_id "${2:-}")"
        if (( $# >= 2 )); then shift 2; else shift; fi
        python3 "$INSTALL_DIR/share/tunnel-doctor.py" --config-dir "$TUNNELS_DIR/$id" "$@"
        ;;
    direct-icmp-pair)
        need_root
        [[ "$#" == 2 ]] || { echo "Usage: ununknowntunctl direct-icmp-pair /new/private/output" >&2; exit 1; }
        exec /usr/bin/python3 -I "$INSTALL_DIR/share/direct-icmp-pair.py" --output "$2"
        ;;
    direct-icmp-setup)
        need_root
        [[ "$#" == 2 && ( "$2" == foreign || "$2" == iran ) ]] || { echo "Usage: ununknowntunctl direct-icmp-setup foreign|iran" >&2; exit 1; }
        exec /usr/bin/python3 -I "$INSTALL_DIR/share/direct-icmp-setup.py" "$2" --binary /usr/local/bin/ununknowntun --binary-manifest "$INSTALL_DIR/share/direct-icmp-binaries.json"
        ;;
    direct-icmp-doctor)
        need_root
        [[ "$#" == 2 ]] || { echo "Usage: ununknowntunctl direct-icmp-doctor /etc/ununknowntun-direct-icmp/NAME/ROLE" >&2; exit 1; }
        exec /usr/bin/python3 -I "$INSTALL_DIR/share/direct-icmp-manage.py" doctor --endpoint "$2"
        ;;
    scanner)
        need_root
        shift
        # Independent scanner: no tunnel selection, service changes or CDN apply.
        PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
        export PATH
        /usr/bin/python3 -I - "$INSTALL_DIR/share" "$INSTALL_DIR/scanner-venv" "$@" 3<&0 <<'SCANNER_LAUNCH'
import os
from pathlib import Path
import stat
import sys

def trusted(path, regular=False):
    path = Path(path)
    for item in (path, *path.parents):
        info = item.lstat()
        if info.st_uid != 0 or info.st_mode & 0o022 or stat.S_ISLNK(info.st_mode):
            raise SystemExit("Unsafe scanner ownership, permissions or symlink; refused.")
    if regular and not stat.S_ISREG(path.stat().st_mode):
        raise SystemExit("Expected a regular scanner file; refused.")

share, venv = map(Path, sys.argv[1:3])
console = share / "scanner-console.py"
for helper in (console, share / "scanner-engine.py"):
    trusted(helper, regular=True)
runtime = Path("/usr/bin/python3").resolve(strict=True)
trusted(runtime, regular=True)
if venv.exists() or venv.is_symlink():
    trusted(venv)
    trusted(venv / "pyvenv.cfg", regular=True)
    candidate = venv / "bin/python3"
    trusted(candidate.parent)
    info = candidate.lstat()
    if info.st_uid != 0 or (not stat.S_ISLNK(info.st_mode) and info.st_mode & 0o022):
        raise SystemExit("Unsafe scanner virtual environment interpreter; refused.")
    trusted(candidate.resolve(strict=True), regular=True)
    # Python imports its environment before the console can validate it.
    # Reject writable dependency files and links escaping into unsafe paths.
    for directory, dirs, files in os.walk(venv, followlinks=False):
        for name in dirs + files:
            path = Path(directory) / name
            if path.is_symlink():
                if path.lstat().st_uid != 0:
                    raise SystemExit("Unsafe virtual environment link; refused.")
                trusted(path.resolve(strict=True))
            else:
                trusted(path)
    runtime = candidate
env = {key: value for key, value in os.environ.items()
       if not key.startswith(("PYTHON", "LD_", "DYLD_", "BASH_FUNC_"))
       and key not in {"BASH_ENV", "ENV", "SHELLOPTS", "BASHOPTS", "UNUNKNOWNTUN_TOKEN", "V7_TOKEN"}}
env["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
os.dup2(3, 0)
os.close(3)
os.execve(str(runtime), [str(runtime), "-I", str(console), *sys.argv[3:]], env)
SCANNER_LAUNCH
        ;;
    cdn|cdn-scan|cdn-rounds|cdn-preview|cdn-status)
        need_root; id="$(select_id "${2:-}")"
        case "$command_name" in cdn) action=menu;; cdn-scan) action=scan;; cdn-rounds) action=rounds;; cdn-preview) action=preview;; cdn-status) action=status;; esac
        python3 "$INSTALL_DIR/share/cdn-control.py" "$action" --config-dir "$TUNNELS_DIR/$id"
        ;;
    edit|edit-apply|edit-show|edit-ip|edit-ports|apply-update)
        need_root; id="$(select_id "${2:-}")"
        case "$command_name" in
            edit) action=menu;; edit-apply|apply-update) action=apply-update;; edit-show) action=show;;
            edit-ip) action=ip;; edit-ports) action=ports;;
        esac
        # The editor takes its own global lock. Never hold a shell lock here.
        python3 "$INSTALL_DIR/share/tunnel-editor.py" "$action" \
            --config-dir "$TUNNELS_DIR/$id" --state-dir "/var/lib/ununknowntun/$id"
        ;;
    delete) need_root; id="$(select_id "${2:-}")"; manager_lock; delete_tunnel "$id" ;;
    customers|usage|customer-add|customer-quota|customer-disable|customer-enable|customer-export|customer-ports|tunnel-quota)
        need_root; id="$(select_id "${2:-}")"
        case "$command_name" in
            customers) action=menu;; usage) action=list;; customer-add) action=add;;
            customer-quota) action=quota;; customer-disable) action=disable;; customer-enable) action=enable;;
            customer-export) action=export;; customer-ports) action=ports;; tunnel-quota) action=total-quota;;
        esac
        customer_command "$action" "$id" "${3:-}"
        ;;
    help|*)
        cat <<'HELP'
Usage: ununknowntunctl COMMAND [TUNNEL_ID]

  ui            Open the Control Room terminal UI (optional --demo/--preview)
  direct-icmp-manage  Manage installed Direct ICMP pairs and port forwards
  list          List every tunnel on this server
  status        Show one service status
  health        Show one tunnel health and resources
  monitor       Refresh one tunnel monitor every two seconds
  start|stop|restart
  logs          Follow one tunnel log
  test          Test one service and TLS path
  doctor|scan   Bounded diagnostics; optional --endpoints HOST:PORT,... --output FILE --offline
  direct-icmp-pair DIR   Create an encrypted IPv4 ICMP pair with off/fixed/adaptive FEC (no deployment)
  direct-icmp-setup foreign|iran   Set up ICMP L3 using one private pairing code
  direct-icmp-doctor DIR          Read-only checks for one installed ICMP endpoint
  scanner       Full SIKDPI scanner: IP, SNI, REALITY, speed, discovery and exports (no TUNNEL_ID)
  cdn           Edit Cloudflare scan settings and automatic update schedule
  cdn-scan      Scan and transactionally apply an authenticated improved endpoint
  cdn-rounds    Guided scan rounds, ranked results and authenticated endpoint selection
  cdn-preview   Preview an authenticated scan without applying/restarting
  cdn-status    Show scan settings and timer state
  info          Show client and inbound guidance
  ports         Show ports owned by one tunnel
  peer-code     Show the paired-server installation code
  edit-ip       Change Iran or foreign IP and emit a synchronization code
  edit-ports    Add, remove, or replace ports without touching other tunnels
  apply-update  Apply a V3 synchronization code (alias of edit-apply)
  edit          Open the complete per-tunnel settings editor
  edit-apply    Apply a confidential V3 editor synchronization code
  edit-show     Show editable settings without revealing secrets
  delete        Safely remove one tunnel and keep a recoverable backup
  config        Show the launch command without exposing the token
  customers     Open customer access and quota management
  usage         Show customer usage and remaining allowances
  customer-add  Add a separate customer endpoint
  customer-quota|customer-disable|customer-enable|customer-export|customer-ports
                Manage one customer (optional third argument: customer ID)
  tunnel-quota  Change the total lifetime tunnel allowance
HELP
        ;;
esac
CTL
    chmod 0755 "$CTL_PATH"
    install_access_helper
}

install_access_helper() {
    install -d -m 0755 "$INSTALL_DIR/share"
    cat > "$INSTALL_DIR/share/access-manager.py" <<'ACCESS_MANAGER_PY'
__ACCESS_MANAGER_SOURCE__
ACCESS_MANAGER_PY
    chmod 0755 "$INSTALL_DIR/share/access-manager.py"
    cat > "$INSTALL_DIR/share/tunnel-editor.py" <<'TUNNEL_EDITOR_PY'
__TUNNEL_EDITOR_SOURCE__
TUNNEL_EDITOR_PY
    cat > "$INSTALL_DIR/share/editor_tls.py" <<'EDITOR_TLS_PY'
__EDITOR_TLS_SOURCE__
EDITOR_TLS_PY
    cat > "$INSTALL_DIR/share/profile-validation.py" <<'PROFILE_VALIDATION_PY'
__PROFILE_VALIDATION_INSTALLED_SOURCE__
PROFILE_VALIDATION_PY
    chmod 0644 "$INSTALL_DIR/share/profile-validation.py"
    cat > "$INSTALL_DIR/share/tunnel-doctor.py" <<'TUNNEL_DOCTOR_PY'
__TUNNEL_DOCTOR_SOURCE__
TUNNEL_DOCTOR_PY
    cat > "$INSTALL_DIR/share/cdn-endpoints.py" <<'CDN_ENDPOINTS_PY'
__CDN_ENDPOINTS_SOURCE__
CDN_ENDPOINTS_PY
    cat > "$INSTALL_DIR/share/cdn-control.py" <<'CDN_CONTROL_PY'
__CDN_CONTROL_SOURCE__
CDN_CONTROL_PY
    chmod 0755 "$INSTALL_DIR/share/cdn-endpoints.py" "$INSTALL_DIR/share/cdn-control.py"
    chmod 0755 "$INSTALL_DIR/share/tunnel-doctor.py"
    chmod 0755 "$INSTALL_DIR/share/tunnel-editor.py"
    chmod 0644 "$INSTALL_DIR/share/editor_tls.py"
    install_scanner_helpers
    install_terminal_ui
    install_direct_icmp_helpers
}

write_terminal_ui() {
    local destination="$1"
    cat > "$destination/ununknowntun-ui.py" <<'TERMINAL_UI_PY'
__TERMINAL_UI_SOURCE__
TERMINAL_UI_PY
    cat > "$destination/direct-icmp-console.py" <<'DIRECT_ICMP_CONSOLE_PY'
__DIRECT_ICMP_CONSOLE_SOURCE__
DIRECT_ICMP_CONSOLE_PY
    chown root:root "$destination/ununknowntun-ui.py" "$destination/direct-icmp-console.py"
    chmod 0755 "$destination/ununknowntun-ui.py" "$destination/direct-icmp-console.py"
}

install_terminal_ui() (
    # share/ is included in the install/upgrade transaction snapshot.
    [[ -d "$INSTALL_DIR/share" && ! -L "$INSTALL_DIR" && ! -L "$INSTALL_DIR/share" ]] ||
        die "Unsafe UI installation directory."
    local stage
    stage="$(mktemp -d "$INSTALL_DIR/share/.ui-stage.XXXXXXXX")"
    trap 'rm -rf -- "$stage"' EXIT
    chmod 0700 "$stage"
    chown root:root "$stage"
    write_terminal_ui "$stage"
    mv -f -- "$stage/ununknowntun-ui.py" "$INSTALL_DIR/share/ununknowntun-ui.py"
    mv -f -- "$stage/direct-icmp-console.py" "$INSTALL_DIR/share/direct-icmp-console.py"
)

write_scanner_helpers() {
    local destination="$1"
    cat > "$destination/scanner-console.py" <<'SCANNER_CONSOLE_PY'
__SCANNER_CONSOLE_SOURCE__
SCANNER_CONSOLE_PY
    cat > "$destination/scanner-engine.py" <<'SCANNER_ENGINE_PY'
__SCANNER_ENGINE_SOURCE__
SCANNER_ENGINE_PY
    chown root:root "$destination/scanner-console.py" "$destination/scanner-engine.py"
    chmod 0755 "$destination/scanner-console.py"
    chmod 0700 "$destination/scanner-engine.py"
}

install_scanner_helpers() (
    # Install/upgrade owns share through the existing transaction snapshot.
    # A private staging directory prevents following an old helper symlink.
    [[ -d "$INSTALL_DIR/share" && ! -L "$INSTALL_DIR" && ! -L "$INSTALL_DIR/share" ]] ||
        die "Unsafe scanner installation directory."
    local stage
    stage="$(mktemp -d "$INSTALL_DIR/share/.scanner-stage.XXXXXXXX")"
    trap 'rm -rf -- "$stage"' EXIT
    chmod 0700 "$stage"
    chown root:root "$stage"
    write_scanner_helpers "$stage"
    mv -f -- "$stage/scanner-console.py" "$INSTALL_DIR/share/scanner-console.py"
    mv -f -- "$stage/scanner-engine.py" "$INSTALL_DIR/share/scanner-engine.py"
)

initialize_customer_access() {
    local ports="$1" total_gb="$2" provider="$3"
    local -a options=()
    [[ "$provider" == none ]] || options+=(--proxied)
    python3 "$INSTALL_DIR/share/access-manager.py" init --config-dir "$CONFIG_DIR" --ports "$ports" --quota-gb "$total_gb" ${options[@]+"${options[@]}"}
    runuser -u ununknowntun -- "$BIN_PATH" -access-config "$CONFIG_DIR/access.json" \
        -access-state "$TUNNEL_STATE_DIR/access-state.json" -access-init-state
}

setup_time_sync() {
    if ! timedatectl show -p NTPSynchronized --value 2>/dev/null | grep -qx true; then
        warn "The system clock is not synchronized. A difference greater than five minutes will reject transport pre-authentication."
    fi
}

select_resource_profile() {
    local ram_kb
    ram_kb="$(awk '/^MemTotal:/ {print $2; exit}' /proc/meminfo 2>/dev/null || echo 0)"
    if (( ram_kb > 0 && ram_kb < 1572864 )); then
        PROFILE_MAX_MEMORY=268435456
        PROFILE_MAX_STREAMS=1024
    elif (( ram_kb > 0 && ram_kb < 4194304 )); then
        PROFILE_MAX_MEMORY=536870912
        PROFILE_MAX_STREAMS=2048
    else
        PROFILE_MAX_MEMORY=1073741824
        PROFILE_MAX_STREAMS=4096
    fi
    info "Resource profile: max-memory=$PROFILE_MAX_MEMORY, max-streams=$PROFILE_MAX_STREAMS"
}

setup_safe_tcp_tuning() {
    # Shared-host safety: all these settings affect Native Reverse/Xray too.
    # Keep existing host TCP settings unchanged; tune separately after testing.
    info "Existing host TCP/sysctl settings are unchanged."
    return 0
}

check_nginx_domain_conflicts() {
    local domain="$1" dump conflicts env_file owner registered
    for env_file in "$TUNNELS_DIR"/*/deployment.env; do
        [[ -f "$env_file" ]] || continue
        owner="${env_file%/deployment.env}"; owner="${owner##*/}"
        [[ "$owner" == "$CURRENT_TUNNEL_ID" ]] && continue
        registered="$(sed -nE 's/^(FOREIGN_DOMAIN|IRAN_ENTRY_DOMAIN)=//p' "$env_file")"
        printf '%s\n' "$registered" | grep -Fxq "$domain" || continue
        fail "Domain $domain already belongs to tunnel '$owner'. Use a different domain so an existing tunnel is not overwritten."
        return 1
    done
    command -v nginx >/dev/null 2>&1 || return 0
    dump="$(nginx -T 2>&1)" || { fail "Existing Nginx configuration is invalid; correct it before retrying."; return 1; }
    conflicts="$(printf '%s\n' "$dump" | awk -v domain="$domain" '
        /^# configuration file / { file=$4; sub(/:$/, "", file) }
        { line=$0; sub(/#.*/, "", line) }
        line ~ /server_name[[:space:]]/ { collecting=1; names="" }
        collecting { names=names " " line }
        collecting && line ~ /;/ {
            collecting=0; gsub(/[;\"]/, " ", names); n=split(names, words, /[[:space:]]+/)
            managed1="/etc/nginx/sites-available/ununknowntun-" domain ".conf"
            managed2="/etc/nginx/sites-enabled/ununknowntun-" domain ".conf"
            for(i=1;i<=n;i++) if(words[i]==domain && file!=managed1 && file!=managed2) print file
        }')"
    [[ -z "$conflicts" ]] || { fail "Domain $domain is already configured outside the managed site: $conflicts. Use a separate tunnel domain."; return 1; }
}

open_ufw_ports() {
    local ports="$1" port result
    if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | head -n 1 | grep -q 'Status: active'; then
        install -d -m 0750 "$CONFIG_DIR"
        for port in ${ports//,/ }; do
            # IPv4-only rule matches the IPv4 listeners. A single-family rule
            # lets rollback distinguish a newly added rule from an existing one.
            result="$(LC_ALL=C ufw allow proto tcp from 0.0.0.0/0 to 0.0.0.0/0 port "$port")"
            if [[ "$result" == *"Rule added"* || "$result" == *"Rules updated"* ]]; then
                [[ "$TX_ACTIVE" != 1 ]] || TX_UFW_PORTS+=("$port")
                printf '%s\n' "$port" >> "$CONFIG_DIR/firewall-owned.ports"
            fi
        done
        [[ ! -f "$CONFIG_DIR/firewall-owned.ports" ]] || sort -nu -o "$CONFIG_DIR/firewall-owned.ports" "$CONFIG_DIR/firewall-owned.ports"
        info "TCP ports opened in UFW: $ports"
    else
        warn "UFW is not active, so no firewall changes were made. Also open ports $ports in the datacenter firewall."
    fi
}

check_port_conflicts() {
    local ports="$1" allowed_regex="$2" label="$3" port owners bad
    command -v ss >/dev/null 2>&1 || return 0
    for port in ${ports//,/ }; do
        owners="$(ss -H -ltnp "sport = :$port" 2>/dev/null || true)"
        [[ -z "$owners" ]] && continue
        if [[ -n "$allowed_regex" ]]; then
            bad="$(printf '%s\n' "$owners" | grep -Ev "$allowed_regex" || true)"
        else
            bad="$owners"
        fi
        if [[ -n "$bad" ]]; then
            printf '%s\n' "$bad" >&2
            fail "Port $port for $label is already used by another process. Choose another port or stop the conflicting service yourself."
            return 1
        fi
    done
    return 0
}

install_ca_if_needed() {
    if [[ -s "$CONFIG_DIR/ca-bundle.pem" ]]; then
        openssl x509 -in "$CONFIG_DIR/ca-bundle.pem" -noout >/dev/null 2>&1 || { fail "The copied CA bundle is not valid PEM; replace that file before retrying."; return 1; }
        ORIGIN_CA_PATH="$CONFIG_DIR/ca-bundle.pem"
        info "Using the explicitly supplied offline CA bundle."
        return 0
    fi
    if [[ -s "$BASE_CONFIG_DIR/ca-bundle.pem" ]]; then
        openssl x509 -in "$BASE_CONFIG_DIR/ca-bundle.pem" -noout >/dev/null 2>&1 || { fail "The shared offline CA bundle is not valid PEM; replace that file before retrying."; return 1; }
        ORIGIN_CA_PATH="$BASE_CONFIG_DIR/ca-bundle.pem"
        info "Using the shared offline CA bundle."
        return 0
    fi
    ORIGIN_CA_PATH=/etc/ssl/certs/ca-certificates.crt
    [[ -s "$ORIGIN_CA_PATH" ]] && return 0
    warn "No CA bundle was found on the Iran server. Attempting to install ca-certificates."
    if apt-get -o Acquire::Retries=1 -o Acquire::http::Timeout=15 -o Acquire::https::Timeout=15 update &&
        DEBIAN_FRONTEND=noninteractive apt-get -o Acquire::Retries=1 -y install ca-certificates; then
        update-ca-certificates || true
    fi
    [[ -s /etc/ssl/certs/ca-certificates.crt ]]
}

write_common_files() {
    local role="$1"
    TX_SERVICE_TOUCHED=1
    ensure_service_user
    install_binary "$role"
    install_manager
    install_service_unit
    setup_time_sync
	select_resource_profile
}

install_foreign_packages() {
    local cert_choice="${1:-1}"
    local -a packages=()
    command -v nginx >/dev/null 2>&1 || packages+=(nginx)
    if [[ "$cert_choice" == 1 ]]; then
        command -v certbot >/dev/null 2>&1 || packages+=(certbot)
    fi
    [[ -s /etc/ssl/certs/ca-certificates.crt ]] || packages+=(ca-certificates)
    (( ${#packages[@]} )) || return 0
    info "Installing missing dependencies only: ${packages[*]}. Existing packages are not explicitly upgraded."
    apt-get -o Acquire::Retries=2 -o Acquire::http::Timeout=20 -o Acquire::https::Timeout=20 update || { fail "Dependency index update failed; repair package access before retrying."; return 1; }
    DEBIAN_FRONTEND=noninteractive apt-get -o Acquire::Retries=2 install --no-upgrade -y "${packages[@]}" || { fail "Dependency installation failed; repair the package manager before retrying."; return 1; }
    command -v nginx >/dev/null 2>&1 || { fail "Nginx was not installed. Check repository connectivity."; return 1; }
    [[ "$cert_choice" != 1 ]] || command -v certbot >/dev/null 2>&1 || { fail "Certbot was not installed."; return 1; }
}

make_decoy_site() {
    install -d -o www-data -g www-data -m 0755 "$DECOY_DIR/.well-known/acme-challenge"
    if [[ ! -s "$DECOY_DIR/index.html" ]]; then
        cat > "$DECOY_DIR/index.html" <<'HTML'
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Service Status</title><style>body{font:16px system-ui;background:#f5f7fb;color:#172033;margin:0}.box{max-width:720px;margin:12vh auto;background:white;padding:42px;border-radius:14px;box-shadow:0 8px 32px #18233a18}.ok{color:#14804a}</style></head>
<body><main class="box"><h1>Service Status</h1><p class="ok">All systems operational</p><p>This endpoint provides secure customer services.</p></main></body></html>
HTML
        chown www-data:www-data "$DECOY_DIR/index.html"
    fi
}

write_http_challenge_site() {
    local domain="$1" site="$NGINX_SITE_DIR/ununknowntun-$1.conf"
    # A previous managed TLS site already serves the webroot challenge. Keep it
    # live while obtaining/validating its replacement certificate.
    if [[ -e "$site" || -L "$site" ]]; then
        grep -Fq "root $DECOY_DIR;" "$site" &&
            grep -Fq 'location ^~ /.well-known/acme-challenge/' "$site" ||
            die "Existing managed Nginx site has no expected ACME webroot; refusing to replace it for issuance."
        return 0
    fi
    backup_file "$site"
    cat > "$site" <<EOF
server {
    listen 80;
    server_name $domain;
    root $DECOY_DIR;
    location ^~ /.well-known/acme-challenge/ { try_files \$uri =404; }
    location / { try_files \$uri \$uri/ /index.html; }
}
EOF
    ln -sfn "$site" "$NGINX_ENABLED_DIR/ununknowntun-$domain.conf"
    nginx -t
    systemctl enable --now nginx
    systemctl reload nginx
}

obtain_certificate() {
    local domain="$1" cert_mode="$2" email="$3" cert_path="$4" key_path="$5"
    if [[ "$cert_mode" == "existing" ]]; then
		[[ -s "$cert_path" && -s "$key_path" ]] || { fail "The certificate or private key file was not found."; return 1; }
		openssl x509 -in "$cert_path" -noout -checkend 86400 >/dev/null || { fail "The certificate is invalid or expires in less than 24 hours."; return 1; }
        local host_result cert_public key_public
        if ! host_result="$(openssl x509 -in "$cert_path" -noout -checkhost "$domain" 2>&1)"; then
            if [[ "$host_result" == "Hostname $domain does NOT match certificate" ]]; then
                fail "The certificate does not include $domain."
            else
                fail "Certificate hostname inspection failed; verify certificate readability and OpenSSL -checkhost support."
            fi
            return 1
        fi
        [[ "$host_result" == "Hostname $domain does match certificate" ]] || { fail "The certificate does not include $domain."; return 1; }
        cert_public="$(openssl x509 -in "$cert_path" -pubkey -noout | openssl pkey -pubin -outform DER | sha256sum)" || return 1
        key_public="$(openssl pkey -in "$key_path" -passin pass: -pubout -outform DER | sha256sum)" || return 1
        [[ "$cert_public" == "$key_public" ]] || { fail "Certificate and private key do not match."; return 1; }
		return
    fi
    command -v certbot >/dev/null 2>&1 || { fail "Certbot is unavailable. Install it or select an existing certificate."; return 1; }
    valid_port 80
    info "Requesting or renewing the Let's Encrypt certificate for $domain..."
    certbot certonly --webroot -w "$DECOY_DIR" -d "$domain" \
        --cert-name "$domain" --non-interactive --agree-tos --email "$email" --keep-until-expiring || {
        fail "Certificate issuance failed. Verify DNS and port 80; let /.well-known/acme-challenge/ reach this origin without cache, redirects, or browser challenges."
        return 1
    }
    obtain_certificate "$domain" existing "" "$cert_path" "$key_path"
}

ask_certificate_settings() {
    local cert_domain="$1"
    printf '\nTLS certificate method:\n  1) Automatic Let\x27s Encrypt\n  2) Use an existing certificate (including downloaded Arvan ORIGIN certificate + key)\n'
    info "CDN edge HTTPS and CDN-to-origin HTTPS are separate. Enabling the CDN edge certificate does not install the origin certificate on this server."
    info "Arvan's issued origin certificate is a public Let's Encrypt certificate; a private CA is optional only for other explicitly private origin certificates."
    ask_valid cert_choice "Select an option" "${cert_choice:-1}" valid_two_choices "Select 1 or 2."
    if [[ "$cert_choice" == 1 ]]; then
        ask_valid email "Email address for Let's Encrypt" "${email:-}" valid_email "Enter a valid email address."
        cert_path="/etc/letsencrypt/live/$cert_domain/fullchain.pem"
        key_path="/etc/letsencrypt/live/$cert_domain/privkey.pem"
    else
        while true; do
            ask_valid cert_path "Absolute path to fullchain.pem (no whitespace)" "${cert_path:-}" valid_cert_path "Use an absolute certificate path without spaces."
            ask_valid key_path "Absolute path to privkey.pem (no whitespace)" "${key_path:-}" valid_cert_path "Use an absolute private-key path without spaces."
            obtain_certificate "$cert_domain" existing "" "$cert_path" "$key_path" && break
            warn "Correct the certificate/key files or enter their corrected paths. Earlier installation answers are retained."
        done
        ask_valid LOCAL_TLS_CA_PATH "CA bundle for local origin certificate verification (CDN edge trust stays separate)" "${LOCAL_TLS_CA_PATH:-/etc/ssl/certs/ca-certificates.crt}" valid_ca_path "Choose an existing readable PEM CA bundle with an absolute path."
    fi
}

valid_ca_path() {
    valid_cert_path "$1" && [[ -r "$1" && -s "$1" ]] && openssl x509 -in "$1" -noout >/dev/null 2>&1
}

obtain_certificate_with_retry() {
    local cert_domain="$1" action
    while true; do
        if [[ "$cert_choice" == 1 ]]; then
            obtain_certificate "$cert_domain" letsencrypt "$email" "$cert_path" "$key_path" && return 0
        else
            obtain_certificate "$cert_domain" existing "" "$cert_path" "$key_path" && return 0
        fi
        printf '\n1) Recheck after fixing DNS/CDN/firewall/files\n2) Correct email or certificate settings\n3) Cancel and restore installation snapshot\n'
        ask_valid action "Certificate recovery" 1 valid_three_choices "Select 1, 2, or 3."
        case "$action" in 1) ;; 2) ask_certificate_settings "$cert_domain" ;; 3) die "Certificate setup cancelled." ;; esac
    done
}

show_acme_proxy_guidance() {
    local provider="$1" domain="$2"
    [[ "$provider" != none && "$provider" != nginx ]] || return 0
    warn "Certificate bootstrap for $domain: the HTTP80 ACME challenge must reach this server without cache or browser challenges."
    if [[ "$provider" == arvan ]]; then
        warn "For the FIRST certificate, temporarily use Arvan origin Auto/follow HTTP and disable HTTP-to-HTTPS redirects for /.well-known/acme-challenge/. Forcing origin HTTPS443 before a certificate exists prevents issuance."
        warn "After the TLS frontend is installed below, change Arvan origin to HTTPS443 before the CDN WebSocket test. An existing valid certificate avoids this bootstrap step."
    fi
}

nginx_rotation_pattern() {
    local base='^/gdt-r/([0-9a-f]{32}|[0-9a-f]{64})'
    if [[ "$1" == xhttp ]]; then
        # stream-one uses the trailing slash alone; other modes use a UUID,
        # with an optional canonical upload sequence. The core validates all.
        printf '%s\n' "$base/([0-9A-Fa-f]{8}-([0-9A-Fa-f]{4}-){3}[0-9A-Fa-f]{12}(/(0|[1-9][0-9]{0,19}))?)?\$"
    else
        printf '%s\n' "$base\$"
    fi
}

write_nginx_rotation_route() {
    local backend_port="$1" upgrade="$2" connection="$3" route
    route="$(nginx_rotation_pattern "${transport:-wss}")"
    cat <<EOF
    # Prepared for opt-in rotation; the core rejects unconfigured/unauthenticated paths.
    location ~ "$route" {
        access_log off;
        proxy_pass http://127.0.0.1:$backend_port;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
$upgrade
$connection
        proxy_set_header Authorization \$http_authorization;
        proxy_buffering off;
        proxy_request_buffering off;
        proxy_cache off;
        add_header Cache-Control "no-store" always;
        proxy_socket_keepalive on;
        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
        proxy_intercept_errors off;
    }
EOF
}

write_nginx_wss_site() {
    local domain="$1" ports="$2" ws_path="$3" backend_port="$4" h2_path="$5" h2_backend_port="$6" cert_path="$7" key_path="$8"
    local site="$NGINX_SITE_DIR/ununknowntun-$domain.conf" temp port route="= $ws_path" upgrade='        proxy_set_header Upgrade $http_upgrade;'
    local connection='        proxy_set_header Connection "upgrade";'
    if [[ "${transport:-auto}" == xhttp ]]; then
        route="^~ ${xhttp_path%/}/"
        upgrade='        client_max_body_size 2m;
        gzip off;
        proxy_set_header Accept-Encoding "";'
        connection='        proxy_set_header Connection "";'
        if [[ "${xhttp_mode:-packet-up}" != packet-up ]]; then
            upgrade="${upgrade/client_max_body_size 2m/client_max_body_size 0}"
        fi
    fi
    temp="$(mktemp /tmp/ununknowntun-nginx.XXXXXX)"
    cat > "$temp" <<EOF
server {
    listen 80;
    server_name $domain;
    root $DECOY_DIR;
    location ^~ /.well-known/acme-challenge/ { try_files \$uri =404; }
    location / { try_files \$uri \$uri/ /index.html; }
}

server {
EOF
    for port in ${ports//,/ }; do
        printf '    listen %s ssl http2;\n' "$port" >> "$temp"
    done
    cat >> "$temp" <<EOF
    server_name $domain;
    root $DECOY_DIR;
    server_tokens off;

    ssl_certificate $cert_path;
    ssl_certificate_key $key_path;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_session_cache shared:UNUNKNOWNTUN:10m;
    ssl_session_timeout 1d;

    # UNUNKNOWNTUN_TRANSPORT_BEGIN
    location $route {
        access_log off;
        proxy_pass http://127.0.0.1:$backend_port;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
$upgrade
$connection
        proxy_set_header Authorization \$http_authorization;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_buffering off;
        proxy_request_buffering off;
        proxy_cache off;
        add_header Cache-Control "no-store" always;
        proxy_socket_keepalive on;
        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
        proxy_intercept_errors off;
    }
EOF
    write_nginx_rotation_route "$backend_port" "$upgrade" "$connection" >> "$temp"
    cat >> "$temp" <<EOF
    # UNUNKNOWNTUN_TRANSPORT_END
    location / { try_files \$uri \$uri/ /index.html; }
}
EOF
    backup_file "$site"
    install -m 0644 "$temp" "$site"
    rm -f "$temp"
    ln -sfn "$site" "$NGINX_ENABLED_DIR/ununknowntun-$domain.conf"
    nginx -t
    systemctl enable --now nginx
    systemctl reload nginx
}

write_nginx_origin_proxy_site() {
    local domain="$1" ports="$2" entry_path="$3" local_port="$4" cert_path="$5" key_path="$6"
    local site="$NGINX_SITE_DIR/ununknowntun-$domain.conf" temp port route="= $entry_path" upgrade='        proxy_set_header Upgrade $http_upgrade;'
    local connection='        proxy_set_header Connection "upgrade";'
    if [[ "${entry_transport:-ws}" == xhttp ]]; then
        route="^~ ${entry_path%/}/"
        upgrade='        proxy_set_header Authorization $http_authorization;
        gzip off;
        proxy_set_header Accept-Encoding "";'
        connection='        proxy_set_header Connection "";'
    fi
    temp="$(mktemp /tmp/ununknowntun-origin-nginx.XXXXXX)"
    cat > "$temp" <<EOF
server {
    listen 80;
    server_name $domain;
    root $DECOY_DIR;
    location ^~ /.well-known/acme-challenge/ { try_files \$uri =404; }
    location / { try_files \$uri \$uri/ /index.html; }
}

server {
EOF
    for port in ${ports//,/ }; do
        printf '    listen %s ssl http2;\n' "$port" >> "$temp"
    done
    cat >> "$temp" <<EOF
    server_name $domain;
    root $DECOY_DIR;
    server_tokens off;

    ssl_certificate $cert_path;
    ssl_certificate_key $key_path;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_session_cache shared:UNUNKNOWNTUN_IRAN:10m;
    ssl_session_timeout 1d;

    location $route {
        access_log off;
        client_max_body_size 0;
        proxy_pass http://127.0.0.1:$local_port;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
$upgrade
$connection
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_buffering off;
        proxy_request_buffering off;
        proxy_cache off;
        add_header Cache-Control "no-store" always;
        proxy_socket_keepalive on;
        proxy_read_timeout 86400s;
        proxy_send_timeout 86400s;
    }

    # UNUNKNOWNTUN_CUSTOMER_ROUTES
    location / { try_files \$uri \$uri/ /index.html; }
}
EOF
    backup_file "$site"
    install -m 0644 "$temp" "$site"
    rm -f "$temp"
    ln -sfn "$site" "$NGINX_ENABLED_DIR/ununknowntun-$domain.conf"
    nginx -t
    systemctl enable --now nginx
    systemctl reload nginx
}

install_certbot_reload_hook() {
    [[ -d /etc/letsencrypt ]] || return
    install -d -m 0755 "$CERTBOT_HOOK_DIR"
    cat > "$CERTBOT_HOOK_DIR/ununknowntun-nginx-reload" <<'HOOK'
#!/usr/bin/env sh
nginx -t && systemctl reload nginx
HOOK
    chmod 0755 "$CERTBOT_HOOK_DIR/ununknowntun-nginx-reload"
    TX_CERTBOT_TIMER_TOUCHED=1
    systemctl enable --now certbot.timer >/dev/null 2>&1 || warn "Certbot timer was not enabled; verify that an existing cron/timer renews this certificate."
}

check_dns_mode() {
    local domain="$1" direct_ip="$2" provider="$3"
    if [[ "$provider" == none || "$provider" == nginx ]]; then
        domain_points_to_ipv4 "$domain" "$direct_ip" || { fail "$domain must resolve directly to $direct_ip in no-proxy mode."; return 1; }
        pass "Direct DNS record confirmed: $domain -> $direct_ip"
    else
        domain_is_proxied_from_ipv4 "$domain" "$direct_ip" || { fail "$domain does not resolve, or still exposes origin $direct_ip. Enable the selected proxy or correct the selected mode."; return 1; }
        pass "$domain resolves away from the origin; selected provider: $(proxy_summary "$provider")."
        info "DNS alone cannot verify the CDN provider or its settings; the encrypted WebSocket path is tested separately."
    fi
}

confirm_dns_settings() {
    local domain_var="$1" ip_var="$2" provider_var="$3" action
    while ! check_dns_mode "${!domain_var}" "${!ip_var}" "${!provider_var}"; do
        printf '\n1) Recheck after changing DNS/proxy in the provider panel\n2) Correct proxy mode\n3) Correct domain or origin IP\n'
        ask_valid action "Fix this DNS step" 1 valid_three_choices "Select 1, 2, or 3."
        case "$action" in
            1) ;;
            2) select_proxy_provider "$provider_var" "Selected endpoint" ;;
            3)
                ask_valid "$domain_var" "Domain" "${!domain_var}" valid_domain "Enter a domain such as tunnel.example.com."
                ask_valid "$ip_var" "Origin server public IPv4" "${!ip_var}" valid_public_ipv4 "Enter a public IPv4 address."
                ;;
        esac
    done
}

correct_foreign_settings() {
    select_proxy_provider foreign_provider "Foreign server"
    ask_valid domain "Foreign domain" "$domain" valid_domain "Invalid domain."
    domain="$(lower_ascii "$domain")"
    ask_valid direct_ip "Foreign origin public IPv4" "$direct_ip" valid_public_ipv4 "Invalid public IPv4 address."
    confirm_dns_settings domain direct_ip foreign_provider
}

probe_rotating_foreign() {
    # Use the same route derivation/authentication as real origins; never probe
    # the retired static path or duplicate the cryptographic algorithm here.
    local probe_domain="$1" probe_host="$2" probe_port="$3" probe_ca="$4"
    "$BIN_PATH" -check-tunnel -probe-timeout 20s -mode origin \
        -transport "${transport:-wss}" -connect "$probe_host:$probe_port" \
        -target "127.0.0.1:$target_port" -token-file "$CONFIG_DIR/token" \
        -ws-host "${http_host:-$probe_domain}" -sni "$probe_domain" -ca "$probe_ca" -tls-min-version 1.2 \
        -ws-path "$ws_path" -xhttp-path "${xhttp_path:-$ws_path}" -xhttp-mode "${xhttp_mode:-packet-up}" \
        -mux "${mux_mode:-on}" -path-rotation "${path_rotation:-0}" -path-count "${path_count:-3}" \
        -path-grace "${path_grace:-5m}" -path-legacy "${path_legacy:-false}"
}

confirm_foreign_websocket() {
    local recovery connect_host minimum route_field=ws_path route_label=WebSocket route_mode=ws route_validator=valid_ws_path
    if [[ "${transport:-wss}" == xhttp ]]; then route_field=xhttp_path; route_label=XHTTP; route_mode=xhttp; route_validator=valid_xhttp_path; fi
    while true; do
        connect_host="$domain"; minimum=1.3
        [[ "$foreign_provider" != none ]] || connect_host="$direct_ip"
        [[ "$foreign_provider" != arvan ]] || minimum=1.2
        probe_websocket_path "$domain" "$connect_host" "${foreign_ports%%,*}" "${!route_field}" "$token" "$ORIGIN_CA_PATH" "$minimum" "$route_mode" && return 0
        printf '\n1) Recheck after fixing the CDN/firewall/clock\n2) Correct %s path\n3) Correct shared token\n' "$route_label"
        ask_valid recovery "Repair $route_label route (Ctrl-C cancels)" 1 valid_three_choices "Select 1, 2, or 3."
        case "$recovery" in
            1) ;;
            2) ask_valid "$route_field" "Exact $route_label path from the foreign connection code" "${!route_field}" "$route_validator" "Invalid $route_label path; use a clean absolute path without double slashes." ;;
            3)
                ask_valid token "Shared token from the foreign server" "" valid_token "Invalid token."
                pair_id="$(pair_id_from_token "$token")"
                ;;
        esac
    done
}

write_token_file() {
    local token="$1"
    printf '%s\n' "$token" > "$CONFIG_DIR/token"
    chown root:ununknowntun "$CONFIG_DIR/token"
    chmod 0640 "$CONFIG_DIR/token"
}

write_foreign_run_script() {
    local domain="$1" ws_path="$2" backend_port="$3" h2_path="$4" h2_backend_port="$5" target_port="$6"
    cat > "$CONFIG_DIR/run.sh" <<EOF
#!/usr/bin/env sh
exec $BIN_PATH \\
  -mode egress \\
  -transport ${transport:-wss} \\
  -listen 127.0.0.1:$backend_port \\
  -ws-host ${http_host:-$domain} \\
  -ws-path $ws_path \\
  -h2-path $h2_path \\
  -xhttp-path ${xhttp_path:-$ws_path} \\
  -xhttp-mode ${xhttp_mode:-packet-up} \\
  -path-rotation ${path_rotation:-0} \\
  -path-count ${path_count:-3} \\
  -path-grace ${path_grace:-5m} \\
  -path-legacy ${path_legacy:-false} \\
  -xhttp-padding-bytes ${xhttp_padding:-0} \\
  -padding-bytes ${padding_bytes:-0} \\
  -mux ${mux_mode:-on} \\
  -token-file $CONFIG_DIR/token \\
  -allow 127.0.0.1:$target_port \\
  -pad 0 \\
  -edge-write-timeout 0 \\
  -max-memory $PROFILE_MAX_MEMORY \\
  -max-streams $PROFILE_MAX_STREAMS \\
  -stats 5s
EOF
    chown root:ununknowntun "$CONFIG_DIR/run.sh"
    chmod 0750 "$CONFIG_DIR/run.sh"
}

write_origin_run_script() {
    local domain="$1" direct_ip="$2" foreign_ports="$3" ws_path="$4" h2_path="$5" target_port="$6" local_ports="$7" sessions="$8" pad="$9"
    local foreign_provider="${10:-none}" iran_provider="${11:-none}" spoof_profile="${12:-chrome}" ech_mode="${13:-off}"
    local connects="" listens="" port connect_host listen_host selected_transport="${transport:-wss}" tls_min=1.3
    if [[ "$foreign_provider" == arvan && "$ech_mode" != strict ]]; then tls_min=1.2; fi
    if [[ "$foreign_provider" == none ]]; then connect_host="$direct_ip"; else connect_host="$domain"; fi
    [[ -z "${dial_host:-}" ]] || connect_host="$dial_host"
    [[ "$connect_host" != *:* ]] || connect_host="[$connect_host]"
    if [[ "$iran_provider" == none ]]; then listen_host="0.0.0.0"; else listen_host="127.0.0.1"; fi
    for port in ${foreign_ports//,/ }; do
        connects+="${connects:+,}$connect_host:$port"
    done
    for port in ${local_ports//,/ }; do
        listens+="${listens:+,}$listen_host:$port"
    done
    cat > "$CONFIG_DIR/run.sh" <<EOF
#!/usr/bin/env sh
exec $BIN_PATH \\
  -mode origin \\
  -transport $selected_transport \\
  -tls-min-version $tls_min \\
  -listen $listens \\
  -access-config $CONFIG_DIR/access.json \\
  -access-state $TUNNEL_STATE_DIR/access-state.json \\
  -connect $connects \\
  -target 127.0.0.1:$target_port \\
  -ws-host ${http_host:-$domain} \\
  -ws-path $ws_path \\
  -h2-path $h2_path \\
  -xhttp-path ${xhttp_path:-$ws_path} \\
  -xhttp-mode ${xhttp_mode:-packet-up} \\
  -path-rotation ${path_rotation:-0} \\
  -path-count ${path_count:-3} \\
  -path-grace ${path_grace:-5m} \\
  -path-legacy ${path_legacy:-false} \\
  -xhttp-padding-bytes ${xhttp_padding:-0} \\
  -padding-bytes ${padding_bytes:-0} \\
  -mux ${mux_mode:-on} \\
  -sni ${tls_sni:-$domain} \\
  -ca $ORIGIN_CA_PATH \\
  -ech-mode $ech_mode \\
  -ech-config '${ech_source:-auto}' \\
  -tls-fragment ${tls_fragment:-off} \\
  -tls-fragment-size ${fragment_size:-100-200} \\
  -tls-fragment-interval ${fragment_interval:-1-3ms} \\
  -utls-profile $spoof_profile \\
  -token-file $CONFIG_DIR/token \\
  -sessions-min 2 \\
  -sessions $sessions \\
  -session-renewal ${session_renewal:-0} \\
  -pad 0 \\
  -edge-write-timeout 0 \\
  -max-memory $PROFILE_MAX_MEMORY \\
  -max-streams $PROFILE_MAX_STREAMS \\
  -stats 5s
EOF
    chown root:ununknowntun "$CONFIG_DIR/run.sh"
    chmod 0750 "$CONFIG_DIR/run.sh"
}

write_deployment_env() {
    local role="$1" domain="$2" direct_ip="$3" foreign_ports="$4" local_ports="${5:-}" foreign_provider="${6:-none}" iran_provider="${7:-none}"
    local iran_ip="${8:-}" entry_domain="${9:-}" entry_ports="${10:-}" entry_path="${11:-}" spoof_profile="${12:-chrome}" nginx_site="${13:-}"
    local wss_backend_port="${14:-}" h2_backend_port="${15:-}" target_port="${16:-}" pair_id="${17:-}"
    {
        printf 'ROLE=%q\n' "$role"
        printf 'TUNNEL_ID=%q\n' "$CURRENT_TUNNEL_ID"
        printf 'TUNNEL_NAME=%q\n' "$CURRENT_TUNNEL_NAME"
        printf 'PAIR_ID=%q\n' "$pair_id"
        printf 'FOREIGN_DOMAIN=%q\n' "$domain"
        printf 'FOREIGN_IP=%q\n' "$direct_ip"
        printf 'IRAN_IP=%q\n' "$iran_ip"
        printf 'FOREIGN_PORTS=%q\n' "$foreign_ports"
        printf 'LOCAL_PORTS=%q\n' "$local_ports"
        printf 'FOREIGN_PROXY_PROVIDER=%q\n' "$foreign_provider"
        printf 'IRAN_PROXY_PROVIDER=%q\n' "$iran_provider"
        printf 'IRAN_ENTRY_DOMAIN=%q\n' "$entry_domain"
        printf 'IRAN_ENTRY_PORTS=%q\n' "$entry_ports"
        printf 'IRAN_ENTRY_PATH=%q\n' "$entry_path"
        printf 'SPOOF_PROFILE=%q\n' "$spoof_profile"
        printf 'WSS_BACKEND_PORT=%q\n' "$wss_backend_port"
        printf 'H2_BACKEND_PORT=%q\n' "$h2_backend_port"
        printf 'TARGET_PORT=%q\n' "$target_port"
        printf 'CA_PATH=%q\n' "$ORIGIN_CA_PATH"
        printf 'LOCAL_TLS_CA_PATH=%q\n' "$LOCAL_TLS_CA_PATH"
        printf 'NGINX_SITE=%q\n' "$nginx_site"
        printf 'TRANSPORT=%q\n' "${transport:-wss}"
        printf 'XHTTP_PATH=%q\n' "${xhttp_path:-}"
        printf 'XHTTP_MODE=%q\n' "${xhttp_mode:-packet-up}"
        printf 'PADDING_BYTES=%q\n' "${padding_bytes:-0}"
        printf 'XHTTP_PADDING_BYTES=%q\n' "${xhttp_padding:-0}"
        printf 'CONNECT_HOST=%q\n' "${dial_host:-}"
        printf 'TLS_SNI=%q\n' "${tls_sni:-$domain}"
        printf 'HTTP_HOST=%q\n' "${http_host:-$domain}"
        printf 'ECH_SOURCE=%q\n' "${ech_source:-auto}"
        printf 'MUX_MODE=%q\n' "${mux_mode:-on}"
        printf 'ECH_MODE=%q\n' "${ech_mode:-off}"
        printf 'TLS_FRAGMENT=%q\n' "${tls_fragment:-off}"
        printf 'TLS_FRAGMENT_SIZE=%q\n' "${fragment_size:-100-200}"
        printf 'TLS_FRAGMENT_INTERVAL=%q\n' "${fragment_interval:-1-3ms}"
        printf 'IRAN_ENTRY_TRANSPORT=%q\n' "${entry_transport:-ws}"
        printf 'PATH_ROTATION=%q\n' "${path_rotation:-0}"
        printf 'PATH_COUNT=%q\n' "${path_count:-3}"
        printf 'PATH_GRACE=%q\n' "${path_grace:-5m}"
        printf 'PATH_LEGACY=%q\n' "${path_legacy:-false}"
        printf 'SESSION_RENEWAL=%q\n' "${session_renewal:-0}"
    } > "$CONFIG_DIR/deployment.env"
    chmod 0640 "$CONFIG_DIR/deployment.env"
    chown root:ununknowntun "$CONFIG_DIR/deployment.env"
}

write_ports_registry() {
    local value port
    : > "$CONFIG_DIR/ports.list"
    for value in "$@"; do
        for port in ${value//,/ }; do
            valid_port "$port" || continue
            printf '%s\n' "$((10#$port))" >> "$CONFIG_DIR/ports.list"
        done
    done
    sort -nu -o "$CONFIG_DIR/ports.list" "$CONFIG_DIR/ports.list"
    chmod 0640 "$CONFIG_DIR/ports.list"
    chown root:ununknowntun "$CONFIG_DIR/ports.list"
}

create_peer_code() {
    local domain="$1" direct_ip="$2" ports="$3" ws_path="$4" h2_path="$5" token="$6" target_port="$7" provider="${8:-none}" spoof_profile="${9:-chrome}"
    local iran_provider="${10:-none}" entry_path="${11:-}" pair_id="${12:-}"
    cat > "$CONFIG_DIR/peer.env" <<EOF
FORMAT=UNUNKNOWNTUN_V5_FLEET
TUNNEL_ID=$CURRENT_TUNNEL_ID
TUNNEL_NAME=$CURRENT_TUNNEL_NAME
PAIR_ID=$pair_id
DOMAIN=$domain
FOREIGN_IP=$direct_ip
PORTS=$ports
WS_PATH=$ws_path
H2_PATH=$h2_path
TOKEN=$token
TARGET_PORT=$target_port
FOREIGN_PROXY_PROVIDER=$provider
IRAN_PROXY_PROVIDER=$iran_provider
IRAN_ENTRY_PATH=$entry_path
SPOOF_PROFILE=$spoof_profile
TRANSPORT=${transport:-wss}
XHTTP_PATH=${xhttp_path:-$ws_path}
XHTTP_MODE=${xhttp_mode:-packet-up}
HTTP_HOST=${http_host:-$domain}
MUX_MODE=${mux_mode:-on}
IRAN_ENTRY_TRANSPORT=${entry_transport:-ws}
PATH_ROTATION=${path_rotation:-0}
PATH_COUNT=${path_count:-3}
PATH_GRACE=${path_grace:-5m}
PATH_LEGACY=${path_legacy:-false}
EOF
    chmod 0600 "$CONFIG_DIR/peer.env"
    chown root:root "$CONFIG_DIR/peer.env"
    base64 < "$CONFIG_DIR/peer.env" | tr -d '\n'
}

decode_peer_code() {
    local code="$1" temp key value seen=,
    code="${code//[[:space:]]/}"
    temp="$(mktemp /tmp/ununknowntun-peer.XXXXXX)"
    if ! printf '%s' "$code" | base64 -d > "$temp" 2>/dev/null; then
        rm -f "$temp"
        return 1
    fi
    PEER_FORMAT=""; PEER_TUNNEL_ID=""; PEER_TUNNEL_NAME=""; PEER_PAIR_ID=""; PEER_DOMAIN=""; PEER_FOREIGN_IP=""; PEER_PORTS=""; PEER_PATH=""; PEER_H2_PATH=""; PEER_TOKEN=""; PEER_TARGET_PORT=""; PEER_FOREIGN_PROXY_PROVIDER="none"; PEER_IRAN_PROXY_PROVIDER="none"; PEER_IRAN_ENTRY_PATH=""; PEER_SPOOF_PROFILE="chrome"
    PEER_TRANSPORT=auto; PEER_XHTTP_PATH=""; PEER_XHTTP_MODE=packet-up; PEER_MUX_MODE=on; PEER_IRAN_ENTRY_TRANSPORT=ws
    PEER_HTTP_HOST=""
    PEER_PATH_ROTATION=0; PEER_PATH_COUNT=3; PEER_PATH_GRACE=5m; PEER_PATH_LEGACY=false
    while IFS='=' read -r key value; do
        key="${key%$'\r'}"
        value="${value%$'\r'}"
        [[ "$seen" != *",$key,"* ]] || { rm -f "$temp"; return 1; }; seen+="$key,"
        case "$key" in
            FORMAT) PEER_FORMAT="$value" ;;
            TUNNEL_ID) PEER_TUNNEL_ID="$value" ;;
            TUNNEL_NAME) PEER_TUNNEL_NAME="$value" ;;
            PAIR_ID) PEER_PAIR_ID="$value" ;;
            DOMAIN) PEER_DOMAIN="$value" ;;
            FOREIGN_IP) PEER_FOREIGN_IP="$value" ;;
            PORTS) PEER_PORTS="$value" ;;
            WS_PATH) PEER_PATH="$value" ;;
            H2_PATH) PEER_H2_PATH="$value" ;;
            TOKEN) PEER_TOKEN="$value" ;;
            TARGET_PORT) PEER_TARGET_PORT="$value" ;;
            FOREIGN_PROXY_PROVIDER) PEER_FOREIGN_PROXY_PROVIDER="$value" ;;
            IRAN_PROXY_PROVIDER) PEER_IRAN_PROXY_PROVIDER="$value" ;;
            IRAN_ENTRY_PATH) PEER_IRAN_ENTRY_PATH="$value" ;;
            SPOOF_PROFILE) PEER_SPOOF_PROFILE="$value" ;;
            TRANSPORT) PEER_TRANSPORT="$value" ;;
            XHTTP_PATH) PEER_XHTTP_PATH="$value" ;;
            XHTTP_MODE) PEER_XHTTP_MODE="$value" ;;
            HTTP_HOST) PEER_HTTP_HOST="$value" ;;
            MUX_MODE) PEER_MUX_MODE="$value" ;;
            IRAN_ENTRY_TRANSPORT) PEER_IRAN_ENTRY_TRANSPORT="$value" ;;
            PATH_ROTATION) PEER_PATH_ROTATION="$value" ;;
            PATH_COUNT) PEER_PATH_COUNT="$value" ;;
            PATH_GRACE) PEER_PATH_GRACE="$value" ;;
            PATH_LEGACY) PEER_PATH_LEGACY="$value" ;;
            *) rm -f "$temp"; return 1 ;;
        esac
    done < "$temp"
    rm -f "$temp"
    if [[ "$PEER_FORMAT" == UNUNKNOWNTUN_V4_FLEET || "$PEER_FORMAT" == UNUNKNOWNTUN_V5_FLEET ]]; then
        for key in TRANSPORT XHTTP_PATH XHTTP_MODE MUX_MODE IRAN_ENTRY_TRANSPORT; do
            [[ "$seen" == *",$key,"* ]] || return 1
        done
    fi
    [[ "$seen" == *,TRANSPORT,* || "$PEER_FOREIGN_PROXY_PROVIDER" != arvan ]] || PEER_TRANSPORT=wss
    [[ -n "$PEER_XHTTP_PATH" ]] || PEER_XHTTP_PATH="$PEER_PATH"
    [[ -n "$PEER_HTTP_HOST" ]] || PEER_HTTP_HOST="$PEER_DOMAIN"
    valid_domain "$PEER_HTTP_HOST" || return 1
    validate_peer_path_profile || return 1
    if [[ "$PEER_PATH_ROTATION" != 0 ]]; then
        if [[ "$PEER_TRANSPORT" == xhttp ]]; then
            valid_xhttp_path "$PEER_XHTTP_PATH" || return 1
        else
            valid_xhttp_path "$PEER_PATH" || return 1
        fi
    fi
    [[ "$PEER_FORMAT" == "UNUNKNOWNTUN_V3_FLEET" || "$PEER_FORMAT" == "UNUNKNOWNTUN_V4_FLEET" || "$PEER_FORMAT" == "UNUNKNOWNTUN_V5_FLEET" ]] && valid_tunnel_id "$PEER_TUNNEL_ID" && [[ "$PEER_PAIR_ID" =~ ^[a-f0-9]{16}$ ]] && valid_domain "$PEER_DOMAIN" && valid_public_ipv4 "$PEER_FOREIGN_IP" &&
        PEER_PORTS="$(normalize_ports "$PEER_PORTS")" && valid_ws_path "$PEER_PATH" && valid_ws_path "$PEER_H2_PATH" &&
        [[ "$PEER_PATH" != "$PEER_H2_PATH" ]] &&
        valid_token "$PEER_TOKEN" && valid_port "$PEER_TARGET_PORT" &&
        [[ "$PEER_FOREIGN_PROXY_PROVIDER" =~ ^(none|cloudflare|arvan|fastly)$ ]] && [[ "$PEER_IRAN_PROXY_PROVIDER" =~ ^(none|cloudflare|arvan|fastly|nginx)$ ]] &&
        [[ "$PEER_TRANSPORT" =~ ^(auto|wss|h2|xhttp)$ && "$PEER_XHTTP_MODE" =~ ^(auto|packet-up|stream-up|stream-one)$ && "$PEER_MUX_MODE" =~ ^(on|off)$ && "$PEER_IRAN_ENTRY_TRANSPORT" =~ ^(ws|xhttp)$ ]] &&
        { [[ "$PEER_TRANSPORT" != xhttp ]] || valid_xhttp_path "$PEER_XHTTP_PATH"; } &&
        { [[ "$PEER_FOREIGN_PROXY_PROVIDER" != fastly ]] || [[ "$PEER_TRANSPORT" == xhttp ]]; } &&
        { [[ "$PEER_IRAN_PROXY_PROVIDER" != fastly ]] || [[ "$PEER_IRAN_ENTRY_TRANSPORT" == xhttp ]]; } &&
        { [[ "$PEER_IRAN_PROXY_PROVIDER" == none && -z "$PEER_IRAN_ENTRY_PATH" ]] || valid_ws_path "$PEER_IRAN_ENTRY_PATH"; } &&
        [[ "$PEER_SPOOF_PROFILE" =~ ^(chrome|firefox|ios)$ ]] || return 1
    if [[ "$PEER_FORMAT" != UNUNKNOWNTUN_V5_FLEET ]]; then
        warn "Imported a legacy pairing code. Upgrade BOTH peers to 3.5 before using this pair, especially XHTTP (3.5 packet pipeline is not compatible with the old XHTTP receiver)."
    fi
    if [[ "$PEER_TRANSPORT" == auto || "$PEER_TRANSPORT" == h2 ]]; then
        warn "Legacy auto/h2 transport is migrated to normal WSS; gRPC is removed. Upgrade the paired server too."
        PEER_TRANSPORT=wss
    fi
    return 0
}

install_foreign() {
    require_root
    acquire_install_lock
    detect_os
    migrate_legacy_install_if_needed
    prepare_tunnel_context new "foreign-$(( $(tunnel_count) + 1 ))"
    ensure_preflight_tools
    printf '\n%s=== Reverse Tunnel: Foreign Server / Egress ===%s\n' "$CYAN" "$RESET"
    local domain direct_ip detected_ip ports default_ports backend_port h2_backend_port target_port cert_choice email cert_path key_path token pair_id ws_path h2_path peer_code
    local foreign_provider iran_provider spoof_choice spoof_profile suggested_backend suggested_h2 client_entry_path="" detected_targets suggested_target recovery
    local transport=wss xhttp_path mux_mode=on entry_transport=ws
    local xhttp_mode=packet-up padding_bytes=0 xhttp_padding=0
    local path_rotation=0 path_count=3 path_grace=5m path_legacy=false
    select_proxy_provider foreign_provider "Foreign server"
    select_proxy_provider iran_provider "Iran client entry"
    select_tunnel_profile
    select_path_profile
    select_entry_profile
    if [[ "$iran_provider" != none ]]; then
        client_entry_path="$(random_ws_path)"
        printf '\nThe Iran entry will be proxied. The dedicated Xray inbound on this foreign server must use:\n'
        printf '  Transport: %s\n  TLS on Xray inbound: disabled\n  Client path: %s\n' "$entry_transport" "$client_entry_path"
        printf 'UNUNKNOWNTUN and the Iran Nginx front end provide the encrypted outer paths.\n\n'
    fi
    ask_valid domain "Tunnel domain configured for the selected foreign proxy mode" "" valid_domain "Invalid domain. Example: tunnel.example.com."
    domain="$(lower_ascii "$domain")"
    detected_ip="$(detect_public_ipv4 || true)"
    ask_valid direct_ip "Foreign server public IPv4 address" "$detected_ip" valid_public_ipv4 "Invalid or non-public foreign IPv4 address."
    confirm_dns_settings domain direct_ip foreign_provider
    while ! check_nginx_domain_conflicts "$domain"; do
        ask_valid domain "Choose a separate tunnel domain (or re-enter after fixing Nginx)" "" valid_domain "Invalid domain."
        confirm_dns_settings domain direct_ip foreign_provider
    done
    default_ports="$(proxy_default_ports "$foreign_provider")"
    ask_ports ports "Public HTTPS ports in priority order, separated by commas" "$default_ports" "$foreign_provider" nginx 80
    detected_targets="$(discover_xray_loopback_ports || true)"
    suggested_target="$(printf '%s\n' "$detected_targets" | head -n1)"
    suggested_target="${suggested_target:-18082}"
    if [[ -n "$detected_targets" ]]; then
        printf 'Detected loopback Xray listener port(s): %s\n' "$(printf '%s' "$detected_targets" | paste -sd, -)"
    else
        warn "No loopback Xray inbound was detected. Create a dedicated inbound before continuing."
    fi
    ask_target_port "$suggested_target" "80,$ports"
    select_backend_ports "$ports,$target_port"
    while ! preflight_foreign_inputs "$domain" "$direct_ip" "$ports" "$backend_port" "$h2_backend_port" "$target_port" "$foreign_provider"; do
        printf '\n1) Recheck after correcting the reported server/network setting\n2) Correct target inbound port\n3) Correct domain/proxy/public ports\n'
        ask_valid recovery "Repair foreign preflight" 1 valid_three_choices "Select 1, 2, or 3."
        case "$recovery" in
            1) ;;
            2) ask_target_port "$target_port" "80,$ports" ;;
            3)
                correct_foreign_settings
                ask_ports ports "Public HTTPS ports" "$ports" "$foreign_provider" nginx "80,$target_port"
                ;;
        esac
        select_backend_ports "$ports,$target_port"
    done
    printf '\nTraffic camouflage profile:\n  1) Chrome (recommended)\n  2) Firefox\n  3) iOS\n'
    ask_valid spoof_choice "Select a profile" "1" valid_three_choices "Select 1, 2, or 3."
    case "$spoof_choice" in 1) spoof_profile=chrome;; 2) spoof_profile=firefox;; 3) spoof_profile=ios;; *) die "Invalid camouflage profile.";; esac
    ask_certificate_settings "$domain"
    select_padding_profile
    printf '\n%sAll foreign preflight checks passed.%s\n' "$GREEN" "$RESET"
    while ! validate_selected_profile; do
        select_proxy_provider foreign_provider "Foreign server"
        select_proxy_provider iran_provider "Iran client entry"
        select_tunnel_profile
        select_entry_profile
        if [[ "$iran_provider" != none && -z "$client_entry_path" ]]; then client_entry_path="$(random_ws_path)"; fi
        [[ "$iran_provider" == none ]] || printf 'Configure the dedicated Xray inbound: transport=%s, TLS disabled, path=%s\n' "$entry_transport" "$client_entry_path"
        confirm_dns_settings domain direct_ip foreign_provider
        ask_ports ports "Public HTTPS ports" "$ports" "$foreign_provider" nginx "80,$target_port,$backend_port,$h2_backend_port"
    done
    yes_no "Proceed with the foreign side of the reverse tunnel?" "y" || exit 0
    transaction_begin egress "$domain"

    token="$(random_hex 32)"
    pair_id="$(pair_id_from_token "$token")"
    ws_path="$(random_ws_path)"
    xhttp_path="$ws_path"
    h2_path="$(random_ws_path)"
    while [[ "$h2_path" == "$ws_path" ]]; do
        h2_path="$(random_ws_path)"
    done
    TX_NGINX_TOUCHED=1
    retry_step "dependency installation" install_foreign_packages "$cert_choice"
    make_decoy_site
    if [[ "$cert_choice" == "1" ]]; then
        show_acme_proxy_guidance "$foreign_provider" "$domain"
        open_ufw_ports 80
        write_http_challenge_site "$domain"
        obtain_certificate_with_retry "$domain"
        install_certbot_reload_hook
    elif [[ "$cert_path" == /etc/letsencrypt/live/* ]]; then
        install_certbot_reload_hook
    fi

    write_common_files "egress"
    write_token_file "$token"
    write_foreign_run_script "$domain" "$ws_path" "$backend_port" "$h2_path" "$h2_backend_port" "$target_port"
	systemctl stop "$SERVICE" >/dev/null 2>&1 || true
    write_nginx_wss_site "$domain" "$ports" "$ws_path" "$backend_port" "$h2_path" "$h2_backend_port" "$cert_path" "$key_path"
    write_deployment_env "egress" "$domain" "$direct_ip" "$ports" "" "$foreign_provider" "$iran_provider" "" "" "" "$client_entry_path" "$spoof_profile" "$NGINX_SITE_DIR/ununknowntun-$domain.conf" "$backend_port" "$h2_backend_port" "$target_port" "$pair_id"
    write_ports_registry "$ports" "$backend_port" "$h2_backend_port" "$target_port"
    peer_code="$(create_peer_code "$domain" "$direct_ip" "$ports" "$ws_path" "$h2_path" "$token" "$target_port" "$foreign_provider" "$spoof_profile" "$iran_provider" "$client_entry_path" "$pair_id")"
    if [[ "$SCRIPT_PATH" != "$INSTALL_DIR/share/ununknowntun-easy.sh" ]]; then
        install -o root -g root -m 0700 "$SCRIPT_PATH" "$INSTALL_DIR/share/ununknowntun-easy.sh"
    else
        chmod 0700 "$SCRIPT_PATH"
    fi
    cp -f "$BIN_PATH" "$INSTALL_DIR/share/ununknowntun-linux-$(case "$(uname -m)" in x86_64) echo amd64;; *) echo arm64;; esac)"
    chmod 0755 "$INSTALL_DIR/share"/ununknowntun-linux-*

    setup_safe_tcp_tuning
    open_ufw_ports "80,$ports"
    systemctl enable "$SERVICE"
    systemctl restart "$SERVICE"
    SERVICE_INVOCATION="$(systemctl show "$SERVICE" -p InvocationID --value)"
    sleep 2
    systemctl is-active --quiet "$SERVICE" || { journalctl -u "$SERVICE" -n 80 --no-pager; die "The egress service failed to start."; }
    [[ "$SERVICE_INVOCATION" =~ ^[0-9a-fA-F]{32}$ && "$(systemctl show "$SERVICE" -p InvocationID --value)" == "$SERVICE_INVOCATION" ]] || die "The egress service restarted during startup validation."
    nginx -t
    retry_step "foreign HTTPS endpoint verification" verify_foreign_reverse_endpoint "$domain" "$ports"
    if [[ "${path_rotation:-0}" != 0 ]]; then
        retry_step "authenticated local rotating carrier" probe_rotating_foreign "$domain" 127.0.0.1 "${ports%%,*}" "$LOCAL_TLS_CA_PATH"
    elif [[ "$transport" == xhttp ]]; then
        retry_step "authenticated local origin XHTTP route" probe_websocket_path "$domain" 127.0.0.1 "${ports%%,*}" "$xhttp_path" "$token" "$LOCAL_TLS_CA_PATH" 1.2 xhttp
    else
        retry_step "authenticated local origin WebSocket upgrade" probe_websocket_path "$domain" 127.0.0.1 "${ports%%,*}" "$ws_path" "$token" "$LOCAL_TLS_CA_PATH" 1.2
    fi
    if [[ "$foreign_provider" != none ]]; then
        show_proxy_guidance "$foreign_provider" "$domain" "$ws_path"
        if [[ "${path_rotation:-0}" != 0 ]]; then
            retry_step "authenticated CDN rotating carrier" probe_rotating_foreign "$domain" "$domain" "${ports%%,*}" /etc/ssl/certs/ca-certificates.crt
        elif [[ "$transport" != xhttp ]]; then
            retry_step "CDN WebSocket upgrade" probe_websocket_path "$domain" "$domain" "${ports%%,*}" "$ws_path" "$token" /etc/ssl/certs/ca-certificates.crt 1.2
        else
            retry_step "authenticated CDN XHTTP route" probe_websocket_path "$domain" "$domain" "${ports%%,*}" "$xhttp_path" "$token" /etc/ssl/certs/ca-certificates.crt 1.2 xhttp
        fi
    fi
    tcp_probe 127.0.0.1 "$target_port" 3 || die "The target stopped accepting TCP during installation."

    cat > "$CONFIG_DIR/client-info.txt" <<EOF
UNUNKNOWNTUN V3 - REVERSE TUNNEL - FOREIGN/EGRESS
Domain: $domain
Direct foreign IP: $direct_ip
Public HTTPS ports: $ports
WebSocket path: $ws_path
HTTP/2 path: $h2_path
XHTTP path: $xhttp_path
MUX: $mux_mode
WSS backend: 127.0.0.1:$backend_port
HTTP/2 backend: 127.0.0.1:$h2_backend_port
Allowed Xray/Panel inbound: 127.0.0.1:$target_port
ECH: disabled
Foreign proxy mode: $(proxy_summary "$foreign_provider")
Iran proxy mode: $(proxy_summary "$iran_provider")
Camouflage profile: $spoof_profile
Transport: $(transport_summary "$foreign_provider")

Inbound configuration on the foreign-server panel:
  Listen IP = 127.0.0.1
  Port      = $target_port
  Use a separate inbound for this tunnel; do not modify an existing Native Reverse inbound.
$(if [[ "$iran_provider" == none ]]; then
    printf '  Direct Iran entry: keep the intended protocol/UUID/security settings identical between the inbound and clients.\n'
else
    printf '  Proxied Iran entry: Transport = %s, TLS = disabled on this loopback inbound, Path = %s\n' "$entry_transport" "$client_entry_path"
    [[ "$entry_transport" != xhttp ]] || printf '  XHTTP entry mode = packet-up (configure/test the Xray inbound separately)\n'
fi)

Validation: local target TCP and HTTPS front-end only. No Xray protocol traffic has been tested.

To display the Iran installation code again, run:
  ununknowntunctl peer-code $CURRENT_TUNNEL_ID
EOF
    chmod 0640 "$CONFIG_DIR/client-info.txt"
    chown root:ununknowntun "$CONFIG_DIR/client-info.txt"

    transaction_commit
    printf '\n%sForeign transport endpoint installed; real-client traffic validation is still required.%s\n' "$GREEN" "$RESET"
    printf 'Paste this confidential code into the Iran server installer:\n\n%s\n\n' "$peer_code"
    printf 'Foreign inbound: 127.0.0.1:%s\n' "$target_port"
    printf 'Monitor: ununknowntunctl monitor %s\nLogs: ununknowntunctl logs %s\n' "$CURRENT_TUNNEL_ID" "$CURRENT_TUNNEL_ID"
}

copy_ca_from_foreign() {
    local ssh_host ssh_port ssh_user
    ask ssh_host "Foreign server SSH IP address or hostname for retrieving the CA bundle"
    ask_valid ssh_port "SSH port" "22" valid_port "Invalid SSH port."
    ask ssh_user "SSH user" "root"
    command -v scp >/dev/null 2>&1 || die "scp is not installed."
    scp -P "$ssh_port" "$ssh_user@$ssh_host:/etc/ssl/certs/ca-certificates.crt" "$CONFIG_DIR/ca-bundle.pem"
    chmod 0644 "$CONFIG_DIR/ca-bundle.pem"
}

install_origin() {
    require_root
    acquire_install_lock
    detect_os
    migrate_legacy_install_if_needed
    ensure_preflight_tools
    printf '\n%s=== Reverse Tunnel: Iran Server / Origin ===%s\n' "$CYAN" "$RESET"
    local code domain direct_ip foreign_ports ws_path h2_path token pair_id="" target_port entry_domain="" local_ports sessions pad total_quota_gb
    local foreign_provider iran_provider iran_ip detected_iran_ip entry_ports="" entry_path="" spoof_profile=chrome ech_mode=off
    local transport=wss xhttp_path mux_mode=on tls_fragment=off fragment_size=100-200 fragment_interval=1-3ms entry_transport=ws
    local xhttp_mode=packet-up padding_bytes=0 xhttp_padding=0 ech_source=auto dial_host="" tls_sni="" http_host="" clean_scan=no scan_auto=no scan_seconds=300 scan_count=64 scan_hours=8
    local path_rotation=0 path_count=3 path_grace=5m path_legacy=false session_renewal=0
    local existing_count first_answer suggested_local cert_choice="" email="" cert_path="" key_path="" tx_domain="" nginx_site="" recovery
    existing_count="$(tunnel_count)"
    if yes_no "Is this the first tunnel on this Iran server?" "$([[ "$existing_count" == 0 ]] && echo y || echo n)"; then
        first_answer=yes
    else
        first_answer=no
    fi
    if [[ "$existing_count" == 0 && "$first_answer" == no ]]; then
        warn "No registered tunnel was found; this installation will be treated as the first tunnel."
    elif [[ "$existing_count" != 0 && "$first_answer" == yes ]]; then
        warn "$existing_count existing tunnel(s) were detected; this installation will be added without replacing them."
    fi
    while true; do
        ask code "Connection code generated on the foreign server (leave empty for manual entry)"
        [[ -n "$code" ]] || break
        decode_peer_code "$code" && break
        warn "The connection code is corrupted or invalid. Paste the complete code again; earlier answers are retained."
    done
    if [[ -n "$code" ]]; then
        domain="$PEER_DOMAIN"; direct_ip="$PEER_FOREIGN_IP"; foreign_ports="$PEER_PORTS"; ws_path="$PEER_PATH"; h2_path="$PEER_H2_PATH"; token="$PEER_TOKEN"; target_port="$PEER_TARGET_PORT"
        foreign_provider="$PEER_FOREIGN_PROXY_PROVIDER"; iran_provider="$PEER_IRAN_PROXY_PROVIDER"; entry_path="$PEER_IRAN_ENTRY_PATH"; spoof_profile="$PEER_SPOOF_PROFILE"; pair_id="$PEER_PAIR_ID"
        transport="$PEER_TRANSPORT"; xhttp_path="$PEER_XHTTP_PATH"; mux_mode="$PEER_MUX_MODE"; entry_transport="$PEER_IRAN_ENTRY_TRANSPORT"
        xhttp_mode="$PEER_XHTTP_MODE"
        path_rotation="$PEER_PATH_ROTATION"; path_count="$PEER_PATH_COUNT"; path_grace="$PEER_PATH_GRACE"; path_legacy="$PEER_PATH_LEGACY"
        http_host="$PEER_HTTP_HOST"
        prepare_tunnel_context new "$PEER_TUNNEL_ID" "$PEER_TUNNEL_NAME"
        printf 'Selected pair: Iran = %s, foreign = %s.\n' "$(proxy_summary "$iran_provider")" "$(proxy_summary "$foreign_provider")"
        printf 'Paired carrier: %s | MUX: %s | Independent Iran client entry: %s\n' "$transport" "$mux_mode" "$entry_transport"
        info "Transport and MUX were imported from the paired server. Later changes use Manage/Edit and a signed peer synchronization code."
        if ! yes_no "Are these proxy modes correct?" y; then
            select_proxy_provider foreign_provider "Foreign server"
            select_proxy_provider iran_provider "Iran client entry"
            warn "Set the foreign CDN/panel to match these corrected modes. Connection paths and token are retained."
        fi
    else
        prepare_tunnel_context new "origin-$((existing_count + 1))"
        select_proxy_provider foreign_provider "Foreign server"
        select_proxy_provider iran_provider "Iran client entry"
        select_tunnel_profile
        select_path_profile
        select_entry_profile
        ask_valid domain "Foreign server HTTPS domain" "" valid_domain "Invalid foreign-server domain."
        domain="$(lower_ascii "$domain")"
        ask_valid direct_ip "Foreign server direct public IPv4 address" "" valid_public_ipv4 "Invalid or non-public foreign IPv4 address."
        ask_ports foreign_ports "Foreign HTTPS ports in priority order" "$(proxy_default_ports "$foreign_provider")" "$foreign_provider" - 80
        ask_valid ws_path "Confidential transport base path from the foreign endpoint" "" valid_transport_seed "Use the foreign endpoint's path (16-512 letters, digits, /, _ or -); rotating paths cannot contain double slashes."
        xhttp_path="$ws_path"
        if [[ "$transport" == xhttp ]]; then
            ask_valid xhttp_path "Confidential XHTTP path from the foreign endpoint" "$ws_path" valid_xhttp_path "Enter a clean absolute XHTTP base path (16-512 characters, no double slashes)."
        fi
        h2_path="$(random_ws_path)"
        ask_valid token "Shared token" "" valid_token "The token must contain at least 16 characters."
        ask_valid target_port "Inbound port on the foreign server" "8080" valid_port "Invalid target port."
        target_port="$((10#$target_port))"
    fi
    [[ -n "$pair_id" ]] || pair_id="$(pair_id_from_token "$token")"
    confirm_dns_settings domain direct_ip foreign_provider
    if [[ "$iran_provider" != none && -z "$entry_path" ]]; then
        ask_valid entry_path "Exact $entry_transport path configured on the dedicated foreign Xray inbound" "" valid_ws_path "Enter the matching Xray client-entry path."
    fi

    detected_iran_ip="$(detect_public_ipv4 || true)"
    ask_valid iran_ip "Iran server public IPv4 address" "$detected_iran_ip" valid_public_ipv4 "Invalid or non-public Iran IPv4 address."

    if [[ "$iran_provider" == none ]]; then
        while true; do
            ask entry_domain "Optional direct domain clients will use instead of the Iran server IP address"
            [[ -n "$entry_domain" ]] || break
            entry_domain="$(lower_ascii "$entry_domain")"
            valid_domain "$entry_domain" || { warn "Invalid Iran entry domain; enter it again or leave empty."; continue; }
            confirm_dns_settings entry_domain iran_ip iran_provider
            break
        done
    fi
    if [[ "$iran_provider" == none ]]; then
        suggested_local="$(next_free_port 2053 65535)" || die "No free Iran client entry port was found."
        ask_ports local_ports "Client entry port or ports on the Iran server" "$suggested_local" none '' 80
        entry_ports="$local_ports"
    else
        while true; do
            ask_valid entry_domain "Iran HTTPS entry domain (CDN or standalone Nginx)" "$entry_domain" valid_domain "Invalid Iran entry domain."
            entry_domain="$(lower_ascii "$entry_domain")"
            confirm_dns_settings entry_domain iran_ip iran_provider
            check_nginx_domain_conflicts "$entry_domain" && break
        done
        if [[ "$iran_provider" == none ]]; then
            suggested_local="$(next_free_port 2053 65535)" || die "No free Iran client entry port was found."
            ask_ports local_ports "Client entry port or ports on the Iran server" "$suggested_local" none '' 80
            entry_ports="$local_ports"
        else
        ask_ports entry_ports "Public HTTPS ports exposed by Iran Nginx/CDN" "$(proxy_default_ports "$iran_provider")" "$iran_provider" nginx 80
        suggested_local="$(next_free_port 19080 19999)" || die "No free internal Iran backend port was found."
        local_ports="$suggested_local"
        if [[ -z "$entry_path" ]]; then
            ask_valid entry_path "Exact $entry_transport path on the dedicated foreign Xray inbound" "" valid_ws_path "Enter the matching Xray client-entry path."
        fi
        retry_step "shared Iran HTTP/ACME port availability" check_port_conflicts 80 nginx "Iran ACME"
        ask_certificate_settings "$entry_domain"
        fi
    fi

    if [[ "$mux_mode" == off ]]; then
        ask_valid sessions "Maximum concurrent dedicated sessions (MUX OFF; minimum pool ignored)" "32" valid_sessions "The dedicated session limit must be between 2 and 32."
    else
        ask_valid sessions "Maximum adaptive sessions (8 is recommended; maximum 32)" "8" valid_sessions "The maximum session count must be between 2 and 32."
    fi
    sessions="$((10#$sessions))"
    select_session_renewal
    pad=0
    select_dial_profile
    select_tls_handshake_profile
    select_padding_profile
    ask_valid total_quota_gb "Total tunnel traffic allowance in GB (upload + download; 0 = unlimited)" "0" valid_quota_gb "Enter a non-negative GB amount; 0 means unlimited."

    retry_step "CA trust store setup" install_ca_if_needed
    while ! preflight_origin_path "$domain" "$direct_ip" "$foreign_ports" "$local_ports" "$foreign_provider" "$iran_provider"; do
        printf '\n1) Recheck after fixing the reported issue\n2) Correct foreign DNS/proxy/ports\n3) Correct Iran listener ports\n'
        ask_valid recovery "Repair Iran preflight" 1 valid_three_choices "Select 1, 2, or 3."
        case "$recovery" in
            1) ;;
            2)
                correct_foreign_settings
                ask_ports foreign_ports "Foreign HTTPS ports" "$foreign_ports" "$foreign_provider" - 80
                ;;
            3)
                ask_ports local_ports "Iran listener ports" "$local_ports" none '' "$([[ "$iran_provider" == none ]] && echo 80 || echo "80,$entry_ports")"
                [[ "$iran_provider" != none ]] || entry_ports="$local_ports"
                ;;
        esac
    done
    show_proxy_guidance "$foreign_provider" "$domain" "$ws_path"
    while ! validate_selected_profile; do
        select_proxy_provider foreign_provider "Foreign server (must match paired transport)"
        confirm_dns_settings domain direct_ip foreign_provider
        ask_ports foreign_ports "Foreign HTTPS ports" "$foreign_ports" "$foreign_provider" - 80
        if [[ "$iran_provider" == fastly && "$entry_transport" != xhttp ]]; then select_entry_profile; fi
    done
    if [[ "$ech_mode" == strict || "$tls_fragment" == hello || "$clean_scan" == yes || -n "$dial_host" || "$tls_sni" != "$domain" || "$http_host" != "$domain" || "$transport" == xhttp || "$path_rotation" != 0 ]]; then
        warn "Selected TLS handshake will be validated by the actual tunnel, not a plain TLS preflight."
    else
        confirm_foreign_websocket
    fi
    printf '\n%sBoth servers are ready for the reverse tunnel.%s\n' "$GREEN" "$RESET"
    yes_no "Start and validate the reverse tunnel now?" "y" || exit 0
    [[ "$iran_provider" == none ]] || tx_domain="$entry_domain"
    transaction_begin origin "$tx_domain"

    write_common_files "origin"
    write_token_file "$token"
    if [[ "$ORIGIN_CA_PATH" == "$CONFIG_DIR/ca-bundle.pem" ]]; then
        chown root:ununknowntun "$ORIGIN_CA_PATH"
        chmod 0640 "$ORIGIN_CA_PATH"
    fi
    if [[ "$iran_provider" != none ]]; then
        TX_NGINX_TOUCHED=1
        retry_step "dependency installation" install_foreign_packages "$cert_choice"
        make_decoy_site
        if [[ "$cert_choice" == 1 ]]; then
            show_acme_proxy_guidance "$iran_provider" "$entry_domain"
            open_ufw_ports 80
            write_http_challenge_site "$entry_domain"
            obtain_certificate_with_retry "$entry_domain"
            install_certbot_reload_hook
        elif [[ "$cert_path" == /etc/letsencrypt/live/* ]]; then
            install_certbot_reload_hook
        fi
        write_nginx_origin_proxy_site "$entry_domain" "$entry_ports" "$entry_path" "${local_ports%%,*}" "$cert_path" "$key_path"
        nginx_site="$NGINX_SITE_DIR/ununknowntun-$entry_domain.conf"
    fi
    write_origin_run_script "$domain" "$direct_ip" "$foreign_ports" "$ws_path" "$h2_path" "$target_port" "$local_ports" "$sessions" "$pad" "$foreign_provider" "$iran_provider" "$spoof_profile" "$ech_mode"
    write_deployment_env "origin" "$domain" "$direct_ip" "$foreign_ports" "$local_ports" "$foreign_provider" "$iran_provider" "$iran_ip" "$entry_domain" "$entry_ports" "$entry_path" "$spoof_profile" "$nginx_site" "" "" "$target_port" "$pair_id"
    initialize_customer_access "$local_ports" "$total_quota_gb" "$iran_provider"
    write_ports_registry "$local_ports" "$entry_ports"
    write_cdn_settings
    if [[ "$clean_scan" == yes ]]; then
        retry_step "authenticated Cloudflare scan" python3 "$INSTALL_DIR/share/cdn-control.py" scan --config-dir "$CONFIG_DIR" --initial-lock-fd 9
    fi
    while ! python3 "$INSTALL_DIR/share/cdn-control.py" verify --config-dir "$CONFIG_DIR"; do
        printf '\n1) Retry after correcting the paired/CDN endpoint\n2) Correct connection address, SNI/Host, ECH/fragment and padding here\n3) Cancel safely\n'
        ask_valid recovery "Repair the reported carrier error (other answers retained)" 1 valid_three_choices "Choose 1-3."
        case "$recovery" in
            1) ;;
            2)
                select_dial_profile
                select_tls_handshake_profile
                select_padding_profile
                write_origin_run_script "$domain" "$direct_ip" "$foreign_ports" "$ws_path" "$h2_path" "$target_port" "$local_ports" "$sessions" "$pad" "$foreign_provider" "$iran_provider" "$spoof_profile" "$ech_mode"
                write_deployment_env "origin" "$domain" "$direct_ip" "$foreign_ports" "$local_ports" "$foreign_provider" "$iran_provider" "$iran_ip" "$entry_domain" "$entry_ports" "$entry_path" "$spoof_profile" "$nginx_site" "" "" "$target_port" "$pair_id"
                write_cdn_settings
                [[ "$clean_scan" != yes ]] || retry_step "authenticated Cloudflare scan" python3 "$INSTALL_DIR/share/cdn-control.py" scan --config-dir "$CONFIG_DIR" --initial-lock-fd 9
                ;;
            3) die "Carrier validation cancelled; restoring previous installation state." ;;
        esac
    done
    setup_safe_tcp_tuning
    if [[ "$iran_provider" == none ]]; then open_ufw_ports "$local_ports"; else open_ufw_ports "80,$entry_ports"; fi
    systemctl enable "$SERVICE"
    systemctl restart "$SERVICE"
    SERVICE_INVOCATION="$(systemctl show "$SERVICE" -p InvocationID --value)"
    sleep 4
    while ! verify_origin_reverse_tunnel "2"; do
        warn "Correct the reported tunnel/CDN issue. Previous answers and the current installation are retained during retry."
        yes_no "Retry tunnel validation?" y || die "Tunnel validation cancelled."
        SERVICE_INVOCATION="$(systemctl show "$SERVICE" -p InvocationID --value)"
    done
    if [[ "$iran_provider" != none && "$entry_transport" == ws ]]; then
        show_proxy_guidance "$iran_provider" "$entry_domain" "$entry_path"
        retry_step "Iran local origin client WebSocket route" probe_websocket_path "$entry_domain" 127.0.0.1 "${entry_ports%%,*}" "$entry_path" "" "$LOCAL_TLS_CA_PATH" 1.2
        retry_step "Iran public client WebSocket route" probe_websocket_path "$entry_domain" "$entry_domain" "${entry_ports%%,*}" "$entry_path" "" /etc/ssl/certs/ca-certificates.crt 1.2
    fi
    if [[ "$iran_provider" != none && "$entry_transport" == xhttp ]]; then
        warn "Iran XHTTP client entry requires a real Xray packet-up client test. Tunnel session health alone does not validate this independent route."
    fi

    local client_address first_port
    client_address="${entry_domain:-$iran_ip}"
    if [[ "$iran_provider" == none ]]; then first_port="${local_ports%%,*}"; else first_port="${entry_ports%%,*}"; fi
    cat > "$CONFIG_DIR/client-info.txt" <<EOF
UNUNKNOWNTUN V3 - REVERSE TUNNEL - IRAN/ORIGIN
Foreign transport endpoint: $domain ports $foreign_ports
Direct foreign IP: $direct_ip
ECH: $ech_mode
TLS ClientHello fragmentation: $tls_fragment ($fragment_size bytes, $fragment_interval; experimental)
MUX: $mux_mode
XHTTP base path: $xhttp_path
Foreign proxy mode: $(proxy_summary "$foreign_provider")
Iran proxy mode: $(proxy_summary "$iran_provider")
Camouflage profile: $spoof_profile
Transport: $(transport_summary "$foreign_provider")
Iran internal listeners: $local_ports
Iran client address: $client_address
Foreign Xray inbound target: 127.0.0.1:$target_port
Sessions: $sessions maximum (MUX OFF: dedicated concurrency limit; minimum pool ignored)
Padding: $pad
Total tunnel allowance: $total_quota_gb GB (0 = unlimited; upload + download combined)
Customer management: ununknowntunctl customers $CURRENT_TUNNEL_ID
Customer-only connection export: ununknowntunctl customer-export $CURRENT_TUNNEL_ID CUSTOMER_ID

Inbound format on the foreign-server panel:
  Listen IP = 127.0.0.1
  Port      = $target_port

Client address format:
  Address   = $client_address
  Port      = $first_port   (or one of: $entry_ports)
$(if [[ "$iran_provider" == none ]]; then
    printf '  Transport/security/UUID = exactly the same as the dedicated foreign inbound\n'
else
    printf '  Transport = %s\n  Client entry path = %s\n  TLS = enabled on the client\n  SNI/Host = %s\n  UUID = exactly the same as the dedicated foreign inbound\n' "$entry_transport" "$entry_path" "$entry_domain"
    [[ "$entry_transport" != xhttp ]] || printf '  XHTTP entry mode = packet-up\n'
fi)

Do not publish an AAAA record unless this installation is explicitly configured for IPv6.
Validation: transport sessions only. Xray authentication, payload traffic, and sustained throughput require a real-client test before production use.
EOF
    chmod 0640 "$CONFIG_DIR/client-info.txt"
    chown root:ununknowntun "$CONFIG_DIR/client-info.txt"

    if systemctl is-active --quiet "$SERVICE"; then
        info "The origin service is active."
    else
        journalctl -u "$SERVICE" -n 100 --no-pager
        die "The origin service failed to start."
    fi
    if journalctl "_SYSTEMD_INVOCATION_ID=$SERVICE_INVOCATION" --no-pager | grep -q 'session established'; then
        info "At least one reverse session connected to the foreign server."
    else
        warn "The service is active, but no session is connected yet. Check it with: ununknowntunctl test $CURRENT_TUNNEL_ID"
    fi

    transaction_commit
    printf '\n%sTransport installation and session validation completed; Xray traffic is not yet validated.%s\n' "$GREEN" "$RESET"
    if [[ "$scan_auto" == yes ]]; then
        python3 "$INSTALL_DIR/share/cdn-control.py" schedule --config-dir "$CONFIG_DIR" --initial-lock-fd 9
    fi
    cat "$CONFIG_DIR/client-info.txt"
    printf '\nMonitor: ununknowntunctl monitor %s\nStop: ununknowntunctl stop %s\nStart: ununknowntunctl start %s\n' "$CURRENT_TUNNEL_ID" "$CURRENT_TUNNEL_ID" "$CURRENT_TUNNEL_ID"
    printf 'Sell a separate port/access: ununknowntunctl customer-add %s\nUsage and remaining traffic: ununknowntunctl usage %s\n' "$CURRENT_TUNNEL_ID" "$CURRENT_TUNNEL_ID"
}

patch_upgrade_configuration() {
    python3 - "$CONFIG_DIR" "$TUNNEL_STATE_DIR" "$(nginx_rotation_pattern wss)" "$(nginx_rotation_pattern xhttp)" <<'PY'
from pathlib import Path
import re, shlex, sys
directory, state = map(Path, sys.argv[1:3])
rotation_patterns = dict(zip(('wss', 'xhttp'), sys.argv[3:5]))
env = {}
for line in (directory / 'deployment.env').read_text().splitlines():
    if '=' not in line or line.startswith('#'): continue
    key, value = line.split('=', 1)
    parts = shlex.split(value)
    env[key] = parts[0] if parts else ''
run = directory / 'run.sh'
source = run.read_text()
for managed in ('transport', 'tls-min-version', 'ech-mode', 'tls-fragment', 'tls-fragment-size', 'tls-fragment-interval', 'mux', 'pad', 'xhttp-path', 'xhttp-mode'):
    if len(re.findall(r'(?m)^\s*-' + re.escape(managed) + r'\s+', source)) > 1:
        raise SystemExit('Duplicate launch flag: -' + managed)
def flag(name, value):
    global source
    pattern = r'(?m)^(\s*)' + re.escape(name) + r'\s+[^\s\\]+(\s*\\?)$'
    matches = list(re.finditer(pattern, source))
    if len(matches) > 1: raise SystemExit('Duplicate launch flag: ' + name)
    if matches:
        source = re.sub(pattern, lambda m: m[1] + name + ' ' + value + m[2], source)
    else:
        marker = re.search(r'(?m)^\s*-mode (?:origin|egress)\s+\\$', source)
        if not marker: raise SystemExit('Unrecognized managed origin/egress launch script; not changed.')
        source = source[:marker.end()] + '\n  ' + name + ' ' + value + ' \\' + source[marker.end():]
def read_flag(name, fallback=''):
    matches = re.findall(r'(?m)^[ \t]*-' + re.escape(name) + r'[ \t]+(.+?)[ \t]*(?:\\)?$', source)
    if len(matches) > 1: raise SystemExit('Duplicate launch flag: -' + name)
    if not matches: return fallback
    values = shlex.split(matches[0].strip().rstrip('\\').strip())
    if len(values) != 1: raise SystemExit('Unsupported launch flag layout: -' + name)
    return values[0]
transport = read_flag('transport', 'auto')
if transport not in ('auto', 'h2', 'wss', 'xhttp'): raise SystemExit('Unsupported transport; migration cancelled.')
if transport in ('auto', 'h2'):
    transport = 'wss'
flag('-transport', transport)
flag('-pad', '0')
env['TRANSPORT'] = transport
env.setdefault('LOCAL_TLS_CA_PATH', '/etc/ssl/certs/ca-certificates.crt')
if env.get('ROLE') == 'origin':
    # Preserve TLS/ECH, MUX and nonremoved tuning; only retired carriers/pad migrate.
    if not re.search(r'(?m)^\s*-tls-min-version\s+', source):
        flag('-tls-min-version', '1.3')  # Preserve the historical core default.
    flag('-access-config', str(directory / 'access.json'))
    flag('-access-state', str(state / 'access-state.json'))
launch = re.sub(r'(?m)^[ \t]*-h2-listen[^\n]*\n', '', source)
launch_profile = {'TRANSPORT': transport, 'XHTTP_PATH': read_flag('xhttp-path', read_flag('ws-path')),
                  'XHTTP_MODE': read_flag('xhttp-mode', 'packet-up'), 'MUX_MODE': read_flag('mux', 'on'),
                  'IRAN_ENTRY_TRANSPORT': env.get('IRAN_ENTRY_TRANSPORT', 'ws')}
for key, option, default in (('PATH_ROTATION', 'path-rotation', '0'), ('PATH_COUNT', 'path-count', '3'), ('PATH_GRACE', 'path-grace', '5m'), ('PATH_LEGACY', 'path-legacy', 'false')):
    launch_profile[key] = read_flag(option, default)
env.update(launch_profile)
site_name = env.get('NGINX_SITE', '')
site_source = None
if site_name:
    site = Path(site_name)
    if not site.is_file(): raise SystemExit('Managed Nginx site is missing: ' + site_name)
    source = site.read_text()
    if not re.search(r'(?m)^\s*ssl_protocols\s+[^;]+;', source):
        raise SystemExit('Unrecognized managed Nginx TLS configuration; restore/review the site.')
    if env.get('ROLE') == 'egress':
        # Only old managed grpc_pass locations are retired. Unrelated sites and
        # custom locations remain byte-for-byte outside these narrow blocks.
        old_source = source
        source = launch
        ws_path, h2_path = read_flag('ws-path'), read_flag('h2-path')
        backend = env.get('WSS_BACKEND_PORT') or read_flag('listen').rsplit(':', 1)[-1]
        source = old_source
        candidates = list(re.finditer(r'(?m)^[ \t]*location\s*=\s+([^\s{]+)\s*\{[^{}]*grpc_pass\s+grpc://127\.0\.0\.1:[0-9]+;[^{}]*\}', source))
        managed = [match for match in candidates if match[1] == h2_path]
        if managed:
            if len(managed) != 1 or not re.fullmatch(r'/[A-Za-z0-9/_-]{15,511}', ws_path) or not backend.isdigit() or not 1 <= int(backend) <= 65535:
                raise SystemExit('Legacy gRPC route cannot be safely mapped to WSS; migration cancelled.')
            replacement = ''
            if transport == 'wss' and not re.search(r'location\s*=\s+' + re.escape(ws_path) + r'\s*\{', source):
                replacement = ('    location = ' + ws_path + ' {\n        proxy_pass http://127.0.0.1:' + backend + ';\n'
                    '        proxy_http_version 1.1;\n        proxy_set_header Host $host;\n'
                    '        proxy_set_header Upgrade $http_upgrade;\n        proxy_set_header Connection "upgrade";\n'
                    '        proxy_set_header Authorization $http_authorization;\n        proxy_buffering off;\n'
                    '        proxy_request_buffering off;\n        proxy_read_timeout 86400s;\n        proxy_send_timeout 86400s;\n    }')
            match = managed[0]
            source = source[:match.start()] + replacement + source[match.end():]
    if 'proxy_cache off;' not in source:
        source = re.sub(r'(?m)^(\s*)proxy_buffering off;$', r'\1proxy_buffering off;\n\1proxy_cache off;', source)
    if 'add_header Cache-Control "no-store" always;' not in source:
        source = re.sub(r'(?m)^(\s*)proxy_cache off;$', r'\1proxy_cache off;\n\1add_header Cache-Control "no-store" always;', source)
    if env.get('ROLE') == 'egress' and 'proxy_set_header Authorization ' not in source:
        source = re.sub(r'(?m)^(\s*)proxy_set_header Upgrade \$http_upgrade;$',
                        r'\1proxy_set_header Upgrade $http_upgrade;\n\1proxy_set_header Authorization $http_authorization;', source)
    if env.get('ROLE') == 'origin' and '# UNUNKNOWNTUN_CUSTOMER_ROUTES' not in source:
        at = source.rfind('    location /')
        if at < 0: raise SystemExit('Managed Nginx fallback was not found.')
        source = source[:at] + '    # UNUNKNOWNTUN_CUSTOMER_ROUTES\n' + source[at:]
    if env.get('ROLE') == 'egress':
        rotation_header = 'location ~ "' + rotation_patterns[transport] + '"'
        old_rotation = r'location\s+\^~\s+/gdt-r/\s*(?=\{)'
        if len(re.findall(old_rotation, source)) > 1:
            raise SystemExit('Duplicate managed rotating routes; no files changed.')
        # Upgrade the old broad prefix in place, retaining its proxy settings.
        source = re.sub(old_rotation, lambda _: rotation_header + ' ', source)
    if env.get('ROLE') == 'egress' and rotation_header not in source:
        # Prepare one bounded forwarding route, retaining the original route's
        # timeouts/buffering/headers and every unrelated site/location. The core
        # rejects this namespace until rotation is explicitly enabled on both peers.
        active_path = launch_profile['XHTTP_PATH'].rstrip('/') + '/' if transport == 'xhttp' else ws_path
        routes = list(re.finditer(r'(?m)^[ \t]*location\s+(?:=|\^~)\s+' + re.escape(active_path) + r'\s*\{[^{}]*proxy_pass\s+http://127\.0\.0\.1:[0-9]+;[^{}]*\}', source))
        if len(routes) != 1:
            if launch_profile['PATH_ROTATION'] != '0':
                raise SystemExit('Active rotation requires a recognized Nginx route; no files changed.')
            print('[NOTE] Custom/legacy route retained. Rotation stays off; review the Nginx route before enabling it.', file=sys.stderr)
        else:
            route = routes[0]
            rotation = re.sub(r'location\s+(?:=|\^~)\s+[^\s{]+', lambda _: rotation_header, route[0], count=1)
            source = source[:route.end()] + '\n' + rotation + source[route.end():]
    # Existing custom TLS certificates, routing, limits and paths are preserved.
    site_source = source
# All parsing/validation precedes the first write. The surrounding upgrade
# transaction restores these files together if service/Nginx validation fails.
run.write_text(launch)
(directory / 'deployment.env').write_text(''.join(key + '=' + shlex.quote(value) + '\n' for key, value in env.items()))
peer = directory / 'peer.env'
if peer.exists():
    fields = dict(line.split('=', 1) for line in peer.read_text().splitlines() if '=' in line)
    fields.update(launch_profile, FORMAT='UNUNKNOWNTUN_V5_FLEET')
    peer.write_text(''.join(key + '=' + value + '\n' for key, value in fields.items()))
if site_source is not None:
    site.write_text(site_source)
PY
    bash -n "$CONFIG_DIR/run.sh"
}

upgrade_existing() {
    require_root
    acquire_install_lock
    detect_os
    migrate_legacy_install_if_needed
    (( $(tunnel_count) > 0 )) || die "No installed tunnel was found. Choose a new installation instead."
    local suggested domain="" total_gb=0 new_accounting=0 suffix ack_after
    suggested="$(find "$TUNNELS_DIR" -mindepth 1 -maxdepth 1 -type d -exec basename {} \; | sort | head -n1)"
    prepare_tunnel_context existing "$suggested"
    ensure_preflight_tools
    # Only our root-owned metadata is sourced, never a pasted customer/update code.
    . "$CONFIG_DIR/deployment.env"
    [[ "${ROLE:-}" == origin || "${ROLE:-}" == egress ]] || die "Unsupported legacy role; no files changed."
    [[ -f "$CONFIG_DIR/run.sh" ]] || die "Managed launch script is missing."
    if [[ "$ROLE" == origin ]]; then
        if [[ -f "$CONFIG_DIR/access.json" ]]; then
            [[ -s "$TUNNEL_STATE_DIR/access-state.json" ]] || die "Accounting state is missing. Restore its backup; upgrade will not reset consumption."
        else
            [[ ! -e "$TUNNEL_STATE_DIR/access-state.json" ]] || die "Accounting state exists without its configuration. Restore the matching configuration before upgrading."
            new_accounting=1
            ask_valid total_gb "Total traffic allowance from this upgrade in GB (0 = unlimited)" 0 valid_quota_gb "Enter a non-negative GB amount."
            warn "This older tunnel has no accounting history. Metering starts at this upgrade; prior traffic cannot be reconstructed."
        fi
    fi
    if [[ -n "${NGINX_SITE:-}" ]]; then
        if [[ "$ROLE" == egress ]]; then domain="$FOREIGN_DOMAIN"; else domain="$IRAN_ENTRY_DOMAIN"; fi
        [[ "$NGINX_SITE" == "$NGINX_SITE_DIR/ununknowntun-$domain.conf" ]] || die "Unexpected Nginx path. Upgrade cancelled before changes."
    fi
    warn "3.5 removes gRPC and legacy padding: auto/h2 becomes WSS, pad becomes 0. Upgrade BOTH peers in a maintenance window; 3.5 XHTTP packet-up requires the 3.5 receiver. Existing domains, certificates, customer IDs/quotas/consumption stay."
    yes_no "Upgrade $CURRENT_TUNNEL_ID only with the displayed transport migration?" y || return 0
    transaction_begin "$ROLE" "$domain"
    # An existing state directory can predate customer accounting. Roll back
    # only these new ledger files; never snapshot/refund an existing ledger.
    if [[ "$new_accounting" == 1 && -d "$TUNNEL_STATE_DIR" ]]; then
        for suffix in '' .lock .status.json; do
            transaction_snapshot "$TUNNEL_STATE_DIR/access-state.json$suffix"
        done
    fi
    write_common_files "$ROLE"
    if [[ "$new_accounting" == 1 ]]; then
        initialize_customer_access "$LOCAL_PORTS" "$total_gb" "${IRAN_PROXY_PROVIDER:-none}"
    fi
    patch_upgrade_configuration
    if [[ -n "$domain" ]]; then
        TX_NGINX_TOUCHED=1
        nginx -t
        if [[ "$TX_NGINX_ACTIVE" == active ]]; then systemctl reload nginx; fi
    fi
    if [[ "$SCRIPT_PATH" != "$INSTALL_DIR/share/ununknowntun-easy.sh" ]]; then
        install -o root -g root -m 0700 "$SCRIPT_PATH" "$INSTALL_DIR/share/ununknowntun-easy.sh"
    fi
    if [[ "$TX_UNUNKNOWNTUN_ACTIVE" == active ]]; then
        systemctl restart "$SERVICE"
        SERVICE_INVOCATION="$(systemctl show "$SERVICE" -p InvocationID --value)"
        ack_after="$(python3 -c 'import time; print(time.time())')"
        sleep 2
        systemctl is-active --quiet "$SERVICE" || die "Upgraded service failed; restoring the previous release."
        if [[ "$ROLE" == origin ]]; then
            python3 - "$CONFIG_DIR/access.json" "$TUNNEL_STATE_DIR/access-state.json.status.json" "$ack_after" <<'PY'
import datetime, hashlib, json, sys, time
from pathlib import Path
wanted = hashlib.sha256(Path(sys.argv[1]).read_bytes()).hexdigest()
for _ in range(50):
    try:
        status = json.loads(Path(sys.argv[2]).read_text())
        updated = datetime.datetime.fromisoformat(status.get('updated_at', '').replace('Z', '+00:00')).timestamp()
        if updated >= float(sys.argv[3]) and status.get('config_revision') == wanted and status.get('running') and not status.get('error'):
            break
    except (OSError, ValueError): pass
    time.sleep(.1)
else: raise SystemExit('The upgraded service did not acknowledge customer accounting.')
PY
        fi
        [[ "$SERVICE_INVOCATION" =~ ^[0-9a-fA-F]{32}$ && "$(systemctl show "$SERVICE" -p InvocationID --value)" == "$SERVICE_INVOCATION" ]] || die "The service restarted during upgrade validation; restoring previous files."
        systemctl is-active --quiet "$SERVICE" || die "Service stopped during upgrade validation."
    fi
    transaction_commit
    info "Upgraded $CURRENT_TUNNEL_ID to $VERSION. Other tunnel services were not restarted."
    warn "The executable and manager are shared; repeat Upgrade for each existing tunnel on both servers to update its individual configuration."
    warn "Run ununknowntunctl test $CURRENT_TUNNEL_ID and test a real client. This upgrade does not certify the CDN/network path."
}

show_transfer_help() {
    cat <<'HELP'

Transfer procedure from the foreign server to Iran when downloads are restricted:

1) On the foreign server after installation:
   scp /opt/ununknowntun/share/ununknowntun-easy.sh root@IRAN_IP:/root/

   If inbound SSH access to Iran is unavailable, pull the file from the Iran server:
   scp root@FOREIGN_IP:/opt/ununknowntun/share/ununknowntun-easy.sh /root/

2) On the Iran server:
   chmod +x /root/ununknowntun-easy.sh
   /root/ununknowntun-easy.sh iran

This installer contains both amd64 and arm64 binaries. Go and GitHub access are not required on the Iran server.
If ca-certificates is not available on the Iran server:

   mkdir -p /etc/ununknowntun
   scp /etc/ssl/certs/ca-certificates.crt root@IRAN_IP:/etc/ununknowntun/ca-bundle.pem

Then run the Iran installer again.
HELP
}

management_selector() {
    require_root
    local choice
    printf '\n1) WSS / XHTTP and managed TLS tunnels\n2) Direct ICMP tunnels and port forwards\n0) Back\n'
    while true; do
        read -r -p 'Tunnel type [2]: ' choice || return 0
        case "${choice:-2}" in
            1) management_menu; return ;;
            2) run_terminal_ui --icmp-manage; return ;;
            0) return 0 ;;
            *) printf 'Choose 0, 1 or 2.\n' ;;
        esac
    done
}

management_menu() {
    require_root
    acquire_install_lock
    detect_os
    printf '\n1) List tunnels\n2) Status\n3) Monitor\n4) Logs\n5) Restart\n6) Stop\n7) Start\n8) Health test\n9) Client info\n10) Change IP\n11) Change ports\n12) Remove one tunnel\n13) Customers, ports and traffic quotas (Iran)\n14) Apply paired-server update code (V3)\n15) Edit all tunnel settings\n16) Apply paired-server editor code (V3)\n17) Show editable settings\n18) Bounded connection diagnostics\n19) Cloudflare scan / auto-update settings\n20) Scan and apply authenticated clean IP\n21) Show scanner/timer status\n'
    local choice
    printf '22) Preview a Cloudflare scan (no endpoint change or restart)\n'
    printf '23) Full SIKDPI scanner (IP, SNI, REALITY, speed, exports)\n'
    printf '24) Guided Cloudflare scan rounds and endpoint selection\n'
    ask_valid choice "Select an option" "1" valid_manage_choice "Choose a number from 1 to 24."
    # The independent scanner never triggers legacy tunnel migration.
    if [[ "$choice" != 23 ]]; then migrate_legacy_install_if_needed; fi
    # The manager/customer helper takes its own lock for mutations.
    flock -u 9
    exec 9>&-
    case "$choice" in
        1) "$CTL_PATH" list ;;
        2) "$CTL_PATH" status ;;
        3) "$CTL_PATH" monitor ;;
        4) "$CTL_PATH" logs ;;
        5) "$CTL_PATH" restart ;;
        6) "$CTL_PATH" stop ;;
        7) "$CTL_PATH" start ;;
        8) "$CTL_PATH" test ;;
        9) "$CTL_PATH" info ;;
        10) "$CTL_PATH" edit-ip ;;
        11) "$CTL_PATH" edit-ports ;;
        12) "$CTL_PATH" delete ;;
        13) "$CTL_PATH" customers ;;
        14) "$CTL_PATH" apply-update ;;
        15) "$CTL_PATH" edit ;;
        16) "$CTL_PATH" edit-apply ;;
        17) "$CTL_PATH" edit-show ;;
        18) "$CTL_PATH" doctor ;;
        19) "$CTL_PATH" cdn ;;
        20) "$CTL_PATH" cdn-scan ;;
        21) "$CTL_PATH" cdn-status ;;
        22) "$CTL_PATH" cdn-preview ;;
        23) "$CTL_PATH" scanner ;;
        24) "$CTL_PATH" cdn-rounds ;;
        *) die "Invalid selection." ;;
    esac
}

write_spoof_pair_helper() {
    cat > "$gdt_spoof_stage/spoof-pair.py" <<'SPOOF_PAIR_PY'
__SPOOF_PAIR_SOURCE__
SPOOF_PAIR_PY
}

generate_spoof_pair() (
    # Generates private files only. Never installs dependencies/binaries, starts
    # services, changes firewall/sysctl/routes, or modifies an existing tunnel.
    command -v python3 >/dev/null || die "Python 3 is required for pair generation."
    command -v openssl >/dev/null || die "OpenSSL is required for the private TLS pair."
    local destination="${1:-}"
    # This function runs in a subshell. Keep the stage reference alive for EXIT
    # even when errexit unwinds function-local variables after helper failure.
    gdt_spoof_stage=""
    if [[ -z "$destination" ]]; then
        printf 'Native IP source spoof / GRE pair (Linux, direct TLS; NOT browser fingerprint).\n'
        printf 'Both real peer addresses and both permitted source addresses are required.\n'
        read -r -p 'New absolute output directory (must not exist): ' destination
    fi
    [[ "$destination" == /* ]] || die "Use a new absolute output directory."
    gdt_spoof_stage="$(mktemp -d)"
    chmod 0700 "$gdt_spoof_stage"
    trap 'rm -f -- "$gdt_spoof_stage/spoof-pair.py"; rmdir -- "$gdt_spoof_stage"' EXIT
    umask 077
    write_spoof_pair_helper
    python3 -I "$gdt_spoof_stage/spoof-pair.py" --output "$destination"
)

generate_icmp_pair() (
    command -v python3 >/dev/null || die "Python 3 is required for pair generation."
    local destination="${1:-}" selected_mode="${2:-}"
    [[ -z "$selected_mode" || "$selected_mode" == native-icmp || "$selected_mode" == icmp-wss ]] || die "Invalid ICMP mode."
    if [[ -z "$destination" ]]; then
        read -r -p 'New absolute private pair directory (must not exist): ' destination || die "Cancelled."
    fi
    [[ "$destination" == /* ]] || die "Use a new absolute output directory."
    gdt_spoof_stage="$(mktemp -d)"
    chmod 0700 "$gdt_spoof_stage"
    trap 'rm -f -- "$gdt_spoof_stage/icmp-pair.py" "$gdt_spoof_stage/spoof-pair.py"; rmdir -- "$gdt_spoof_stage"' EXIT
    umask 077
    write_spoof_pair_helper
    cat > "$gdt_spoof_stage/icmp-pair.py" <<'ICMP_PAIR_PY'
__ICMP_PAIR_SOURCE__
ICMP_PAIR_PY
    if [[ -n "$selected_mode" ]]; then
        python3 -I "$gdt_spoof_stage/icmp-pair.py" --output "$destination" --mode "$selected_mode"
    else
        python3 -I "$gdt_spoof_stage/icmp-pair.py" --output "$destination"
    fi
)

write_direct_icmp_helpers() {
    local destination="$1"
    cat > "$destination/direct-icmp-pair.py" <<'DIRECT_ICMP_PAIR_PY'
__DIRECT_ICMP_PAIR_SOURCE__
DIRECT_ICMP_PAIR_PY
    cat > "$destination/direct-icmp-manage.py" <<'DIRECT_ICMP_MANAGE_PY'
__DIRECT_ICMP_MANAGE_SOURCE__
DIRECT_ICMP_MANAGE_PY
    cat > "$destination/direct-icmp-setup.py" <<'DIRECT_ICMP_SETUP_PY'
__DIRECT_ICMP_SETUP_SOURCE__
DIRECT_ICMP_SETUP_PY
    cat > "$destination/direct-icmp-doctor.py" <<'DIRECT_ICMP_DOCTOR_PY'
__DIRECT_ICMP_DOCTOR_SOURCE__
DIRECT_ICMP_DOCTOR_PY
    printf '{"version":"%s","binary_sha256":{"amd64":"%s","arm64":"%s"}}\n' "$VERSION" "$AMD64_SHA256" "$ARM64_SHA256" > "$destination/direct-icmp-binaries.json"
    chmod 0600 "$destination/direct-icmp-pair.py" "$destination/direct-icmp-manage.py" "$destination/direct-icmp-setup.py" "$destination/direct-icmp-doctor.py" "$destination/direct-icmp-binaries.json"
}

cleanup_direct_icmp_stage() {
    local stage="$1"
    rm -f -- "$stage/direct-icmp-pair.py" "$stage/direct-icmp-manage.py" "$stage/direct-icmp-setup.py" "$stage/direct-icmp-doctor.py" "$stage/direct-icmp-binaries.json" "$stage/spoof-pair.py" "$stage/ununknowntun"
    rmdir -- "$stage"
}

new_direct_icmp_stage() {
    local purpose="$1"
    case "$purpose" in ununknowntun-direct-install|ununknowntun-icmp-setup|ununknowntun-icmp-doctor) ;; *) die "Invalid ICMP staging purpose.";; esac
    [[ -d /run && ! -L /run ]] || die "A trusted /run directory is required."
    umask 077
    mktemp -d "/run/$purpose.XXXXXXXX"
}

install_direct_icmp_helpers() (
    umask 077
    # Called after creation of the trusted root-owned share directory.
    gdt_spoof_stage="$(mktemp -d "$INSTALL_DIR/share/.direct-icmp.XXXXXXXX")"
    trap 'cleanup_direct_icmp_stage "$gdt_spoof_stage"' EXIT
    chmod 0700 "$gdt_spoof_stage"
    write_spoof_pair_helper
    write_direct_icmp_helpers "$gdt_spoof_stage"
    local name
    for name in direct-icmp-pair.py direct-icmp-manage.py direct-icmp-setup.py direct-icmp-doctor.py direct-icmp-binaries.json spoof-pair.py; do
        mv -f -- "$gdt_spoof_stage/$name" "$INSTALL_DIR/share/$name"
    done
)

generate_direct_icmp_pair() (
    command -v python3 >/dev/null || die "Python 3 is required."
    local destination="${1:-}"
    if [[ -z "$destination" ]]; then
        read -r -p 'New absolute private pair directory (must not exist): ' destination || die "Cancelled."
    fi
    [[ "$destination" == /* ]] || die "Use a new absolute output directory."
    umask 077
    gdt_spoof_stage="$(mktemp -d)"
    gdt_spoof_stage="$(cd "$gdt_spoof_stage" && pwd -P)"
    chmod 0700 "$gdt_spoof_stage"
    trap 'cleanup_direct_icmp_stage "$gdt_spoof_stage"' EXIT
    write_spoof_pair_helper
    write_direct_icmp_helpers "$gdt_spoof_stage"
    python3 -I "$gdt_spoof_stage/direct-icmp-pair.py" --output "$destination"
)

install_direct_icmp_endpoint() (
    require_root
    command -v python3 >/dev/null || die "Python 3 is required."
    local endpoint="${1:-}" machine arch
    [[ "$endpoint" == /* && -d "$endpoint" && ! -L "$endpoint" ]] || die "Use the absolute private origin/ or egress/ endpoint directory."
    machine="$(uname -m)"
    case "$machine" in x86_64|amd64) arch=amd64 ;; aarch64|arm64) arch=arm64 ;; *) die "Unsupported architecture." ;; esac
    umask 077
    gdt_spoof_stage="$(new_direct_icmp_stage ununknowntun-direct-install)"
    chmod 0700 "$gdt_spoof_stage"
    trap 'cleanup_direct_icmp_stage "$gdt_spoof_stage"' EXIT
    write_direct_icmp_helpers "$gdt_spoof_stage"
    extract_embedded_binary "$arch" "$gdt_spoof_stage/ununknowntun" || die "Embedded binary verification failed."
    python3 -I "$gdt_spoof_stage/direct-icmp-manage.py" install --endpoint "$endpoint" --binary "$gdt_spoof_stage/ununknowntun"
)

ensure_direct_icmp_dependencies() {
    local tool
    local -a packages=()
    have_command python3 || packages+=(python3)
    have_command ip || packages+=(iproute2)
    have_command nft || packages+=(nftables)
    have_command flock || packages+=(util-linux)
    if (( ${#packages[@]} )); then
        info "Installing missing ICMP L3 prerequisites: ${packages[*]}"
        apt-get -o Acquire::Retries=2 -o Acquire::http::Timeout=20 -o Acquire::https::Timeout=20 update || die "Package index update failed. Restore repository access and run this setup again."
        DEBIAN_FRONTEND=noninteractive apt-get -o Acquire::Retries=2 install --no-upgrade -y "${packages[@]}" || die "Required packages could not be installed."
    fi
    for tool in python3 ip nft flock; do
        have_command "$tool" || die "Required command is unavailable: $tool"
    done
}

run_direct_icmp_setup() (
    local role="${1:-}" choice machine arch
    if [[ -z "$role" ]]; then
        printf '\nICMP L3 setup\n1) Foreign server - create the private pairing code\n2) Iran server - paste the private pairing code\n'
        ask_valid choice "This server" "1" valid_two_choices "Select 1 or 2."
        if [[ "$choice" == 1 ]]; then role=foreign; else role=iran; fi
    fi
    case "$role" in egress) role=foreign;; origin) role=iran;; foreign|iran) ;; *) die "Choose foreign or iran.";; esac
    require_root
    detect_os
    machine="$(uname -m)"
    case "$machine" in x86_64|amd64) arch=amd64;; aarch64|arm64) arch=arm64;; *) die "Unsupported architecture: $machine.";; esac
    ensure_direct_icmp_dependencies
    acquire_install_lock
    umask 077
    gdt_spoof_stage="$(new_direct_icmp_stage ununknowntun-icmp-setup)"
    chmod 0700 "$gdt_spoof_stage"
    trap 'cleanup_direct_icmp_stage "$gdt_spoof_stage"' EXIT
    write_spoof_pair_helper
    write_direct_icmp_helpers "$gdt_spoof_stage"
    extract_embedded_binary "$arch" "$gdt_spoof_stage/ununknowntun" || die "Embedded binary verification failed. Use the complete matching installer; no endpoint was installed."
    python3 -I "$gdt_spoof_stage/direct-icmp-setup.py" "$role" --binary "$gdt_spoof_stage/ununknowntun" --binary-manifest "$gdt_spoof_stage/direct-icmp-binaries.json"
)

run_direct_icmp_doctor() (
    require_root
    command -v python3 >/dev/null || die "Python 3 is required."
    [[ "$#" == 1 && "$1" == /* ]] || die "Usage: $0 direct-icmp-doctor /etc/ununknowntun-direct-icmp/NAME/ROLE"
    umask 077
    gdt_spoof_stage="$(new_direct_icmp_stage ununknowntun-icmp-doctor)"
    chmod 0700 "$gdt_spoof_stage"
    trap 'cleanup_direct_icmp_stage "$gdt_spoof_stage"' EXIT
    write_direct_icmp_helpers "$gdt_spoof_stage"
    python3 -I "$gdt_spoof_stage/direct-icmp-doctor.py" --endpoint "$1"
)

create_tunnel() {
    # Decide the protocol before root checks, package installation or mutation.
    local role="$1" selected
    printf '\nWhat kind of tunnel?\n'
    printf '1) Existing managed WSS / XHTTP (CDN and current settings)\n'
    printf '2) Native ICMP carrier - matched pair, experimental, no ordinary CDN\n'
    printf '3) ICMP Echo inside WSS - ping adapters for a managed WSS pair\n'
    printf '4) Native IP source spoof / GRE - matched pair\n'
    printf '5) Direct ICMP L3 - encrypted IPv4, adaptive FEC, no TLS/WS/CDN\n'
    ask_valid selected "Tunnel type" "1" valid_five_choices "Choose 1, 2, 3, 4 or 5."
    case "$selected" in
        1) if [[ "$role" == egress ]]; then install_foreign; else install_origin; fi ;;
        2) generate_icmp_pair "" native-icmp ;;
        3) generate_icmp_pair "" icmp-wss ;;
        4) generate_spoof_pair ;;
        5) run_direct_icmp_setup "$role" ;;
    esac
}

run_full_scanner() (
    require_root
    # Run the embedded console without installing a core, service or helper.
    # /run is root-owned and avoids accepting a user-controlled TMPDIR.
    local stage
    [[ -d /run && ! -L /run ]] || die "A trusted /run directory is required."
    stage="$(mktemp -d /run/ununknowntun-scanner.XXXXXXXX)"
    trap 'rm -rf -- "$stage"' EXIT
    chmod 0700 "$stage"
    chown root:root "$stage"
    write_scanner_helpers "$stage"
    /usr/bin/python3 -I - "$stage" "$INSTALL_DIR/scanner-venv" "$@" 3<&0 <<'SCANNER_MENU_LAUNCH'
import os
from pathlib import Path
import stat
import sys

def trusted(path, regular=False):
    path = Path(path)
    for item in (path, *path.parents):
        info = item.lstat()
        if info.st_uid != 0 or info.st_mode & 0o022 or stat.S_ISLNK(info.st_mode):
            raise SystemExit("Unsafe scanner ownership, permissions or symlink; refused.")
    if regular and not stat.S_ISREG(path.stat().st_mode):
        raise SystemExit("Expected a regular scanner file; refused.")

share, venv = map(Path, sys.argv[1:3])
console = share / "scanner-console.py"
for helper in (console, share / "scanner-engine.py"):
    trusted(helper, regular=True)
runtime = Path("/usr/bin/python3").resolve(strict=True)
trusted(runtime, regular=True)
if venv.exists() or venv.is_symlink():
    trusted(venv)
    trusted(venv / "pyvenv.cfg", regular=True)
    candidate = venv / "bin/python3"
    trusted(candidate.parent)
    info = candidate.lstat()
    if info.st_uid != 0 or (not stat.S_ISLNK(info.st_mode) and info.st_mode & 0o022):
        raise SystemExit("Unsafe scanner virtual environment interpreter; refused.")
    trusted(candidate.resolve(strict=True), regular=True)
    # Python imports its environment before the console can validate it.
    # Reject writable dependency files and links escaping into unsafe paths.
    for directory, dirs, files in os.walk(venv, followlinks=False):
        for name in dirs + files:
            path = Path(directory) / name
            if path.is_symlink():
                if path.lstat().st_uid != 0:
                    raise SystemExit("Unsafe virtual environment link; refused.")
                trusted(path.resolve(strict=True))
            else:
                trusted(path)
    runtime = candidate
env = {key: value for key, value in os.environ.items()
       if not key.startswith(("PYTHON", "LD_", "DYLD_", "BASH_FUNC_"))
       and key not in {"BASH_ENV", "ENV", "SHELLOPTS", "BASHOPTS", "UNUNKNOWNTUN_TOKEN", "V7_TOKEN"}}
env["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
os.dup2(3, 0)
os.close(3)
os.execve(str(runtime), [str(runtime), "-I", str(console), *sys.argv[3:]], env)
SCANNER_MENU_LAUNCH
)

run_terminal_ui() (
    require_root
    # The embedded UI can inspect an existing installation without updating it.
    # Use private temporary files only; opening the UI takes no installer lock.
    local stage
    [[ -d /run && ! -L /run ]] || die "A trusted /run directory is required."
    stage="$(mktemp -d /run/ununknowntun-ui.XXXXXXXX)"
    trap 'rm -rf -- "$stage"' EXIT
    chmod 0700 "$stage"
    chown root:root "$stage"
    write_terminal_ui "$stage"
    /usr/bin/python3 -I - "$stage/ununknowntun-ui.py" "$@" 3<&0 <<'UI_MENU_LAUNCH'
import os
from pathlib import Path
import stat
import sys

def trusted(path):
    path = Path(path)
    for item in (path, *path.parents):
        info = item.lstat()
        if info.st_uid != 0 or info.st_mode & 0o022 or stat.S_ISLNK(info.st_mode):
            raise SystemExit("Unsafe UI ownership, permissions or symlink; refused.")
    if not stat.S_ISREG(path.stat().st_mode):
        raise SystemExit("Expected a regular UI file; refused.")

ui = Path(sys.argv[1])
trusted(ui)
runtime = Path("/usr/bin/python3").resolve(strict=True)
trusted(runtime)
env = {key: value for key, value in os.environ.items()
       if not key.startswith(("PYTHON", "LD_", "DYLD_", "BASH_FUNC_"))
       and key not in {"BASH_ENV", "ENV", "SHELLOPTS", "BASHOPTS", "UNUNKNOWNTUN_TOKEN", "V7_TOKEN"}}
env["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
os.dup2(3, 0)
os.close(3)
os.execve(str(runtime), [str(runtime), "-I", str(ui), *sys.argv[2:]], env)
UI_MENU_LAUNCH
)

run_connection_test() {
    command -v python3 >/dev/null 2>&1 || die "python3 is required for the connection test."
    local role port token host link ip
    printf '\nConnection test between the Iran and Foreign servers (no tunnel is touched):\n'
    printf '  1) This is the IRAN server    - starts the listener and prints a link\n'
    printf '  2) This is the FOREIGN server - paste the link and run all tests\n'
    ask_valid role "Select this server" "1" valid_two_choices "Select 1 or 2."
    if [[ "$role" == 1 ]]; then
        ip="$(curl --noproxy '*' -4fsS --connect-timeout 5 --max-time 8 https://api.ipify.org 2>/dev/null || true)"
        ask_valid host "This Iran server's public IP" "$ip" valid_name "Enter the server IP."
        ask_valid port "Base port (uses port to port+2)" "4500" valid_port "Invalid port."
        token="$(head -c 12 /dev/urandom | od -An -tx1 | tr -d ' \n')"
        printf '\n'
        info "Run option 0 on the FOREIGN server, choose 2 and paste this link:"
        printf '\n    %suut://%s:%s/%s%s\n\n' "$GREEN" "$host" "$port" "$token" "$RESET"
        info "Allow TCP+UDP ports $port-$((port + 2)) in the firewall if blocked."
        run_connection_test_py server --port "$port" --token "$token"
    else
        while true; do
            ask link "Paste the link from the Iran server (uut://IP:PORT/TOKEN)" ""
            if [[ "$link" =~ ^uut://([^:/[:space:]]+):([0-9]{4,5})/([0-9a-f]{24})$ ]]; then
                host="${BASH_REMATCH[1]}"; port="${BASH_REMATCH[2]}"; token="${BASH_REMATCH[3]}"
                valid_port "$port" && break
            fi
            warn "Invalid link. Copy it exactly from the Iran server."
        done
        run_connection_test_py client --host "$host" --port "$port" --token "$token"
    fi
}

run_connection_test_py() {
    python3 -I - "$@" <<'UUT_CONNTEST_PY_EOF'
#!/usr/bin/env python3
"""UnUnknownTun connection test between two servers (stdlib only).

  server role: python3 connection-test.py server --port 4500 --token SECRET
  client role: python3 connection-test.py client --host SERVER_IP --port 4500 --token SECRET

Ports used on the server: P (TCP+UDP), P+1 (TLS + WebSocket over TLS), P+2 (plain HTTP).
ICMP is tested with the system ping command and needs no listener.
It does not touch any tunnel, service or firewall configuration.
"""
import argparse, base64, hashlib, os, shutil, socket, ssl, struct, subprocess, sys, tempfile, threading, time

GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
CHUNK = 64 * 1024


def recv_line(conn, limit=512):
    data = b""
    while not data.endswith(b"\n") and len(data) < limit:
        piece = conn.recv(1)
        if not piece:
            break
        data += piece
    return data.decode("latin-1").strip()


def recv_exact(conn, count):
    buf = b""
    while len(buf) < count:
        piece = conn.recv(min(CHUNK, count - len(buf)))
        if not piece:
            raise ConnectionError("peer closed")
        buf += piece
    return buf


def ws_read(conn):
    head = recv_exact(conn, 2)
    length = head[1] & 0x7F
    if length == 126:
        length = struct.unpack(">H", recv_exact(conn, 2))[0]
    elif length == 127:
        length = struct.unpack(">Q", recv_exact(conn, 8))[0]
    mask = recv_exact(conn, 4) if head[1] & 0x80 else b""
    payload = recv_exact(conn, length)
    if mask:
        payload = bytes(b ^ mask[i % 4] for i, b in enumerate(payload))
    return head[0] & 0x0F, payload


def ws_write(conn, payload, mask=False):
    head = bytes([0x82])
    if len(payload) < 126:
        head += bytes([len(payload) | (0x80 if mask else 0)])
    else:
        head += bytes([126 | (0x80 if mask else 0)]) + struct.pack(">H", len(payload))
    if mask:
        key = os.urandom(4)
        payload = key + bytes(b ^ key[i % 4] for i, b in enumerate(payload))
    conn.sendall(head + payload)


# ---------------------------------------------------------------- server
def handle_stream(conn, token, allow_ws):
    conn.settimeout(20)
    first = recv_line(conn)
    if allow_ws and first.startswith("GET "):
        key = ""
        while True:
            line = recv_line(conn)
            if not line:
                break
            if line.lower().startswith("sec-websocket-key:"):
                key = line.split(":", 1)[1].strip()
        accept = base64.b64encode(hashlib.sha1((key + GUID).encode()).digest()).decode()
        conn.sendall(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                      f"Sec-WebSocket-Accept: {accept}\r\n\r\n").encode())
        opcode, payload = ws_read(conn)
        ws_write(conn, payload)
        return
    if first != f"TOKEN {token}":
        conn.sendall(b"DENIED\n")
        return
    conn.sendall(b"OK\n")
    while True:
        cmd = recv_line(conn)
        if not cmd:
            return
        parts = cmd.split()
        if parts[0] == "ECHO" and len(parts) == 2:
            conn.sendall(recv_exact(conn, int(parts[1])))
        elif parts[0] == "SINK" and len(parts) == 2:
            recv_exact(conn, min(int(parts[1]), 256 << 20))
            conn.sendall(b"DONE\n")
        elif parts[0] == "BLAST" and len(parts) == 2:
            left = min(int(parts[1]), 256 << 20)
            block = b"\0" * CHUNK
            while left > 0:
                conn.sendall(block[:min(CHUNK, left)])
                left -= CHUNK
        else:
            return


def serve_tcp(port, token, ctx=None, allow_ws=False):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("0.0.0.0", port))
    sock.listen(64)

    def one(raw):
        try:
            conn = ctx.wrap_socket(raw, server_side=True) if ctx else raw
            handle_stream(conn, token, allow_ws)
        except Exception:
            pass
        finally:
            try:
                raw.close()
            except OSError:
                pass

    while True:
        raw, _ = sock.accept()
        threading.Thread(target=one, args=(raw,), daemon=True).start()


def serve_udp(port, token):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(("0.0.0.0", port))
    prefix = f"TOKEN {token} ".encode()
    while True:
        data, addr = sock.recvfrom(2048)
        if data.startswith(prefix):
            sock.sendto(data, addr)


def serve_http(port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("0.0.0.0", port))
    sock.listen(32)

    def one(conn):
        try:
            conn.settimeout(10)
            conn.recv(2048)
            conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok")
        except Exception:
            pass
        finally:
            conn.close()

    while True:
        conn, _ = sock.accept()
        threading.Thread(target=one, args=(conn,), daemon=True).start()


def run_server(args):
    workdir = tempfile.mkdtemp(prefix="uut-conntest-")
    cert, key = os.path.join(workdir, "c.pem"), os.path.join(workdir, "k.pem")
    ctx = None
    if shutil.which("openssl"):
        made = subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", key, "-out", cert,
                               "-days", "1", "-subj", "/CN=uut-connection-test"], capture_output=True)
        if made.returncode == 0:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            ctx.load_cert_chain(cert, key)
    shutil.rmtree(workdir, ignore_errors=True)
    p = args.port
    jobs = [(serve_tcp, (p, args.token)), (serve_udp, (p, args.token)), (serve_http, (p + 2,))]
    if ctx:
        jobs.append((serve_tcp, (p + 1, args.token, ctx, True)))
    for fn, a in jobs:
        threading.Thread(target=fn, args=a, daemon=True).start()
    print(f"Listening: TCP+UDP {p}, HTTP {p + 2}" + (f", TLS/WebSocket {p + 1}" if ctx else ", (TLS/WebSocket disabled: openssl not found)"))
    print("Open these ports in the firewall if needed. Press Ctrl+C to stop.")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        print("\nStopped.")


# ---------------------------------------------------------------- client
RESULTS = []
SPEEDS = []


def report(name, ok, detail):
    RESULTS.append((name, ok))
    mark = "\033[32mPASS\033[0m" if ok else "\033[31mFAIL\033[0m"
    print(f"  [{mark}] {name:<28} {detail}")


def connect(host, port, timeout, ctx=None):
    raw = socket.create_connection((host, port), timeout=timeout)
    return ctx.wrap_socket(raw, server_hostname=None) if ctx else raw


def test_icmp(host, count=5):
    if not shutil.which("ping"):
        report("ICMP echo", False, "ping command not installed")
        return
    out = subprocess.run(["ping", "-c", str(count), "-W", "2", host], capture_output=True, text=True).stdout
    loss = None
    avg = None
    for line in out.splitlines():
        if "packet loss" in line:
            for tok in line.split(","):
                if "loss" in tok:
                    loss = tok.strip().split("%")[0]
        if line.startswith(("rtt", "round-trip")):
            avg = line.split("=")[1].split("/")[1]
    ok = loss is not None and float(loss) < 100
    report("ICMP echo (ping)", ok, f"loss {loss}%  avg {avg} ms" if ok else "no reply (ICMP blocked or host down)")


def stream_checks(label, host, port, token, ctx, timeout):
    try:
        began = time.monotonic()
        conn = connect(host, port, timeout, ctx)
        setup_ms = (time.monotonic() - began) * 1000
        conn.settimeout(timeout)
        conn.sendall(f"TOKEN {token}\n".encode())
        if recv_line(conn) != "OK":
            report(f"{label} connect", False, "server rejected token")
            return
        extra = f" ({conn.version()})" if ctx else ""
        sample = os.urandom(512)
        began = time.monotonic()
        conn.sendall(b"ECHO 512\n" + sample)
        good = recv_exact(conn, 512) == sample
        rtt = (time.monotonic() - began) * 1000
        report(f"{label} connect + echo", good, f"setup {setup_ms:.0f} ms, echo {rtt:.0f} ms{extra}")
        size = 8 << 20
        began = time.monotonic()
        conn.sendall(f"BLAST {size}\n".encode())
        recv_exact(conn, size)
        down = size * 8 / (time.monotonic() - began) / 1e6
        began = time.monotonic()
        conn.sendall(f"SINK {size}\n".encode())
        block = b"\0" * CHUNK
        sent = 0
        while sent < size:
            conn.sendall(block[:min(CHUNK, size - sent)])
            sent += CHUNK
        recv_line(conn)
        up = size * 8 / (time.monotonic() - began) / 1e6
        SPEEDS.append((f"{label} single stream", down, up))
        report(f"{label} throughput", True, f"download {down:.1f} Mbit/s, upload {up:.1f} Mbit/s (8 MiB)")
        conn.close()
    except Exception as exc:
        report(f"{label} connect + echo", False, f"{type(exc).__name__}: {exc}")


def test_parallel(host, port, token, ctx, timeout, streams=4, size=4 << 20):
    label = "TLS" if ctx else "TCP"
    results = []

    def worker(direction):
        try:
            conn = connect(host, port, timeout, ctx)
            conn.settimeout(timeout)
            conn.sendall(f"TOKEN {token}\n".encode())
            if recv_line(conn) != "OK":
                return
            if direction == "down":
                conn.sendall(f"BLAST {size}\n".encode())
                recv_exact(conn, size)
            else:
                conn.sendall(f"SINK {size}\n".encode())
                block = b"\0" * CHUNK
                sent = 0
                while sent < size:
                    conn.sendall(block[:min(CHUNK, size - sent)])
                    sent += CHUNK
                recv_line(conn)
            results.append(size)
            conn.close()
        except Exception:
            pass

    rates = []
    for direction in ("down", "up"):
        results.clear()
        threads = [threading.Thread(target=worker, args=(direction,)) for _ in range(streams)]
        began = time.monotonic()
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        elapsed = time.monotonic() - began
        rates.append(sum(results) * 8 / elapsed / 1e6 if results else 0.0)
    ok = rates[0] > 0 and rates[1] > 0
    if ok:
        SPEEDS.append((f"{label} {streams} parallel streams", rates[0], rates[1]))
    report(f"{label} {streams} parallel streams", ok, f"download {rates[0]:.1f} Mbit/s, upload {rates[1]:.1f} Mbit/s" if ok else "failed")


def test_websocket(host, port, ctx, timeout):
    try:
        conn = connect(host, port, timeout, ctx)
        conn.settimeout(timeout)
        key = base64.b64encode(os.urandom(16)).decode()
        conn.sendall((f"GET /uut HTTP/1.1\r\nHost: {host}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                      f"Sec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n").encode())
        status = recv_line(conn)
        while recv_line(conn):
            pass
        if "101" not in status:
            report("WSS WebSocket upgrade", False, status or "no response")
            return
        began = time.monotonic()
        payload = os.urandom(300)
        ws_write(conn, payload, mask=True)
        _, echoed = ws_read(conn)
        report("WSS WebSocket upgrade", echoed == payload, f"frame echo {(time.monotonic() - began) * 1000:.0f} ms")
        conn.close()
    except Exception as exc:
        report("WSS WebSocket upgrade", False, f"{type(exc).__name__}: {exc}")


def test_http(host, port, timeout):
    try:
        conn = connect(host, port, timeout)
        conn.settimeout(timeout)
        began = time.monotonic()
        conn.sendall(f"GET / HTTP/1.1\r\nHost: {host}\r\nConnection: close\r\n\r\n".encode())
        body = b""
        while True:
            piece = conn.recv(4096)
            if not piece:
                break
            body += piece
        report("HTTP plain", body.endswith(b"ok"), f"{(time.monotonic() - began) * 1000:.0f} ms")
    except Exception as exc:
        report("HTTP plain", False, f"{type(exc).__name__}: {exc}")


def test_udp(host, port, token, timeout, total=40):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.settimeout(timeout / 3)
    got, rtts = 0, []
    for i in range(total):
        packet = f"TOKEN {token} {i} ".encode() + os.urandom(200)
        began = time.monotonic()
        sock.sendto(packet, (host, port))
        try:
            data, _ = sock.recvfrom(2048)
            if data == packet:
                got += 1
                rtts.append((time.monotonic() - began) * 1000)
        except socket.timeout:
            pass
    loss = (total - got) * 100 / total
    detail = f"loss {loss:.0f}%" + (f", avg {sum(rtts) / len(rtts):.0f} ms" if rtts else "")
    report("UDP echo", got > 0 and loss <= 50, detail if got else "no reply (UDP blocked or server not listening)")
    burst = 200
    for i in range(burst):
        sock.sendto(f"TOKEN {token} b{i} ".encode() + b"x" * 1000, (host, port))
    sock.settimeout(1.5)
    back = 0
    try:
        while back < burst:
            sock.recvfrom(2048)
            back += 1
    except socket.timeout:
        pass
    report("UDP burst (200 x 1 KB)", back > 0, f"{back}/{burst} returned")


def run_client(args):
    host, p, t = args.host, args.port, args.token
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    print(f"Testing {host} (ports {p}, {p + 1}, {p + 2}) ...\n")
    test_icmp(host)
    stream_checks("TCP", host, p, t, None, args.timeout)
    stream_checks("TLS", host, p + 1, t, ctx, args.timeout)
    test_parallel(host, p, t, None, args.timeout)
    test_parallel(host, p + 1, t, ctx, args.timeout)
    test_websocket(host, p + 1, ctx, args.timeout)
    test_http(host, p + 2, args.timeout)
    test_udp(host, p, t, args.timeout)
    if SPEEDS:
        print("\nSpeed summary (this server <- -> remote):")
        for name, down, up in SPEEDS:
            print(f"  {name:<30} down {down:8.1f} Mbit/s   up {up:8.1f} Mbit/s")
    passed = sum(1 for _, ok in RESULTS if ok)
    print(f"\nSummary: {passed}/{len(RESULTS)} checks passed.")
    print("A blocked protocol here shows what the path between these two servers allows; it does not test a live tunnel.")
    return 0 if passed else 1


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="role", required=True)
    s = sub.add_parser("server")
    s.add_argument("--port", type=int, default=4500)
    s.add_argument("--token", required=True)
    c = sub.add_parser("client")
    c.add_argument("--host", required=True)
    c.add_argument("--port", type=int, default=4500)
    c.add_argument("--token", required=True)
    c.add_argument("--timeout", type=float, default=8.0)
    args = ap.parse_args()
    if not 1024 <= args.port <= 65533:
        sys.exit("Port must be 1024..65533.")
    if args.role == "server":
        run_server(args)
        return 0
    return run_client(args)


if __name__ == "__main__":
    sys.exit(main())
UUT_CONNTEST_PY_EOF
}

main_menu() {
    local B=$'\033[1m' D=$'\033[2m' R=$'\033[31m'
    printf '%s\n' "$RED"
    printf '%s\n' '█   █ █   █ █   █ █   █ █  █  █   █  ███  █   █ █   █ █████ █   █ █   █'
    printf '%s\n' '█   █ ██  █ █   █ ██  █ █ █   ██  █ █   █ █   █ ██  █   █   █   █ ██  █'
    printf '%s\n' '█   █ █ █ █ █   █ █ █ █ ██    █ █ █ █   █ █ █ █ █ █ █   █   █   █ █ █ █'
    printf '%s\n' '█   █ █  ██ █   █ █  ██ █ █   █  ██ █   █ ██ ██ █  ██   █   █   █ █  ██'
    printf '%s\n' ' ███  █   █  ███  █   █ █  █  █   █  ███  █   █ █   █   █    ███  █   █'
    printf '%s\n' "$RESET"
    printf '  %sUnUnknownTun%s  %sv%s%s\n' "$B" "$RESET" "$R" "$RELEASE_LABEL" "$RESET"
    printf '  %sNormal WSS / XHTTP + TLS / Direct ICMP / IP spoof%s\n' "$D" "$RESET"
    printf '  %s==============================================%s\n\n' "$D" "$RESET"
    local n title desc
    while IFS='|' read -r n title desc; do
        printf '  %s%2s)%s %s%-16s%s %s%s%s\n' "$R" "$n" "$RESET" "$B" "$title" "$RESET" "$D" "$desc" "$RESET"
    done <<'MENU'
 0|Connection Test|Iran/Foreign: test all protocols and speed
 1|Setup Iran|the server users connect to
 2|Setup Foreign|the server abroad, with the service
 3|Manage|tunnels, customers, health, remove
 4|Transfer Help|foreign to Iran pairing instructions
 5|Upgrade|keep settings and usage
 6|IP Spoof / GRE|generate a matched pair
 7|Scanner|full SIKDPI scanner, no tunnel needed
 8|ICMP L3|easy setup with a pairing code
 9|Control Room|Tunnels / Tuning / Doctor
10|Exit|
MENU
    printf '\n'
    local choice
    ask_valid choice "Select an option" "1" valid_main_choice "Choose a number from 0 to 10."
    case "$choice" in
        0) run_connection_test ;;
        1) create_tunnel origin ;;
        2) create_tunnel egress ;;
        3) management_selector ;;
        4) show_transfer_help ;;
        5) upgrade_existing ;;
        6) generate_spoof_pair ;;
        7) run_full_scanner ;;
        8) run_direct_icmp_setup ;;
        9) run_terminal_ui ;;
        10) exit 0 ;;
        *) die "Invalid selection." ;;
    esac
}

case "${1:-}" in
    foreign|egress) create_tunnel egress ;;
    iran|origin) create_tunnel origin ;;
    manage) management_selector ;;
    upgrade) upgrade_existing ;;
    transfer-help) show_transfer_help ;;
    spoof-pair) generate_spoof_pair "${2:-}" ;;
    icmp-pair) generate_icmp_pair "${2:-}" ;;
    direct-icmp-pair) generate_direct_icmp_pair "${2:-}" ;;
    direct-icmp-install) install_direct_icmp_endpoint "${2:-}" ;;
    direct-icmp-setup) run_direct_icmp_setup "${2:-}" ;;
    direct-icmp-doctor) run_direct_icmp_doctor "${2:-}" ;;
    direct-icmp-manage) shift; run_terminal_ui --icmp-manage "$@" ;;
    scanner) shift; run_full_scanner "$@" ;;
    ui) shift; run_terminal_ui "$@" ;;
    connection-test|test) shift; run_connection_test "$@" ;;
    "") main_menu ;;
    help|--help|-h)
        printf 'Usage: %s [foreign|iran|manage|upgrade|scanner|ui]\n' "$0"
        printf '  connection-test                Test TCP/UDP/ICMP/TLS/WebSocket between two servers\n'
        printf '  ui [UI_OPTIONS]                Open the embedded Control Room without upgrading\n'
        printf '  direct-icmp-setup [foreign|iran]  Easy ICMP L3 setup; no manual pair-file transfer\n'
        printf '  direct-icmp-doctor ENDPOINT_DIR  Read-only ICMP host diagnostics\n'
        printf '  direct-icmp-manage              List and manage installed ICMP pairs\n'
        printf '  direct-icmp-pair OUTPUT_DIR     Advanced offline pair generation\n'
        printf '  direct-icmp-install ENDPOINT_DIR Advanced offline endpoint installation\n'
        ;;
    *) die "Invalid option: $1 (use --help)" ;;
esac

exit 0
