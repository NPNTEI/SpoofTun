#!/usr/bin/env python3
"""Assemble checked preview artifacts in a NEW directory. Never deploys/publishes."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import zipfile


def validation_logs(summary, version, source_root, directory):
    required = {"go-test", "go-race", "go-vet", "go-resilience", "installer-syntax", "terminal-ui", "test-gre-wire", "test-gre-systemd", "test-icmp-wire", "test-icmp-wss"}
    required.update(path.stem for path in (source_root / "packaging").glob("test-*.py"))
    if not isinstance(summary, dict):
        raise ValueError("Validation summary must be an object.")
    results = summary.get("results", [])
    if summary.get("version") != version or not isinstance(results, list) or not results:
        raise ValueError("Validation version/results are missing or stale.")
    logs = {}
    for result in results:
        if not isinstance(result, dict):
            raise ValueError("Validation group must be an object.")
        name = result.get("name", "")
        if not isinstance(name, str) or not re.fullmatch(r"[a-z0-9-]+", name) or name in logs:
            raise ValueError("Validation group names must be unique and safe.")
        if result.get("status") != "PASS" or type(result.get("exit_code")) is not int or result["exit_code"] != 0:
            raise ValueError("Fresh validation is not entirely passing.")
        path = directory / (name + ".log")
        if path.is_symlink() or not path.is_file():
            raise ValueError("Missing regular validation log: " + name)
        logs[name] = path.read_text()
    if not required.issubset(logs):
        raise ValueError("Missing required validation groups: " + ", ".join(sorted(required - logs.keys())))
    return logs


def unittest_counts(text):
    runs = re.findall(r"(?m)^Ran (\d+) tests? in ", text)
    outcomes = re.findall(r"(?m)^OK(?: \(skipped=(\d+)\))?\s*$", text)
    if len(runs) != 1 or len(outcomes) != 1 or re.search(r"(?m)^FAILED\b", text):
        raise ValueError("Expected one complete successful unittest result.")
    total, skipped = int(runs[0]), int(outcomes[0] or 0)
    if total < 1 or not 0 <= skipped <= total:
        raise ValueError("Invalid unittest counts.")
    return total, skipped


def audit_files(directory):
    """Accept only reviewed text evidence, never fixture trees or symlink targets."""
    if directory.is_symlink() or not directory.is_dir():
        raise ValueError("Audit input must be a regular sanitized evidence directory.")
    selected, size = [], 0
    permitted_name = re.compile(r"(?:scanner-real-curl\.(?:log|json)|scanner-standalone\.json|direct-icmp-systemd-final\.json|direct-icmp-standalone-final\.json|direct-icmp-final\.json|direct-icmp-fec-final\.json|Fuzz[A-Za-z0-9_]+\.log|security-after[A-Za-z0-9._-]*\.json|security-binary-linux-(?:amd64|arm64)\.json|security-linux-(?:amd64|arm64)-package-list\.txt|security-summary\.md|go-native-coverage\.log|gre-netns-final\.log|spoof-systemd-final\.log|icmp-native-final\.json|icmp-wss-final\.json|rotation-soak-final\.json|README\.md)")
    sensitive_name = re.compile(r"(?:^|[-_.])(?:fixtures?|tokens?|privkey|private[-_]?key|certificates?|passwords?|credentials?)(?:$|[-_.])", re.I)
    sensitive_text = re.compile(
        r"-----BEGIN (?:[A-Z ]*PRIVATE KEY|CERTIFICATE)-----|"
        r"(?im:^\s*(?:TOKEN|UNUNKNOWNTUN_TOKEN|Authorization|PRIVATE_KEY|API_TOKEN|PASSWORD)\s*[:=]\s*\S+)|"
        r'"(?:token|private_key|api_token|password|privkey)"\s*:\s*"[^"\s]{8,}"|'
        r"(?:vless|vmess|ss)://", re.I)
    for path in sorted(directory.rglob("*")):
        relative = path.relative_to(directory)
        if path.is_symlink() or any(sensitive_name.search(part) for part in relative.parts):
            raise ValueError("Unsafe audit path: " + relative.as_posix())
        if len(relative.parts) != 1 or not path.is_file() or not permitted_name.fullmatch(path.name):
            raise ValueError("Only approved, flat text audit reports may be packaged: " + relative.as_posix())
        file_size = path.stat().st_size
        size += file_size
        if file_size > 16 * 1024 * 1024 or size > 128 * 1024 * 1024 or len(selected) >= 256:
            raise ValueError("Audit evidence exceeds conservative packaging bounds.")
        text = path.read_text(encoding="utf-8")
        if "\x00" in text or sensitive_text.search(text):
            raise ValueError("Possible private fixture/credential in audit report: " + relative.as_posix())
        selected.append((path, relative))
    return selected


def validate_integration(report, version):
    if not isinstance(report, dict):
        raise ValueError("Integration report must be an object.")
    modes = report.get("modes", [])
    if report.get("status") != "PASS" or report.get("binary_version") != "ununknowntun " + version or not isinstance(modes, list) or len(modes) != 20:
        raise ValueError("Expected passing 20-profile executable-level integration report.")
    expected = {f"{mode}-mux-{mux}-fragment-{fragment}"
                for mode in ("wss", "xhttp") for mux in ("on", "off") for fragment in ("off", "hello")}
    expected.update({"auto-mux-on-fragment-off", "h2-mux-on-fragment-off"})
    expected.update(f"wss-padded-mux-{mux}" for mux in ("on", "off"))
    expected.update(f"xhttp-{mode}-padded-mux-{mux}"
                    for mode in ("auto", "packet-up", "stream-up", "stream-one") for mux in ("on", "off"))
    if any(not isinstance(item, dict) or not isinstance(item.get("profile"), str) for item in modes) or {item["profile"] for item in modes} != expected:
        raise ValueError("Integration report does not cover the required unique profiles.")
    if report.get("frontend_kind") not in {"go", "nginx"}:
        raise ValueError("Integration report must identify the tested front end.")
    if report["frontend_kind"] == "nginx" and not report.get("nginx_version"):
        raise ValueError("Real Nginx evidence must identify its executable version.")
    for item in modes:
        if any(item.get(key) is not True for key in ("all_sha256_and_fin_verified", "authenticated_probe_passed", "stream_and_queue_cleanup_verified")):
            raise ValueError("Incomplete integration evidence: " + item["profile"])
        doctor = item.get("doctor", {})
        if not isinstance(doctor, dict) or any(doctor.get(key) is not True for key in ("actual_subprocess", "authenticated", "wrong_route_rejected", "configuration_unchanged", "secrets_redacted")):
            raise ValueError("Incomplete diagnostic integration evidence: " + item["profile"])
        for key in ("fast_stream_during_slow_consumer", "slow_consumer", "new_stream_after_egress_restart"):
            exchange = item.get(key, {})
            if not isinstance(exchange, dict) or exchange.get("sha256_verified") is not True or exchange.get("fin_eof_verified") is not True:
                raise ValueError("Incomplete stream/recovery integration evidence: " + item["profile"])


def runtime_statement(tested_arches):
    executed = "the shipped Linux " + ", ".join(tested_arches) + " executable in the isolated lab" if tested_arches else "a native test executable, not a shipped Linux binary"
    untested = [arch for arch in ("amd64", "arm64") if arch not in tested_arches]
    caveat = "; Linux " + ", ".join(untested) + " runtime" if untested else ""
    return executed, caveat


root = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--build", type=Path, required=True)
parser.add_argument("--validation", type=Path, required=True)
parser.add_argument("--integration-report", type=Path, required=True)
parser.add_argument("--preview-installer", type=Path, required=True)
parser.add_argument("--audit", type=Path, help="Additional sanitized test evidence (no credentials or fixtures)")
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
version = (root / "VERSION").read_text().strip()
name = "UNUNKNOWNTUN-" + version
out = args.output.resolve()
if out.exists(): raise SystemExit("Output already exists; choose a new directory.")
summary = json.loads((args.validation / "summary.json").read_text())
try:
    checked_logs = validation_logs(summary, version, root, args.validation)
    checked_audit = audit_files(args.audit) if args.audit else []
except (ValueError, OSError) as error:
    raise SystemExit(str(error)) from error
integration = json.loads(args.integration_report.read_text())
try:
    validate_integration(integration, version)
except ValueError as error:
    raise SystemExit(str(error)) from error
native_binary = args.build / "ununknowntun-native"
if not native_binary.is_file() or hashlib.sha256(native_binary.read_bytes()).hexdigest() != integration.get("binary_sha256"):
    raise SystemExit("Integration report does not match the final native test binary.")
test = subprocess.run([sys.executable, "-I", str(args.preview_installer / "test_install_preview.py")], capture_output=True, text=True)
if test.returncode: raise SystemExit(test.stdout + test.stderr)
python_tests, skips = unittest_counts(test.stdout + test.stderr)
for group, text in checked_logs.items():
    if group.startswith("test-") or group == "terminal-ui":
        count, skipped = unittest_counts(text)
        python_tests += count
        skips += skipped
manifest = json.loads((args.build / "direct-icmp-binaries.json").read_text())
expected_hashes = {arch: hashlib.sha256((args.build / "bin" / ("ununknowntun-linux-" + arch)).read_bytes()).hexdigest()
                   for arch in ("amd64", "arm64")}
if manifest != {"version": version, "binary_sha256": expected_hashes}:
    raise SystemExit("Direct ICMP binary manifest does not match the final release binaries.")
out.mkdir(parents=True)
bundle = out / name
bundle.mkdir()
source = bundle / "source"
source.mkdir()
# Exclude historical release claims, generated caches, and old UI package tools.
excluded = {"README-RC1.md", "RELEASE-NOTES-RC1.md", "RELEASE-VALIDATION.md", "README.fa.txt", "preview-terminal.png", "build.py", "package-complete.py"}
for path in sorted(root.rglob("*")):
    rel = path.relative_to(root)
    if not path.is_file() or path.is_symlink(): continue
    # Always repopulate dependency notices from the final build, including when
    # this source was unpacked from an older complete release.
    if any(p in {"__pycache__", ".git", "validation", "work-release", "release", "dist", "THIRD_PARTY_LICENSES"} for p in rel.parts) or path.name in excluded: continue
    if path.suffix not in {".go", ".mod", ".sum", ".md", ".txt", ".py", ".sh", ".yml", ".yaml"} and path.name not in {"VERSION", ".gitignore"}: continue
    target = source / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
for filename in ("README.md", "README.ru.md", "README.zh-CN.md", "VERSION", "xhttp-profile.md"):
    shutil.copy2(root / filename, bundle / filename)
shutil.copy2(root / "packaging/spoof-pair.py", bundle / "spoof-pair.py")
shutil.copy2(root / "packaging/icmp-pair.py", bundle / "icmp-pair.py")
for filename in ("direct-icmp-pair.py", "direct-icmp-manage.py", "direct-icmp-setup.py", "direct-icmp-doctor.py"):
    shutil.copy2(root / "packaging" / filename, bundle / filename)
shutil.copy2(args.build / "direct-icmp-binaries.json", bundle / "direct-icmp-binaries.json")
shutil.copytree(root / "docs", bundle / "docs")
shutil.copytree(source / "ui", bundle / "ui")
installer = "UNUNKNOWNTUN-V3-INSTALLER-" + version + ".sh"
shutil.copy2(args.build / installer, bundle / installer)
for arch in ("amd64", "arm64"):
    target = bundle / "bin" / ("linux-" + arch)
    target.mkdir(parents=True)
    shutil.copy2(args.build / "bin" / ("ununknowntun-linux-" + arch), target / "ununknowntun")
for filename in ("install-preview.py", "test_install_preview.py"):
    shutil.copy2(args.preview_installer / filename, bundle / filename)
shutil.copytree(args.build / "THIRD_PARTY_LICENSES", bundle / "THIRD_PARTY_LICENSES")
spec = importlib.util.spec_from_file_location("release_scanner", root / "packaging/cdn-endpoints.py")
scanner = importlib.util.module_from_spec(spec); spec.loader.exec_module(scanner)
(bundle / "THIRD_PARTY_LICENSES/SIKDPI-SCANNER-LICENSE").write_text(scanner.SIKDPI_LICENSE)
shutil.copytree(bundle / "THIRD_PARTY_LICENSES", source / "THIRD_PARTY_LICENSES")
(bundle / "validation").mkdir()
shutil.copy2(args.validation / "summary.json", bundle / "validation/summary.json")
for group in checked_logs:
    shutil.copy2(args.validation / (group + ".log"), bundle / "validation" / (group + ".log"))
(bundle / "validation/binary-only-installer.log").write_text(test.stdout + test.stderr)
# Keep the result, not ephemeral private fixture token/certificate files.
tested_arches = [arch for arch in ("amd64", "arm64") if hashlib.sha256((args.build / "bin" / ("ununknowntun-linux-" + arch)).read_bytes()).hexdigest() == integration.get("binary_sha256")]
tested_linux = bool(tested_arches)
integration["binary"] = "shipped Linux executable" if tested_linux else "native test build (not a shipped Linux executable)"
integration.pop("logs", None)
(bundle / "validation/core-proxy-integration.json").write_text(json.dumps(integration, indent=2) + "\n")
for path, relative in checked_audit:
    target = bundle / "validation/additional-audit" / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
runtime_description, untested_runtime = runtime_statement(tested_arches)
report = f"""# Validation — {version}

Status: all {len(summary['results'])} local validation groups passed.

Preview.9 adds easy ICMP pairing, private pool round robin and guided scanner rounds. Preview.8 introduced bounded fixed/adaptive forward error correction to Direct ICMP IPv4 L3, with per-direction feedback and matched private setup. Both peers must support the enabled FEC wire format; old configurations with omitted FEC settings retain off mode. FEC consumes additional traffic and cannot repair complete ICMP blocking. It is not Backpack wire-compatible and does not support IPv6 or ordinary CDN proxying. Tests and privileged runtime evidence are reported separately; no production/WAN performance or DPI guarantee is implied.

Preview.6 adds the full SIKDPI terminal scanner. Its engine, console and installer integration are included in the Python suites. Optional scanner reports, when included, identify actual curl-cffi loopback tests on macOS and standalone-installer tests on Linux. These are not public REALITY/Xray-server, public discovery, WAN-speed or ISP filtering tests. Browser/REALITY modes require optional dependencies; REALITY TCP/raw jobs run serially. This terminal interface retains the original scanner workflows, not the Tkinter graphical interface.

- Go unit/integration suite, race detector and go vet: PASS.
- Python/terminal/binary-only installer tests: {python_tests} total; {skips} optional tests skipped (see logs).
- Twenty real-process loopback profiles: PASS. TLS 1.3, HTTP/2-to-HTTP/1.1 proxy conversion, WSS/XHTTP four modes, MUX on/off, padding, fragmentation, authentication, wrong route rejection, concurrent byte hashes, FIN, slow reader isolation, new stream after egress restart, cleanup.
- Manual ECH and resolver fixture tests run in the Go suite, including strict local ECH acceptance.
- Scheduler/editor rollback and deletion tests use fake services and private temporary files. They do not certify a real systemd installation.
- Linux amd64 and arm64 builds: built and architecture-checked. Runtime integration used {runtime_description}.
- Front end used for the twenty-profile process test: {integration.get('frontend_kind', 'unspecified')}; {integration.get('nginx_version', 'see integration report')}.

Not verified: live Cloudflare/Arvan/Fastly; ISP/spoof reachability; public DNS; customer VLESS clients; sustained WAN bandwidth or multi-day stability{untested_runtime}. Additional bounded soak, fuzz, dependency and isolated GRE results, when present, are recorded separately in additional-audit; they are not Internet deployment tests. No production server or panel was changed.

Preview.4 adds a generation-only native IP-spoof/GRE pair wizard, matched private TLS/token configuration, separate service templates, configuration-only wire plans and rejection categories. Offline pair/installer/parser tests are included above. Privileged generated-launcher wire capture and systemd sandbox results are separate additional-audit logs when present; they must not be inferred from offline tests. The Backhaul reference was inspected statically, never executed or bundled. Matching IP-address semantics do not imply wire/protocol interoperability. Native GRE is separate from HTTP path rotation and CDN modes.

The unsupported ClientHello-over-DNS choice has been removed. ECH DNS discovery remains; it is not DNS tunneling.

3.7 additions exercised by the Go/Python suites: deterministic shared path schedules with bounded overlap and backup routes; authenticated route failover, including split XHTTP upload failures; optional make-before-break carrier renewal; scanner preflight/progress/preview; explicit standalone Iran Nginx entry configuration. Preview.3 adds data-queue payload health probes, bounded route quarantine and signed random recovery routes. Existing streams drain on their original carrier for at most two minutes and are interrupted if still open at that deadline, so they cannot indefinitely block later renewal. The twenty-profile matrix covers compatibility; separate timed reports, when included, cover local fault injection and recovery. Full payload-health coverage requires upgraded peers, and automatic path replacement requires coordinated rotation to be enabled on both peers. Internet destinations beyond the tunnel are not checked. No zero-downtime, DPI-resistance, or public-IP rotation guarantee is made.

Source, tests, Linux binaries and installer are included. Streaming is a UNUNKNOWNTUN transport, not stock Xray wire compatibility. Periodic IP changes restart only the selected tunnel and may interrupt sessions. Do not describe this preview as bug-free or production-certified.
"""
(bundle / "VALIDATION.md").write_text(report)
(bundle / "validation/README.md").write_text(report)
# Current program's sample-data preview; never fabricate live PASS statuses.
ui_spec = importlib.util.spec_from_file_location("release_ui", source / "ui/ununknowntun-ui.py")
ui = importlib.util.module_from_spec(ui_spec); sys.modules[ui_spec.name] = ui; ui_spec.loader.exec_module(ui)
ui.export_html(bundle / "ui/preview.html")
for page in ("tunnels", "tuning", "doctor"):
    (bundle / "ui" / ("preview-" + page + ".txt")).write_text(ui.render(ui.demo_tunnels(), page=page, demo=True))

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
manifest = []
for path in sorted(bundle.rglob("*")):
    if path.is_file(): manifest.append(digest(path) + "  " + path.relative_to(bundle).as_posix())
(bundle / "SHA256SUMS").write_text("\n".join(manifest) + "\n")
files = [p for p in sorted(bundle.rglob("*")) if p.is_file()]
groups = {
    "ALL-FILES": files,
    "INSTALL-AND-UI": [p for p in files if p.relative_to(bundle).parts[0] != "source"],
    "GITHUB-SOURCE": [p for p in files if p.is_relative_to(source)],
    "TESTS-AND-REPORTS": [p for p in files if p.relative_to(bundle).parts[0] in {"source", "validation"} or p.name == "VALIDATION.md"],
}
archives = []
for label, chosen in groups.items():
    archive = out / (name + "-" + label + ".zip")
    chosen = [path for path in chosen if path != bundle / "SHA256SUMS"]
    def relative(path):
        return (path.relative_to(source) if label == "GITHUB-SOURCE" else path.relative_to(bundle)).as_posix()
    # Each archive gets its own manifest: a subset must not reference absent
    # files from the complete bundle.
    archive_manifest = "".join(digest(path) + "  " + relative(path) + "\n" for path in chosen).encode()
    with zipfile.ZipFile(archive, "x", zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
        for path in chosen:
            zipped.write(path, name + "/" + relative(path))
        zipped.writestr(name + "/SHA256SUMS", archive_manifest)
    with zipfile.ZipFile(archive) as zipped:
        if zipped.testzip() is not None: raise SystemExit("ZIP integrity failed")
        if zipped.read(name + "/SHA256SUMS") != archive_manifest:
            raise SystemExit("Packaged manifest mismatch")
        for path in chosen:
            if hashlib.sha256(zipped.read(name + "/" + relative(path))).hexdigest() != digest(path):
                raise SystemExit("Packaged bytes mismatch")
    archives.append({"file": archive.name, "sha256": digest(archive), "bytes": archive.stat().st_size})
    print(label + ": verified " + str(len(chosen)) + " files", flush=True)
(out / "SHA256SUMS").write_text("".join(a["sha256"] + "  " + a["file"] + "\n" for a in archives))
(out / "ARTIFACTS.json").write_text(json.dumps({"version": version, "archives": archives, "python_tests": python_tests, "optional_skips": skips, "integration_profiles": 20, "runtime_tested_linux_arches": tested_arches, "integration_frontend": integration["frontend_kind"]}, indent=2) + "\n")
print("Prepared and verified: " + str(out))
