#!/usr/bin/env python3
"""Assemble reviewed local release artifacts without publishing or overwriting."""
import hashlib
import json
from pathlib import Path
import shutil
import sys
import zipfile

root = Path(__file__).resolve().parent.parent
build = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
if output.exists():
    raise SystemExit("Output directory already exists; choose a new release staging directory.")
version = (root / "VERSION").read_text().strip()
installer = f"UNUNKNOWNTUN-V3-INSTALLER-{version}.sh"
required = [build / installer, root / "xhttp-profile.md", build / "THIRD_PARTY_LICENSES/INDEX.txt", root / "ui/run-tests.py", root / "ui/ununknowntun-ui.py"]
if not all(path.is_file() for path in required):
    raise SystemExit("Build, UI source, profile guide, or dependency notices are missing.")
manifest = json.loads((build / "direct-icmp-binaries.json").read_text())
expected_hashes = {arch: hashlib.sha256((build / "bin" / ("ununknowntun-linux-" + arch)).read_bytes()).hexdigest()
                   for arch in ("amd64", "arm64")}
if manifest != {"version": version, "binary_sha256": expected_hashes}:
    raise SystemExit("Direct ICMP binary manifest does not match release binaries.")
output.mkdir(parents=True)
for helper in ("spoof-pair.py", "icmp-pair.py", "direct-icmp-pair.py", "direct-icmp-manage.py", "direct-icmp-setup.py", "direct-icmp-doctor.py"):
    shutil.copy2(root / "packaging" / helper, output / helper)
shutil.copy2(build / "direct-icmp-binaries.json", output / "direct-icmp-binaries.json")
shutil.copy2(build / installer, output / installer)
shutil.copytree(build / "bin", output / "bin")
shutil.copytree(build / "THIRD_PARTY_LICENSES", output / "THIRD_PARTY_LICENSES")
for name in ("README.md", "README.ru.md", "README.zh-CN.md", "VERSION", "CHANGELOG.md", "xhttp-profile.md"):
    shutil.copy2(root / name, output / name)
shutil.copytree(root / "docs", output / "docs")
excluded = {"README-RC1.md", "RELEASE-NOTES-RC1.md", "RELEASE-VALIDATION.md", "README.fa.txt", "preview-terminal.png", "build.py", "package-complete.py"}
shutil.copytree(root / "ui", output / "ui", ignore=shutil.ignore_patterns("__pycache__", *excluded))
shutil.copy2(root / "packaging/direct-icmp-console.py", output / "ui/direct-icmp-console.py")
# A source checkout may intentionally omit old release reports. Assembly is
# not fresh testing: never require or republish a historical PASS assertion.
(output / "VALIDATION.md").write_text(f"""# Artifact assembly — {version}

This command checks the archive bytes and SHA-256 manifests only. It does not
run the Go, Python, Linux or live-network validation suites and makes no new
claim that they passed. The caller supplies the previously built binaries.

Run packaging/build-complete.sh on a Linux build host for the complete build
pipeline. Preserve fresh results from that run separately. For the reviewed
preview with its fresh test reports, use packaging/package-preview.py.

No tunnel, service, server or CDN configuration was changed by this assembler.
Historical 3.5 release validation reports are deliberately not copied.
""")

source_zip = output / f"UNUNKNOWNTUN-{version}-github-source.zip"
source_files = []
for path in sorted(root.rglob("*")):
    rel = path.relative_to(root)
    if not path.is_file() or path.is_symlink():
        continue
    if any(part in {".git", "__pycache__", "validation", "work-release", "release", "dist"} for part in rel.parts) or path.name in excluded:
        continue
    if rel.parts[0] not in {"packaging", "tests", "docs", "ui", ".github", "THIRD_PARTY_LICENSES"} and len(rel.parts) != 1:
        continue
    if path.suffix not in {".go", ".mod", ".sum", ".md", ".txt", ".py", ".sh", ".yml", ".yaml"} and path.name not in {"VERSION", ".gitignore"} and rel.parts[0] != "THIRD_PARTY_LICENSES":
        continue
    source_files.append(path)
source_names = {path.relative_to(root).as_posix() for path in source_files}
for name in ("ui/run-tests.py", "ui/ununknowntun-ui.py", "packaging/profile-validation.py", "packaging/cdn-endpoints.py", "packaging/cdn-control.py", "packaging/test-cdn-delete.py", ".github/workflows/ci.yml", ".github/workflows/release.yml"):
    if name not in source_names:
        raise SystemExit("Required reproducible source file omitted: " + name)
with zipfile.ZipFile(source_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in source_files:
        archive.write(path, f"UNUNKNOWNTUN-{version}/" + path.relative_to(root).as_posix())
    archive.writestr(f"UNUNKNOWNTUN-{version}/SHA256SUMS", "".join(hashlib.sha256(path.read_bytes()).hexdigest() + "  " + path.relative_to(root).as_posix() + "\n" for path in source_files))
with zipfile.ZipFile(source_zip) as archive:
    assert archive.testzip() is None
    assert f"UNUNKNOWNTUN-{version}/.github/workflows/ci.yml" in archive.namelist()
    for path in source_files:
        assert archive.read(f"UNUNKNOWNTUN-{version}/" + path.relative_to(root).as_posix()) == path.read_bytes()

runtime_zip = output / f"UNUNKNOWNTUN-{version}-linux-bundle.zip"
runtime_files = [path for path in sorted(output.rglob("*")) if path.is_file() and path.suffix != ".zip"]
with zipfile.ZipFile(runtime_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in runtime_files:
        archive.write(path, path.relative_to(output).as_posix())
    archive.writestr("SHA256SUMS", "".join(hashlib.sha256(path.read_bytes()).hexdigest() + "  " + path.relative_to(output).as_posix() + "\n" for path in runtime_files))
with zipfile.ZipFile(runtime_zip) as archive:
    assert archive.testzip() is None

entries = []
for path in sorted(output.rglob("*")):
    if path.is_file():
        entries.append(hashlib.sha256(path.read_bytes()).hexdigest() + "  " + path.relative_to(output).as_posix())
(output / "SHA256SUMS").write_text("\n".join(entries) + "\n")
print(f"Prepared {output}\nSource files: {len(source_files)}; checked files: {len(entries)}")
print("Archives verified; no server configuration or credentials were included. Nothing was published.")
