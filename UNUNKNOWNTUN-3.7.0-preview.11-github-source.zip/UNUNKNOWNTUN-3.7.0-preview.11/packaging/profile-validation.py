#!/usr/bin/env python3
"""Standalone, offline validation for installer profile prompts.

Embedded in the installer; uses only the Python standard library and never
resolves a host, reads a configuration file or executes another program.
The ECH structure rules mirror tunnel-editor.py and ech_source.go. Syntax
acceptance is not proof that a resolver or a CDN supports strict ECH.
"""
import base64
import ipaddress
import json
import re
import sys
import urllib.parse


def domain(value):
    value = value.lower()
    if not value or len(value) > 253 or "." not in value or not re.fullmatch(r"[a-z0-9.-]+", value):
        raise ValueError("Use an ASCII DNS domain without a scheme or path.")
    labels = value.split(".")
    if any(not label or len(label) > 63 or label.startswith("-") or label.endswith("-") for label in labels) or all(label.isdecimal() for label in labels):
        raise ValueError("Invalid DNS domain.")
    try:
        ipaddress.ip_address(value)
    except ValueError:
        return value
    raise ValueError("Use a DNS domain, not an IP address.")


def host(value):
    if not value or any(c in value for c in "/\\,@%?#\"' "):
        raise ValueError("Invalid resolver host.")
    try:
        return str(ipaddress.ip_address(value))
    except ValueError:
        if ":" in value or re.fullmatch(r"[0-9.]+", value):
            raise ValueError("Invalid resolver IP address.") from None
        return domain(value)


def byte_range(value, maximum):
    match = re.fullmatch(r"(0|[1-9][0-9]{0,3})(?:-(0|[1-9][0-9]{0,3}))?", value)
    if not match or not 0 <= int(match[1]) <= int(match[2] or match[1]) <= maximum:
        raise ValueError(f"Use N or MIN-MAX with 0 <= MIN <= MAX <= {maximum}, without leading zeros.")
    return value


def duration(value, *, minimum=0, maximum=604800):
    if value == "0" and minimum == 0:
        return 0
    match = re.fullmatch(r"([1-9][0-9]{0,6})(s|m|h)", value)
    if not match:
        raise ValueError("Use whole seconds, minutes or hours (for example 5m or 2h).")
    seconds = int(match[1]) * {"s": 1, "m": 60, "h": 3600}[match[2]]
    if not minimum <= seconds <= maximum:
        raise ValueError(f"Duration must be {minimum}-{maximum} seconds.")
    return seconds


def path_profile(value):
    def unique_object(pairs):
        result = {}
        for key, item in pairs:
            if key in result:
                raise ValueError("Duplicate rotation profile field.")
            result[key] = item
        return result
    try:
        if not isinstance(value, str) or len(value) > 2048:
            raise ValueError("Invalid rotation profile size.")
        data = json.loads(value, object_pairs_hook=unique_object)
        if not isinstance(data, dict) or set(data) != {"interval", "count", "grace", "legacy"} or any(not isinstance(v, str) for v in data.values()):
            raise ValueError("Use interval/count/grace/legacy strings.")
        interval = duration(data["interval"])
        grace = duration(data["grace"])
        if not re.fullmatch(r"[2-8]", data["count"]) or data["legacy"] not in ("true", "false"):
            raise ValueError("Backup path count must be 2-8; legacy must be true/false.")
        if interval and (interval < 60 or grace > interval):
            raise ValueError("Rotation interval must be at least 1m and grace cannot exceed it.")
        if not interval and data["legacy"] == "true":
            raise ValueError("Legacy-path acceptance is only valid while rotation is enabled.")
        return json.dumps(data, sort_keys=True, separators=(",", ":"))
    except (TypeError, json.JSONDecodeError, RecursionError) as error:
        raise ValueError("Invalid rotation profile.") from error


def ech_source(value):
    """Return the unchanged, single-quote-safe source or raise ValueError."""
    if not isinstance(value, str) or not value or len(value) > 90000 or any(c.isspace() or ord(c) < 32 or ord(c) == 127 or c == "'" for c in value):
        raise ValueError("ECH source is empty, too large or contains whitespace, a control character or an apostrophe.")
    if value == "auto":
        return value
    if "://" in value:
        resolver = value
        prefix = value.split("://", 1)[0]
        if "+" in prefix:
            name, resolver = value.split("+", 1)
            domain(name)
        try:
            parsed = urllib.parse.urlsplit(resolver)
            if parsed.scheme not in ("udp", "tcp", "https") or not parsed.hostname or parsed.username is not None or parsed.password is not None or parsed.fragment:
                raise ValueError()
            if parsed.netloc.endswith(":") or parsed.port is not None and not 1 <= parsed.port <= 65535:
                raise ValueError()
            if parsed.scheme in ("udp", "tcp"):
                if "%" in parsed.hostname:
                    raise ValueError()
                ipaddress.ip_address(parsed.hostname)
                if parsed.path or parsed.query or "?" in resolver:
                    raise ValueError()
            else:
                host(parsed.hostname)
            # urllib accepts malformed percent escapes that Go's URL parser
            # rejects. Refuse those here instead of failing after installation.
            if re.search(r"%(?![0-9A-Fa-f]{2})", resolver):
                raise ValueError()
        except ValueError:
            raise ValueError("Use [domain+]udp://IP[:port], tcp://IP[:port], or verified https://resolver/dns-query; no credentials or fragments.") from None
        return value
    try:
        encoded = value.removeprefix("base64:")
        raw = base64.b64decode(encoded, validate=True)
        if base64.b64encode(raw).decode() != encoded or not 6 <= len(raw) <= 65537 or int.from_bytes(raw[:2], "big") != len(raw) - 2:
            raise ValueError()
        at, usable = 2, False

        def vector(data, index, width):
            if index + width > len(data):
                raise ValueError()
            size = int.from_bytes(data[index:index + width], "big")
            start = index + width
            if start + size > len(data):
                raise ValueError()
            return data[start:start + size], start + size

        while at < len(raw):
            if at + 4 > len(raw):
                raise ValueError()
            version = int.from_bytes(raw[at:at + 2], "big")
            body, at = vector(raw, at + 2, 2)
            if version != 0xfe0d:
                continue
            if len(body) < 3:
                raise ValueError()
            kem = int.from_bytes(body[1:3], "big")
            key, pos = vector(body, 3, 2)
            suites, pos = vector(body, pos, 2)
            if pos >= len(body):
                raise ValueError()
            name, pos = vector(body, pos + 1, 1)
            extensions, pos = vector(body, pos, 2)
            if pos != len(body) or not key or not suites or len(suites) % 4:
                raise ValueError()
            domain(name.decode("ascii"))
            offset, kinds, mandatory = 0, set(), False
            while offset < len(extensions):
                if offset + 4 > len(extensions):
                    raise ValueError()
                kind = int.from_bytes(extensions[offset:offset + 2], "big")
                _, offset = vector(extensions, offset + 2, 2)
                if kind in kinds:
                    raise ValueError()
                kinds.add(kind)
                mandatory = mandatory or bool(kind & 0x8000)
            cipher_ok = any(int.from_bytes(suites[i:i + 2], "big") == 1 and int.from_bytes(suites[i + 2:i + 4], "big") in (1, 2, 3) for i in range(0, len(suites), 4))
            usable = usable or kem == 0x20 and len(key) == 32 and cipher_ok and not mandatory
        if not usable:
            raise ValueError()
    except (ValueError, UnicodeError):
        raise ValueError("Use a structurally valid Base64 ECHConfigList with a supported X25519 configuration, not a server private key.") from None
    return value


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) != 2 or argv[0] not in ("ech", "bytes", "http-bytes", "path-profile", "renewal"):
        print("Usage: profile-validation.py ech|bytes|http-bytes|path-profile|renewal VALUE", file=sys.stderr)
        return 1
    try:
        if argv[0] == "path-profile":
            path_profile(argv[1])
        elif argv[0] == "renewal":
            if argv[1] != "0":
                duration(argv[1], minimum=60)
        elif argv[0] == "ech":
            ech_source(argv[1])
        else:
            byte_range(argv[1], 1024 if argv[0] == "bytes" else 4096)
    except ValueError as error:
        # Never echo a source: a private DoH URL may contain query credentials.
        print(str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
