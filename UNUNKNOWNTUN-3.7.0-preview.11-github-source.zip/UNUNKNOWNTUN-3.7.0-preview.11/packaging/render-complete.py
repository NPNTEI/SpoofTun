#!/usr/bin/env python3
"""BUILD HOST ONLY: render the standalone installer from newly built ELF files."""
import base64
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import struct
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent.parent
out = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else root / "release"
version = (root / "VERSION").read_text().strip()
template = (root / "packaging/full-installer.template.sh").read_text()
helpers = (
    ("../ui/ununknowntun-ui.py", "__TERMINAL_UI_SOURCE__", "TERMINAL_UI_PY"),
    ("direct-icmp-console.py", "__DIRECT_ICMP_CONSOLE_SOURCE__", "DIRECT_ICMP_CONSOLE_PY"),
    ("spoof-pair.py", "__SPOOF_PAIR_SOURCE__", "SPOOF_PAIR_PY"),
    ("icmp-pair.py", "__ICMP_PAIR_SOURCE__", "ICMP_PAIR_PY"),
    ("direct-icmp-pair.py", "__DIRECT_ICMP_PAIR_SOURCE__", "DIRECT_ICMP_PAIR_PY"),
    ("direct-icmp-manage.py", "__DIRECT_ICMP_MANAGE_SOURCE__", "DIRECT_ICMP_MANAGE_PY"),
    ("direct-icmp-setup.py", "__DIRECT_ICMP_SETUP_SOURCE__", "DIRECT_ICMP_SETUP_PY"),
    ("direct-icmp-doctor.py", "__DIRECT_ICMP_DOCTOR_SOURCE__", "DIRECT_ICMP_DOCTOR_PY"),
    ("access-manager.py", "__ACCESS_MANAGER_SOURCE__", "ACCESS_MANAGER_PY"),
    ("tunnel-editor.py", "__TUNNEL_EDITOR_SOURCE__", "TUNNEL_EDITOR_PY"),
    ("editor_tls.py", "__EDITOR_TLS_SOURCE__", "EDITOR_TLS_PY"),
    ("tunnel-doctor.py", "__TUNNEL_DOCTOR_SOURCE__", "TUNNEL_DOCTOR_PY"),
    ("cdn-endpoints.py", "__CDN_ENDPOINTS_SOURCE__", "CDN_ENDPOINTS_PY"),
    ("cdn-control.py", "__CDN_CONTROL_SOURCE__", "CDN_CONTROL_PY"),
    ("scanner-console.py", "__SCANNER_CONSOLE_SOURCE__", "SCANNER_CONSOLE_PY"),
    ("scanner-engine.py", "__SCANNER_ENGINE_SOURCE__", "SCANNER_ENGINE_PY"),
    ("profile-validation.py", "__PROFILE_VALIDATION_SOURCE__", "ECH_SOURCE_VALIDATE"),
    ("profile-validation.py", "__PROFILE_VALIDATION_INSTALLED_SOURCE__", "PROFILE_VALIDATION_PY"),
)
for name, marker, terminator in helpers:
    helper = (root / "packaging" / name).read_text().rstrip()
    compile(helper, name, "exec")
    if template.count(marker) != 1 or terminator in helper.splitlines():
        raise SystemExit(f"Invalid embedded helper marker: {name}")
    template = template.replace(marker, helper)
if not version or any(c not in "0123456789abcdefghijklmnopqrstuvwxyz.-" for c in version):
    raise SystemExit("Invalid release version")
main_source = (root / "main.go").read_text()
source_versions = re.findall(r'^\s*Version\s*=\s*"([^"]+)"', main_source, re.MULTILINE)
if source_versions != [version]:
    raise SystemExit(f"Source/version mismatch: VERSION={version}, main.go={source_versions}")
blobs = {}
checksums = {}
for arch, machine in (("amd64", 62), ("arm64", 183)):
    binary = out / "bin" / f"ununknowntun-linux-{arch}"
    data = binary.read_bytes()
    if data[:6] != b"\x7fELF\x02\x01" or struct.unpack_from("<H", data, 18)[0] != machine:
        raise SystemExit(f"Wrong executable architecture: {arch}")
    blobs[arch] = data
    checksums[arch] = hashlib.sha256(data).hexdigest()
for arch in blobs:
    metadata = subprocess.check_output(["go", "version", "-m", str(out / f"bin/ununknowntun-linux-{arch}")], text=True)
    toolchain = re.search(r": go(\d+)\.(\d+)\.(\d+)(?:\s|$)", metadata.splitlines()[0])
    if not toolchain or tuple(map(int, toolchain.groups())) < (1, 26, 10):
        raise SystemExit(f"Build requires Go 1.26.10 or newer security-patched toolchain: {arch}")
    if "\tpath\tununknowntun\n" not in metadata or "\tbuild\tGOOS=linux\n" not in metadata or f"\tbuild\tGOARCH={arch}\n" not in metadata:
        raise SystemExit(f"Unexpected Go build metadata: {arch}")
native_arch = {"x86_64": "amd64", "amd64": "amd64", "aarch64": "arm64", "arm64": "arm64"}.get(platform.machine().lower())
if platform.system() == "Linux" and native_arch:
    observed = subprocess.check_output([str(out / f"bin/ununknowntun-linux-{native_arch}"), "-version"], text=True).strip()
    if observed != f"ununknowntun {version}":
        raise SystemExit(f"Wrong binary version: {observed}")
template = template.replace("__VERSION__", version)
for arch, digest in checksums.items():
    template = template.replace(f"__{arch.upper()}_SHA256__", digest)
if any(marker in template for marker in ("__VERSION__", "__AMD64_SHA256__", "__ARM64_SHA256__", *(entry[1] for entry in helpers))):
    raise SystemExit("Unexpanded release placeholder")
if "__UNUNKNOWNTUN_AMD64_BEGIN__\n" in template:
    raise SystemExit("Template unexpectedly contains embedded binaries")
output = out / f"UNUNKNOWNTUN-V3-INSTALLER-{version}.sh"
fd, staged = tempfile.mkstemp(prefix="installer-stage-", suffix=".sh", dir=out)
try:
    with os.fdopen(fd, "wb") as stream:
        stream.write(template.rstrip().encode() + b"\n\n")
        for arch, blob in blobs.items():
            stream.write(f"__UNUNKNOWNTUN_{arch.upper()}_BEGIN__\n".encode())
            stream.write(base64.encodebytes(blob))
            stream.write(f"__UNUNKNOWNTUN_{arch.upper()}_END__\n".encode())
    subprocess.run(["bash", "-n", staged], check=True)
    os.chmod(staged, 0o755)
    os.replace(staged, output)
finally:
    if os.path.exists(staged):
        os.unlink(staged)
# Exact-release hashes consumed by the independent Direct ICMP pair helper.
(out / "direct-icmp-binaries.json").write_text(json.dumps({"version": version, "binary_sha256": checksums}, sort_keys=True, indent=2) + "\n")
# Validate the delivered bytes, not just the build inputs.
rendered = output.read_bytes()
for arch in blobs:
    encoded = rendered.split(f"\n__UNUNKNOWNTUN_{arch.upper()}_BEGIN__\n".encode(), 1)[1]
    encoded = encoded.split(f"\n__UNUNKNOWNTUN_{arch.upper()}_END__".encode(), 1)[0]
    if base64.b64decode(encoded) != blobs[arch]:
        raise SystemExit(f"Embedded binary differs: {arch}")
entries = [(hashlib.sha256(rendered).hexdigest(), output.name),
           (hashlib.sha256((out / "direct-icmp-binaries.json").read_bytes()).hexdigest(), "direct-icmp-binaries.json")]
entries.extend((checksums[arch], f"bin/ununknowntun-linux-{arch}") for arch in blobs)
(out / "SHA256SUMS").write_text("".join(f"{digest}  {name}\n" for digest, name in entries))
print(f"Standalone installer: {output}")
print("Embedded amd64/arm64 ELF architectures, Go metadata, source version, checksums and shell syntax: PASS")
for digest, name in entries:
    print(digest, name)
subprocess.run([sys.executable, str(root / "packaging/collect-licenses.py"), str(out)], check=True)
