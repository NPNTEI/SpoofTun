#!/usr/bin/env python3
"""Private, headless SIKDPI console for UNUNKNOWNTUN. No tunnel configuration is changed."""
import os
import sys

# Do not let the launch directory, PYTHONPATH or user site packages supply code.
if __name__ == "__main__" and not sys.flags.isolated:
    os.execv(sys.executable, [sys.executable, "-I", os.path.abspath(__file__), *sys.argv[1:]])

import argparse
import base64
import csv
import datetime
import getpass
import importlib.util
import io
import ipaddress
import json
import math
import re
import signal
import shutil
import stat
import threading
import uuid
from contextlib import contextmanager
from concurrent.futures import ThreadPoolExecutor, as_completed, wait, FIRST_COMPLETED
from pathlib import Path

VERSION = "3.7.0-preview.11"
MAX_JOBS = 4096
MAX_INPUT = 262144
MAX_REPORT = 128 * 1024 * 1024
ENGINE = None
SCHEMA = "ununknowntun.scanner.v1"


def engine():
    global ENGINE
    if ENGINE is not None:
        return ENGINE
    path = Path(os.path.abspath(__file__)).with_name("scanner-engine.py")
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o022:
        raise ValueError("The sibling scanner engine must be a regular, trusted, non-writable file")
    if os.geteuid() == 0:
        for parent in path.parents:
            meta = parent.lstat()
            if not stat.S_ISDIR(meta.st_mode) or meta.st_uid != 0 or meta.st_mode & 0o022:
                raise ValueError("Root scanner engine must have root-owned, non-writable parent directories")
    spec = importlib.util.spec_from_file_location("ununknowntun_scanner_engine", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    ENGINE = module
    return module


def bounded(low, high):
    def parse(value):
        try:
            number = int(value)
        except (TypeError, ValueError):
            raise argparse.ArgumentTypeError("an integer is required") from None
        if not low <= number <= high:
            raise argparse.ArgumentTypeError(f"must be between {low} and {high}")
        return number
    return parse


def transfer_size(value):
    try:
        number = float(value)
    except ValueError:
        raise argparse.ArgumentTypeError("a number is required") from None
    if not math.isfinite(number) or not 0 <= number <= 256:
        raise argparse.ArgumentTypeError("must be between 0 and 256 MiB")
    return number


def _dir_fd(path, create=False, private=False):
    """Walk with directory descriptors: never follow a path-component symlink."""
    path = Path(os.path.abspath(os.path.expanduser(str(path))))
    fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:]:
            if create:
                try:
                    os.mkdir(part, 0o700, dir_fd=fd)
                except FileExistsError:
                    pass
            next_fd = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = next_fd
        if private:
            info = os.fstat(fd)
            if info.st_uid != os.geteuid() or stat.S_IMODE(info.st_mode) != 0o700:
                raise ValueError("Report directory must be owned by you and have permissions 0700")
        return fd
    except BaseException:
        os.close(fd)
        raise


def read_text(path, maximum=MAX_INPUT, secret=False):
    path = Path(os.path.abspath(os.path.expanduser(str(path))))
    parent = _dir_fd(path.parent)
    try:
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
    finally:
        os.close(parent)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > maximum:
            raise ValueError("Input must be a bounded regular file")
        if secret and (info.st_uid != os.geteuid() or info.st_mode & 0o077):
            raise ValueError("Secret input must be owned by you with permissions 0600 or 0400")
        raw = stream.read(maximum + 1)
    if len(raw) > maximum:
        raise ValueError("Input exceeds the permitted size")
    return raw.decode("utf-8-sig")


def private_write(path, text, private_parent=False):
    """Atomic publication with no overwrite, including dangling symlink targets."""
    path = Path(os.path.abspath(os.path.expanduser(str(path))))
    parent = _dir_fd(path.parent, create=True, private=private_parent)
    temporary = ".scanner-" + uuid.uuid4().hex
    fd = None
    try:
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                     0o600, dir_fd=parent)
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as stream:
            fd = None
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.link(temporary, path.name, src_dir_fd=parent, dst_dir_fd=parent, follow_symlinks=False)
        os.fsync(parent)
    finally:
        if fd is not None:
            os.close(fd)
        try:
            os.unlink(temporary, dir_fd=parent)
        except FileNotFoundError:
            pass
        os.close(parent)
    return str(path)


def default_report_dir():
    # A predictable private directory; environment overrides are deliberately ignored.
    return str(Path.home() / ".local" / "state" / "ununknowntun" / "scanner-reports")


def authorize(args, description):
    if not getattr(args, "authorized", False):
        raise ValueError("Network operations require --authorized (only test targets you own or may test)")
    print(description + " | Ctrl+C: cancel and save completed rows", file=sys.stderr)


@contextmanager
def cancel_scope():
    event = threading.Event()
    previous = signal.getsignal(signal.SIGINT)
    engine().set_cancel_event(event)
    signal.signal(signal.SIGINT, lambda signum, frame: event.set())
    try:
        yield event
    finally:
        signal.signal(signal.SIGINT, previous)
        engine().set_cancel_event(None)


def public_address(value, allow_private=False):
    ip = ipaddress.ip_address(value)
    if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped:
        ip = ip.ipv4_mapped
    # Cloud metadata ranges remain denied even with explicit private-network consent.
    if ip.is_link_local or ip.is_unspecified or ip.is_multicast or str(ip) in {
        "100.100.100.200", "168.63.129.16", "192.0.0.192", "fd00:ec2::254"
    }:
        raise ValueError("Link-local, metadata, unspecified and multicast targets are forbidden")
    if ip.is_global:
        return str(ip)
    local = ip.is_loopback
    if ip.version == 4:
        local = local or ip in ipaddress.ip_network("10.0.0.0/8") or ip in ipaddress.ip_network("172.16.0.0/12") or ip in ipaddress.ip_network("192.168.0.0/16") or ip in ipaddress.ip_network("100.64.0.0/10")
    else:
        local = local or ip in ipaddress.ip_network("fc00::/7")
    if not (allow_private and local):
        raise ValueError("A non-public target was refused; authorized private/loopback networks need --allow-private")
    return str(ip)


def resolve_pinned(host, port, allow_private, timeout_ms):
    try:
        return public_address(host, allow_private)
    except ValueError:
        try:
            ipaddress.ip_address(host)
        except ValueError:
            pass
        else:
            raise
    addresses = engine()._getaddrinfo(host, port, timeout_ms / 1000)
    checked = list(dict.fromkeys(public_address(item[4][0], allow_private) for item in addresses))
    if not checked:
        raise ValueError("Target has no usable addresses")
    # Every DNS answer is checked; the exact connection address is then frozen.
    return checked[0]


def domains_from(text):
    if len(text.encode("utf-8")) > MAX_INPUT:
        raise ValueError("Candidate input is too large")
    domains, invalid = engine().parse_domain_list(text)
    if invalid:
        raise ValueError("Invalid domain candidates; use plain domain names")
    if not domains or len(domains) > MAX_JOBS:
        raise ValueError("Provide between 1 and 4096 domain candidates")
    return domains


def ip_candidates(text):
    if len(text.encode("utf-8")) > MAX_INPUT:
        raise ValueError("Candidate input is too large")
    values = []
    for token in re.split(r"[,\s]+", text.strip()):
        if not token:
            continue
        if "/" in token:
            net = ipaddress.ip_network(token, strict=False)
            total = net.num_addresses
            if net.version == 4 and net.prefixlen < 31:
                total -= 2
            elif net.version == 6 and net.prefixlen < 127:
                total -= 1
            if total > MAX_JOBS:
                raise ValueError("CIDR exceeds 4096 candidates; choose an explicit smaller CIDR (nothing was truncated)")
            values.extend(str(ip) for ip in net.hosts())
        else:
            values.append(str(ipaddress.ip_address(token)))
        values = list(dict.fromkeys(values))
        if len(values) > MAX_JOBS:
            raise ValueError("Input exceeds 4096 unique candidates; choose a smaller explicit set")
    if not values:
        raise ValueError("Provide an IP, CIDR, or input file")
    return values


ROW_FIELDS = (
    "ip", "target", "connect_host", "port", "method", "sni", "fingerprint", "fingerprint_effective", "status", "verdict",
    "success", "count", "packet_loss", "avg_ping", "min_ping", "max_ping", "jitter", "stddev",
    "tcp_status", "tcp_success", "tcp_count", "tcp_packet_loss", "tcp_avg_ping", "tcp_min_ping",
    "tcp_max_ping", "tcp_jitter", "tcp_stddev", "tls_version", "tls_versions", "alpn", "failure_reason",
    "reality_last_error", "attempt_diagnostics", "latencies", "download_mbps", "upload_mbps",
    "download_ok", "upload_ok", "download_bytes", "upload_bytes", "download_elapsed_s", "upload_elapsed_s",
    "download_http_status", "upload_http_status",
    "download_mb", "upload_mb", "error", "filtered", "scan_error", "tcp", "reality",
    "round", "planned_count", "max_latency_ms", "partial"
)
TOKEN_FIELDS = {"status", "verdict", "method", "fingerprint", "fingerprint_effective", "tcp_status", "tls_version", "alpn", "failure_reason", "category", "phase"}
ADDRESS_FIELDS = {"ip", "connect_host", "target", "sni"}


def error_code(value):
    if not value:
        return None
    upper = str(value).upper()
    for word in ("CANCELLED", "FINGERPRINT_ERROR", "DEPENDENCY_ERROR", "XRAY_START_TIMEOUT", "XRAY_START_ERROR", "XRAY_BINARY_ERROR",
                 "PROBE_TIMEOUT", "TIMEOUT", "TLS_ERROR", "DNS_ERROR", "NETWORK_ERROR",
                 "REALITY_REJECTED_OR_FALLBACK", "PROBE_ERROR", "PORT_FILTERED"):
        if word in upper:
            return word
    return "OPERATION_FAILED"


def clean_value(key, value):
    if value is None or isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value if math.isfinite(value) else None
    if key in {"error", "reality_last_error", "scan_error", "last_error"}:
        return error_code(value)
    if isinstance(value, list):
        if len(value) > 1000:
            raise ValueError("Too many result details")
        return [clean_value(key, item) for item in value]
    if isinstance(value, dict):
        allowed = {"attempt", "phase", "category", "error", "ok", "latency_ms", "elapsed_ms", "elapsed_s",
                   "attempts", "success", "failed", "timeouts", "network_errors", "avg_ms", "jitter_ms", "latencies"}
        return {k: clean_value(k, v) for k, v in value.items() if k in allowed}
    if not isinstance(value, str):
        return None
    if key in ADDRESS_FIELDS:
        if len(value) > 300 or any(c in value for c in "@/?#\\\n\r\x1b"):
            return "REDACTED"
        if not re.fullmatch(r"[A-Za-z0-9_.:\[\]-]+", value):
            return "REDACTED"
        return value
    if key in TOKEN_FIELDS or key == "tls_versions":
        return value if re.fullmatch(r"[A-Za-z0-9_./ +:,-]{0,100}", value) else "REDACTED"
    return None


def clean_row(row):
    return {key: clean_value(key, row[key]) for key in ROW_FIELDS if key in row}


def rank(row):
    order = {"VALID": 0, "FLAKY": 1, "PROBE_TIMEOUT": 3, "TIMEOUT": 4, "NETWORK_ERROR": 5, "INVALID": 6}
    return (order.get(row.get("verdict"), 2), row.get("packet_loss") if row.get("packet_loss") is not None else 100,
            row.get("avg_ping") if row.get("avg_ping") is not None else math.inf,
            row.get("jitter") if row.get("jitter") is not None else math.inf, str(row.get("ip", "")))


def display(value):
    if value is None:
        return "-"
    if isinstance(value, (list, dict)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    return str(value)


def table(rows):
    # Every scalar metric present in the report is shown, with no top-ten cutoff.
    fields = [key for key in ROW_FIELDS if key != "attempt_diagnostics" and any(key in row for row in rows)]
    output = [[str(index)] + [display(row.get(key)) for key in fields] for index, row in enumerate(rows, 1)]
    headings = ["#"] + fields
    widths = [len(h) for h in headings]
    for row in output:
        widths = [max(width, len(value)) for width, value in zip(widths, row)]
    return "\n".join(" | ".join(v.ljust(w) for v, w in zip(row, widths)) for row in [headings, *output]) + "\n"


def viewport(rows):
    """A bounded terminal overview; full values remain in detail/full view/export."""
    name_width = max(12, min(32, shutil.get_terminal_size((110, 24)).columns - 74))
    columns = [("#", 3), ("IP / SNI", name_width), ("State", 8), ("OK/N", 7),
               ("Loss%", 6), ("Avg ms", 8), ("Jitter", 7), ("DL Mbps", 8), ("UL Mbps", 8)]
    data = [[str(index), row.get("ip"), row.get("verdict") or row.get("status"),
             f"{display(row.get('success'))}/{display(row.get('count'))}", row.get("packet_loss"),
             row.get("avg_ping"), row.get("jitter"), row.get("download_mbps"), row.get("upload_mbps")]
            for index, row in enumerate(rows, 1)]
    def line(values):
        return " ".join((display(value)[:width - 1] + "…" if len(display(value)) > width else display(value)).ljust(width)
                        for value, (_, width) in zip(values, columns))
    return "\n".join([line([label for label, _ in columns]), *[line(row) for row in data]]) + "\n"


def render(rows, format_name, report=None):
    if format_name == "json":
        return json.dumps(report if report is not None else rows, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    if format_name == "csv":
        fields = [key for key in ROW_FIELDS if any(key in row for row in rows)]
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: display(value) if isinstance(value, (list, dict)) else value for key, value in row.items()})
        return stream.getvalue()
    output = table(rows)
    for index, row in enumerate(rows, 1):
        if row.get("attempt_diagnostics"):
            output += f"\nRow {index} attempt details:\n" + json.dumps(row["attempt_diagnostics"], indent=2) + "\n"
    return output


def load_report(path):
    report = json.loads(read_text(path, MAX_REPORT))
    if not isinstance(report, dict) or report.get("schema") != SCHEMA:
        raise ValueError("Not a supported scanner report")
    rows = report.get("rows")
    if not isinstance(rows, list) or len(rows) > MAX_JOBS or any(not isinstance(r, dict) for r in rows):
        raise ValueError("Invalid or oversized report rows")
    # Rebuild the object: untrusted metadata/unknown fields must not reappear in exports.
    return {"schema": SCHEMA, "version": VERSION, "kind": report.get("kind") if report.get("kind") in
            ("ip", "sni", "reality", "speed", "discover") else "unknown",
            "created_at": str(report.get("created_at", ""))[:40] if re.fullmatch(r"[0-9TZ:.+\-]{0,40}", str(report.get("created_at", ""))) else "",
            "cancelled": report.get("cancelled") is True,
            "planned": report.get("planned") if isinstance(report.get("planned"), int) else len(rows),
            "rows": [clean_row(row) for row in rows]}


def save_report(args, kind, rows, planned, cancelled=False):
    rows = sorted([clean_row(row) for row in rows], key=rank)
    report = {"schema": SCHEMA, "version": VERSION, "kind": kind,
              "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "cancelled": cancelled, "planned": planned, "rows": rows}
    name = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:12] + ".json"
    path = private_write(Path(args.report_dir) / name, render(rows, "json", report), private_parent=True)
    print(f"Report: {path}\nCompleted: {len(rows)}/{planned}; cancelled: {cancelled}", file=sys.stderr)
    rendered = render(rows, getattr(args, "format", "table"), report if getattr(args, "format", "table") == "json" else None)
    if getattr(args, "output", None):
        print("Export: " + private_write(args.output, rendered), file=sys.stderr)
    elif getattr(args, "compact", False):
        print(viewport(rows), end="")
    else:
        print(rendered, end="")
    args.last_report = path
    return 130 if cancelled else 0


def parallel(items, worker, workers):
    if not 1 <= len(items) <= MAX_JOBS:
        raise ValueError("A scan must contain 1 to 4096 jobs")
    cancellation = threading.Event()
    engine().set_cancel_event(cancellation)
    rows = []
    previous = signal.getsignal(signal.SIGINT)
    def stop(signum, frame):
        cancellation.set()
    signal.signal(signal.SIGINT, stop)
    try:
        with ThreadPoolExecutor(max_workers=min(workers, len(items))) as pool:
            futures = {pool.submit(worker, item): item for item in items}
            for future in as_completed(futures):
                if cancellation.is_set():
                    for pending in futures:
                        pending.cancel()
                if future.cancelled():
                    continue
                try:
                    row = future.result()
                except engine().ScanCancelled:
                    continue
                except Exception as exc:
                    item = futures[future]
                    row = dict(item) if isinstance(item, dict) else {"ip": item}
                    row.update(status="Error", scan_error=error_code(str(exc)))
                rows.append(clean_row(row))
                short = {key: rows[-1].get(key) for key in ("ip", "status", "verdict", "success", "count", "avg_ping", "download_mbps", "upload_mbps") if key in rows[-1]}
                print(f"[{len(rows)}/{len(items)}] " + json.dumps(short, ensure_ascii=False), file=sys.stderr)
    finally:
        signal.signal(signal.SIGINT, previous)
        engine().set_cancel_event(None)
    return rows, cancellation.is_set()


def need_curl():
    if not engine().HAVE_CURL_CFFI:
        raise ValueError("This mode needs optional curl-cffi. Install it in a trusted Python environment, then rerun; nothing was installed automatically")


def secret_link(args, attribute="reality_config"):
    path = getattr(args, attribute, None)
    if path:
        value = read_text(path, 16384, secret=True).strip()
    elif getattr(args, "secret_prompt", False) and sys.stdin.isatty():
        value = getpass.getpass("Config link (hidden; never stored in the report): ").strip()
    else:
        raise ValueError("Provide a protected config file or --secret-prompt on a terminal; links are never command arguments")
    if not value or len(value) > 16384 or "\n" in value or "\r" in value:
        raise ValueError("The secret input must contain exactly one bounded link")
    return value


def reality_setup(args):
    need_curl()
    params = engine().parse_reality_link(secret_link(args))
    if params.get("error"):
        raise ValueError("Invalid VLESS/Trojan REALITY config; only TCP/raw transport is supported; verify port, security=reality and public key")
    if getattr(args, "fingerprint", None):
        params["fingerprint"] = args.fingerprint
    if not getattr(args, "xray", None):
        raise ValueError("Provide --xray with an explicitly trusted absolute executable path; use dependencies for setup")
    engine().set_xray_binary(args.xray)
    path, _detail = engine().ensure_xray_binary(allow_download=False)
    return path, params


def ip_worker(args, row):
    e = engine()
    address, port = row["connect_host"], row["port"]
    if getattr(args, "port_filter", False) and not e.check_port(address, port, args.filter_timeout / 1000):
        return dict(row, status="Filtered", count=0, success=0, packet_loss=None, avg_ping=None,
                    failure_reason="PORT_FILTERED", filtered=True)
    method = row["method"]
    if method == "tcp":
        measured = e.tcp_handshake_ping(address, port, args.count, args.timeout)
    elif method == "tls":
        measured = e.tls_handshake_ping(address, port, row["sni"], args.count, args.timeout)
    else:
        measured = e.browser_tls_ping(address, port, row["sni"], args.count, args.timeout, row["fingerprint"])
    return dict(row, **measured)


def command_ip(args):
    text = "\n".join(args.targets + ([read_text(args.input_file)] if args.input_file else []))
    addresses = [public_address(ip, args.allow_private) for ip in ip_candidates(text)]
    sni = domains_from(args.sni)[0]
    if args.method == "browser":
        need_curl()
    jobs = [dict(ip=ip, connect_host=ip, port=args.port, method=args.method, sni=sni, fingerprint=args.fingerprint) for ip in addresses]
    authorize(args, f"IP scan: {len(jobs)} targets, {args.count} attempts each, {args.method}, port {args.port}")
    rows, cancelled = parallel(jobs, lambda row: ip_worker(args, row), args.workers)
    return save_report(args, "ip", rows, len(jobs), cancelled)


def ipv4_range(value):
    """Represent a range arithmetically; never expand a large CIDR in memory."""
    if not isinstance(value, str) or len(value) > 100:
        raise ValueError("Enter one IPv4 CIDR or START-END range")
    value = value.strip()
    try:
        if "/" in value:
            network = ipaddress.IPv4Network(value, strict=False)
            first, last = int(network.network_address), int(network.broadcast_address)
            if network.prefixlen < 31:
                first, last = first + 1, last - 1
            label = str(network)
        elif "-" in value:
            start, end = value.split("-", 1)
            first, last = int(ipaddress.IPv4Address(start.strip())), int(ipaddress.IPv4Address(end.strip()))
            label = str(ipaddress.IPv4Address(first)) + "-" + str(ipaddress.IPv4Address(last))
        else:
            first = last = int(ipaddress.IPv4Address(value))
            label = str(ipaddress.IPv4Address(first))
    except (ValueError, TypeError):
        raise ValueError("Enter one IPv4 CIDR or START-END range") from None
    if first > last:
        raise ValueError("Range start must not exceed range end")
    return first, last, label


def sample_ipv4_range(value, count, allow_private=False):
    first, last, _ = ipv4_range(value)
    if type(count) is not int or not 1 <= count <= min(MAX_JOBS, last - first + 1):
        raise ValueError("Sample count must fit the range and be between 1 and 4096")
    # Even spacing covers the requested range instead of quietly taking its first N IPs.
    offsets = [0] if count == 1 else [index * (last - first) // (count - 1) for index in range(count)]
    return [public_address(str(ipaddress.IPv4Address(first + offset)), allow_private) for offset in offsets]


def round_rank(row):
    """Manual round ranking: fewer failed attempts, then lower mean/jitter."""
    return (row.get("packet_loss") if row.get("packet_loss") is not None else 100, row.get("avg_ping") if row.get("avg_ping") is not None else math.inf,
            row.get("jitter") if row.get("jitter") is not None else math.inf, str(row.get("ip", "")))


def round_worker(args, ip, emit):
    e = engine()
    times, diagnostics, attempts = [], [], 0
    row = dict(ip=ip, connect_host=ip, port=args.port, method=args.method, sni=args.sni,
               fingerprint=args.fingerprint, round=args.round_number,
               planned_count=args.count, max_latency_ms=args.timeout)
    for index in range(args.count):
        try:
            e._check_cancel()
            emit(f"[Round {args.round_number}] {ip}:{args.port} | {args.method.upper()} probe {index + 1}/{args.count}")
            if args.method == "tcp":
                measured = e.tcp_handshake_ping(ip, args.port, 1, args.timeout)
            elif args.method == "tls":
                measured = e.tls_handshake_ping(ip, args.port, args.sni, 1, args.timeout)
            else:
                measured = e.browser_tls_ping(ip, args.port, args.sni, 1, args.timeout, args.fingerprint)
            # Compare the unrounded sample, so 100.04 ms cannot pass a 100 ms limit.
            samples = measured.get("latencies", [])
            latency = samples[0] if samples else measured.get("avg_ping")
            attempts += 1
            if measured.get("success", 0) > 0 and isinstance(latency, (float, int)) and math.isfinite(latency) and 0 <= latency <= args.timeout:
                times.append(float(latency))
                emit(f"[GOOD] {ip}:{args.port} | probe {index + 1}: {latency:.1f} ms")
            else:
                reason = "TIMEOUT" if isinstance(latency, (float, int)) and latency > args.timeout else error_code(measured.get("error"))
                if not reason:
                    details = measured.get("attempt_diagnostics", [])
                    reason = (error_code(details[0].get("error")) if details else None) or "OPERATION_FAILED"
                diagnostics.append({"attempt": index + 1, "phase": args.method, "error": reason})
                emit(f"[FAILED] {ip}:{args.port} | probe {index + 1}: {reason}")
        except e.ScanCancelled:
            if not attempts:
                raise
            break
        except Exception as exc:
            attempts += 1
            reason = error_code(e._safe_error(exc)) or "OPERATION_FAILED"
            diagnostics.append({"attempt": index + 1, "phase": args.method, "error": reason})
            emit(f"[FAILED] {ip}:{args.port} | probe {index + 1}: {reason}")
    row.update(count=attempts, success=len(times), packet_loss=round((1 - len(times) / attempts) * 100, 1),
               avg_ping=round(sum(times) / len(times), 1) if times else None,
               status="Online" if times else "Offline", latencies=times,
               attempt_diagnostics=diagnostics, partial=attempts < args.count)
    row.update(e._ping_stats(times))
    return clean_row(row)


def scan_round(args, candidates):
    """Only workers active at cancellation may finish; no unbounded queued jobs."""
    if not candidates or len(candidates) > MAX_JOBS:
        raise ValueError("A round requires 1..4096 candidates")
    rows, print_lock = [], threading.Lock()
    def emit(message):
        with print_lock:
            print(message, file=sys.stderr, flush=True)
    with cancel_scope() as stopped:
        with ThreadPoolExecutor(max_workers=min(args.workers, len(candidates))) as pool:
            iterator, pending = iter(candidates), {}
            def submit():
                if stopped.is_set():
                    return
                ip = next(iterator, None)
                if ip is not None:
                    pending[pool.submit(round_worker, args, ip, emit)] = ip
            for _ in range(min(args.workers, len(candidates))):
                submit()
            while pending:
                ready, _ = wait(pending, timeout=.1, return_when=FIRST_COMPLETED)
                if stopped.is_set():
                    for future in pending:
                        future.cancel()
                for future in ready:
                    ip = pending.pop(future)
                    if not future.cancelled():
                        try:
                            row = future.result()
                        except engine().ScanCancelled:
                            row = None
                        except Exception:
                            row = dict(ip=ip, connect_host=ip, port=args.port, method=args.method,
                                       round=args.round_number, status="Error", count=0, success=0,
                                       packet_loss=100, avg_ping=None, scan_error="OPERATION_FAILED")
                        if row is not None:
                            rows.append(row)
                            emit(f"[Completed {len(rows)}/{len(candidates)}] {ip} | OK {row.get('success', 0)}/{row.get('count', 0)} | loss {row.get('packet_loss', 100)}% | average {display(row.get('avg_ping'))} ms")
                    submit()
        cancelled = stopped.is_set()
    return sorted(rows, key=round_rank), cancelled


def ask_number(label, default, low, high):
    while True:
        try:
            return bounded(low, high)(ask(label, str(default)))
        except argparse.ArgumentTypeError as exc:
            print("Invalid value: " + str(exc), file=sys.stderr)


def choose_round_ip(rows):
    eligible = {row["ip"] for row in rows if row.get("success", 0) > 0 and row.get("count", 0) > 0}
    if not eligible:
        print("No successful IP in this round; no IP selected.", file=sys.stderr)
        return None
    best = next(row["ip"] for row in rows if row["ip"] in eligible)
    print("Select a successful IP from the latest round. Partial rows are marked in the saved report.", file=sys.stderr)
    while True:
        value = ask("IP to use (q = finish without selection)", best)
        if value.lower() == "q":
            return None
        try:
            value = str(ipaddress.IPv4Address(value))
        except ValueError:
            value = ""
        if value in eligible:
            return value
        print("Choose an IP with a successful probe in the latest displayed round.", file=sys.stderr)


def command_rounds(args):
    """Iterative manual narrowing; automatic CDN scoring/apply remains separate."""
    if args.selected_output and os.path.lexists(os.path.expanduser(args.selected_output)):
        raise ValueError("Selected-IP output already exists; choose a new file")
    if not args.authorized:
        if not sys.stdin.isatty() or not confirm("Test the requested range under your authorization?"):
            raise ValueError("Network operations require --authorized")
        args.authorized = True
    while True:
        try:
            raw_range = args.ip_range or ask("IPv4 range (CIDR or START-END)")
            first, last, range_label = ipv4_range(raw_range)
            break
        except ValueError as exc:
            if args.ip_range:
                raise
            print(str(exc), file=sys.stderr)
    maximum = min(MAX_JOBS, last - first + 1)
    sample_count = args.sample or ask_number(f"How many IPs from this range (1..{maximum})", min(256, maximum), 1, maximum)
    candidates = sample_ipv4_range(raw_range, sample_count, args.allow_private)
    args.port = args.port if args.port is not None else 443
    args.sni = domains_from(args.sni)[0]
    if args.method == "browser":
        need_curl()
    print(f"Range: {range_label}; {len(candidates)} distinct, evenly spaced candidates. Port: {args.port} (inherited when launched from a tunnel; standalone default 443).", file=sys.stderr)
    print(f"Measurement: {args.method.upper()} handshake latency, not ICMP Echo or tunnel authentication. Ctrl+C stops this round and keeps finished probes for selection.", file=sys.stderr)
    history_rows, last_rows, cancelled = [], [], False
    args.round_number = 0
    while candidates:
        args.round_number += 1
        print(f"\nROUND {args.round_number} — {len(candidates)} candidates", file=sys.stderr)
        args.count = ask_number("Probes per IP (1..100)", args.count, 1, 100)
        args.workers = ask_number("Simultaneous workers (1..32)", args.workers, 1, 32)
        args.timeout = ask_number("Maximum latency in ms (higher is TIMEOUT)", args.timeout, 1, 120000)
        last_rows, cancelled = scan_round(args, candidates)
        print("Best to worst: lower loss, then lower mean latency and jitter.", file=sys.stderr)
        save_report(args, "ip", last_rows, len(candidates), cancelled)
        history_rows.append({"round": args.round_number, "candidates": len(candidates),
                             "probes_per_ip": args.count, "workers": args.workers,
                             "maximum_latency_ms": args.timeout, "cancelled": cancelled,
                             "completed_ips": len(last_rows), "report": Path(args.last_report).name})
        if not last_rows or not confirm("Run another round on the top results?"):
            break
        top = ask_number(f"How many top IPs (1..{len(last_rows)})", len(last_rows), 1, len(last_rows))
        candidates = [row["ip"] for row in last_rows[:top]]
    selected = choose_round_ip(last_rows)
    session = {"schema": "ununknowntun.scanner.rounds.v1", "version": VERSION, "range": range_label,
               "sample_count": sample_count, "port": args.port, "method": args.method, "sni": args.sni,
               "ranking": ["packet_loss", "avg_ping", "jitter", "ip"], "rounds": history_rows,
               "selected_ip": selected, "tunnel_authenticated": False,
               "automatic_policy_changed": False, "configuration_changed": False}
    path = private_write(Path(args.report_dir) / ("rounds-" + uuid.uuid4().hex + ".json"),
                         json.dumps(session, indent=2) + "\n", private_parent=True)
    print("Round history: " + path, file=sys.stderr)
    args.session_report, args.selected_ip = path, selected
    if selected is None:
        return 130 if cancelled else 2
    if args.selected_output:
        private_write(args.selected_output, selected + "\n")
    print("SELECTED_IP=" + selected)
    print("Candidate selected. The tunnel manager must authenticate it before applying it; automatic scan policy is unchanged.", file=sys.stderr)
    return 0


def collect_domains(args):
    chunks = list(getattr(args, "snis", []))
    if getattr(args, "sni_file", None):
        chunks.append(read_text(args.sni_file))
    if getattr(args, "common", False):
        chunks.extend(engine().COMMON_REALITY_DOMAINS)
    return domains_from("\n".join(chunks))


def sni_worker(args, row, setup=None):
    if setup:
        raw = engine().reality_sni_test(
            setup[0], setup[1], row["connect_host"], row["port"], row["ip"], args.count, args.timeout,
            xray_ready_timeout_s=args.timeout / 1000, probe_timeout_ms=args.timeout,
        )
        measured = engine().reality_result_to_row(raw)
        measured["reality"] = raw.get("reality")
        measured["tcp"] = raw.get("tcp")
        measured.update(row)
        return measured
    measured = engine().sni_target_test(row["connect_host"], row["port"], row["ip"], args.count, args.timeout, row["fingerprint"])
    measured.update(row)
    return measured


def command_sni(args):
    need_curl()
    candidates = collect_domains(args)
    raw_targets = "\n".join([args.target] + ([read_text(args.target_file)] if args.target_file else []))
    targets, invalid = engine().parse_target_list(raw_targets, args.port)
    if invalid or not targets or len(targets) * len(candidates) > MAX_JOBS:
        raise ValueError("Invalid targets or more than 4096 target/SNI combinations; reduce the input explicitly")
    authorize(args, f"SNI scan: {len(targets)} targets × {len(candidates)} SNI candidates, {args.count} attempts each")
    setup = reality_setup(args) if args.reality_config or args.secret_prompt else None
    if setup:
        print("REALITY jobs run one at a time to coordinate local Xray safely; worker options do not increase REALITY concurrency.", file=sys.stderr)
    jobs = []
    for label, host, port in targets:
        if args.server:
            host, port, err = engine().parse_target_string(args.server, port)
            if err:
                raise ValueError("Invalid server override")
        address = resolve_pinned(host, port, args.allow_private, args.timeout)
        fingerprint = setup[1].get("fingerprint", "chrome") if setup else (args.fingerprint or "chrome")
        jobs.extend(dict(ip=sni, target=label, connect_host=address, port=port, method="reality" if setup else "sni", fingerprint=fingerprint) for sni in candidates)
    rows, cancelled = parallel(jobs, lambda row: sni_worker(args, row, setup), 1 if setup else args.workers)
    return save_report(args, "reality" if setup else "sni", rows, len(jobs), cancelled)


def selected_rows(args, report):
    rows = list(report["rows"])
    if getattr(args, "online", False):
        rows = [row for row in rows if row.get("status") == "Online"]
    if getattr(args, "filter", None):
        needle = args.filter.casefold()
        rows = [row for row in rows if needle in json.dumps(row, ensure_ascii=False).casefold()]
    if getattr(args, "sort", None):
        key = args.sort
        def sort_key(row):
            value = row.get(key)
            return (value is None, 0 if isinstance(value, (int, float)) else 1, value if isinstance(value, (int, float)) else str(value or ""))
        rows.sort(key=sort_key, reverse=getattr(args, "descending", False))
    else:
        rows.sort(key=rank)
    if getattr(args, "rows", None):
        indexes = []
        for token in args.rows.split(","):
            if "-" in token:
                a, b = token.split("-", 1)
                start, end = int(a), int(b)
                if not 1 <= start <= end <= len(rows):
                    raise ValueError("Selected row range is out of bounds")
                indexes.extend(range(start, end + 1))
            else:
                indexes.append(int(token))
        if not indexes or len(indexes) > MAX_JOBS or any(i < 1 or i > len(rows) for i in indexes):
            raise ValueError("Selected row number is out of bounds")
        rows = [rows[i - 1] for i in dict.fromkeys(indexes)]
    if getattr(args, "top", None):
        rows = rows[:args.top]
    return rows


def command_retest(args):
    report = load_report(args.report)
    if report["kind"] not in ("ip", "sni", "reality", "speed"):
        raise ValueError("Choose an IP, SNI, or REALITY scan report")
    rows = selected_rows(args, report)
    if not rows:
        raise ValueError("No matching rows")
    is_ip = report["kind"] == "ip"
    if (getattr(args, "method", None) or getattr(args, "sni", None)) and not is_ip:
        raise ValueError("--method and --sni overrides apply to IP reports; SNI reports preserve candidate domains")
    override_sni = domains_from(args.sni)[0] if getattr(args, "sni", None) else None
    for row in rows:
        for field in ("port", "method", "fingerprint"):
            if getattr(args, field, None) is not None:
                row[field] = getattr(args, field)
        if override_sni:
            row["sni"] = override_sni
        row["connect_host"] = public_address(row["connect_host"], args.allow_private)
        bounded(1, 65535)(row["port"])
        if row.get("method") not in ("tcp", "tls", "browser", "sni", "reality"):
            raise ValueError("Report has an unsupported scan method")
    authorize(args, f"Retest: {len(rows)} selected rows; {args.count} attempts each; existing pinned addresses")
    is_reality = not is_ip and any(row.get("method") == "reality" for row in rows)
    setup = reality_setup(args) if is_reality else None
    if setup:
        print("REALITY retests run one at a time; worker options do not increase REALITY concurrency.", file=sys.stderr)
        for row in rows:
            row["fingerprint"] = setup[1].get("fingerprint", "chrome")
    if not is_ip or any(row["method"] == "browser" for row in rows):
        need_curl()
    jobs = [{key: value for key, value in row.items() if key in ("ip", "connect_host", "target", "port", "method", "sni", "fingerprint")} for row in rows]
    result, cancelled = parallel(jobs, (lambda row: ip_worker(args, row)) if is_ip else (lambda row: sni_worker(args, row, setup)), 1 if setup else args.workers)
    return save_report(args, "ip" if is_ip else ("reality" if is_reality else "sni"), result, len(jobs), cancelled)


def command_speed(args):
    report = load_report(args.report)
    if report["kind"] not in ("reality", "sni", "speed"):
        raise ValueError("Speed testing requires a SNI/REALITY report and your REALITY credentials")
    rows = selected_rows(args, report)
    if not rows or args.download_mb + args.upload_mb <= 0:
        raise ValueError("Select at least one row and a positive transfer size")
    total = len(rows) * (args.download_mb + args.upload_mb)
    if total > 4096:
        raise ValueError("Total requested transfer exceeds 4096 MiB; reduce Top N or transfer size")
    authorize(args, f"REALITY speed test through speed.cloudflare.com: {len(rows)} rows, {args.download_mb} MiB down + {args.upload_mb} MiB up each; up to {total:g} MiB payload plus protocol overhead")
    if not args.traffic_consent:
        raise ValueError("Speed tests consume traffic; add --traffic-consent after reviewing the displayed amount")
    setup = reality_setup(args)
    print("REALITY speed tests run one at a time; worker options do not increase REALITY concurrency.", file=sys.stderr)
    for row in rows:
        row["connect_host"] = public_address(row["connect_host"], args.allow_private)
        bounded(1, 65535)(row["port"])
        domains_from(row["ip"])
    def speed(row):
        value = engine().high_accuracy_speed_test(setup[0], setup[1], row["connect_host"], row["port"], row["ip"], args.download_mb, args.upload_mb, args.timeout)
        return dict(row, **value, method="reality", fingerprint=setup[1].get("fingerprint", "chrome"),
                    download_mb=args.download_mb, upload_mb=args.upload_mb)
    result, cancelled = parallel(rows, speed, 1)
    return save_report(args, "speed", result, len(rows), cancelled)


def command_discover(args):
    bases = domains_from("\n".join(args.domains))
    if len(bases) > 32:
        raise ValueError("Discovery is limited to 32 explicit base domains")
    authorize(args, f"Certificate-transparency lookup on crt.sh for {len(bases)} base domains (this does not prove usability)")
    rows, seen, cancelled = [], set(), False
    with cancel_scope() as event:
        try:
            for index, base in enumerate(bases, 1):
                # Ask for one more to detect overflow; never quietly hide expansion.
                found, error = engine().find_subdomains_via_crtsh(base, timeout=args.timeout / 1000, limit=args.limit + 1)
                if error:
                    print(f"{base}: {error_code(error)}", file=sys.stderr)
                    rows.append({"ip": base, "target": base, "status": "Error", "error": error_code(error)})
                    continue
                if len(found) > args.limit:
                    raise ValueError("Discovery exceeded the requested limit; narrow the base domain or raise --limit (nothing was silently truncated)")
                for domain in domains_from("\n".join(found)) if found else []:
                    if domain == base or domain.endswith("." + base):
                        if domain not in seen:
                            rows.append(dict(ip=domain, target=base, status="Discovered"))
                            seen.add(domain)
                if len(rows) > MAX_JOBS:
                    raise ValueError("Discovery exceeds 4096 candidates; narrow the request")
                print(f"[{index}/{len(bases)}] {base}: {len(found)} candidates; {len(rows)} unique total", file=sys.stderr)
                engine()._check_cancel()
        except engine().ScanCancelled:
            cancelled = True
        cancelled = cancelled or event.is_set()
    if args.candidates_output:
        print("Candidates: " + private_write(args.candidates_output, "\n".join(row["ip"] for row in rows if row["status"] == "Discovered") + "\n"), file=sys.stderr)
    return save_report(args, "discover", rows, len(rows), cancelled)


def history(directory):
    try:
        fd = _dir_fd(directory, private=True)
    except FileNotFoundError:
        return []
    try:
        names = sorted((name for name in os.listdir(fd) if re.fullmatch(r"\d{8}T\d{6}Z-[0-9a-f]{12}\.json", name)), reverse=True)
    finally:
        os.close(fd)
    return [str(Path(directory) / name) for name in names]


def command_results(args):
    if not args.report:
        for number, path in enumerate(history(args.report_dir), 1):
            report = load_report(path)
            print(f"{number}. {Path(path).name} | {report['kind']} | {len(report['rows'])}/{report['planned']} | cancelled={report['cancelled']}")
        return 0
    report = load_report(args.report)
    rows = selected_rows(args, report)
    if args.detail:
        if args.detail > len(rows):
            raise ValueError("Detail row number is out of bounds")
        print(json.dumps(rows[args.detail - 1], ensure_ascii=False, indent=2))
    else:
        print(f"{report['kind']} | {len(rows)} selected / {len(report['rows'])} saved | cancelled={report['cancelled']}")
        print(render(rows, args.format), end="")
    return 0


def command_export(args):
    report = load_report(args.report)
    rows = selected_rows(args, report)
    report["rows"] = rows
    print(private_write(args.output, render(rows, args.format, report if args.format == "json" else None)))
    return 0


def command_sni_json(args):
    if args.report:
        rows = selected_rows(args, load_report(args.report))
        names = domains_from("\n".join(row["ip"] for row in rows))
    else:
        names = collect_domains(args)
    host, port, error = engine().parse_target_string(args.target, args.port)
    if error:
        raise ValueError("Invalid JSON target")
    value = {"security": "reality", "realitySettings": {"show": False, "xver": 0,
             "target": f"[{host}]:{port}" if ":" in host else f"{host}:{port}", "serverNames": names}}
    text = json.dumps(value, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        print(private_write(args.output, text))
    else:
        print(text, end="")
    return 0


def command_configs(args):
    report = load_report(args.report)
    if report["kind"] != "ip":
        raise ValueError("Config IP replacement requires an IP scan report")
    rows = selected_rows(args, report)
    if not rows:
        raise ValueError("No matching IP rows")
    link = secret_link(args, "config_file")
    if not link.startswith(("vless://", "vmess://", "trojan://", "ss://")):
        raise ValueError("Supported formats: VLESS, VMess, Trojan, Shadowsocks")
    links = []
    for row in rows:
        ip = str(ipaddress.ip_address(row["ip"]))
        value = engine().modify_config_link(link, ip)
        if not value:
            raise ValueError("The supplied config link could not be rewritten safely")
        links.append(value)
    path = private_write(args.output, "\n".join(links) + "\n")
    print(f"Saved {len(links)} credential-bearing links privately to {path}; no tunnel settings were applied")
    return 0


def command_dependencies(args):
    e = engine()
    print(f"Python: {sys.version.split()[0]}; stdlib TCP/TLS: available; curl-cffi: {'available' if e.HAVE_CURL_CFFI else 'missing (optional)'}")
    print(f"Xray pinned download version: {e.XRAY_PINNED_VERSION}; no automatic package installation")
    if args.action == "install":
        authorize(args, "Download explicitly requested: pinned Xray release and SHA-256 verification")
        with cancel_scope():
            path, _detail = e.ensure_xray_binary(force_download=False, allow_download=True)
        print("Trusted Xray path: " + path)
    elif args.xray:
        path = e.set_xray_binary(args.xray)
        if args.action == "check":
            path, _detail = e.ensure_xray_binary(allow_download=False)
        print("Explicit Xray path: " + path)
    else:
        print("No Xray path selected. Supply --xray /absolute/trusted/xray; status does not execute a binary")
    return 0


def add_selection(parser, top=False):
    parser.add_argument("--sort", choices=ROW_FIELDS)
    parser.add_argument("--descending", action="store_true")
    parser.add_argument("--filter", help="case-insensitive result text filter")
    parser.add_argument("--online", action="store_true")
    parser.add_argument("--rows", help="selected row numbers after sorting/filtering, e.g. 1,3-5")
    if top:
        parser.add_argument("--top", type=bounded(1, MAX_JOBS), default=20)


def add_output(parser):
    parser.add_argument("--report-dir", default=default_report_dir())
    parser.add_argument("--format", choices=("table", "json", "csv", "txt"), default="table")
    parser.add_argument("--output", help="new output file (never overwritten)")


def add_network(parser):
    parser.add_argument("--authorized", action="store_true", help="confirm permission to test all requested targets")
    parser.add_argument("--allow-private", action="store_true", help="also permit authorized private/loopback targets; metadata remains forbidden")
    parser.add_argument("--count", type=bounded(1, 100), default=4)
    parser.add_argument("--timeout", type=bounded(100, 120000), default=4000, metavar="MS",
                        help="per network phase; REALITY applies this separately to TCP, Xray startup and tunnel probe (queueing/cleanup extra)")
    parser.add_argument("--workers", type=bounded(1, 32), default=8,
                        help="parallel generic scan jobs; REALITY and speed jobs always run one at a time")


def add_secret(parser):
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--reality-config", metavar="FILE", help="0600 file containing one VLESS/Trojan TCP/raw REALITY link")
    group.add_argument("--secret-prompt", action="store_true", help="hidden interactive link prompt")
    parser.add_argument("--xray", help="explicit trusted absolute Xray executable")


def add_snis(parser):
    parser.add_argument("snis", nargs="*")
    parser.add_argument("--sni-file")
    parser.add_argument("--common", action="store_true")


def build_parser():
    parser = argparse.ArgumentParser(description="UNUNKNOWNTUN SIKDPI headless scanner. No args: interactive console. Only test authorized targets.")
    parser.add_argument("--version", action="version", version=VERSION)
    commands = parser.add_subparsers(dest="command")
    p = commands.add_parser("rounds", help="interactive IP sampling, repeated Top N rounds and final IP selection")
    p.add_argument("--range", dest="ip_range", help="one IPv4 CIDR or START-END; asked when omitted")
    p.add_argument("--sample", type=bounded(1, MAX_JOBS), help="number of distinct IPs sampled across the range")
    p.add_argument("--port", type=bounded(1, 65535), help="tunnel's current port; standalone default is 443")
    p.add_argument("--sni", default="www.cloudflare.com")
    p.add_argument("--method", choices=("tcp", "tls", "browser"), default="tcp")
    p.add_argument("--fingerprint", choices=("chrome", "chrome124", "chrome131", "chrome136", "safari", "safari_ios", "firefox"), default="chrome")
    p.add_argument("--selected-output", help="new file containing only the final selected IPv4; no configuration is applied")
    p.add_argument("--authorized", action="store_true")
    p.add_argument("--allow-private", action="store_true")
    p.add_argument("--count", type=bounded(1, 100), default=4, help="initial prompt default, not a skipped prompt")
    p.add_argument("--timeout", type=bounded(1, 120000), default=500, help="initial maximum-latency prompt default, ms")
    p.add_argument("--workers", type=bounded(1, 32), default=8, help="initial prompt default")
    p.add_argument("--report-dir", default=default_report_dir())
    p.set_defaults(handler=command_rounds, compact=True)
    p = commands.add_parser("ip", help="IP/CIDR/file TCP, TLS or browser TLS scan")
    p.add_argument("targets", nargs="*")
    p.add_argument("--input-file")
    p.add_argument("--port", type=bounded(1, 65535), default=443)
    p.add_argument("--method", choices=("tcp", "tls", "browser"), default="tcp")
    p.add_argument("--sni", default="www.cloudflare.com")
    p.add_argument("--fingerprint", choices=("chrome", "chrome124", "chrome131", "chrome136", "safari", "safari_ios", "firefox"), default="chrome")
    p.add_argument("--port-filter", action="store_true")
    p.add_argument("--filter-timeout", type=bounded(100, 120000), default=3000)
    add_network(p); add_output(p); p.set_defaults(handler=command_ip)
    p = commands.add_parser("sni", help="generic browser TLS/SNI or authenticated REALITY")
    p.add_argument("target", help="host or host:port; bracket IPv6")
    p.add_argument("--target-file", help="additional targets, one per line")
    p.add_argument("--server", help="connect override, e.g. your own REALITY server")
    p.add_argument("--port", type=bounded(1, 65535), default=443)
    p.add_argument("--fingerprint", choices=("chrome", "chrome124", "chrome131", "chrome136", "safari", "safari_ios", "firefox"), help="generic default chrome; REALITY default comes from secret link")
    p.add_argument("--reality-workers", type=bounded(1, 32), default=1,
                   help="compatibility option; REALITY jobs are serialized and always run one at a time")
    add_snis(p); add_secret(p); add_network(p); add_output(p); p.set_defaults(handler=command_sni)
    p = commands.add_parser("discover", help="crt.sh subdomain discovery")
    p.add_argument("domains", nargs="+")
    p.add_argument("--limit", type=bounded(1, MAX_JOBS - 1), default=400)
    p.add_argument("--candidates-output", help="new plain candidate file for --sni-file")
    add_network(p); add_output(p); p.set_defaults(handler=command_discover, timeout=15000)
    for name, handler in (("retest", command_retest), ("speed", command_speed)):
        p = commands.add_parser(name, help="retest selected Top N" if name == "retest" else "REALITY download/upload of selected Top N")
        p.add_argument("report")
        add_selection(p, top=True); add_secret(p); add_network(p); add_output(p)
        p.set_defaults(handler=handler, count=10)
        p.add_argument("--fingerprint", choices=("chrome", "chrome124", "chrome131", "chrome136", "safari", "safari_ios", "firefox"), help="optional fingerprint override")
        if name == "retest":
            p.add_argument("--method", choices=("tcp", "tls", "browser"), help="override method for an IP report")
            p.add_argument("--sni", help="override TLS SNI for an IP report")
            p.add_argument("--port", type=bounded(1, 65535), help="override port of selected destinations")
        if name == "speed":
            p.add_argument("--download-mb", type=transfer_size, default=20.0)
            p.add_argument("--upload-mb", type=transfer_size, default=10.0)
            p.add_argument("--traffic-consent", action="store_true")
            p.set_defaults(timeout=15000, workers=1)
    p = commands.add_parser("results", help="history, all result rows, sorting/filtering and attempt details")
    p.add_argument("report", nargs="?")
    p.add_argument("--detail", type=bounded(1, MAX_JOBS))
    add_selection(p); add_output(p); p.set_defaults(handler=command_results)
    p = commands.add_parser("export", help="export every selected field/attempt to JSON, CSV or TXT")
    p.add_argument("report"); p.add_argument("--output", required=True)
    p.add_argument("--format", choices=("json", "csv", "txt"), required=True)
    add_selection(p); p.set_defaults(handler=command_export)
    p = commands.add_parser("sni-json", help="generate REALITY target/serverNames snippet; no application")
    p.add_argument("target"); p.add_argument("--port", type=bounded(1, 65535), default=443)
    p.add_argument("--report"); p.add_argument("--output")
    add_snis(p); add_selection(p); p.set_defaults(handler=command_sni_json)
    p = commands.add_parser("configs", help="rewrite IP destinations in VLESS/VMess/Trojan/SS links")
    p.add_argument("report"); p.add_argument("--config-file"); p.add_argument("--secret-prompt", action="store_true")
    p.add_argument("--output", required=True)
    add_selection(p); p.set_defaults(handler=command_configs)
    for name in ("dependencies", "xray"):
        p = commands.add_parser(name, help="optional dependencies and explicit Xray setup")
        p.add_argument("action", choices=("status", "check", "install"), nargs="?", default="status")
        p.add_argument("--xray"); p.add_argument("--authorized", action="store_true")
        p.set_defaults(handler=command_dependencies)
    return parser


def ask(label, default=""):
    value = input(label + (f" [{default}]" if default != "" else "") + ": ").strip()
    return value or default


def confirm(label):
    return ask(label + " (yes/no)", "no").casefold() in ("yes", "y")


def choose_report(directory):
    paths = history(directory)
    for index, path in enumerate(paths, 1):
        report = load_report(path)
        print(f"{index}. {Path(path).name} | {report['kind']} | {len(report['rows'])} rows")
    choice = ask("Report number or full file path")
    if choice.isdigit() and 1 <= int(choice) <= len(paths):
        return paths[int(choice) - 1]
    return choice


def browse(path):
    report = load_report(path)
    args = argparse.Namespace(sort=None, filter=None, online=False, descending=False, rows=None)
    page, size = 0, 20
    while True:
        rows = selected_rows(args, report)
        page = min(page, max(0, (len(rows) - 1) // size))
        start = page * size
        print(f"\n{path}\nRows {start + 1 if rows else 0} to {min(start + size, len(rows))} of {len(rows)} | page {page + 1}")
        print(viewport(rows[start:start + size]), end="")
        print("Summary view; d shows every field for one row, a shows every field for all rows. Ellipsis only shortens the display.")
        print("n next | p previous | a all | d details | s sort | f filter | e export | q back")
        action = ask("Choice", "q").lower()
        if action == "q": return
        if action == "n": page += 1
        elif action == "p": page = max(0, page - 1)
        elif action == "a": print(render(rows, "txt"), end="")
        elif action == "d":
            number = bounded(1, len(rows))(ask("Row number on this page"))
            index = start + number - 1
            if index >= min(start + size, len(rows)):
                raise ValueError("Row number is outside this page")
            print(json.dumps(rows[index], ensure_ascii=False, indent=2))
        elif action == "s":
            print(", ".join(ROW_FIELDS))
            field = ask("Column name", "avg_ping")
            if field not in ROW_FIELDS: raise ValueError("Unknown column")
            args.sort, args.descending, page = field, confirm("Descending?"), 0
        elif action == "f": args.filter, page = ask("Text filter; empty for all"), 0
        elif action == "e":
            fmt = ask("Format json/csv/txt", "txt")
            if fmt not in ("json", "csv", "txt"): raise ValueError("Unknown format")
            output = ask("New output file path")
            print(private_write(output, render(rows, fmt, dict(report, rows=rows) if fmt == "json" else None)))


def wizard_network(argv, speed=False):
    if not speed:
        argv += ["--count", ask("Attempts 1..100", "4")]
    argv += ["--timeout", ask("Deadline per network phase, milliseconds", "15000" if speed else "4000")]
    if speed or "--reality-config" in argv or "--secret-prompt" in argv:
        print("REALITY and speed tests run one at a time to coordinate Xray safely.")
        argv += ["--workers", "1"]
    else:
        argv += ["--workers", ask("Simultaneous jobs 1..32", "8")]
    if speed:
        print("This deadline applies to download and upload separately; Xray startup and queueing take extra time.")
    elif "--reality-config" in argv or "--secret-prompt" in argv:
        print("For REALITY, this deadline applies separately to TCP, Xray startup and the tunnel probe; queueing and cleanup are additional.")
    if confirm("Also include authorized private/loopback targets?"):
        argv.append("--allow-private")
    print("Only test targets you own or may test. Ctrl+C stops and saves completed results.")
    if not confirm("Send network probes with these settings?"):
        return False
    argv.append("--authorized")
    return True


def wizard_secret(argv):
    path = ask("Private REALITY file path (empty: enter the link hidden when prompted)")
    argv += ["--reality-config", path] if path else ["--secret-prompt"]
    argv += ["--xray", ask("Absolute trusted Xray path")]


def wizard(parser):
    if not sys.stdin.isatty():
        parser.print_help()
        return 0
    directory = default_report_dir()
    while True:
        print(f"\nFull SIKDPI scanner / UNUNKNOWNTUN {VERSION}\n1 Guided IP scan rounds and selection\n2 SNI / REALITY scan\n3 Discover domains with crt.sh\n4 History and all results\n5 Retest Top N\n6 REALITY download/upload\n7 JSON/CSV/TXT export\n8 REALITY domain JSON\n9 Generate links with selected IPs\n10 Dependencies / Xray\n11 Advanced IP/CIDR/file scan\n0 Exit")
        try:
            choice = ask("Choice", "0")
            if choice == "0": return 0
            if choice == "4": browse(choose_report(directory)); continue
            argv = []
            if choice == "1":
                args = parser.parse_args(["rounds", "--report-dir", directory])
                args.handler(args)
                continue
            elif choice == "11":
                argv = ["ip"]
                source = ask("1 Enter IPs/CIDRs separated by spaces, 2 File", "1")
                if source == "2": argv += ["--input-file", ask("File path")]
                else: argv += ask("IPs or CIDRs separated by spaces").split()
                method = ask("Method tcp/tls/browser", "tcp")
                argv += ["--method", method, "--port", ask("Port", "443")]
                if method != "tcp": argv += ["--sni", ask("SNI", "www.cloudflare.com")]
                if method == "browser": argv += ["--fingerprint", ask("fingerprint: chrome/chrome124/chrome131/chrome136/safari/safari_ios/firefox", "chrome")]
                if confirm("Enable initial port filter?"):
                    argv += ["--port-filter", "--filter-timeout", ask("Filter timeout, milliseconds", "3000")]
            elif choice == "2":
                argv = ["sni", ask("Target IP or hostname; optional port")]
                source = ask("SNI: 1 Manual, 2 File, 3 Built-in domains, 4 crt.sh discovery", "1")
                if source == "2": argv += ["--sni-file", ask("SNI file path")]
                elif source == "3": argv += ["--common"]
                elif source == "4":
                    base = ask("Base domain")
                    if not confirm("Send domain discovery request to crt.sh?"): continue
                    dargs = parser.parse_args(["discover", base, "--authorized", "--report-dir", directory])
                    command_discover(dargs)
                    found = [row["ip"] for row in load_report(dargs.last_report)["rows"] if row.get("status") == "Discovered"]
                    if not found: raise ValueError("No discovered candidates")
                    argv += found
                else: argv += ask("SNI domains separated by spaces").split()
                override = ask("Server override (empty: use target)")
                if override: argv += ["--server", override]
                argv += ["--port", ask("Default port", "443")]
                if confirm("Authenticated REALITY test using your own config?"):
                    wizard_secret(argv)
                    fingerprint = ask("Optional fingerprint; empty: use link value")
                    if fingerprint: argv += ["--fingerprint", fingerprint]
                else: argv += ["--fingerprint", ask("Browser fingerprint", "chrome")]
            elif choice == "3":
                argv = ["discover", *ask("Base domains separated by spaces").split(), "--limit", ask("Maximum domains per base (no silent truncation)", "400")]
                output = ask("New domain list file (optional)")
                if output: argv += ["--candidates-output", output]
            elif choice in ("5", "6"):
                argv = ["retest" if choice == "5" else "speed", choose_report(directory), "--top", ask("Top N", "20")]
                report = load_report(argv[1])
                if choice == "6" or report["kind"] in ("reality", "speed"): wizard_secret(argv)
                if choice == "5":
                    if report["kind"] == "ip":
                        method = ask("New method tcp/tls/browser; empty: keep current")
                        if method: argv += ["--method", method]
                        sni = ask("New SNI; empty: keep current")
                        if sni: argv += ["--sni", sni]
                    port = ask("New port; empty: keep current")
                    if port: argv += ["--port", port]
                fingerprint = ask("Optional fingerprint; empty: keep current or REALITY link value")
                if fingerprint: argv += ["--fingerprint", fingerprint]
                if choice == "6":
                    dl, ul = ask("Download MiB per row", "20"), ask("Upload MiB per row", "10")
                    print(f"Requested traffic is at most {min(int(argv[3]), len(report['rows'])) * (transfer_size(dl) + transfer_size(ul)):g} MiB plus overhead; destination is speed.cloudflare.com through REALITY.")
                    if not confirm("Use this amount of traffic?"): continue
                    argv += ["--download-mb", dl, "--upload-mb", ul, "--traffic-consent"]
            elif choice == "7":
                argv = ["export", choose_report(directory), "--format", ask("json/csv/txt", "txt"), "--output", ask("New output file path")]
            elif choice == "8":
                argv = ["sni-json", ask("Destination target:port"), "--report", choose_report(directory)]
                output = ask("New output path; empty: display")
                if output: argv += ["--output", output]
            elif choice == "9":
                argv = ["configs", choose_report(directory), "--rows", ask("Selected rows such as 1,3-5"), "--output", ask("New private output file")]
                config = ask("Private file path; empty: hidden input")
                argv += ["--config-file", config] if config else ["--secret-prompt"]
            elif choice == "10":
                argv = ["dependencies", ask("status/check/install", "status")]
                if argv[1] == "install":
                    if not confirm("Download the pinned Xray release with SHA-256 verification?"): continue
                    argv += ["--authorized"]
                else:
                    path = ask("Absolute Xray path (optional)")
                    if path: argv += ["--xray", path]
            else:
                print("Invalid selection"); continue
            if choice in ("11", "2", "3", "5", "6"):
                if not wizard_network(argv, speed=choice == "6"): continue
                argv += ["--report-dir", directory]
            args = parser.parse_args(argv)
            result = args.handler(args)
            if getattr(args, "last_report", None): browse(args.last_report)
        except EOFError:
            print("\nExit")
            return 0
        except KeyboardInterrupt:
            print("\nBack; no new operation started")
        except (Exception, SystemExit) as exc:
            print("Error: " + safe_exception(exc), file=sys.stderr)


def safe_exception(exc):
    if isinstance(exc, (ValueError, argparse.ArgumentTypeError)):
        text = str(exc)
        if not any(marker in text for marker in ("://", "@", "\x1b", "\n")) and len(text) <= 500:
            return text
        return "Invalid input (sensitive diagnostic omitted)"
    if isinstance(exc, FileExistsError): return "Output already exists; choose a new filename"
    if isinstance(exc, FileNotFoundError): return "Required file or directory was not found"
    if isinstance(exc, PermissionError): return "Access refused; verify ownership and private file permissions"
    if isinstance(exc, json.JSONDecodeError): return "Invalid report JSON"
    return "Operation failed (raw diagnostics omitted to protect secrets)"


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if not args.command:
            return wizard(parser)
        return args.handler(args)
    except KeyboardInterrupt:
        print("Cancelled before scan completion", file=sys.stderr)
        return 130
    except Exception as exc:
        if ENGINE is not None and isinstance(exc, ENGINE.ScanCancelled):
            print("Cancelled", file=sys.stderr)
            return 130
        print("error: " + safe_exception(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
