"""Headless scanning engine for UNUNKNOWNTUN, adapted from MIT-licensed SIKDPI Scanner.

This module intentionally has no Tkinter dependency so it can be used on servers.
Only scan systems and networks that you own or are authorized to test.
"""

import os
import re
import json
import ssl
import time
import base64
import socket
import subprocess
import ipaddress
import urllib.parse
import urllib.request
import urllib.error
import zipfile
import platform
import shutil
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import errno
import math
import queue
import select
import stat
import tempfile
import threading
import uuid
from contextlib import contextmanager

MAX_CANDIDATES = 4096
MAX_INPUT_BYTES = 262144
MAX_ATTEMPTS = 100
MAX_TIMEOUT_MS = 120000
MAX_TRANSFER_BYTES = 256 * 1024 * 1024
MAX_BUFFERED_UPLOAD_BYTES = 16 * 1024 * 1024
# curl_cffi's write wrapper ignores short byte counts; this sentinel aborts.
CURL_WRITEFUNC_ERROR = 0xFFFFFFFF
MAX_DNS_WORKERS = 8
REALITY_SUPPORTED_TRANSPORTS = frozenset({"tcp", "raw"})
_cancel_event = None
_explicit_xray_path = None
_xray_lock = threading.RLock()
_dns_slots = threading.BoundedSemaphore(MAX_DNS_WORKERS)


class ScanCancelled(Exception):
    """The caller requested cancellation; never report this as a failed target."""


class CurlCapabilityError(Exception):
    """Installed curl_cffi cannot safely perform the requested transfer."""


def set_cancel_event(event):
    """Set one shared cancellation Event before starting a batch, or clear with None."""
    global _cancel_event
    if event is not None and not isinstance(event, threading.Event):
        raise TypeError("Cancellation must be a threading.Event or None")
    _cancel_event = event


def _check_cancel():
    if _cancel_event is not None and _cancel_event.is_set():
        raise ScanCancelled("Scan cancelled")


def _input_text(value):
    if not isinstance(value, str) or len(value.encode("utf-8")) > MAX_INPUT_BYTES:
        raise ValueError("Input is too large (maximum 262144 bytes)")
    if any(ord(c) < 32 and c not in "\n\r\t" for c in value):
        raise ValueError("Input contains control characters")
    return value


def _bounded_int(value, minimum, maximum, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or int(value) != value:
        raise ValueError(f"{label} must be an integer")
    if not minimum <= value <= maximum:
        raise ValueError(f"{label} must be between {minimum} and {maximum}")
    return int(value)


def _timeout_seconds(value):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 < value <= MAX_TIMEOUT_MS / 1000:
        raise ValueError("Timeout must be positive and at most 120 seconds")
    return float(value)


def _validate_host(host, domain_only=False):
    host = _input_text(host).strip().rstrip(".").lower()
    if not domain_only:
        try:
            if "%" in host:
                raise ValueError("Scoped IPv6 addresses are not supported")
            return str(ipaddress.ip_address(host))
        except ValueError:
            pass
    try:
        host = host.encode("idna").decode("ascii")
    except UnicodeError:
        raise ValueError("Invalid hostname") from None
    if not _DOMAIN_RE.fullmatch(host):
        raise ValueError("Invalid hostname")
    return host


def _attempt_args(host, port, count, timeout_ms, sni=None):
    _check_cancel()
    _validate_host(host)
    _bounded_int(port, 1, 65535, "Port")
    _bounded_int(count, 1, MAX_ATTEMPTS, "Attempts")
    _bounded_int(timeout_ms, 1, MAX_TIMEOUT_MS, "Timeout milliseconds")
    if sni is not None:
        _validate_host(sni, domain_only=True)


def _safe_error(error):
    """Never expose URLs, credentials, subprocess output, or untrusted error text."""
    if isinstance(error, CurlCapabilityError):
        return "DEPENDENCY_ERROR: installed curl_cffi lacks streaming uploads; use an upload of at most 16 MiB or upgrade curl_cffi"
    if isinstance(error, (TimeoutError, socket.timeout)):
        return "TIMEOUT: operation timed out"
    if isinstance(error, ssl.SSLError):
        return "TLS_ERROR: TLS handshake failed"
    if isinstance(error, ConnectionRefusedError):
        return "NETWORK_ERROR: connection refused"
    if isinstance(error, ConnectionResetError):
        return "NETWORK_ERROR: connection reset"
    if isinstance(error, socket.gaierror):
        return "DNS_ERROR: name resolution failed"
    code = getattr(error, "code", None)
    if code == 28:
        return "TIMEOUT: operation timed out"
    return "NETWORK_ERROR: operation failed"


def _getaddrinfo(host, port, timeout):
    """Bound DNS wait and outstanding resolver threads, including timed-out calls.

    The system resolver cannot be interrupted safely. Its daemon worker retains
    a shared slot until it actually returns, so repeated caller timeouts cannot
    accumulate an unbounded number of blocked threads.
    """
    host = _validate_host(host)
    _bounded_int(port, 1, 65535, "Port")
    _timeout_seconds(timeout)
    _check_cancel()
    try:
        ip = ipaddress.ip_address(host)
        family = socket.AF_INET6 if ip.version == 6 else socket.AF_INET
        return [(family, socket.SOCK_STREAM, 0, "", (host, port))]
    except ValueError:
        pass
    deadline = time.monotonic() + timeout
    slots = _dns_slots
    while True:
        _check_cancel()
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("DNS capacity wait timed out")
        if slots.acquire(timeout=min(0.1, remaining)):
            break
    result = queue.Queue(maxsize=1)
    def lookup():
        try:
            result.put((socket.getaddrinfo(host, port, type=socket.SOCK_STREAM), None))
        except Exception as exc:
            result.put((None, exc))
        finally:
            slots.release()
    try:
        _check_cancel()
        threading.Thread(target=lookup, daemon=True, name="ununknowntun-scanner-dns").start()
    except BaseException:
        slots.release()
        raise
    while True:
        _check_cancel()
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("DNS timeout")
        try:
            addresses, error = result.get(timeout=min(0.1, remaining))
            if error:
                raise error
            return addresses
        except queue.Empty:
            continue


def _connect_socket(host, port, timeout):
    deadline = time.monotonic() + _timeout_seconds(timeout)
    addresses = _getaddrinfo(host, port, timeout)
    last_error = OSError("No address available")
    for family, kind, proto, _, address in addresses:
        _check_cancel()
        sock = socket.socket(family, kind, proto)
        try:
            sock.setblocking(False)
            code = sock.connect_ex(address)
            if code not in (0, errno.EINPROGRESS, errno.EWOULDBLOCK, errno.EALREADY):
                raise OSError(code, "Connection failed")
            while code != 0:
                _check_cancel()
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError("Connection timeout")
                _, writable, errors = select.select([], [sock], [sock], min(0.1, remaining))
                if writable or errors:
                    code = sock.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR)
                    if code:
                        raise OSError(code, "Connection failed")
            sock.settimeout(max(0.001, deadline - time.monotonic()))
            return sock
        except BaseException as exc:
            sock.close()
            if isinstance(exc, ScanCancelled) or not isinstance(exc, Exception):
                raise
            last_error = exc
            if time.monotonic() >= deadline:
                break
    raise last_error


def _tls_connect(ctx, host, port, sni, timeout):
    deadline = time.monotonic() + timeout
    sock = _connect_socket(host, port, timeout)
    tls_sock = None
    try:
        tls_sock = ctx.wrap_socket(sock, server_hostname=sni, do_handshake_on_connect=False)
        tls_sock.setblocking(False)
        while True:
            _check_cancel()
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("TLS timeout")
            try:
                tls_sock.do_handshake()
                return tls_sock
            except ssl.SSLWantReadError:
                select.select([tls_sock], [], [], min(0.1, remaining))
            except ssl.SSLWantWriteError:
                select.select([], [tls_sock], [], min(0.1, remaining))
    except BaseException:
        (tls_sock or sock).close()
        raise


@contextmanager
def _serialized_xray():
    while not _xray_lock.acquire(timeout=0.1):
        _check_cancel()
    try:
        _check_cancel()
        yield
    finally:
        _xray_lock.release()

DEFAULT_SNI = "www.cloudflare.com"

NEXT_PHASE_DEFAULT_COUNT = "10"
NEXT_PHASE_DEFAULT_TIMEOUT = "1500"
DEFAULT_FILTER_TIMEOUT_MS = "3000"
CIDR_ASK_THRESHOLD = 5000


SNI_MODE_DEFAULT_COUNT = "5"
SNI_MODE_DEFAULT_TIMEOUT_MS = "4000"

COMMON_REALITY_DOMAINS = [
    "www.apple.com",
    "gateway.icloud.com",
    "www.microsoft.com",
    "www.swift.org",
    "www.amd.com",
    "discord.com",
    "www.samsung.com",
    "cdn.jsdelivr.net",
    "www.cloudflare.com",
    "www.nvidia.com",
]

# ---- Speed test (Low Accuracy / High Accuracy) ----
SPEEDTEST_DEFAULT_DOWNLOAD_MB = "20"
SPEEDTEST_DEFAULT_UPLOAD_MB = "10"
SPEEDTEST_DEFAULT_HOST = "speed.cloudflare.com"
SPEEDTEST_DOWNLOAD_PATH = "/__down?bytes={bytes}"
SPEEDTEST_UPLOAD_PATH = "/__up"
XRAY_LOCAL_HOST = "127.0.0.1"
XRAY_TUNNEL_READY_TIMEOUT_S = 12.0
XRAY_SOCKS_PORT_RANGE = (18080, 18980)
XRAY_PINNED_VERSION = "v26.9.8"
XRAY_GITHUB_API = "https://api.github.com/repos/XTLS/Xray-core/releases/tags/"

# ---- REALITY TCP precheck tuning ----
# The precheck is only meant to weed out targets that are completely
# unreachable before we bother spawning xray-core. A single low-timeout
# attempt is prone to false negatives (one dropped SYN, one slow RTT
# sample) that have nothing to do with whether the real REALITY server
# is reachable - so we always give it a few attempts and a reasonably
# generous floor on the timeout, regardless of what the (possibly very
# tight) general scan timeout is set to.
REALITY_TCP_PRECHECK_ATTEMPTS = 3


def _open_https_url(request, timeout, allowed_hosts):
    """Open a validated HTTPS URL while preventing unexpected local schemes/hosts."""
    url = request.full_url if isinstance(request, urllib.request.Request) else str(request)
    parsed = urllib.parse.urlsplit(url)
    host = (parsed.hostname or "").lower()
    allowed = {item.lower() for item in allowed_hosts}
    if parsed.scheme != "https" or parsed.username or parsed.password or host not in allowed:
        raise ValueError("Refusing an unexpected download URL")
    _check_cancel()
    _timeout_seconds(timeout)
    class SafeRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            dest = urllib.parse.urlsplit(newurl)
            if dest.scheme != "https" or dest.username or dest.password or (dest.hostname or "").lower() not in allowed:
                raise ValueError("Refusing an unexpected redirect")
            return super().redirect_request(req, fp, code, msg, headers, newurl)
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), SafeRedirect())
    return opener.open(request, timeout=timeout)


def _read_bounded(response, maximum, timeout):
    deadline = time.monotonic() + timeout
    chunks, size = [], 0
    while True:
        _check_cancel()
        if time.monotonic() >= deadline:
            raise TimeoutError("Response timeout")
        chunk = response.read(min(65536, maximum + 1 - size))
        if not chunk:
            return b"".join(chunks)
        chunks.append(chunk)
        size += len(chunk)
        if size > maximum:
            raise ValueError("Response exceeds size limit")


REALITY_TCP_PRECHECK_MIN_TIMEOUT_MS = 3000


def parse_ip_input(ip_input, max_per_cidr=CIDR_ASK_THRESHOLD):
    """Parse IPs / CIDR ranges. A range is only ever truncated when it
    exceeds max_per_cidr; smaller ranges are used in full.
    Returns (ip_list, invalid_items, truncated_info)."""
    _input_text(ip_input)
    max_per_cidr = _bounded_int(max_per_cidr, 1, 65536, "CIDR limit")
    all_ips, seen = [], set()
    truncated_info = []
    raw_inputs = re.split(r"[,\s]+", ip_input.strip())
    errors = []
    for item in raw_inputs:
        _check_cancel()
        item = item.strip()
        if not item:
            continue
        try:
            if "/" in item:
                network = ipaddress.ip_network(item, strict=False)
                total = network.num_addresses
                if network.version == 4 and network.prefixlen < 31:
                    total -= 2
                elif network.version == 6 and network.prefixlen < 127:
                    total -= 1
                limit = min(total, max_per_cidr, MAX_CANDIDATES - len(all_ips))
                if total > limit:
                    truncated_info.append((item, total, limit))
                for i, ip in enumerate(network.hosts()):
                    if i >= limit:
                        break
                    address = str(ip)
                    if address not in seen:
                        seen.add(address)
                        all_ips.append(address)
            else:
                if "%" in item:
                    raise ValueError("Scoped IPv6 is unsupported")
                address = str(ipaddress.ip_address(item))
                if address not in seen:
                    if len(all_ips) >= MAX_CANDIDATES:
                        truncated_info.append((item, 1, 0))
                    else:
                        seen.add(address)
                        all_ips.append(address)
        except ValueError:
            errors.append(item)
    return list(dict.fromkeys(all_ips)), errors, truncated_info


_DOMAIN_RE = re.compile(
    r"^(?=.{1,253}$)(?!-)[A-Za-z0-9-]{1,63}(?<!-)"
    r"(\.(?!-)[A-Za-z0-9-]{1,63}(?<!-))+$"
)


def parse_domain_list(text):
    """Parse a list of SNI/domain candidates, one per line/comma/space.
    Strips scheme prefixes and paths if pasted as a URL.
    Returns (domain_list, invalid_items)."""
    _input_text(text)
    domains = []
    errors = []
    raw_inputs = re.split(r"[,\s]+", text.strip())
    for item in raw_inputs:
        item = item.strip()
        if not item:
            continue
        _check_cancel()
        try:
            parsed = urllib.parse.urlsplit(item if "://" in item else "//" + item)
            if parsed.username or parsed.password or parsed.scheme not in ("", "http", "https"):
                raise ValueError("Invalid domain URL")
            if parsed.port is not None:
                _bounded_int(parsed.port, 1, 65535, "Port")
            domain = _validate_host(parsed.hostname or "", domain_only=True)
            if domain not in domains:
                if len(domains) >= MAX_CANDIDATES:
                    raise ValueError("Too many domains")
                domains.append(domain)
        except ValueError:
            errors.append(item)
    return list(dict.fromkeys(domains)), errors


def check_port(ip, port, timeout=3.0):
    _attempt_args(ip, port, 1, int(_timeout_seconds(timeout) * 1000))
    try:
        with _connect_socket(ip, port, timeout):
            return True
    except ScanCancelled:
        raise
    except Exception:
        return False


def parse_target_string(target_text, fallback_port):
    """Parse a 'host' or 'host:port' string (host may be a domain or an IP).
    Returns (host, port, error)."""
    try:
        text = _input_text(target_text).strip()
        port = _bounded_int(fallback_port, 1, 65535, "Port")
        if not text:
            raise ValueError("Target is empty")
        try:
            host = str(ipaddress.ip_address(text))
        except ValueError:
            parsed = urllib.parse.urlsplit(text if "://" in text else "//" + text)
            if parsed.username or parsed.password or parsed.scheme not in ("", "http", "https"):
                raise ValueError("Invalid target URL")
            host = parsed.hostname or ""
            port = parsed.port if parsed.port is not None else port
        host = _validate_host(host)
        _bounded_int(port, 1, 65535, "Port")
        return host, port, None
    except ValueError:
        return None, None, "Invalid target host or port"


def parse_target_list(text, fallback_port):
    """Parse multiple 'host' / 'host:port' entries, one per line (also
    accepts comma/space separated). Returns (targets, errors) where
    targets is a list of (raw_label, host, port) tuples, de-duplicated
    on (host, port), preserving order."""
    _input_text(text)
    targets = []
    errors = []
    seen = set()
    raw_inputs = re.split(r"[,\s]+", text.strip())
    for item in raw_inputs:
        item = item.strip()
        if not item:
            continue
        host, port, err = parse_target_string(item, fallback_port)
        if err:
            errors.append(item)
            continue
        key = (host.lower(), port)
        if key in seen:
            continue
        if len(targets) >= MAX_CANDIDATES:
            errors.append(item)
            continue
        seen.add(key)
        targets.append((item, host, port))
    return targets, errors


def resolve_host(host):
    """Return (ip, error). If host is already an IP, returns it unchanged."""
    _check_cancel()
    try:
        host = _validate_host(host)
        ipaddress.ip_address(host)
        return host, None
    except ValueError:
        pass
    try:
        return _getaddrinfo(host, 443, 5.0)[0][4][0], None
    except ScanCancelled:
        raise
    except Exception as e:
        return None, _safe_error(e)


_TWO_LABEL_TLDS = {
    "co.uk",
    "org.uk",
    "gov.uk",
    "ac.uk",
    "co.jp",
    "co.kr",
    "co.in",
    "co.nz",
    "com.au",
    "com.br",
    "com.cn",
    "com.mx",
    "com.tw",
}


def guess_base_domain(host):
    """Best-effort registrable-domain guess (e.g. apps.apple.com -> apple.com)
    so subdomain discovery covers siblings, not just children of the exact host."""
    parts = host.lower().split(".")
    if len(parts) <= 2:
        return host
    last_two = ".".join(parts[-2:])
    last_three = ".".join(parts[-3:])
    if last_two in _TWO_LABEL_TLDS and len(parts) >= 3:
        return last_three
    return last_two


def find_subdomains_via_crtsh(domain, timeout=15, limit=150):
    """Look up subdomains of `domain` from public certificate-transparency
    logs (crt.sh). Returns (domain_list, error). No API key / auth needed;
    this only reads publicly-logged certificate data.

    `error` is None on success (including the "legitimately no results"
    case, e.g. a 404 from crt.sh for a domain with no logged certs) so
    callers can tell "nothing found" apart from "the lookup itself broke".
    When something did go wrong, `error` is a short classified string:
    "NO_RESULTS: ...", "RATE_LIMIT: ...", "TEMPORARY_ERROR: ...",
    "TIMEOUT: ...", "CONNECTION_ERROR: ...", "PARSE_ERROR: ...".
    """
    domain = _validate_host(domain, domain_only=True)
    _timeout_seconds(timeout)
    limit = _bounded_int(limit, 1, MAX_CANDIDATES, "Discovery limit")
    _check_cancel()
    url = f"https://crt.sh/?q=%25.{urllib.parse.quote(domain, safe='')}&output=json"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with _open_https_url(req, timeout=timeout, allowed_hosts={"crt.sh"}) as resp:
            raw = _read_bounded(resp, 8 * 1024 * 1024, timeout).decode("utf-8", errors="strict")
    except ScanCancelled:
        raise
    except urllib.error.HTTPError as e:
        if e.code == 404:
            # crt.sh returns 404 when it has no certs logged for the query -
            # that's a legitimate "no results", not a broken lookup.
            return [], None
        if e.code == 429:
            return [], "RATE_LIMIT: crt.sh is throttling requests right now"
        if 500 <= e.code < 600:
            return [], f"TEMPORARY_ERROR: crt.sh returned HTTP {e.code}"
        return [], f"HTTP_ERROR: crt.sh returned HTTP {e.code}"
    except (socket.timeout, TimeoutError):
        return [], "TIMEOUT: crt.sh did not respond in time"
    except urllib.error.URLError as e:
        return [], "CONNECTION_ERROR: crt.sh connection failed"
    except Exception as e:
        return [], _safe_error(e)

    try:
        entries = json.loads(raw)
        if not isinstance(entries, list):
            raise ValueError("Expected list")
    except Exception as e:
        return [], "PARSE_ERROR: could not parse crt.sh response"

    counts = {}
    for entry in entries:
        _check_cancel()
        name_value = entry.get("name_value", "") if isinstance(entry, dict) else ""
        if not isinstance(name_value, str):
            continue
        for line in name_value.split("\n"):
            line = line.strip().lower()
            if line.startswith("*."):
                line = line[2:]
            if line and _DOMAIN_RE.fullmatch(line) and (line == domain or line.endswith("." + domain)):
                counts[line] = counts.get(line, 0) + 1

    ranked = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
    return [name for name, _ in ranked][:limit], None


def find_subdomains_for_bases(bases, timeout=15, per_domain_limit=150, total_limit=400):
    """Run find_subdomains_via_crtsh for several base domains concurrently
    and merge the results (de-duplicated, order preserved: best rank per
    source domain first, sources interleaved).

    A failure (or an empty result) on one base domain never stops the
    others - each base is looked up independently and the failures are
    only reported back for display, not raised.

    Returns (merged_list, errors, empty_bases):
      - errors: list of (base_domain, classified_error_message) for bases
        whose lookup actually broke (timeout, rate limit, HTTP/connection
        error, parse error) - NOT bases that simply had zero certs logged.
      - empty_bases: list of base domains that were looked up successfully
        but came back with zero subdomains (e.g. crt.sh 404 / no matches).
    """
    if len(bases) > MAX_CANDIDATES:
        raise ValueError("Too many discovery bases")
    bases = list(dict.fromkeys(_validate_host(base, domain_only=True) for base in bases))
    _timeout_seconds(timeout)
    _bounded_int(per_domain_limit, 1, MAX_CANDIDATES, "Per-domain limit")
    _bounded_int(total_limit, 1, MAX_CANDIDATES, "Total limit")
    _check_cancel()
    per_base = {}
    errors = []
    empty_bases = []
    with ThreadPoolExecutor(max_workers=max(1, min(8, len(bases)))) as executor:
        futures = {
            executor.submit(find_subdomains_via_crtsh, base, timeout, per_domain_limit): base
            for base in bases
        }
        for future in as_completed(futures):
            _check_cancel()
            base = futures[future]
            domains, err = future.result()
            if err:
                errors.append((base, err))
            elif not domains:
                empty_bases.append(base)
            else:
                per_base[base] = domains

    merged = []
    seen = set()
    max_len = max((len(v) for v in per_base.values()), default=0)
    for i in range(max_len):
        for base in bases:
            lst = per_base.get(base, [])
            if i < len(lst):
                name = lst[i]
                if name not in seen:
                    seen.add(name)
                    merged.append(name)
                    if len(merged) >= total_limit:
                        return merged, errors, empty_bases
    return merged, errors, empty_bases


def _ping_stats(times):
    """Given a list of successful round-trip times (ms), compute simple
    stability stats. Returns a dict with min/max/jitter/stddev, all None
    when there isn't enough data. `jitter` here is the mean absolute
    difference between consecutive samples (RFC3550-style), `stddev` is
    the classic population standard deviation - together they say a lot
    more about how usable a connection will be in practice than a single
    average ping does (a stable 60ms beats a bouncy 35-390ms average)."""
    if not times:
        return {"min_ping": None, "max_ping": None, "jitter": None, "stddev": None}
    avg = sum(times) / len(times)
    variance = sum((t - avg) ** 2 for t in times) / len(times)
    stddev = variance**0.5
    if len(times) > 1:
        jitter = sum(abs(times[i] - times[i - 1]) for i in range(1, len(times))) / (len(times) - 1)
    else:
        jitter = 0.0
    return {
        "min_ping": round(min(times), 1),
        "max_ping": round(max(times), 1),
        "jitter": round(jitter, 1),
        "stddev": round(stddev, 1),
    }


def tcp_handshake_ping(ip, port, count, max_timeout):
    _attempt_args(ip, port, count, max_timeout)
    timeout = max_timeout / 1000
    times, success, errors = [], 0, []
    for attempt in range(count):
        _check_cancel()
        start = time.perf_counter()
        try:
            with _connect_socket(ip, port, timeout):
                _check_cancel()
            times.append((time.perf_counter() - start) * 1000)
            success += 1
        except ScanCancelled:
            raise
        except Exception as exc:
            _check_cancel()
            errors.append({"attempt": attempt + 1, "phase": "tcp", "error": _safe_error(exc)})
    loss = round((1 - success / count) * 100, 1) if count else 100.0
    avg = round(sum(times) / len(times), 1) if times else float("inf")
    result = {
        "ip": ip,
        "packet_loss": loss,
        "avg_ping": avg,
        "status": "Online" if success > 0 else "Offline",
        "success": success,
        "count": count,
        "attempt_diagnostics": errors,
        "latencies": times,
    }
    result.update(_ping_stats(times))
    return result


# Load curl_cffi dynamically. This keeps the scanner runnable even when VS Code/Pylance
# is pointed at a different Python environment than the one where curl_cffi is installed.
try:
    import importlib

    _curl_cffi = importlib.import_module("curl_cffi")
    Curl = _curl_cffi.Curl
    CurlOpt = _curl_cffi.CurlOpt
    CurlInfo = _curl_cffi.CurlInfo
    # Low-level Curl.impersonate does not expand aliases such as "chrome".
    _normalize_browser_type = importlib.import_module("curl_cffi.requests.impersonate").normalize_browser_type
    HAVE_CURL_CFFI = True
except Exception:
    Curl = None
    CurlOpt = None
    CurlInfo = None
    _normalize_browser_type = lambda value: value
    HAVE_CURL_CFFI = False

BROWSER_FINGERPRINTS = [
    "chrome",
    "chrome124",
    "chrome131",
    "chrome136",
    "safari",
    "safari_ios",
    "firefox",
]


def _curl_cancel(curl):
    # Returning nonzero aborts libcurl without leaking a callback exception.
    def progress(*_):
        return int(_cancel_event is not None and _cancel_event.is_set())
    try:
        curl.setopt(CurlOpt.NOPROGRESS, 0)
        curl.setopt(CurlOpt.XFERINFOFUNCTION, progress)
        return True
    except (AttributeError, TypeError, NotImplementedError):
        # Older curl_cffi versions do not expose this callback. Transfers still
        # stop in read/write callbacks and each handshake is bounded by TIMEOUT_MS.
        curl.setopt(CurlOpt.NOPROGRESS, 1)
        return False


def tls_handshake_ping(ip, port, sni, count, max_timeout):
    """TLS-handshake `ip:port` using `sni` as the TLS server_hostname.
    Works both for 'many IPs, one SNI' and 'one IP, many SNIs' modes.

    NOTE ON REALITY TARGETS: this sends a plain Python/OpenSSL ClientHello,
    which does NOT mimic a real browser's TLS fingerprint (JA3) the way
    uTLS-based clients (fp=chrome/firefox in Xray etc.) do. A REALITY
    inbound may treat a non-browser-looking hello differently than it
    treats your real client. So a Timeout/Offline result here means
    "a generic TLS client couldn't complete a handshake with this
    SNI/IP/port combo in the time given" - it is a useful reachability
    signal, but it isn't a byte-for-byte replica of your real client, and
    isn't proof the SNI won't work with your actual config.

    IMPORTANT: even a successful handshake here only proves generic TLS
    reachability. It is NOT a REALITY handshake validation - REALITY
    additionally checks the client's X25519 key exchange against the
    server's configured public key/shortId, which a plain TLS test (or
    a browser-fingerprinted one) has no way to reproduce without your
    actual private key material. Treat "Online" as "TLS-reachable",
    not "REALITY-ready".
    """
    _attempt_args(ip, port, count, max_timeout, sni)
    timeout = max_timeout / 1000
    times, success, errors = [], 0, []
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    negotiated_versions = set()
    for attempt in range(count):
        _check_cancel()
        start = time.perf_counter()
        try:
            with _tls_connect(ctx, ip, port, sni, timeout) as tls_sock:
                negotiated_versions.add(tls_sock.version())
            times.append((time.perf_counter() - start) * 1000)
            success += 1
        except ScanCancelled:
            raise
        except Exception as exc:
            _check_cancel()
            errors.append({"attempt": attempt + 1, "phase": "tls", "error": _safe_error(exc)})
    loss = round((1 - success / count) * 100, 1) if count else 100.0
    avg = round(sum(times) / len(times), 1) if times else float("inf")
    result = {
        "ip": ip,
        "packet_loss": loss,
        "avg_ping": avg,
        "status": "Online" if success > 0 else "Offline",
        "success": success,
        "count": count,
        "attempt_diagnostics": errors,
        "tls_version": "/".join(sorted(negotiated_versions)) if negotiated_versions else "-",
        "latencies": times,
    }
    result.update(_ping_stats(times))
    return result


def browser_tls_ping(ip, port, sni, count, max_timeout, impersonate="chrome"):
    """TLS-handshake `ip:port` using `sni` as the SNI/Host, but with a REAL
    browser TLS fingerprint (JA3/JA4 + extension order), via curl_cffi
    (a binding for curl-impersonate, BoringSSL under the hood - not
    Python's OpenSSL). This is the same class of ClientHello that
    Xray/V2Ray sends when your REALITY client config uses
    fingerprint (fp) = chrome / safari / firefox / etc.

    CURLOPT_RESOLVE pins `sni:port` to `ip` so curl connects to the exact
    IP you're testing while still sending `sni` as both the Host header
    and the TLS SNI - exactly how a REALITY client reaches a specific
    destination IP while pretending to be that domain.

    CURLOPT_CONNECT_ONLY stops curl right after the TCP+TLS handshake
    completes - no HTTP request/response is sent, so this measures the
    handshake only, same as the plain-TLS version above.

    IMPORTANT: same caveat as tls_handshake_ping - a successful handshake
    here proves the SNI/IP/port combo is TLS-reachable with a realistic
    browser fingerprint, but it still isn't a REALITY protocol validation
    (no X25519/public-key/shortId check happens). Use it to rule targets
    IN or OUT for further testing in your real client, not as a final
    verdict on whether a REALITY config will work end-to-end.
    """
    _attempt_args(ip, port, count, max_timeout, sni)
    if impersonate not in BROWSER_FINGERPRINTS:
        raise ValueError("Unsupported browser fingerprint")
    if not HAVE_CURL_CFFI:
        raise RuntimeError(
            "curl_cffi is not installed. Run: pip install curl_cffi --break-system-packages "
            "(or just: pip install curl_cffi)"
        )

    times, success, errors = [], 0, []
    effective_fingerprint = _normalize_browser_type(impersonate)
    url = f"https://{sni}:{port}/".encode()
    address = f"[{ip}]" if ":" in ip else ip
    resolve_entry = f"{sni}:{port}:{address}".encode()

    for attempt in range(count):
        _check_cancel()
        c = Curl()
        try:
            c.setopt(CurlOpt.URL, url)
            c.setopt(CurlOpt.RESOLVE, [resolve_entry])
            c.setopt(CurlOpt.PROXY, b"")
            _curl_cancel(c)
            c.setopt(CurlOpt.CONNECT_ONLY, 1)
            c.setopt(CurlOpt.CONNECTTIMEOUT_MS, int(max_timeout))
            c.setopt(CurlOpt.TIMEOUT_MS, int(max_timeout))
            c.setopt(CurlOpt.SSL_VERIFYPEER, 0)
            c.setopt(CurlOpt.SSL_VERIFYHOST, 0)
            if c.impersonate(effective_fingerprint) != 0:
                errors.append({"attempt": attempt + 1, "phase": "browser_tls", "error": "FINGERPRINT_ERROR: selected browser fingerprint is unavailable"})
                continue

            start = time.perf_counter()
            c.perform()
            _check_cancel()
            elapsed_ms = (time.perf_counter() - start) * 1000
            times.append(elapsed_ms)
            success += 1
        except ScanCancelled:
            raise
        except Exception as exc:
            _check_cancel()
            errors.append({"attempt": attempt + 1, "phase": "browser_tls", "error": _safe_error(exc)})
        finally:
            c.close()

    loss = round((1 - success / count) * 100, 1) if count else 100.0
    avg = round(sum(times) / len(times), 1) if times else float("inf")
    result = {
        "ip": ip,
        "packet_loss": loss,
        "avg_ping": avg,
        "status": "Online" if success > 0 else "Offline",
        "success": success,
        "count": count,
        "fingerprint": impersonate,
        "fingerprint_effective": effective_fingerprint,
        "attempt_diagnostics": errors,
        "latencies": times,
    }
    result.update(_ping_stats(times))
    return result


def alpn_probe(ip, port, sni, timeout_s=3.0):
    """Single best-effort ALPN probe using a plain OpenSSL ClientHello
    (NOT browser-fingerprinted). This is purely informational - some
    REALITY/anti-censorship setups react differently to a generic hello
    than to a real browser one, so a mismatch here doesn't necessarily
    mean anything is wrong. Returns the negotiated ALPN protocol string
    (e.g. "h2", "http/1.1") or None if the handshake failed or no ALPN
    was negotiated."""
    _attempt_args(ip, port, 1, int(_timeout_seconds(timeout_s) * 1000), sni)
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        try:
            ctx.set_alpn_protocols(["h2", "http/1.1"])
        except NotImplementedError:
            return None
        with _tls_connect(ctx, ip, port, sni, timeout_s) as tls_sock:
            return tls_sock.selected_alpn_protocol()
    except ScanCancelled:
        raise
    except Exception:
        return None


def sni_target_test(connect_host, port, sni, count, max_timeout, impersonate="chrome"):
    """The real per-(target, SNI) test used by SNI/REALITY mode. Unlike a
    single browser_tls_ping call, this reports TCP reachability and
    TLS+SNI reachability SEPARATELY, since they can legitimately disagree
    (e.g. DPI/firewalls that let a real-looking TLS ClientHello through
    but drop/reset a bare TCP probe, or vice versa) - collapsing them into
    one Online/Offline value hides exactly the kind of mismatch you were
    asking about (a config that reaches your server on 8007 with a real
    REALITY handshake, while a bare socket.connect() to 8007 times out).

    Returns a dict with the TLS result's usual keys (ip, packet_loss,
    avg_ping, status, jitter, ...) as the PRIMARY result - used for
    sorting/ranking, unchanged from before - plus:
      tcp_status / tcp_packet_loss / tcp_avg_ping : raw TCP-only reachability
      alpn        : best-effort ALPN from a single generic-client probe (may be None)
      verdict     : a short human label combining TCP + TLS results

    Still NOT a REALITY handshake validation (see browser_tls_ping) - the
    verdict tells you whether the SNI/IP/port combo is worth trying in
    your real client, not that REALITY itself will succeed.
    """
    tcp_res = tcp_handshake_ping(connect_host, port, count, max_timeout)
    tls_res = browser_tls_ping(connect_host, port, sni, count, max_timeout, impersonate)
    alpn = alpn_probe(connect_host, port, sni, timeout_s=max_timeout / 1000)

    tcp_online = tcp_res["status"] == "Online"
    tls_online = tls_res["status"] == "Online"
    if tls_online and tcp_online:
        verdict = "GOOD TARGET"
    elif tls_online and not tcp_online:
        verdict = "VALID TLS TARGET"  # TLS+SNI works even though a bare TCP probe didn't
    elif not tls_online and tcp_online:
        verdict = "TCP OK / TLS FAILED"
    else:
        verdict = "OFFLINE"

    result = dict(tls_res)  # TLS stats stay primary (status/avg_ping/jitter/etc.)
    result["tcp_status"] = tcp_res["status"]
    result["tcp_packet_loss"] = tcp_res["packet_loss"]
    result["tcp_avg_ping"] = tcp_res["avg_ping"]
    result["alpn"] = alpn or "-"
    result["verdict"] = verdict
    return result


def modify_config_link(config_link, target_ip):
    _input_text(config_link)
    target_ip = str(ipaddress.ip_address(target_ip))
    authority_ip = f"[{target_ip}]" if ":" in target_ip else target_ip
    try:
        if config_link.startswith(("vless://", "trojan://")):
            parsed = urllib.parse.urlparse(config_link)
            user_info = parsed.netloc.rsplit("@", 1)[0]
            port = _bounded_int(parsed.port, 1, 65535, "Port")
            if not parsed.hostname or "@" not in parsed.netloc:
                return None
            new_netloc = f"{user_info}@{authority_ip}:{port}"
            fragment = parsed.fragment
            new_fragment = f"Clean-{target_ip}" if not fragment else f"{fragment}-Clean-{target_ip}"
            new_uri = parsed._replace(netloc=new_netloc, fragment=new_fragment)
            return urllib.parse.urlunparse(new_uri)

        elif config_link.startswith("vmess://"):
            raw_b64 = config_link.replace("vmess://", "").strip()
            raw_b64 += "=" * ((4 - len(raw_b64) % 4) % 4)
            data = json.loads(base64.b64decode(raw_b64).decode("utf-8"))
            data["add"] = target_ip
            data["ps"] = f"{data.get('ps', 'VMess')}-Clean-{target_ip}"
            new_b64 = base64.b64encode(json.dumps(data).encode("utf-8")).decode("utf-8")
            return f"vmess://{new_b64}"

        elif config_link.startswith("ss://"):
            parsed = urllib.parse.urlparse(config_link)
            netloc = parsed.netloc
            if "@" in netloc:
                userinfo, hostport = netloc.split("@", 1)
                port = _bounded_int(parsed.port, 1, 65535, "Port")
                new_netloc = f"{userinfo}@{authority_ip}:{port}"
                fragment = parsed.fragment
                new_fragment = (
                    f"Clean-{target_ip}" if not fragment else f"{fragment}-Clean-{target_ip}"
                )
                new_uri = parsed._replace(netloc=new_netloc, fragment=new_fragment)
                return urllib.parse.urlunparse(new_uri)
    except Exception:
        pass
    return None


# ============================================================
#  Speed test backend (Low Accuracy / High Accuracy)
# ============================================================


def _xray_executable_name():
    return "xray.exe" if os.name == "nt" else "xray"


def _xray_cache_dir():
    """Return a per-user cache directory that is writable after installation."""
    if os.name != "nt":
        import pwd
        if os.geteuid() == 0:
            return Path("/var/lib/ununknowntun/scanner/xray")
        home = Path(pwd.getpwuid(os.geteuid()).pw_dir)
        return home / ".cache" / "ununknowntun-scanner" / "xray-core"
    return Path.home() / "AppData" / "Local" / "UNUNKNOWNTUN" / "Cache" / "xray-core"


def validate_xray_binary(path):
    """Validate an explicitly selected binary; root never trusts PATH or env vars."""
    if not isinstance(path, (str, Path)) or not Path(path).is_absolute():
        raise ValueError("Xray requires an explicit absolute executable path")
    candidate = Path(path).resolve(strict=True)
    metadata = candidate.stat()
    if not stat.S_ISREG(metadata.st_mode) or not os.access(candidate, os.X_OK):
        raise PermissionError("Xray path must be an executable regular file")
    if os.name != "nt" and os.geteuid() == 0:
        for item in (candidate, *candidate.parents):
            info = item.stat()
            if info.st_uid != 0 or info.st_mode & (stat.S_IWGRP | stat.S_IWOTH):
                raise PermissionError("Root requires a root-owned Xray path with no group/world-writable ancestors")
    return str(candidate)


def set_xray_binary(path):
    """Explicitly select a trusted binary; passing None clears the selection."""
    global _explicit_xray_path
    _explicit_xray_path = validate_xray_binary(path) if path is not None else None
    return _explicit_xray_path


def find_xray_binary():
    """Return only the binary selected explicitly with set_xray_binary()."""
    return validate_xray_binary(_explicit_xray_path) if _explicit_xray_path else None


def _xray_asset_name():
    system, machine = platform.system().lower(), platform.machine().lower()
    if system == "windows":
        return "Xray-windows-64.zip" if machine in ("amd64", "x86_64") else "Xray-windows-32.zip"
    if system == "darwin":
        return (
            "Xray-macos-arm64-v8a.zip" if machine in ("arm64", "aarch64") else "Xray-macos-64.zip"
        )
    if system == "linux":
        if machine in ("arm64", "aarch64"):
            return "Xray-linux-arm64-v8a.zip"
        if machine in ("386", "i386", "i686"):
            return "Xray-linux-32.zip"
        return "Xray-linux-64.zip"
    raise RuntimeError(f"Unsupported platform: {platform.system()} / {platform.machine()}")


def _run_xray_version(path):
    process = None
    try:
        path = validate_xray_binary(path)
        _check_cancel()
        process = subprocess.Popen(
            [path, "version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            env=_xray_environment(),
            creationflags=(0x08000000 if os.name == "nt" else 0),
        )
        deadline = time.monotonic() + 8
        while process.poll() is None:
            _check_cancel()
            if time.monotonic() >= deadline:
                return False, "Xray version check timed out"
            time.sleep(0.05)
        return process.returncode == 0, "Xray version check passed" if process.returncode == 0 else "Xray version check failed"
    except ScanCancelled:
        raise
    except Exception as e:
        return False, "Xray executable check failed"
    finally:
        stop_xray_process(process, None)


def _xray_environment():
    env = {"PATH": "/usr/bin:/bin", "LANG": "C", "LC_ALL": "C"}
    if os.name == "nt" and os.environ.get("SystemRoot"):
        env["SystemRoot"] = os.environ["SystemRoot"]
    return env


def _sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as file_handle:
        for chunk in iter(lambda: file_handle.read(1024 * 1024), b""):
            _check_cancel()
            digest.update(chunk)
    return digest.hexdigest()


def ensure_xray_binary(force_download=False, allow_download=False):
    """Return a working Xray path, verifying GitHub's SHA-256 on downloads.

    Downloads are pinned to ``XRAY_PINNED_VERSION`` and are rejected if the
    GitHub release API does not provide a SHA-256 digest. Server callers should
    pass ``allow_download=False`` unless the user explicitly opted in.
    """
    _check_cancel()
    if not isinstance(force_download, bool) or not isinstance(allow_download, bool):
        raise ValueError("Download consent must be a boolean")
    found = find_xray_binary()
    if found and not force_download:
        ok, detail = _run_xray_version(found)
        if ok:
            return found, detail

    cache = _xray_cache_dir()
    exe = cache / _xray_executable_name()

    if not allow_download:
        raise FileNotFoundError(
            "No working explicitly selected Xray executable. "
            "Select an installed binary or explicitly allow the pinned download."
        )

    cache.mkdir(parents=True, exist_ok=True, mode=0o700)
    if os.name != "nt":
        for item in (cache, *cache.parents):
            info = item.stat()
            if info.st_uid != os.geteuid() and info.st_uid != 0 or info.st_mode & 0o022:
                raise PermissionError("Unsafe Xray download cache permissions")

    asset_name = _xray_asset_name()
    api = XRAY_GITHUB_API + XRAY_PINNED_VERSION
    staging = tempfile.TemporaryDirectory(prefix="download-", dir=cache)
    archive = Path(staging.name) / asset_name
    staged_exe = Path(staging.name) / _xray_executable_name()
    try:
        req = urllib.request.Request(
            api,
            headers={"Accept": "application/vnd.github+json", "User-Agent": "SIKDPI-SNI-Scanner"},
        )
        with _open_https_url(req, timeout=20, allowed_hosts={"api.github.com"}) as r:
            release = json.loads(_read_bounded(r, 2 * 1024 * 1024, 20).decode("utf-8"))
        asset = next((x for x in release.get("assets", []) if x.get("name") == asset_name), None)
        if not asset:
            raise RuntimeError(f"Asset {asset_name} not found in {XRAY_PINNED_VERSION}")

        declared_digest = asset.get("digest") or ""
        if not declared_digest.startswith("sha256:"):
            raise RuntimeError(
                "GitHub did not provide a SHA-256 digest for this release asset; "
                "refusing to execute an unverified download"
            )
        expected_sha256 = declared_digest.split(":", 1)[1].lower()
        if not re.fullmatch(r"[0-9a-f]{64}", expected_sha256):
            raise RuntimeError("GitHub returned an invalid SHA-256 digest")

        req = urllib.request.Request(
            asset["browser_download_url"], headers={"User-Agent": "SIKDPI-SNI-Scanner"}
        )
        with (
            _open_https_url(req, timeout=90, allowed_hosts={"github.com", "release-assets.githubusercontent.com", "objects.githubusercontent.com"}) as r,
            open(archive, "wb") as f,
        ):
            f.write(_read_bounded(r, 128 * 1024 * 1024, 90))

        actual_sha256 = _sha256_file(archive)
        if actual_sha256 != expected_sha256:
            raise RuntimeError(
                f"Xray archive SHA-256 mismatch (expected {expected_sha256}, "
                f"received {actual_sha256})"
            )

        with zipfile.ZipFile(archive, "r") as z:
            member = next(
                (m for m in z.namelist() if Path(m).name.lower() in ("xray", "xray.exe")), None
            )
            if not member:
                raise RuntimeError("Downloaded archive contains no xray executable")
            if z.getinfo(member).file_size > 256 * 1024 * 1024:
                raise RuntimeError("Xray executable exceeds size limit")
            with z.open(member) as srcf, open(staged_exe, "wb") as dstf:
                shutil.copyfileobj(srcf, dstf)
        if os.name != "nt":
            staged_exe.chmod(staged_exe.stat().st_mode | 0o111)

        ok, detail = _run_xray_version(str(staged_exe))
        if not ok:
            raise RuntimeError(f"Downloaded Xray self-test failed: {detail}")
        os.replace(staged_exe, exe)
        set_xray_binary(str(exe))
        return str(exe), detail
    except ScanCancelled:
        raise
    except Exception as e:
        raise RuntimeError(
            f"Automatic Xray setup failed ({XRAY_PINNED_VERSION}/{asset_name}); download was not installed"
        ) from e
    finally:
        staging.cleanup()
        for temporary_path in (archive, staged_exe):
            try:
                temporary_path.unlink()
            except FileNotFoundError:
                pass


def _find_free_local_port(port_range=XRAY_SOCKS_PORT_RANGE):
    """Find a free TCP port on 127.0.0.1 within port_range. Falls back
    to letting the OS pick an ephemeral port if the whole range is busy."""
    lo, hi = port_range
    _bounded_int(lo, 1, 65535, "Port range start")
    _bounded_int(hi, lo + 1, 65536, "Port range end")
    for port in range(lo, hi):
        _check_cancel()
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind((XRAY_LOCAL_HOST, port))
                return port
            except OSError:
                continue
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind((XRAY_LOCAL_HOST, 0))
        return s.getsockname()[1]


def parse_reality_link(config_link):
    """Parse a vless:// or trojan:// link that uses REALITY (security=reality)
    into the fields needed to build an xray client outbound.

    Returns a dict with: protocol ('vless' or 'trojan'), uuid (vless only) /
    password (trojan only), address, port, flow, fingerprint, public_key,
    short_id, spider_x, network, sni, error.
    `error` is None on success, or a short human-readable message
    ("Not a vless:///trojan:// link", "Missing REALITY publicKey", ...) on
    failure.
    """
    out = {"error": None}
    try:
        _input_text(config_link)
        if config_link.startswith("vless://"):
            protocol = "vless"
        elif config_link.startswith("trojan://"):
            protocol = "trojan"
        else:
            return {"error": "This is not a vless:// or trojan:// link."}

        parsed = urllib.parse.urlparse(config_link)
        if "@" not in parsed.netloc:
            return {"error": "Link is missing the credentials@host part."}
        userinfo, hostport = parsed.netloc.rsplit("@", 1)
        if parsed.port is None:
            return {"error": "Link is missing a port."}
        out["protocol"] = protocol
        out["address"] = _validate_host(parsed.hostname or "")
        out["port"] = _bounded_int(parsed.port, 1, 65535, "Port")
        if protocol == "vless":
            out["uuid"] = str(uuid.UUID(urllib.parse.unquote(userinfo)))
        else:  # trojan
            out["password"] = urllib.parse.unquote(userinfo)
            if not out["password"] or len(out["password"]) > 256 or any(ord(c) < 32 for c in out["password"]):
                raise ValueError("Invalid password")

        q = urllib.parse.parse_qs(parsed.query, keep_blank_values=True, max_num_fields=64)
        if any(len(values) != 1 for values in q.values()):
            raise ValueError("Ambiguous duplicate parameters")

        def first(key, default=""):
            v = q.get(key)
            return v[0] if v else default

        security = first("security", "").lower()
        if security != "reality":
            return {
                "error": "High Accuracy speed test only supports security=reality configs."
            }

        pbk = first("pbk")
        if not pbk:
            return {"error": "Link is missing the REALITY Public Key (pbk=...)."}
        if not re.fullmatch(r"[A-Za-z0-9_-]{43}", pbk) or len(base64.urlsafe_b64decode(pbk + "=")) != 32:
            return {"error": "Invalid REALITY Public Key"}

        out["network"] = first("type", "tcp")
        out["flow"] = first("flow", "") if protocol == "vless" else ""
        out["fingerprint"] = first("fp", "chrome")
        out["public_key"] = pbk
        out["short_id"] = first("sid", "")
        out["spider_x"] = first("spx", "")
        out["sni"] = first("sni", "")
        if out["sni"]:
            out["sni"] = _validate_host(out["sni"], domain_only=True)
        if not re.fullmatch(r"(?:[0-9a-fA-F]{2}){0,8}", out["short_id"]):
            return {"error": "Invalid REALITY short ID"}
        if out["network"] not in REALITY_SUPPORTED_TRANSPORTS:
            return {"error": "Unsupported REALITY transport: this scanner supports tcp/raw only"}
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", out["fingerprint"]):
            return {"error": "Invalid fingerprint"}
        if out["flow"] not in {"", "xtls-rprx-vision", "xtls-rprx-vision-udp443"}:
            return {"error": "Unsupported VLESS flow"}
        if len(out["spider_x"]) > 2048 or any(ord(c) < 32 for c in out["spider_x"]):
            return {"error": "Invalid spider path"}
        out["error"] = None
        return out
    except Exception:
        return {"error": "Could not parse link: invalid address, credentials, port, or parameters"}


# Backward-compatible alias (old name used elsewhere / by any external callers)
parse_vless_reality_link = parse_reality_link


def build_xray_client_config(vless_params, target_ip, target_port, sni, local_socks_port):
    """Build a minimal xray-core JSON config: one SOCKS inbound on
    127.0.0.1:local_socks_port, and one VLESS or Trojan (+REALITY) outbound
    pointed at target_ip:target_port using `sni` as the REALITY serverName
    (so we can test several SNI candidates against the same server)."""
    _attempt_args(target_ip, target_port, 1, 1000, sni)
    _bounded_int(local_socks_port, 1, 65535, "SOCKS port")
    if vless_params.get("error"):
        raise ValueError("Invalid REALITY parameters")
    protocol = vless_params.get("protocol", "vless")
    if protocol not in {"vless", "trojan"}:
        raise ValueError("Unsupported REALITY protocol")
    network = vless_params.get("network", "tcp")
    if network not in REALITY_SUPPORTED_TRANSPORTS:
        raise ValueError("Unsupported REALITY transport: this scanner supports tcp/raw only")

    if protocol == "trojan":
        outbound_settings = {
            "servers": [
                {"address": target_ip, "port": target_port, "password": vless_params["password"]}
            ]
        }
    else:
        outbound_settings = {
            "vnext": [
                {
                    "address": target_ip,
                    "port": target_port,
                    "users": [
                        {
                            "id": vless_params["uuid"],
                            "encryption": "none",
                            "flow": vless_params.get("flow", ""),
                        }
                    ],
                }
            ]
        }

    return {
        "log": {"loglevel": "warning"},
        "inbounds": [
            {
                "listen": XRAY_LOCAL_HOST,
                "port": local_socks_port,
                "protocol": "socks",
                "settings": {"udp": False, "auth": "noauth"},
                "sniffing": {"enabled": False},
            }
        ],
        "outbounds": [
            {
                "protocol": protocol,
                "settings": outbound_settings,
                "streamSettings": {
                    "network": network,
                    "security": "reality",
                    "realitySettings": {
                        "serverName": sni,
                        "fingerprint": vless_params.get("fingerprint", "chrome"),
                        "publicKey": vless_params["public_key"],
                        "shortId": vless_params.get("short_id", ""),
                        "spiderX": vless_params.get("spider_x", ""),
                    },
                },
            }
        ],
    }


def run_xray_process(xray_path, config_dict, ready_timeout=XRAY_TUNNEL_READY_TIMEOUT_S):
    """Start one private SOCKS client; failed startup always removes its secrets.

    The lifetime lock remains held until stop_xray_process(), preventing workers
    from racing to reuse ports. Output goes to DEVNULL: pipes can block a noisy
    child, and Xray diagnostics can contain credentials from its configuration.
    """
    config_path = None
    process = None
    locked = ready = False
    try:
        _timeout_seconds(ready_timeout)
        _check_cancel()
        xray_path = validate_xray_binary(xray_path)
        while not _xray_lock.acquire(timeout=0.1):
            _check_cancel()
        locked = True
        inbound = config_dict["inbounds"][0]
        port = _bounded_int(inbound["port"], 1, 65535, "SOCKS port")
        if inbound.get("listen") != XRAY_LOCAL_HOST or inbound.get("protocol") != "socks":
            raise ValueError("Xray inbound must be loopback SOCKS")
        # Refuse an existing listener instead of mistaking it for our child.
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as reservation:
            reservation.bind((XRAY_LOCAL_HOST, port))
        fd, config_path = tempfile.mkstemp(prefix="ununknowntun_scanner_xray_", suffix=".json")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            if os.name != "nt":
                os.fchmod(f.fileno(), 0o600)
            json.dump(config_dict, f)
        flags = 0x08000000 if os.name == "nt" else 0
        process = subprocess.Popen(
            [xray_path, "run", "-c", config_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env=_xray_environment(),
            creationflags=flags,
        )
        deadline = time.monotonic() + ready_timeout
        while time.monotonic() < deadline:
            _check_cancel()
            rc = process.poll()
            if rc is not None:
                return None, None, False, f"XRAY_START_ERROR: Xray exited before SOCKS readiness (exit code {rc})"
            if _socks_ready(port, min(0.2, max(0.001, deadline - time.monotonic()))):
                if process.poll() is not None:
                    return None, None, False, "XRAY_START_ERROR: Xray exited during readiness check"
                process._scanner_lock_held = True
                ready = True
                return process, config_path, True, None
            time.sleep(min(0.05, max(0, deadline - time.monotonic())))
        return None, None, False, "XRAY_START_TIMEOUT: local SOCKS startup timed out"
    except ScanCancelled:
        raise
    except (FileNotFoundError, PermissionError):
        return None, None, False, "XRAY_BINARY_ERROR: missing or untrusted executable"
    except Exception:
        return None, None, False, "XRAY_LAUNCH_ERROR: invalid configuration or local startup failure"
    finally:
        if not ready:
            stop_xray_process(process, config_path)
            if locked:
                _xray_lock.release()


def _socks_ready(port, timeout):
    try:
        with _connect_socket(XRAY_LOCAL_HOST, port, timeout) as sock:
            sock.settimeout(timeout)
            sock.sendall(b"\x05\x01\x00")
            response = b""
            while len(response) < 2:
                chunk = sock.recv(2 - len(response))
                if not chunk:
                    return False
                response += chunk
            return response == b"\x05\x00"
    except ScanCancelled:
        raise
    except OSError:
        return False


def stop_xray_process(process, config_path):
    """Terminate the xray process (if still running) and always delete
    the temp config file, since it contains REALITY connection secrets."""
    try:
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=3)
            except Exception:
                process.kill()
                process.wait(timeout=3)
    except Exception:
        pass
    if config_path:
        try:
            os.remove(config_path)
        except Exception:
            pass
    if process is not None and getattr(process, "_scanner_lock_held", False):
        process._scanner_lock_held = False
        _xray_lock.release()


def high_accuracy_speed_test(
    xray_path, vless_params, target_ip, target_port, sni, download_mb, upload_mb, timeout_ms=15000
):
    with _serialized_xray():
        return _high_accuracy_speed_test(xray_path, vless_params, target_ip, target_port, sni, download_mb, upload_mb, timeout_ms)


def _high_accuracy_speed_test(
    xray_path, vless_params, target_ip, target_port, sni, download_mb, upload_mb, timeout_ms=15000
):
    """High Accuracy speed test: spins up a REAL xray-core VLESS/Trojan
    +REALITY client tunnel to target_ip:target_port using `sni` as
    serverName, then measures real download/upload throughput of
    speed.cloudflare.com THROUGH that tunnel's local SOCKS proxy.

    This only produces a meaningful result if target_ip:target_port is
    actually your own REALITY server (matching the publicKey/shortId in
    vless_params) - against any other server the REALITY handshake will
    simply fail (which is reported as an error, not a crash).
    """
    _attempt_args(target_ip, target_port, 1, timeout_ms, sni)
    for value in (download_mb, upload_mb):
        if isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value) or not 0 <= value <= MAX_TRANSFER_BYTES / 1024 / 1024 or (value > 0 and int(value * 1024 * 1024) < 1):
            raise ValueError("Transfer size must be between zero and 256 MiB")
    if download_mb == 0 and upload_mb == 0:
        raise ValueError("Enable at least one transfer direction")
    if not HAVE_CURL_CFFI:
        raise RuntimeError("curl_cffi is required for a tunnel speed test")
    result = {
        "ip": sni,
        "download_mbps": 0.0,
        "upload_mbps": 0.0,
        "download_ok": False,
        "upload_ok": False,
        "download_bytes": 0,
        "upload_bytes": 0,
        "download_http_status": None,
        "upload_http_status": None,
        "error": None,
    }

    if not xray_path or not os.path.isfile(xray_path):
        result["error"] = "XRAY_BINARY_ERROR: executable not found"
        return result

    local_port = _find_free_local_port()
    config = build_xray_client_config(vless_params, target_ip, target_port, sni, local_port)
    process, config_path, ok, err = run_xray_process(xray_path, config, ready_timeout=min(timeout_ms / 1000, XRAY_TUNNEL_READY_TIMEOUT_S))
    if not ok:
        result["error"] = err
        return result

    try:
        proxy_url = f"socks5h://{XRAY_LOCAL_HOST}:{local_port}"
        for direction, amount in (("download", download_mb), ("upload", upload_mb)):
            _check_cancel()
            if amount == 0:
                continue
            try:
                expected = int(amount * 1024 * 1024)
                actual, status, elapsed = _speed_transfer(proxy_url, direction, expected, timeout_ms)
                result[direction + "_http_status"] = status
                result[direction + "_bytes"] = actual
                if 200 <= status < 300 and actual == expected and elapsed > 0:
                    result[direction + "_mbps"] = round((actual * 8 / 1_000_000) / elapsed, 2)
                    result[direction + "_ok"] = True
                else:
                    previous = result["error"]
                    result["error"] = (previous + "; " if previous else "") + direction + " failed: HTTP status or byte count mismatch"
            except ScanCancelled:
                raise
            except Exception as exc:
                _check_cancel()
                previous = result["error"]
                result["error"] = (previous + "; " if previous else "") + direction + " failed: " + _safe_error(exc)
    finally:
        stop_xray_process(process, config_path)

    return result


def _speed_transfer(proxy_url, direction, expected, timeout_ms):
    counted, supplied = {"n": 0}, {"n": 0}
    payload = os.urandom(min(expected, 1024 * 1024)) if direction == "upload" else b""
    def on_write(chunk):
        if _cancel_event is not None and _cancel_event.is_set():
            return CURL_WRITEFUNC_ERROR
        # Cap unexpected response bodies as well as the measured download.
        maximum = expected if direction == "download" else 1024 * 1024
        if counted["n"] + len(chunk) > maximum:
            return CURL_WRITEFUNC_ERROR
        counted["n"] += len(chunk)
        return len(chunk)
    def on_read(size):
        if _cancel_event is not None and _cancel_event.is_set():
            return b""
        chunk = payload[: min(size, expected - supplied["n"], len(payload))]
        supplied["n"] += len(chunk)
        return chunk
    path = SPEEDTEST_DOWNLOAD_PATH.format(bytes=expected) if direction == "download" else SPEEDTEST_UPLOAD_PATH
    curl = Curl()
    try:
        curl.setopt(CurlOpt.URL, f"https://{SPEEDTEST_DEFAULT_HOST}{path}".encode())
        curl.setopt(CurlOpt.PROXY, proxy_url.encode())
        # An inherited NO_PROXY entry must never bypass the tunnel under test.
        curl.setopt(CurlOpt.NOPROXY, b"")
        curl.setopt(CurlOpt.CONNECTTIMEOUT_MS, int(timeout_ms))
        curl.setopt(CurlOpt.TIMEOUT_MS, int(timeout_ms))
        curl.setopt(CurlOpt.WRITEFUNCTION, on_write)
        if direction == "upload":
            curl.setopt(CurlOpt.UPLOAD, 1)
            curl.setopt(CurlOpt.CUSTOMREQUEST, b"POST")
            curl.setopt(CurlOpt.INFILESIZE, expected)
            try:
                curl.setopt(CurlOpt.READFUNCTION, on_read)
            except (AttributeError, TypeError, NotImplementedError):
                # Released older bindings lack READFUNCTION. Retain their upload
                # support with a strictly capped POST body, never a 256 MiB copy.
                if expected > MAX_BUFFERED_UPLOAD_BYTES:
                    raise CurlCapabilityError() from None
                curl.setopt(CurlOpt.UPLOAD, 0)
                curl.setopt(CurlOpt.POSTFIELDSIZE, expected)
                curl.setopt(CurlOpt.POSTFIELDS, os.urandom(expected))
        _curl_cancel(curl)
        started = time.perf_counter()
        curl.perform()
        _check_cancel()
        elapsed = time.perf_counter() - started
        actual = counted["n"] if direction == "download" else int(curl.getinfo(CurlInfo.SIZE_UPLOAD_T))
        return actual, int(curl.getinfo(CurlInfo.RESPONSE_CODE)), elapsed
    finally:
        curl.close()


# ============================================================
#  REAL REALITY handshake validator (used by SNI/REALITY scan mode)
#
#  Rationale (see the accompanying design notes): neither a bare TCP
#  connect() nor a generic/browser-fingerprinted TLS handshake proves
#  anything about whether a REALITY server will actually accept a given
#  SNI - REALITY's accept/reject decision happens server-side, verified
#  from the X25519 key share embedded in the real client's ClientHello.
#  On rejection the server transparently relays the connection to the
#  disguised (fallback) website, so the TLS handshake itself completes
#  either way. The only way to tell the two apart from the client side
#  is to actually speak the client's real proxy protocol (VLESS/Trojan)
#  over the tunnel and see whether something that understands it is on
#  the other end - a real REALITY session will parse it and proxy
#  traffic; a rejected/fallback session hands the bytes to a normal
#  website, which won't and will simply error out/reset/hang.
# ============================================================

REALITY_PROBE_URL = "https://cp.cloudflare.com/generate_204"
REALITY_VERDICT_RANK = {
    "VALID": 0,
    "FLAKY": 1,
    "PROBE_TIMEOUT": 2,
    "TIMEOUT": 3,
    "NETWORK_ERROR": 4,
    "INVALID": 5,
}


def reality_probe_through_tunnel(local_socks_port, timeout_ms=6000):
    """Send one lightweight HTTP request THROUGH an already-up xray SOCKS
    tunnel to confirm the REALITY handshake was actually accepted on the
    server side (see module-level note above for why this is necessary -
    "TLS completed" is not the same as "REALITY accepted").

    Returns (ok, error). Success requires the expected HTTPS 204 response
    through the configured proxy. Timeouts/resets are inconclusive network
    failures; a TCP precheck cannot distinguish them from auth rejection.
    """
    _bounded_int(local_socks_port, 1, 65535, "SOCKS port")
    _bounded_int(timeout_ms, 1, MAX_TIMEOUT_MS, "Probe timeout")
    _check_cancel()
    if not HAVE_CURL_CFFI:
        return False, "curl_cffi not installed"
    proxy_url = f"socks5h://{XRAY_LOCAL_HOST}:{local_socks_port}"
    c = Curl()
    try:
        c.setopt(CurlOpt.URL, REALITY_PROBE_URL.encode())
        c.setopt(CurlOpt.PROXY, proxy_url.encode())
        # Force this authenticated probe through SOCKS even with NO_PROXY=*.
        c.setopt(CurlOpt.NOPROXY, b"")
        c.setopt(CurlOpt.CONNECTTIMEOUT_MS, int(timeout_ms))
        c.setopt(CurlOpt.TIMEOUT_MS, int(timeout_ms))
        c.setopt(CurlOpt.SSL_VERIFYPEER, 1)
        c.setopt(CurlOpt.SSL_VERIFYHOST, 2)
        c.setopt(CurlOpt.WRITEFUNCTION, lambda chunk: len(chunk))
        _curl_cancel(c)
        c.perform()
        _check_cancel()
        status = None
        try:
            status = c.getinfo(CurlInfo.RESPONSE_CODE)
        except Exception:
            pass
        if status is not None and int(status) == 204:
            return True, None
        return False, "UNEXPECTED_RESPONSE: expected HTTP 204 through the tunnel"
    except ScanCancelled:
        raise
    except Exception as e:
        _check_cancel()
        return False, _safe_error(e)
    finally:
        c.close()


def _classify_probe_error(error_text):
    text = (error_text or "").lower()
    if any(x in text for x in ("timed out", "timeout", "operation timed out", "curl error 28")):
        return "PROBE_TIMEOUT"
    if "unexpected_response" in text:
        return "UNEXPECTED_RESPONSE"
    return "NETWORK_ERROR"


def reality_sni_test(
    xray_path,
    vless_params,
    connect_host,
    connect_port,
    sni,
    attempts,
    tcp_timeout_ms,
    xray_ready_timeout_s=XRAY_TUNNEL_READY_TIMEOUT_S,
    probe_timeout_ms=6000,
):
    with _serialized_xray():
        return _reality_sni_test(xray_path, vless_params, connect_host, connect_port, sni, attempts, tcp_timeout_ms, xray_ready_timeout_s, probe_timeout_ms)


def _reality_sni_test(xray_path, vless_params, connect_host, connect_port, sni, attempts,
                      tcp_timeout_ms, xray_ready_timeout_s, probe_timeout_ms):
    _attempt_args(connect_host, connect_port, attempts, tcp_timeout_ms, sni)
    _timeout_seconds(xray_ready_timeout_s)
    _bounded_int(probe_timeout_ms, 1, MAX_TIMEOUT_MS, "Probe timeout")
    # Respect the caller's explicit timeout instead of silently imposing 3 s.
    precheck_timeout_ms = tcp_timeout_ms
    tcp_res = tcp_handshake_ping(
        connect_host, connect_port, REALITY_TCP_PRECHECK_ATTEMPTS, precheck_timeout_ms
    )
    tcp_ok = tcp_res["success"] > 0
    result = {
        "sni": sni,
        "connect_host": connect_host,
        "connect_port": connect_port,
        "tcp": {
            "ok": tcp_ok,
            "latency_ms": tcp_res["avg_ping"] if tcp_ok else None,
            "success": tcp_res["success"],
            "attempts": tcp_res["count"],
        },
        "reality": {
            "attempts": 0,
            "success": 0,
            "failed": 0,
            "timeouts": 0,
            "network_errors": 0,
            "latencies": [],
            "avg_ms": None,
            "jitter_ms": None,
        },
        "verdict": "NETWORK_ERROR",
        "failure_reason": None,
        "attempt_diagnostics": [],
        "last_error": None,
    }
    if not tcp_ok:
        result["failure_reason"] = "TCP_PRECHECK_FAILED"
        result["last_error"] = (
            f"TCP_PRECHECK_FAILED: {connect_host}:{connect_port} failed all "
            f"{REALITY_TCP_PRECHECK_ATTEMPTS} attempts ({precheck_timeout_ms}ms each)."
        )
        return result
    if not xray_path or not os.path.isfile(xray_path):
        result["failure_reason"] = "XRAY_BINARY_ERROR"
        result["last_error"] = "XRAY_BINARY_ERROR: executable not found"
        return result

    success = failed = timeouts = network_errors = 0
    latencies = []
    diagnostics = []
    for n in range(1, max(1, attempts) + 1):
        _check_cancel()
        result["reality"]["attempts"] += 1
        local_port = _find_free_local_port()
        config = build_xray_client_config(vless_params, connect_host, connect_port, sni, local_port)
        process, config_path, ok, err = run_xray_process(
            xray_path, config, ready_timeout=xray_ready_timeout_s
        )
        if not ok:
            cat = (
                "XRAY_START_TIMEOUT" if err and "XRAY_START_TIMEOUT:" in err else "XRAY_START_ERROR"
            )
            if cat == "XRAY_START_TIMEOUT":
                timeouts += 1
            else:
                network_errors += 1
            diagnostics.append(
                {
                    "attempt": n,
                    "phase": "xray_start",
                    "category": cat,
                    "error": cat + ": local Xray startup failed",
                }
            )
            stop_xray_process(None, config_path)
            continue
        try:
            started = time.perf_counter()
            probe_ok, probe_err = reality_probe_through_tunnel(local_port, probe_timeout_ms)
            elapsed = (time.perf_counter() - started) * 1000
            if probe_ok:
                success += 1
                latencies.append(elapsed)
                diagnostics.append(
                    {
                        "attempt": n,
                        "phase": "reality_probe",
                        "category": "VALID",
                        "error": None,
                        "latency_ms": round(elapsed, 1),
                    }
                )
            else:
                failed += 1
                cat = _classify_probe_error(probe_err)
                if cat == "NETWORK_ERROR":
                    network_errors += 1
                diagnostics.append(
                    {
                        "attempt": n,
                        "phase": "reality_probe",
                        "category": cat,
                        "error": cat + ": tunnel probe did not complete successfully",
                        "latency_ms": round(elapsed, 1),
                    }
                )
        finally:
            stop_xray_process(process, config_path)

    r = result["reality"]
    r.update(
        {
            "success": success,
            "failed": failed,
            "timeouts": timeouts,
            "network_errors": network_errors,
            "latencies": [round(x, 1) for x in latencies],
        }
    )
    if latencies:
        r["avg_ms"] = round(sum(latencies) / len(latencies), 1)
        r["jitter_ms"] = (
            round(
                sum(abs(latencies[i] - latencies[i - 1]) for i in range(1, len(latencies)))
                / (len(latencies) - 1),
                1,
            )
            if len(latencies) > 1
            else 0.0
        )

    total = r["attempts"]
    if success == total and success > 0:
        verdict, reason = "VALID", None
    elif success > 0:
        verdict, reason = "FLAKY", "MIXED_ATTEMPTS"
    elif total > 0 and timeouts == total:
        verdict, reason = "TIMEOUT", "XRAY_START_TIMEOUT"
    else:
        probe_cats = [d["category"] for d in diagnostics if d["phase"] == "reality_probe"]
        if probe_cats and all(x == "PROBE_TIMEOUT" for x in probe_cats):
            verdict, reason = "PROBE_TIMEOUT", "REALITY_PROBE_TIMEOUT"
        elif total > 0 and network_errors == total:
            verdict, reason = "NETWORK_ERROR", "XRAY_OR_PROBE_NETWORK_ERROR"
        elif network_errors or timeouts:
            verdict, reason = "NETWORK_ERROR", "INCONCLUSIVE_FAILURES"
        else:
            verdict, reason = (
                "INVALID",
                (probe_cats[-1] if probe_cats else "REALITY_REJECTED_OR_FALLBACK"),
            )
    result["verdict"] = verdict
    result["failure_reason"] = reason
    result["attempt_diagnostics"] = diagnostics
    result["last_error"] = diagnostics[-1].get("error") if diagnostics else None
    return result


def reality_result_to_row(res):
    """Adapt a reality_sni_test() result into the same row shape the
    existing results table / sort / export code already understands, so
    real REALITY validation can reuse that UI instead of needing a
    parallel one. `ip`/'domain' column carries the SNI (as before),
    `status` mirrors REALITY success (not generic TLS), and `verdict`
    is now one of VALID/FLAKY/INVALID/TIMEOUT/NETWORK_ERROR rather than
    the old GOOD/OFFLINE-style labels."""
    reality = res["reality"]
    attempts = reality["attempts"] or 1
    success = reality["success"]
    avg = reality.get("avg_ms")
    jitter = reality.get("jitter_ms")
    loss = round((1 - success / attempts) * 100, 1) if attempts else 100.0
    row = {
        "ip": res["sni"],
        "packet_loss": loss,
        "avg_ping": avg if avg is not None else float("inf"),
        "status": "Online" if success > 0 else "Offline",
        "success": success,
        "count": attempts,
        "jitter": jitter,
        "min_ping": None,
        "max_ping": None,
        "stddev": None,
        "tcp_status": "Online" if res["tcp"]["ok"] else "Offline",
        "tcp_packet_loss": 0.0 if res["tcp"]["ok"] else 100.0,
        "tcp_avg_ping": res["tcp"]["latency_ms"] if res["tcp"]["ok"] else float("inf"),
        "alpn": "-",
        "verdict": res["verdict"],
        "failure_reason": res.get("failure_reason"),
        "connect_host": res["connect_host"],
        "port": res["connect_port"],
        "reality_last_error": res.get("last_error"),
        "attempt_diagnostics": res.get("attempt_diagnostics", []),
    }
    return row


def reality_sort_key(row):
    """Ranking key for REALITY-validated rows: VALID beats FLAKY beats
    TIMEOUT/NETWORK_ERROR beats INVALID, no matter the latency - only
    WITHIN the same verdict tier do we then sort by speed/jitter. This
    is the fix for the old bug where a low-latency INVALID SNI could
    outrank a slightly-slower VALID one."""
    rank = REALITY_VERDICT_RANK.get(row.get("verdict"), 6)
    ping = row["avg_ping"] if row["avg_ping"] != float("inf") else float("inf")
    jitter = row.get("jitter")
    jitter = jitter if jitter is not None else float("inf")
    return (rank, ping, jitter)
