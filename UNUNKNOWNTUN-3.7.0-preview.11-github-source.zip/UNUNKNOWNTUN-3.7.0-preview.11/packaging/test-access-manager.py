#!/usr/bin/env python3
"""Isolated customer UI/transaction tests. No service or firewall is changed."""
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time
import unittest
from unittest import mock

spec = importlib.util.spec_from_file_location("access_manager", Path(__file__).with_name("access-manager.py"))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class AccessManagerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="ununknowntun-customer-tests-")
        self.root = Path(self.temp.name)
        self.config_dir = self.root / "tunnels" / "test"
        self.config_dir.mkdir(parents=True)
        self.state_dir = self.root / "state"
        self.state_dir.mkdir()
        (self.config_dir / "deployment.env").write_text("ROLE=origin\nIRAN_PROXY_PROVIDER=none\nIRAN_IP=203.0.113.1\nIRAN_ENTRY_DOMAIN=''\nIRAN_ENTRY_PORTS=21001\nTOKEN=never-export-this\nFOREIGN_IP=198.51.100.4\n")
        self.config = {"version": 1, "total_quota_bytes": 100_000_000_000, "accounts": [
            {"id": "default", "name": "Default", "listen": "0.0.0.0:21001", "quota_bytes": 0, "enabled": True},
            {"id": "alice", "name": "Alice", "listen": "0.0.0.0:21002", "quota_bytes": 10_000_000_000, "enabled": True}]}
        (self.config_dir / "access.json").write_text(module.encoded_json(self.config))
        (self.config_dir / "access-routes.json").write_text("{}\n")
        (self.config_dir / "ports.list").write_text("21001\n21002\n")
        self.manager = module.Manager(self.config_dir, self.state_dir, self.root / "install")
        self.manager.reload = mock.Mock()
        self.manager.run = mock.Mock(return_value=subprocess.CompletedProcess([], 0, "", ""))

    def tearDown(self):
        self.temp.cleanup()

    def test_quota_uses_decimal_gb_and_rejects_invalid_overflow(self):
        self.assertEqual(module.gb_to_bytes("0"), 0)
        self.assertEqual(module.gb_to_bytes("0.5"), 500_000_000)
        for value in ("NaN", "Infinity", "-1", "1e1000", "0.0000000001", "bad"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                module.gb_to_bytes(value)

    def test_prompt_retries_only_invalid_value(self):
        with mock.patch("builtins.input", side_effect=["-5", "wrong", "20"]), contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(module.prompt("quota", "0", module.gb_to_bytes), 20_000_000_000)

    def test_name_retries_utf8_overflow_at_name_field(self):
        with mock.patch("builtins.input", side_effect=["😀" * 80, "مشتری"]), contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(module.prompt("name", validate=module.customer_name), "مشتری")
        self.assertEqual(module.customer_name("😀" * 64), "😀" * 64)

    def test_export_contains_only_customer_endpoint(self):
        with contextlib.redirect_stdout(io.StringIO()):
            self.manager.export("alice")
        path = self.config_dir / "customer-exports" / "alice.json"
        payload = json.loads(path.read_text())
        self.assertEqual(payload["ports"], [21002])
        self.assertEqual(payload["address"], "203.0.113.1")
        self.assertNotIn("never-export-this", path.read_text())
        self.assertNotIn("198.51.100.4", path.read_text())
        self.assertEqual(path.stat().st_mode & 0o777, 0o600)

    def test_proxy_routes_exact_paths_rewrite_to_xray_private_listener(self):
        config = copy.deepcopy(self.config)
        config["accounts"][1]["listen"] = "127.0.0.1:19101"
        routes = {"alice": "/gdt-c/0123456789abcdef0123456789abcdef"}
        site = "server {\n" + module.MARKER + "\n}\n"
        rendered = module.build_routes(site, config, routes, "/original-xray-websocket-path")
        self.assertIn("location = /gdt-c/", rendered)
        self.assertIn("proxy_pass http://127.0.0.1:19101/original-xray-websocket-path;", rendered)
        self.assertNotIn("21001", rendered)
        self.assertEqual(module.build_routes(rendered, config, routes, "/original-xray-websocket-path"), rendered)
        config["accounts"][1]["enabled"] = False
        self.assertNotIn("proxy_pass", module.build_routes(rendered, config, routes, "/original-xray-websocket-path"))

    def test_malicious_nginx_path_or_public_proxy_backend_rejected(self):
        site = "server {\n" + module.MARKER + "\n}\n"
        with self.assertRaises(ValueError):
            module.build_routes(site, self.config, {"alice": "/valid-customer-path"}, "/original-xray-websocket-path")
        config = copy.deepcopy(self.config)
        config["accounts"][1]["listen"] = "127.0.0.1:19101"
        with self.assertRaises(ValueError):
            module.build_routes(site, config, {"alice": "/path;evil-directive"}, "/original-xray-websocket-path")

    def test_failed_reload_restores_configuration_and_keeps_accounting(self):
        ledger = self.state_dir / "access-state.json"
        ledger.write_text('existing-accounting-never-reset')
        before = (self.config_dir / "access.json").read_bytes()
        self.manager.reload.side_effect = [RuntimeError("rejected"), None]
        config = copy.deepcopy(self.config)
        config["accounts"][1]["quota_bytes"] = 20_000_000_000
        with self.assertRaises(RuntimeError):
            self.manager.commit(config, {})
        self.assertEqual((self.config_dir / "access.json").read_bytes(), before)
        self.assertEqual(ledger.read_text(), "existing-accounting-never-reset")
        self.assertEqual(self.manager.reload.call_count, 2)

    def test_late_registry_failure_restores_registry_and_ownership(self):
        registry = self.config_dir / "ports.list"
        ownership = self.config_dir / "firewall-owned.ports"
        ownership.write_text("443\n")
        old_registry, old_owned = registry.read_bytes(), ownership.read_bytes()
        real_write = module.atomic_write
        injected = False
        def fail_once(path, content, *args, **kwargs):
            nonlocal injected
            real_write(path, content, *args, **kwargs)
            if Path(path) == registry and not injected:
                injected = True
                raise OSError("simulated post-rename durability failure")
        config = copy.deepcopy(self.config)
        config["accounts"].append({"id": "bob", "name": "Bob", "listen": "0.0.0.0:21003", "quota_bytes": 0, "enabled": True})
        with mock.patch.object(module, "atomic_write", side_effect=fail_once), self.assertRaises(OSError):
            self.manager.commit(config, {})
        self.assertEqual(registry.read_bytes(), old_registry)
        self.assertEqual(ownership.read_bytes(), old_owned)
        self.assertEqual(self.manager.config, self.config)

    def test_persistent_rollback_failure_stops_only_affected_tunnel_and_reports_backup(self):
        ledger = self.state_dir / "access-state.json"
        ledger.write_text("unchanged usage")
        real_write = module.atomic_write
        failed = False
        def fail_persistently(path, content, *args, **kwargs):
            nonlocal failed
            if Path(path) == self.config_dir / "ports.list":
                failed = True
                raise OSError("registry disk full")
            if failed and Path(path) == self.manager.path:
                raise OSError("rollback disk full")
            return real_write(path, content, *args, **kwargs)
        config = copy.deepcopy(self.config)
        config["accounts"][1]["quota_bytes"] = 0
        with mock.patch.object(module, "atomic_write", side_effect=fail_persistently), contextlib.redirect_stderr(io.StringIO()) as output:
            with self.assertRaisesRegex(OSError, "registry disk full"):
                self.manager.commit(config, {})
        self.manager.run.assert_called_once_with("systemctl", "stop", "ununknowntun@test")
        self.assertIn("Backup:", output.getvalue())
        self.assertIn("rollback disk full", output.getvalue())
        self.assertEqual(ledger.read_text(), "unchanged usage")
        self.assertTrue(list((self.root / "install" / "backups").glob("customers-test-*/deployment.env")))

    def test_failed_rollback_ack_stops_tunnel_after_restoring_disk(self):
        self.manager.reload.side_effect = [RuntimeError("initial ack failed"), RuntimeError("rollback ack failed")]
        config = copy.deepcopy(self.config)
        config["accounts"][1]["quota_bytes"] = 0
        with contextlib.redirect_stderr(io.StringIO()) as output, self.assertRaisesRegex(RuntimeError, "initial ack failed"):
            self.manager.commit(config, {})
        self.assertEqual(module.load_json(self.manager.path), self.config)
        self.manager.run.assert_called_once_with("systemctl", "stop", "ununknowntun@test")
        self.assertIn("rollback ack failed", output.getvalue())

    def test_port_edit_releases_old_customer_port_but_keeps_infrastructure_and_metadata(self):
        registry = self.config_dir / "ports.list"
        registry.write_text("443\n18080\n21001\n21002\n")
        config = copy.deepcopy(self.config)
        config["accounts"][0]["listen"] = "0.0.0.0:21003,0.0.0.0:21004"
        with contextlib.redirect_stdout(io.StringIO()):
            self.manager.commit(config, {})
        self.assertEqual(set(registry.read_text().splitlines()), {"443", "18080", "21002", "21003", "21004"})
        env = module.read_env(self.config_dir / "deployment.env")
        self.assertEqual(env["LOCAL_PORTS"], "21003,21004")
        self.assertEqual(env["IRAN_ENTRY_PORTS"], "21003,21004")

    def test_released_owned_firewall_port_is_removed_before_reuse(self):
        owned = self.config_dir / "firewall-owned.ports"
        owned.write_text("443\n21002\n")
        config = copy.deepcopy(self.config)
        config["accounts"][1]["listen"] = "0.0.0.0:21003"
        with mock.patch.object(module.shutil, "which", return_value="/usr/sbin/ufw"), contextlib.redirect_stdout(io.StringIO()):
            self.manager.commit(config, {})
        self.assertEqual(owned.read_text(), "443\n")
        self.manager.run.assert_called_once_with("ufw", "--force", "delete", "allow", "proto", "tcp", "from", "0.0.0.0/0", "to", "0.0.0.0/0", "port", "21002")

    def test_removed_firewall_rule_is_restored_after_later_failure(self):
        owned = self.config_dir / "firewall-owned.ports"
        owned.write_text("443\n21002\n")
        config = copy.deepcopy(self.config)
        config["accounts"][1]["listen"] = "0.0.0.0:21003"
        real_write = module.atomic_write
        failed = False
        def fail_once(path, content, *args, **kwargs):
            nonlocal failed
            if Path(path) == owned and not failed:
                failed = True
                raise OSError("ownership write failed")
            return real_write(path, content, *args, **kwargs)
        with mock.patch.object(module.shutil, "which", return_value="/usr/sbin/ufw"), mock.patch.object(module, "atomic_write", side_effect=fail_once), contextlib.redirect_stderr(io.StringIO()), self.assertRaises(OSError):
            self.manager.commit(config, {})
        self.assertEqual(owned.read_text(), "443\n21002\n")
        self.assertIn(mock.call("ufw", "allow", "proto", "tcp", "from", "0.0.0.0/0", "to", "0.0.0.0/0", "port", "21002"), self.manager.run.call_args_list)

    def test_reload_requires_fresh_matching_successful_ack(self):
        wanted = hashlib.sha256(self.manager.path.read_bytes()).hexdigest()
        statuses = [
            {"config_revision": "wrong", "running": True, "_fresh": True, "_mtime_ns": 101},
            {"config_revision": wanted, "running": True, "_fresh": True, "_mtime_ns": 99},
            {"config_revision": wanted, "running": True, "_fresh": True, "_mtime_ns": 101, "error": "disk error"},
            {"config_revision": wanted, "running": True, "_fresh": True, "_mtime_ns": 101},
        ]
        with mock.patch.object(self.manager, "status", side_effect=statuses), mock.patch.object(module.time, "time_ns", return_value=100), mock.patch.object(module.time, "sleep") as sleep:
            self.assertTrue(module.Manager.reload(self.manager))
        self.assertEqual(sleep.call_count, 3)
        self.assertIn(mock.call("systemctl", "kill", "--kill-who=main", "--signal=HUP", "ununknowntun@test"), self.manager.run.call_args_list)

    def test_reload_rejects_non_acknowledged_or_failed_status(self):
        wanted = hashlib.sha256(self.manager.path.read_bytes()).hexdigest()
        with mock.patch.object(self.manager, "status", return_value={"config_revision": wanted, "running": True, "_fresh": True, "_mtime_ns": 101, "error": "state persistence failed"}), mock.patch.object(module.time, "time_ns", return_value=100), mock.patch.object(module.time, "sleep"):
            with self.assertRaisesRegex(RuntimeError, "did not acknowledge"):
                module.Manager.reload(self.manager)

    def test_stopped_tunnel_does_not_receive_hup(self):
        self.manager.run.return_value = subprocess.CompletedProcess([], 3, "", "")
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertFalse(module.Manager.reload(self.manager))
        self.manager.run.assert_called_once_with("systemctl", "is-active", "--quiet", "ununknowntun@test", check=False)

    def test_old_running_snapshot_is_not_shown_as_live(self):
        path = self.state_dir / "access-state.json.status.json"
        path.write_text(module.encoded_json({"running": True, "accounts": [], "total_used_bytes": 10}))
        old = time.time() - 60
        os.utime(path, (old, old))
        with contextlib.redirect_stdout(io.StringIO()) as output:
            self.manager.show()
        self.assertIn("status stale", output.getvalue())
        self.assertIn("last known snapshot", output.getvalue())
        self.manager.run.return_value = subprocess.CompletedProcess([], 3, "", "")
        with contextlib.redirect_stdout(io.StringIO()) as output:
            self.manager.show()
        self.assertIn("stopped", output.getvalue())

    def test_invalid_status_is_reported_without_crashing_manager(self):
        (self.state_dir / "access-state.json.status.json").write_text("corrupt")
        self.assertIn("cannot be read", self.manager.status()["error"])

    def test_quota_update_does_not_reset_other_customer_or_state(self):
        ledger = self.state_dir / "access-state.json"
        ledger.write_text("persistent-usage")
        with mock.patch("builtins.input", return_value="25"), contextlib.redirect_stdout(io.StringIO()):
            self.manager.set_quota("alice")
        updated = json.loads((self.config_dir / "access.json").read_text())
        self.assertEqual(updated["accounts"][0], self.config["accounts"][0])
        self.assertEqual(updated["accounts"][1]["quota_bytes"], 25_000_000_000)
        self.assertEqual(ledger.read_text(), "persistent-usage")

    def test_reserved_port_rejected_without_touching_files(self):
        with self.assertRaisesRegex(ValueError, "already belongs"):
            self.manager.available_port("21002")
        self.assertEqual(json.loads((self.config_dir / "access.json").read_text()), self.config)


if __name__ == "__main__":
    unittest.main(verbosity=2)
