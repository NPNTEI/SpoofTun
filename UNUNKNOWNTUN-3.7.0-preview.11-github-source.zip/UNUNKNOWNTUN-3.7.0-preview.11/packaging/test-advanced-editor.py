#!/usr/bin/env python3
"""Advanced 3.6 edits: private filesystem fixtures and mocked services only."""
import base64
import contextlib
import importlib.util
import io
from pathlib import Path
import struct
import unittest

spec = importlib.util.spec_from_file_location("advanced_fixture", Path(__file__).with_name("test-editor-safety.py"))
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
editor = fixture.editor


def ech_fixture():
    name = b"public.example.test"
    body = b"\x01\x00\x20\x00\x20" + b"k" * 32 + b"\x00\x04\x00\x01\x00\x01\x40" + bytes([len(name)]) + name + b"\x00\x00"
    config = b"\xfe\x0d" + struct.pack("!H", len(body)) + body
    return base64.b64encode(struct.pack("!H", len(config)) + config).decode()


class AdvancedEditorTests(unittest.TestCase):
    def setUp(self):
        self.fx = fixture.EditorSafetyTests(methodName="runTest")
        self.fx.setUp()
        self.addCleanup(self.fx.doCleanups)
        self.ed, self.directory = self.fx.instance, self.fx.directory

    def commit(self, field, value, **kwargs):
        plan = self.ed.plan(field, value)
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            self.ed.commit(plan, **kwargs)
        return plan

    def test_clean_dial_host_leaves_tls_sni_host_and_peers_alone(self):
        plan = self.commit("connect_host", "clean.example.test")
        self.assertIsNone(plan["update"])
        self.assertEqual(editor.read_flag(self.ed.script, "connect"), "clean.example.test:443,clean.example.test:8443")
        self.assertEqual(editor.read_flag(self.ed.script, "sni"), "foreign.example")
        self.assertEqual(editor.read_flag(self.ed.script, "ws-host"), "foreign.example")
        self.assertEqual(self.ed.env["FOREIGN_IP"], "203.0.113.2")

    def test_ipv6_dial_host_and_reset_auto(self):
        self.commit("connect_host", "[2001:db8::5]")
        self.assertEqual(self.ed.env["CONNECT_HOST"], "2001:db8::5")
        self.assertEqual(editor.read_flag(self.ed.script, "connect"), "[2001:db8::5]:443,[2001:db8::5]:8443")
        self.commit("connect_host", "auto")
        self.assertEqual(editor.read_flag(self.ed.script, "connect"), "203.0.113.2:443,203.0.113.2:8443")
        self.commit("foreign_provider", "cloudflare")
        self.assertEqual(editor.read_flag(self.ed.script, "connect"), "foreign.example:443,foreign.example:8443")

    def test_override_survives_domain_ip_ports_and_provider_edits(self):
        self.commit("connect_host", "203.0.113.44")
        for field, value in (("foreign_domain", "new.example.test"), ("foreign_ip", "203.0.113.8"), ("foreign_ports", "443"), ("foreign_provider", "cloudflare")):
            self.commit(field, value)
            self.assertEqual(self.ed.env["CONNECT_HOST"], "203.0.113.44")
            self.assertTrue(all(p.startswith("203.0.113.44:") for p in editor.read_flag(self.ed.script, "connect").split(",")))

    def test_explicit_sni_host_independent_and_preserved_after_rename(self):
        self.assertIsNone(self.commit("tls_sni", "tls.example.test")["update"])
        self.assertIsNotNone(self.commit("http_host", "http.example.test")["update"])
        self.commit("foreign_domain", "renamed.example.test")
        self.assertEqual(editor.read_flag(self.ed.script, "sni"), "tls.example.test")
        self.assertEqual(editor.read_flag(self.ed.script, "ws-host"), "http.example.test")
        self.assertEqual(self.ed.env["TLS_SNI"], "tls.example.test")
        self.assertEqual(self.ed.env["HTTP_HOST"], "http.example.test")

    def test_installer_defaults_follow_domain_without_explicit_marker(self):
        self.fx.env.update(TLS_SNI="foreign.example", HTTP_HOST="foreign.example")
        self.fx.write_fixture()
        self.commit("foreign_domain", "renamed.example.test")
        self.assertEqual(editor.read_flag(self.ed.script, "sni"), "renamed.example.test")
        self.assertEqual(editor.read_flag(self.ed.script, "ws-host"), "renamed.example.test")

    def test_installer_custom_names_remain_without_explicit_marker(self):
        self.fx.env.update(TLS_SNI="tls.example.test", HTTP_HOST="http.example.test")
        self.fx.script = editor.set_flag(editor.set_flag(self.fx.script, "sni", "tls.example.test"), "ws-host", "http.example.test")
        self.fx.write_fixture()
        self.commit("foreign_domain", "renamed.example.test")
        self.assertEqual(editor.read_flag(self.ed.script, "sni"), "tls.example.test")
        self.assertEqual(editor.read_flag(self.ed.script, "ws-host"), "http.example.test")

    def test_padding_is_local_mode_and_host_have_signed_updates(self):
        for field, value, flag in (("padding_bytes", "100-1000", "padding-bytes"), ("xhttp_padding", "100-2000", "xhttp-padding-bytes"), ("ech_source", "cloudflare-ech.com+udp://9.9.9.9", "ech-config")):
            plan = self.commit(field, value)
            self.assertIsNone(plan["update"])
            self.assertEqual(editor.read_flag(self.ed.script, flag), value)
        for field, value in (("xhttp_mode", "stream-up"), ("http_host", "another.example.test")):
            self.assertIsNotNone(self.commit(field, value)["update"])
        self.assertEqual((self.fx.state / "access-state.json").read_text(), "live-use-must-never-be-restored")

    def test_peer_export_uses_actual_mode_and_host(self):
        (self.directory / "peer.env").write_text("FORMAT=UNUNKNOWNTUN_V5_FLEET\nXHTTP_MODE=packet-up\n")
        self.commit("xhttp_mode", "stream-one")
        self.commit("http_host", "routed.example.test")
        peer = (self.directory / "peer.env").read_text()
        self.assertIn("XHTTP_MODE=stream-one\n", peer)
        self.assertIn("HTTP_HOST=routed.example.test\n", peer)
        self.commit("transport", "xhttp")
        self.assertEqual(editor.read_flag(self.ed.script, "xhttp-mode"), "stream-one")

    def test_all_modes_validate_and_signatures_reject_tampering(self):
        for mode in ("auto", "packet-up", "stream-up", "stream-one"):
            self.assertEqual(editor.validate("xhttp_mode", mode), mode)
        data = self.fx.valid_data("xhttp_mode", "stream-one")
        self.assertEqual(self.ed.decode_update(self.fx.signed(data)), ("xhttp_mode", "stream-one"))
        bad = dict(data, value="unknown")
        with self.assertRaises(ValueError):
            self.ed.decode_update(self.fx.signed(bad))

    def test_origin_only_fields_rejected_on_egress(self):
        self.fx.env["ROLE"] = "egress"
        self.fx.write_fixture()
        for field, value in (("connect_host", "203.0.113.4"), ("tls_sni", "example.test"), ("ech_source", "udp://9.9.9.9")):
            with self.subTest(field=field), self.assertRaises(ValueError):
                self.ed.plan(field, value)

    def test_bad_hosts_ranges_sources_rejected_before_mutation(self):
        before = (self.directory / "run.sh").read_bytes()
        for field, value in (("connect_host", "https://clean.example"), ("connect_host", "host.example:443"), ("connect_host", "999.1.1.1"), ("connect_host", "2001:db8::1%eth0"), ("connect_host", "a.example,b.example"), ("tls_sni", "$(id)"), ("padding_bytes", "1025"), ("padding_bytes", "2-1"), ("xhttp_padding", "4097"), ("xhttp_padding", "01-10"), ("ech_source", "AAL+DQ=="), ("ech_source", "udp://example.test"), ("ech_source", "https://user:secret@resolver.example/"), ("ech_source", "http://resolver.example/"), ("xhttp_mode", "stream-two")):
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                self.ed.plan(field, value)
        self.assertEqual((self.directory / "run.sh").read_bytes(), before)
        self.assertFalse(self.ed.run.called)

    def test_manual_base64_and_resolver_validation(self):
        for value in (ech_fixture(), "base64:" + ech_fixture(), "cloudflare-ech.com+udp://9.9.9.9", "tcp://[::1]:8053", "https://resolver.example.test/dns-query?token=private"):
            self.assertEqual(editor.validate("ech_source", value), value)
        self.commit("ech_source", "https://resolver.example.test/dns-query?token=private")
        self.assertNotIn("token=private", (self.directory / "client-info.txt").read_text())
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            self.ed.show()
        self.assertNotIn("token=private", out.getvalue())

    def test_post_validate_sees_new_files_and_runs_after_restart(self):
        self.ed.active.return_value = True
        checked = []
        def verify():
            checked.append(self.ed.env["CONNECT_HOST"])
            self.assertIn(("systemctl", "restart", self.ed.service), [c.args for c in self.ed.run.call_args_list])
            self.assertTrue(self.ed.wait_service.called)
        self.commit("connect_host", "203.0.113.55", post_validate=verify)
        self.assertEqual(checked, ["203.0.113.55"])

    def test_post_validate_failure_restores_files_and_selected_service(self):
        self.ed.active.return_value = True
        before = {p: p.read_bytes() for p in (self.directory / "run.sh", self.directory / "deployment.env")}
        def reject():
            raise RuntimeError("authenticated candidate failed")
        with self.assertRaises(RuntimeError):
            self.commit("connect_host", "203.0.113.55", post_validate=reject)
        for path, data in before.items():
            self.assertEqual(path.read_bytes(), data)
        calls = [c.args for c in self.ed.run.call_args_list if c.args[:2] == ("systemctl", "restart")]
        self.assertEqual(calls, [("systemctl", "restart", self.ed.service)] * 2)
        self.assertEqual((self.fx.state / "access-state.json").read_text(), "live-use-must-never-be-restored")
        self.assertEqual(self.ed.current("connect_host"), "auto")

    def test_post_validate_false_rolls_back_stopped_without_start(self):
        with self.assertRaises(RuntimeError):
            self.commit("connect_host", "203.0.113.55", post_validate=lambda: False)
        self.assertFalse(any(c.args[:2] in (("systemctl", "start"), ("systemctl", "restart")) for c in self.ed.run.call_args_list))
        self.assertEqual(self.ed.current("connect_host"), "auto")

    def test_background_update_cancelled_before_mutation_if_stopped(self):
        plan = self.ed.plan("connect_host", "203.0.113.55")
        plan["background"] = True
        before = (self.directory / "run.sh").read_bytes()
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()), self.assertRaisesRegex(RuntimeError, "tunnel is stopped"):
            self.ed.commit(plan)
        self.assertEqual((self.directory / "run.sh").read_bytes(), before)
        self.assertFalse(any(c.args[:1] == ("systemctl",) for c in self.ed.run.call_args_list))

    def test_background_external_stop_is_not_reactivated_on_rollback(self):
        plan = self.ed.plan("connect_host", "203.0.113.55")
        plan["background"] = True
        before = (self.directory / "run.sh").read_bytes()
        self.ed.active.side_effect = [True, False, False]
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()), self.assertRaisesRegex(RuntimeError, "stopped during"):
            self.ed.commit(plan)
        self.assertEqual((self.directory / "run.sh").read_bytes(), before)
        actions = [c.args for c in self.ed.run.call_args_list if c.args[:1] == ("systemctl",)]
        self.assertEqual(actions, [("systemctl", "try-restart", self.ed.service)] * 2)
        self.assertFalse(self.ed.wait_service.called)

    def test_background_validation_failure_recovers_running_service_without_start(self):
        plan = self.ed.plan("connect_host", "203.0.113.55")
        plan["background"] = True
        self.ed.active.return_value = True
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()), self.assertRaises(RuntimeError):
            self.ed.commit(plan, post_validate=lambda: False)
        actions = [c.args for c in self.ed.run.call_args_list if c.args[:1] == ("systemctl",)]
        self.assertEqual(actions, [("systemctl", "try-restart", self.ed.service)] * 2)
        self.assertEqual(self.ed.wait_service.call_count, 2)
        self.assertEqual(self.ed.current("connect_host"), "auto")


if __name__ == "__main__":
    unittest.main()
