#!/usr/bin/env python3
"""3.6 wizard/launch/upgrade regressions using isolated shell fixtures only.

No installer dispatcher, public scanner, DNS resolver, service, package manager
or real tunnel is run. Host tools are mocked by test-full-installer.py.
"""
import base64
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import struct
import unittest


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(filename))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


installer = load("advanced_installer_fixture", "test-full-installer.py")
upgrade = load("advanced_upgrade_fixture", "test-upgrade.py")
editor = load("advanced_installer_editor", "tunnel-editor.py")
validation = load("advanced_profile_validation", "profile-validation.py")


def ech_fixture(*, extensions=b"", key=b"k" * 32, kem=0x20, suites=b"\x00\x01\x00\x01", name=b"public.example.test"):
    body = b"\x01" + struct.pack("!HH", kem, len(key)) + key + struct.pack("!H", len(suites)) + suites + b"\x40" + bytes([len(name)]) + name + struct.pack("!H", len(extensions)) + extensions
    config = b"\xfe\x0d" + struct.pack("!H", len(body)) + body
    return base64.b64encode(struct.pack("!H", len(config)) + config).decode()


class ProfileValidationTests(unittest.TestCase):
    def test_manual_list_and_descriptor_editor_parity(self):
        for value in ("auto", ech_fixture(), "base64:" + ech_fixture(), "cloudflare-ech.com+udp://9.9.9.9", "outer.example+tcp://[2001:db8::53]:5353", "https://resolver.example/dns-query?token=private&x=2+3%20a"):
            with self.subTest(value=value[:25]):
                self.assertEqual(validation.ech_source(value), value)
                self.assertEqual(editor.validate_ech_source(value), value)

    def test_manual_list_rejects_unusable_or_malformed(self):
        invalid = ("AA==", "AAAA", "not-a-config", ech_fixture() + "A", ech_fixture(key=b"k" * 31), ech_fixture(kem=1), ech_fixture(suites=b"\x00\x99\x00\x01"), ech_fixture(suites=b"\x00\x01\x00"), ech_fixture(name=b"127.0.0.1"), ech_fixture(extensions=b"\x80\x01\x00\x00"), ech_fixture(extensions=b"\x00\x01\x00\x00" * 2), ech_fixture(extensions=b"\x00\x01\x00\x03"))
        for value in invalid:
            with self.subTest(value=value[:20]), self.assertRaises(ValueError):
                validation.ech_source(value)

    def test_resolver_rejects_bad_scheme_host_port_credentials(self):
        invalid = ("udp://dns.example", "tcp://9.9.9.9/", "udp://9.9.9.9?", "http://resolver.example/dns-query", "https://user:password@resolver.example/dns-query", "https://resolver.example:0/dns-query", "https://resolver.example:65536/dns-query", "https://resolver.example:/dns-query", "https://resolver.example/dns-query#frag", "https://resolver.example/%ZZ", "tcp://[2001:db8::1%eth0]:53")
        for value in invalid:
            with self.subTest(value=value), self.assertRaises(ValueError):
                validation.ech_source(value)

    def test_embedded_shell_source_rejects_controls_and_apostrophes(self):
        for suffix in ("\x00", "\x01", "\x7f", "\n", "\t", " ", "'", "';touch-private-file;'"):
            with self.subTest(suffix=repr(suffix)), self.assertRaises(ValueError):
                validation.ech_source("https://resolver.example/dns-query?token=" + suffix)
        # These characters remain literal inside the installer's single quotes.
        value = 'https://resolver.example/dns-query?x=$(echo private)&y=`literal`&z="quoted"'
        with self.assertRaises(ValueError):
            validation.ech_source(value)  # whitespace remains forbidden
        self.assertEqual(validation.ech_source(value.replace(" ", "")), value.replace(" ", ""))

    def test_cli_never_echoes_private_resolver(self):
        for command in ("ech", "bytes", "http-bytes", "bad"):
            output = io.StringIO()
            with contextlib.redirect_stderr(output):
                self.assertEqual(validation.main([command, "https://secret.example/?token=secret-private-value'"]), 1)
            self.assertNotIn("secret-private-value", output.getvalue())
            self.assertNotIn("secret.example", output.getvalue())

    def test_byte_range_parity_and_bounds(self):
        for maximum in (1024, 4096):
            for value in ("0", "0-0", "100-1000", str(maximum), "0-" + str(maximum)):
                self.assertEqual(validation.byte_range(value, maximum), editor.byte_range(value, maximum))
            for value in ("01", "00-1", "1-01", "-1", "1.0", "2-1", "1-" + str(maximum + 1), "10000", " 1", "1\n"):
                with self.subTest(value=value, maximum=maximum), self.assertRaises(ValueError):
                    validation.byte_range(value, maximum)
        self.assertEqual(validation.main(["bytes", "0-1024"]), 0)
        self.assertEqual(validation.main(["http-bytes", "0-4096"]), 0)


class AdvancedInstallerTests(unittest.TestCase):
    def setUp(self):
        self.fx = installer.InstallerTests(methodName="runTest")
        self.fx.setUp()
        self.addCleanup(self.fx.tearDown)

    def launch(self):
        return (self.fx.root / "config/run.sh").read_text()

    def test_cloudflare_domain_default_and_opt_in_auto(self):
        result = self.fx.run_shell('''
domain=edge.example; foreign_provider=cloudflare
select_dial_profile
[[ -z "$dial_host" && "$tls_sni/$http_host/$clean_scan/$scan_auto" == edge.example/edge.example/no/no ]]
printf 'dial-default-ok\n'
''', stdin="1\nn\nn\n")
        self.assertIn("dial-default-ok", result.stdout)
        self.assertEqual(self.fx.log.read_text(), "")

    def test_cloudflare_manual_ip_separate_sni_host(self):
        self.fx.run_shell('''
domain=edge.example; foreign_provider=cloudflare
select_dial_profile
[[ "$dial_host" == 203.0.113.17 && "$tls_sni" == tls.example && "$http_host" == route.example && "$clean_scan/$scan_auto" == no/no ]]
''', stdin="2\nhttps://invalid.example\n203.0.113.17\ny\ntls.example\nroute.example\nn\n")

    def test_other_cdns_manual_domain_and_no_cloudflare_scan(self):
        for provider in ("arvan", "fastly"):
            with self.subTest(provider=provider):
                result = self.fx.run_shell(f'''
domain=edge.example; foreign_provider={provider}
select_dial_profile
[[ "$dial_host/$clean_scan/$scan_auto/$tls_sni/$http_host" == clean.example/no/no/edge.example/edge.example ]]
''', stdin="3\n2\nclean.example\nn\n")
                self.assertIn("Cloudflare only", result.stderr)
                self.assertNotIn("3) Scan Cloudflare", result.stdout)
        self.assertEqual(self.fx.log.read_text(), "")

    def test_cloudflare_scanner_parameters_reprompt_locally_and_opt_in_interval(self):
        result = self.fx.run_shell('''
domain=edge.example; foreign_provider=cloudflare
select_dial_profile
[[ "$clean_scan/$scan_seconds/$scan_count/$scan_auto/$scan_hours" == yes/360/72/yes/7 ]]
''', stdin="3\n9\n360\n129\n72\nn\ny\n0\n7\n")
        self.assertIn("10-600", result.stderr)
        self.assertIn("1-128", result.stderr)
        self.assertIn("1-168", result.stderr)
        self.assertEqual(self.fx.log.read_text(), "")

    def test_no_proxy_profile_requires_no_answers(self):
        self.fx.run_shell('''
domain=edge.example; foreign_provider=none
select_dial_profile
[[ -z "$dial_host" && "$tls_sni/$http_host/$clean_scan/$scan_auto" == edge.example/edge.example/no/no ]]
''', stdin="")

    def test_manual_ipv6_acceptance_host_only_rejection(self):
        self.fx.run_shell('''
valid_dial_host 2001:db8::17
valid_dial_host clean.example
! valid_dial_host https://clean.example
! valid_dial_host clean.example:443
! valid_dial_host 999.999.999.999
! valid_dial_host '2001:db8::17%eth0'
''')

    def test_tls_has_only_three_modes_and_rejects_old_four(self):
        result = self.fx.run_shell('''
select_tls_handshake_profile
[[ "$ech_mode/$tls_fragment/$ech_source" == off/off/auto ]]
''', stdin="4\n1\n")
        self.assertNotIn("TLS Hello over DNS", result.stdout)
        self.assertIn("Select 1, 2 or 3", result.stderr)
        self.assertEqual(self.fx.log.read_text(), "")

    def test_tls_manual_ech_repairs_only_the_source(self):
        result = self.fx.run_shell('''
select_tls_handshake_profile
[[ "$ech_mode/$tls_fragment" == strict/off ]]
[[ "$ech_source" == cloudflare-ech.com+udp://9.9.9.9 ]]
''', stdin="2\nn\nhas spaces\nnot-a-config\ncloudflare-ech.com+udp://9.9.9.9\n")
        self.assertIn("fail closed", result.stderr)

    def test_ech_source_validator_matches_supported_resolver_protocols(self):
        self.fx.run_shell('''
valid_ech_source cloudflare-ech.com+udp://9.9.9.9
valid_ech_source 'outer.example+tcp://[2001:db8::1]:53'
valid_ech_source https://resolver.example/dns-query
! valid_ech_source http://resolver.example/dns-query
! valid_ech_source not-a-config
! valid_ech_source udp://9.9.9.9:0
! valid_ech_source https://user:secret@resolver.example/dns-query
''')

    def test_tls_auto_ech_and_fragment_remain_distinct(self):
        self.fx.run_shell('select_tls_handshake_profile; [[ "$ech_mode/$tls_fragment/$ech_source" == strict/off/auto ]]', stdin="2\ny\n")
        self.fx.run_shell('select_tls_handshake_profile; [[ "$ech_mode/$tls_fragment/$fragment_size/$fragment_interval" == off/hello/120-240/2-4ms ]]', stdin="3\n120-240\n2-4ms\n")

    def test_four_xhttp_modes_and_mux_mapping(self):
        for option, mode in (("1", "auto"), ("2", "stream-up"), ("3", "stream-one"), ("4", "packet-up")):
            with self.subTest(mode=mode):
                self.fx.run_shell(f'foreign_provider=cloudflare; select_tunnel_profile; [[ "$transport/$mux_mode/$xhttp_mode" == xhttp/off/{mode} ]]', stdin=f"2\n2\n{option}\n")

    def test_padding_prompt_ranges_repair_only_bad_number(self):
        self.fx.run_shell('transport=xhttp; select_padding_profile; [[ "$padding_bytes/$xhttp_padding" == 100-1000/100-2000 ]]', stdin="y\n1025\n100-1000\ny\n4097\n100-2000\n")
        self.fx.run_shell('transport=wss; select_padding_profile; [[ "$padding_bytes/$xhttp_padding" == 0/0 ]]', stdin="n\n")

    def test_padding_validator_is_canonical_like_core(self):
        self.fx.run_shell('''
valid_byte_padding 0; valid_byte_padding 0-1024
valid_http_padding 4096; valid_http_padding 100-1000
! valid_byte_padding 1025; ! valid_http_padding 4097
! valid_byte_padding 10-1; ! valid_http_padding 20-10
! valid_byte_padding 01; ! valid_http_padding 01-010
! valid_byte_padding -1; ! valid_http_padding 1.5
''')

    def test_generated_origin_separates_dial_sni_http_and_retains_strict_ech(self):
        self.fx.run_shell('''
PROFILE_MAX_MEMORY=268435456; PROFILE_MAX_STREAMS=128
transport=xhttp; xhttp_mode=stream-up; xhttp_path=/private-xhttp-path; mux_mode=off
dial_host=203.0.113.77; tls_sni=tls.example; http_host=route.example
ech_source=cloudflare-ech.com+udp://9.9.9.9; padding_bytes=100-1000; xhttp_padding=20-200
write_origin_run_script edge.example 203.0.113.10 443,8443 /private-wss-path /private-h2-path 18082 2055 8 0 cloudflare none chrome strict
sh -n "$CONFIG_DIR/run.sh"
''')
        launch = self.launch()
        for flag, expected in {"connect": "203.0.113.77:443,203.0.113.77:8443", "sni": "tls.example", "ws-host": "route.example", "ech-mode": "strict", "ech-config": "cloudflare-ech.com+udp://9.9.9.9", "xhttp-mode": "stream-up", "padding-bytes": "100-1000", "xhttp-padding-bytes": "20-200", "mux": "off", "tls-min-version": "1.3"}.items():
            self.assertEqual(editor.read_flag(launch, flag), expected)
        self.assertEqual(self.fx.log.read_text(), "")

    def test_generated_ipv6_dial_is_bracketed_per_port(self):
        self.fx.run_shell('''
PROFILE_MAX_MEMORY=268435456; PROFILE_MAX_STREAMS=128
dial_host=2001:db8::77
write_origin_run_script edge.example 203.0.113.10 443,8443 /private-wss-path /private-h2-path 18082 2055 8 0 cloudflare none chrome off
''')
        self.assertEqual(editor.read_flag(self.launch(), "connect"), "[2001:db8::77]:443,[2001:db8::77]:8443")

    def test_generated_egress_agrees_with_custom_host_mode_padding(self):
        self.fx.run_shell('''
PROFILE_MAX_MEMORY=268435456; PROFILE_MAX_STREAMS=128
transport=xhttp; xhttp_mode=stream-one; http_host=route.example; padding_bytes=100-500; xhttp_padding=50-100
write_foreign_run_script edge.example /private-wss-path 18080 /private-h2-path 18081 18082
''')
        for flag, expected in (("ws-host", "route.example"), ("xhttp-mode", "stream-one"), ("padding-bytes", "100-500"), ("xhttp-padding-bytes", "50-100")):
            self.assertEqual(editor.read_flag(self.launch(), flag), expected)

    def test_peer_roundtrip_host_mode_and_legacy_host_default(self):
        self.fx.run_shell('''
transport=xhttp; xhttp_path=/private-xhttp-path; xhttp_mode=stream-one; http_host=route.example
code="$(create_peer_code edge.example 203.0.113.10 443 /private-wss-path /private-h2-path 0123456789abcdef0123456789abcdef 18082 cloudflare chrome none '' a1b2c3d4e5f60718)"
decode_peer_code "$code"
[[ "$PEER_HTTP_HOST/$PEER_XHTTP_MODE" == route.example/stream-one ]]
''')
        peer = (self.fx.root / "config/peer.env").read_text()
        old = "\n".join(line for line in peer.splitlines() if not line.startswith("HTTP_HOST=")) + "\n"
        self.fx.run_shell('decode_peer_code ' + base64.b64encode(old.encode()).decode() + '; [[ "$PEER_HTTP_HOST" == edge.example ]]')
        invalid = peer.replace("HTTP_HOST=route.example", "HTTP_HOST=bad;host")
        self.fx.run_shell('! decode_peer_code ' + base64.b64encode(invalid.encode()).decode())

    def test_metadata_keeps_independent_endpoint_and_padding_values(self):
        self.fx.run_shell('''
transport=xhttp; xhttp_mode=stream-up; dial_host=clean.example; tls_sni=tls.example; http_host=route.example
ech_source=cloudflare-ech.com+udp://9.9.9.9; padding_bytes=100-1000; xhttp_padding=0
write_deployment_env origin edge.example 203.0.113.10 443 2055 cloudflare none
''')
        values = editor.access.read_env(self.fx.root / "config/deployment.env")
        for key, value in {"CONNECT_HOST": "clean.example", "TLS_SNI": "tls.example", "HTTP_HOST": "route.example", "ECH_SOURCE": "cloudflare-ech.com+udp://9.9.9.9", "PADDING_BYTES": "100-1000", "XHTTP_PADDING_BYTES": "0", "XHTTP_MODE": "stream-up"}.items():
            self.assertEqual(values[key], value)

    def test_scanner_config_opt_in_saved_private_without_scan(self):
        self.fx.run_shell('foreign_provider=cloudflare; scan_auto=yes; scan_seconds=360; scan_count=72; scan_hours=7; write_cdn_settings')
        path = self.fx.root / "config/cdn-endpoints.json"
        config = json.loads(path.read_text())
        self.assertEqual((config["enabled"], config["duration_seconds"], config["max_candidates"], config["interval_hours"]), (True, 360, 72, 7))
        self.assertEqual(path.stat().st_mode & 0o777, 0o600)
        self.assertEqual(self.fx.log.read_text(), "")

    def test_nginx_streaming_modes_have_unlimited_body_without_buffering(self):
        for mode in ("auto", "stream-up", "stream-one", "packet-up"):
            with self.subTest(mode=mode):
                self.fx.run_shell(f'transport=xhttp; xhttp_mode={mode}; xhttp_path=/private-xhttp-path; write_nginx_wss_site edge.example 443 /private-wss-path 18080 /private-h2-path 18081 /cert.pem /key.pem')
                site = (self.fx.root / "nginx-available/ununknowntun-edge.example.conf").read_text()
                self.assertIn("client_max_body_size " + ("2m" if mode == "packet-up" else "0") + ";", site)
                self.assertIn("proxy_request_buffering off;", site)
                self.assertIn("proxy_buffering off;", site)
                self.assertNotIn("grpc_", site)


class AdvancedUpgradeTests(unittest.TestCase):
    def test_upgrade_preserves_mode_padding_ech_and_dial_separation(self):
        fx = upgrade.UpgradeTests(methodName="runTest")
        fx.setUp()
        self.addCleanup(fx.tearDown)
        fx.prepare(with_site=False)
        profile = {"xhttp-mode": "stream-one", "padding-bytes": "100-1000", "xhttp-padding-bytes": "20-200", "ech-config": "cloudflare-ech.com+udp://9.9.9.9", "connect": "clean.example:443", "sni": "tls.example", "ws-host": "route.example"}
        source = fx.run.read_text().replace("-transport auto", "-transport xhttp")
        for flag, value in profile.items():
            source = editor.set_flag(source, flag, value)
        fx.run.write_text(source)
        (fx.directory / "peer.env").write_text("FORMAT=UNUNKNOWNTUN_V5_FLEET\nTOKEN=private-fixture\nXHTTP_MODE=packet-up\n")
        ledger = (fx.state / "access-state.json").read_bytes()
        fx.shell("patch_upgrade_configuration\n")
        for flag, value in profile.items():
            self.assertEqual(editor.read_flag(fx.run.read_text(), flag), value)
        self.assertIn("XHTTP_MODE=stream-one\n", (fx.directory / "peer.env").read_text())
        self.assertEqual((fx.state / "access-state.json").read_bytes(), ledger)


class InitialCarrierRepairTests(unittest.TestCase):
    def setUp(self):
        self.fx = installer.InstallerTests(methodName="runTest")
        self.fx.setUp()
        self.addCleanup(self.fx.tearDown)
        start = '    while ! python3 "$INSTALL_DIR/share/cdn-control.py" verify --config-dir "$CONFIG_DIR"; do\n'
        self.loop = start + installer.SOURCE.split(start, 1)[1].split('    setup_safe_tcp_tuning\n', 1)[0]
        self.assertNotIn("initialize_customer_access", self.loop)
        self.assertNotIn("write_token_file", self.loop)
        self.assertNotIn("systemctl", self.loop)
        self.private = {}
        for name, content in (("token", b"keep-private-token\n"), ("access.json", b'{"fixture":"quota-must-not-reset"}\n'), ("access-state.json", b'{"used_bytes":123456}\n')):
            path = self.fx.root / "config" / name
            path.write_bytes(content)
            self.private[path] = content
        (self.fx.root / "config/run.sh").write_text("existing launch sentinel\n")
        self.setup = '''
domain=edge.example; direct_ip=203.0.113.20; foreign_ports=443,8443
local_ports=2055; target_port=18082; sessions=8; pad=0.22; total_quota_gb=123
foreign_provider=cloudflare; iran_provider=none; iran_ip=203.0.113.10
entry_domain=; entry_ports=; entry_path=/entry; nginx_site=; spoof_profile=chrome
pair_id=keep-pair-id; token=keep-private-token; ws_path=/keep-ws; h2_path=/keep-h2
transport=xhttp; xhttp_mode=stream-one; xhttp_path=/keep-xhttp; mux_mode=off
PROFILE_MAX_MEMORY=268435456; PROFILE_MAX_STREAMS=128
dial_host=old-clean.example; tls_sni=old-sni.example; http_host=route.example
ech_mode=off; ech_source=auto; tls_fragment=off; padding_bytes=0; xhttp_padding=0
clean_scan=no; scan_auto=no; scan_seconds=300; scan_count=64; scan_hours=8
verify_calls=0
python3() {
    if [[ "$1" == "$INSTALL_DIR/share/cdn-control.py" ]]; then
        [[ "$2/$3/$4/$#" == "verify/--config-dir/$CONFIG_DIR/4" ]] || return 99
        verify_calls=$((verify_calls+1))
        printf 'verify %s\\n' "$verify_calls" >> "$MOCK_LOG"
        [[ "$verify_calls" -ge 2 ]]
    else command python3 "$@"; fi
}
'''
        self.retained = '''
[[ "$verify_calls" == 2 ]]
[[ "$pair_id/$token/$total_quota_gb/$local_ports/$target_port/$foreign_ports/$sessions" == keep-pair-id/keep-private-token/123/2055/18082/443,8443/8 ]]
[[ "$ws_path/$h2_path/$xhttp_path/$xhttp_mode/$mux_mode" == /keep-ws//keep-h2//keep-xhttp/stream-one/off ]]
'''

    def assert_private_unchanged(self):
        for path, content in self.private.items():
            self.assertEqual(path.read_bytes(), content)

    def test_retry_reuses_all_answers_without_rewriting_launch(self):
        self.fx.run_shell(self.setup + self.loop + self.retained, stdin="1\n")
        self.assertEqual((self.fx.root / "config/run.sh").read_text(), "existing launch sentinel\n")
        self.assert_private_unchanged()
        self.assertEqual(self.fx.log.read_text(), "verify 1\nverify 2\n")

    def test_repair_updates_only_connection_profile_and_preserves_quota_pair_ports(self):
        answer = "2\n2\nhttps://bad.example\n203.0.113.55\ny\ntls.example\nroute.example\nn\n2\nn\nnot-a-config\ncloudflare-ech.com+udp://9.9.9.9\ny\n1040\n100-500\ny\n4097\n50-100\n"
        self.fx.run_shell(self.setup + self.loop + self.retained, stdin=answer)
        launch = (self.fx.root / "config/run.sh").read_text()
        for flag, value in {"connect": "203.0.113.55:443,203.0.113.55:8443", "sni": "tls.example", "ws-host": "route.example", "ech-mode": "strict", "ech-config": "cloudflare-ech.com+udp://9.9.9.9", "padding-bytes": "100-500", "xhttp-padding-bytes": "50-100", "xhttp-mode": "stream-one", "mux": "off", "target": "127.0.0.1:18082", "listen": "0.0.0.0:2055"}.items():
            self.assertEqual(editor.read_flag(launch, flag), value)
        metadata = (self.fx.root / "config/deployment.env").read_text()
        self.assertIn("PAIR_ID=keep-pair-id\n", metadata)
        self.assertIn("LOCAL_PORTS=2055\n", metadata)
        self.assert_private_unchanged()
        self.assertEqual(self.fx.log.read_text(), "verify 1\nverify 2\n")

    def test_cancel_exits_without_rewriting_answers_or_customer_state(self):
        result = self.fx.run_shell(self.setup + self.loop, stdin="3\n", expected=1)
        self.assertIn("Carrier validation cancelled", result.stderr)
        self.assertEqual((self.fx.root / "config/run.sh").read_text(), "existing launch sentinel\n")
        self.assert_private_unchanged()
        self.assertEqual(self.fx.log.read_text(), "verify 1\n")


if __name__ == "__main__":
    unittest.main(verbosity=2)
