#!/usr/bin/env python3
"""Offline controller transactions: temporary files, mocked probes and services.

No live scan, systemd operation, or production config write is performed.
The existing editor safety fixture supplies the real plan/commit implementation.
"""
import contextlib
import copy
import fcntl
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(filename))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


controller = load("tested_cdn_control", "cdn-control.py")
safety = load("cdn_control_editor_fixture", "test-editor-safety.py")


class ManagerPreviewDispatchTests(unittest.TestCase):
    def test_scheduler_cli_requires_global_lock_and_forwards_inherited_descriptor(self):
        directory = Path("/etc/ununknowntun/tunnels/example")
        for action in ("schedule", "unschedule"):
            for inherited in (None, 9):
                args = ["cdn-control.py", action, "--config-dir", str(directory)]
                if inherited is not None:
                    args += ["--initial-lock-fd", str(inherited)]
                with self.subTest(action=action, inherited=inherited), \
                        mock.patch.object(sys, "argv", args), \
                        mock.patch.object(controller.os, "geteuid", return_value=0), \
                        mock.patch.object(Path, "is_symlink", return_value=False), \
                        mock.patch.object(Path, "is_dir", return_value=True), \
                        mock.patch.object(Path, "lstat", return_value=SimpleNamespace(st_uid=0, st_mode=0o755)), \
                        mock.patch.object(controller.signal, "signal"), \
                        mock.patch.object(controller, "lock", return_value=contextlib.nullcontext()) as lock, \
                        mock.patch.object(controller, "schedule") as schedule:
                    controller.main()
                lock.assert_called_once_with("/run/ununknowntun-installer.lock", inherited)
                schedule.assert_called_once_with(directory, disable=action == "unschedule")

    def test_scheduler_lock_contention_prevents_any_schedule_change(self):
        args = ["cdn-control.py", "schedule", "--config-dir", "/etc/ununknowntun/tunnels/example"]
        with mock.patch.object(sys, "argv", args), \
                mock.patch.object(controller.os, "geteuid", return_value=0), \
                mock.patch.object(Path, "is_symlink", return_value=False), \
                mock.patch.object(Path, "is_dir", return_value=True), \
                mock.patch.object(Path, "lstat", return_value=SimpleNamespace(st_uid=0, st_mode=0o755)), \
                mock.patch.object(controller.signal, "signal"), \
                mock.patch.object(controller, "lock", side_effect=ValueError("Another edit is running")), \
                mock.patch.object(controller, "schedule") as schedule:
            with self.assertRaisesRegex(ValueError, "Another edit"):
                controller.main()
        schedule.assert_not_called()

    def test_cli_rejects_irrelevant_background_or_inherited_flags(self):
        for action, option in (("preview", "--periodic"), ("schedule", "--periodic"), ("menu", "--initial-lock-fd")):
            args = ["cdn-control.py", action, "--config-dir", "/etc/ununknowntun/tunnels/example", option]
            if option == "--initial-lock-fd":
                args += ["9"]
            with self.subTest(action=action), mock.patch.object(sys, "argv", args), contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit) as error:
                controller.main()
            self.assertEqual(error.exception.code, 2)

    def test_manager_preview_reaches_preview_only_controller_action(self):
        # Execute only the embedded manager with every host-facing entry point
        # replaced. This checks real CLI dispatch without executing an installer,
        # touching /etc, starting a service, or making a network request.
        source = Path(__file__).with_name("full-installer.template.sh").read_text()
        manager = source.split("<<'CTL'\n", 1)[1].split("\nCTL\n", 1)[0]
        definitions, dispatch = manager.split('\ncommand_name="${1:-help}"', 1)
        script = definitions + '''
need_root() { :; }
select_id() { printf '%s\\n' example; }
manager_lock() { exit 97; }
python3() { printf '%s\\n' "$@"; }
INSTALL_DIR=/isolated/opt/ununknowntun
TUNNELS_DIR=/etc/ununknowntun/tunnels
set -- cdn-preview example
command_name="${1:-help}"
''' + dispatch
        result = subprocess.run(["bash", "-c", script], capture_output=True,
                                text=True, timeout=5, check=False)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.splitlines(), [
            "/isolated/opt/ununknowntun/share/cdn-control.py", "preview",
            "--config-dir", "/etc/ununknowntun/tunnels/example"])
        with mock.patch.object(sys, "argv", result.stdout.splitlines()), \
                mock.patch.object(controller.os, "geteuid", return_value=0), \
                mock.patch.object(Path, "is_symlink", return_value=False), \
                mock.patch.object(Path, "is_dir", return_value=True), \
                mock.patch.object(Path, "lstat", return_value=SimpleNamespace(st_uid=0, st_mode=0o755)), \
                mock.patch.object(controller.signal, "signal"), \
                mock.patch.object(controller, "scan") as scan:
            controller.main()
        scan.assert_called_once_with(Path("/etc/ununknowntun/tunnels/example"), False, None, preview=True)


class ControllerFixture(unittest.TestCase):
    def setUp(self):
        fixture = safety.EditorSafetyTests(methodName="runTest")
        fixture.setUp()
        self.addCleanup(fixture.doCleanups)
        self.fixture = fixture
        self.directory = fixture.directory
        self.root = fixture.root
        fixture.env.update(FOREIGN_PROXY_PROVIDER="cloudflare")
        fixture.script = fixture.script.replace(
            "-connect 203.0.113.2:443,203.0.113.2:8443",
            "-connect foreign.example:443,foreign.example:8443")
        fixture.script = fixture.script.replace("  -mode origin", " \\\n".join([
            "  -mode origin", "  -transport wss", "  -token-file " + str(self.directory / "token")]))
        fixture.write_fixture()
        self.settings = dict(controller.scanner.DEFAULT_SETTINGS)
        self.settings_path = self.directory / "cdn-endpoints.json"
        self.write_settings()
        self.instance = fixture.make_editor()
        self.profile = self.reload_profile()
        self.report = {
            "changed": True, "selected_endpoint": "104.16.0.1:443",
            "configuration_changed": False, "reason": "Authenticated improvement.",
            "results": [{"endpoint": "104.16.0.1:443", "fully_authenticated": True}],
        }
        self.probe = mock.Mock(return_value={"ok": True, "stage": "authenticated", "reason": "OK"})
        self.stdout = io.StringIO()
        self.stderr = io.StringIO()
        out = contextlib.redirect_stdout(self.stdout)
        err = contextlib.redirect_stderr(self.stderr)
        out.__enter__()
        err.__enter__()
        self.addCleanup(out.__exit__, None, None, None)
        self.addCleanup(err.__exit__, None, None, None)
        # Unexpected subprocess use fails rather than contacting a live service.
        guard = mock.patch.object(subprocess, "run", side_effect=AssertionError("Unmocked process/network operation"))
        guard.start()
        self.addCleanup(guard.stop)

    def write_settings(self):
        self.settings_path.write_text(json.dumps(self.settings))

    def reload_profile(self):
        return controller.scanner.load_profile(self.directory)

    def snapshot(self):
        return {path.name: path.read_bytes() for path in self.directory.iterdir() if path.is_file()}

    def apply(self, **kwargs):
        return controller.apply_candidate(self.instance, self.profile, self.report,
                                          self.reload_profile, probe=self.probe, **kwargs)

    def service_calls(self):
        return [call.args for call in self.instance.run.call_args_list if call.args[0] == "systemctl"]


class GuidedRoundTests(ControllerFixture):
    def setUp(self):
        super().setUp()
        self.instance.state_dir = self.instance.state_dir.resolve()
        self.held = []
        self.process_status = 0
        self.selected_value = "104.16.0.1\n"
        self.probe_phases = []
        stack = contextlib.ExitStack()
        self.addCleanup(stack.close)
        stack.enter_context(mock.patch.object(controller.editor, "Editor", return_value=self.instance))
        self.preflight = stack.enter_context(mock.patch.object(controller.scanner, "preflight_profile", return_value={"local_core_compatible": True}))
        stack.enter_context(mock.patch.object(controller, "trusted_round_helpers"))
        stack.enter_context(mock.patch.object(controller, "lock", side_effect=self.fake_lock))
        self.launch = stack.enter_context(mock.patch.object(controller, "launch_round_console", side_effect=self.fake_console))
        self.authentication = stack.enter_context(mock.patch.object(controller.scanner, "probe_endpoint", side_effect=self.good_probe))

    @contextlib.contextmanager
    def fake_lock(self, path, inherited=None):
        self.held.append(path)
        try:
            yield
        finally:
            self.held.remove(path)

    def fake_console(self, port, sni, selected, reports):
        self.assertEqual(["/run/ununknowntun-cdn-sample.lock"], self.held)
        self.assertFalse(selected.exists())
        self.assertEqual(0o700, selected.parent.stat().st_mode & 0o777)
        selected.write_text(self.selected_value)
        selected.chmod(0o600)
        (reports / "full-round-details.json").write_text('{"fixture":"all IP results retained"}\n')
        self.selected_path, self.reports_path = selected, reports
        return self.process_status

    def good_probe(self, profile, endpoint, timeout):
        self.probe_phases.append(tuple(self.held))
        return {"ok": True, "elapsed_ms": 10, "stage": "authenticated-carrier", "reason": "OK"}

    def last_round_report(self):
        return json.loads((self.directory / "cdn-rounds-last-report.json").read_text())

    def test_inherits_port_sni_then_authenticates_and_applies_under_final_lock(self):
        self.settings["minimum_improvement_percent"] = 95
        self.write_settings()
        before_settings = self.settings_path.read_bytes()
        self.assertEqual(0, controller.rounds(self.directory))
        self.preflight.assert_called_once()
        self.assertEqual((443, "foreign.example"), self.launch.call_args.args[:2])
        self.assertEqual(3, self.authentication.call_count)  # two configured samples plus post-change check
        self.assertEqual([6, 6, 20], [call.args[2] for call in self.authentication.call_args_list])
        self.assertEqual([("/run/ununknowntun-cdn-sample.lock",)] * 2, self.probe_phases[:2])
        self.assertEqual(("/run/ununknowntun-cdn-sample.lock", "/run/ununknowntun-installer.lock"), self.probe_phases[-1])
        self.assertEqual("104.16.0.1:443", self.reload_profile()["current_endpoint"])
        self.assertEqual(self.settings_path.read_bytes(), before_settings)
        self.assertEqual([], self.service_calls())  # stopped tunnel stays stopped
        self.assertFalse(self.selected_path.exists())
        self.assertTrue((self.reports_path / "full-round-details.json").exists())
        self.assertEqual(0o600, (self.reports_path / "controller-result.json").stat().st_mode & 0o777)
        report = self.last_round_report()
        self.assertTrue(report["configuration_changed"])
        self.assertTrue(report["improvement_threshold_bypassed"])
        self.assertFalse(report["automatic_policy_changed"])
        self.assertEqual([], self.held)

    def test_cancel_error_and_no_selection_never_authenticate_or_apply(self):
        original = (self.directory / "run.sh").read_bytes()
        for status in (130, -2, 2, 1):
            self.process_status = status
            self.assertIn(controller.rounds(self.directory), (130, 2, 1))
            self.assertEqual(original, (self.directory / "run.sh").read_bytes())
            self.assertFalse(self.last_round_report()["configuration_changed"])
        self.authentication.assert_not_called()
        self.assertEqual([], self.service_calls())

    def test_rejects_non_cloudflare_port_injection_and_multiple_ips(self):
        original = (self.directory / "run.sh").read_bytes()
        for candidate in ("8.8.8.8\n", "104.16.0.1:8443\n", "104.16.0.1\n104.16.0.2\n", "104.16.0.1", "104.16.0.1\n\n"):
            self.selected_value = candidate
            with self.subTest(candidate=candidate), self.assertRaises(ValueError):
                controller.rounds(self.directory)
            self.assertEqual(original, (self.directory / "run.sh").read_bytes())
        self.authentication.assert_not_called()

    def test_rejects_nonprivate_selected_file(self):
        def unprotected(*args):
            self.fake_console(*args)
            args[2].chmod(0o644)
            return 0
        self.launch.side_effect = unprotected
        with self.assertRaisesRegex(ValueError, "Secret input"):
            controller.rounds(self.directory)
        self.authentication.assert_not_called()

    def test_revision_change_during_interaction_blocks_even_authentication(self):
        def changed(*args):
            self.settings["interval_hours"] = 9
            self.write_settings()
            return self.fake_console(*args)
        self.launch.side_effect = changed
        with self.assertRaisesRegex(ValueError, "changed during scanning"):
            controller.rounds(self.directory)
        self.authentication.assert_not_called()
        self.assertEqual([], self.service_calls())

    def test_revision_change_during_authentication_blocks_transaction(self):
        original = (self.directory / "run.sh").read_bytes()
        def changed(*args):
            self.settings["interval_hours"] = 9
            self.write_settings()
            return self.good_probe(*args)
        self.authentication.side_effect = changed
        with self.assertRaisesRegex(ValueError, "changed during scanning"):
            controller.rounds(self.directory)
        self.assertEqual(2, self.authentication.call_count)
        self.assertEqual(original, (self.directory / "run.sh").read_bytes())
        self.assertEqual([], self.service_calls())

    def test_every_configured_authentication_sample_must_pass(self):
        self.authentication.side_effect = [{"ok": True, "elapsed_ms": 10}, {"ok": False, "elapsed_ms": 20, "stage": "authentication", "reason": "token rejected"}]
        original = (self.directory / "run.sh").read_bytes()
        self.assertEqual(1, controller.rounds(self.directory))
        self.assertEqual(original, (self.directory / "run.sh").read_bytes())
        self.assertEqual(2, self.authentication.call_count)
        self.assertFalse(self.last_round_report()["results"][0]["fully_authenticated"])

    def test_late_or_invalid_latency_is_never_authenticated(self):
        for latency in (6000.01, float("nan"), float("inf"), -1, True, None):
            with self.subTest(latency=latency):
                self.authentication.return_value = {"ok": True, "elapsed_ms": latency}
                self.authentication.side_effect = None
                self.assertEqual(1, controller.rounds(self.directory))
                self.assertFalse(self.last_round_report()["configuration_changed"])
        self.assertEqual([], self.service_calls())

    def test_post_change_authentication_failure_rolls_back(self):
        self.instance.active.return_value = True
        original = (self.directory / "run.sh").read_bytes()
        self.authentication.side_effect = [{"ok": True, "elapsed_ms": 10}, {"ok": True, "elapsed_ms": 12}, {"ok": False, "stage": "tls", "reason": "failed"}]
        with self.assertRaisesRegex(RuntimeError, "Post-change tls"):
            controller.rounds(self.directory)
        self.assertEqual(original, (self.directory / "run.sh").read_bytes())
        self.assertEqual([("systemctl", "restart", self.instance.service)] * 2, self.service_calls())
        self.assertFalse(self.last_round_report()["configuration_changed"])

    def test_interruption_during_authentication_retains_endpoint(self):
        original = (self.directory / "run.sh").read_bytes()
        self.authentication.side_effect = KeyboardInterrupt()
        with self.assertRaises(KeyboardInterrupt): controller.rounds(self.directory)
        self.assertEqual(original, (self.directory / "run.sh").read_bytes())
        self.assertTrue(self.last_round_report()["cancelled"])
        self.assertEqual([], self.service_calls())

    def test_eligibility_and_local_core_preflight_precede_interaction(self):
        for changes in ({"provider": "none"}, {"current_endpoint": "foreign.example:1234"},
                        {"flags": dict(self.profile["flags"], transport="icmp")},
                        {"flags": dict(self.profile["flags"], **{"spoof-config": "/private"})},
                        {"flags": dict(self.profile["flags"], sni="")}):
            with mock.patch.object(controller.scanner, "load_profile", return_value=dict(self.profile, **changes)), self.assertRaises(ValueError):
                controller.rounds(self.directory)
        self.launch.assert_not_called()
        self.preflight.assert_not_called()
        self.preflight.side_effect = ValueError("installed core missing capability")
        with self.assertRaisesRegex(ValueError, "missing capability"):
            controller.rounds(self.directory)
        self.launch.assert_not_called()


class GuidedLauncherTests(unittest.TestCase):
    def test_interactive_child_inherits_terminal_no_global_timeout_and_restores_interrupt(self):
        console = Path("/opt/ununknowntun/share/scanner-console.py")
        original = controller.signal.getsignal(controller.signal.SIGINT)
        with mock.patch.object(controller, "trusted_round_helpers", return_value=console), mock.patch.object(controller.subprocess, "run", return_value=SimpleNamespace(returncode=130)) as process, mock.patch.dict(os.environ, {"PYTHONPATH": "/untrusted", "UNUNKNOWNTUN_TOKEN": "secret"}):
            self.assertEqual(130, controller.launch_round_console(8443, "tunnel.example", Path("/private/new"), Path("/private/reports")))
        self.assertEqual(original, controller.signal.getsignal(controller.signal.SIGINT))
        argv, options = process.call_args.args[0], process.call_args.kwargs
        self.assertEqual([controller.sys.executable, "-I", str(console), "rounds"], argv[:4])
        self.assertEqual("8443", argv[argv.index("--port") + 1])
        self.assertEqual("tunnel.example", argv[argv.index("--sni") + 1])
        for forbidden in ("timeout", "capture_output", "stdin", "stdout", "stderr", "shell"):
            self.assertNotIn(forbidden, options)
        self.assertNotIn("PYTHONPATH", options["env"])
        self.assertNotIn("UNUNKNOWNTUN_TOKEN", options["env"])


class CandidateTransactionTests(ControllerFixture):
    def test_local_scan_error_blocks_apply_even_with_an_earlier_good_candidate(self):
        self.report["local_error"] = True
        with mock.patch.object(self.instance, "plan") as plan, self.assertRaisesRegex(ValueError, "local core/configuration"):
            self.apply()
        plan.assert_not_called()
        self.probe.assert_not_called()

    def test_nonboolean_authenticated_flag_cannot_authorize_apply(self):
        self.report["results"][0]["fully_authenticated"] = "yes"
        with self.assertRaisesRegex(ValueError, "authentication result"):
            self.apply()
        self.probe.assert_not_called()

    def test_cancel_during_post_change_probe_restores_selected_files_and_service(self):
        before = self.snapshot()
        self.instance.active.return_value = True
        self.probe.side_effect = KeyboardInterrupt()
        with self.assertRaises(KeyboardInterrupt):
            self.apply()
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.service_calls(), [("systemctl", "restart", self.instance.service)] * 2)
        self.assertEqual((self.fixture.state / "access-state.json").read_text(), "live-use-must-never-be-restored")

    def test_stale_run_settings_or_token_reject_before_plan(self):
        for filename in ("run.sh", "cdn-endpoints.json", "token", "deployment.env"):
            with self.subTest(filename=filename):
                path = self.directory / filename
                before = path.read_bytes()
                if filename == "cdn-endpoints.json":
                    path.write_text(json.dumps(dict(self.settings, interval_hours=9)))
                elif filename == "token":
                    path.write_text("b" * 64 + "\n")
                elif filename == "deployment.env":
                    path.write_bytes(before + b"\nTUNNEL_NAME=Changed\n")
                else:
                    path.write_bytes(before.replace(b"-stats 5s", b"-stats 10s"))
                changed = self.snapshot()
                with mock.patch.object(self.instance, "plan", wraps=self.instance.plan) as plan:
                    with self.assertRaisesRegex(ValueError, "changed during scanning"):
                        self.apply()
                    plan.assert_not_called()
                self.assertEqual(self.snapshot(), changed)
                path.write_bytes(before)
        self.probe.assert_not_called()
        self.assertFalse(self.instance.run.called)

    def test_no_improvement_keeps_all_files_and_service_untouched(self):
        before = self.snapshot()
        self.report["changed"] = False
        self.assertFalse(self.apply())
        self.assertEqual(self.snapshot(), before)
        self.probe.assert_not_called()
        self.assertFalse(self.instance.run.called)

    def test_unchanged_report_still_requires_fresh_revision(self):
        self.report["changed"] = False
        self.settings["interval_hours"] = 11
        self.write_settings()
        with self.assertRaisesRegex(ValueError, "changed during scanning"):
            self.apply()

    def test_selection_must_be_authenticated_cloudflare_same_port(self):
        cases = [
            ("104.16.0.1:8443", True, "paired HTTPS port"),
            ("104.16.0.1:443", False, "authentication result"),
            ("203.0.113.7:443", True, "Cloudflare"),
        ]
        before = self.snapshot()
        for endpoint, authenticated, message in cases:
            with self.subTest(endpoint=endpoint, authenticated=authenticated):
                self.report.update(selected_endpoint=endpoint, results=[{
                    "endpoint": endpoint, "fully_authenticated": authenticated}])
                with self.assertRaisesRegex(ValueError, message):
                    self.apply()
                self.assertEqual(self.snapshot(), before)
        self.probe.assert_not_called()
        self.assertFalse(self.instance.run.called)

    def test_missing_selected_result_refused(self):
        self.report["results"] = []
        with self.assertRaisesRegex(ValueError, "authentication result"):
            self.apply()
        self.assertFalse(self.instance.run.called)

    def test_manual_update_of_stopped_tunnel_never_starts_service(self):
        accounts = (self.directory / "access.json").read_bytes()
        token = (self.directory / "token").read_bytes()
        settings = self.settings_path.read_bytes()
        self.assertTrue(self.apply())
        updated = self.reload_profile()
        self.assertEqual(updated["current_endpoint"], "104.16.0.1:443")
        self.assertEqual(updated["flags"]["connect"], "104.16.0.1:443,104.16.0.1:8443")
        self.assertEqual(updated["flags"]["ws-host"], "foreign.example")
        self.assertEqual(updated["flags"]["sni"], "foreign.example")
        self.assertEqual(controller.scanner.parse_env((self.directory / "deployment.env").read_text())["FOREIGN_PORTS"], "443,8443")
        self.assertEqual(self.service_calls(), [])
        self.probe.assert_called_once()
        self.assertEqual(self.probe.call_args.args[1:], ("104.16.0.1:443", 20))
        self.assertEqual((self.directory / "access.json").read_bytes(), accounts)
        self.assertEqual((self.directory / "token").read_bytes(), token)
        self.assertEqual(self.settings_path.read_bytes(), settings)
        self.assertEqual((self.fixture.state / "access-state.json").read_text(), "live-use-must-never-be-restored")
        self.assertIn("stopped and remains stopped", self.stdout.getvalue())

    def test_post_authentication_failure_restores_files_and_active_service(self):
        before = self.snapshot()
        self.instance.active.return_value = True
        self.probe.return_value = {"ok": False, "stage": "TLS", "reason": "Certificate mismatch"}
        with self.assertRaisesRegex(RuntimeError, "Post-change TLS check failed"):
            self.apply()
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.service_calls(), [("systemctl", "restart", self.instance.service)] * 2)
        self.assertEqual(self.instance.wait_service.call_count, 2)
        self.assertEqual((self.fixture.state / "access-state.json").read_text(), "live-use-must-never-be-restored")
        self.assertNotIn("a" * 64, self.stdout.getvalue() + self.stderr.getvalue())

    def test_post_probe_exception_also_rolls_back_stopped_tunnel(self):
        before = self.snapshot()
        self.probe.side_effect = OSError("Mocked probe unavailable")
        with self.assertRaisesRegex(OSError, "Mocked probe"):
            self.apply()
        self.assertEqual(self.snapshot(), before)
        self.assertEqual(self.service_calls(), [])

    def test_background_flag_uses_try_restart_only(self):
        self.instance.active.return_value = True
        with mock.patch.object(self.instance, "commit", wraps=self.instance.commit) as commit:
            self.assertTrue(self.apply(background=True))
        self.assertIs(commit.call_args.args[0]["background"], True)
        self.assertEqual(self.service_calls(), [("systemctl", "try-restart", self.instance.service)])

    def test_background_update_rejects_service_already_stopped(self):
        before = self.snapshot()
        with self.assertRaisesRegex(RuntimeError, "tunnel is stopped"):
            self.apply(background=True)
        self.assertEqual(self.snapshot(), before)
        self.probe.assert_not_called()
        self.assertEqual(self.service_calls(), [])

    def test_stop_race_during_background_update_never_reactivates_service(self):
        before = self.snapshot()
        self.instance.active.side_effect = [True, False, False]
        with self.assertRaisesRegex(RuntimeError, "stopped during the background update"):
            self.apply(background=True)
        self.assertEqual(self.snapshot(), before)
        self.probe.assert_not_called()
        self.assertEqual(self.service_calls(), [("systemctl", "try-restart", self.instance.service)] * 2)
        self.instance.wait_service.assert_not_called()


class ScanDispatchTests(ControllerFixture):
    def test_scan_cancellation_leaves_service_endpoint_and_report_untouched(self):
        _, scan, apply = self.scan_patches()
        before = self.snapshot()
        scan.side_effect = KeyboardInterrupt()
        with self.assertRaises(KeyboardInterrupt):
            controller.scan(self.directory)
        apply.assert_not_called()
        self.assertEqual(self.snapshot(), before)
        self.assertFalse(self.instance.run.called)

    def scan_patches(self):
        stack = contextlib.ExitStack()
        self.addCleanup(stack.close)
        stack.enter_context(mock.patch.object(controller.editor, "Editor", return_value=self.instance))
        # All lock files are temporary stand-ins; scan never opens /run here.
        lock_mock = stack.enter_context(mock.patch.object(controller, "lock", side_effect=lambda *_: contextlib.nullcontext()))
        scan_mock = stack.enter_context(mock.patch.object(controller.scanner, "scan_profile", return_value=copy.deepcopy(self.report)))
        apply_mock = stack.enter_context(mock.patch.object(controller, "apply_candidate", return_value=True))
        return lock_mock, scan_mock, apply_mock

    def test_periodic_disabled_skips_without_probes_or_report(self):
        self.instance.active.return_value = True
        _, scan, apply = self.scan_patches()
        before = self.snapshot()
        controller.scan(self.directory, periodic=True)
        scan.assert_not_called()
        apply.assert_not_called()
        self.assertEqual(self.snapshot(), before)

    def test_periodic_stopped_skips_without_probes_or_report(self):
        self.settings["enabled"] = True
        self.write_settings()
        _, scan, apply = self.scan_patches()
        before = self.snapshot()
        controller.scan(self.directory, periodic=True)
        scan.assert_not_called()
        apply.assert_not_called()
        self.assertEqual(self.snapshot(), before)

    def test_periodic_stop_during_scan_discards_candidate_before_apply(self):
        self.settings["enabled"] = True
        self.write_settings()
        self.instance.active.side_effect = [True, False]
        _, scan, apply = self.scan_patches()
        with self.assertRaisesRegex(ValueError, "stopped during scan"):
            controller.scan(self.directory, periodic=True)
        scan.assert_called_once()
        apply.assert_not_called()
        self.assertFalse((self.directory / "cdn-last-report.json").exists())

    def test_periodic_dispatch_passes_background_and_saves_private_report(self):
        self.settings["enabled"] = True
        self.write_settings()
        self.instance.active.return_value = True
        locks, scan, apply = self.scan_patches()
        controller.scan(self.directory, periodic=True)
        scan.assert_called_once()
        self.assertIs(apply.call_args.kwargs["background"], True)
        self.assertEqual(locks.call_args_list[-1].args, ("/run/ununknowntun-installer.lock", None))
        report = self.directory / "cdn-last-report.json"
        self.assertEqual(report.stat().st_mode & 0o777, 0o600)
        saved = json.loads(report.read_text())
        self.assertTrue(saved["configuration_changed"])
        self.assertEqual(saved["verdict"], "authenticated-replacement-applied")

    def test_manual_scan_allowed_with_periodic_disabled(self):
        _, scan, apply = self.scan_patches()
        controller.scan(self.directory)
        scan.assert_called_once()
        self.assertIs(apply.call_args.kwargs["background"], False)

    def test_preview_never_plans_or_applies_and_saves_private_proposal(self):
        _, scan, apply = self.scan_patches()
        launcher = (self.directory / "run.sh").read_bytes()
        controller.scan(self.directory, preview=True)
        scan.assert_called_once()
        self.assertIn("progress", scan.call_args.kwargs)
        apply.assert_not_called()
        self.assertFalse(self.instance.run.called)
        self.assertEqual((self.directory / "run.sh").read_bytes(), launcher)
        report = json.loads((self.directory / "cdn-last-report.json").read_text())
        self.assertTrue(report["preview_only"])
        self.assertFalse(report["configuration_changed"])
        self.assertIn("Preview only", self.stdout.getvalue())

    def test_preview_cannot_be_periodic_or_initial_apply(self):
        _, scan, apply = self.scan_patches()
        for changes in ({"periodic": True}, {"inherited": 9}):
            with self.subTest(changes=changes), self.assertRaisesRegex(ValueError, "Preview is a manual"):
                controller.scan(self.directory, preview=True, **changes)
        scan.assert_not_called()
        apply.assert_not_called()

    def test_preview_stale_revision_is_discarded_without_apply(self):
        _, scan, apply = self.scan_patches()
        def changed(*args, **kwargs):
            self.settings["interval_hours"] = 11
            self.write_settings()
            return copy.deepcopy(self.report)
        scan.side_effect = changed
        with self.assertRaisesRegex(ValueError, "changed during scanning"):
            controller.scan(self.directory, preview=True)
        apply.assert_not_called()
        self.assertFalse((self.directory / "cdn-last-report.json").exists())

    def test_initial_setup_scan_requires_new_service_stopped(self):
        self.instance.active.return_value = True
        _, scan, apply = self.scan_patches()
        with self.assertRaisesRegex(ValueError, "requires a stopped"):
            controller.scan(self.directory, inherited=9)
        scan.assert_not_called()
        apply.assert_not_called()

    def test_initial_setup_passes_inherited_lock_to_commit_boundary(self):
        locks, scan, apply = self.scan_patches()
        controller.scan(self.directory, inherited=9)
        scan.assert_called_once()
        self.assertEqual(locks.call_args_list[-1].args, ("/run/ununknowntun-installer.lock", 9))
        self.assertIs(apply.call_args.kwargs["background"], False)


class VerifyTests(ControllerFixture):
    def test_verify_without_scanner_settings_uses_actual_managed_carrier(self):
        self.settings_path.unlink()
        self.fixture.env["FOREIGN_PROXY_PROVIDER"] = "arvan"
        self.fixture.script = self.fixture.script.replace("-transport wss", "-transport xhttp")
        self.fixture.write_fixture()
        with mock.patch.object(controller.scanner, "probe_endpoint", self.probe):
            controller.verify(self.directory)
        self.probe.assert_called_once()
        profile, endpoint, timeout = self.probe.call_args.args
        self.assertEqual(profile["provider"], "arvan")
        self.assertEqual(profile["flags"]["transport"], "xhttp")
        self.assertEqual(profile["flags"]["sni"], "foreign.example")
        self.assertEqual(profile["token_file"], str(self.directory / "token"))
        self.assertEqual(endpoint, "foreign.example:443")
        self.assertEqual(timeout, 20)
        self.assertIn("Target payload was not tested", self.stdout.getvalue())
        self.assertNotIn(self.fixture.token, self.stdout.getvalue())

    def test_verify_rejects_egress_or_mismatched_launcher_role(self):
        for change_env in (True, False):
            with self.subTest(change_env=change_env):
                self.fixture.env["ROLE"] = "egress" if change_env else "origin"
                self.fixture.write_fixture()
                if not change_env:
                    path = self.directory / "run.sh"
                    path.write_text(path.read_text().replace("-mode origin", "-mode egress"))
                with self.assertRaisesRegex(ValueError, "connection-initiating origin"):
                    controller.profile_for_verify(self.directory)

    def test_verify_rejects_inline_or_unrelated_token_and_gre(self):
        script = (self.directory / "run.sh").read_text()
        cases = [
            script.replace(str(self.directory / "token"), str(self.root / "other-token")),
            script + " -token inline-test-value-should-never-be-used\n",
            script + " -spoof-config /private/spoof.json\n",
        ]
        for candidate in cases:
            with self.subTest(candidate=candidate[-55:]):
                (self.directory / "run.sh").write_text(candidate)
                with self.assertRaisesRegex(ValueError, "managed tunnel token"):
                    controller.profile_for_verify(self.directory)

    def test_verify_probe_failure_does_not_print_success_or_modify_files(self):
        before = self.snapshot()
        self.probe.return_value = {"ok": False, "stage": "timeout", "reason": "Carrier deadline elapsed"}
        with mock.patch.object(controller.scanner, "probe_endpoint", self.probe):
            with self.assertRaisesRegex(RuntimeError, "timeout: Carrier deadline elapsed"):
                controller.verify(self.directory)
        self.assertEqual(self.snapshot(), before)
        self.assertNotIn("[PASS]", self.stdout.getvalue())
        self.assertFalse(self.instance.run.called)


class SchedulerTests(ControllerFixture):
    def test_enable_timer_refuses_wrong_role_provider_and_carrier_before_changes(self):
        for changes in ({"ROLE": "egress"}, {"FOREIGN_PROXY_PROVIDER": "fastly"}, {"FOREIGN_PROXY_PROVIDER": "none"}):
            original = dict(self.fixture.env)
            self.fixture.env.update(changes)
            self.fixture.write_fixture()
            runner = self.runner()
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                controller.schedule(self.directory, unit_dir=self.unit_dir, runner=runner)
            runner.assert_not_called()
            self.assertEqual(list(self.unit_dir.iterdir()), [])
            self.fixture.env = original
        self.fixture.write_fixture()
        path = self.directory / "run.sh"
        path.write_text(path.read_text().replace("-transport wss", "-transport tls"))
        runner = self.runner()
        with self.assertRaisesRegex(ValueError, "WSS/XHTTP"):
            controller.schedule(self.directory, unit_dir=self.unit_dir, runner=runner)
        runner.assert_not_called()

    def test_recovery_timeout_attempts_remaining_steps_and_does_not_reenable_timer(self):
        before = self.install_previous_units()
        base = self.runner(enabled=True, active=True)
        def operation(*args, **kwargs):
            if args == ("systemctl", "restart", self.timer.name):
                raise subprocess.CalledProcessError(1, args)
            if args == ("systemctl", "stop", self.timer.name):
                raise subprocess.TimeoutExpired(args, 45)
            return base(*args, **kwargs)
        runner = mock.Mock(side_effect=operation)
        with self.assertRaisesRegex(RuntimeError, "recovery was incomplete"):
            controller.schedule(self.directory, unit_dir=self.unit_dir, runner=runner)
        self.assertEqual((self.service.read_bytes(), self.timer.read_bytes()), before)
        runner.assert_any_call("systemctl", "daemon-reload")
        runner.assert_any_call("systemctl", "disable", "--now", self.timer.name)
        self.assertNotIn(mock.call("systemctl", "start", self.timer.name, check=False), runner.call_args_list)

    def test_nonzero_recovery_status_is_not_reported_as_restored(self):
        self.install_previous_units()
        base = self.runner(enabled=True, active=True)
        def operation(*args, **kwargs):
            if args == ("systemctl", "restart", self.timer.name):
                raise subprocess.CalledProcessError(1, args)
            if args == ("systemctl", "enable", self.timer.name) and not kwargs.get("check", True):
                return subprocess.CompletedProcess(args, 1, "", "")
            return base(*args, **kwargs)
        runner = mock.Mock(side_effect=operation)
        with self.assertRaisesRegex(RuntimeError, "restore persistent enable"):
            controller.schedule(self.directory, unit_dir=self.unit_dir, runner=runner)
        runner.assert_any_call("systemctl", "disable", "--now", self.timer.name)
        self.assertNotIn(mock.call("systemctl", "start", self.timer.name, check=False), runner.call_args_list)

    def test_cancellation_rolls_back_timer_units_and_state(self):
        before = self.install_previous_units()
        base = self.runner(enabled=True, active=True)
        def operation(*args, **kwargs):
            if args == ("systemctl", "restart", self.timer.name):
                raise KeyboardInterrupt()
            return base(*args, **kwargs)
        runner = mock.Mock(side_effect=operation)
        with self.assertRaises(KeyboardInterrupt):
            controller.schedule(self.directory, unit_dir=self.unit_dir, runner=runner)
        self.assertEqual((self.service.read_bytes(), self.timer.read_bytes()), before)
        runner.assert_any_call("systemctl", "start", self.timer.name, check=False)

    def setUp(self):
        super().setUp()
        self.unit_dir = self.root / "systemd"
        self.unit_dir.mkdir()
        self.service = self.unit_dir / "ununknowntun-cdn-sample.service"
        self.timer = self.unit_dir / "ununknowntun-cdn-sample.timer"
        self.settings.update(enabled=True)
        self.write_settings()

    def runner(self, enabled=False, active=False, fail=None):
        def result(*args, **kwargs):
            if fail is not None and args == fail and kwargs.get("check", True):
                raise subprocess.CalledProcessError(1, args)
            status = 0
            if args[1] == "is-enabled": status = 0 if enabled else 1
            if args[1] == "is-active": status = 0 if active else 3
            output = ((enabled if isinstance(enabled, str) else "enabled") if enabled else "disabled") + "\n" if args[1] == "is-enabled" else ""
            return subprocess.CompletedProcess(args, status, output, "")
        return mock.Mock(side_effect=result)

    def install_previous_units(self):
        self.service.write_text(controller.MARKER + "previous service\n")
        self.timer.write_text(controller.MARKER + "previous timer\n")
        return self.service.read_bytes(), self.timer.read_bytes()

    def test_enable_only_selected_timer_with_valid_interval(self):
        self.settings["interval_hours"] = 7
        self.write_settings()
        runner = self.runner()
        controller.schedule(self.directory, unit_dir=self.unit_dir, runner=runner)
        self.assertIn("OnUnitInactiveSec=7h", self.timer.read_text())
        self.assertIn("Persistent=false", self.timer.read_text())
        self.assertIn("scan --periodic --config-dir /etc/ununknowntun/tunnels/sample", self.service.read_text())
        self.assertEqual(self.service.stat().st_mode & 0o777, 0o644)
        runner.assert_any_call("systemctl", "enable", self.timer.name)
        runner.assert_any_call("systemctl", "restart", self.timer.name)
        self.assertFalse(any(call.args[-1] == self.service.name and call.args[1] in ("start", "restart") for call in runner.call_args_list))

    def test_enable_failure_restores_existing_units_and_timer_state(self):
        before = self.install_previous_units()
        runner = self.runner(enabled=True, active=True, fail=("systemctl", "restart", self.timer.name))
        with self.assertRaises(subprocess.CalledProcessError):
            controller.schedule(self.directory, unit_dir=self.unit_dir, runner=runner)
        self.assertEqual((self.service.read_bytes(), self.timer.read_bytes()), before)
        runner.assert_any_call("systemctl", "enable", self.timer.name, check=False)
        runner.assert_any_call("systemctl", "start", self.timer.name, check=False)

    def test_new_schedule_failure_removes_only_new_owned_units(self):
        unrelated = self.unit_dir / "unrelated.service"
        unrelated.write_text("untouched")
        runner = self.runner(fail=("systemctl", "enable", self.timer.name))
        with self.assertRaises(subprocess.CalledProcessError):
            controller.schedule(self.directory, unit_dir=self.unit_dir, runner=runner)
        self.assertFalse(self.service.exists())
        self.assertFalse(self.timer.exists())
        self.assertEqual(unrelated.read_text(), "untouched")
        runner.assert_any_call("systemctl", "disable", self.timer.name)
        runner.assert_any_call("systemctl", "stop", self.timer.name, check=False)

    def test_failed_update_restores_runtime_enable_without_persistent_link(self):
        before = self.install_previous_units()
        runner = self.runner(enabled="enabled-runtime", active=True, fail=("systemctl", "restart", self.timer.name))
        with self.assertRaises(subprocess.CalledProcessError):
            controller.schedule(self.directory, unit_dir=self.unit_dir, runner=runner)
        self.assertEqual((self.service.read_bytes(), self.timer.read_bytes()), before)
        cleared = mock.call("systemctl", "disable", self.timer.name)
        restored = mock.call("systemctl", "enable", "--runtime", self.timer.name, check=False)
        self.assertLess(runner.call_args_list.index(cleared), runner.call_args_list.index(restored))
        self.assertNotIn(mock.call("systemctl", "enable", self.timer.name, check=False), runner.call_args_list)

    def test_unmanaged_enable_states_fail_before_any_mutation(self):
        before = self.install_previous_units()
        for state in ("masked", "static", "linked", "linked-runtime", "unexpected"):
            with self.subTest(state=state):
                runner = self.runner(enabled=state)
                with self.assertRaisesRegex(ValueError, "Unmanaged scheduler enable state"):
                    controller.schedule(self.directory, unit_dir=self.unit_dir, runner=runner)
                self.assertEqual((self.service.read_bytes(), self.timer.read_bytes()), before)
                self.assertEqual([call.args[1] for call in runner.call_args_list], ["is-enabled"])

    def test_disable_failure_rolls_back_timer_enable_and_active_state(self):
        before = self.install_previous_units()
        runner = self.runner(enabled=True, active=True, fail=("systemctl", "stop", self.service.name))
        with self.assertRaises(subprocess.CalledProcessError):
            controller.schedule(self.directory, disable=True, unit_dir=self.unit_dir, runner=runner)
        self.assertEqual((self.service.read_bytes(), self.timer.read_bytes()), before)
        runner.assert_any_call("systemctl", "disable", "--now", self.timer.name)
        runner.assert_any_call("systemctl", "enable", self.timer.name, check=False)
        runner.assert_any_call("systemctl", "start", self.timer.name, check=False)

    def test_disable_succeeds_without_settings_and_keeps_owned_files(self):
        before = self.install_previous_units()
        self.settings_path.unlink()
        runner = self.runner(enabled=True, active=True)
        controller.schedule(self.directory, disable=True, unit_dir=self.unit_dir, runner=runner)
        self.assertEqual((self.service.read_bytes(), self.timer.read_bytes()), before)
        runner.assert_any_call("systemctl", "disable", "--now", self.timer.name)
        runner.assert_any_call("systemctl", "stop", self.service.name)

    def test_disabled_default_creates_no_units_and_starts_nothing(self):
        self.settings["enabled"] = False
        self.write_settings()
        runner = self.runner()
        controller.schedule(self.directory, unit_dir=self.unit_dir, runner=runner)
        self.assertEqual(list(self.unit_dir.iterdir()), [])
        self.assertEqual([call.args[1] for call in runner.call_args_list], ["is-enabled", "is-active"])

    def test_unowned_units_rejected_before_systemd_changes(self):
        for path in (self.service, self.timer):
            with self.subTest(path=path.name):
                path.write_text("# Owned by someone else\n")
                runner = self.runner()
                with self.assertRaisesRegex(ValueError, "Unrelated scheduler file"):
                    controller.schedule(self.directory, unit_dir=self.unit_dir, runner=runner)
                runner.assert_not_called()
                self.assertEqual(path.read_text(), "# Owned by someone else\n")
                path.unlink()

    def test_symlink_units_rejected_even_when_target_has_owned_marker(self):
        target = self.root / "do-not-change"
        target.write_text(controller.MARKER + "not selected unit\n")
        for path in (self.service, self.timer):
            with self.subTest(path=path.name):
                path.symlink_to(target)
                runner = self.runner()
                with self.assertRaisesRegex(ValueError, "Unrelated scheduler file"):
                    controller.schedule(self.directory, unit_dir=self.unit_dir, runner=runner)
                runner.assert_not_called()
                self.assertTrue(path.is_symlink())
                self.assertEqual(target.read_text(), controller.MARKER + "not selected unit\n")
                path.unlink()

    def test_unit_ids_reject_injection_and_escape(self):
        for value in ("../sample", "sample/other", "sample;id", "sample\nExecStart=oops", "--sample", "sample--x", "Sample", "x" * 49):
            with self.subTest(value=value), self.assertRaises(ValueError):
                controller.unit_texts(value, self.settings)

    def test_menu_failed_schedule_restores_previous_settings(self):
        before = self.settings_path.read_bytes()
        with mock.patch("builtins.input", side_effect=["60", "", "", "", "", "", "", "n"]), \
                mock.patch.object(controller, "schedule", side_effect=RuntimeError("Mock schedule failure")):
            with self.assertRaisesRegex(RuntimeError, "Mock schedule failure"):
                controller.menu(self.directory)
        self.assertEqual(self.settings_path.read_bytes(), before)

    def test_menu_failed_initial_schedule_leaves_no_new_settings(self):
        self.settings_path.unlink()
        with mock.patch("builtins.input", side_effect=[""] * 7 + ["y"]), \
                mock.patch.object(controller, "schedule", side_effect=RuntimeError("Mock schedule failure")):
            with self.assertRaises(RuntimeError):
                controller.menu(self.directory)
        self.assertFalse(self.settings_path.exists())


class LockTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="ununknowntun-cdn-lock-tests-")
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "installer.lock"
        self.path.touch()

    @contextlib.contextmanager
    def inherited(self):
        # Borrow descriptor 9 in this test process only, preserving its previous
        # open-file description when the test runner already uses it.
        try:
            saved = os.dup(9)
        except OSError:
            saved = None
        handle = os.open(str(self.path), os.O_RDWR)
        try:
            if handle != 9:
                os.dup2(handle, 9)
                os.close(handle)
            fcntl.flock(9, fcntl.LOCK_EX | fcntl.LOCK_NB)
            yield
        finally:
            if saved is None:
                os.close(9)
            else:
                os.dup2(saved, 9)
                os.close(saved)

    def assert_locked(self):
        with self.path.open("a") as other:
            with self.assertRaises(BlockingIOError):
                fcntl.flock(other, fcntl.LOCK_EX | fcntl.LOCK_NB)

    def test_inherited_lock_remains_owned_after_success(self):
        with self.inherited():
            with controller.lock(self.path, inherited=9):
                self.assert_locked()
            self.assert_locked()
            self.assertEqual(os.fstat(9).st_ino, self.path.stat().st_ino)

    def test_inherited_lock_remains_owned_after_failure(self):
        with self.inherited():
            with self.assertRaisesRegex(RuntimeError, "test abort"):
                with controller.lock(self.path, inherited=9):
                    raise RuntimeError("test abort")
            self.assert_locked()

    def test_wrong_inherited_path_or_descriptor_rejected(self):
        other = self.path.with_name("unrelated.lock")
        other.touch()
        with self.inherited():
            with self.assertRaisesRegex(ValueError, "Invalid inherited"):
                with controller.lock(other, inherited=9):
                    self.fail("Wrong lock accepted")
            with self.assertRaisesRegex(ValueError, "Invalid inherited"):
                with controller.lock(self.path, inherited=8):
                    self.fail("Wrong descriptor accepted")
            self.assert_locked()

    def test_regular_lock_blocks_competing_owner_and_releases_after_context(self):
        with controller.lock(self.path):
            with self.assertRaisesRegex(ValueError, "Another scan or edit"):
                with controller.lock(self.path):
                    self.fail("Concurrent edit accepted")
        with controller.lock(self.path):
            self.assert_locked()


if __name__ == "__main__":
    unittest.main(verbosity=2)
