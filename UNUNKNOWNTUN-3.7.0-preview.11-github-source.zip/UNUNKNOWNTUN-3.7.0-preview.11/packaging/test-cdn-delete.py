#!/usr/bin/env python3
"""Delete/scheduler rollback regressions. All paths and service states are fake."""
import importlib.util
from pathlib import Path
import shlex
import unittest


spec = importlib.util.spec_from_file_location("cdn_delete_fixture", Path(__file__).with_name("test-manager.py"))
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)


class CDNDeleteTests(unittest.TestCase):
    def setUp(self):
        self.fx = fixture.ManagerTests(methodName="runTest")
        self.fx.setUp()
        self.addCleanup(self.fx.doCleanups)
        self.fx.delete_fixture()
        self.units = self.fx.root / "systemd"
        self.units.mkdir()
        self.states = self.fx.root / "service-state"
        self.states.mkdir()
        self.fx.defs.write_text(self.fx.defs.read_text().replace("/etc/systemd/system", str(self.units)))
        other = self.fx.root / "tunnels/other"
        other.mkdir()
        (other / "deployment.env").write_text("ROLE=origin\nFOREIGN_DOMAIN=other.example\n")
        (other / "run.sh").write_text("other tunnel fixture\n")
        self.other_before = (other / "deployment.env").read_bytes(), (other / "run.sh").read_bytes()
        for name in ("test", "other"):
            for suffix in ("timer", "service"):
                (self.units / f"ununknowntun-cdn-{name}.{suffix}").write_text("# Managed by UNUNKNOWNTUN CDN controller v1\nfixture\n")
            for unit in (f"ununknowntun@{name}", f"ununknowntun-cdn-{name}.timer", f"ununknowntun-cdn-{name}.service"):
                self.state(unit, "active", "enabled")

    def state(self, unit, active=None, enabled=None):
        if active is not None:
            (self.states / (unit + ".active")).write_text(active)
        if enabled is not None:
            (self.states / (unit + ".enabled")).write_text(enabled)
        return ((self.states / (unit + ".active")).read_text(), (self.states / (unit + ".enabled")).read_text())

    def events(self):
        path = self.fx.root / "services.log"
        return path.read_text() if path.exists() else ""

    def run_delete(self, failure="", answer="test\n", expected=0):
        q = shlex.quote
        body = f'''
states={q(str(self.states))}; failure={q(failure)}; nginx_calls=0
systemctl() {{
    local action="$1" unit="${{!#}}"
    printf '%s\\n' "$*" >> {q(str(self.fx.root / "services.log"))}
    case "$action" in
        is-active) [[ "$(command cat "$states/$unit.active")" == active ]];;
        is-enabled) local current; current="$(command cat "$states/$unit.enabled")"; printf '%s\\n' "$current"; [[ "$current" == enabled* ]];;
        stop) [[ "$failure/$unit" != stop/ununknowntun@test ]] || return 1; printf inactive > "$states/$unit.active";;
        disable) printf disabled > "$states/$unit.enabled"; [[ "$*" != *--now* ]] || printf inactive > "$states/$unit.active";;
        enable) if [[ "$*" == *--runtime* ]]; then printf enabled-runtime > "$states/$unit.enabled"; else printf enabled > "$states/$unit.enabled"; fi;;
        start) printf active > "$states/$unit.active";;
        reload|daemon-reload) return 0;;
        *) echo 'Unexpected mocked service action' >&2; return 97;;
    esac
}}
python3() {{
    [[ "$1" == "$INSTALL_DIR/share/cdn-control.py" && "$2" == unschedule && "$3" == --config-dir && "$4" == "$TUNNELS_DIR/test" && "$5" == --initial-lock-fd && "$6" == 9 && "$#" == 6 ]] || return 96
    printf 'unschedule test\\n' >> {q(str(self.fx.root / "services.log"))}
    systemctl disable --now ununknowntun-cdn-test.timer || return
    [[ "$failure" != unschedule ]] || return 1
    systemctl stop ununknowntun-cdn-test.service
}}
nginx() {{ nginx_calls=$((nginx_calls + 1)); [[ "$failure" != nginx || "$nginx_calls" != 1 ]]; }}
delete_tunnel test
'''
        return self.fx.shell(body, answer, expected=expected)

    def assert_other_untouched(self):
        self.assertNotIn("other", self.events())
        for unit in ("ununknowntun@other", "ununknowntun-cdn-other.timer", "ununknowntun-cdn-other.service"):
            self.assertEqual(self.state(unit), ("active", "enabled"))
        other = self.fx.root / "tunnels/other"
        self.assertEqual(self.other_before, ((other / "deployment.env").read_bytes(), (other / "run.sh").read_bytes()))

    def test_delete_disables_only_selected_timer_before_removing_config(self):
        self.run_delete()
        self.assertFalse(self.fx.config.exists())
        self.assertEqual(self.state("ununknowntun-cdn-test.timer"), ("inactive", "disabled"))
        self.assertEqual(self.state("ununknowntun-cdn-test.service")[0], "inactive")
        self.assertEqual(self.state("ununknowntun@test"), ("inactive", "disabled"))
        self.assert_other_untouched()
        events = self.events()
        self.assertLess(events.index("unschedule test"), events.index("stop ununknowntun@test"))
        backup = next((self.fx.root / "install/backups").glob("deleted-test-*"))
        self.assertEqual((backup / "cdn-timer-state.txt").read_text(), "present=1\nenabled=enabled\nactive=1\n")
        self.assertTrue((backup / "removed-config").is_dir())

    def test_rollback_restores_every_enabled_active_combination(self):
        for active in ("active", "inactive"):
            for enabled in ("enabled", "disabled"):
                with self.subTest(active=active, enabled=enabled):
                    for unit in ("ununknowntun-cdn-test.timer", "ununknowntun@test"):
                        self.state(unit, active, enabled)
                    self.run_delete("nginx", expected=1)
                    for unit in ("ununknowntun-cdn-test.timer", "ununknowntun@test"):
                        self.assertEqual(self.state(unit), (active, enabled))
                    self.assertTrue(self.fx.config.is_dir())
                    self.assertEqual(self.fx.site.read_text(), "original nginx site\n")
                    self.assertEqual((self.fx.state / "usage.json").read_text(), "retained usage\n")
                    self.assert_other_untouched()

    def test_rollback_retains_runtime_enablement(self):
        self.state("ununknowntun-cdn-test.timer", "active", "enabled-runtime")
        self.run_delete("nginx", expected=1)
        self.assertEqual(self.state("ununknowntun-cdn-test.timer"), ("active", "enabled-runtime"))
        self.assert_other_untouched()

    def test_partial_unschedule_failure_restores_timer_before_core_stop(self):
        self.run_delete("unschedule", expected=1)
        self.assertEqual(self.state("ununknowntun-cdn-test.timer"), ("active", "enabled"))
        self.assertNotIn("stop ununknowntun@test", self.events())
        self.assertTrue(self.fx.config.is_dir())
        self.assert_other_untouched()

    def test_failed_core_stop_restores_previously_disabled_timer(self):
        self.state("ununknowntun-cdn-test.timer", "inactive", "disabled")
        self.run_delete("stop", expected=1)
        self.assertEqual(self.state("ununknowntun-cdn-test.timer"), ("inactive", "disabled"))
        self.assertEqual(self.state("ununknowntun@test"), ("active", "enabled"))
        self.assertTrue(self.fx.config.is_dir())
        self.assert_other_untouched()

    def test_cancelled_confirmation_never_touches_scheduler_or_service(self):
        result = self.run_delete(answer="not-test\n")
        self.assertIn("Cancelled", result.stdout)
        self.assertEqual(self.events(), "")
        self.assertTrue(self.fx.config.is_dir())
        self.assertFalse((self.fx.root / "install/backups").exists())
        self.assert_other_untouched()

    def test_closed_confirmation_never_touches_scheduler_or_service(self):
        self.run_delete(answer="", expected=1)
        self.assertEqual(self.events(), "")
        self.assertTrue(self.fx.config.is_dir())
        self.assert_other_untouched()

    def test_unowned_scheduler_refused_without_modifications(self):
        timer = self.units / "ununknowntun-cdn-test.timer"
        timer.write_text("# unrelated administrator timer\n")
        result = self.run_delete(expected=1)
        self.assertIn("Unrelated scheduler", result.stderr)
        self.assertEqual(self.events(), "")
        self.assertEqual(timer.read_text(), "# unrelated administrator timer\n")
        self.assertTrue(self.fx.config.is_dir())
        self.assert_other_untouched()


if __name__ == "__main__":
    unittest.main(verbosity=2)
