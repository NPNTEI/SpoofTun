#!/usr/bin/env python3
"""Offline scanner contracts. No public network scan or service changes."""
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import random
import stat
import subprocess
import tempfile
import time
import unittest
from unittest import mock

spec = importlib.util.spec_from_file_location("cdn_endpoints", Path(__file__).with_name("cdn-endpoints.py"))
cdn = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cdn)


class EndpointTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="gdt-cdn-test-")
        self.addCleanup(self.tmp.cleanup)
        self.directory = Path(self.tmp.name)
        self.token = self.directory / "token"
        self.token.write_text("private-unit-test-token-do-not-export")
        self.binary = self.directory / "ununknowntun"
        self.binary.write_text("offline fixture, never executed")
        self.binary.chmod(0o700)
        self.settings = {"candidate_source": "manual", "candidates": ["104.16.0.1", "104.16.0.2"], "samples": 2}
        self.profile = {"provider": "cloudflare", "current_endpoint": "current.example:443", "binary": str(self.binary), "token_file": str(self.token), "flags": {"transport": "wss", "sni": "private.example", "ws-host": "private.example", "ws-path": "/private-path", "ech-mode": "off", "tls-fragment": "off", "mux": "on"}, "settings": self.settings}

    def successful(self, profile, endpoint, timeout):
        return {"ok": True, "elapsed_ms": 100 if endpoint.startswith("current") else 20}

    def test_manual_endpoint_normalization_and_ipv6(self):
        cases = {"EXAMPLE.com": ("example.com", 443), "104.16.0.1:2053": ("104.16.0.1", 2053), "[2001:db8::1]:8443": ("2001:db8::1", 8443), "2001:db8::1": ("2001:db8::1", 443)}
        for source, expected in cases.items():
            self.assertEqual(cdn.validate_endpoint(source), expected)
        self.assertEqual(cdn.normalize_endpoint("2001:db8::1"), "[2001:db8::1]:443")

    def test_endpoint_rejects_injection_ranges_ports_and_malformed_names(self):
        for value in ("https://example.com", "104.16.0.0/24", "x;id", "$(id)", "a@b", "a..example", "bad_name.example", "example.com:0", "example.com:65536", " 104.16.0.1", "[example.com]:443", "999.999.999.999", "fe80::1%eth0", "example.com\n"):
            with self.subTest(value=value), self.assertRaises(cdn.EndpointError):
                cdn.validate_endpoint(value)

    def test_default_settings_and_explicit_opt_in(self):
        settings = cdn.validate_settings({})
        self.assertEqual(settings["duration_seconds"], 300)
        self.assertEqual(settings["interval_hours"], 8)
        self.assertFalse(settings["enabled"])
        settings["candidates"].append("104.16.0.1")
        self.assertEqual(cdn.DEFAULT_SETTINGS["candidates"], [])

    def test_path_rotation_probe_flags_and_go_boolean_preserved(self):
        self.profile["flags"].update({"path-rotation": "2h", "path-count": "3", "path-grace": "5m", "path-legacy": "false"})
        with mock.patch.object(cdn.os, "geteuid", return_value=501):
            args = cdn.probe_command(self.profile, "104.16.0.1:443", 2)
        self.assertIn("-path-legacy=false", args)
        self.assertNotIn("false", args)
        for name, value in (("path-rotation", "2h"), ("path-count", "3"), ("path-grace", "5m")):
            self.assertEqual(args[args.index("-" + name) + 1], value)
        self.assertEqual(cdn.parse_flags("  -path-legacy=false \\\n")["path-legacy"], "false")

    def help_output(self):
        return "\n".join("  -" + key + " value\n      usage" for key in (*cdn.PROBE_FLAGS, "check-tunnel", "mode", "probe-timeout", "connect", "token-file"))

    def test_preflight_is_local_only_no_token_or_target_in_command(self):
        result = subprocess.CompletedProcess([], 0, "", self.help_output())
        with mock.patch.object(cdn.os, "geteuid", return_value=501), mock.patch.object(cdn.subprocess, "run", return_value=result) as run:
            self.assertEqual(cdn.preflight_profile(self.profile)["network_requests"], False)
        run.assert_called_once()
        self.assertEqual(run.call_args.args[0], [str(self.binary), "-h"])
        self.assertEqual(run.call_args.kwargs["timeout"], 3)

    def test_old_core_rejected_once_without_network_probes(self):
        result = subprocess.CompletedProcess([], 0, "", "  -mode string\n")
        with mock.patch.object(cdn.os, "geteuid", return_value=501), mock.patch.object(cdn.subprocess, "run", return_value=result) as run, self.assertRaisesRegex(cdn.EndpointError, "lacks required scanner options"):
            cdn.scan_profile(self.profile)
        run.assert_called_once()
        self.assertEqual(run.call_args.args[0], [str(self.binary), "-h"])

    def test_missing_core_is_preflight_error_not_repeated_candidate_failures(self):
        self.binary.unlink()
        with mock.patch.object(cdn.subprocess, "run") as run, self.assertRaisesRegex(cdn.EndpointError, "binary is unavailable"):
            cdn.scan_profile(self.profile)
        run.assert_not_called()

    def test_invalid_local_trust_settings_fail_before_any_scan(self):
        for changes in ({"system-ca": "false"}, {"system-ca": "true", "fingerprint": "a" * 64}, {"fingerprint": "bad"}, {"ca": str(self.directory / "absent-ca.pem")}):
            self.profile["flags"].update(changes)
            with self.subTest(changes=changes), mock.patch.object(cdn.os, "geteuid", return_value=501), mock.patch.object(cdn.subprocess, "run") as run, self.assertRaises(cdn.EndpointError):
                cdn.scan_profile(self.profile)
            run.assert_not_called()
            for name in changes:
                self.profile["flags"].pop(name)

    def test_progress_and_failure_summary_are_bounded_and_redacted(self):
        events = []
        report = cdn.scan_profile(self.profile, lambda *args: {"ok": False, "stage": "timeout", "reason": "secret-token at /secret-path"}, progress=events.append)
        self.assertEqual(events[0]["event"], "started")
        self.assertEqual(events[-1]["event"], "finished")
        self.assertEqual(len(events), 2 + 2 * 3)
        self.assertEqual(report["completed_endpoints"], 3)
        self.assertEqual(report["failure_summary"][0]["attempts"], 6)
        self.assertEqual(report["failure_summary"][0]["stage"], "timeout")
        self.assertFalse(report["current_authenticated"])
        serialized = json.dumps({"report": report, "events": events})
        self.assertNotIn("secret-token", serialized)
        self.assertNotIn("/secret-path", serialized)

    def test_local_failure_remains_local_in_summary(self):
        report = cdn.scan_profile(self.profile, lambda *args: {"ok": False, "stage": "local", "reason": "private-file"})
        self.assertEqual(report["failure_summary"][0]["stage"], "local")
        self.assertEqual(cdn.classify_failure("flag provided but not defined: -check-tunnel")[0], "local")
        self.assertEqual(cdn.classify_failure("[path/config] invalid path rotation interval")[0], "local")
        self.assertEqual(cdn.classify_failure("[session/config] invalid session renewal interval")[0], "local")

    def test_local_error_aborts_remaining_scan_and_discards_earlier_proposal(self):
        calls = []
        def failed_late(profile, endpoint, timeout):
            calls.append(endpoint)
            if len(calls) == 5:
                return {"ok": False, "stage": "local", "reason": "core replaced during scan"}
            return self.successful(profile, endpoint, timeout)
        report = cdn.scan_profile(self.profile, failed_late, rng=random.Random(1))
        self.assertEqual(len(calls), 5)
        self.assertTrue(report["local_error"])
        self.assertFalse(report["changed"])
        self.assertEqual(report["selected_endpoint"], self.profile["current_endpoint"])
        self.assertIn("discarded", report["reason"])

    def test_malformed_probe_result_is_local_error_without_further_calls(self):
        probe = mock.Mock(return_value=None)
        report = cdn.scan_profile(self.profile, probe)
        probe.assert_called_once()
        self.assertTrue(report["local_error"])
        self.assertFalse(report["changed"])

    def test_success_after_total_deadline_is_not_certified(self):
        now = [0.0]
        self.profile["settings"] = dict(self.settings, duration_seconds=2, samples=1)
        def probe(*args):
            now[0] = 3.0
            return {"ok": True, "elapsed_ms": 1}
        report = cdn.scan_profile(self.profile, probe, clock=lambda: now[0])
        self.assertTrue(report["timed_out"])
        self.assertFalse(report["current_authenticated"])
        self.assertEqual(report["results"][0]["successes"], 0)

    def test_probe_elapsed_above_deadline_and_huge_finite_values_cannot_win(self):
        for elapsed in (20001, 1e308):
            with self.subTest(elapsed=elapsed):
                report = cdn.scan_profile(self.profile, lambda *args: {"ok": True, "elapsed_ms": elapsed})
                self.assertFalse(report["changed"])
                self.assertFalse(report["current_authenticated"])
                json.dumps(report, allow_nan=False)

    def test_cancelled_probe_never_produces_a_proposal(self):
        probe = mock.Mock(side_effect=KeyboardInterrupt())
        with self.assertRaises(KeyboardInterrupt):
            cdn.scan_profile(self.profile, probe)
        probe.assert_called_once()

    def test_symlink_core_is_refused_before_any_process(self):
        alias = self.directory / "core-alias"
        alias.symlink_to(self.binary)
        self.profile["binary"] = str(alias)
        with mock.patch.object(cdn.subprocess, "run") as run, self.assertRaises(cdn.EndpointError):
            cdn.preflight_profile(self.profile)
        run.assert_not_called()

    def test_rotating_path_timeout_is_explicitly_incomplete_not_all_path_failure(self):
        self.profile["flags"].update({"path-rotation": "2h", "path-count": "8"})
        report = cdn.scan_profile(self.profile, lambda *args: {"ok": False, "stage": "timeout"})
        self.assertTrue(report["rotation_probe_may_be_incomplete"])
        self.assertIn("fresh route cursor", report["rotation_probe_note"])
        self.assertFalse(report["changed"])
        self.profile["flags"]["path-rotation"] = "0"
        self.assertFalse(cdn.rotation_probe_limited(self.profile, report))

    def test_strict_settings_ranges_and_unknown_keys(self):
        for changes in ({"duration_seconds": 601}, {"max_candidates": 129}, {"max_candidates": True}, {"samples": 4}, {"probe_timeout_seconds": 21}, {"interval_hours": 0}, {"enabled": "yes"}, {"minimum_improvement_percent": 100}, {"candidate_source": "internet"}, {"candidate_source": "manual"}, {"unknown": 1}, {"schema": True}):
            with self.subTest(changes=changes), self.assertRaises(cdn.EndpointError):
                cdn.validate_settings(changes)

    def test_only_cf_ipv4_ranges_enter_scanner(self):
        for candidate in ("127.0.0.1", "10.0.0.0/8", "0.0.0.0/0", "8.8.8.8", "2606:4700::1", "104.16.0.1:443", "cloudflare.com"):
            with self.subTest(candidate=candidate), self.assertRaises(cdn.EndpointError):
                cdn.validate_settings({"candidate_source": "manual", "candidates": [candidate]})

    def test_cidr_expansion_has_global_cap_and_deduplicates(self):
        settings = {"candidate_source": "manual", "candidates": ["104.16.0.0/13", "104.16.0.0/13"], "max_candidates": 5}
        addresses = cdn.candidate_addresses(settings, random.Random(10))
        self.assertEqual(len(addresses), 5)
        self.assertEqual(len(set(addresses)), 5)
        self.assertTrue(all(cdn._cf_network(value) for value in addresses))

    def test_default_snapshot_is_bounded_and_interleaved(self):
        addresses = cdn.candidate_addresses({"max_candidates": 30}, random.Random(2))
        self.assertEqual(len(addresses), 30)
        self.assertEqual(len(set(addresses)), 30)
        for network in cdn.CF_IPV4:
            self.assertTrue(any(cdn.ipaddress.ip_address(value) in network for value in addresses))
        self.assertEqual(len(cdn.CF_IPV4), 15)

    def test_small_network_and_single_address_are_preserved(self):
        addresses = cdn.candidate_addresses({"candidate_source": "manual", "candidates": ["104.16.0.1", "104.16.0.0/30"], "max_candidates": 20}, random.Random(1))
        self.assertEqual(set(addresses), {"104.16.0.1", "104.16.0.2"})

    def test_stats_finite_and_jitter(self):
        self.assertEqual(cdn.latency_stats([])["avg_ms"], None)
        self.assertEqual(cdn.latency_stats([10, 20, 30])["jitter_ms"], 10)
        self.assertEqual(cdn.latency_stats([10])["stddev_ms"], 0)

    def test_success_only_proposes_it_never_changes_config(self):
        before = self.token.read_bytes()
        report = cdn.scan_profile(self.profile, self.successful, rng=random.Random(1))
        self.assertTrue(report["changed"])
        self.assertFalse(report["configuration_changed"])
        self.assertFalse(report["target_payload_tested"])
        self.assertEqual(report["authenticated_candidates"], 2)
        self.assertEqual(self.token.read_bytes(), before)
        self.assertIn("transactional", report["reason"])

    def test_failures_retain_current_and_do_not_leak_callbacks(self):
        def failed(*args):
            return {"ok": False, "elapsed_ms": 1, "stage": "auth", "reason": "private-token /secret/path Authorization: Bearer secret"}
        report = cdn.scan_profile(self.profile, failed)
        self.assertFalse(report["changed"])
        self.assertEqual(report["selected_endpoint"], "current.example:443")
        payload = json.dumps(report)
        for secret in ("private-token", "/secret/path", "Bearer secret"):
            self.assertNotIn(secret, payload)

    def test_partial_success_cannot_replace_current(self):
        calls = {}
        def partial(profile, endpoint, timeout):
            calls[endpoint] = calls.get(endpoint, 0) + 1
            return {"ok": calls[endpoint] == 1, "elapsed_ms": 1}
        report = cdn.scan_profile(self.profile, partial)
        self.assertFalse(report["changed"])
        self.assertEqual(report["authenticated_candidates"], 0)

    def test_hysteresis_retains_healthy_endpoint(self):
        def similar(profile, endpoint, timeout):
            return {"ok": True, "elapsed_ms": 100 if endpoint.startswith("current") else 90}
        report = cdn.scan_profile(self.profile, similar)
        self.assertFalse(report["changed"])
        self.assertIn("threshold", report["reason"])

    def test_unhealthy_current_can_be_replaced_by_slower_authenticated(self):
        def recovered(profile, endpoint, timeout):
            return {"ok": not endpoint.startswith("current"), "elapsed_ms": 500}
        report = cdn.scan_profile(self.profile, recovered)
        self.assertTrue(report["changed"])

    def test_budget_limits_calls_and_incomplete_candidate_cannot_win(self):
        now = [0.0]
        self.profile["settings"] = dict(self.settings, duration_seconds=3)
        calls = []
        def clock():
            return now[0]
        def limited(profile, endpoint, timeout):
            calls.append(timeout)
            now[0] += 1
            return {"ok": True, "elapsed_ms": 10}
        report = cdn.scan_profile(self.profile, limited, clock, random.Random(1))
        self.assertEqual(calls, [3, 2, 1])
        self.assertTrue(report["timed_out"])
        self.assertFalse(report["changed"])

    def test_nonfinite_or_boolean_elapsed_never_certifies(self):
        for elapsed in (float("nan"), float("inf"), -1, True, "10"):
            with self.subTest(elapsed=elapsed):
                report = cdn.scan_profile(self.profile, lambda *args: {"ok": True, "elapsed_ms": elapsed})
                self.assertFalse(report["changed"])
                json.dumps(report, allow_nan=False)

    def test_provider_spoof_port_and_transport_guardrails(self):
        for change in ({"provider": "fastly"}, {"current_endpoint": "current.example:80"}, {"flags": dict(self.profile["flags"], transport="tls")}, {"flags": dict(self.profile["flags"], **{"spoof-config": "/private/gre.json"})}, {"flags": {"transport": "wss"}}):
            with self.subTest(change=change), self.assertRaises(cdn.EndpointError):
                cdn.scan_profile(dict(self.profile, **change), self.successful)

    def test_core_flags_allowlist_preserves_sni_host_and_new_options(self):
        self.profile["flags"].update({"listen": "0.0.0.0:443", "access-config": "/do-not-open", "token": "NEVER-IN-ARGV", "ech-config": "ech.example+udp://9.9.9.9", "padding-bytes": "100-200", "xhttp-padding-bytes": "100-1000", "xhttp-mode": "stream-up"})
        result = subprocess.CompletedProcess([], 0, "OK", "")
        with mock.patch.object(cdn.os, "geteuid", return_value=501), mock.patch.object(cdn.subprocess, "run", return_value=result) as run:
            report = cdn.core_probe(self.profile, "104.16.0.1:443", 4)
        args = run.call_args.args[0]
        self.assertNotIn("-listen", args)
        self.assertNotIn("-access-config", args)
        self.assertNotIn("-token", args)
        self.assertNotIn("NEVER-IN-ARGV", args)
        self.assertEqual(args[args.index("-sni") + 1], "private.example")
        self.assertEqual(args[args.index("-ws-host") + 1], "private.example")
        self.assertEqual(args[args.index("-connect") + 1], "104.16.0.1:443")
        for flag in ("-ech-config", "-padding-bytes", "-xhttp-padding-bytes", "-xhttp-mode"):
            self.assertIn(flag, args)
        self.assertTrue(report["ok"])
        self.assertEqual(run.call_args.kwargs["timeout"], 4)
        self.assertNotIn("shell", run.call_args.kwargs)

    def test_environment_cannot_inject_unrelated_token_or_proxy(self):
        result = subprocess.CompletedProcess([], 0, "", "")
        with mock.patch.dict(os.environ, {"UNUNKNOWNTUN_TOKEN": "wrong", "V7_TOKEN": "wrong", "https_proxy": "http://wrong", "HTTP_PROXY": "http://wrong"}), mock.patch.object(cdn.os, "geteuid", return_value=501), mock.patch.object(cdn.subprocess, "run", return_value=result) as run:
            cdn.core_probe(self.profile, "104.16.0.1:443", 2)
        environment = run.call_args.kwargs["env"]
        for key in ("UNUNKNOWNTUN_TOKEN", "V7_TOKEN", "https_proxy", "HTTP_PROXY"):
            self.assertNotIn(key, environment)

    def test_core_error_redaction_is_categorical_not_raw(self):
        text = "x509 certificate failed " + self.token.read_text() + " /private-path " + str(self.token)
        result = subprocess.CompletedProcess([], 1, "", text)
        with mock.patch.object(cdn.os, "geteuid", return_value=501), mock.patch.object(cdn.subprocess, "run", return_value=result):
            report = cdn.core_probe(self.profile, "104.16.0.1:443", 2)
        self.assertEqual(report["stage"], "tls-certificate")
        self.assertFalse(report["ok"])
        payload = json.dumps(report)
        for secret in (self.token.read_text(), "/private-path", str(self.token)):
            self.assertNotIn(secret, payload)

    def test_core_timeout_returns_bounded_reason(self):
        with mock.patch.object(cdn.os, "geteuid", return_value=501), mock.patch.object(cdn.subprocess, "run", side_effect=subprocess.TimeoutExpired("private-token", 2)):
            report = cdn.core_probe(self.profile, "104.16.0.1:443", 2)
        self.assertEqual(report["stage"], "timeout")
        self.assertNotIn("private-token", json.dumps(report))

    def test_real_local_subprocess_deadline_kills_and_reaps_fixture(self):
        # This is a local sleeping fixture, not a tunnel or public IP probe.
        # Exercise subprocess.run's real deadline/kill behavior rather than a
        # mocked TimeoutExpired exception. No socket or target stream is opened.
        pidfile = self.directory / "fixture.pid"
        self.binary.write_text("#!/bin/sh\nprintf '%s' \"$$\" > " + cdn.shlex.quote(str(pidfile)) + "\nexec /bin/sleep 10\n")
        began = time.monotonic()
        # Execute the trusted shell directly: macOS can defer first execution of
        # a newly written temporary executable beyond this 0.5-second deadline.
        # Command validation is covered separately; this test exercises the real
        # subprocess deadline, kill and reap, with no mocked subprocess calls.
        with mock.patch.object(cdn, "probe_command", return_value=["/bin/sh", str(self.binary)]):
            report = cdn.core_probe(self.profile, "104.16.0.1:443", .5)
        self.assertEqual(report["stage"], "timeout")
        self.assertLess(time.monotonic() - began, 3)
        self.assertTrue(pidfile.is_file(), "local fixture never started")
        with self.assertRaises(ProcessLookupError):
            os.kill(int(pidfile.read_text()), 0)

    def test_post_change_public_hook_normalizes_and_bounds_timeout(self):
        with mock.patch.object(cdn, "core_probe", return_value={"ok": True}) as probe:
            self.assertTrue(cdn.probe_endpoint(self.profile, "EXAMPLE.com", 3)["ok"])
        self.assertEqual(probe.call_args.args[1], "example.com:443")
        for timeout in (True, 0, .01, 21, float("inf"), "3"):
            with self.subTest(timeout=timeout), self.assertRaises(cdn.EndpointError):
                cdn.probe_endpoint(self.profile, "example.com", timeout)

    def test_system_ca_bool_does_not_terminate_go_flag_parsing(self):
        self.profile["flags"]["system-ca"] = "true"
        result = subprocess.CompletedProcess([], 0, "", "")
        with mock.patch.object(cdn.os, "geteuid", return_value=501), mock.patch.object(cdn.subprocess, "run", return_value=result) as run:
            cdn.core_probe(self.profile, "104.16.0.1:443", 2)
        args = run.call_args.args[0]
        self.assertIn("-system-ca=true", args)
        self.assertNotIn("true", args)

    def test_token_length_matches_core_byte_limit(self):
        for value in ("x" * 15, "x" * 513, "é" * 257):
            self.token.write_text(value)
            with self.subTest(length=len(value)), mock.patch.object(cdn.os, "geteuid", return_value=501), self.assertRaises(cdn.EndpointError):
                cdn.core_probe(self.profile, "104.16.0.1:443", 2)

    def test_common_failure_categories_do_not_claim_filter_root_cause(self):
        cases = {"x509": "tls-certificate", "strict ECH rejected": "ech", "context deadline exceeded": "timeout", "403 Forbidden": "http", "401": "http", "token invalid": "authentication", "connection refused": "tcp", "no such host": "dns", "TLS handshake error": "tls"}
        for text, stage in cases.items():
            with self.subTest(text=text):
                self.assertEqual(cdn.classify_failure(text)[0], stage)

    def test_root_refuses_mutable_binary(self):
        self.binary.chmod(0o777)
        with mock.patch.object(cdn.os, "geteuid", return_value=0), self.assertRaises(cdn.EndpointError):
            cdn.core_probe(self.profile, "104.16.0.1:443", 2)

    def test_json_duplicate_unknown_and_symlink_rejected(self):
        path = self.directory / "settings.json"
        path.write_text('{"enabled":false,"enabled":true}')
        with self.assertRaises(cdn.EndpointError):
            cdn.load_settings(path)
        path.unlink()
        path.symlink_to(self.token)
        with self.assertRaises(cdn.EndpointError):
            cdn.load_settings(path)

    def save_profile(self):
        (self.directory / "deployment.env").write_text("ROLE=origin\nFOREIGN_PROXY_PROVIDER=cloudflare\nFOREIGN_PORTS=443\nTUNNEL_NAME=$'Friendly name'\n")
        lines = ["#!/bin/sh", "exec /usr/local/bin/ununknowntun \\"]
        flags = dict(self.profile["flags"], mode="origin", connect="current.example:443", **{"token-file": str(self.token)})
        lines.extend("  -" + name + " " + value + " \\" for name, value in flags.items())
        (self.directory / "run.sh").write_text("\n".join(lines) + "\n")
        (self.directory / "cdn-endpoints.json").write_text(json.dumps(self.settings))

    def test_profile_loader_never_executes_launcher_and_has_revision(self):
        self.save_profile()
        with mock.patch.object(cdn.subprocess, "run", side_effect=AssertionError("must not execute")):
            profile = cdn.load_profile(self.directory)
        self.assertEqual(profile["current_endpoint"], "current.example:443")
        revision = profile["revision"]
        self.token.write_text("replacement-private-unit-test-token")
        self.assertNotEqual(cdn.load_profile(self.directory)["revision"], revision)
        self.assertEqual(profile["original_endpoints"], ["current.example:443"])

    def test_missing_optional_settings_uses_safe_defaults_without_writes(self):
        self.save_profile()
        settings_path = self.directory / "cdn-endpoints.json"
        settings_path.unlink()
        profile = cdn.load_profile(self.directory)
        self.assertEqual(profile["settings"], cdn.DEFAULT_SETTINGS)
        self.assertFalse(profile["settings"]["enabled"])
        self.assertFalse(settings_path.exists())
        with self.assertRaises(cdn.EndpointError):
            cdn.load_profile(self.directory, settings_path=settings_path)

    def test_missing_settings_does_not_ignore_dangling_symlink(self):
        self.save_profile()
        settings_path = self.directory / "cdn-endpoints.json"
        settings_path.unlink()
        settings_path.symlink_to(self.directory / "missing-file")
        with self.assertRaises(cdn.EndpointError):
            cdn.load_profile(self.directory)

    def test_loader_rejects_inline_or_unrelated_token(self):
        self.save_profile()
        path = self.directory / "run.sh"
        path.write_text(path.read_text().replace(str(self.token), "/other/token"))
        with self.assertRaises(cdn.EndpointError):
            cdn.load_profile(self.directory)

    def test_loader_rejects_launcher_role_mismatch_or_missing_mode(self):
        self.save_profile()
        path = self.directory / "run.sh"
        original = path.read_text()
        for value in (original.replace("-mode origin", "-mode egress"), original.replace("  -mode origin \\\n", "")):
            path.write_text(value)
            with self.assertRaisesRegex(cdn.EndpointError, "connection-initiating origin"):
                cdn.load_profile(self.directory)

    def test_parse_flags_never_evaluates_shell_and_rejects_duplicate(self):
        for text in ("  -sni $(touch /tmp/never-created)\n", "  -sni $DOMAIN\n", "  -sni a.example\n  -sni b.example\n"):
            with self.assertRaises(cdn.EndpointError):
                cdn.parse_flags(text)

    def test_report_is_private_exclusive_and_json_finite(self):
        path = self.directory / "report.json"
        cdn.write_report(path, {"status": "fixture"})
        self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)
        with self.assertRaises(FileExistsError):
            cdn.write_report(path, {})

    def test_check_settings_cli_no_network(self):
        self.save_profile()
        with contextlib.redirect_stdout(io.StringIO()) as output, mock.patch.object(cdn.subprocess, "run", side_effect=AssertionError("network")):
            result = cdn.main(["check-settings", "--config-dir", str(self.directory)])
        self.assertEqual(result, 0)
        self.assertEqual(json.loads(output.getvalue())["verdict"], "settings-checked-no-network")

    def test_sikdpi_license_and_official_source_are_preserved(self):
        self.assertIn("Copyright (c) 2026 SIKDPI contributors", cdn.SIKDPI_LICENSE)
        self.assertIn("THE SOFTWARE IS PROVIDED", cdn.SIKDPI_LICENSE)
        self.assertEqual(cdn.CF_SOURCE, "https://www.cloudflare.com/ips-v4/")


if __name__ == "__main__":
    unittest.main(verbosity=2)
