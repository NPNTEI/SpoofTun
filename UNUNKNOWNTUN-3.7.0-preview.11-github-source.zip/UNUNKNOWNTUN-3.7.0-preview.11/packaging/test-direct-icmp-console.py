#!/usr/bin/env python3
"""Offline Direct ICMP discovery/delegation regressions; no service or network calls."""
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

sys.dont_write_bytecode = True
SPEC = importlib.util.spec_from_file_location("icmp_console_tests_module", Path(__file__).with_name("direct-icmp-console.py"))
console = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = console
SPEC.loader.exec_module(console)


class ConsoleTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name) / "registry"
        self.root.mkdir()
        self.patch = mock.patch.object(console, "CONFIG_ROOT", self.root)
        self.patch.start()
        self.addCleanup(self.patch.stop)
        self.process_patch = mock.patch.object(console.subprocess, "run", side_effect=AssertionError("No live process allowed"))
        self.process = self.process_patch.start()
        self.addCleanup(self.process_patch.stop)

    def fixture(self, role="origin", version="3.7.0-preview.9"):
        folder = self.root / "demo" / role
        folder.mkdir(parents=True, mode=0o700)
        unit = "ununknowntun-direct-icmp-demo-" + role + ".service"
        config = {"role": role, "key_file": str(folder / "icmp.key"), "local_ip": "192.0.2.1", "peer_ip": "192.0.2.2",
                  "inner_local_ip": "10.79.0.1", "inner_peer_ip": "10.79.0.2", "local_pool_cidr": "10.80.0.0/29",
                  "secret_not_for_display": "never-display-me", "port_forwards": [{"protocol": "tcp", "listen": "0.0.0.0:12055", "target": "10.79.0.2:28082"}]}
        files = {"manage.py": b"# isolated installed manager\n", "doctor.py": b"# doctor\n", "direct-icmp.json": json.dumps(config).encode(),
                 "icmp.key": b"a" * 64 + b"\n", unit: b"[Unit]\n"}
        for name, data in files.items():
            (folder / name).write_bytes(data)
            (folder / name).chmod(0o600)
        metadata = {"format": 1, "version": version, "pair_id": "demo", "role": role, "install_dir": str(folder),
                    "binary_path": str(console.BINARY_ROOT / version / "ununknowntun"), "unit_name": unit,
                    "binary_sha256": {"amd64": "a" * 64, "arm64": "b" * 64},
                    "files": {name: hashlib.sha256(data).hexdigest() for name, data in files.items()}}
        (folder / "endpoint.json").write_text(json.dumps(metadata))
        (folder / "endpoint.json").chmod(0o600)
        return folder

    def change_manifest(self, folder, **values):
        path = folder / "endpoint.json"
        metadata = json.loads(path.read_text())
        metadata.update(values)
        path.write_text(json.dumps(metadata))

    def inspect(self, folder):
        return console.inspect_endpoint(folder, check_trust=False)

    def test_discovery_is_read_only_and_accepts_old_version(self):
        self.fixture()
        self.fixture("egress", "3.7.0-preview.10")
        endpoints, rejected = console.discover(check_trust=False)
        self.assertEqual([e.identity for e in endpoints], ["demo/egress", "demo/origin"])
        self.assertEqual(rejected, [])
        self.process.assert_not_called()

    def test_summary_includes_forwarding_without_secrets(self):
        endpoint = self.inspect(self.fixture())
        with contextlib.redirect_stdout(io.StringIO()) as output:
            console.show_inventory([endpoint], [])
        text = output.getvalue()
        self.assertIn("TCP 0.0.0.0:12055 -> 10.79.0.2:28082", text)
        self.assertIn("Local pool: 10.80.0.0/29", text)
        self.assertNotIn("never-display-me", text)
        self.assertNotIn("icmp.key", text)
        self.assertNotIn("a" * 64, text)

    def test_invalid_display_fields_do_not_emit_controls(self):
        self.assertEqual(console.socket_label("password\x1b[2J:80"), "invalid mapping (details hidden)")
        self.assertNotIn("\x1b", console.clean("name\x1b[2J"))
        self.assertEqual(console.socket_label("[::1]:443"), "[::1]:443")

    def test_manifest_arbitrary_command_and_paths_refused(self):
        for field, value in (("command", "reboot"), ("binary_path", "/tmp/evil"), ("install_dir", "/etc"), ("pair_id", "other"), ("unit_name", "ssh.service")):
            with self.subTest(field=field):
                folder = self.fixture()
                self.change_manifest(folder, **{field: value})
                with self.assertRaises(console.ConsoleError):
                    self.inspect(folder)
                for path in folder.iterdir():
                    path.unlink()
                folder.rmdir()
        self.process.assert_not_called()

    def test_bad_version_and_hash_inventory_rejected(self):
        folder = self.fixture()
        self.change_manifest(folder, version="../../tmp/evil")
        with self.assertRaises(console.ConsoleError):
            self.inspect(folder)
        self.change_manifest(folder, version="3.7.0-preview.9", binary_sha256={"amd64": "a" * 64})
        with self.assertRaises(console.ConsoleError):
            self.inspect(folder)

    def test_tampered_manager_rejected_before_execution(self):
        folder = self.fixture()
        (folder / "manage.py").write_text("raise SystemExit(0)")
        with self.assertRaises(console.ConsoleError):
            self.inspect(folder)
        self.process.assert_not_called()

    def test_duplicate_json_and_unexpected_files_rejected(self):
        folder = self.fixture()
        (folder / "extra.py").write_text("# unknown")
        with self.assertRaises(console.ConsoleError):
            self.inspect(folder)
        with self.assertRaises(console.ConsoleError):
            console.strict_json('{"a":1,"a":2}')

    def test_symlink_helper_or_endpoint_rejected(self):
        folder = self.fixture()
        (folder / "manage.py").unlink()
        (folder / "manage.py").symlink_to(folder / "doctor.py")
        with self.assertRaises(OSError):
            self.inspect(folder)
        (self.root / "linked").symlink_to(folder.parent, target_is_directory=True)
        endpoints, rejected = console.discover(check_trust=False)
        self.assertEqual(endpoints, [])
        self.assertEqual(len(rejected), 2)

    def test_multilink_and_oversized_files_refused(self):
        folder = self.fixture()
        os.link(folder / "manage.py", folder.parent / "hardlink")
        with self.assertRaises(console.ConsoleError):
            console.read_file(folder / "manage.py", check_trust=False)
        (folder / "doctor.py").write_bytes(b"a" * (console.FILE_LIMIT + 1))
        with self.assertRaises(console.ConsoleError):
            console.read_file(folder / "doctor.py", check_trust=False)

    def test_trust_rejects_unowned_group_writable_and_symlink(self):
        for mode, uid in ((stat.S_IFREG | 0o600, 1000), (stat.S_IFREG | 0o620, 0), (stat.S_IFLNK | 0o777, 0)):
            with self.subTest(mode=mode, uid=uid), mock.patch.object(Path, "lstat", return_value=SimpleNamespace(st_mode=mode, st_uid=uid)):
                with self.assertRaises(console.ConsoleError):
                    console.trusted(Path("/etc/example"))

    def test_discovery_missing_registry_and_bounded_input(self):
        self.root.rmdir()
        self.assertEqual(console.discover(check_trust=False), ([], []))
        self.root.mkdir()
        for number in range(3):
            (self.root / str(number)).mkdir()
        with self.assertRaises(console.ConsoleError):
            console.bounded_children(self.root, 2)

    def test_action_uses_fixed_installed_manager_and_clean_environment(self):
        endpoint = self.inspect(self.fixture())
        self.process.side_effect = [SimpleNamespace(returncode=0, stdout="{status,start,stop,restart,logs,doctor,info,uninstall}", stderr=""), SimpleNamespace(returncode=3)]
        with mock.patch.object(console, "inspect_endpoint", return_value=endpoint), mock.patch.dict(os.environ, {"PYTHONPATH": "/tmp/evil", "LD_PRELOAD": "evil", "UNUNKNOWNTUN_TOKEN": "secret"}):
            self.assertEqual(console.invoke(endpoint, "status"), 3)
        first, last = self.process.call_args_list
        self.assertEqual(first.args[0], ["/usr/bin/python3", "-I", str(endpoint.folder / "manage.py"), "--help"])
        self.assertEqual(last.args[0], ["/usr/bin/python3", "-I", str(endpoint.folder / "manage.py"), "status"])
        self.assertFalse(last.kwargs.get("shell", False))
        self.assertNotIn("UNUNKNOWNTUN_TOKEN", last.kwargs["env"])
        self.assertNotIn("PYTHONPATH", last.kwargs["env"])

    def test_old_manager_missing_restart_does_not_emulate_it(self):
        endpoint = self.inspect(self.fixture())
        self.process.side_effect = None
        self.process.return_value = SimpleNamespace(returncode=0, stdout="{status,start,stop}", stderr="")
        with mock.patch.object(console, "inspect_endpoint", return_value=endpoint), self.assertRaisesRegex(console.ConsoleError, "does not support restart"):
            console.invoke(endpoint, "restart")
        self.assertEqual(self.process.call_count, 1)

    def test_changed_endpoint_and_unknown_action_refused(self):
        endpoint = self.inspect(self.fixture())
        with mock.patch.object(console, "inspect_endpoint", return_value=None), self.assertRaises(console.ConsoleError):
            console.invoke(endpoint, "start")
        with self.assertRaises(console.ConsoleError):
            console.invoke(endpoint, "install")
        self.process.assert_not_called()

    def test_help_failure_and_timeout_do_not_mutate(self):
        endpoint = self.inspect(self.fixture())
        with mock.patch.object(console, "inspect_endpoint", return_value=endpoint):
            for outcome in (SimpleNamespace(returncode=1, stdout="{restart}", stderr=""), subprocess.TimeoutExpired(["private"], 5)):
                self.process.reset_mock()
                self.process.side_effect = [outcome]
                with self.assertRaises(console.ConsoleError):
                    console.invoke(endpoint, "restart")
                self.assertEqual(self.process.call_count, 1)

    def test_uninstall_requires_exact_pair_and_role(self):
        endpoint = self.inspect(self.fixture())
        for response, calls in (("demo", 0), ("other/origin", 0), ("demo/origin", 1)):
            with self.subTest(response=response), mock.patch.object(console, "discover", return_value=([endpoint], [])), \
                    mock.patch.object(console, "invoke", return_value=0) as invoke, contextlib.redirect_stdout(io.StringIO()):
                answers = iter(["1", "8", response] + ([""] if calls else []) + ["q"])
                self.assertEqual(console.interactive(lambda _: next(answers)), 0)
                self.assertEqual(invoke.call_count, calls)
                if calls:
                    invoke.assert_called_once_with(endpoint, "uninstall")

    def test_open_quit_and_cancel_restart_never_launch_manager(self):
        endpoint = self.inspect(self.fixture())
        for answers in (["q"], ["1", "4", "", "q"]):
            with mock.patch.object(console, "discover", return_value=([endpoint], [])), contextlib.redirect_stdout(io.StringIO()):
                replies = iter(answers)
                self.assertEqual(console.interactive(lambda _: next(replies)), 0)
        self.process.assert_not_called()

    def test_list_requires_linux_root_and_does_not_call_manager(self):
        with mock.patch.object(console.sys, "platform", "linux"), mock.patch.object(console.os, "geteuid", return_value=0), \
                mock.patch.object(console, "discover", return_value=([], [])), contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(console.main(["--list"]), 0)
        with mock.patch.object(console.os, "geteuid", return_value=1000), contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            console.main(["--list"])
        self.process.assert_not_called()


if __name__ == "__main__":
    unittest.main(verbosity=2)
