#!/usr/bin/env python3
"""Execute the embedded pair wizard offline with host mutations forbidden."""
import importlib.util
import json
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode=True
HERE=Path(__file__).parent
spec=importlib.util.spec_from_file_location('direct_installer_fixture',HERE/'test-full-installer.py')
fixture=importlib.util.module_from_spec(spec);spec.loader.exec_module(fixture)

class DirectInstallerTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='gdt-direct-installer-',dir=str(Path(tempfile.gettempdir()).resolve()))
        self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
        self.defs=self.root/'definitions.sh';self.defs.write_text(fixture.DEFINITIONS)
        self.output=self.root/'private-pair';self.guard=self.root/'guard.log';self.guard.touch()

    def run_shell(self,body,answers='',expected=0):
        q=shlex.quote
        guards='\n'.join(name+'() { deny '+name+' "$@"; }' for name in ('systemctl','nginx','ufw','ip','sysctl','install','curl','wget','apt','apt-get','require_root','install_binary','install_foreign','install_origin','upgrade_existing'))
        script=f'''source {q(str(self.defs))}
VERSION=3.7.0-preview.11
AMD64_SHA256={'a'*64}
ARM64_SHA256={'b'*64}
GUARD={q(str(self.guard))}
OUTPUT={q(str(self.output))}
deny() {{ printf '%s\\n' "$*" >> "$GUARD"; return 97; }}
{guards}
{body}
'''
        result=subprocess.run(['bash','-c',script],input=answers,text=True,capture_output=True)
        self.assertEqual(result.returncode,expected,result.stdout+result.stderr)
        self.assertEqual(self.guard.read_text(),'')
        return result

    def answers(self, fec=None):
        return '\n'.join(['my-icmp','192.0.2.10','eth0','10.79.0.1','192.0.2.20','ens3','10.79.0.2','1200','20','15','3600']+
                         (['','',''] if fec is None else fec)+['no'])+'\n'

    def test_actual_embedded_generation(self):
        self.run_shell('generate_direct_icmp_pair "$OUTPUT"',self.answers())
        config=json.loads((self.output/'origin/direct-icmp.json').read_text())
        self.assertEqual(config['peer_ip'],'192.0.2.20')
        self.assertEqual(config['fec_mode'],'adaptive')
        self.assertEqual(config['fec_max_percent'],25)
        self.assertEqual(config['fec_block_ms'],20)
        self.assertEqual((self.output/'origin/manage.py').read_bytes(),(HERE/'direct-icmp-manage.py').read_bytes())
        meta=json.loads((self.output/'origin/endpoint.json').read_text())
        self.assertEqual(meta['binary_sha256'],{'amd64':'a'*64,'arm64':'b'*64})

    def test_fixed_mode_actual_wizard_and_mirrored_config(self):
        self.run_shell('generate_direct_icmp_pair "$OUTPUT"',self.answers(['fixed','30','15','10']))
        configs=[json.loads((self.output/role/'direct-icmp.json').read_text()) for role in ('origin','egress')]
        for config in configs:
            self.assertEqual(config['fec_mode'],'fixed')
            self.assertEqual(config['fec_percent'],15)
            self.assertEqual(config['fec_max_percent'],30)
            self.assertEqual(config['fec_block_ms'],10)

    def test_off_mode_skips_repair_prompts(self):
        result=self.run_shell('generate_direct_icmp_pair "$OUTPUT"',self.answers(['off']))
        self.assertNotIn('Maximum repair percent',result.stdout)
        config=json.loads((self.output/'origin/direct-icmp.json').read_text())
        self.assertEqual(config['fec_mode'],'off')

    def test_invalid_fec_rejected_without_output(self):
        self.run_shell('generate_direct_icmp_pair "$OUTPUT"',self.answers(['fixed','25','50']),expected=1)
        self.assertFalse(self.output.exists())

    def test_creation_menu_routes_to_new_mode(self):
        result=self.run_shell('run_direct_icmp_setup() { printf "EASY_ROLE=%s\\n" "$1"; }; create_tunnel origin','5\n')
        self.assertIn('Direct ICMP L3',result.stdout)
        self.assertIn('EASY_ROLE=origin',result.stdout)
        self.assertFalse(self.output.exists())

    def test_main_menu_new_choice(self):
        result=self.run_shell('run_direct_icmp_setup() { echo EASY_SETUP; }; main_menu','8\n')
        self.assertIn('EASY_SETUP',result.stdout)
        self.assertIn('private pairing code',result.stdout)

    def test_generation_does_not_require_root(self):
        result=self.run_shell('generate_direct_icmp_pair "$OUTPUT"',self.answers())
        self.assertIn('Generation only:',result.stdout)

    def test_bad_output_refused_before_wizard(self):
        self.run_shell('generate_direct_icmp_pair relative',expected=1)
        self.assertFalse(self.output.exists())

    def test_renderer_and_package_include_helpers_and_hashes(self):
        render=(HERE/'render-complete.py').read_text()
        package=(HERE/'package-preview.py').read_text()
        for name in ('direct-icmp-pair.py','direct-icmp-manage.py','direct-icmp-setup.py','direct-icmp-doctor.py','direct-icmp-binaries.json'):
            self.assertIn(name,render);self.assertIn(name,package)
        self.assertIn('direct-icmp-pair)',fixture.DEFINITIONS)
        self.assertIn('install_direct_icmp_helpers',fixture.DEFINITIONS)

    def easy_fixture(self, role='foreign', exit_status=0, broken_binary=False):
        q=shlex.quote
        binary_mock = 'return 1' if broken_binary else 'printf fixture-binary > "$2"; printf "%s\\n" "$1" > "$OUTPUT.arch"'
        return f'''
require_root() {{ :; }}
detect_os() {{ :; }}
ensure_direct_icmp_dependencies() {{ :; }}
acquire_install_lock() {{ :; }}
new_direct_icmp_stage() {{ command mktemp -d {q(str(self.root / 'stage.XXXXXXXX'))}; }}
extract_embedded_binary() {{ {binary_mock}; }}
python3() {{
    [[ "$1" == -I && "$2" == */direct-icmp-setup.py ]] || return 93
    command python3 -I "$2" --help >/dev/null || return
    command python3 -I - "$2" "$3" "$5" "$7" "$OUTPUT" <<'VERIFY_STAGE'
import json, os, pathlib, sys
stage=pathlib.Path(sys.argv[1]).parent
names={{'spoof-pair.py','direct-icmp-pair.py','direct-icmp-manage.py','direct-icmp-setup.py','direct-icmp-doctor.py','direct-icmp-binaries.json','ununknowntun'}}
assert {{p.name for p in stage.iterdir()}} == names
assert os.stat(stage).st_mode & 0o777 == 0o700
assert pathlib.Path(sys.argv[3]).read_bytes() == b'fixture-binary'
manifest=json.loads(pathlib.Path(sys.argv[4]).read_text())
assert manifest['version'] == '3.7.0-preview.11'
assert manifest['binary_sha256'] == {{'amd64':'a'*64,'arm64':'b'*64}}
pathlib.Path(sys.argv[5]).write_text(sys.argv[2])
VERIFY_STAGE
    return {exit_status}
}}
run_direct_icmp_setup {q(role)}
'''

    def test_easy_foreign_stages_all_helpers_and_manifest_without_file_transfer(self):
        self.run_shell(self.easy_fixture())
        self.assertEqual(self.output.read_text(),'foreign')
        self.assertIn((self.root/'private-pair.arch').read_text().strip(),('arm64','amd64'))
        self.assertFalse(list(self.root.glob('stage.*')))

    def test_easy_iran_role_alias_and_staging_cleanup_after_error(self):
        self.run_shell(self.easy_fixture('origin',exit_status=42),expected=42)
        self.assertEqual(self.output.read_text(),'iran')
        self.assertFalse(list(self.root.glob('stage.*')))

    def test_easy_role_prompt(self):
        self.run_shell(self.easy_fixture(''),answers='2\n')
        self.assertEqual(self.output.read_text(),'iran')

    def test_easy_invalid_binary_never_launches_setup(self):
        self.run_shell(self.easy_fixture(broken_binary=True),expected=1)
        self.assertFalse(self.output.exists())
        self.assertFalse(list(self.root.glob('stage.*')))

    def test_existing_prerequisites_do_not_call_package_manager(self):
        self.run_shell('have_command() { return 0; }; ensure_direct_icmp_dependencies')

    def test_only_missing_dependency_is_installed(self):
        result=self.run_shell('''
ready=0
have_command() { [[ "$1" != nft || "$ready" == 1 ]]; }
apt-get() { printf 'APT %s\\n' "$*"; [[ "$*" != *install* ]] || ready=1; }
ensure_direct_icmp_dependencies
''')
        self.assertIn('install --no-upgrade -y nftables',result.stdout)
        self.assertNotIn('-y python3',result.stdout)

    def test_share_helper_install_keeps_full_inventory_and_removes_stage(self):
        self.run_shell('INSTALL_DIR="${OUTPUT}-share"; mkdir -p "$INSTALL_DIR/share"; install_direct_icmp_helpers')
        share=self.root/'private-pair-share/share'
        for name in ('direct-icmp-setup.py','direct-icmp-doctor.py','direct-icmp-pair.py','direct-icmp-manage.py','spoof-pair.py'):
            self.assertEqual((share/name).read_bytes(),(HERE/name).read_bytes())
        self.assertFalse(list(share.glob('.direct-icmp.*')))

    def test_guided_scan_route_and_menu_exist_and_ui_is_english(self):
        self.assertIn('cdn-rounds) action=rounds',fixture.DEFINITIONS)
        self.assertIn('24) "$CTL_PATH" cdn-rounds',fixture.DEFINITIONS)
        self.assertNotRegex(fixture.TEMPLATE.read_text(),r'[\u0600-\u06ff]')
        self.run_shell('valid_manage_choice 24; ! valid_manage_choice 25')

if __name__=='__main__':unittest.main()
