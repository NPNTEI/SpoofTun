#!/usr/bin/env python3
"""Offline matched-pair, private-file and lifecycle integrity tests. No host changes."""
import copy
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import platform
import stat
import struct
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

sys.dont_write_bytecode = True
HERE = Path(__file__).parent

def load(name):
    spec = importlib.util.spec_from_file_location(name.replace('-', '_'), HERE / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

pair = load('direct-icmp-pair')
manager = load('direct-icmp-manage')

class PairTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='gdt-direct-', dir=str(Path(tempfile.gettempdir()).resolve()))
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.output = self.root / 'pair'
        self.spec = {'pair_id': 'demo', 'binary_sha256': {'amd64': 'a'*64, 'arm64': 'b'*64},
                     'origin': {'interface': 'eth0', 'real_ip': '192.0.2.10', 'inner_ip': '10.79.0.1'},
                     'egress': {'interface': 'ens3', 'real_ip': '192.0.2.20', 'inner_ip': '10.79.0.2'}}

    def generate(self):
        return pair.generate(self.spec, str(self.output))

    def test_pair_roundtrip_and_private_permissions(self):
        spec = self.generate()
        self.assertEqual(pair.check_pair(str(self.output)), spec)
        for path in [self.output, *self.output.rglob('*')]:
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o700 if path.is_dir() else 0o600)
        self.assertEqual((self.output/'origin/icmp.key').read_bytes(), (self.output/'egress/icmp.key').read_bytes())
        a = json.loads((self.output/'origin/direct-icmp.json').read_text())
        b = json.loads((self.output/'egress/direct-icmp.json').read_text())
        self.assertEqual(a['peer_ip'], b['local_ip'])
        self.assertEqual(a['inner_peer_ip'], b['inner_local_ip'])
        self.assertNotEqual(a['role'], b['role'])
        self.assertEqual(a['fec_mode'], 'adaptive')
        for field in pair.FEC_FIELDS:
            self.assertEqual(a[field], b[field])

    def test_all_fec_modes_are_matched_and_explicit(self):
        for mode in ('off', 'fixed', 'adaptive'):
            with self.subTest(mode=mode):
                value=copy.deepcopy(self.spec)
                value.update(fec_mode=mode, fec_percent=15, fec_max_percent=30, fec_block_ms=10)
                output=self.root/mode
                spec=pair.generate(value,str(output))
                self.assertEqual(pair.check_pair(str(output)),spec)
                for role in ('origin','egress'):
                    config=json.loads((output/role/'direct-icmp.json').read_text())
                    self.assertEqual({k:config[k] for k in pair.FEC_FIELDS},
                                     {k:value[k] for k in pair.FEC_FIELDS})

    def test_fec_invalid_values_fail_before_writing(self):
        for key,value in [('fec_mode','auto'),('fec_mode',True),('fec_mode',None),
                          ('fec_percent',-1),('fec_percent',51),('fec_percent',True),
                          ('fec_max_percent',4),('fec_max_percent',51),('fec_max_percent',False),
                          ('fec_block_ms',4),('fec_block_ms',101),('fec_block_ms',20.0)]:
            with self.subTest(key=key,value=value):
                spec=copy.deepcopy(self.spec);spec[key]=value
                with self.assertRaises(pair.base.PairError):pair.generate(spec,str(self.output))
                self.assertFalse(self.output.exists())

    def test_fixed_repair_target_cannot_exceed_cap(self):
        self.spec.update(fec_mode='fixed',fec_percent=30,fec_max_percent=25)
        with self.assertRaises(pair.base.PairError):self.generate()
        self.assertFalse(self.output.exists())

    def wizard(self, tail):
        answers=['demo','192.0.2.10','eth0','10.79.0.1','192.0.2.20','ens3','10.79.0.2',
                 '1200','20','15','3600']+tail+['no']
        with mock.patch.object(pair.base,'prompt',side_effect=answers):
            return pair.validate_spec(pair.wizard(self.spec['binary_sha256']))

    def test_wizard_fec_modes_and_low_cap(self):
        adaptive=self.wizard(['adaptive','10','20'])
        self.assertEqual(adaptive['fec_mode'],'adaptive')
        self.assertEqual(adaptive['fec_max_percent'],10)
        self.assertEqual(adaptive['fec_percent'],10)
        fixed=self.wizard(['fixed','50','35','100'])
        self.assertEqual(fixed['fec_percent'],35)
        self.assertEqual(fixed['fec_block_ms'],100)
        off=self.wizard(['off'])
        self.assertEqual(off['fec_mode'],'off')

    def test_wizard_refuses_unknown_mode_and_over_cap_target(self):
        for tail in (['unknown'],['fixed','25','26'],['adaptive','0'],['adaptive','25','4']):
            with self.subTest(tail=tail):
                with self.assertRaises(pair.base.PairError):self.wizard(tail)

    def test_old_spec_remains_l3_only(self):
        spec = self.generate()
        for role in ('origin', 'egress'):
            config = pair.endpoint_config(spec, role)
            self.assertNotIn('port_forwards', config)
            self.assertNotIn('forward_idle_seconds', config)

    def test_forward_ports_relay_and_protocols_match(self):
        self.spec['forwards'] = [dict(iran_port=12055, foreign_port=18082, protocol='both'),
                                 dict(iran_port=12056, foreign_port=18082, protocol='tcp')]
        spec = self.generate()
        self.assertEqual(pair.check_pair(str(self.output)), spec)
        a, b = [pair.endpoint_config(spec, role) for role in ('origin', 'egress')]
        self.assertEqual(len(a['port_forwards']), 3)
        self.assertEqual(len(b['port_forwards']), 2)
        relay = spec['forwards'][0]['relay_port']
        self.assertNotEqual(relay, 18082)
        self.assertEqual(relay, spec['forwards'][1]['relay_port'])
        self.assertEqual(a['forward_idle_seconds'], 180)
        for rule in a['port_forwards']:
            self.assertEqual(rule['target'], '10.79.0.2:' + str(relay))
            self.assertTrue(rule['listen'].startswith('0.0.0.0:'))
        for rule in b['port_forwards']:
            self.assertEqual(rule['listen'], '10.79.0.2:' + str(relay))
            self.assertEqual(rule['target'], '127.0.0.1:18082')
        self.assertEqual(pair.validate_spec(spec), spec)
        self.assertIn('no socat needed', pair.readme(spec).decode())

    def test_invalid_forward_fields_and_overlapping_listeners_rejected(self):
        baseline = dict(iran_port=12055, foreign_port=18082, protocol='tcp')
        invalid = [dict(baseline, **{field: value})
                   for field in ('iran_port', 'foreign_port', 'relay_port')
                   for value in (True, '12055', 1, 65536, 12055.0)]
        invalid += [dict(baseline, protocol=p) for p in ('icmp', '', None, ['tcp'])]
        invalid += [dict(baseline, relay_port=18082), dict(baseline, extra='field')]
        for mapping in invalid:
            with self.subTest(mapping=mapping), self.assertRaises(pair.base.PairError):
                pair.validate_spec(dict(self.spec, forwards=[mapping]))
        for mappings in ([baseline, baseline], [dict(baseline, protocol='both'), baseline],
                         [dict(baseline, relay_port=40000), dict(baseline, iran_port=12056, relay_port=40001)],
                         [dict(baseline, relay_port=40000), dict(baseline, iran_port=12056, foreign_port=18083, relay_port=40000)]):
            with self.subTest(mappings=mappings), self.assertRaises(pair.base.PairError):
                pair.validate_spec(dict(self.spec, forwards=mappings))
        for forwards in (None, {}, 'tcp'):
            with self.assertRaises(pair.base.PairError):
                pair.validate_spec(dict(self.spec, forwards=forwards))

    def test_forward_rule_limit_and_idle_boundaries(self):
        mappings = [dict(iran_port=12000+i, foreign_port=18082, protocol='both') for i in range(16)]
        spec = pair.validate_spec(dict(self.spec, forwards=mappings, forward_idle_seconds=10))
        self.assertEqual(len(pair.endpoint_config(spec, 'origin')['port_forwards']), 32)
        self.assertEqual(pair.validate_spec(dict(spec, forward_idle_seconds=3600))['forward_idle_seconds'], 3600)
        for value in (9, 3601, True, '180', 180.0):
            with self.assertRaises(pair.base.PairError):
                pair.validate_spec(dict(self.spec, forward_idle_seconds=value))
        mappings.append(dict(iran_port=13000, foreign_port=18082, protocol='tcp'))
        with self.assertRaises(pair.base.PairError):
            pair.validate_spec(dict(self.spec, forwards=mappings))

    def test_forward_prompt_multiple_rules_and_rejection(self):
        with mock.patch.object(pair.base, 'prompt', side_effect=['yes', '12055', '18082', 'both', 'yes', '12056', '18083', 'udp', 'no']):
            rules = pair.prompt_forwards()
        self.assertEqual(len(rules), 2)
        for answer in ('maybe', 'true'):
            with mock.patch.object(pair.base, 'prompt', return_value=answer), self.assertRaises(pair.base.PairError):
                pair.prompt_forwards()

    def test_separate_pairs_have_independent_keys_and_tuns(self):
        self.generate()
        old = (self.output/'origin/icmp.key').read_bytes()
        self.spec['pair_id']='other'
        spec = pair.generate(self.spec, str(self.root/'other'))
        self.assertNotEqual(old, (self.root/'other/origin/icmp.key').read_bytes())
        first = json.loads((self.output/'origin/direct-icmp.json').read_text())
        self.assertNotEqual(first['tun_name'], spec['origin']['tun_name'])

    def test_existing_output_never_overwritten(self):
        self.generate()
        before = (self.output/'origin/icmp.key').read_bytes()
        with self.assertRaises(pair.base.PairError): self.generate()
        self.assertEqual(before, (self.output/'origin/icmp.key').read_bytes())

    def test_symlink_parent_rejected(self):
        link=self.root/'link';link.symlink_to(self.root, target_is_directory=True)
        with self.assertRaises(OSError): pair.generate(self.spec, str(link/'bad'))

    def test_matching_key_required(self):
        self.generate()
        (self.output/'egress/icmp.key').write_text('f'*64+'\n')
        with self.assertRaises(pair.base.PairError): pair.check_pair(str(self.output))

    def test_public_permissions_refused(self):
        self.generate();(self.output/'origin/icmp.key').chmod(0o644)
        with self.assertRaises(pair.base.PairError): pair.check_pair(str(self.output))

    def test_hardlink_refused(self):
        self.generate();os.link(self.output/'origin/icmp.key', self.root/'key')
        with self.assertRaises(pair.base.PairError): pair.check_pair(str(self.output))

    def test_unknown_config_field_rejected(self):
        self.spec['dns_proxy']=True
        with self.assertRaises(pair.base.PairError): self.generate()

    def test_bad_id_injection_refused(self):
        for bad in ('../x', 'a;id', 'a%u', 'a b', 'a\nx', '-x', 'a'*25):
            with self.subTest(bad=bad):
                self.spec['pair_id']=bad
                with self.assertRaises(pair.base.PairError): self.generate()

    def test_ipv6_and_same_peer_refused(self):
        for ip in ('::1','192.0.2.10','127.0.0.1','224.0.0.1'):
            with self.subTest(ip=ip):
                self.spec['egress']['real_ip']=ip
                with self.assertRaises(pair.base.PairError): self.generate()

    def test_private_prefixes_mirror_and_route_only_explicit(self):
        self.spec['origin']['cidrs']=['10.80.0.0/24'];self.spec['egress']['cidrs']=['10.81.0.0/24']
        self.generate()
        a=json.loads((self.output/'origin/direct-icmp.json').read_text())
        b=json.loads((self.output/'egress/direct-icmp.json').read_text())
        self.assertEqual(a['local_cidrs'],b['peer_cidrs'])
        self.assertEqual(a['peer_cidrs'],b['local_cidrs'])

    def test_dangerous_routes_refused(self):
        for routes in (['0.0.0.0/0'],['8.8.8.0/24'],['10.79.0.0/24'],['10.80.0.1/24'],['10.80.0.0/24']*2):
            with self.subTest(routes=routes):
                self.spec['origin']['cidrs']=routes
                with self.assertRaises(pair.base.PairError): self.generate()

    def test_duplicate_json_keys_refused(self):
        with self.assertRaises(pair.base.PairError): pair.base.strict_json(b'{"a":1,"a":2}')
        with self.assertRaises(manager.ManageError): manager.strict_json(b'{"a":1,"a":2}')

    def test_boundaries_and_bool_integer_refused(self):
        for key,value in [('mtu',575),('mtu',1401),('poll_ms',0),('timeout_seconds',True),('rekey_seconds',59)]:
            spec=copy.deepcopy(self.spec);spec[key]=value
            with self.subTest(key=key,value=value):
                with self.assertRaises(pair.base.PairError):pair.validate_spec(spec)

    def test_hash_manifest_required(self):
        for hashes in ({}, {'amd64':'x'*64,'arm64':'b'*64}, {'amd64':'a'*64}):
            self.spec['binary_sha256']=hashes
            with self.assertRaises(pair.base.PairError):self.generate()

    def test_manifest_wrong_release_refused(self):
        path=self.root/'manifest.json';path.write_text(json.dumps({'version':'3.7.0-preview.6','binary_sha256':self.spec['binary_sha256']}))
        with self.assertRaises(pair.base.PairError):pair.binary_manifest(path)

    def test_manager_offline_bundle_validation(self):
        self.generate()
        metadata, files=manager.load_bundle(self.output/'origin')
        self.assertEqual(metadata['role'],'origin')
        with mock.patch.object(manager,'systemctl',side_effect=AssertionError('host command forbidden')):
            manager.execute('check-bundle', self.output/'origin', metadata, files)

    def test_manager_tampered_config_refused(self):
        self.generate();(self.output/'origin/direct-icmp.json').write_text('{}')
        with self.assertRaises(manager.ManageError):manager.load_bundle(self.output/'origin')

    def test_manager_path_escape_refused(self):
        self.generate();path=self.output/'origin/endpoint.json'
        data=json.loads(path.read_text());data['install_dir']='/etc/ssh';path.write_text(json.dumps(data))
        with self.assertRaises(manager.ManageError):manager.load_bundle(self.output/'origin')

    def test_manager_additional_file_refused(self):
        self.generate();(self.output/'origin/extra').touch()
        with self.assertRaises(manager.ManageError):manager.load_bundle(self.output/'origin')

    def test_wrong_binary_hash_rejected_before_execution(self):
        self.generate();metadata,_=manager.load_bundle(self.output/'origin')
        raw=bytearray(128);raw[:6]=b'\x7fELF\x02\x01';struct.pack_into('<H',raw,18,183)
        binary=self.root/'binary';binary.write_bytes(raw)
        with mock.patch.object(platform,'machine',return_value='arm64'), mock.patch.object(subprocess,'check_output',side_effect=AssertionError('must not run')):
            with self.assertRaisesRegex(manager.ManageError,'SHA256'):manager.binary_bytes(binary,metadata)

    def test_wrong_binary_architecture_refused_even_correct_hash(self):
        self.generate();metadata,_=manager.load_bundle(self.output/'origin')
        raw=bytearray(128);raw[:6]=b'\x7fELF\x02\x01';struct.pack_into('<H',raw,18,183)
        binary=self.root/'binary';binary.write_bytes(raw);metadata['binary_sha256']['amd64']=hashlib.sha256(raw).hexdigest()
        with mock.patch.object(platform,'machine',return_value='amd64'):
            with self.assertRaisesRegex(manager.ManageError,'architecture'):manager.binary_bytes(binary,metadata)

    def test_manager_no_root_no_mutation(self):
        self.generate();metadata,files=manager.load_bundle(self.output/'origin')
        with mock.patch.object(os,'geteuid',return_value=1000), mock.patch.object(platform,'system',return_value='Linux'),mock.patch.object(manager,'lock',side_effect=AssertionError('no mutation')):
            with self.assertRaises(manager.ManageError):manager.execute('start',self.output/'origin',metadata,files)

    def test_manager_restart_scoped_and_status_exit_propagated(self):
        self.generate(); metadata, files = manager.load_bundle(self.output/'origin')
        with mock.patch.object(os, 'geteuid', return_value=0), mock.patch.object(platform, 'system', return_value='Linux'), \
             mock.patch.object(manager, 'lock', side_effect=contextlib.nullcontext), \
             mock.patch.object(manager, 'verify_installed') as verify, \
             mock.patch.object(manager, 'systemctl', return_value=subprocess.CompletedProcess([], 3)) as ctl:
            manager.execute('restart', self.output/'origin', metadata, files)
            ctl.assert_called_once_with('restart', metadata['unit_name'])
            verify.assert_called_once_with(metadata, files)
            self.assertEqual(manager.execute('status', self.output/'origin', metadata, files), 3)
        with mock.patch.object(manager, 'load_bundle', return_value=(metadata, files)), \
             mock.patch.object(manager, 'execute', return_value=3):
            self.assertEqual(manager.main(['status', '--endpoint', str(self.output/'origin')]), 3)

    def test_manager_info_includes_forwarding_but_never_secret_fields(self):
        self.spec['forwards'] = [dict(iran_port=12055, foreign_port=18082, protocol='both')]
        self.generate(); metadata, files = manager.load_bundle(self.output/'origin')
        config = json.loads(files['direct-icmp.json'])
        config['secret'] = 'private-test-value'
        config['port_forwards'][0]['password'] = 'private-test-value'
        files['direct-icmp.json'] = json.dumps(config).encode()
        stream = io.StringIO()
        with mock.patch.object(manager, 'systemctl', side_effect=AssertionError('no host commands')), contextlib.redirect_stdout(stream):
            self.assertEqual(manager.execute('info', self.output/'origin', metadata, files), 0)
        result = json.loads(stream.getvalue())
        self.assertEqual(result['pair_id'], 'demo')
        self.assertEqual(len(result['config']['port_forwards']), 2)
        self.assertNotIn('key_file', stream.getvalue())
        self.assertNotIn('private-test-value', stream.getvalue())
        self.assertNotIn(files['icmp.key'].decode().strip(), stream.getvalue())

    def test_manager_unknown_action_never_touches_host(self):
        with mock.patch.object(manager, 'lock', side_effect=AssertionError('no host command')), self.assertRaises(manager.ManageError):
            manager.execute('anything', self.output, {}, {})

    def test_unit_is_independent_and_has_no_tls_or_default_route(self):
        spec=self.generate();unit=pair.service(spec,'origin').decode()
        self.assertIn('-direct-icmp-config',unit);self.assertNotIn('-cert',unit)
        self.assertIn('CAP_NET_ADMIN CAP_NET_RAW',unit)
        self.assertNotIn('ExecStartPre',unit);self.assertNotIn('iptables',unit)
        self.assertNotEqual(pair.unit_name(spec,'origin'),pair.unit_name(spec,'egress'))

    def test_rekey_window_must_exceed_idle_timeout(self):
        self.spec['timeout_seconds'] = 60
        self.spec['rekey_seconds'] = 120
        with self.assertRaises(pair.base.PairError):self.generate()

    def test_manager_extra_service_directive_refused_even_with_matching_hash(self):
        self.generate();folder=self.output/'origin';path=folder/'endpoint.json'
        data=json.loads(path.read_text());unit=folder/data['unit_name']
        unit.write_text(unit.read_text()+'Environment=LD_PRELOAD=/tmp/evil.so\n')
        data['files'][unit.name]=hashlib.sha256(unit.read_bytes()).hexdigest();path.write_text(json.dumps(data))
        with self.assertRaisesRegex(manager.ManageError,'directives'):manager.load_bundle(folder)

    def test_manager_reordered_unit_sections_refused_even_with_matching_hash(self):
        self.generate();folder=self.output/'origin';path=folder/'endpoint.json'
        data=json.loads(path.read_text());unit=folder/data['unit_name']
        original=unit.read_text()
        # Retain every old line, but place the security setting under [Install].
        altered=original.replace('NoNewPrivileges=yes\n','').replace('[Install]\n','[Install]\nNoNewPrivileges=yes\n')
        self.assertEqual(sorted(original.splitlines()), sorted(altered.splitlines()))
        unit.write_text(altered)
        data['files'][unit.name]=hashlib.sha256(unit.read_bytes()).hexdigest();path.write_text(json.dumps(data))
        with self.assertRaisesRegex(manager.ManageError,'ordering'):manager.load_bundle(folder)

    def test_generated_manager_accepts_explicit_endpoint_offline(self):
        self.generate()
        result=subprocess.run([sys.executable,'-I',str(HERE/'direct-icmp-manage.py'),'check-bundle','--endpoint',str(self.output/'origin')],capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)

    def test_cli_check_reports_no_key(self):
        self.generate()
        result=subprocess.run([sys.executable,'-I',str(HERE/'direct-icmp-pair.py'),'--check-pair',str(self.output)],capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertNotIn((self.output/'origin/icmp.key').read_text().strip(),result.stdout+result.stderr)

    def test_cli_spec_works_without_sidecar_when_hashes_supplied(self):
        path=self.root/'spec.json';path.write_text(json.dumps(self.spec))
        result=subprocess.run([sys.executable,'-I',str(HERE/'direct-icmp-pair.py'),'--spec',str(path),'--output',str(self.output)],capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)

if __name__=='__main__':unittest.main()
