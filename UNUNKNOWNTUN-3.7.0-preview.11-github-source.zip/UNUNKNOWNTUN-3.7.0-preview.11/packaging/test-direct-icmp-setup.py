#!/usr/bin/env python3
"""Offline code-pairing, host selection, scoped rollback and diagnostic tests."""
import base64
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock
import zlib

sys.dont_write_bytecode = True
HERE = Path(__file__).parent
loader = importlib.util.spec_from_file_location('icmp_setup_tests_target', HERE / 'direct-icmp-setup.py')
setup = importlib.util.module_from_spec(loader)
loader.loader.exec_module(setup)
pair, doctor = setup.pair, setup.doctor


def sample():
    return {'pair_id': 'quick', 'binary_sha256': {'amd64': 'a' * 64, 'arm64': 'b' * 64},
            'origin': {'real_ip': '192.0.2.10', 'interface': 'eth0', 'inner_ip': '10.79.1.1', 'pool_cidr': '10.79.1.0/28'},
            'egress': {'real_ip': '192.0.2.20', 'interface': 'ens3', 'inner_ip': '10.79.2.1', 'pool_cidr': '10.79.2.0/28'},
            'source_rotation': 'round-robin'}


class PairCodeTests(unittest.TestCase):
    def setUp(self):
        self.spec = sample()
        self.key = b'c' * 64 + b'\n'
        self.now = 1800000000
        self.code = setup.encode_code(self.spec, self.key, self.now)

    def decode(self, code=None, now=None, hashes=None):
        return setup.decode_code(code or self.code, hashes or self.spec['binary_sha256'], self.now if now is None else now)

    def mutate(self, function):
        compressed = base64.urlsafe_b64decode(self.code.split('.')[1] + '===')
        value = json.loads(zlib.decompress(compressed))
        function(value)
        compressed = zlib.compress(json.dumps(value).encode())
        return 'GDTICMP3.' + base64.urlsafe_b64encode(compressed).decode().rstrip('=') + '.' + hashlib.sha256(compressed).hexdigest()

    def test_roundtrip_matching_endpoint_configs(self):
        spec, key = self.decode()
        self.assertEqual(key, self.key)
        a, b = pair.endpoint_config(spec, 'origin'), pair.endpoint_config(spec, 'egress')
        self.assertEqual(a['local_pool_cidr'], b['peer_pool_cidr'])
        self.assertEqual(a['peer_pool_cidr'], b['local_pool_cidr'])
        self.assertEqual(a['source_rotation'], 'round-robin')
        self.assertLess(len(self.code), 2000)

    def test_forward_mapping_and_relay_survive_pairing_code(self):
        self.spec['forwards'] = [dict(iran_port=12055, foreign_port=18082, protocol='both')]
        self.spec['forward_idle_seconds'] = 300
        spec, key = self.decode(setup.encode_code(self.spec, self.key, self.now))
        self.assertEqual(spec['forward_idle_seconds'], 300)
        self.assertEqual(key, self.key)
        a, b = [pair.endpoint_config(spec, role) for role in ('origin', 'egress')]
        self.assertEqual(a['port_forwards'][0]['target'], b['port_forwards'][0]['listen'])
        self.assertNotEqual(b['port_forwards'][0]['listen'].rsplit(':', 1)[1], '18082')

    def test_copy_error_fails_before_config_use(self):
        changed = self.code[:-1] + ('0' if self.code[-1] != '0' else '1')
        with self.assertRaises(pair.base.PairError):
            self.decode(changed)

    def test_local_release_hashes_are_not_trusted_from_code(self):
        with self.assertRaises(pair.base.PairError):
            self.decode(hashes={'amd64': 'd' * 64, 'arm64': 'b' * 64})

    def test_version_expiry_clock_and_invalid_key_rejected(self):
        for change in (lambda v: v.update(version='old'), lambda v: v.update(issued_at=True),
                       lambda v: v.update(expires_at=v['expires_at'] + 1), lambda v: v.update(key='0' * 64),
                       lambda v: v.update(key='password'), lambda v: v.update(command='rm -rf /')):
            with self.subTest(change=change), self.assertRaises(pair.base.PairError):
                self.decode(self.mutate(change))
        for now in (self.now - 301, self.now + 86401):
            with self.assertRaises(pair.base.PairError):
                self.decode(now=now)

    def test_compression_bomb_and_trailing_compressed_data_rejected(self):
        for data in (zlib.compress(b'A' * (setup.PAYLOAD_LIMIT + 1)),
                     zlib.compress(b'{}') + zlib.compress(b'{}')):
            code = 'GDTICMP3.' + base64.urlsafe_b64encode(data).decode().rstrip('=') + '.' + hashlib.sha256(data).hexdigest()
            with self.assertRaises(pair.base.PairError):
                self.decode(code)

    def test_duplicate_json_fields_rejected(self):
        data = zlib.compress(b'{"format":1,"format":2}')
        code = 'GDTICMP3.' + base64.urlsafe_b64encode(data).decode().rstrip('=') + '.' + hashlib.sha256(data).hexdigest()
        with self.assertRaises(pair.base.PairError):
            self.decode(code)

    def test_ranges_and_commands_cannot_escape_validation(self):
        changes = (lambda v: v['spec'].update(pair_id='../ssh'),
                   lambda v: v['spec']['origin'].update(pool_cidr='0.0.0.0/0'),
                   lambda v: v['spec']['origin'].update(interface='eth0;id'),
                   lambda v: v['spec'].update(binary_path='/bin/sh'))
        for change in changes:
            with self.assertRaises(pair.base.PairError):
                self.decode(self.mutate(change))

    def test_supplied_key_and_doctor_survive_private_generation(self):
        with tempfile.TemporaryDirectory(dir=str(Path(tempfile.gettempdir()).resolve())) as tmp:
            output = Path(tmp) / 'pair'
            pair.generate(self.spec, str(output), key=self.key)
            pair.check_pair(str(output))
            for role in ('origin', 'egress'):
                metadata, files = setup.manager.load_bundle(output / role)
                self.assertEqual(files['icmp.key'], self.key)
                self.assertIn('doctor.py', metadata['files'])
                unit = files[metadata['unit_name']].decode()
                self.assertIn('RuntimeDirectory=ununknowntun-icmp-rr\n', unit)
                self.assertIn('RuntimeDirectoryPreserve=yes\n', unit)
                self.assertIn('ReadWritePaths=/run/ununknowntun-icmp-rr\n', unit)
            with self.assertRaises(pair.base.PairError):
                pair.generate(self.spec, str(output), key=self.key)
            self.assertEqual((output / 'origin/icmp.key').read_bytes(), self.key)


class PoolValidationTests(unittest.TestCase):
    def test_off_without_pools_remains_compatible(self):
        spec = sample()
        for role in ('origin', 'egress'):
            del spec[role]['pool_cidr']
        spec['source_rotation'] = 'off'
        self.assertEqual(pair.validate_spec(spec)['source_rotation'], 'off')

    def test_both_pools_mandatory_membership_overlap_and_routed_ranges(self):
        changes = (lambda s: s['origin'].pop('pool_cidr'),
                   lambda s: s['origin'].update(pool_cidr='10.79.1.0/24'),
                   lambda s: s['origin'].update(inner_ip='10.79.1.0'),
                   lambda s: s['origin'].update(inner_ip='10.79.1.15'),
                   lambda s: s['origin'].update(inner_ip='10.80.1.1'),
                   lambda s: s['origin'].update(cidrs=['10.79.1.0/28']),
                   lambda s: s['egress'].update(inner_ip='10.79.1.2', pool_cidr='10.79.1.0/28'),
                   lambda s: s.update(source_rotation='random-per-packet'))
        for change in changes:
            spec = sample(); change(spec)
            with self.subTest(spec=spec), self.assertRaises(pair.base.PairError):
                pair.validate_spec(spec)

    def test_minimum_and_maximum_pool_sizes(self):
        for prefix in (26, 30):
            spec = sample()
            spec['origin']['pool_cidr'] = '10.79.1.0/' + str(prefix)
            spec['egress']['pool_cidr'] = '10.79.2.0/' + str(prefix)
            self.assertEqual(pair.validate_spec(spec)['source_rotation'], 'round-robin')


class HostAndTransactionTests(unittest.TestCase):
    def test_paired_setup_uses_the_local_interface_and_installed_hashed_doctor(self):
        spec, key = sample(), b'c' * 64 + b'\n'
        built = []
        temporary_directory = tempfile.TemporaryDirectory
        def staging(**kwargs):
            return temporary_directory(prefix=kwargs['prefix'], dir=str(Path(tempfile.gettempdir()).resolve()))
        def installed(folder, metadata, contents, binary):
            built.append((metadata, json.loads(contents['direct-icmp.json']), contents['icmp.key']))
            self.assertEqual(hashlib.sha256(contents['doctor.py']).hexdigest(), metadata['files']['doctor.py'])
        with mock.patch.object(setup, 'dependencies'), mock.patch.object(setup.doctor, 'collect', return_value={}), \
             mock.patch.object(setup.doctor, 'display'), mock.patch.object(setup, 'start_installed', side_effect=installed), \
             mock.patch.object(setup.tempfile, 'TemporaryDirectory', side_effect=staging), \
             mock.patch.object(setup, 'discover_local', side_effect=[{'real_ip':'192.0.2.20','interface':'ens3'}, {'real_ip':'192.0.2.10','interface':'ens18'}]):
            foreign = setup.setup('egress', spec, key, '/trusted-binary')
            imported, imported_key = setup.decode_code(setup.encode_code(foreign, key), spec['binary_sha256'])
            setup.setup('origin', imported, imported_key, '/trusted-binary')
        self.assertEqual([item[1]['interface'] for item in built], ['ens3', 'ens18'])
        self.assertEqual(built[0][1]['local_pool_cidr'], built[1][1]['peer_pool_cidr'])
        self.assertEqual(built[0][2], built[1][2])

    def test_missing_required_dependency_stops_before_install(self):
        with mock.patch.object(setup.platform, 'system', return_value='Linux'), mock.patch.object(setup.os, 'geteuid', return_value=0), \
             mock.patch.object(setup.shutil, 'which', side_effect=lambda name, **kw: None if name == 'nft' else '/usr/bin/' + name), \
             self.assertRaisesRegex(pair.base.PairError, 'nft'):
            setup.dependencies()

    def test_host_detection_and_wrong_host_refusal(self):
        answers = [[{'dev': 'ens3', 'prefsrc': '192.0.2.20'}],
                   [{'addr_info': [{'family': 'inet', 'local': '192.0.2.20'}]}]]
        with mock.patch.object(setup, 'command_json', side_effect=answers):
            self.assertEqual(setup.discover_local('192.0.2.10', '192.0.2.20')['interface'], 'ens3')
        with mock.patch.object(setup, 'command_json', side_effect=answers), self.assertRaises(pair.base.PairError):
            setup.discover_local('192.0.2.10', '192.0.2.99')

    def test_route_source_must_be_assigned(self):
        with mock.patch.object(setup, 'command_json', side_effect=[[{'dev': 'ens3', 'prefsrc': '192.0.2.20'}], [{'addr_info': []}]]):
            with self.assertRaises(pair.base.PairError):
                setup.discover_local('192.0.2.10')

    def test_foreign_wizard_never_asks_for_peer_interface_or_manual_file(self):
        answers = ['192.0.2.10', 'quick', '10.79.1.0/28', '10.79.2.0/28', '1200', 'adaptive', 'yes', '12055', '18082', 'both', 'no']
        with mock.patch.object(pair.base, 'prompt', side_effect=answers), mock.patch.object(setup, 'discover_local', return_value={'real_ip':'192.0.2.20','interface':'ens3'}):
            spec = setup.foreign_spec(sample()['binary_sha256'])
        self.assertEqual(spec['egress']['interface'], 'ens3')
        self.assertEqual(spec['source_rotation'], 'round-robin')
        self.assertEqual(spec['forwards'][0]['iran_port'], 12055)
        self.assertEqual(spec['forwards'][0]['foreign_port'], 18082)

    def test_busy_foreign_relay_replaced_and_carried_in_code(self):
        spec = sample()
        spec['forwards'] = [dict(iran_port=12055, foreign_port=18082, protocol='both'),
                            dict(iran_port=12056, foreign_port=18082, protocol='tcp')]
        original = pair.validate_spec(spec)['forwards'][0]['relay_port']
        calls = []
        def available(port, protocols):
            calls.append((port, protocols))
            return port != original
        result = setup.select_available_relays(spec, available)
        relays = {rule['relay_port'] for rule in result['forwards']}
        self.assertEqual(len(relays), 1)
        self.assertNotIn(original, relays)
        self.assertEqual(calls[0], (original, {'tcp', 'udp'}))
        decoded, _ = setup.decode_code(setup.encode_code(result, b'c'*64+b'\n'), spec['binary_sha256'])
        self.assertEqual(decoded, result)

    def test_no_available_relay_stops_without_install(self):
        spec = sample(); spec['forwards'] = [dict(iran_port=12055, foreign_port=18082, protocol='both')]
        with mock.patch.object(setup, 'start_installed', side_effect=AssertionError('no install')), \
             self.assertRaisesRegex(pair.base.PairError, 'relay port'):
            setup.select_available_relays(spec, lambda port, protocols: False)

    def test_l3_only_setup_never_probes_ports(self):
        for spec in (sample(), dict(sample(), forwards=[])):
            with mock.patch.object(setup, 'relay_available', side_effect=AssertionError('L3 only must not bind ports')):
                self.assertEqual(setup.select_available_relays(spec), pair.validate_spec(spec))

    def test_relay_probe_closes_sockets_on_success_and_failure(self):
        for failed in (False, True):
            sockets = [mock.MagicMock(), mock.MagicMock()]
            if failed:
                sockets[1].bind.side_effect = OSError('busy')
            with mock.patch.object(setup.socket, 'socket', side_effect=sockets):
                self.assertEqual(setup.relay_available(45000, {'tcp', 'udp'}), not failed)
            for sock in sockets:
                sock.bind.assert_called_once_with(('127.0.0.1', 45000))
                sock.close.assert_called_once_with()

    def test_failed_start_rolls_back_only_new_endpoint(self):
        calls = []
        def execute(action, *args):
            calls.append(action)
            if action == 'start':
                raise subprocess.CalledProcessError(1, ['systemctl'])
        with mock.patch.object(setup.manager, 'execute', side_effect=execute), self.assertRaises(subprocess.CalledProcessError):
            setup.start_installed(Path('/unused'), {'unit_name':'unit'}, {}, '/unused')
        self.assertEqual(calls, ['install', 'start', 'uninstall'])

    def test_existing_endpoint_install_failure_never_uninstalls(self):
        calls = []
        def execute(action, *args):
            calls.append(action)
            raise setup.manager.ManageError('Endpoint already exists')
        with mock.patch.object(setup.manager, 'execute', side_effect=execute), self.assertRaises(setup.manager.ManageError):
            setup.start_installed(Path('/unused'), {'unit_name':'unit'}, {}, '/unused')
        self.assertEqual(calls, ['install'])

    def test_restart_during_initial_start_rolls_back(self):
        responses = [subprocess.CompletedProcess([], 0), subprocess.CompletedProcess([], 0, stdout='1\n')]
        with mock.patch.object(setup.manager, 'execute') as execute, mock.patch.object(setup.time, 'sleep'), mock.patch.object(setup.subprocess, 'run', side_effect=responses), self.assertRaises(pair.base.PairError):
            setup.start_installed(Path('/unused'), {'unit_name':'unit'}, {}, '/unused')
        self.assertEqual([c.args[0] for c in execute.call_args_list], ['install', 'start', 'uninstall'])


class DoctorTests(unittest.TestCase):
    def test_manager_doctor_does_not_write_bytecode_into_strict_bundle(self):
        # Run the real doctor action in a fresh interpreter without -B. Only
        # host mutation/inspection boundaries are replaced; the import is real.
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / 'doctor.py').write_bytes((HERE / 'direct-icmp-doctor.py').read_bytes())
            source = (HERE / 'direct-icmp-manage.py').read_text().split('if __name__ == "__main__":')[0]
            harness = '''
platform.system = lambda: "Linux"
os.geteuid = lambda: 0
lock = contextlib.nullcontext
verify_installed = lambda *args: None
import shutil
shutil.which = lambda *args, **kwargs: None
folder = Path(__file__).parent
metadata = {"install_dir":str(folder),"unit_name":"ununknowntun-direct-icmp-test-origin.service"}
contents = {"direct-icmp.json":b'{"peer_ip":"192.0.2.1","interface":"eth0","tun_name":"gdltesto"}'}
execute("doctor", folder, metadata, contents)
'''
            (folder / 'manage.py').write_text(source + harness)
            result = subprocess.run([sys.executable, '-I', str(folder / 'manage.py')], capture_output=True, text=True, timeout=10)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertEqual({p.name for p in folder.iterdir()}, {'manage.py','doctor.py'})

    def test_rule_matches_are_not_claimed_effective_drop(self):
        text = ':INPUT DROP [0:0]\n-A INPUT -s 192.0.2.10/32 -p icmp -j DROP\n-A INPUT -p tcp -j DROP\n-A OUTPUT -p icmp -j REJECT\n-A INPUT -p icmp -m limit --limit 1/sec -j ACCEPT\n'
        result = doctor.iptables_findings(text, '192.0.2.10')
        self.assertEqual(result['potential_peer_drop_rules'], 1)
        self.assertEqual(result['broad_icmp_or_all_drop_rules'], 1)
        self.assertEqual(result['icmp_or_all_rate_limit_rules'], 1)
        self.assertIn('unknown', result['effective_verdict'])

    def test_read_only_commands_ban_detection_and_unknown_commands(self):
        calls = []
        def runner(command):
            calls.append(command)
            if command == ['fail2ban-client', 'status']:
                return {'state':'ok','text':'Status\nJail list: sshd, custom\n'}
            if command == ['fail2ban-client', 'get', 'sshd', 'banip']:
                return {'state':'ok','text':'192.0.2.10 192.0.2.11'}
            return {'state':'timeout' if command[0] == 'nft' else 'not_installed','text':''}
        report = doctor.collect('192.0.2.10', 'eth0', runner=runner)
        fail = next(x for x in report['checks'] if x['name'] == 'fail2ban')['details']
        self.assertEqual(fail['peer_banned_in'], ['sshd'])
        self.assertEqual(fail['unknown_jails'], 1)
        self.assertTrue(report['read_only'])
        self.assertFalse(report['network_probe_sent'])
        forbidden = {'flush','delete','unbanip','stop','restart','disable','-F','-X','-w'}
        self.assertFalse(any(forbidden.intersection(command) for command in calls))

    def test_unreadable_nft_and_missing_jail_list_are_unknown(self):
        self.assertIn('unknown', doctor.nft_findings('[]', '192.0.2.10')['effective_verdict'])
        report = doctor.collect('192.0.2.10','eth0',runner=lambda args:{'state':'ok','text':'{}'})
        fail = next(x for x in report['checks'] if x['name'] == 'fail2ban')['details']
        self.assertEqual(fail['status_parse'], 'unknown')

    def test_malformed_structured_route_is_unknown_and_other_checks_continue(self):
        bad_values = ({}, {'dev':'eth0'}, [], [None], [1], ['eth0'], [[]], [{}],
                      [{'dev':None}], [{'dev':[]}], [{'dev':'eth0','prefsrc':{}}],
                      [{'dev':'eth0','prefsrc':'not-an-ip'}], [{'dev':'eth0'}, False])
        for value in bad_values:
            with self.subTest(value=value):
                def runner(args):
                    return {'state':'ok','text':json.dumps(value)} if args[0] == 'ip' else {'state':'not_installed','text':''}
                report = doctor.collect('192.0.2.10','eth0',runner=runner)
                route = next(x for x in report['checks'] if x['name'] == 'peer_route')
                self.assertEqual(route['state'], 'unreadable')
                self.assertNotIn('details', route)
                self.assertTrue(any(x['name'] == 'fail2ban' for x in report['checks']))

    def test_valid_route_objects_report_selected_interface(self):
        def runner(args):
            return {'state':'ok','text':'[{"dev":"eth0","prefsrc":"192.0.2.20"}]'} if args[0] == 'ip' else {'state':'not_installed','text':''}
        report = doctor.collect('192.0.2.10','eth0',runner=runner)
        route = next(x for x in report['checks'] if x['name'] == 'peer_route')
        self.assertEqual(route['state'], 'ok')
        self.assertTrue(route['details'][0]['selected_interface_matches'])

    def test_malformed_nft_structure_never_claims_table_absence(self):
        values = ({}, [], {'nftables':{}}, {'nftables':[None]}, {'nftables':[{'rule':None}]},
                  {'nftables':[{'rule':{'expr':None}}]}, {'nftables':[{'table':[]} ]})
        for value in values:
            with self.subTest(value=value):
                result = doctor.nft_findings(json.dumps(value), '192.0.2.10', 'gdltesto')
                self.assertEqual(result['effective_verdict'], 'unknown_unreadable_ruleset')
                self.assertNotIn('matching_name_table_present',result)

    def test_endpoint_object_shape_is_validated(self):
        with tempfile.TemporaryDirectory() as tmp:
            for value in ([], None, {}, {'peer_ip':[],'interface':'eth0'}):
                with self.subTest(value=value):
                    (Path(tmp)/'direct-icmp.json').write_text(json.dumps(value))
                    with self.assertRaises(ValueError):
                        doctor.endpoint_identity(tmp)

    def test_invalid_names_do_not_execute(self):
        for interface, unit in [('eth0;id',None), ('eth0','ssh.service')]:
            with mock.patch.object(doctor,'Runner',side_effect=AssertionError('must validate first')), self.assertRaises(ValueError):
                doctor.collect('192.0.2.10',interface,unit)

    def test_service_events_redact_raw_messages(self):
        secret='DO-NOT-PRINT-PRIVATE-TOKEN'
        def runner(args):
            return {'state':'ok','text':('timeout token='+secret) if args[0]=='journalctl' else '{}'}
        report=doctor.collect('192.0.2.10','eth0','ununknowntun-direct-icmp-demo-origin.service',runner=runner)
        self.assertNotIn(secret,json.dumps(report))
        event=next(x for x in report['checks'] if x['name']=='recent_service_events')['details']
        self.assertEqual(event['timeout'],1)

    def test_rotation_table_name_is_not_an_ownership_claim(self):
        name = 'gdt_icmp_' + hashlib.sha256(b'gdltesto').hexdigest()[:16]
        rules = {'nftables': [{'table': {'family':'ip','name':name}}, {'rule':{'expr':[{'limit':{'rate':1}}]}}]}
        result = doctor.nft_findings(json.dumps(rules), '192.0.2.10', 'gdltesto')
        self.assertTrue(result['matching_name_table_present'])
        self.assertEqual(result['table_ownership'], 'name_only_not_proven')
        self.assertEqual(result['rate_limit_rules'], 1)

    def test_runtime_counters_are_bounded_allowlisted_recent_snapshot(self):
        text = '[direct-icmp/stats] connected=false sent=10 received=2 rejected=1 dropped=3 engine={Handshakes:1 Reconnects:2 AuthFailures:3 LocalSendFailures:4 Secret:do-not-copy}'
        result = doctor.runtime_counters(text)
        self.assertEqual(result['counters']['LocalSendFailures'], 4)
        self.assertEqual(result['counters']['wire_rejected'], 1)
        self.assertFalse(result['counters']['connected'])
        self.assertNotIn('do-not-copy', json.dumps(result))
        self.assertIn('not_live_probe', result['state'])


if __name__ == '__main__':
    unittest.main()
