#!/usr/bin/env python3
"""Editor packaging/CLI checks; all host commands are replaced with harmless stubs."""
from pathlib import Path
import importlib.util
import shlex
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parent.parent
TEMPLATE = ROOT / "packaging/full-installer.template.sh"
SOURCE = TEMPLATE.read_text()
MANAGER = SOURCE.split("<<'CTL'\n", 1)[1].split("\nCTL\n", 1)[0]
DEFINITIONS, DISPATCH = MANAGER.split('\ncommand_name="${1:-help}"', 1)
DISPATCH = '\ncommand_name="${1:-help}"' + DISPATCH


class EditorIntegrationTests(unittest.TestCase):
    def dispatch(self, command):
        script = DEFINITIONS + '''
need_root() { :; }
select_id() { printf '%s\\n' example; }
manager_lock() { echo unexpected-shell-lock >&2; exit 97; }
python3() { printf '<%s>\\n' "$@"; }
INSTALL_DIR=/isolated/opt/ununknowntun
TUNNELS_DIR=/isolated/etc/ununknowntun/tunnels
''' + "\nset -- " + shlex.quote(command) + " example\n" + DISPATCH
        result = subprocess.run(["bash", "-c", script], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        return result.stdout

    def test_edit_commands_use_python_editor_without_shell_lock(self):
        for command, action in (("edit", "menu"), ("edit-show", "show"),
                                ("edit-apply", "apply-update"), ("edit-ip", "ip"),
                                ("edit-ports", "ports"), ("apply-update", "apply-update")):
            with self.subTest(command=command):
                output = self.dispatch(command)
                self.assertEqual(output.splitlines(), [
                    "</isolated/opt/ununknowntun/share/tunnel-editor.py>", f"<{action}>",
                    "<--config-dir>", "</isolated/etc/ununknowntun/tunnels/example>",
                    "<--state-dir>", "</var/lib/ununknowntun/example>",
                ])

    def test_embedded_helpers_match_source_and_compile(self):
        helper_specs = (("access-manager.py", "__ACCESS_MANAGER_SOURCE__", "ACCESS_MANAGER_PY"),
                        ("tunnel-editor.py", "__TUNNEL_EDITOR_SOURCE__", "TUNNEL_EDITOR_PY"),
                        ("editor_tls.py", "__EDITOR_TLS_SOURCE__", "EDITOR_TLS_PY"),
                        ("tunnel-doctor.py", "__TUNNEL_DOCTOR_SOURCE__", "TUNNEL_DOCTOR_PY"),
                        ("profile-validation.py", "__PROFILE_VALIDATION_INSTALLED_SOURCE__", "PROFILE_VALIDATION_PY"))
        expanded = SOURCE
        for name, marker, delimiter in helper_specs:
            with self.subTest(helper=name):
                helper = (ROOT / "packaging" / name).read_text().rstrip()
                self.assertEqual(SOURCE.count(marker), 1)
                self.assertNotIn(delimiter, helper.splitlines())
                compile(helper, name, "exec")
                expanded = expanded.replace(marker, helper)
                embedded = expanded.split("<<'" + delimiter + "'\n", 1)[1].split("\n" + delimiter + "\n", 1)[0]
                self.assertEqual(embedded, helper)
        with tempfile.NamedTemporaryFile(mode="w", suffix=".sh") as stream:
            stream.write(expanded)
            stream.flush()
            result = subprocess.run(["bash", "-n", stream.name], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)

    def test_management_menu_accepts_new_options_and_rejects_out_of_range(self):
        function = SOURCE.split("valid_manage_choice() {", 1)[1].split("\n", 1)[0]
        result = subprocess.run(["bash", "-c", "valid_manage_choice() {" + function + '''
for option in 1 14 15 16 17 18 19 20 21 22 23 24; do valid_manage_choice "$option" || exit 1; done
for option in 0 25 -1 hello; do ! valid_manage_choice "$option" || exit 2; done
'''], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        for entry in ('15) "$CTL_PATH" edit', '16) "$CTL_PATH" edit-apply', '17) "$CTL_PATH" edit-show'):
            self.assertIn(entry, SOURCE)

    def test_version_and_release_pipeline_include_editor(self):
        version = (ROOT / "VERSION").read_text().strip()
        self.assertEqual(version, "3.7.0-preview.11")
        self.assertIn('Version = "' + version + '"', (ROOT / "main.go").read_text())
        pipeline = (ROOT / "packaging/build-complete.sh").read_text()
        for filename in ("test-tunnel-editor.py", "test-editor-tls.py", "test-editor-safety.py", "test-editor-integration.py", "test-entry-migrations.py", "test-tunnel-doctor.py"):
            self.assertIn(filename, pipeline)

    def upgrade_fixture(self):
        spec = importlib.util.spec_from_file_location("editor_upgrade_integration", ROOT / "packaging/test-upgrade.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        fixture = module.UpgradeTests(methodName="runTest")
        fixture.setUp()
        self.addCleanup(fixture.tearDown)
        fixture.prepare(provider="none", with_site=False, accounting=True)
        common = "write_common_files() {" + SOURCE.split("write_common_files() {", 1)[1].split("\n}\n", 1)[0] + "\n}\n"
        safe_setup = common + '''
ensure_service_user() { install -d -m 0755 "$INSTALL_DIR/share"; }
install_binary() { printf '%s\\n' 'upgraded binary' > "$BIN_PATH"; }
setup_time_sync() { :; }
select_resource_profile() { :; }
MOCK_ACTIVE=inactive
'''
        return fixture, safe_setup

    def test_32_upgrade_installs_new_editor_helpers_and_preserves_ledger(self):
        fixture, safe_setup = self.upgrade_fixture()
        ledger = (fixture.state / "access-state.json").read_bytes()
        share = fixture.root / "install/share"
        share.mkdir(parents=True)
        (share / "access-manager.py").write_text("# old 3.2 helper\n")
        old_manager = fixture.root / "bin/ununknowntunctl"
        old_manager.write_text("# old 3.2 manager\n")
        for _ in range(2):
            fixture.shell(safe_setup + "upgrade_existing\n", stdin="y\n")
            for filename in ("access-manager.py", "tunnel-editor.py", "editor_tls.py", "tunnel-doctor.py", "profile-validation.py"):
                self.assertEqual((share / filename).read_text().rstrip(), (ROOT / "packaging" / filename).read_text().rstrip())
            self.assertIn('edit|edit-apply|edit-show|edit-ip|edit-ports|apply-update)', old_manager.read_text())
            self.assertEqual((fixture.state / "access-state.json").read_bytes(), ledger)
        self.assertEqual((share / "tunnel-editor.py").stat().st_mode & 0o777, 0o755)
        self.assertEqual((share / "editor_tls.py").stat().st_mode & 0o777, 0o644)
        self.assertEqual((share / "profile-validation.py").stat().st_mode & 0o777, 0o644)
        # Execute imports from the installed tree, not source-side fixtures:
        # argparse help exits before root checks, locks or service operations.
        result = subprocess.run([sys.executable, "-B", str(share / "tunnel-editor.py"), "--help"], capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("apply-update", result.stdout)
        result = subprocess.run([sys.executable, "-B", str(share / "profile-validation.py"), "path-profile", '{"interval":"2h","count":"3","grace":"5m","legacy":"false"}'], capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        log = fixture.fixture.log.read_text()
        self.assertNotIn("initialize quota=", log)
        self.assertNotIn("systemctl restart", log)
        self.assertNotIn("systemctl start", log)

    def test_failed_32_upgrade_restores_old_helpers_and_manager(self):
        fixture, safe_setup = self.upgrade_fixture()
        ledger = (fixture.state / "access-state.json").read_bytes()
        share = fixture.root / "install/share"
        share.mkdir(parents=True)
        (share / "access-manager.py").write_text("# old 3.2 helper\n")
        old_manager = fixture.root / "bin/ununknowntunctl"
        old_manager.write_text("# old 3.2 manager\n")
        fixture.shell(safe_setup + "patch_upgrade_configuration() { return 1; }\nupgrade_existing\n", expected=1, stdin="y\n")
        self.assertEqual((share / "access-manager.py").read_text(), "# old 3.2 helper\n")
        self.assertEqual(old_manager.read_text(), "# old 3.2 manager\n")
        self.assertFalse((share / "tunnel-editor.py").exists())
        self.assertFalse((share / "editor_tls.py").exists())
        self.assertFalse((share / "tunnel-doctor.py").exists())
        self.assertFalse((share / "profile-validation.py").exists())
        self.assertEqual((fixture.state / "access-state.json").read_bytes(), ledger)

    def test_doctor_commands_use_bounded_helper_without_shell_lock(self):
        for command in ("doctor", "scan"):
            self.assertEqual(self.dispatch(command).splitlines(), ["</isolated/opt/ununknowntun/share/tunnel-doctor.py>", "<--config-dir>", "</isolated/etc/ununknowntun/tunnels/example>"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
