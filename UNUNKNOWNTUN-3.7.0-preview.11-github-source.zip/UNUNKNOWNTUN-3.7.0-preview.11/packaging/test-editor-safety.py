#!/usr/bin/env python3
"""Independent editor boundary tests; no live service/network operation occurs."""
import base64
import contextlib
import copy
import hashlib
import hmac
import importlib.util
import io
import json
import os
from pathlib import Path
import shlex
import subprocess
import tempfile
import time
import unittest
from unittest import mock


spec = importlib.util.spec_from_file_location("safety_editor", Path(__file__).with_name("tunnel-editor.py"))
editor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(editor)


class EditorSafetyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="ununknowntun-editor-safety-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.directory = self.root / "tunnels" / "sample"
        self.state = self.root / "state" / "sample"
        self.available, self.enabled = self.root / "nginx/available", self.root / "nginx/enabled"
        for directory in (self.directory, self.state, self.available, self.enabled):
            directory.mkdir(parents=True)
        self.env = {"ROLE": "origin", "TUNNEL_ID": "sample", "TUNNEL_NAME": "Sample",
                    "PAIR_ID": "0123456789abcdef", "FOREIGN_IP": "203.0.113.2", "IRAN_IP": "203.0.113.1",
                    "FOREIGN_DOMAIN": "foreign.example", "FOREIGN_PORTS": "443,8443", "IRAN_PROXY_PROVIDER": "none",
                    "FOREIGN_PROXY_PROVIDER": "none", "LOCAL_PORTS": "21001", "IRAN_ENTRY_PORTS": "21001",
                    "IRAN_ENTRY_PATH": "/original-client-websocket", "IRAN_ENTRY_DOMAIN": "", "TARGET_PORT": "19000", "NGINX_SITE": ""}
        self.accounts = {"version": 1, "total_quota_bytes": 200_000_000_000, "accounts": [
            {"id": "default", "name": "Default", "listen": "0.0.0.0:21001", "quota_bytes": 2_000_000_000, "enabled": True},
            {"id": "alice", "name": "Alice", "listen": "0.0.0.0:21002", "quota_bytes": 3_000_000_000, "enabled": False}]}
        self.routes = {"alice": "/gdt-c/customer-route-0123456789abcdef"}
        self.token = "a" * 64
        self.script = "#!/bin/sh\n" + " \\\n".join([
            "exec /usr/local/bin/ununknowntun", "  -mode origin",
            "  -connect 203.0.113.2:443,203.0.113.2:8443",
            "  -listen 0.0.0.0:21001", "  -target 127.0.0.1:19000",
            "  -ws-host foreign.example", "  -sni foreign.example",
            "  -ws-path /transport-websocket-path", "  -h2-path /transport-http2-path",
            "  -pad 0.22", "  -access-config /etc/ununknowntun/tunnels/sample/access.json",
            "  -access-state /var/lib/ununknowntun/sample/access-state.json", "  -stats 5s"]) + "\n"
        self.write_fixture()
        self.instance = self.make_editor()

    def write_fixture(self):
        (self.directory / "deployment.env").write_text(editor.encode_env(self.env))
        (self.directory / "run.sh").write_text(self.script)
        (self.directory / "token").write_text(self.token + "\n")
        (self.directory / "access.json").write_text(json.dumps(self.accounts))
        (self.directory / "access-routes.json").write_text(json.dumps(self.routes))
        (self.directory / "ports.list").write_text("21001\n21002\n")
        (self.state / "access-state.json").write_text("live-use-must-never-be-restored")

    def make_editor(self):
        instance = editor.Editor(self.directory, self.state, self.root / "install", self.available, self.enabled)
        instance.run = mock.Mock(return_value=subprocess.CompletedProcess([], 0, "", ""))
        instance.active = mock.Mock(return_value=False)
        instance.wait_service = mock.Mock()
        return instance

    def configure_proxy(self):
        self.env.update(IRAN_PROXY_PROVIDER="arvan", IRAN_ENTRY_DOMAIN="iran.example", IRAN_ENTRY_PORTS="443", LOCAL_PORTS="19101")
        self.accounts["accounts"][0]["listen"] = "127.0.0.1:19101"
        self.accounts["accounts"][1]["listen"] = "127.0.0.1:19102"
        site = self.available / "ununknowntun-iran.example.conf"
        self.env["NGINX_SITE"] = str(site)
        self.write_fixture()
        site.write_text("server {\n    listen 80;\n    server_name iran.example;\n}\nserver {\n    listen 443 ssl http2;\n    server_name iran.example;\n    ssl_certificate /certs/fullchain.pem;\n    ssl_certificate_key /certs/privkey.pem;\n    location = /original-client-websocket {\n        proxy_pass http://127.0.0.1:19101;\n    }\n    # UNUNKNOWNTUN_CUSTOMER_ROUTES\n    # UNUNKNOWNTUN_CUSTOMERS_BEGIN\n    location = /gdt-c/customer-route-0123456789abcdef {\n        proxy_pass http://127.0.0.1:19102/original-client-websocket;\n    }\n    # UNUNKNOWNTUN_CUSTOMERS_END\n}\n")
        (self.enabled / site.name).symlink_to(site)
        self.instance = self.make_editor()
        return site

    def signed(self, data, token=None):
        signature = hmac.new((token or self.token).encode(), editor.canonical(data), hashlib.sha256).hexdigest()
        return base64.b64encode(editor.canonical({"data": data, "signature": signature})).decode()

    def valid_data(self, field="foreign_ip", value="203.0.113.3"):
        return {"format": "UNUNKNOWNTUN_EDIT_V3", "pair": self.env["PAIR_ID"], "from": "egress", "field": field,
                "previous": editor.digest(self.instance.current(field)), "value": value, "created": int(time.time()), "nonce": "b" * 32}

    def test_sync_tamper_wrong_peer_expiry_and_staleness_refused(self):
        data = self.valid_data()
        self.assertEqual(self.instance.decode_update(self.signed(data)), ("foreign_ip", "203.0.113.3"))
        for field, value in (("pair", "f" * 16), ("from", "origin"), ("created", int(time.time()) - 8 * 86400),
                             ("created", int(time.time()) + 600), ("previous", "f" * 64), ("field", "pad"), ("value", "$(id)")):
            altered = dict(data, **{field: value})
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                self.instance.decode_update(self.signed(altered))
        original = json.loads(base64.b64decode(self.signed(data)))
        original["data"]["value"] = "203.0.113.99"
        with self.assertRaises(ValueError):
            self.instance.decode_update(base64.b64encode(editor.canonical(original)).decode())
        self.assertFalse(self.instance.run.called)

    def test_sync_rejects_duplicate_json_fields_before_interpretation(self):
        data = self.valid_data()
        signature = hmac.new(self.token.encode(), editor.canonical(data), hashlib.sha256).hexdigest()
        raw = '{"data":' + editor.canonical(data).decode() + ',"signature":"bad","signature":' + json.dumps(signature) + '}'
        with self.assertRaises(ValueError):
            self.instance.decode_update(base64.b64encode(raw.encode()).decode())

    def test_sync_created_bool_is_not_an_integer_timestamp(self):
        data = self.valid_data()
        data["created"] = True
        with mock.patch.object(editor.time, "time", return_value=1), self.assertRaises(ValueError):
            self.instance.decode_update(self.signed(data))

    def test_malformed_sync_schema_and_deep_json_return_user_error(self):
        for payload in ("null", "[]", "0", "{}", '{"data":[],"signature":1}',
                        '{"data":null,"signature":"bad"}', "[" * 1100 + "0" + "]" * 1100):
            with self.subTest(payload=payload[:60]), self.assertRaises(ValueError):
                self.instance.decode_update(base64.b64encode(payload.encode()).decode())
        self.assertFalse(self.instance.run.called)

    def test_secret_rotation_code_old_key_authenticates_only_until_rotation(self):
        data = self.valid_data("token", "c" * 64)
        code = self.signed(data)
        self.assertEqual(self.instance.decode_update(code), ("token", "c" * 64))
        plan = self.instance.plan("token", "c" * 64, emit=False)
        with contextlib.redirect_stdout(io.StringIO()):
            self.instance.commit(plan)
        with self.assertRaises(ValueError):
            self.instance.decode_update(code)
        self.assertEqual((self.state / "access-state.json").read_text(), "live-use-must-never-be-restored")
        self.assertEqual(editor.access.read_env(self.directory / "deployment.env")["PAIR_ID"], self.env["PAIR_ID"])

    def test_authenticated_origin_optional_metadata_bootstraps_blank_foreign_side(self):
        # Foreign is installed first and never learns the Iran IP/domain during
        # the original one-way pairing-code workflow.
        self.env.update(ROLE="egress", IRAN_IP="", IRAN_ENTRY_DOMAIN="")
        self.write_fixture()
        self.instance = self.make_editor()
        for field, prior, value in (("iran_ip", "203.0.113.1", "203.0.113.9"),
                                    ("entry_domain", "old-iran.example", "new-iran.example")):
            data = self.valid_data(field, value)
            data.update(previous=editor.digest(prior), **{"from": "origin"})
            with self.subTest(field=field):
                self.assertEqual(self.instance.decode_update(self.signed(data)), (field, value))

    def test_populated_optional_peer_metadata_still_rejects_stale_sync(self):
        self.env.update(ROLE="egress", IRAN_IP="203.0.113.7")
        self.write_fixture()
        self.instance = self.make_editor()
        data = self.valid_data("iran_ip", "203.0.113.9")
        data.update(previous=editor.digest("203.0.113.1"), **{"from": "origin"})
        with self.assertRaises(ValueError):
            self.instance.decode_update(self.signed(data))

    def test_optional_metadata_bootstrap_still_requires_valid_previous_digest(self):
        self.env.update(ROLE="egress", IRAN_IP="")
        self.write_fixture()
        self.instance = self.make_editor()
        data = self.valid_data("iran_ip", "203.0.113.9")
        data.update(previous=None, **{"from": "origin"})
        with self.assertRaises(ValueError):
            self.instance.decode_update(self.signed(data))

    def test_paired_update_never_contains_old_token_or_private_certificate(self):
        plan = self.instance.plan("foreign_ip", "203.0.113.3")
        decoded = base64.b64decode(plan["update"])
        self.assertNotIn(self.token.encode(), decoded)
        self.assertNotIn(b"PRIVATE KEY", decoded)
        self.assertNotIn(b"access-state", decoded)
        self.assertEqual(set(json.loads(decoded)["data"]), {"format", "pair", "from", "field", "previous", "value", "created", "nonce"})

    def test_direct_port_edit_keeps_customer_limits_identity_and_meter_flags(self):
        plan = self.instance.plan("entry_ports", "21003,21004")
        updated = json.loads(plan["changes"][self.directory / "access.json"])
        self.assertEqual(updated["accounts"][1], self.accounts["accounts"][1])
        self.assertEqual(updated["accounts"][0]["quota_bytes"], self.accounts["accounts"][0]["quota_bytes"])
        self.assertEqual(updated["total_quota_bytes"], self.accounts["total_quota_bytes"])
        self.assertEqual(updated["accounts"][0]["listen"], "0.0.0.0:21003,0.0.0.0:21004")
        launcher = plan["changes"][self.directory / "run.sh"].decode()
        self.assertIn("-access-config /etc/ununknowntun/tunnels/sample/access.json", launcher)
        self.assertIn("-access-state /var/lib/ununknowntun/sample/access-state.json", launcher)
        self.assertNotIn(self.directory / "access-routes.json", plan["changes"])
        self.assertEqual(plan["changes"][self.directory / "ports.list"], b"21002\n21003\n21004\n")

    def test_other_customer_port_reserved_even_on_same_tunnel(self):
        with self.assertRaisesRegex(ValueError, "reserved|customer|occupied"):
            self.instance.plan("entry_ports", "21002")

    def test_remote_ports_never_reserved_on_origin(self):
        plan = self.instance.plan("foreign_ports", "443,2053")
        self.assertEqual(plan["changes"][self.directory / "ports.list"], b"21001\n21002\n")
        self.assertFalse(plan["public_ports"])
        self.assertNotIn(self.directory / "access.json", plan["changes"])

    def test_entry_path_keeps_customer_routes_and_rewrites_target_suffix(self):
        site = self.configure_proxy()
        plan = self.instance.plan("entry_path", "/new-client-websocket-path")
        result = plan["changes"][site].decode()
        self.assertIn("location = /gdt-c/customer-route-0123456789abcdef", result)
        self.assertIn("proxy_pass http://127.0.0.1:19102/new-client-websocket-path;", result)
        self.assertNotIn("/original-client-websocket", result)
        self.assertNotIn(self.directory / "access.json", plan["changes"])
        self.assertNotIn(self.directory / "access-routes.json", plan["changes"])

    def test_ip_edit_refreshes_export_without_revealing_master_credentials(self):
        exports = self.directory / "customer-exports"
        exports.mkdir()
        payload = {"format": "UNUNKNOWNTUN_CUSTOMER_ENDPOINT_V1", "customer": "Alice", "address": "203.0.113.1", "ports": [21002]}
        path = exports / "alice.json"
        path.write_text(json.dumps(payload))
        plan = self.instance.plan("iran_ip", "203.0.113.9")
        new = json.loads(plan["changes"][path])
        self.assertEqual(new["address"], "203.0.113.9")
        self.assertEqual(new["ports"], [21002])
        self.assertNotIn(self.token, plan["changes"][path].decode())
        self.assertNotIn(self.env["FOREIGN_IP"], plan["changes"][path].decode())

    def test_shared_nginx_site_refuses_mutation(self):
        self.configure_proxy()
        other = self.root / "tunnels" / "other"
        other.mkdir()
        (other / "deployment.env").write_text(editor.encode_env(self.env))
        with self.assertRaisesRegex(ValueError, "shared"):
            self.instance.plan("entry_path", "/new-client-websocket-path")

    def test_enabled_site_link_to_unrelated_configuration_is_not_replaced(self):
        site = self.configure_proxy()
        unrelated = self.available / "another-service.conf"
        unrelated.write_text("unrelated service")
        link = self.enabled / site.name
        link.unlink()
        link.symlink_to(unrelated)
        with self.assertRaises(ValueError):
            self.instance.plan("entry_path", "/new-client-websocket-path")
        self.assertEqual(link.resolve(), unrelated.resolve())

    def test_transaction_rejects_link_to_outside_managed_site(self):
        site = self.configure_proxy()
        plan = self.instance.plan("entry_path", "/new-client-websocket-path")
        plan["changes"][self.enabled / site.name] = editor.Link(self.root / "unrelated.conf")
        with self.assertRaises(ValueError):
            self.instance.commit(plan)
        self.assertEqual((self.enabled / site.name).resolve(), site.resolve())

    def test_export_parent_symlink_cannot_mutate_outside_tunnel(self):
        external = self.root / "unrelated"
        external.mkdir()
        payload = b'{"format":"UNUNKNOWNTUN_CUSTOMER_ENDPOINT_V1","address":"old"}'
        (external / "alice.json").write_bytes(payload)
        (self.directory / "customer-exports").symlink_to(external, target_is_directory=True)
        with self.assertRaises(ValueError):
            self.instance.plan("iran_ip", "203.0.113.4")
        self.assertEqual((external / "alice.json").read_bytes(), payload)

    def test_commit_rejects_ledger_or_arbitrary_other_nginx_file(self):
        for path in (self.state / "access-state.json", self.available / "unrelated.conf"):
            plan = self.instance.plan("name", "Renamed")
            plan["changes"][path] = b"must not be written"
            with self.subTest(path=path), self.assertRaises(ValueError):
                self.instance.commit(plan)
        self.assertEqual((self.state / "access-state.json").read_text(), "live-use-must-never-be-restored")
        self.assertFalse((self.available / "unrelated.conf").exists())

    def test_existing_weak_secret_export_permissions_are_tightened(self):
        path = self.directory / "last-edit-update.txt"
        path.write_text("previous code")
        path.chmod(0o644)
        plan = self.instance.plan("iran_ip", "203.0.113.4")
        with contextlib.redirect_stdout(io.StringIO()):
            self.instance.commit(plan)
        self.assertEqual(path.stat().st_mode & 0o777, 0o600)

    def test_persistent_rollback_failure_stops_only_affected_service_and_retains_live_usage(self):
        self.instance.active.return_value = True
        plan = self.instance.plan("pad", "0.3")
        original_write = self.instance.write
        ledger = self.state / "access-state.json"
        failed = False
        def injected_write(path, value, previous):
            nonlocal failed
            if path == self.directory / "deployment.env":
                failed = True
                ledger.write_text("usage-advanced-after-edit-start")
                raise OSError("simulated persistent disk failure")
            if failed and path == self.directory / "run.sh":
                raise OSError("simulated restore failure")
            return original_write(path, value, previous)
        with mock.patch.object(self.instance, "write", side_effect=injected_write), contextlib.redirect_stderr(io.StringIO()) as output:
            with self.assertRaises(OSError):
                self.instance.commit(plan)
        self.assertEqual(ledger.read_text(), "usage-advanced-after-edit-start")
        self.assertIn(mock.call("systemctl", "stop", "ununknowntun@sample"), self.instance.run.call_args_list)
        self.assertNotIn(mock.call("systemctl", "restart", "ununknowntun@sample"), self.instance.run.call_args_list)
        self.assertIn("manual recovery required", output.getvalue())
        manifests = list((self.root / "install/backups").glob("edit-*/manifest.json"))
        self.assertEqual(len(manifests), 1)
        self.assertNotIn(str(ledger), manifests[0].read_text())

    def test_printable_shell_name_is_data_never_command(self):
        payload = "name; $(id) `whoami` 'quoted'"
        plan = self.instance.plan("name", payload)
        data = plan["changes"][self.directory / "deployment.env"].decode()
        line = next(x for x in data.splitlines() if x.startswith("TUNNEL_NAME="))
        self.assertEqual(shlex.split(line.partition("=")[2]), [payload])
        self.assertFalse(self.instance.run.called)
        for field, value in (("name", "line\nbreak"), ("foreign_domain", "x.example;evil"), ("ws_path", "/path-with-a-long;injection"), ("pad", "NaN")):
            with self.subTest(field=field), self.assertRaises(ValueError):
                editor.validate(field, value)


if __name__ == "__main__":
    unittest.main(verbosity=2)
