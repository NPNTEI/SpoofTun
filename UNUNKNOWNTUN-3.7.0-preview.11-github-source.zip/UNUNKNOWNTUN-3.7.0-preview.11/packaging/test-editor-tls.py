#!/usr/bin/env python3
"""TLS editor tests; all files are temporary and no service is changed."""
import importlib.util
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import tempfile
import unittest
from unittest import mock

spec = importlib.util.spec_from_file_location("editor_tls", Path(__file__).with_name("editor_tls.py"))
tls = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tls)

SITE = r'''# Managed tunnel; old.example.com stays in comments.
server {
    listen 80;
    server_name old.example.com; # ownership
    root /var/www/ununknowntun-decoy;
    location ^~ /.well-known/acme-challenge/ { try_files $uri =404; }
    location / { try_files $uri $uri/ /index.html; }
}
server {
    listen 443 ssl http2;
    listen 8443 ssl http2;
    server_name old.example.com;
    ssl_certificate /etc/letsencrypt/live/old.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/old.example.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    location = /keep-route {
        proxy_pass http://127.0.0.1:19100;
        proxy_set_header Host $host;
        proxy_set_header Connection "upgrade";
        proxy_set_header Authorization $http_authorization;
        proxy_cache off;
        add_header Cache-Control "no-store" always;
    }
    # UNUNKNOWNTUN_CUSTOMER_ROUTES
    location = /gdt-c/abc123 {
        proxy_pass http://127.0.0.1:19101/keep-route;
    }
    location / { try_files $uri $uri/ /index.html; }
}
'''

PUBLIC = "-----BEGIN PUBLIC KEY-----\nYWJjZGVmZ2g=\n-----END PUBLIC KEY-----\n"


class TLSEditorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="ununknowntun-editor-tls-")
        self.root = Path(self.temp.name)
        self.cert = self.root / "cert.pem"
        self.key = self.root / "key.pem"
        self.cert.write_text("public test fixture\n")
        self.key.write_text("private test fixture never printed\n")
        self.key.chmod(0o600)
        self.commands = []

    def tearDown(self):
        self.temp.cleanup()

    def runner(self, command, **kwargs):
        self.assertEqual(kwargs, {"capture_output": True, "text": True, "check": False})
        self.assertIsInstance(command, list)
        self.commands.append(command)
        output = ""
        if "-startdate" in command:
            output = "notBefore=Jan  1 00:00:00 2020 GMT\n"
        elif "-checkhost" in command:
            output = "Hostname " + command[-1] + " does match certificate\n"
        elif "-pubkey" in command or "-pubout" in command:
            output = PUBLIC
        return subprocess.CompletedProcess(command, 0, output, "")

    def test_domain_canonicalization(self):
        self.assertEqual(tls.validate_domain("TUNNEL.Example.COM"), "tunnel.example.com")
        self.assertEqual(tls.validate_domain("xn--mgbh0fb.example"), "xn--mgbh0fb.example")

    def test_domain_rejects_injection_invalid_labels_ips_and_wildcards(self):
        invalid = ("", "localhost", "127.0.0.1", "01.2.3.4", "::1", "*.example.com",
                   "https://example.com", "example.com/path", "a;return 200", "a.com\n",
                   "a.com\x00", "a..com", "-a.com", "a-.com", "a.com.", ".a.com",
                   "a_foo.com", "مثال.com", "a" * 64 + ".com", ".".join(["a" * 63] * 4))
        for domain in invalid:
            with self.subTest(domain=repr(domain)), self.assertRaises(tls.TLSEditError):
                tls.validate_domain(domain)

    def test_certificate_paths_extract_unique_pair(self):
        self.assertEqual(tls.certificate_paths(SITE), ("/etc/letsencrypt/live/old.example.com/fullchain.pem", "/etc/letsencrypt/live/old.example.com/privkey.pem"))

    def test_certificate_paths_reject_ambiguous_missing_dynamic_pair(self):
        invalid = (SITE.replace("ssl_protocols", "ssl_certificate /other.pem;\n ssl_protocols"),
                   SITE.replace("ssl_certificate_key", "not_ssl_certificate_key"),
                   SITE.replace("/etc/letsencrypt/live/old.example.com/fullchain.pem", "$dynamic_cert"),
                   SITE + SITE.replace("/fullchain.pem", "/another.pem"))
        for site in invalid:
            with self.subTest(site=site[-60:]), self.assertRaises(tls.TLSEditError):
                tls.certificate_paths(site)

    def test_rewrite_preserves_every_non_target_byte(self):
        updated = tls.rewrite_site(SITE, "old.example.com", "new.example.com", "/etc/new/cert.pem", "/etc/new/key.pem")
        expected = SITE.replace("server_name old.example.com", "server_name new.example.com")
        expected = expected.replace("ssl_certificate /etc/letsencrypt/live/old.example.com/fullchain.pem", "ssl_certificate /etc/new/cert.pem")
        expected = expected.replace("ssl_certificate_key /etc/letsencrypt/live/old.example.com/privkey.pem", "ssl_certificate_key /etc/new/key.pem")
        self.assertEqual(updated, expected)
        self.assertIn("# Managed tunnel; old.example.com stays in comments.", updated)
        self.assertEqual(tls.rewrite_site(updated, "new.example.com", "new.example.com", "/etc/new/cert.pem", "/etc/new/key.pem"), updated)

    def test_rewrite_domain_alone_and_quoted_values(self):
        site = SITE.replace("server_name old.example.com;", 'server_name "old.example.com";')
        updated = tls.rewrite_site(site, "OLD.EXAMPLE.COM", "new.example.com")
        self.assertEqual(updated, site.replace('server_name "old.example.com";', 'server_name "new.example.com";'))
        self.assertEqual(tls.certificate_paths(updated), tls.certificate_paths(SITE))

    def test_rewrite_rejects_unknown_or_other_domain_layout(self):
        invalid = (SITE.replace("server_name old.example.com;", "server_name wrong.example.com;", 1),
                   SITE.replace("server_name old.example.com;", "server_name old.example.com other.example.com;", 1),
                   SITE.replace("root /var/www", "include /etc/foreign.conf;\nroot /var/www", 1),
                   "http { " + SITE + " }", SITE + "map $host $v { default 1; }", SITE[:-2],
                   SITE.replace("server_name old.example.com;", "server_name old.example.com; server_name old.example.com;", 1),
                   SITE.replace("listen 80;", ""), SITE.replace("location = /keep-route {", "location = /keep-route { server_name old.example.com;"))
        for site in invalid:
            with self.subTest(site=site[:90]), self.assertRaises(tls.TLSEditError):
                tls.rewrite_site(site, "old.example.com", "new.example.com")

    def test_rewrite_rejects_path_injection_and_missing_pair(self):
        for cert in ("relative.pem", "/etc/a;return200", "/etc/a\nssl_certificate", "/etc/a b.pem", "/etc/../key.pem", "$variable"):
            with self.subTest(cert=repr(cert)), self.assertRaises(tls.TLSEditError):
                tls.rewrite_site(SITE, "old.example.com", "new.example.com", cert, "/etc/key.pem")
        with self.assertRaises(tls.TLSEditError):
            tls.rewrite_site(SITE, "old.example.com", "new.example.com", "/etc/cert.pem")

    def test_certificate_validates_and_never_captures_private_key(self):
        self.assertEqual(tls.validate_certificate("OLD.example.com", self.cert, self.key, self.runner), (str(self.cert), str(self.key)))
        self.assertEqual(len(self.commands), 5)
        self.assertIn(["openssl", "pkey", "-in", str(self.key), "-passin", "pass:", "-pubout"], self.commands)
        self.assertFalse(any("-text" in command for command in self.commands))

    def test_certificate_rejects_expiry_failure_without_exposing_output(self):
        runner = mock.Mock(return_value=subprocess.CompletedProcess([], 1, "PRIVATE KEY LEAK", "PRIVATE KEY LEAK"))
        with self.assertRaises(tls.TLSEditError) as context:
            tls.validate_certificate("old.example.com", self.cert, self.key, runner)
        self.assertNotIn("PRIVATE KEY", str(context.exception))

    def test_certificate_rejects_not_yet_valid(self):
        def runner(command, **kwargs):
            result = self.runner(command, **kwargs)
            if "-startdate" in command:
                result.stdout = "notBefore=Jan 1 00:00:00 2099 GMT\n"
            return result
        with self.assertRaisesRegex(tls.TLSEditError, "not valid yet"):
            tls.validate_certificate("old.example.com", self.cert, self.key, runner)

    def test_certificate_rejects_hostname_false_success_and_no_checkhost_support(self):
        for returncode, output in ((0, "Hostname old.example.com does NOT match certificate"), (1, "unknown option checkhost")):
            def runner(command, **kwargs):
                result = self.runner(command, **kwargs)
                if "-checkhost" in command:
                    result.returncode, result.stdout = returncode, output
                return result
            with self.subTest(returncode=returncode), self.assertRaises(tls.TLSEditError):
                tls.validate_certificate("old.example.com", self.cert, self.key, runner)

    def test_certificate_rejects_mismatched_public_keys(self):
        def runner(command, **kwargs):
            result = self.runner(command, **kwargs)
            if "-pubout" in command:
                result.stdout = PUBLIC.replace("YWJj", "ZGVm")
            return result
        with self.assertRaisesRegex(tls.TLSEditError, "do not match"):
            tls.validate_certificate("old.example.com", self.cert, self.key, runner)

    def test_certificate_missing_empty_or_directory_rejected_before_openssl(self):
        missing = self.root / "missing.pem"
        empty = self.root / "empty.pem"
        empty.touch()
        for path in (missing, empty, self.root):
            runner = mock.Mock()
            with self.subTest(path=path), self.assertRaises(tls.TLSEditError):
                tls.validate_certificate("old.example.com", path, self.key, runner)
            runner.assert_not_called()

    def test_certificate_letsencrypt_style_symlink_accepted(self):
        link = self.root / "fullchain.pem"
        link.symlink_to(self.cert)
        self.assertEqual(tls.validate_certificate("old.example.com", link, self.key, self.runner)[0], str(link))

    def test_issuance_webroot_only_and_disables_hooks(self):
        with mock.patch.object(tls, "validate_certificate", return_value=("cert", "key")) as validation:
            self.assertEqual(tls.issue_certificate("new.example.com", "admin@example.com", self.root, self.runner), ("cert", "key"))
        command = self.commands[0]
        self.assertIn("--webroot", command)
        self.assertIn("--no-directory-hooks", command)
        self.assertNotIn("--nginx", command)
        self.assertEqual(command[command.index("--deploy-hook") + 1], "")
        self.assertEqual(command[command.index("--config") + 1], "/dev/null")
        validation.assert_called_once_with("new.example.com", "/etc/letsencrypt/live/new.example.com/fullchain.pem", "/etc/letsencrypt/live/new.example.com/privkey.pem", runner=self.runner)

    def test_issuance_failure_explains_existing_certificate_and_cdn_bootstrap(self):
        runner = mock.Mock(return_value=subprocess.CompletedProcess([], 1, "", "failure"))
        with self.assertRaises(tls.TLSEditError) as context:
            tls.issue_certificate("new.example.com", "admin@example.com", self.root, runner)
        for phrase in ("existing valid certificate", "HTTP port 80", "HTTPS", "bootstrap"):
            self.assertIn(phrase, str(context.exception))

    def test_issuance_rejects_email_injection(self):
        runner = mock.Mock()
        with self.assertRaises(tls.TLSEditError):
            tls.issue_certificate("new.example.com", "admin@example.com\n--nginx", self.root, runner)
        runner.assert_not_called()


@unittest.skipUnless(shutil.which("openssl"), "OpenSSL is unavailable")
class RealOpenSSLTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="ununknowntun-real-tls-")
        self.root = Path(self.temp.name)
        self.cert, self.key = self.root / "cert.pem", self.root / "key.pem"
        config = self.root / "openssl.cnf"
        config.write_text("[req]\nprompt=no\ndistinguished_name=dn\nx509_extensions=ext\n[dn]\nCN=old.example.com\n[ext]\nsubjectAltName=DNS:old.example.com,DNS:*.wild.example.com\n")
        subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "3", "-keyout", str(self.key), "-out", str(self.cert), "-config", str(config)], check=True, capture_output=True, text=True)

    def tearDown(self):
        self.temp.cleanup()

    def test_real_certificate_time_and_public_key_validation_portable(self):
        def runner(command, **kwargs):
            if "-checkhost" in command:
                return subprocess.CompletedProcess(command, 0, "Hostname old.example.com does match certificate\n", "")
            return subprocess.run(command, **kwargs)
        self.assertEqual(tls.validate_certificate("old.example.com", self.cert, self.key, runner), (str(self.cert), str(self.key)))

    def test_real_openssl_hostname_matches_mismatch_and_wildcard(self):
        supported = subprocess.run(["openssl", "x509", "-in", str(self.cert), "-noout", "-checkhost", "old.example.com"], capture_output=True, text=True)
        if "unknown option" in supported.stderr or "unrecognized" in supported.stderr:
            self.skipTest("Host OpenSSL/LibreSSL lacks x509 -checkhost; Linux CI executes this test")
        tls.validate_certificate("old.example.com", self.cert, self.key)
        tls.validate_certificate("child.wild.example.com", self.cert, self.key)
        for domain in ("wrong.example.com", "deep.child.wild.example.com", "wild.example.com"):
            with self.subTest(domain=domain), self.assertRaises(tls.TLSEditError):
                tls.validate_certificate(domain, self.cert, self.key)


class RealNginxEditorTests(unittest.TestCase):
    @unittest.skipUnless(os.environ.get("UNUNKNOWNTUN_TEST_NGINX"), "set UNUNKNOWNTUN_TEST_NGINX for the real edited-site parser gate")
    def test_domain_certificate_rewrite_of_production_sites_parses(self):
        """Generate production sites with inert host commands, then run nginx -t."""
        nginx = Path(os.environ["UNUNKNOWNTUN_TEST_NGINX"])
        self.assertTrue(nginx.is_absolute() and nginx.is_file())
        fixture_spec = importlib.util.spec_from_file_location("installer_tls_fixture", Path(__file__).with_name("test-full-installer.py"))
        fixtures = importlib.util.module_from_spec(fixture_spec)
        fixture_spec.loader.exec_module(fixtures)
        fixture = fixtures.InstallerTests()
        fixture.setUp()
        try:
            (fixture.root / "logs").mkdir()
            cert, key = fixture.certificate(name="new.example.com")
            fixture.run_shell(f'''
write_nginx_wss_site old.example.com 443,8443 /private-websocket-path 18080 /private-http2-path 18081 {cert} {key}
write_nginx_origin_proxy_site old-entry.example.com 443 /client-private-entry-path 19080 {cert} {key}
''')
            customer_spec = importlib.util.spec_from_file_location("editor_tls_customer_fixture", Path(__file__).with_name("access-manager.py"))
            customer = importlib.util.module_from_spec(customer_spec)
            customer_spec.loader.exec_module(customer)
            for old_domain in ("old.example.com", "old-entry.example.com"):
                with self.subTest(domain=old_domain):
                    site = (fixture.root / "nginx-available" / ("ununknowntun-" + old_domain + ".conf")).read_text()
                    if old_domain == "old-entry.example.com":
                        accounts = {"accounts": [{"id": "default", "listen": "127.0.0.1:19080", "enabled": True}, {"id": "customer-1", "listen": "127.0.0.1:19101", "enabled": True}]}
                        site = customer.build_routes(site, accounts, {"customer-1": "/private-customer-route"}, "/client-private-entry-path")
                    edited = tls.rewrite_site(site, old_domain, "new.example.com", str(cert), str(key))
                    self.assertNotIn("server_name " + old_domain, edited)
                    self.assertEqual(site.replace("server_name " + old_domain, "server_name new.example.com"), edited)
                    sockets = []
                    def private_listener(match):
                        sock = socket.socket()
                        sock.bind(("127.0.0.1", 0))
                        sockets.append(sock)
                        return match[1] + "127.0.0.1:" + str(sock.getsockname()[1])
                    try:
                        private = re.sub(r"(?m)^(\s*listen\s+)[0-9]+", private_listener, edited)
                    finally:
                        for sock in sockets:
                            sock.close()
                    (fixture.root / "edited-site.conf").write_text(private)
                    conf = fixture.root / "nginx.conf"
                    conf.write_text(f"pid {fixture.root}/nginx.pid;\nerror_log {fixture.root}/nginx-error.log;\nevents {{ worker_connections 32; }}\nhttp {{ access_log off; default_type text/html; include {fixture.root}/edited-site.conf; }}\n")
                    result = subprocess.run([str(nginx), "-t", "-p", str(fixture.root) + "/", "-c", str(conf)], capture_output=True, text=True, timeout=15)
                    self.assertEqual(result.returncode, 0, result.stderr)
                    self.assertIn("test is successful", result.stderr)
        finally:
            fixture.tearDown()


if __name__ == "__main__":
    unittest.main(verbosity=2)
