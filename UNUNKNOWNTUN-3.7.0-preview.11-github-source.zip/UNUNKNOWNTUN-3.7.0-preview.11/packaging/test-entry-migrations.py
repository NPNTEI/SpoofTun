#!/usr/bin/env python3
"""Offline fixtures for 3.5 paired provider/entry migrations and rollback."""
import base64
import contextlib
import copy
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import unittest
from unittest import mock

spec = importlib.util.spec_from_file_location("migration_safety", Path(__file__).with_name("test-editor-safety.py"))
safety = importlib.util.module_from_spec(spec)
spec.loader.exec_module(safety)
editor = safety.editor


class MigrationTests(unittest.TestCase):
    def setUp(self):
        self.fx = safety.EditorSafetyTests(methodName="runTest")
        self.fx.setUp()
        self.addCleanup(self.fx.doCleanups)
        self.ed = self.fx.instance
        self.cert = mock.patch.object(editor.tls, "validate_certificate", side_effect=lambda domain, cert, key: (cert, key))
        self.cert.start()
        self.addCleanup(self.cert.stop)
        exports = self.fx.directory / "customer-exports"
        exports.mkdir()
        for account in self.fx.accounts["accounts"]:
            (exports / (account["id"] + ".json")).write_text(json.dumps({"format": "UNUNKNOWNTUN_CUSTOMER_ENDPOINT_V1", "customer": account["name"], "address": "203.0.113.1", "ports": [21001], "transport": "match the dedicated Xray inbound"}))

    def profile(self, **values):
        data = dict(provider="cloudflare", transport="ws", domain="iran.example", ports="443", path="/original-client-websocket")
        data.update(values)
        return editor.canonical(data).decode()

    def commit(self, plan):
        with contextlib.redirect_stdout(io.StringIO()):
            self.ed.commit(plan)

    def assert_preserved(self):
        saved = editor.access.load_json(self.fx.directory / "access.json")
        self.assertEqual(saved["total_quota_bytes"], self.fx.accounts["total_quota_bytes"])
        self.assertEqual([{k: v for k, v in a.items() if k != "listen"} for a in saved["accounts"]], [{k: v for k, v in a.items() if k != "listen"} for a in self.fx.accounts["accounts"]])
        self.assertEqual((self.fx.state / "access-state.json").read_text(), "live-use-must-never-be-restored")

    def test_direct_to_proxy_retains_ledger_ids_quotas_and_exports(self):
        plan = self.ed.entry_plan(self.profile(), ("/certs/cert.pem", "/certs/key.pem"))
        self.assertNotIn(self.fx.state / "access-state.json", plan["changes"])
        self.assertNotIn(b"/certs/", base64.b64decode(plan["update"]))
        self.commit(plan)
        self.assert_preserved()
        accounts = editor.access.load_json(self.fx.directory / "access.json")
        self.assertEqual(accounts["accounts"][0]["listen"], "127.0.0.1:20000")
        self.assertEqual(accounts["accounts"][1]["listen"], "127.0.0.1:20001")
        exported = editor.access.load_json(self.fx.directory / "customer-exports/default.json")
        self.assertEqual((exported["address"], exported["transport"], exported["tls"]), ("iran.example", "websocket", True))
        self.assertNotIn("customer-route-0123456789abcdef", self.ed.site.read_text())  # Disabled account stays disabled.

    def test_standalone_nginx_without_cdn_preserves_accounts_and_exports_https(self):
        plan = self.ed.entry_plan(self.profile(provider="nginx", ports="8443"), ("/certs/cert.pem", "/certs/key.pem"))
        self.assertEqual(json.loads(json.loads(base64.b64decode(plan["update"]))["data"]["value"])["provider"], "nginx")
        self.commit(plan)
        self.assertEqual(self.ed.env["IRAN_PROXY_PROVIDER"], "nginx")
        self.assert_preserved()
        self.assertIn("listen 8443 ssl", self.ed.site.read_text())
        exported = editor.access.load_json(self.fx.directory / "customer-exports/default.json")
        self.assertEqual((exported["transport"], exported["tls"]), ("websocket", True))
        self.assertEqual(exported["ports"], [8443])
        with self.assertRaises(ValueError):
            editor.validate("foreign_provider", "nginx")

    def test_standalone_nginx_to_direct_restores_original_tcp_exports(self):
        self.commit(self.ed.entry_plan(self.profile(provider="nginx", transport="xhttp"), ("/certs/cert.pem", "/certs/key.pem")))
        self.commit(self.ed.entry_plan(self.profile(provider="none", ports="21001", transport="xhttp")))
        self.assert_preserved()
        self.assertEqual(editor.access.load_json(self.fx.directory / "access.json"), self.fx.accounts)
        self.assertNotIn("tls", editor.access.load_json(self.fx.directory / "customer-exports/default.json"))

    def test_proxy_to_direct_restores_all_previous_ports_and_clears_tls_fields(self):
        self.commit(self.ed.entry_plan(self.profile(transport="xhttp"), ("/certs/cert.pem", "/certs/key.pem")))
        site = self.ed.site
        self.commit(self.ed.entry_plan(self.profile(provider="none", ports="21001", transport="xhttp")))
        self.assertFalse(site.exists())
        self.assertTrue((self.fx.directory / "entry-site.saved.conf").is_file())
        self.assert_preserved()
        self.assertEqual(editor.access.load_json(self.fx.directory / "access.json"), self.fx.accounts)
        exported = editor.access.load_json(self.fx.directory / "customer-exports/default.json")
        self.assertEqual(exported["address"], "203.0.113.1")
        for key in ("tls", "sni", "host", "path", "xhttp_mode"):
            self.assertNotIn(key, exported)

    def test_return_to_proxy_reuses_retained_certificate_and_site(self):
        self.commit(self.ed.entry_plan(self.profile(), ("/certs/cert.pem", "/certs/key.pem")))
        self.commit(self.ed.entry_plan(self.profile(provider="none", ports="21001")))
        self.commit(self.ed.entry_plan(self.profile(transport="xhttp", provider="fastly")))
        self.assertIn("ssl_certificate /certs/cert.pem;", self.ed.site.read_text())
        self.assertIn("location ^~ /original-client-websocket/", self.ed.site.read_text())
        self.assertNotIn('Connection "upgrade"', self.ed.site.read_text())
        self.assert_preserved()

    def test_existing_proxy_ws_to_xhttp_preserves_custom_site_and_certificate(self):
        self.fx.configure_proxy()
        self.ed = self.fx.instance
        with self.ed.site.open("a") as stream:
            stream.write("# keep custom operator comment\n")
        self.commit(self.ed.entry_plan(self.profile(provider="arvan", transport="xhttp")))
        site = self.ed.site.read_text()
        self.assertIn("# keep custom operator comment", site)
        self.assertIn("ssl_certificate /certs/fullchain.pem;", site)
        self.assertIn("location ^~ /original-client-websocket/", site)
        self.assertNotIn("location = /original-client-websocket", site)
        self.assert_preserved()

    def test_nginx_failure_rolls_back_sites_customers_exports_and_reservations(self):
        before = {p: p.read_bytes() for p in self.fx.directory.rglob("*") if p.is_file()}
        plan = self.ed.entry_plan(self.profile(), ("/certs/cert.pem", "/certs/key.pem"))
        def run(*args, **kwargs):
            if args[:2] == ("nginx", "-t"):
                raise subprocess.CalledProcessError(1, args)
            return subprocess.CompletedProcess(args, 0, "", "")
        self.ed.run.side_effect = run
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(subprocess.CalledProcessError):
            self.ed.commit(plan)
        self.assertEqual({p: p.read_bytes() for p in self.fx.directory.rglob("*") if p.is_file()}, before)
        self.assertEqual(list(self.fx.available.iterdir()), [])
        self.assertEqual(list(self.fx.enabled.iterdir()), [])
        self.assert_preserved()

    def test_peer_sync_is_metadata_only_and_replay_stale(self):
        plan = self.ed.entry_plan(self.profile(), ("/certs/cert.pem", "/certs/key.pem"))
        self.fx.env.update(ROLE="egress", IRAN_ENTRY_PORTS="", IRAN_ENTRY_DOMAIN="", WSS_BACKEND_PORT="18080", H2_BACKEND_PORT="18081")
        self.fx.write_fixture()
        peer = self.fx.make_editor()
        field, value = peer.decode_update(plan["update"])
        remote = peer.plan(field, value, emit=False)
        self.assertFalse(remote["nginx"])
        self.assertFalse(remote["restart"])
        self.assertNotIn(self.fx.directory / "access.json", remote["changes"])
        with contextlib.redirect_stdout(io.StringIO()):
            peer.commit(remote)
        with self.assertRaises(ValueError):
            peer.decode_update(plan["update"])

    def test_customer_ports_overlap_and_missing_account_rejected(self):
        self.fx.configure_proxy()
        self.ed = self.fx.instance
        for assigned in ({"default": "21001"}, {"default": "21001", "alice": "21001"}):
            with self.subTest(assigned=assigned), self.assertRaises(ValueError):
                self.ed.entry_plan(self.profile(provider="none", ports="21001"), direct_ports=assigned)

    def test_other_tunnel_reserved_port_is_rejected(self):
        other = self.fx.directory.parent / "other"
        other.mkdir()
        (other / "ports.list").write_text("22000\n")
        (other / "deployment.env").write_text("ROLE=origin\n")
        self.fx.configure_proxy()
        self.ed = self.fx.instance
        with self.assertRaisesRegex(ValueError, "reserved by other"):
            self.ed.entry_plan(self.profile(provider="none", ports="22000"), direct_ports={"default": "22000", "alice": "22001"})

    def test_foreign_provider_changes_connect_host_and_emits_signed_code(self):
        plan = self.ed.plan("foreign_provider", "cloudflare")
        self.assertIn(b"-connect foreign.example:443,foreign.example:8443", plan["changes"][self.fx.directory / "run.sh"])
        self.assertIsNotNone(plan["update"])
        self.commit(plan)
        plan = self.ed.plan("foreign_provider", "none")
        self.assertIn(b"-connect 203.0.113.2:443,203.0.113.2:8443", plan["changes"][self.fx.directory / "run.sh"])

    def test_fastly_constraints_and_ech_provider_neutral(self):
        with self.assertRaises(ValueError):
            self.ed.entry_plan(self.profile(provider="fastly", transport="ws"))
        with self.assertRaises(ValueError):
            self.ed.plan("foreign_provider", "arvan")  # Existing 8443 invalid.
        self.assertIn(b"-ech-mode strict", self.ed.plan("ech_mode", "strict")["changes"][self.fx.directory / "run.sh"])

    def test_disabled_default_can_migrate_protocol_and_return_from_direct(self):
        self.fx.accounts["accounts"][0]["enabled"] = False
        self.fx.write_fixture()
        self.ed = self.fx.make_editor()
        self.commit(self.ed.entry_plan(self.profile(), ("/certs/cert.pem", "/certs/key.pem")))
        self.assertIn("All systems operational", self.ed.site.read_text())
        self.commit(self.ed.entry_plan(self.profile(transport="xhttp")))
        self.commit(self.ed.entry_plan(self.profile(provider="none", ports="21001", transport="xhttp")))
        self.commit(self.ed.entry_plan(self.profile()))
        self.assert_preserved()

    def test_disabled_nginx_site_stays_disabled_through_migration(self):
        self.fx.configure_proxy()
        self.ed = self.fx.instance
        (self.ed.enabled / self.ed.site.name).unlink()
        self.commit(self.ed.entry_plan(self.profile(transport="xhttp")))
        self.assertFalse((self.ed.enabled / self.ed.site.name).exists())
        self.commit(self.ed.entry_plan(self.profile(provider="none", ports="21001", transport="xhttp"), direct_ports={"default": "21001", "alice": "21002"}))
        self.commit(self.ed.entry_plan(self.profile()))
        self.assertFalse((self.ed.enabled / self.ed.site.name).exists())

    def test_new_entry_ports_sync_only_peer_metadata_and_preserve_next_profile_hash(self):
        local = self.ed.plan("entry_ports", "22001")
        self.fx.env.update(ROLE="egress", IRAN_ENTRY_PORTS="21001", WSS_BACKEND_PORT="18080", H2_BACKEND_PORT="18081")
        self.fx.write_fixture()
        peer = self.fx.make_editor()
        field, value = peer.decode_update(local["update"])
        remote = peer.plan(field, value, emit=False)
        self.assertFalse(remote["nginx"])
        self.assertFalse(remote["restart"])
        self.assertNotIn(self.fx.directory / "run.sh", remote["changes"])

    def test_disabled_default_path_edit_updates_saved_route_without_enabling(self):
        self.fx.accounts["accounts"][0]["enabled"] = False
        self.fx.write_fixture()
        self.ed = self.fx.make_editor()
        self.commit(self.ed.entry_plan(self.profile(), ("/certs/cert.pem", "/certs/key.pem")))
        self.commit(self.ed.plan("entry_path", "/replacement-client-path"))
        self.assertNotIn("location = /replacement-client-path", self.ed.site.read_text())
        self.assertEqual(editor.access.load_json(self.fx.directory / "access-routes.json")["default"], "/replacement-client-path")

    def test_migration_cannot_repurpose_other_tunnel_site_or_key_path(self):
        other = self.fx.available / "ununknowntun-iran.example.conf"
        other.write_text("unrelated managed site")
        with self.assertRaisesRegex(ValueError, "already exists"):
            self.ed.entry_plan(self.profile(), ("/certs/cert.pem", "/certs/key.pem"))
        self.assertEqual(other.read_text(), "unrelated managed site")

    @unittest.skipUnless(os.environ.get("UNUNKNOWNTUN_TEST_NGINX"), "set UNUNKNOWNTUN_TEST_NGINX for migrated-entry parser gate")
    def test_generated_migrations_parse_with_real_nginx(self):
        cert, key = self.fx.root / "cert.pem", self.fx.root / "key.pem"
        subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "2", "-subj", "/CN=iran.example", "-keyout", str(key), "-out", str(cert)], check=True, capture_output=True)
        self.fx.accounts["accounts"][1]["enabled"] = True
        self.fx.write_fixture()
        self.ed = self.fx.make_editor()
        (self.fx.root / "logs").mkdir(exist_ok=True)
        for provider in ("nginx", "cloudflare"):
            for protocol in ("ws", "xhttp"):
                with self.subTest(provider=provider, protocol=protocol):
                    plan = self.ed.entry_plan(self.profile(provider=provider, transport=protocol), (str(cert), str(key)))
                    site = next(value.decode() for path, value in plan["changes"].items() if path.parent == self.fx.available and isinstance(value, bytes))
                    self.assertIn("customer-route-0123456789abcdef", site)
                    self.assertIn("proxy_pass http://127.0.0.1:20001", site)
                    site = site.replace("listen 80;", "listen 127.0.0.1:28080;").replace("listen 443 ssl", "listen 127.0.0.1:28443 ssl")
                    conf = self.fx.root / "nginx.conf"
                    conf.write_text(f"pid {self.fx.root}/nginx.pid;\nerror_log {self.fx.root}/nginx-error.log;\nevents {{ worker_connections 32; }}\nhttp {{ access_log off;\n{site}\n}}\n")
                    result = subprocess.run([os.environ["UNUNKNOWNTUN_TEST_NGINX"], "-t", "-p", str(self.fx.root), "-c", str(conf)], capture_output=True, text=True, timeout=15)
                    self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                    self.commit(plan)


if __name__ == "__main__":
    unittest.main()
