#!/usr/bin/env python3
"""Isolated shell regressions: definitions only, temp paths, mocked host commands.

Never runs the installer dispatcher, embedded executable, apt, UFW, systemd,
or Xray. OpenSSL certificate checks and ordinary temp-file operations are real.
An optional real Nginx test uses private files/loopback high ports, with no daemon.
Run with: python3 packaging/test-full-installer.py
To enable the real parser gate, set UNUNKNOWNTUN_TEST_NGINX=/absolute/path/to/nginx.
"""
import os
from pathlib import Path
import shlex
import socket
import subprocess
import tempfile
import unittest
import shutil
import base64
import hashlib
import hmac
import importlib.util
import ssl
import threading


TEMPLATE = Path(__file__).with_name("full-installer.template.sh")
SOURCE = TEMPLATE.read_text()
for marker, name in (("__TERMINAL_UI_SOURCE__", "../ui/ununknowntun-ui.py"),
                     ("__DIRECT_ICMP_CONSOLE_SOURCE__", "direct-icmp-console.py"),
                     ("__SPOOF_PAIR_SOURCE__", "spoof-pair.py"),
                     ("__ICMP_PAIR_SOURCE__", "icmp-pair.py"),
                     ("__DIRECT_ICMP_PAIR_SOURCE__", "direct-icmp-pair.py"),
                     ("__DIRECT_ICMP_MANAGE_SOURCE__", "direct-icmp-manage.py"),
                     ("__DIRECT_ICMP_SETUP_SOURCE__", "direct-icmp-setup.py"),
                     ("__DIRECT_ICMP_DOCTOR_SOURCE__", "direct-icmp-doctor.py"),
                     ("__ACCESS_MANAGER_SOURCE__", "access-manager.py"),
                     ("__TUNNEL_EDITOR_SOURCE__", "tunnel-editor.py"),
                     ("__EDITOR_TLS_SOURCE__", "editor_tls.py"),
                     ("__TUNNEL_DOCTOR_SOURCE__", "tunnel-doctor.py"),
                     ("__CDN_ENDPOINTS_SOURCE__", "cdn-endpoints.py"),
                     ("__CDN_CONTROL_SOURCE__", "cdn-control.py"),
                     ("__SCANNER_CONSOLE_SOURCE__", "scanner-console.py"),
                     ("__SCANNER_ENGINE_SOURCE__", "scanner-engine.py"),
                     ("__PROFILE_VALIDATION_SOURCE__", "profile-validation.py"),
                     ("__PROFILE_VALIDATION_INSTALLED_SOURCE__", "profile-validation.py")):
    SOURCE = SOURCE.replace(marker, (TEMPLATE.parent / name).read_text().rstrip())
DISPATCH = '\ncase "${1:-}" in\n'
assert SOURCE.count(DISPATCH) == 1
DEFINITIONS = SOURCE.split(DISPATCH)[0]
INVOCATION = "1234567890abcdef1234567890abcdef"
OPENSSL_HAS_CHECKHOST = "-checkhost" in subprocess.run(
    ["openssl", "x509", "-help"], text=True, capture_output=True
).stderr


class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="ununknowntun-installer-test-")
        self.root = Path(self.temp.name)
        self.defs = self.root / "definitions.sh"
        self.defs.write_text(DEFINITIONS)
        for name in ("config", "config-root/tunnels", "state", "bin", "units", "nginx-available", "nginx-enabled", "hooks", "decoy"):
            (self.root / name).mkdir(parents=True, exist_ok=True)
        self.log = self.root / "mock.log"
        self.log.touch()

    def tearDown(self):
        self.temp.cleanup()

    def run_shell(self, body, expected=0, stdin=None):
        q = shlex.quote
        preamble = f'''
source {q(str(self.defs))}
ROOT={q(str(self.root))}
CONFIG_DIR="$ROOT/config"
BASE_CONFIG_DIR="$ROOT/config-root"
TUNNELS_DIR="$BASE_CONFIG_DIR/tunnels"
CURRENT_TUNNEL_ID=test
CURRENT_TUNNEL_NAME='Test tunnel'
TUNNEL_STATE_DIR="$ROOT/state/test"
INSTALL_DIR="$ROOT/install"
BIN_PATH="$ROOT/bin/ununknowntun"
CTL_PATH="$ROOT/bin/ununknowntunctl"
UNIT_PATH="$ROOT/units/ununknowntun.service"
LOCK_PATH="$ROOT/installer.lock"
NGINX_SITE_DIR="$ROOT/nginx-available"
NGINX_ENABLED_DIR="$ROOT/nginx-enabled"
CERTBOT_HOOK_DIR="$ROOT/hooks"
CERTBOT_RENEWAL_DIR="$ROOT/renewal"
DECOY_DIR="$ROOT/decoy"
MOCK_LOG="$ROOT/mock.log"
SERVICE_INVOCATION={INVOCATION}
systemctl() {{
    printf 'systemctl %s\\n' "$*" >> "$MOCK_LOG"
    case "$1" in
        is-active) printf '%s\\n' "${{MOCK_ACTIVE:-active}}"; [[ "${{MOCK_ACTIVE:-active}}" == active ]] ;;
        is-enabled) printf '%s\\n' "${{MOCK_ENABLED:-enabled}}" ;;
        show) printf '%s\\n' "${{MOCK_INVOCATION:-$SERVICE_INVOCATION}}" ;;
        *) return 0 ;;
    esac
}}
nginx() {{ printf 'nginx %s\\n' "$*" >> "$MOCK_LOG"; return "${{MOCK_NGINX_STATUS:-0}}"; }}
ufw() {{
    printf 'ufw %s\\n' "$*" >> "$MOCK_LOG"
    case "$1" in status) echo 'Status: active' ;; allow) echo "${{MOCK_UFW_RESULT:-Rule added}}" ;; esac
}}
chown() {{ :; }}
sleep() {{ :; }}
apt-get() {{ echo 'FORBIDDEN apt-get' >&2; return 99; }}
useradd() {{ echo 'FORBIDDEN useradd' >&2; return 99; }}
sysctl() {{ echo 'FORBIDDEN sysctl' >&2; return 99; }}
timedatectl() {{ return 1; }}
'''
        result = subprocess.run(["bash", "-c", preamble + body], text=True, capture_output=True, input=stdin, timeout=15)
        self.assertEqual(result.returncode, expected, result.stdout + result.stderr)
        self.assertNotIn("FORBIDDEN", result.stderr)
        return result

    def certificate(self, name="right.example", suffix="", rsa=False):
        cert, key = self.root / f"cert{suffix}.pem", self.root / f"key{suffix}.pem"
        key_options = ["-newkey", "rsa:2048"] if rsa else ["-newkey", "ec", "-pkeyopt", "ec_paramgen_curve:prime256v1"]
        subprocess.run([
            "openssl", "req", "-x509", "-sha256", *key_options,
            "-nodes", "-subj", f"/CN={name}", "-addext", f"subjectAltName=DNS:{name}",
            "-days", "2", "-keyout", str(key), "-out", str(cert),
        ], check=True, capture_output=True)
        return cert, key

    def test_syntax(self):
        subprocess.run(["bash", "-n", str(TEMPLATE)], check=True)

    def test_port_normalization_and_overflow(self):
        result = self.run_shell('normalize_ports "0443,443,0080"; ! valid_port 18446744073709617153\n')
        self.assertIn("443,80", result.stdout)

    def test_failed_transaction_restores_files_and_service(self):
        original = self.root / "config" / "token"
        original.write_text("old secret")
        os.chmod(original, 0o640)
        result = self.run_shell('''
transaction_begin origin
TX_SERVICE_TOUCHED=1
printf 'replacement' > "$CONFIG_DIR/token"
printf 'new binary' > "$BIN_PATH"
false
''', expected=1)
        self.assertEqual(original.read_text(), "old secret")
        self.assertEqual(original.stat().st_mode & 0o777, 0o640)
        self.assertFalse((self.root / "bin" / "ununknowntun").exists())
        self.assertIn("systemctl restart ununknowntun", self.log.read_text())
        self.assertNotIn("xray", self.log.read_text().lower())
        backups = list((self.root / "install" / "backups").glob("transaction.*"))
        self.assertEqual(backups[0].stat().st_mode & 0o777, 0o700)
        self.assertIn("restored", result.stderr)

    def test_signal_rolls_back_with_signal_exit_status(self):
        token = self.root / "config" / "token"
        token.write_text("before")
        self.run_shell('''
transaction_begin origin
printf 'after' > "$CONFIG_DIR/token"
kill -TERM "$$"
''', expected=143)
        self.assertEqual(token.read_text(), "before")

    def test_incomplete_file_restore_never_restarts_tunnel_or_reloads_nginx(self):
        token = self.root / "config" / "token"
        token.write_text("original protected secret")
        unrelated = self.root / "nginx-available" / "unrelated-panel.conf"
        unrelated.write_text("unrelated panel configuration")
        result = self.run_shell('''
transaction_begin origin
TX_SERVICE_TOUCHED=1
TX_NGINX_TOUCHED=1
printf 'replacement secret' > "$CONFIG_DIR/token"
cp() {
    if [[ "$*" == *"$TX_DIR/files/0"* ]]; then return 1; fi
    command cp "$@"
}
false
''', expected=1)
        log = self.log.read_text()
        self.assertIn("systemctl stop ununknowntun", log)
        self.assertNotIn("systemctl restart ununknowntun", log)
        self.assertNotIn("systemctl reload nginx", log)
        self.assertNotIn("systemctl stop nginx", log)
        self.assertIn("manual attention", result.stderr)
        backup = next((self.root / "install" / "backups").glob("transaction.*"))
        self.assertEqual((backup / "files/0/token").read_text(), "original protected secret")
        self.assertEqual((backup / "failed/0/token").read_text(), "replacement secret")
        self.assertEqual(unrelated.read_text(), "unrelated panel configuration")

    def test_uncommitted_zero_exit_is_failure(self):
        self.run_shell("transaction_begin origin\nexit 0\n", expected=1)

    def test_commit_keeps_changes(self):
        self.run_shell('''
transaction_begin origin
printf 'kept' > "$CONFIG_DIR/token"
transaction_commit
''')
        self.assertEqual((self.root / "config" / "token").read_text(), "kept")
        self.assertNotIn("systemctl stop", self.log.read_text())

    def test_new_certbot_timer_is_disabled_again_on_failure(self):
        self.run_shell('''
MOCK_ACTIVE=inactive
MOCK_ENABLED=disabled
transaction_begin origin
TX_CERTBOT_TIMER_TOUCHED=1
false
''', expected=1)
        log = self.log.read_text()
        self.assertIn("systemctl disable certbot.timer", log)
        self.assertIn("systemctl stop certbot.timer", log)

    def test_rollback_restores_nginx_file_and_symlink(self):
        site = self.root / "nginx-available" / "ununknowntun-right.example.conf"
        link = self.root / "nginx-enabled" / site.name
        site.write_text("old TLS site")
        link.symlink_to(site)
        self.run_shell('''
transaction_begin egress right.example
TX_NGINX_TOUCHED=1
printf 'bad replacement' > "$NGINX_SITE_DIR/ununknowntun-right.example.conf"
false
''', expected=1)
        self.assertEqual(site.read_text(), "old TLS site")
        self.assertTrue(link.is_symlink())
        self.assertEqual(os.path.realpath(link), os.path.realpath(site))
        self.assertIn("systemctl reload nginx", self.log.read_text())

    def test_acme_keeps_existing_tls_site(self):
        site = self.root / "nginx-available" / "ununknowntun-right.example.conf"
        original = f"listen 443 ssl;\nroot {self.root}/decoy;\nlocation ^~ /.well-known/acme-challenge/ {{ }}\n"
        site.write_text(original)
        self.run_shell("write_http_challenge_site right.example\n")
        self.assertEqual(site.read_text(), original)
        self.assertNotIn("systemctl reload", self.log.read_text())

    @unittest.skipUnless(os.environ.get("UNUNKNOWNTUN_TEST_NGINX"), "set UNUNKNOWNTUN_TEST_NGINX for the real Nginx parser gate")
    def test_generated_site_parses_with_real_nginx(self):
        nginx = Path(os.environ["UNUNKNOWNTUN_TEST_NGINX"])
        self.assertTrue(nginx.is_absolute() and nginx.is_file())
        cert, key = self.certificate()
        (self.root / "logs").mkdir()
        conf = self.root / "nginx.conf"
        conf.write_text(
            # The parser only runs as this test process; it never launches a
            # worker. Avoid unmapped nobody ownership in restricted containers.
            "user root;\n"
            f"pid {self.root}/nginx.pid;\n"
            f"error_log {self.root}/nginx-error.log;\n"
            "events { worker_connections 32; }\n"
            "http {\n"
            "  access_log off;\n"
            "  default_type text/html;\n"
            f"  include {self.root}/private-site.conf;\n"
            f"  include {self.root}/private-origin-site.conf;\n"
            "}\n"
        )
        self.run_shell(f'''
write_nginx_wss_site right.example 443,8443,2053 /private-websocket-path 18080 /private-http2-path 18081 {cert} {key}
write_nginx_origin_proxy_site iran.example 443 /client-private-entry-path 19080 {cert} {key}
''')
        generated = (self.root / "nginx-available" / "ununknowntun-right.example.conf").read_text()
        self.assertNotIn("grpc_pass", generated)
        self.assertIn("proxy_pass http://127.0.0.1:18080;", generated)
        self.assertIn("ssl_protocols TLSv1.2 TLSv1.3;", generated)
        self.assertTrue((self.root / "nginx-enabled" / "ununknowntun-right.example.conf").is_symlink())
        self.assertIn("listen 80;", generated)
        spec = importlib.util.spec_from_file_location("nginx_route_test_helper", TEMPLATE.with_name("access-manager.py"))
        helper = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(helper)
        origin = (self.root / "nginx-available" / "ununknowntun-iran.example.conf").read_text()
        accounts = {"accounts": [
            {"id": "default", "listen": "127.0.0.1:19080", "enabled": True},
            {"id": "customer-1", "listen": "127.0.0.1:19101", "enabled": True},
        ]}
        origin = helper.build_routes(origin, accounts, {"customer-1": "/private-customer-one-path"}, "/client-private-entry-path")
        self.assertIn("location = /private-customer-one-path", origin)
        self.assertIn("proxy_pass http://127.0.0.1:19101/client-private-entry-path;", origin)
        self.assertIn("proxy_pass http://127.0.0.1:19080;", origin)
        # `nginx -t` may bind listener sockets, even without starting workers.
        # Keep the exact production output above; validate a copy with only
        # listener addresses changed to unused private loopback high ports.
        sockets = []
        try:
            for _ in range(6):
                sock = socket.socket()
                sock.bind(("127.0.0.1", 0))
                sockets.append(sock)
            private = generated
            for public, sock in zip((80, 443, 8443, 2053), sockets[:4]):
                private = private.replace(f"listen {public}", f"listen 127.0.0.1:{sock.getsockname()[1]}")
            for public, sock in zip((80, 443), sockets[4:]):
                origin = origin.replace(f"listen {public}", f"listen 127.0.0.1:{sock.getsockname()[1]}")
        finally:
            for sock in sockets:
                sock.close()
        (self.root / "private-site.conf").write_text(private)
        (self.root / "private-origin-site.conf").write_text(origin)
        result = subprocess.run(
            [str(nginx), "-t", "-p", str(self.root) + "/", "-c", str(conf)],
            capture_output=True, text=True, timeout=15,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("syntax is ok", result.stderr)
        self.assertIn("test is successful", result.stderr)
        print(result.stderr, end="")

    def test_ufw_rollback_removes_new_rule_only(self):
        self.run_shell('''
transaction_begin origin
open_ufw_ports 80
MOCK_UFW_RESULT='Skipping adding existing rule'
open_ufw_ports 443
false
''', expected=1)
        log = self.log.read_text()
        self.assertIn("ufw --force delete allow proto tcp from 0.0.0.0/0 to 0.0.0.0/0 port 80", log)
        self.assertNotIn("delete allow proto tcp from 0.0.0.0/0 to 0.0.0.0/0 port 443", log)

    @unittest.skipUnless(OPENSSL_HAS_CHECKHOST, "OpenSSL -checkhost is required")
    def test_certificate_hostname_mismatch_rejected(self):
        cert, key = self.certificate("wrong.example")
        result = self.run_shell(f"obtain_certificate right.example existing '' {cert} {key}\n", expected=1)
        self.assertIn("does not include", result.stderr)

    @unittest.skipUnless(OPENSSL_HAS_CHECKHOST, "OpenSSL -checkhost is required")
    def test_certificate_and_key_match_accepted(self):
        cert, key = self.certificate()
        self.run_shell(f"obtain_certificate right.example existing '' {cert} {key}\n")

    @unittest.skipUnless(OPENSSL_HAS_CHECKHOST, "OpenSSL -checkhost is required")
    def test_certificate_key_mismatch_rejected(self):
        cert, _ = self.certificate()
        _, wrong_key = self.certificate(suffix="-wrong")
        result = self.run_shell(f"obtain_certificate right.example existing '' {cert} {wrong_key}\n", expected=1)
        self.assertIn("do not match", result.stderr)

    def test_offline_ca_is_selected_and_used_in_launch(self):
        cert, _ = self.certificate()
        (self.root / "config" / "ca-bundle.pem").write_bytes(cert.read_bytes())
        self.run_shell('''
install_ca_if_needed
PROFILE_MAX_MEMORY=123
PROFILE_MAX_STREAMS=12
write_origin_run_script right.example 193.33.167.13 443 /long-private-path /other-long-private-path 8080 2053 8 .22
''')
        script = (self.root / "config" / "run.sh").read_text()
        self.assertIn(f"-ca {self.root}/config/ca-bundle.pem", script)
        self.assertNotIn("-system-ca", script)

    def test_target_checks_actual_ipv4_loopback(self):
        result = self.run_shell('''
preflight_header() { :; }
preflight_base() { return 0; }
domain_points_to_ipv4() { return 0; }
check_port_conflicts() { :; }
show_firewall_diagnostics() { :; }
tcp_probe() { printf 'probe=%s:%s\\n' "$1" "$2"; return 1; }
preflight_foreign_inputs right.example 193.33.167.13 443 18080 18081 8080
''', expected=1)
        self.assertIn("probe=127.0.0.1:8080", result.stdout)

    def test_wss_health_is_accepted_without_claiming_h2(self):
        result = self.run_shell('''
journalctl() {
    [[ "$1" == "_SYSTEMD_INVOCATION_ID=$SERVICE_INVOCATION" ]] || return 99
    printf '[origin] tunnel session established to peer via wss\\n[stats] sessions=2 streams=0\\n'
}
verify_origin_reverse_tunnel 2
''')
        self.assertIn("WSS fallback", result.stderr)
        self.assertIn("HTTP/2 is not validated", result.stderr)
        self.assertNotIn("HTTP/2 session event(s) observed", result.stdout)

    def test_service_restart_rejects_stale_health(self):
        result = self.run_shell('''
MOCK_INVOCATION=aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
verify_origin_reverse_tunnel 2
''', expected=1)
        self.assertIn("restarted during validation", result.stderr)

    def test_fatal_early_invocation_log_is_not_missed(self):
        result = self.run_shell('''
journalctl() { printf 'authentication failed\\n[stats] sessions=2 streams=0\\n'; }
verify_origin_reverse_tunnel 2
''', expected=1)
        self.assertIn("Authentication or protocol validation failed", result.stderr)

    def test_no_global_tcp_or_time_service_mutations(self):
        self.run_shell("setup_safe_tcp_tuning\nsetup_time_sync\n")
        self.assertNotIn("timesyncd", self.log.read_text())

    @unittest.skipUnless(shutil.which("flock"), "flock is required")
    def test_install_lock_refuses_concurrent_writer(self):
        result = self.run_shell('''
acquire_install_lock
bash -c 'exec 8> "$1"; flock -n 8' _ "$LOCK_PATH" && exit 88
echo lock-exclusive
''')
        self.assertIn("lock-exclusive", result.stdout)

    def test_atomic_binary_replacement_validates_before_rename(self):
        binary = self.root / "bin" / "ununknowntun"
        binary.write_text("previous binary")
        result = self.run_shell('''
extract_embedded_binary() { printf 'untrusted replacement' > "$2"; chmod 0755 "$2"; }
AMD64_SHA256=bad
ARM64_SHA256=bad
install_binary egress
''', expected=1)
        self.assertEqual(binary.read_text(), "previous binary")
        self.assertIn("checksum is incorrect", result.stderr)

    def test_acme_firewall_order_and_certificate_prevalidation(self):
        foreign = DEFINITIONS.split("install_foreign() {", 1)[1].split("copy_ca_from_foreign() {", 1)[0]
        self.assertLess(foreign.index('open_ufw_ports 80'), foreign.index('obtain_certificate_with_retry "$domain"'))
        self.assertLess(foreign.index('ask_certificate_settings "$domain"'), foreign.index('transaction_begin egress'))
        self.assertIn('"$foreign_provider" nginx 80', foreign)

    @unittest.skipUnless(Path("/etc/ssl/certs/ca-certificates.crt").is_file(), "Linux CA path is required")
    def test_dependency_install_does_not_repair_or_upgrade_existing_nginx(self):
        self.run_shell("install_foreign_packages 2\n")
        packages = DEFINITIONS.split("install_foreign_packages() {", 1)[1].split("make_decoy_site() {", 1)[0]
        self.assertIn("--no-upgrade", packages)
        self.assertNotIn("dpkg --configure", packages)

    def test_four_proxy_combinations_and_safe_defaults_exist(self):
        result = self.run_shell('''
printf 'direct=%s cloudflare=%s arvan=%s\n' \
  "$(proxy_default_ports none)" "$(proxy_default_ports cloudflare)" "$(proxy_default_ports arvan)"
for foreign in none cloudflare arvan; do
  for iran in none cloudflare arvan; do printf '%s/%s\n' "$iran" "$foreign"; done
done
''')
        self.assertIn("direct=443,8443,2053 cloudflare=443 arvan=443", result.stdout)
        for pair in ("none/none", "cloudflare/cloudflare", "none/cloudflare", "cloudflare/none"):
            self.assertIn(pair, result.stdout)

    def test_instance_service_unit_uses_tunnel_directory(self):
        self.run_shell("install_service_unit\n")
        unit = (self.root / "units" / "ununknowntun.service").read_text()
        self.assertIn("instance %i", unit)
        self.assertIn("ExecStart=/etc/ununknowntun/tunnels/%i/run.sh", unit)
        self.assertIn("ReadWritePaths=/var/lib/ununknowntun/%i", unit)

    def test_origin_launch_changes_for_direct_and_proxied_iran(self):
        result = self.run_shell('''
PROFILE_MAX_MEMORY=123456
PROFILE_MAX_STREAMS=123
ORIGIN_CA_PATH=/etc/ssl/certs/ca-certificates.crt
write_origin_run_script edge.example 203.0.113.10 443 /private-wss-path /private-h2-path 18082 2053,2054 8 .22 none none chrome off
cp "$CONFIG_DIR/run.sh" "$ROOT/direct-run.sh"
write_origin_run_script edge.example 203.0.113.10 443 /private-wss-path /private-h2-path 18082 19080 8 .22 cloudflare arvan firefox off
cp "$CONFIG_DIR/run.sh" "$ROOT/proxy-run.sh"
''')
        self.assertEqual(result.returncode, 0)
        direct = (self.root / "direct-run.sh").read_text()
        proxied = (self.root / "proxy-run.sh").read_text()
        self.assertIn("-listen 0.0.0.0:2053,0.0.0.0:2054", direct)
        self.assertIn("-connect 203.0.113.10:443", direct)
        self.assertIn("-listen 127.0.0.1:19080", proxied)
        self.assertIn("-connect edge.example:443", proxied)
        self.assertIn("-utls-profile firefox", proxied)
        self.assertIn("-transport wss", proxied)

    def test_peer_code_preserves_pair_identity_and_proxy_modes(self):
        result = self.run_shell('''
code="$(create_peer_code edge.example 203.0.113.10 443 /private-wss-path /private-h2-path 0123456789abcdef0123456789abcdef 18082 cloudflare firefox arvan /client-entry-private-path a1b2c3d4e5f60718)"
decode_peer_code "$code" || { echo decode_failed; exit 1; }
printf '%s|%s|%s|%s|%s|%s\n' "$PEER_TUNNEL_ID" "$PEER_PAIR_ID" "$PEER_FOREIGN_PROXY_PROVIDER" "$PEER_IRAN_PROXY_PROVIDER" "$PEER_SPOOF_PROFILE" "$PEER_IRAN_ENTRY_PATH"
''')
        self.assertIn("test|a1b2c3d4e5f60718|cloudflare|arvan|firefox|/client-entry-private-path", result.stdout)

    def test_origin_proxy_site_uses_shared_https_listener_and_private_backend(self):
        self.run_shell('''
write_nginx_origin_proxy_site iran.example 443 /client-entry-private-path 19080 /cert.pem /key.pem
''')
        generated = (self.root / "nginx-available" / "ununknowntun-iran.example.conf").read_text()
        self.assertIn("listen 443 ssl http2;", generated)
        self.assertIn("location = /client-entry-private-path", generated)
        self.assertIn("proxy_pass http://127.0.0.1:19080;", generated)

    def test_installed_manager_has_multi_tunnel_lifecycle_commands(self):
        self.run_shell('install_manager\nbash -n "$CTL_PATH"\n')
        manager = (self.root / "bin" / "ununknowntunctl").read_text()
        for command in ("list)", "edit-ip)", "edit-ports)", "apply-update)", "delete)"):
            self.assertIn(command, manager)
        self.assertIn('service="ununknowntun@$1"', manager)
        self.assertIn("recoverable backup", manager.lower())

    def test_manager_accepts_public_ip_and_rejects_private_ip(self):
        result = self.run_shell('''
install_manager
eval "$(sed '/^command_name=/,$d' "$CTL_PATH")"
valid_public_ipv4 203.0.113.25
! valid_public_ipv4 192.168.1.20
echo manager-ip-validation-ok
''')
        self.assertIn("manager-ip-validation-ok", result.stdout)

    def test_pair_lookup_survives_different_local_tunnel_ids(self):
        result = self.run_shell('''
install_manager
eval "$(sed '/^command_name=/,$d' "$CTL_PATH")"
TUNNELS_DIR="$ROOT/config-root/tunnels"
mkdir -p "$TUNNELS_DIR/local-name"
printf 'PAIR_ID=a1b2c3d4e5f60718\n' > "$TUNNELS_DIR/local-name/deployment.env"
printf 'mapped=%s\n' "$(find_config_by_pair a1b2c3d4e5f60718)"
''')
        self.assertIn("/local-name", result.stdout)

    def test_rebuilt_registry_keeps_internal_foreign_ports(self):
        result = self.run_shell('''
write_deployment_env egress edge.example 203.0.113.10 443 '' cloudflare none '' '' '' '' chrome /site 18080 18081 18082 a1b2c3d4e5f60718
install_manager
eval "$(sed '/^command_name=/,$d' "$CTL_PATH")"
rebuild_ports_file "$ROOT/config"
paste -sd, "$ROOT/config/ports.list"
''')
        self.assertIn("443,18080,18081,18082", result.stdout)

    def test_existing_tunnel_domain_cannot_be_overwritten(self):
        result = self.run_shell('''
other="$ROOT/config-root/tunnels/other"
mkdir -p "$other"
printf 'FOREIGN_DOMAIN=edge.example\nIRAN_ENTRY_DOMAIN=\n' > "$other/deployment.env"
check_nginx_domain_conflicts edge.example
''', expected=1)
        self.assertIn("already belongs to tunnel 'other'", result.stderr)

    def test_invalid_field_retries_without_losing_other_answers(self):
        result = self.run_shell('''
domain=keep.example
ask_valid port 'Client port' '' valid_port 'Invalid client port.'
printf '%s|%s\n' "$domain" "$port"
''', stdin="not-a-port\n65536\n2053\n")
        self.assertIn("keep.example|2053", result.stdout)
        self.assertEqual(result.stderr.count("Invalid client port."), 2)

    def test_closed_input_cancels_without_retry_loop(self):
        result = self.run_shell("ask_valid port Port '' valid_port Invalid\n", expected=1, stdin="")
        self.assertIn("Input closed", result.stderr)

    def test_invalid_yes_no_retries(self):
        result = self.run_shell("yes_no Continue y\necho accepted\n", stdin="maybe\ny\n")
        self.assertIn("accepted", result.stdout)
        self.assertIn("Enter y", result.stderr)

    def test_proxy_selection_retries_invalid_option(self):
        result = self.run_shell('select_proxy_provider provider Foreign\nprintf "provider=%s\\n" "$provider"\n', stdin="99\n3\n")
        self.assertIn("provider=arvan", result.stdout)

    def test_dns_mode_can_be_corrected_without_reentering_domain(self):
        result = self.run_shell('''
domain=keep.example
direct_ip=203.0.113.10
provider=none
domain_points_to_ipv4() { return 1; }
domain_is_proxied_from_ipv4() { return 0; }
confirm_dns_settings domain direct_ip provider
printf '%s|%s|%s\n' "$domain" "$direct_ip" "$provider"
''', stdin="2\n3\n")
        self.assertIn("keep.example|203.0.113.10|arvan", result.stdout)

    def test_dns_recheck_preserves_values(self):
        result = self.run_shell('''
domain=keep.example
direct_ip=203.0.113.10
provider=none
checks=0
domain_points_to_ipv4() { checks=$((checks + 1)); (( checks > 1 )); }
confirm_dns_settings domain direct_ip provider
printf '%s|%s|%s|%s\n' "$domain" "$direct_ip" "$provider" "$checks"
''', stdin="1\n")
        self.assertIn("keep.example|203.0.113.10|none|2", result.stdout)

    def test_ports_retry_reserved_owned_and_occupied_ports(self):
        result = self.run_shell('''
mkdir -p "$TUNNELS_DIR/other"
printf '2054\n' > "$TUNNELS_DIR/other/ports.list"
ss() { [[ "$*" != *':2055'* ]] || echo 'LISTEN 0 128 0.0.0.0:2055 0.0.0.0:* users:(("other",pid=8,fd=1))'; }
ask_ports selected 'Client ports' 2053 none '' 80
printf 'selected=%s\n' "$selected"
''', stdin="80\n2054\n2055\n2056,2057\n")
        self.assertIn("selected=2056,2057", result.stdout)
        self.assertIn("reserved", result.stderr)
        self.assertIn("belongs to another tunnel", result.stderr)
        self.assertIn("already used", result.stderr)

    def test_proxy_ports_reject_unavailable_https_ports(self):
        result = self.run_shell('''
ask_ports arvan_ports 'Arvan HTTPS' 443 arvan - 80
ask_ports cf_ports 'Cloudflare HTTPS' 443 cloudflare - 80
printf '%s|%s\n' "$arvan_ports" "$cf_ports"
''', stdin="8443\n443\n12345\n443,8443\n")
        self.assertIn("443|443,8443", result.stdout)

    def test_backend_selection_avoids_public_and_target_ports(self):
        result = self.run_shell('''
port_is_listening() { return 1; }
select_backend_ports 18080,18081,18083
printf '%s|%s\n' "$backend_port" "$h2_backend_port"
''')
        self.assertIn("18082|\n", result.stdout)
        self.assertIn("No gRPC backend", result.stdout)

    def test_target_port_retry_does_not_ask_other_fields(self):
        result = self.run_shell('''
domain=keep.example
tcp_probe() { [[ "$2" == 18082 ]]; }
ask_target_port 18082 80,443
printf '%s|%s\n' "$domain" "$target_port"
''', stdin="bad\n443\n18083\n18082\n")
        self.assertIn("keep.example|18082", result.stdout)
        self.assertIn("Nothing accepts connections", result.stderr)

    def test_certificate_retry_retains_prior_settings(self):
        result = self.run_shell('''
cert_choice=1; email=keep@example.com; cert_path=/cert; key_path=/key
attempts=0
obtain_certificate() { attempts=$((attempts + 1)); (( attempts > 1 )); }
obtain_certificate_with_retry keep.example
printf '%s|%s|%s|%s\n' "$email" "$cert_path" "$key_path" "$attempts"
''', stdin="1\n")
        self.assertIn("keep@example.com|/cert|/key|2", result.stdout)

    def test_websocket_failure_allows_correcting_only_path(self):
        result = self.run_shell('''
domain=keep.example; direct_ip=203.0.113.10; foreign_provider=arvan; foreign_ports=443
token=0123456789abcdef; ws_path=/incorrect-old-path; ORIGIN_CA_PATH=/ca.pem
probe_websocket_path() { [[ "$4" == /correct-private-path ]]; }
confirm_foreign_websocket
printf '%s|%s|%s|%s\n' "$domain" "$token" "$ws_path" "$foreign_provider"
''', stdin="2\n/correct-private-path\n")
        self.assertIn("keep.example|0123456789abcdef|/correct-private-path|arvan", result.stdout)

    def test_websocket_failure_allows_correcting_only_token(self):
        result = self.run_shell('''
domain=keep.example; direct_ip=203.0.113.10; foreign_provider=arvan; foreign_ports=443
token=incorrect-old-token; ws_path=/private-websocket-path; ORIGIN_CA_PATH=/ca.pem
probe_websocket_path() { [[ "$5" == 0123456789abcdef ]]; }
confirm_foreign_websocket
printf '%s|%s|%s\n' "$domain" "$token" "$ws_path"
''', stdin="3\n0123456789abcdef\n")
        self.assertIn("keep.example|0123456789abcdef|/private-websocket-path", result.stdout)

    def test_cancel_after_retry_rolls_back_transaction(self):
        original = self.root / "config" / "token"
        original.write_text("retained")
        self.run_shell('''
transaction_begin origin
printf changed > "$CONFIG_DIR/token"
broken_step() { return 1; }
retry_step 'example check' broken_step
''', expected=1, stdin="n\n")
        self.assertEqual(original.read_text(), "retained")

    def test_ufw_creates_tunnel_directory_before_recording_rule(self):
        self.run_shell('''
CONFIG_DIR="$TUNNELS_DIR/new-tunnel"
open_ufw_ports 80
''')
        self.assertEqual((self.root / "config-root/tunnels/new-tunnel/firewall-owned.ports").read_text(), "80\n")

    def test_every_arvan_route_uses_compatible_verified_transport(self):
        self.run_shell('''
PROFILE_MAX_MEMORY=123456; PROFILE_MAX_STREAMS=123; ORIGIN_CA_PATH=/ca.pem
for iran in none cloudflare arvan; do
  write_origin_run_script edge.example 203.0.113.10 443 /private-wss-path /private-h2-path 18082 19080 8 .22 arvan "$iran" chrome off
  cp "$CONFIG_DIR/run.sh" "$ROOT/arvan-$iran.sh"
done
''')
        for iran in ("none", "cloudflare", "arvan"):
            script = (self.root / f"arvan-{iran}.sh").read_text()
            self.assertIn("-transport wss", script)
            self.assertIn("-tls-min-version 1.2", script)
            self.assertIn("-connect edge.example:443", script)
            self.assertIn("-ca /ca.pem", script)
            self.assertNotIn("-insecure", script)

    def websocket_fixture(self, response="upgrade", certificate_domain="right.example"):
        # RSA fixtures interoperate with macOS's older LibreSSL Python as well
        # as Linux OpenSSL. Production probes still accept verified ECDSA certs.
        cert, key = self.certificate(certificate_domain, rsa=True)
        server = socket.socket()
        try:
            server.bind(("127.0.0.1", 0))
        except PermissionError:
            server.close()
            self.skipTest("sandbox does not permit private loopback listeners")
        server.listen(1)
        server.settimeout(10)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_2
        # Make the ephemeral group explicit for older LibreSSL-backed Python;
        # the fixture still negotiates ECDHE with its RSA certificate.
        context.set_ecdh_curve("prime256v1")
        context.load_cert_chain(cert, key)
        errors = []

        def serve():
            try:
                raw, _ = server.accept()
                with raw:
                    with context.wrap_socket(raw, server_side=True) as connection:
                        data = b""
                        while b"\r\n\r\n" not in data:
                            data += connection.recv(2048)
                        lines = data.decode().split("\r\n")
                        headers = dict(line.split(": ", 1) for line in lines[1:] if ": " in line)
                        stamp, nonce, signature = headers["Authorization"][7:].split(".")
                        expected_signature = base64.urlsafe_b64encode(hmac.new(
                            b"0123456789abcdef", f"{stamp}\n{nonce}\nright.example\n/private-websocket-path".encode(), hashlib.sha256
                        ).digest()).decode().rstrip("=")
                        if not hmac.compare_digest(signature, expected_signature):
                            raise AssertionError("probe authentication does not match the transport")
                        if response == "upgrade":
                            accept = base64.b64encode(hashlib.sha1((headers["Sec-WebSocket-Key"] + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest()).decode()
                            connection.sendall(f"HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: {accept}\r\n\r\n".encode())
                        else:
                            connection.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 6\r\n\r\ncached")
            except ssl.SSLError as error:
                if certificate_domain == "right.example":
                    errors.append(f"unexpected TLS failure: {error}")
            except Exception as error:
                errors.append(str(error))
            finally:
                server.close()

        thread = threading.Thread(target=serve, daemon=True)
        thread.start()
        return cert, server.getsockname()[1], thread, errors

    def test_real_websocket_probe_supports_tls12_and_authenticates(self):
        cert, port, thread, errors = self.websocket_fixture()
        result = self.run_shell(f"probe_websocket_path right.example 127.0.0.1 {port} /private-websocket-path 0123456789abcdef {cert} 1.2\n")
        thread.join(2)
        self.assertFalse(errors, errors)
        self.assertIn("Authenticated WebSocket upgrade", result.stdout)
        self.assertIn("TLSv1.2", result.stdout)

    def test_real_websocket_probe_rejects_cached_success_page(self):
        cert, port, thread, errors = self.websocket_fixture(response="cached")
        result = self.run_shell(f"probe_websocket_path right.example 127.0.0.1 {port} /private-websocket-path 0123456789abcdef {cert} 1.2\n", expected=1)
        thread.join(2)
        self.assertFalse(errors, errors)
        self.assertIn("expected authenticated WebSocket 101", result.stderr)

    def test_real_websocket_probe_rejects_wrong_hostname(self):
        cert, port, thread, errors = self.websocket_fixture(certificate_domain="wrong.example")
        result = self.run_shell(f"probe_websocket_path right.example 127.0.0.1 {port} /private-websocket-path 0123456789abcdef {cert} 1.2\n", expected=1)
        thread.join(2)
        self.assertFalse(errors, errors)
        self.assertIn("certificate", result.stderr.lower())


if __name__ == "__main__":
    unittest.main(verbosity=2)
