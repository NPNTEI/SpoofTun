#!/usr/bin/env python3
"""Offline first-choice menu and exact embedded ICMP-helper bridge tests.

Only installer definitions, private temporary files and local OpenSSL run.
Host/network/root/deployment commands are forbidden. Both real interactive
helper modes run with --mode preselection; no binary, service or route runs.
"""
import importlib.util
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
PACKAGING = Path(__file__).resolve().parent


def load(name, filename):
    loader = importlib.util.spec_from_file_location(name, PACKAGING / filename)
    module = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(module)
    return module


installer = load("icmp_installer_fixture", "test-full-installer.py")
pair = load("icmp_installer_pair", "icmp-pair.py")


@unittest.skipUnless(shutil.which("openssl"), "local OpenSSL required for native paired certificate")
class ICMPInstallerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="gdt-icmp-installer-", dir=str(Path(tempfile.gettempdir()).resolve()))
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.definitions = self.root / "definitions.sh"
        self.definitions.write_text(installer.DEFINITIONS)
        self.stage = self.root / "stages"
        self.stage.mkdir(mode=0o700)
        self.output = self.root / "generated-pair"
        self.guard, self.calls, self.stages = (self.root / name for name in ("forbidden.log", "helper.log", "stages.log"))
        for path in (self.guard, self.calls, self.stages):
            path.touch()
        self.existing = self.root / "existing-deployment"
        self.existing.mkdir(mode=0o700)
        self.before = {}
        for name, value in (("token", b"existing-private-token\n"), ("run.sh", b"existing-launcher\n"),
                            ("ununknowntun.service", b"existing-unit\n"), ("nginx.conf", b"existing-site\n")):
            path = self.existing / name
            path.write_bytes(value)
            path.chmod(0o600)
            self.before[name] = value, path.stat().st_mode

    def answers(self, mode):
        values = ["AUTHORIZED", "installer-pair", "", ""]
        if mode == "native-icmp":
            values += ["eth0", "192.0.2.10", "10.78.0.1", "ens3", "192.0.2.20", "10.78.0.2",
                       "127.0.0.1:12055", "127.0.0.1:18082", "18443", "1200", "20", "on"]
        else:
            values += ["192.0.2.30", "127.0.0.1:18083", "127.0.0.1:12056", "3000", "4", "1000", "32"]
        return "\n".join(values) + "\n"

    def shell(self, body, stdin="", expected=0):
        q = shlex.quote
        guards = "\n".join(name + '() { deny ' + name + ' "$@"; }' for name in (
            "systemctl", "nginx", "ufw", "apt-get", "apt", "yum", "dnf", "useradd", "chown", "sysctl", "ip",
            "curl", "wget", "install", "sudo", "su", "require_root", "acquire_install_lock", "detect_os",
            "install_binary", "install_service_unit", "install_foreign", "install_origin", "upgrade_existing"))
        preamble = f'''
source {q(str(self.definitions))}
FIXTURE_ROOT={q(str(self.root))}
STAGE_ROOT={q(str(self.stage))}
STAGE_LOG={q(str(self.stages))}
HELPER_LOG={q(str(self.calls))}
GUARD_LOG={q(str(self.guard))}
EXPECTED_ICMP={q(str(PACKAGING / "icmp-pair.py"))}
EXPECTED_SHARED={q(str(PACKAGING / "spoof-pair.py"))}
REAL_PYTHON={q(sys.executable)}
OUTPUT={q(str(self.output))}
CONFIG_DIR={q(str(self.existing))}
BASE_CONFIG_DIR="$CONFIG_DIR"
TUNNELS_DIR="$CONFIG_DIR/tunnels"
INSTALL_DIR="$FIXTURE_ROOT/unused-install"
BIN_PATH="$FIXTURE_ROOT/never-run-ununknowntun"
UNIT_PATH="$CONFIG_DIR/ununknowntun.service"
LOCK_PATH="$FIXTURE_ROOT/unused.lock"
deny() {{ printf '%s\\n' "$*" >> "$GUARD_LOG"; return 97; }}
{guards}
mktemp() {{
    [[ "$#" == 1 && "$1" == -d ]] || {{ deny unexpected-mktemp; return 97; }}
    local created
    created="$(command mktemp -d "$STAGE_ROOT/helper.XXXXXXXX")"
    printf '%s\\n' "$created" >> "$STAGE_LOG"
    printf '%s\\n' "$created"
}}
python3() {{
    [[ ( "$#" == 4 || "$#" == 6 ) && "$1" == -I && "$2" == "$STAGE_ROOT"/helper.*/icmp-pair.py && "$3" == --output ]] || {{ deny unexpected-python; return 97; }}
    if [[ "$#" == 6 ]]; then
        [[ "$5" == --mode && ( "$6" == native-icmp || "$6" == icmp-wss ) ]] || {{ deny invalid-mode-args; return 97; }}
    fi
    cmp -s "$2" "$EXPECTED_ICMP" || {{ deny wrong-embedded-icmp-helper; return 97; }}
    local helper_dir="${{2%/*}}"
    cmp -s "$helper_dir/spoof-pair.py" "$EXPECTED_SHARED" || {{ deny wrong-embedded-shared-helper; return 97; }}
    command "$REAL_PYTHON" -I -c 'import os,stat,sys; p=sys.argv[1]; assert stat.S_IMODE(os.stat(p).st_mode)==0o700; assert set(os.listdir(p))=={{"icmp-pair.py","spoof-pair.py"}}; assert all(stat.S_IMODE(os.stat(p+"/"+n).st_mode)==0o600 for n in os.listdir(p))' "$helper_dir"
    printf 'exact helpers; mode=%s\\n' "${{6:-interactive}}" >> "$HELPER_LOG"
    command "$REAL_PYTHON" "$@"
}}
'''
        result = subprocess.run(["bash", "-c", preamble + body], input=stdin, text=True,
                                capture_output=True, timeout=30)
        self.assertEqual(result.returncode, expected, result.stdout + result.stderr)
        self.assertEqual(self.guard.read_text(), "", "Forbidden host/network/root operation attempted")
        self.assertEqual({p.name for p in self.existing.iterdir()}, set(self.before))
        for name, (value, mode) in self.before.items():
            self.assertEqual((self.existing / name).read_bytes(), value)
            self.assertEqual((self.existing / name).stat().st_mode, mode)
        self.assertFalse((self.root / "unused-install").exists())
        self.assertFalse((self.root / "unused.lock").exists())
        self.assertEqual(list(self.stage.iterdir()), [], "Private extracted helpers were not cleaned")
        for created in self.stages.read_text().splitlines():
            self.assertFalse(Path(created).exists())
        return result

    def assert_pair(self, result, mode, selected=True):
        spec = pair.check_pair(str(self.output))
        self.assertEqual(spec["mode"], mode)
        self.assertEqual(spec["pair_id"], "installer-pair")
        self.assertEqual(self.calls.read_text(), "exact helpers; mode=" + (mode if selected else "interactive") + "\n")
        self.assertEqual(len(self.stages.read_text().splitlines()), 1)
        self.assertIn("PRIVATE ICMP PAIR PREPARED", result.stdout)
        self.assertIn("No network test was performed", result.stdout)
        for role in ("origin", "egress"):
            home = self.output / role
            self.assertNotIn((home / "icmp.key").read_text().strip(), result.stdout + result.stderr)
            self.assertTrue((home / "run.sh").is_file())
            self.assertTrue((home / "check.sh").is_file())
            self.assertEqual(home.stat().st_mode & 0o777, 0o700)
            for item in home.iterdir():
                self.assertEqual(item.stat().st_mode & 0o777, 0o600)
        if mode == "native-icmp":
            self.assertFalse((self.output / "origin/server.key").exists())
            self.assertTrue((self.output / "egress/server.key").is_file())
            self.assertNotIn((self.output / "origin/token").read_text().strip(), result.stdout + result.stderr)
        else:
            self.assertEqual(list((self.output / "origin").glob("*.service")), [])
            self.assertEqual(len(list((self.output / "egress").glob("*.service"))), 1)

    def test_first_choice_dispatches_all_modes_before_any_host_action(self):
        body = '''
install_foreign() { printf 'managed-egress\\n' >> "$HELPER_LOG"; }
install_origin() { printf 'managed-origin\\n' >> "$HELPER_LOG"; }
generate_icmp_pair() { printf 'icmp:%s:%s\\n' "$1" "$2" >> "$HELPER_LOG"; }
generate_spoof_pair() { printf 'gre\\n' >> "$HELPER_LOG"; }
valid_four_choices 1; valid_four_choices 4; ! valid_four_choices 0; ! valid_four_choices 5
create_tunnel egress; create_tunnel origin
create_tunnel egress; create_tunnel origin
create_tunnel egress; create_tunnel origin
create_tunnel egress; create_tunnel origin
'''
        result = self.shell(body, "1\n1\n2\n2\n3\n3\n4\n4\n")
        self.assertEqual(self.calls.read_text().splitlines(), ["managed-egress", "managed-origin",
                         "icmp::native-icmp", "icmp::native-icmp", "icmp::icmp-wss", "icmp::icmp-wss", "gre", "gre"])
        self.assertIn("1) Existing managed WSS / XHTTP", result.stdout)
        self.assertIn("2) Native ICMP carrier", result.stdout)
        self.assertIn("3) ICMP Echo inside WSS", result.stdout)
        self.assertIn("4) Native IP source spoof / GRE", result.stdout)
        self.assertEqual(self.stages.read_text(), "")

    def test_main_foreign_first_choice_reaches_real_native_preselected_wizard(self):
        result = self.shell("main_menu\n", "1\n2\n" + str(self.output) + "\n" + self.answers("native-icmp"))
        self.assert_pair(result, "native-icmp")

    def test_main_iran_first_choice_reaches_real_relay_preselected_wizard(self):
        result = self.shell("main_menu\n", "2\n3\n" + str(self.output) + "\n" + self.answers("icmp-wss"))
        self.assert_pair(result, "icmp-wss")

    def test_foreign_dispatcher_preserves_first_choice_native(self):
        dispatcher = installer.DISPATCH + installer.SOURCE.split(installer.DISPATCH, 1)[1]
        result = self.shell("set -- foreign\n" + dispatcher, "2\n" + str(self.output) + "\n" + self.answers("native-icmp"))
        self.assert_pair(result, "native-icmp")

    def test_iran_dispatcher_preserves_first_choice_relay(self):
        dispatcher = installer.DISPATCH + installer.SOURCE.split(installer.DISPATCH, 1)[1]
        result = self.shell("set -- iran\n" + dispatcher, "3\n" + str(self.output) + "\n" + self.answers("icmp-wss"))
        self.assert_pair(result, "icmp-wss")

    def test_icmp_pair_dispatcher_unselected_mode_is_real_interactive(self):
        dispatcher = installer.DISPATCH + installer.SOURCE.split(installer.DISPATCH, 1)[1]
        result = self.shell('set -- icmp-pair "$OUTPUT"\n' + dispatcher, "2\n" + self.answers("icmp-wss"))
        self.assert_pair(result, "icmp-wss", selected=False)

    def test_authorization_failure_cleans_both_helpers(self):
        result = self.shell('generate_icmp_pair "$OUTPUT" icmp-wss\n', "NO\n", expected=1)
        self.assertIn("Explicit authorization was not given", result.stderr)
        self.assertEqual(self.calls.read_text(), "exact helpers; mode=icmp-wss\n")
        self.assertFalse(self.output.exists())

    def test_dispatcher_propagates_unselected_wizard_failure(self):
        dispatcher = installer.DISPATCH + installer.SOURCE.split(installer.DISPATCH, 1)[1]
        result = self.shell('set -- icmp-pair "$OUTPUT"\n' + dispatcher, "2\nNO\n", expected=1)
        self.assertIn("Explicit authorization was not given", result.stderr)
        self.assertEqual(self.calls.read_text(), "exact helpers; mode=interactive\n")
        self.assertFalse(self.output.exists())

    def test_eof_failure_cleans_both_helpers(self):
        result = self.shell('generate_icmp_pair "$OUTPUT" native-icmp\n', expected=1)
        self.assertIn("Nothing was activated", result.stderr)
        self.assertEqual(self.calls.read_text(), "exact helpers; mode=native-icmp\n")
        self.assertFalse(self.output.exists())

    def test_existing_destination_unchanged_and_failure_cleans_helpers(self):
        self.output.mkdir(mode=0o700)
        marker = self.output / "existing.txt"
        marker.write_text("leave this private directory unchanged\n")
        result = self.shell('generate_icmp_pair "$OUTPUT" icmp-wss\n', self.answers("icmp-wss"), expected=1)
        self.assertIn("Output already exists", result.stderr)
        self.assertEqual(marker.read_text(), "leave this private directory unchanged\n")
        self.assertEqual(list(self.output.iterdir()), [marker])

    def test_relative_destination_fails_before_staging(self):
        result = self.shell("generate_icmp_pair relative-path icmp-wss\n", expected=1)
        self.assertIn("absolute output directory", result.stderr)
        self.assertEqual(self.calls.read_text(), "")
        self.assertEqual(self.stages.read_text(), "")

    def test_invalid_preselection_fails_before_staging(self):
        result = self.shell('generate_icmp_pair "$OUTPUT" invalid\n', expected=1)
        self.assertIn("Invalid ICMP mode", result.stderr)
        self.assertEqual(self.calls.read_text(), "")
        self.assertEqual(self.stages.read_text(), "")

    def test_metacharacters_are_data_and_rejected_without_execution(self):
        injected = str(self.output) + ";touch " + str(self.root / "injected")
        result = self.shell("generate_icmp_pair " + shlex.quote(injected) + " icmp-wss\n", self.answers("icmp-wss"), expected=1)
        self.assertIn("simple path components", result.stderr)
        self.assertFalse((self.root / "injected").exists())
        self.assertFalse(self.output.exists())


if __name__ == "__main__":
    unittest.main()
