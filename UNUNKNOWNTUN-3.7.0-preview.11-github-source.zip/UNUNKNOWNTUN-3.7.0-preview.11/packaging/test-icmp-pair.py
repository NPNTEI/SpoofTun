#!/usr/bin/env python3
"""Offline paired ICMP wizard tests. No root, services or network actions."""
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shlex
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch


sys.dont_write_bytecode = True
MODULE = Path(__file__).with_name("icmp-pair.py")
LOADER = importlib.util.spec_from_file_location("icmp_pair", MODULE)
pair = importlib.util.module_from_spec(LOADER)
LOADER.loader.exec_module(pair)


def native():
    return {"mode": "native-icmp", "pair_id": "test-native", "authorized": True,
            "origin": {"interface": "eth0", "real_ip": "192.0.2.10", "inner_ip": "10.78.0.1"},
            "egress": {"interface": "ens3", "real_ip": "192.0.2.20", "inner_ip": "10.78.0.2"}}


def relay():
    return {"mode": "icmp-wss", "pair_id": "test-relay", "authorized": True, "target": "192.0.2.30"}


class SpecTests(unittest.TestCase):
    def test_native_exact_crossed_fields_and_defaults(self):
        value = native()
        saved = copy.deepcopy(value)
        spec = pair.validate_spec(value)
        self.assertEqual(saved, value)
        self.assertEqual(spec["binary_path"], pair.DEFAULT_BINARY)
        self.assertEqual((spec["mtu"], spec["poll_ms"], spec["carrier_port"]), (1200, 20, 18443))
        self.assertEqual(spec["install_dir"], "/etc/ununknowntun-icmp/test-native")
        first, second = (pair.endpoint_config(spec, role) for role in ("origin", "egress"))
        self.assertEqual(first["local_ip"], second["peer_ip"])
        self.assertEqual(first["peer_ip"], second["local_ip"])
        self.assertEqual(first["inner_local_ip"], second["inner_peer_ip"])
        self.assertEqual(first["inner_peer_ip"], second["inner_local_ip"])
        self.assertEqual(first["key_file"], spec["install_dir"] + "/origin/icmp.key")
        self.assertEqual(set(first), {"interface", "tun_name", "local_ip", "peer_ip", "inner_local_ip", "inner_peer_ip",
                                    "mtu", "carrier_port", "authorized", "key_file", "poll_ms"})
        self.assertTrue(first["tun_name"].startswith("gdi"))
        self.assertNotEqual(first["tun_name"], second["tun_name"])

    def test_relay_exact_role_fields_and_defaults(self):
        spec = pair.validate_spec(relay())
        origin, egress = (pair.endpoint_config(spec, role) for role in ("origin", "egress"))
        self.assertEqual(origin["connect"], "127.0.0.1:12056")
        self.assertEqual(egress["listen"], "127.0.0.1:18083")
        self.assertEqual(origin["target"], egress["target"])
        self.assertEqual((origin["count"], origin["timeout_ms"], origin["interval_ms"], origin["payload_bytes"]), (4, 3000, 1000, 32))
        self.assertEqual(set(egress), {"role", "target", "authorized", "key_file", "timeout_ms", "listen"})
        self.assertNotIn("listen", origin)
        self.assertNotIn("source_ip", origin)

    def test_authorization_and_mode_require_exact_types(self):
        for sample in (native, relay):
            for value in (False, 1, 1.0, "true", None, [], {}):
                with self.subTest(sample=sample.__name__, value=value), self.assertRaises(pair.PairError):
                    pair.validate_spec(dict(sample(), authorized=value))
            for mode in (None, True, 1, "icmp", "NATIVE-ICMP", "", ["native-icmp"]):
                with self.assertRaises(pair.PairError):
                    pair.validate_spec(dict(sample(), mode=mode))

    def test_unknown_cross_mode_and_spoof_fields_rejected(self):
        for sample, keys in ((native, ("source_ip", "relay_listen", "count", "wss_token", "key_file")),
                             (relay, ("origin", "egress", "carrier_port", "mtu", "mux", "poll_ms", "token", "ws_host"))):
            for key in keys:
                with self.subTest(key=key), self.assertRaises(pair.PairError):
                    pair.validate_spec(dict(sample(), **{key: "x"}))
        for key in ("source_ip", "expected_peer_source_ip", "spoof_dst_ip", "spoof_src_ip"):
            value = native()
            value["origin"][key] = "198.51.100.10"
            with self.assertRaises(pair.PairError):
                pair.validate_spec(value)

    def test_strict_json_duplicate_missing_null_and_bounded(self):
        for data in (b'{"mode":"icmp-wss","mode":"native-icmp"}', b'{"a":{"x":1,"x":2}}', b'{"x":NaN}',
                     b'{"x":Infinity}', b'\xff', b'{', b'{} {}', b' ' * (pair.base.MAX_JSON + 1)):
            with self.assertRaises(pair.PairError):
                pair.base.strict_json(data)
        for value in ({}, [], None, dict(native(), origin=None), dict(relay(), target=None)):
            with self.assertRaises(pair.PairError):
                pair.validate_spec(value)

    def test_names_paths_and_injection_rejected(self):
        for sample in (native, relay):
            for value in ("", "X", "-abc", "a" * 25, "a/b", "a%u", "a;id", "a\nExecStart=bad"):
                with self.assertRaises(pair.PairError):
                    pair.validate_spec(dict(sample(), pair_id=value))
            for key in ("binary_path", "install_dir"):
                for value in ("relative", "/", "/a//b", "/a/../b", "/a/./b", "/a/", "/a b", "/a%u", "/a$HOME",
                              "/a$(id)", "/a`id`", "/a;id", "/a'b", "/a\nb", None):
                    with self.subTest(key=key, value=value), self.assertRaises(pair.PairError):
                        pair.validate_spec(dict(sample(), **{key: value}))
            with self.assertRaises(pair.PairError):
                pair.validate_spec(dict(sample(), binary_path="/private/config/ununknowntun", install_dir="/private/config"))

    def test_native_addresses_and_interfaces(self):
        for field in ("real_ip", "inner_ip"):
            for address in ("host.example", "192.0.2.010", "::1", "127.0.0.1", "0.1.1.1", "0.0.0.0", "224.1.2.3",
                            "240.0.0.1", "169.254.1.1", "1.2.3.4\n", 1):
                value = native()
                value["origin"][field] = address
                with self.assertRaises(pair.PairError):
                    pair.validate_spec(value)
        for field in ("interface", "tun_name"):
            for name in ("lo", "", "x" * 16, "eth0;id", "eth 0", "../eth0", "-eth0", 1):
                value = native()
                value["origin"][field] = name
                with self.assertRaises(pair.PairError):
                    pair.validate_spec(value)
        for field in ("real_ip", "inner_ip"):
            value = native()
            value["origin"][field] = value["egress"][field]
            with self.assertRaises(pair.PairError):
                pair.validate_spec(value)

    def test_relay_target_and_loopback_restriction(self):
        for target in ("127.0.0.1", "0.0.0.0", "0.1.1.1", "169.254.1.1", "224.1.1.1", "240.1.1.1", "255.255.255.255",
                       "192.0.2.010", "::1", "host.example", "192.0.2.1:80", "1.2.3.4\n", 1):
            with self.assertRaises(pair.PairError):
                pair.validate_spec(dict(relay(), target=target))
        for key in ("relay_listen", "client_connect"):
            for endpoint in ("0.0.0.0:18083", "192.0.2.1:18083", "localhost:18083", "[::1]:18083", "127.0.0.1:80",
                             "127.0.0.1:65536", "127.0.0.1:018083", "127.0.0.1:18083,other", None):
                with self.assertRaises(pair.PairError):
                    pair.validate_spec(dict(relay(), **{key: endpoint}))
        for target in ("10.1.2.3", "192.0.2.1", "198.51.100.1", "203.0.113.2"):
            self.assertEqual(pair.validate_spec(dict(relay(), target=target))["target"], target)

    def test_numeric_type_bounds(self):
        for sample, bounds in ((native, (("mtu", 576, 1400), ("carrier_port", 1024, 65535), ("poll_ms", 5, 1000))),
                               (relay, (("timeout_ms", 250, 10000), ("count", 1, 10), ("interval_ms", 1000, 10000), ("payload_bytes", 16, 256)))):
            for key, low, high in bounds:
                for value in (True, False, str(low), float(low), None, low - 1, high + 1):
                    with self.subTest(key=key, value=value), self.assertRaises(pair.PairError):
                        pair.validate_spec(dict(sample(), **{key: value}))
                for value in (low, high):
                    self.assertEqual(pair.validate_spec(dict(sample(), **{key: value}))[key], value)


class RenderTests(unittest.TestCase):
    def test_native_launchers_keep_tls_token_pin_and_offline_checks(self):
        spec, pin = pair.validate_spec(native()), "a" * 64
        for role in ("origin", "egress"):
            args = pair.command_args(spec, role, pin)
            self.assertIn("-token-file", args)
            self.assertIn("-icmp-config", args)
            self.assertNotIn("-spoof-config", args)
            self.assertNotIn("-pad", args)
            self.assertIn("tls", args)
            check = pair.command_args(spec, role, pin, True)
            self.assertIn("-check-icmp-config", check)
            self.assertNotIn("-check-tunnel", check)
            content = pair.launcher(spec, role, pin).decode()
            self.assertEqual(shlex.split(content.split("exec ", 1)[1]), args)
        self.assertIn(pin, pair.command_args(spec, "origin", pin))
        self.assertIn("-allow", pair.command_args(spec, "egress", pin))

    def test_relay_launchers_and_exact_wss_mapping(self):
        spec = pair.validate_spec(relay())
        self.assertEqual(pair.command_args(spec, "origin")[1], "-icmp-ping")
        self.assertEqual(pair.command_args(spec, "egress")[1], "-icmp-relay")
        for role in ("origin", "egress"):
            self.assertEqual(pair.command_args(spec, role, check=True)[1], "-check-icmp-relay-config")
        readme = pair.readme(spec).decode()
        self.assertIn(spec["client_connect"], readme)
        self.assertIn(spec["relay_listen"], readme)
        self.assertIn("dedicated ping client only", readme)
        self.assertIn("not system ping", readme)

    def test_separate_least_privilege_service_templates(self):
        native_spec, relay_spec = pair.validate_spec(native()), pair.validate_spec(relay())
        for role in ("origin", "egress"):
            unit = pair.service(native_spec, role).decode()
            self.assertIn("CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_RAW\n", unit)
            self.assertIn("AF_INET AF_INET6 AF_NETLINK", unit)
            self.assertIn("DeviceAllow=/dev/net/tun rw", unit)
            self.assertIn("PrivateDevices=no", unit)
            self.assertIn("/" + role + "/run.sh", unit)
        relay_unit = pair.service(relay_spec, "egress").decode()
        self.assertIn("CapabilityBoundingSet=CAP_NET_RAW\n", relay_unit)
        self.assertNotIn("CAP_NET_ADMIN", relay_unit)
        self.assertNotIn("/dev/net/tun", relay_unit)
        self.assertIn("PrivateDevices=yes", relay_unit)
        self.assertNotEqual(pair.unit_name(native_spec), pair.unit_name(relay_spec))
        with self.assertRaises(pair.PairError):
            pair.service(relay_spec, "origin")


class BundleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.certificate = pair.base.make_certificate({"pair_id": "offline-icmp"}, pair.base.openssl_binary())

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="gdt-icmp-pair-")
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name).resolve()

    def create(self, mode="native-icmp", name="pair"):
        value = native() if mode == "native-icmp" else relay()
        value["install_dir"] = str(self.root / name)
        output = self.root / name
        with patch.object(pair.base, "make_certificate", return_value=self.certificate):
            spec = pair.generate(value, str(output))
        return output, spec

    def test_both_bundles_roundtrip_and_private_modes(self):
        for mode in ("native-icmp", "icmp-wss"):
            output, spec = self.create(mode, mode)
            self.assertEqual(pair.check_pair(str(output)), spec)
            for directory, subdirs, files in os.walk(output):
                self.assertEqual(stat.S_IMODE(os.stat(directory).st_mode), 0o700)
                for name in files:
                    self.assertEqual(stat.S_IMODE(os.stat(Path(directory) / name).st_mode), 0o600)
            self.assertEqual((output / "origin/icmp.key").read_bytes(), (output / "egress/icmp.key").read_bytes())
            self.assertFalse((output / "origin/server.key").exists())
            if mode == "native-icmp":
                self.assertNotEqual((output / "origin/icmp.key").read_bytes(), (output / "origin/token").read_bytes())
            else:
                self.assertEqual(set(path.name for path in (output / "origin").iterdir()), {"ping.json", "icmp.key", "run.sh", "check.sh"})
                self.assertFalse((output / "egress/token").exists())

    def test_secrets_are_fresh_and_never_summary_output(self):
        first, spec = self.create(name="first")
        second, _ = self.create(name="second")
        for name in ("icmp.key", "token"):
            self.assertNotEqual((first / "origin" / name).read_bytes(), (second / "origin" / name).read_bytes())
        capture = io.StringIO()
        with contextlib.redirect_stdout(capture):
            pair.summary(spec, str(first))
        text = capture.getvalue()
        for name in ("icmp.key", "token"):
            self.assertNotIn((first / "origin" / name).read_text().strip(), text)
        self.assertNotIn(self.certificate[0].decode().strip(), text)

    def test_no_overwrite_and_no_openssl_for_relay(self):
        output, _ = self.create("icmp-wss")
        before = (output / "origin/icmp.key").read_bytes()
        with patch.object(pair.base, "make_certificate", side_effect=AssertionError("must not be called")), self.assertRaises(pair.PairError):
            pair.generate(relay(), str(output))
        self.assertEqual((output / "origin/icmp.key").read_bytes(), before)
        with patch.object(pair.base, "openssl_binary", side_effect=AssertionError("relay must not use TLS generator")):
            second, _ = self.create("icmp-wss", "second")
            pair.check_pair(str(second))

    def test_mismatched_key_config_and_strict_types_rejected(self):
        for index, (mode, key, value) in enumerate((("native-icmp", "authorized", 1), ("native-icmp", "mtu", 1200.0),
              ("native-icmp", "carrier_port", 18443.0), ("native-icmp", "poll_ms", 20.0),
              ("icmp-wss", "authorized", 1), ("icmp-wss", "count", 4.0), ("icmp-wss", "timeout_ms", 3000.0))):
            output, spec = self.create(mode, "mutation" + str(index))
            path = output / "origin" / pair.config_name(spec, "origin")
            data = json.loads(path.read_text())
            data[key] = value
            path.write_bytes(pair.base.json_bytes(data))
            with self.assertRaises(pair.PairError):
                pair.check_pair(str(output))
        output, _ = self.create("icmp-wss", "keys")
        (output / "origin/icmp.key").write_bytes(b"a" * 64 + b"\n")
        with self.assertRaises(pair.PairError):
            pair.check_pair(str(output))

    def test_launcher_service_and_extra_file_tampering_rejected(self):
        for index, entry in enumerate(("origin/run.sh", "origin/check.sh", "egress/ununknowntun-icmp-wss-test-relay.service", "README.txt")):
            output, _ = self.create("icmp-wss", "edit" + str(index))
            with (output / entry).open("ab") as stream:
                stream.write(b"\n# changed\n")
            with self.assertRaises(pair.PairError):
                pair.check_pair(str(output))
        output, _ = self.create("icmp-wss", "extra")
        (output / "origin/extra").write_text("unexpected")
        with self.assertRaises(pair.PairError):
            pair.check_pair(str(output))

    def test_symlinks_hardlinks_fifo_and_permissions_rejected(self):
        output, _ = self.create("icmp-wss")
        alias = self.root / "alias"
        alias.symlink_to(output, target_is_directory=True)
        with self.assertRaises((OSError, pair.PairError)):
            pair.check_pair(str(alias))
        with self.assertRaises((OSError, pair.PairError)):
            pair.generate(relay(), str(alias / "new"))
        key = output / "origin/icmp.key"
        original = key.read_bytes()
        key.unlink()
        key.symlink_to(output / "egress/icmp.key")
        with self.assertRaises((OSError, pair.PairError)):
            pair.check_pair(str(output))
        key.unlink()
        os.link(output / "egress/icmp.key", key)
        with self.assertRaises(pair.PairError):
            pair.check_pair(str(output))
        key.unlink()
        os.mkfifo(key, 0o600)
        with self.assertRaises(pair.PairError):
            pair.check_pair(str(output))
        key.unlink()
        key.write_bytes(original)
        key.chmod(0o644)
        with self.assertRaises(pair.PairError):
            pair.check_pair(str(output))
        key.chmod(0o600)
        (output / "origin").chmod(0o755)
        with self.assertRaises(pair.PairError):
            pair.check_pair(str(output))

    def test_native_pin_and_private_key_validation(self):
        output, spec = self.create()
        bad_pin = "b" * 64
        for role in ("origin", "egress"):
            (output / role / "pin.sha256").write_text(bad_pin + "\n")
            (output / role / "run.sh").write_bytes(pair.launcher(spec, role, bad_pin))
        with self.assertRaises(pair.PairError):
            pair.check_pair(str(output))

    def test_cli_generation_and_check_do_not_activate_binary(self):
        marker = self.root / "never-executed"
        fake_binary = self.root / "fake-binary"
        fake_binary.write_text("#!/bin/sh\ntouch " + shlex.quote(str(marker)) + "\nexit 99\n")
        fake_binary.chmod(0o700)
        spec_path = self.root / "spec.json"
        spec_path.write_bytes(pair.base.json_bytes(dict(relay(), binary_path=str(fake_binary))))
        output = self.root / "cli"
        for args in (("--spec", str(spec_path), "--output", str(output)), ("--check-pair", str(output))):
            result = subprocess.run([sys.executable, "-I", str(MODULE), *args], capture_output=True, timeout=10)
            self.assertEqual(result.returncode, 0, result.stderr.decode())
        self.assertFalse(marker.exists())

    def test_shell_syntax_and_optional_final_core_config_check(self):
        binary = os.environ.get("UNUNKNOWNTUN_TEST_BINARY")
        for mode in ("native-icmp", "icmp-wss"):
            output, spec = self.create(mode, "core-" + mode)
            for role in ("origin", "egress"):
                for script in ("run.sh", "check.sh"):
                    result = subprocess.run(["/bin/sh", "-n", str(output / role / script)], capture_output=True, timeout=5)
                    self.assertEqual(result.returncode, 0, result.stderr.decode())
                if binary:
                    args = pair.command_args(spec, role, check=True)
                    args[0] = str(Path(binary).resolve())
                    result = subprocess.run(args, capture_output=True, timeout=10)
                    self.assertEqual(result.returncode, 0, result.stderr.decode())
        if not binary:
            self.skipTest("Set UNUNKNOWNTUN_TEST_BINARY for final-core offline parser integration; shell syntax passed.")


class WizardTests(unittest.TestCase):
    def test_first_mode_selector_and_explicit_authorization(self):
        with patch("builtins.input", side_effect=["2", "NO"]), contextlib.redirect_stdout(io.StringIO()), self.assertRaises(pair.PairError):
            pair.wizard()
        with patch("builtins.input", side_effect=["bad"]), contextlib.redirect_stdout(io.StringIO()), self.assertRaises(pair.PairError):
            pair.wizard()

    def test_both_interactive_paths(self):
        native_answers = ["1", "AUTHORIZED", "wizard-native", "", "", "", "192.0.2.10", "", "", "192.0.2.20", "",
                          "", "", "", "", "", ""]
        relay_answers = ["2", "AUTHORIZED", "wizard-relay", "", "", "192.0.2.30", "", "", "", "", "", ""]
        for answers, mode in ((native_answers, "native-icmp"), (relay_answers, "icmp-wss")):
            with patch("builtins.input", side_effect=answers), contextlib.redirect_stdout(io.StringIO()):
                spec = pair.wizard()
            self.assertEqual(spec["mode"], mode)
            self.assertIs(spec["authorized"], True)


if __name__ == "__main__":
    unittest.main()
