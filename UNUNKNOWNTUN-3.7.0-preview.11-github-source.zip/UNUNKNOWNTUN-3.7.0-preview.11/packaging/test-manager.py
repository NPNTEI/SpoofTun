#!/usr/bin/env python3
"""Isolated manager regressions; never controls actual services or firewall rules."""
import base64
import json
from pathlib import Path
import shlex
import subprocess
import tempfile
import unittest


SOURCE = Path(__file__).with_name("full-installer.template.sh").read_text()
MANAGER = SOURCE.split('cat > "$CTL_PATH" <<\'CTL\'\n', 1)[1].split("\nCTL\n", 1)[0]
DEFINITIONS = MANAGER.split('\ncommand_name=', 1)[0]


class ManagerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="ununknowntun-manager-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.config = self.root / "tunnels/test"
        self.config.mkdir(parents=True)
        self.defs = self.root / "manager.sh"
        self.defs.write_text(DEFINITIONS)
        self.env = {
            "ROLE": "origin", "PAIR_ID": "a1b2c3d4e5f60718", "IRAN_IP": "203.0.113.10",
            "FOREIGN_IP": "203.0.113.20", "FOREIGN_PORTS": "443,8443", "FOREIGN_DOMAIN": "edge.example",
            "FOREIGN_PROXY_PROVIDER": "none", "IRAN_PROXY_PROVIDER": "none", "LOCAL_PORTS": "21000",
            "IRAN_ENTRY_PORTS": "21000", "WSS_BACKEND_PORT": "18080", "H2_BACKEND_PORT": "18081", "TARGET_PORT": "18082",
        }
        self.write_env()
        (self.config / "run.sh").write_text("#!/bin/sh\nexec /bin/false \\\n  -connect 203.0.113.20:443,203.0.113.20:8443 \\\n  -listen 0.0.0.0:21000 \\\n  -mode origin\n")
        (self.config / "peer.env").write_text("FORMAT=UNUNKNOWNTUN_V3_FLEET\nTOKEN=keep-this-private\nFOREIGN_IP=203.0.113.20\nPORTS=443,8443\n")

    def write_env(self):
        (self.config / "deployment.env").write_text("".join(f"{key}={shlex.quote(value)}\n" for key, value in self.env.items()))

    def shell(self, body, stdin="", expected=0):
        preamble = f'''source {shlex.quote(str(self.defs))}
TUNNELS_DIR={shlex.quote(str(self.root / "tunnels"))}
INSTALL_DIR={shlex.quote(str(self.root / "install"))}
systemctl() {{ printf '%s\\n' "$*" >> {shlex.quote(str(self.root / "services.log"))}; return 0; }}
manager_lock() {{ echo unexpected-shell-lock >&2; return 99; }}
'''
        result = subprocess.run(["bash", "-c", preamble + body], input=stdin, text=True, capture_output=True)
        self.assertEqual(result.returncode, expected, result.stdout + result.stderr)
        return result

    def test_edit_ip_retries_only_invalid_field_and_emits_single_change(self):
        result = self.shell("edit_ip test\n", "bad\n2\n127.0.0.1\n203.0.113.25\n")
        self.assertIn("Choose 1 or 2", result.stderr)
        self.assertIn("Invalid public IPv4", result.stderr)
        decoded = base64.b64decode(result.stdout.splitlines()[-1]).decode()
        self.assertIn("FIELD=FOREIGN_IP\nPREVIOUS=203.0.113.20\nVALUE=203.0.113.25", decoded)
        self.assertNotIn("FOREIGN_PORTS=", decoded)
        self.assertNotIn("IRAN_IP=", decoded)
        self.assertIn("-connect 203.0.113.25:443,203.0.113.25:8443", (self.config / "run.sh").read_text())
        self.assertIn("FOREIGN_IP=203.0.113.25", (self.config / "peer.env").read_text())
        self.assertIn("TOKEN=keep-this-private", (self.config / "peer.env").read_text())

    def diagnostic_mocks(self):
        return '''
function /usr/local/bin/ununknowntun() { echo 'ununknowntun test-fixture'; }
systemctl() { if [[ "$1" == show ]]; then echo 0123456789abcdef0123456789abcdef; else echo active; fi; }
journalctl() {
    [[ "$1" == _SYSTEMD_INVOCATION_ID=0123456789abcdef0123456789abcdef && "$2" == -n && "$3" == 80 ]] || return 99
    printf '[stats] sessions=0 streams=0\\n[origin] no tunnel session available: stage=tls timeout\\n'
}
timeout() { shift; "$@"; }
openssl() { printf 'openssl-arg=%s\\n' "$@"; }
'''

    def test_diagnostic_strict_ech_and_fragment_never_use_plain_tls(self):
        path = self.config / "run.sh"
        original = path.read_text()
        for mode in ("  -ech-mode strict \\\n", "  -tls-fragment hello \\\n"):
            path.write_text(original.replace("  -mode origin", mode + "  -mux off \\\n  -mode origin"))
            result = self.shell(self.diagnostic_mocks() + 'test_tunnel test\n')
            self.assertIn("Plain OpenSSL probe skipped", result.stdout)
            self.assertNotIn("openssl-arg=", result.stdout)
            self.assertIn("current service invocation only", result.stdout)
            self.assertIn("zero idle sessions is expected, not proof", result.stdout)
            self.assertIn("stage=tls timeout", result.stdout)

    def test_diagnostic_plain_tls_uses_launch_ca_and_minimum_not_provider(self):
        self.env["FOREIGN_PROXY_PROVIDER"] = "arvan"
        self.write_env()
        path = self.config / "run.sh"
        path.write_text(path.read_text().replace("  -mode origin", "  -tls-min-version 1.3 \\\n  -ca /custom/trusted-ca.pem \\\n  -mode origin"))
        result = self.shell(self.diagnostic_mocks() + 'test_tunnel test\n')
        self.assertIn("ordinary TLS/certificate probe only", result.stdout)
        self.assertIn("openssl-arg=-min_protocol\nopenssl-arg=TLSv1.3", result.stdout)
        self.assertIn("openssl-arg=-CAfile\nopenssl-arg=/custom/trusted-ca.pem", result.stdout)
        self.assertNotIn("openssl-arg=-tls1_2", result.stdout)

    def test_diagnostic_rejects_duplicate_flags_without_probe(self):
        path = self.config / "run.sh"
        path.write_text(path.read_text().replace("  -mode origin", "  -ech-mode off \\\n  -ech-mode strict \\\n  -mode origin"))
        result = self.shell(self.diagnostic_mocks() + 'test_tunnel test\n', expected=1)
        self.assertIn("Could not read actual launch settings safely", result.stderr)
        self.assertNotIn("openssl-arg=", result.stdout)

    def test_restart_failure_rolls_back_ip_and_launcher(self):
        original = (self.config / "deployment.env").read_bytes()
        launcher = (self.config / "run.sh").read_bytes()
        result = self.shell('systemctl() { return 1; }\napply_metadata_change test FOREIGN_IP 203.0.113.30\n', expected=1)
        self.assertIn("previous settings restored", result.stderr)
        self.assertEqual((self.config / "deployment.env").read_bytes(), original)
        self.assertEqual((self.config / "run.sh").read_bytes(), launcher)

    def update_code(self, previous="203.0.113.10", value="203.0.113.11", field="IRAN_IP"):
        return base64.b64encode(f"FORMAT=UNUNKNOWNTUN_UPDATE_V2\nPAIR_ID=a1b2c3d4e5f60718\nFIELD={field}\nPREVIOUS={previous}\nVALUE={value}\n".encode()).decode() + "\n"

    def test_sync_preserves_unrelated_fields_and_rejects_stale_update(self):
        self.shell("apply_update\n", self.update_code())
        current = (self.config / "deployment.env").read_text()
        self.assertIn("IRAN_IP=203.0.113.11", current)
        self.assertIn("FOREIGN_PORTS=443,8443", current)
        self.assertIn("FOREIGN_IP=203.0.113.20", current)
        self.shell("apply_update\n", self.update_code(value="203.0.113.12"), expected=1)
        self.assertEqual((self.config / "deployment.env").read_text(), current)

    def test_foreign_ports_sync_refreshes_peer_without_remote_registry(self):
        self.shell("apply_update\n", self.update_code("443,8443", "443,2053", "FOREIGN_PORTS"))
        self.assertIn("PORTS=443,2053", (self.config / "peer.env").read_text())
        self.assertEqual((self.config / "ports.list").read_text(), "21000\n")

    def test_registry_is_local_and_retains_every_customer(self):
        (self.config / "access.json").write_text(json.dumps({"accounts": [{"listen": "0.0.0.0:21000,0.0.0.0:21001"}, {"listen": "127.0.0.1:19100"}]}))
        self.shell('rebuild_ports_file "$TUNNELS_DIR/test"\n')
        self.assertEqual((self.config / "ports.list").read_text(), "19100\n21000\n21001\n")
        self.env["ROLE"] = "egress"
        self.write_env()
        (self.config / "access.json").unlink()
        self.shell('rebuild_ports_file "$TUNNELS_DIR/test"\n')
        self.assertEqual((self.config / "ports.list").read_text(), "443\n8443\n18080\n18081\n18082\n")

    def test_metered_edit_ports_uses_helper_not_unmetered_launch_flag(self):
        (self.config / "access.json").write_text(json.dumps({"accounts": [{"id": "default", "listen": "0.0.0.0:22000"}]}))
        original = (self.config / "run.sh").read_bytes()
        result = self.shell('customer_command() { printf "helper=%s|%s|%s|%s\\n" "$1" "$2" "$3" "$4"; }\nedit_ports test 22000\n')
        self.assertIn("helper=ports|test|default|22000", result.stdout)
        self.assertEqual((self.config / "run.sh").read_bytes(), original)
        # Metadata belongs to the helper's locked transaction, not a later shell write.
        self.assertIn("LOCAL_PORTS=21000", (self.config / "deployment.env").read_text())
        self.assertFalse((self.config / "ports.list").exists())

    def test_customer_helper_arguments_and_no_shell_lock(self):
        result = self.shell('python3() { printf "arg=%s\\n" "$@"; }\ncustomer_command export test alice\n')
        self.assertIn("arg=export\n", result.stdout)
        self.assertIn("arg=--customer\narg=alice", result.stdout)
        self.assertIn("arg=--state-dir\narg=/var/lib/ununknowntun/test", result.stdout)
        self.assertNotIn("unexpected-shell-lock", result.stderr)

    def test_port_errors_retry_and_proxy_provider_limits(self):
        result = self.shell("prompt_managed_ports Ports 443 arvan https test\n", "443,443\n80\n8443\n443\n")
        self.assertEqual(result.stdout, "443")
        self.assertIn("unique ports", result.stderr)
        self.assertIn("reserved", result.stderr)
        self.assertIn("Arvan", result.stderr)

    def test_delete_retains_shared_firewall_rules(self):
        body = DEFINITIONS.split("delete_tunnel() {", 1)[1].split("\ntest_tunnel()", 1)[0]
        self.assertNotIn("ufw --force delete", body)

    def delete_fixture(self):
        available, enabled = self.root / "nginx/available", self.root / "nginx/enabled"
        available.mkdir(parents=True)
        enabled.mkdir(parents=True)
        self.site = available / "ununknowntun-test.conf"
        self.site.write_text("original nginx site\n")
        self.link = enabled / self.site.name
        self.link.symlink_to(self.site)
        self.state = self.root / "state/test"
        self.state.mkdir(parents=True)
        (self.state / "usage.json").write_text("retained usage\n")
        self.env["NGINX_SITE"] = str(self.site)
        self.write_env()
        self.defs.write_text(DEFINITIONS.replace("/etc/nginx/sites-available", str(available))
                            .replace("/etc/nginx/sites-enabled", str(enabled))
                            .replace("/var/lib/ununknowntun", str(self.root / "state")))

    def delete_mock(self, failure="", active=1, enabled="enabled"):
        return f'''mock_active={active}; mock_enabled={shlex.quote(enabled)}; nginx_calls=0; reload_calls=0
systemctl() {{
    printf '%s\\n' "$*" >> {shlex.quote(str(self.root / "services.log"))}
    case "$1" in
        is-active) [[ "$mock_active" == 1 ]];;
        is-enabled) printf '%s\\n' "$mock_enabled";;
        stop) [[ {shlex.quote(failure)} != stop ]] || return 1; [[ {shlex.quote(failure)} == still-active ]] || mock_active=0; return 0;;
        disable) mock_enabled=disabled;;
        enable) mock_enabled=enabled;;
        start) mock_active=1;;
        reload) reload_calls=$((reload_calls + 1)); [[ {shlex.quote(failure)} != reload || "$reload_calls" != 1 ]];;
    esac
}}
nginx() {{ nginx_calls=$((nginx_calls + 1)); [[ {shlex.quote(failure)} != nginx || "$nginx_calls" != 1 ]]; }}
mv() {{ [[ {shlex.quote(failure)} != state || "$1" != {shlex.quote(str(self.root / "state/test"))} ]] || return 1; command mv "$@"; }}
delete_tunnel test
'''

    def test_delete_failure_restores_site_symlink_usage_and_service_state(self):
        for failure in ("stop", "still-active", "nginx", "reload", "state"):
            with self.subTest(failure=failure):
                # Fixtures are reusable because every failed removal must restore them.
                if not hasattr(self, "site"):
                    self.delete_fixture()
                result = self.shell(self.delete_mock(failure), "test\n", expected=1)
                self.assertTrue(self.config.is_dir())
                self.assertEqual(self.site.read_text(), "original nginx site\n")
                self.assertTrue(self.link.is_symlink())
                self.assertEqual(self.link.resolve(), self.site.resolve())
                self.assertEqual((self.state / "usage.json").read_text(), "retained usage\n")
                self.assertIn("previous service state restored", result.stderr)
                events = (self.root / "services.log").read_text()
                self.assertIn("enable ununknowntun@test\n", events)
                self.assertIn("start ununknowntun@test\n", events)

    def test_delete_rollback_keeps_previously_stopped_service_stopped(self):
        self.delete_fixture()
        self.shell(self.delete_mock("nginx", active=0, enabled="disabled"), "test\n", expected=1)
        events = (self.root / "services.log").read_text()
        self.assertNotIn("start ununknowntun@test\n", events)
        self.assertNotIn("enable ununknowntun@test\n", events)
        self.assertTrue(self.config.is_dir())

    def test_delete_preserves_exact_shared_nginx_reference(self):
        self.delete_fixture()
        other = self.root / "tunnels/other"
        other.mkdir()
        (other / "deployment.env").write_text(f"NGINX_SITE={shlex.quote(str(self.site))}\n")
        result = self.shell(self.delete_mock(), "test\n")
        self.assertIn("referenced by another tunnel", result.stdout)
        self.assertTrue(self.site.is_file())
        self.assertTrue(self.link.is_symlink())
        self.assertTrue(other.is_dir())
        self.assertFalse(self.config.exists())
        self.assertFalse(self.state.exists())
        self.assertNotIn("reload nginx", (self.root / "services.log").read_text())
        backups = list((self.root / "install/backups").glob("deleted-test-*"))
        self.assertEqual(len(backups), 1)
        self.assertEqual((backups[0] / "state/usage.json").read_text(), "retained usage\n")

    def test_delete_success_removes_only_selected_site_and_keeps_backup(self):
        self.delete_fixture()
        untouched = self.site.parent / "unrelated.conf"
        untouched.write_text("another service\n")
        self.shell(self.delete_mock(), "test\n")
        self.assertFalse(self.config.exists())
        self.assertFalse(self.site.exists())
        self.assertFalse(self.link.is_symlink())
        self.assertEqual(untouched.read_text(), "another service\n")
        backup = next((self.root / "install/backups").glob("deleted-test-*"))
        self.assertTrue((backup / "nginx-enabled" / self.link.name).is_symlink())
        self.assertEqual((backup / "nginx-available" / self.site.name).read_text(), "original nginx site\n")


if __name__ == "__main__":
    unittest.main(verbosity=2)
