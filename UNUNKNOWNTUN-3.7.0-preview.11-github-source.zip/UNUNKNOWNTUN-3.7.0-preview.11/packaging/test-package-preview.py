#!/usr/bin/env python3
"""Offline evidence-boundary tests; never builds, publishes or deploys a package."""
import ast
import copy
from pathlib import Path
import re
import tempfile
import unittest


# The packaging CLI deliberately runs only as a script. Load its pure evidence
# validators without executing argument parsing or creating release artifacts.
path = Path(__file__).with_name("package-preview.py")
tree = ast.parse(path.read_text(), filename=str(path))
helpers = ast.Module(body=[node for node in tree.body if isinstance(node, ast.FunctionDef)
                          and node.name in {"validation_logs", "unittest_counts", "audit_files",
                                            "validate_integration", "runtime_statement"}], type_ignores=[])
namespace = {"re": re}
exec(compile(helpers, str(path), "exec"), namespace)
validation_logs = namespace["validation_logs"]
unittest_counts = namespace["unittest_counts"]
audit_files = namespace["audit_files"]
validate_integration = namespace["validate_integration"]
runtime_statement = namespace["runtime_statement"]


class ValidationEvidenceTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="gdt-package-evidence-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        (self.root / "packaging").mkdir()
        self.logs = self.root / "validation"
        self.logs.mkdir()
        (self.root / "packaging/test-example.py").write_text("# fixture\n")
        names = ["go-test", "go-race", "go-vet", "go-resilience", "installer-syntax", "terminal-ui", "test-gre-wire", "test-gre-systemd", "test-icmp-wire", "test-icmp-wss", "test-example"]
        self.summary = {"version": "fixture-preview.2", "results": [
            {"name": name, "status": "PASS", "exit_code": 0} for name in names]}
        for name in names:
            (self.logs / (name + ".log")).write_text("Ran 2 tests in 0.01s\n\nOK\n")

    def check(self):
        return validation_logs(self.summary, "fixture-preview.2", self.root, self.logs)

    def test_complete_groups_accept_and_ignore_unlisted_stale_logs(self):
        (self.logs / "stale-private-debug.log").write_text("Ran 999 tests in 0s\nOK\n")
        self.assertEqual(len(self.check()), 11)
        self.assertNotIn("stale-private-debug", self.check())

    def test_new_packaging_tests_become_required(self):
        (self.root / "packaging/test-added.py").write_text("# newly added test\n")
        with self.assertRaisesRegex(ValueError, "test-added"):
            self.check()

    def test_missing_fixed_group_rejected(self):
        self.summary["results"] = self.summary["results"][1:]
        with self.assertRaisesRegex(ValueError, "go-test"):
            self.check()

    def test_failed_or_nonzero_group_rejected(self):
        for change in ({"status": "FAIL"}, {"exit_code": 1}, {"exit_code": False}):
            with self.subTest(change=change):
                saved = copy.deepcopy(self.summary)
                self.summary["results"][0].update(change)
                with self.assertRaises(ValueError):
                    self.check()
                self.summary = saved

    def test_stale_version_empty_and_malformed_summary_rejected(self):
        for summary in ([], {"version": "old", "results": self.summary["results"]},
                        {"version": "fixture-preview.2", "results": []},
                        {"version": "fixture-preview.2", "results": [None]}):
            with self.subTest(summary=summary):
                with self.assertRaises(ValueError):
                    validation_logs(summary, "fixture-preview.2", self.root, self.logs)

    def test_duplicate_unsafe_and_nonstring_group_names_rejected(self):
        for name in ("go-test", "../../private", None, 3):
            with self.subTest(name=name):
                saved = copy.deepcopy(self.summary)
                self.summary["results"].append({"name": name, "status": "PASS", "exit_code": 0})
                with self.assertRaises(ValueError):
                    self.check()
                self.summary = saved

    def test_missing_or_symlink_log_rejected(self):
        target = self.logs / "go-test.log"
        target.unlink()
        with self.assertRaisesRegex(ValueError, "regular"):
            self.check()
        target.symlink_to(self.logs / "go-race.log")
        with self.assertRaisesRegex(ValueError, "regular"):
            self.check()


class CountTests(unittest.TestCase):
    def test_success_and_skip_counts(self):
        self.assertEqual(unittest_counts("test_a ... ok\nRan 5 tests in 0.002s\n\nOK\n"), (5, 0))
        self.assertEqual(unittest_counts("Ran 1 test in 1s\nOK (skipped=1)\n"), (1, 1))

    def test_incomplete_failed_duplicate_and_invalid_counts_rejected(self):
        for log in ("PASS", "Ran 2 tests in 1s\nFAILED (errors=1)\n",
                    "Ran 2 tests in 1s\nOK\nRan 2 tests in 1s\nOK\n",
                    "Ran 2 tests in 1s\nOK (skipped=3)\n", "Ran 0 tests in 1s\nOK\n",
                    "Ran 2 tests in 1s\nOK\nFAILED (errors=1)\n"):
            with self.subTest(log=log):
                with self.assertRaises(ValueError):
                    unittest_counts(log)


class AuditBoundaryTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="gdt-audit-evidence-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.audit = self.root / "audit-release"
        self.audit.mkdir()

    def test_planned_sanitized_report_names_accepted(self):
        names = ["FuzzPathSchedule.log", "security-after-go.json", "security-summary.md",
                 "security-binary-linux-amd64.json", "security-binary-linux-arm64.json",
                 "security-linux-amd64-package-list.txt", "security-linux-arm64-package-list.txt",
                 "go-native-coverage.log", "gre-netns-final.log", "icmp-native-final.json", "icmp-wss-final.json", "rotation-soak-final.json", "README.md",
                 "direct-icmp-final.json", "direct-icmp-fec-final.json", "direct-icmp-systemd-final.json", "direct-icmp-standalone-final.json"]
        for name in names:
            (self.audit / name).write_text("Sanitized local lab evidence; no credentials.\n")
        self.assertEqual({relative.name for _, relative in audit_files(self.audit)}, set(names))

    def test_archives_binaries_unreviewed_logs_and_subdirectories_rejected(self):
        for name in ("source.tar.gz", "ununknowntun", "raw-fixture.log", "raw-trace.txt", "key.pem", "nested"):
            with self.subTest(name=name):
                candidate = self.audit / name
                if name == "nested":
                    candidate.mkdir()
                else:
                    candidate.write_text("not a reviewed release report\n")
                with self.assertRaises(ValueError):
                    audit_files(self.audit)
                if candidate.is_dir():
                    candidate.rmdir()
                else:
                    candidate.unlink()

    def test_file_directory_and_root_symlinks_rejected(self):
        secret = self.root / "outside"
        secret.write_text("private")
        link = self.audit / "README.md"
        for target in (secret, self.root):
            link.symlink_to(target)
            with self.assertRaises(ValueError):
                audit_files(self.audit)
            link.unlink()
        root_link = self.root / "linked-audit"
        root_link.symlink_to(self.audit)
        with self.assertRaises(ValueError):
            audit_files(root_link)

    def test_private_fixture_and_credential_content_rejected(self):
        for text in ("-----BEGIN PRIVATE KEY-----\nfixture\n", "-----BEGIN RSA PRIVATE KEY-----\nfixture\n",
                     "-----BEGIN CERTIFICATE-----\nfixture\n", "UNUNKNOWNTUN_TOKEN=secret-placeholder\n",
                     '  "api_token": "secret-placeholder"', "Authorization: Bearer fixture\n",
                     "vless://fixture", "vmess://fixture", "ss://fixture", "binary\x00data"):
            with self.subTest(text=text):
                (self.audit / "README.md").write_text(text)
                with self.assertRaises(ValueError):
                    audit_files(self.audit)

    def test_large_report_rejected(self):
        with (self.audit / "README.md").open("wb") as stream:
            stream.truncate(16 * 1024 * 1024 + 1)
        with self.assertRaisesRegex(ValueError, "bounds"):
            audit_files(self.audit)


class IntegrationEvidenceTests(unittest.TestCase):
    def setUp(self):
        # Read the actual harness's pure profile inventory so packaging cannot
        # accidentally accept a matrix that has drifted from the exercised one.
        harness = Path(__file__).resolve().parent.parent / "tests/nginx_integration.py"
        parsed = ast.parse(harness.read_text())
        profile_function = next(node for node in parsed.body if isinstance(node, ast.FunctionDef) and node.name == "test_profiles")
        profile_namespace = {}
        exec(compile(ast.Module(body=[profile_function], type_ignores=[]), str(harness), "exec"), profile_namespace)
        self.report = {"status": "PASS", "binary_version": "ununknowntun fixture-preview.2",
                       "frontend_kind": "nginx", "nginx_version": "nginx/fixture", "modes": []}
        for profile in profile_namespace["test_profiles"]("all"):
            item = {"profile": profile["label"], "all_sha256_and_fin_verified": True,
                    "authenticated_probe_passed": True, "stream_and_queue_cleanup_verified": True,
                    "doctor": {key: True for key in ("actual_subprocess", "authenticated", "wrong_route_rejected", "configuration_unchanged", "secrets_redacted")}}
            for name in ("fast_stream_during_slow_consumer", "slow_consumer", "new_stream_after_egress_restart"):
                item[name] = {"sha256_verified": True, "fin_eof_verified": True}
            self.report["modes"].append(item)

    def test_real_harness_inventory_accepted(self):
        validate_integration(self.report, "fixture-preview.2")

    def test_fake_or_incomplete_profile_matrix_rejected(self):
        for transform in (lambda report: report["modes"].pop(),
                          lambda report: report["modes"][0].update(profile=report["modes"][1]["profile"]),
                          lambda report: report["modes"][0].update(profile="unexercised-mode"),
                          lambda report: report.update(modes=[None] * 20),
                          lambda report: report.update(binary_version="ununknowntun old")):
            report = copy.deepcopy(self.report)
            transform(report)
            with self.assertRaises(ValueError):
                validate_integration(report, "fixture-preview.2")

    def test_frontend_must_be_identified_without_claiming_nginx_for_go_proxy(self):
        for change in ({"frontend_kind": "mock"}, {"nginx_version": ""}):
            report = copy.deepcopy(self.report)
            report.update(change)
            with self.assertRaises(ValueError):
                validate_integration(report, "fixture-preview.2")
        self.report["frontend_kind"] = "go"
        self.report.pop("nginx_version")
        validate_integration(self.report, "fixture-preview.2")

    def test_claimed_recovery_cleanup_and_authentication_require_evidence(self):
        for transform in (lambda item: item.update(authenticated_probe_passed="yes"),
                          lambda item: item.update(stream_and_queue_cleanup_verified=False),
                          lambda item: item["doctor"].update(wrong_route_rejected=False),
                          lambda item: item["new_stream_after_egress_restart"].update(fin_eof_verified=False),
                          lambda item: item.pop("fast_stream_during_slow_consumer")):
            report = copy.deepcopy(self.report)
            transform(report["modes"][0])
            with self.assertRaises(ValueError):
                validate_integration(report, "fixture-preview.2")


class RuntimeClaimTests(unittest.TestCase):
    def test_arm64_runtime_does_not_claim_amd64_runtime(self):
        description, caveat = runtime_statement(["arm64"])
        self.assertIn("shipped Linux arm64", description)
        self.assertEqual(caveat, "; Linux amd64 runtime")

    def test_other_runtime_combinations(self):
        description, caveat = runtime_statement([])
        self.assertIn("not a shipped Linux binary", description)
        self.assertEqual(caveat, "; Linux amd64, arm64 runtime")
        self.assertEqual(runtime_statement(["amd64"])[1], "; Linux arm64 runtime")
        self.assertEqual(runtime_statement(["amd64", "arm64"])[1], "")


if __name__ == "__main__":
    unittest.main(verbosity=2)
