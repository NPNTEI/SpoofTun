#!/usr/bin/env python3
"""3.7 offline wizard/editor regressions; all services/network mocked."""
import base64
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import unittest


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(filename))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


installer = load("resilience_installer", "test-full-installer.py")
safety = load("resilience_safety", "test-editor-safety.py")
upgrade = load("resilience_upgrade", "test-upgrade.py")
editor = safety.editor


def assert_rotation_routes(test, site, transport):
    patterns = re.findall(r'location\s+~\s+"(\^/gdt-r/[^\"]+)"\s*\{', site)
    test.assertEqual(len(patterns), 1, site)
    test.assertNotIn("location ^~ /gdt-r/", site)
    pattern = re.compile(patterns[0])
    uuid = "01234567-89ab-cdef-0123-456789abcdef"
    suffixes = ("/", "/" + uuid, "/" + uuid.upper(), "/" + uuid + "/0", "/" + uuid + "/18446744073709551615") if transport == "xhttp" else ("",)
    for length in (32, 64):
        base = "/gdt-r/" + "a" * length
        for suffix in suffixes:
            test.assertIsNotNone(pattern.fullmatch(base + suffix), base + suffix)
        invalid_suffixes = ("", "/invalid-session", "/" + uuid + "/", "/" + uuid + "/01", "/" + uuid + "/-1", "/" + uuid + "/1/2", "/" + uuid + "/123456789012345678901") if transport == "xhttp" else ("/", "/" + uuid, "/0")
        for suffix in invalid_suffixes:
            test.assertIsNone(pattern.fullmatch(base + suffix), base + suffix)
    for token in ("a" * 31, "a" * 33, "a" * 48, "a" * 63, "a" * 65, "A" * 32, "g" * 64, "a" * 31 + "%", ""):
        for suffix in suffixes:
            path = "/gdt-r/" + token + suffix
            test.assertIsNone(pattern.fullmatch(path), path)
    return patterns[0]


class WizardTests(unittest.TestCase):
    def setUp(self):
        self.fx = installer.InstallerTests(methodName="runTest")
        self.fx.setUp()
        self.addCleanup(self.fx.tearDown)

    def test_rotation_default_off_and_independent_renewal(self):
        self.fx.run_shell('select_path_profile; [[ "$path_rotation/$path_count/$path_grace/$path_legacy" == 0/3/5m/false ]]', stdin="n\n")
        self.fx.run_shell('mux_mode=off; select_session_renewal; [[ "$session_renewal" == 0 ]]', stdin="")
        self.fx.run_shell('mux_mode=on; select_session_renewal; [[ "$session_renewal" == 8h ]]', stdin="y\n8\n")

    def test_rotation_reprompts_and_sets_matching_profile(self):
        result = self.fx.run_shell('select_path_profile; [[ "$path_rotation/$path_count/$path_grace/$path_legacy" == 2h/4/0/false ]]', stdin="y\n0\n2\n9\n4\n61\n0\n")
        self.assertIn("synchronized", result.stderr)
        self.assertIn("/gdt-r/", result.stderr)

    def test_rotation_probe_uses_real_core_and_reserved_seed_is_rejected(self):
        result = self.fx.run_shell('''
! valid_ws_path /gdt-r/0123456789abcdef
! valid_xhttp_path /gdt-r/0123456789abcdef
mock_core() { printf '%s\n' "$@"; }
BIN_PATH=mock_core
transport=xhttp; xhttp_mode=stream-one; mux_mode=on; target_port=18082
ws_path=/private-ws-base; xhttp_path=/private-xhttp-base
path_rotation=2h; path_count=3; path_grace=5m; path_legacy=false
probe_rotating_foreign edge.example 127.0.0.1 443 /cert.pem
''')
        self.assertIn("-check-tunnel", result.stdout)


    def test_standalone_nginx_is_iran_only_and_direct_dns(self):
        result = self.fx.run_shell('''
select_proxy_provider iran_provider "Iran entry"
[[ "$iran_provider" == nginx ]]
domain_points_to_ipv4() { [[ "$1/$2" == iran.example/203.0.113.1 ]]; }
domain_is_proxied_from_ipv4() { return 99; }
check_dns_mode iran.example 203.0.113.1 nginx
[[ "$(proxy_default_ports nginx)" == 443 ]]
select_entry_profile
[[ "$entry_transport" == xhttp ]]
''', stdin="5\n2\n")
        self.assertIn("NOT converted", result.stderr)
        result = self.fx.run_shell('select_proxy_provider foreign_provider "Foreign"; [[ "$foreign_provider" == none ]]', stdin="5\n1\n")
        self.assertNotIn("5) Nginx", result.stdout)

    def test_peer_roundtrip_and_invalid_rotation_profile_fail_closed(self):
        self.fx.run_shell('''
path_rotation=2h; path_count=4; path_grace=5m; path_legacy=false
transport=wss; mux_mode=on; entry_transport=ws
code="$(create_peer_code edge.example 203.0.113.10 443 /private-ws-base-path /private-h2-base-path 0123456789abcdef0123456789abcdef 18082 none chrome nginx /private-entry-path 0123456789abcdef)"
decode_peer_code "$code"
[[ "$PEER_PATH_ROTATION/$PEER_PATH_COUNT/$PEER_PATH_GRACE/$PEER_PATH_LEGACY/$PEER_IRAN_PROXY_PROVIDER" == 2h/4/5m/false/nginx ]]
PEER_PATH_GRACE=3h; ! validate_peer_path_profile
PEER_PATH_GRACE=5m; PEER_PATH_COUNT=99; ! validate_peer_path_profile
''')

    def test_rotation_pair_decoder_and_manual_seed_share_canonical_validation(self):
        self.fx.run_shell('''
path_rotation=0
valid_transport_seed /private//legacy-ws-path
path_rotation=2h
! valid_transport_seed /private//legacy-ws-path
valid_transport_seed /private-clean-ws-path
path_count=3; path_grace=5m; path_legacy=false
transport=wss; mux_mode=on; entry_transport=ws
code="$(create_peer_code edge.example 203.0.113.10 443 /private//legacy-ws-path /private-h2-base-path 0123456789abcdef0123456789abcdef 18082 none chrome none '' 0123456789abcdef)"
! decode_peer_code "$code"
''')

    def test_both_launchers_share_paths_origin_has_renewal_and_private_entry(self):
        self.fx.run_shell('''
path_rotation=2h; path_count=4; path_grace=5m; path_legacy=false; session_renewal=8h
PROFILE_MAX_MEMORY=268435456; PROFILE_MAX_STREAMS=128
write_foreign_run_script edge.example /private-ws-path 18080 /private-h2-path 18081 18082
grep -q -- '-path-rotation 2h' "$CONFIG_DIR/run.sh"
write_origin_run_script edge.example 203.0.113.10 443 /private-ws-path /private-h2-path 18082 19080 8 0 none nginx chrome off
sh -n "$CONFIG_DIR/run.sh"
grep -q -- '-listen 127.0.0.1:19080' "$CONFIG_DIR/run.sh"
grep -q -- '-session-renewal 8h' "$CONFIG_DIR/run.sh"
grep -q -- '-path-count 4' "$CONFIG_DIR/run.sh"
''')

    def test_nginx_prepared_prefix_preserves_backend_and_headers(self):
        for mode in ("wss", "xhttp"):
            with self.subTest(mode=mode):
                self.fx.run_shell(f'transport={mode}; xhttp_mode=stream-up; xhttp_path=/private-xhttp-path; write_nginx_wss_site edge.example 443 /private-ws-path 18080 /private-h2-path 18081 /cert.pem /key.pem')
                site = (self.fx.root / "nginx-available/ununknowntun-edge.example.conf").read_text()
                pattern = assert_rotation_routes(self, site, mode)
                self.assertEqual(pattern, editor.nginx_rotation_pattern(mode))
                self.assertEqual(site.count("proxy_pass http://127.0.0.1:18080;"), 2)
                self.assertEqual(site.count("proxy_set_header Authorization $http_authorization;"), 2)
                self.assertNotIn("rewrite ", site)
                if mode == "xhttp":
                    self.assertEqual(site.count("client_max_body_size 0;"), 2)
                else:
                    self.assertEqual(site.count("proxy_set_header Upgrade $http_upgrade;"), 2)

    @unittest.skipUnless(os.environ.get("UNUNKNOWNTUN_TEST_NGINX"), "set UNUNKNOWNTUN_TEST_NGINX for real rotating-prefix parser matrix")
    def test_real_nginx_parses_rotation_prefix_for_ws_and_every_xhttp_mode(self):
        cert, key = self.fx.certificate(name="edge.example")
        for transport, mode in (("wss", "packet-up"), *(("xhttp", mode) for mode in ("auto", "packet-up", "stream-up", "stream-one"))):
            with self.subTest(transport=transport, mode=mode):
                self.fx.run_shell(f'''
transport={transport}; xhttp_mode={mode}; xhttp_path=/private-xhttp-base
path_rotation=2h; path_count=3; path_grace=5m; path_legacy=false
write_nginx_wss_site edge.example 443,8443 /private-ws-base 18080 /private-h2-base 18081 {shlex.quote(str(cert))} {shlex.quote(str(key))}
''')
                site = (self.fx.root / "nginx-available/ununknowntun-edge.example.conf").read_text()
                assert_rotation_routes(self, site, transport)
                self.assertIn("proxy_set_header Authorization $http_authorization;", site)
                self.assertNotIn("rewrite ", site)
                site = re.sub(r"(?m)^(\s*listen\s+)([0-9]+)", lambda m: m[1] + "127.0.0.1:" + str(20000 + int(m[2])), site)
                (self.fx.root / "logs").mkdir(exist_ok=True)
                conf = self.fx.root / "nginx-rotation.conf"
                conf.write_text(f"pid {self.fx.root}/nginx.pid;\nerror_log {self.fx.root}/nginx-error.log;\nevents {{ worker_connections 32; }}\nhttp {{ access_log off;\n{site}\n}}\n")
                result = subprocess.run([os.environ["UNUNKNOWNTUN_TEST_NGINX"], "-t", "-p", str(self.fx.root) + "/", "-c", str(conf)], capture_output=True, text=True, timeout=15)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
                self.assertIn("test is successful", result.stderr)


class EditTests(unittest.TestCase):
    def setUp(self):
        self.fx = safety.EditorSafetyTests(methodName="runTest")
        self.fx.setUp()
        self.addCleanup(self.fx.doCleanups)
        self.ed = self.fx.instance

    def set_launcher(self, **flags):
        for flag, value in flags.items():
            self.fx.script = editor.set_flag(self.fx.script, flag.replace("_", "-"), value)
        self.fx.write_fixture()
        self.ed.refresh()

    def profile(self, **overrides):
        result = dict(interval="2h", count="3", grace="5m", legacy="false")
        result.update(overrides)
        return editor.canonical(result).decode()

    def test_rotation_rejects_unsupported_transport_and_noncanonical_seed(self):
        for transport, path in (("tls", "/private-base-path"), ("wss", "/private//base-path"), ("wss", "/gdt-r/private-base-path")):
            with self.subTest(transport=transport, path=path):
                self.set_launcher(transport=transport, ws_path=path)
                before = (self.fx.directory / "run.sh").read_bytes()
                with self.assertRaises(ValueError):
                    self.ed.plan("path_profile", self.profile())
                self.assertEqual((self.fx.directory / "run.sh").read_bytes(), before)

    def test_rotation_checks_mux_switch_and_permits_max_exclusive_pool(self):
        self.set_launcher(transport="wss", mux="off", sessions="64", path_rotation="2h")
        with self.assertRaises(ValueError):
            self.ed.plan("mux", "on")
        # Exclusive carriers do not need a make-before-drain spare slot.
        self.ed.plan("path_profile", self.profile(count="4"))

    def test_rotation_rejects_duplicate_profile_fields(self):
        value = '{"interval":"0","interval":"2h","count":"3","grace":"5m","legacy":"false"}'
        with self.assertRaises(ValueError):
            self.ed.plan("path_profile", value)

    def test_rotating_ws_seed_edits_require_clean_paths(self):
        self.set_launcher(transport="wss", path_rotation="2h")
        with self.assertRaises(ValueError):
            self.ed.plan("ws_path", "/private//new-seed-path")

    def test_atomic_profile_updates_all_flags_and_signed_metadata(self):
        value = editor.canonical(dict(interval="2h", count="4", grace="5m", legacy="false")).decode()
        plan = self.ed.plan("path_profile", value)
        self.assertEqual(json.loads(base64.b64decode(plan["update"]))["data"]["value"], value)
        with contextlib.redirect_stdout(io.StringIO()):
            self.ed.commit(plan)
        for flag, expected in (("path-rotation", "2h"), ("path-count", "4"), ("path-grace", "5m"), ("path-legacy", "false")):
            self.assertEqual(editor.read_flag(self.ed.script, flag), expected)
        self.assertEqual(self.ed.env["PATH_ROTATION"], "2h")
        self.assertEqual((self.fx.state / "access-state.json").read_text(), "live-use-must-never-be-restored")

    def test_invalid_profile_never_edits_files(self):
        before = (self.fx.directory / "run.sh").read_bytes()
        for changes in (dict(interval="5s"), dict(interval="1h", grace="2h"), dict(count="9"), dict(legacy="yes"), dict(interval="0", legacy="true"), dict(interval="$(bad)")):
            profile = dict(interval="2h", count="3", grace="5m", legacy="false")
            profile.update(changes)
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                self.ed.plan("path_profile", editor.canonical(profile).decode())
        self.assertEqual((self.fx.directory / "run.sh").read_bytes(), before)
        for field in ("ws_path", "xhttp_path"):
            with self.assertRaises(ValueError):
                self.ed.plan(field, "/gdt-r/0123456789abcdef")

    def test_signed_rotation_applies_matching_profile_to_peer_and_replay_fails(self):
        value = editor.canonical(dict(interval="3h", count="4", grace="5m", legacy="false")).decode()
        plan = self.ed.plan("path_profile", value)
        site = self.fx.available / "ununknowntun-foreign.example.conf"
        site.write_text("server {\n    # UNUNKNOWNTUN_TRANSPORT_BEGIN\n    # UNUNKNOWNTUN_TRANSPORT_END\n    location /other { return 404; }\n}\n")
        self.fx.env.update(ROLE="egress", WSS_BACKEND_PORT="18080", NGINX_SITE=str(site))
        self.fx.script = self.fx.script.replace("-mode origin", "-mode egress")
        self.fx.write_fixture()
        (self.fx.directory / "peer.env").write_text("FORMAT=UNUNKNOWNTUN_V5_FLEET\nPAIR_ID=0123456789abcdef\n")
        peer = self.fx.make_editor()
        field, decoded = peer.decode_update(plan["update"])
        self.assertEqual((field, decoded), ("path_profile", value))
        remote = peer.plan(field, decoded, emit=False)
        with contextlib.redirect_stdout(io.StringIO()):
            peer.commit(remote)
        self.assertEqual(peer.current("path_profile"), value)
        assert_rotation_routes(self, site.read_text(), "wss")
        self.assertIn("location /other { return 404; }", site.read_text())
        self.assertIn("PATH_ROTATION=3h", (self.fx.directory / "peer.env").read_text())
        with self.assertRaises(ValueError):
            peer.decode_update(plan["update"])
        self.assertEqual((self.fx.state / "access-state.json").read_text(), "live-use-must-never-be-restored")

    def test_renewal_only_on_origin_and_mux_on(self):
        plan = self.ed.plan("session_renewal", "2h")
        self.assertIsNone(plan["update"])
        with contextlib.redirect_stdout(io.StringIO()):
            self.ed.commit(plan)
        self.assertEqual(editor.read_flag(self.ed.script, "session-renewal"), "2h")
        with self.assertRaises(ValueError):
            self.ed.plan("mux", "off")
        for value in ("5s", "169h", "-1", ""):
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.ed.plan("session_renewal", value)

    def test_nginx_editor_rotation_route_uses_active_transport(self):
        env = dict(WSS_BACKEND_PORT="18080")
        before = "  -transport wss\n  -ws-path /private-websocket-path\n  -h2-path /private-http2-path\n"
        site = "server {\n    # UNUNKNOWNTUN_TRANSPORT_BEGIN\n    # old managed region\n    # UNUNKNOWNTUN_TRANSPORT_END\n    location /other { return 404; }\n}\n"
        after = editor.set_flag(before, "transport", "xhttp")
        after += "  -xhttp-path /private-xhttp-path\n  -xhttp-mode stream-one\n"
        result = editor.transport_routes(site, before, after, env)
        assert_rotation_routes(self, result, "xhttp")
        self.assertEqual(result.count("client_max_body_size 0;"), 2)
        self.assertIn("location /other { return 404; }", result)

    def test_nginx_editor_exact_rotation_routes_and_legacy_prefix_removal(self):
        for transport in ("wss", "xhttp"):
            with self.subTest(transport=transport):
                script = (f"  -transport {transport}\n  -ws-path /private-websocket-path\n"
                          "  -h2-path /private-http2-path\n  -xhttp-path /private-xhttp-path\n")
                static = "^~ /private-xhttp-path/" if transport == "xhttp" else "= /private-websocket-path"
                site = (f"server {{\n    location {static} {{\n        proxy_pass http://127.0.0.1:18080;\n    }}\n"
                        "    location ^~ /gdt-r/ {\n        proxy_pass http://127.0.0.1:18080;\n    }\n"
                        "    location /other { return 404; }\n}\n")
                result = editor.transport_routes(site, script, script, dict(WSS_BACKEND_PORT="18080"))
                assert_rotation_routes(self, result, transport)
                self.assertIn("location /other { return 404; }", result)
                self.assertEqual(editor.transport_routes(result, script, script, dict(WSS_BACKEND_PORT="18080")), result)


    def test_transport_reversed_markers_fail_before_any_edit(self):
        launch = "  -transport wss\n  -ws-path /private-websocket-path\n  -h2-path /private-http2-path\n"
        site = "server {\n    # UNUNKNOWNTUN_TRANSPORT_END\n    location /other { return 404; }\n    # UNUNKNOWNTUN_TRANSPORT_BEGIN\n}\n"
        with self.assertRaises(ValueError):
            editor.transport_routes(site, launch, launch, dict(WSS_BACKEND_PORT="18080"))

    def test_rotation_failed_nginx_check_restores_peer_and_preserves_other_sites(self):
        site = self.fx.available / "ununknowntun-foreign.example.conf"
        site.write_text("server {\n    # UNUNKNOWNTUN_TRANSPORT_BEGIN\n    # UNUNKNOWNTUN_TRANSPORT_END\n}\n")
        unrelated = self.fx.available / "panel.conf"
        unrelated.write_text("unrelated panel must remain byte-identical")
        self.fx.env.update(ROLE="egress", WSS_BACKEND_PORT="18080", NGINX_SITE=str(site))
        self.fx.write_fixture()
        (self.fx.directory / "peer.env").write_text("FORMAT=UNUNKNOWNTUN_V5_FLEET\n")
        (self.fx.directory / "peer.env").chmod(0o600)
        ed = self.fx.make_editor()
        plan = ed.plan("path_profile", self.profile())
        before = {path: ed.capture(path) for path in plan["changes"]}
        def fail_nginx(*args, **kwargs):
            if args[:2] == ("nginx", "-t"):
                raise subprocess.CalledProcessError(1, args)
            return subprocess.CompletedProcess(args, 0, "", "")
        ed.run.side_effect = fail_nginx
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(subprocess.CalledProcessError):
            ed.commit(plan)
        self.assertEqual({path: ed.capture(path) for path in plan["changes"]}, before)
        self.assertEqual(unrelated.read_text(), "unrelated panel must remain byte-identical")
        self.assertEqual((self.fx.state / "access-state.json").read_text(), "live-use-must-never-be-restored")
        self.assertNotIn("restart", str(ed.run.call_args_list))


class UpgradeRoutingTests(unittest.TestCase):
    def setUp(self):
        self.fx = upgrade.UpgradeTests(methodName="runTest")
        self.fx.setUp()
        self.addCleanup(self.fx.tearDown)

    def test_upgrade_bounds_old_prefix_and_is_idempotent(self):
        for transport in ("wss", "xhttp"):
            for existing_rotation in (False, True):
                with self.subTest(transport=transport, existing_rotation=existing_rotation):
                    self.fx.prepare(role="egress")
                    script = self.fx.run.read_text().replace("-transport auto", "-transport " + transport)
                    script += "  -ws-path /private-websocket-path\n  -h2-path /private-http2-path\n  -xhttp-path /private-xhttp-path\n"
                    self.fx.run.write_text(script)
                    static = "^~ /private-xhttp-path/" if transport == "xhttp" else "= /private-websocket-path"
                    site = self.fx.site.read_text().replace("    location / { return 200; }", f"    location {static} {{\n        proxy_pass http://127.0.0.1:19080;\n    }}\n    location / {{ return 200; }}")
                    if existing_rotation:
                        site = site.replace("    location / { return 200; }", "    location ^~ /gdt-r/ {\n        proxy_pass http://127.0.0.1:19080;\n        proxy_read_timeout 900s;\n    }\n    location / { return 200; }")
                    self.fx.site.write_text(site)
                    self.fx.shell("patch_upgrade_configuration\n")
                    result = self.fx.site.read_text()
                    assert_rotation_routes(self, result, transport)
                    self.assertIn("location = /keep-customer-route { proxy_pass http://127.0.0.1:19101; }", result)
                    if existing_rotation:
                        self.assertIn("proxy_read_timeout 900s;", result)
                    self.fx.shell("patch_upgrade_configuration\n")
                    self.assertEqual(self.fx.site.read_text(), result)


if __name__ == "__main__":
    unittest.main(verbosity=2)
