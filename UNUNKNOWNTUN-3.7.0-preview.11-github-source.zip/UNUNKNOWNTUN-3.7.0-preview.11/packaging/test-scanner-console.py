#!/usr/bin/env python3
"""Offline and localhost tests; never contact public scan/download endpoints."""
import base64
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import socket
import stat
import tempfile
import threading
import unittest
from unittest.mock import patch

SOURCE = Path(__file__).with_name("scanner-console.py")
spec = importlib.util.spec_from_file_location("scanner_console", SOURCE)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)


class ConsoleTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name).resolve()
        self.reports = self.root / "reports"
        self.e = c.engine()
        self.out, self.err = io.StringIO(), io.StringIO()

    def tearDown(self):
        self.e.set_cancel_event(None)
        self.temp.cleanup()

    def run_cli(self, argv):
        with contextlib.redirect_stdout(self.out), contextlib.redirect_stderr(self.err):
            return c.main(argv)

    def saved(self):
        return next(self.reports.glob("*.json"))

    def report(self, kind="ip", count=12):
        rows = [dict(ip=f"8.8.8.{i + 1}", connect_host=f"8.8.8.{i + 1}", port=443,
                     method="tcp", sni="example.com", fingerprint="chrome", status="Online",
                     success=3, count=4, packet_loss=25, avg_ping=float(i + 10),
                     min_ping=8.2, max_ping=20.5, jitter=3.4, stddev=1.2,
                     attempt_diagnostics=[{"attempt": 4, "phase": "tcp", "error": "TIMEOUT"}])
                for i in range(count)]
        if kind in ("sni", "reality"):
            for i, row in enumerate(rows):
                row.update(ip=f"s{i}.example.com", method=kind, target="example.com", verdict="VALID")
        value = {"schema": c.SCHEMA, "kind": kind, "rows": rows, "planned": count}
        path = self.root / (kind + ".json")
        c.private_write(path, json.dumps(value))
        return str(path)

    def test_all_commands_present(self):
        help_text = c.build_parser().format_help()
        for command in ("ip", "sni", "discover", "retest", "speed", "results", "export", "sni-json", "configs", "dependencies"):
            self.assertIn(command, help_text)

    def test_no_authorization_no_network(self):
        with patch.object(self.e, "tcp_handshake_ping", side_effect=AssertionError("network")):
            self.assertEqual(1, self.run_cli(["ip", "8.8.8.8"]))
        self.assertIn("--authorized", self.err.getvalue())

    def test_sni_authorization_before_dns(self):
        with patch.object(self.e, "HAVE_CURL_CFFI", True), patch.object(self.e, "_getaddrinfo", side_effect=AssertionError("dns")):
            self.assertEqual(1, self.run_cli(["sni", "example.com", "sni.example.com"]))
        self.assertIn("--authorized", self.err.getvalue())

    def test_metadata_never_allowed(self):
        for target in ("169.254.169.254", "100.100.100.200", "168.63.129.16", "::", "fe80::1", "::ffff:169.254.169.254"):
            with self.assertRaises(ValueError): c.public_address(target, True)
        for target in ("127.0.0.1", "10.0.0.1", "::1", "fd00::1"):
            with self.assertRaises(ValueError): c.public_address(target, False)
            self.assertEqual(target, c.public_address(target, True))

    def test_dns_checks_every_answer_before_pinning(self):
        answers = [(socket.AF_INET, socket.SOCK_STREAM, 0, "", ("8.8.8.8", 443)),
                   (socket.AF_INET, socket.SOCK_STREAM, 0, "", ("127.0.0.1", 443))]
        with patch.object(self.e, "_getaddrinfo", return_value=answers):
            with self.assertRaises(ValueError): c.resolve_pinned("example.com", 443, False, 1000)
            self.assertEqual("8.8.8.8", c.resolve_pinned("example.com", 443, True, 1000))

    def test_no_cidr_silent_truncation(self):
        with self.assertRaises(ValueError): c.ip_candidates("8.8.0.0/16")
        self.assertEqual(["8.8.8.1", "8.8.8.2"], c.ip_candidates("8.8.8.0/30 8.8.8.1"))

    def test_private_io_and_no_overwrite(self):
        path = self.root / "new" / "report.json"
        c.private_write(path, "{}", private_parent=True)
        self.assertEqual(0o700, stat.S_IMODE(path.parent.stat().st_mode))
        self.assertEqual(0o600, stat.S_IMODE(path.stat().st_mode))
        with self.assertRaises(FileExistsError): c.private_write(path, "changed")
        self.assertEqual("{}", path.read_text())

    def test_file_and_parent_symlinks_rejected(self):
        target = self.root / "target"
        target.write_text("secret")
        symlink = self.root / "link"
        symlink.symlink_to(target)
        with self.assertRaises(OSError): c.read_text(symlink)
        with self.assertRaises(FileExistsError): c.private_write(symlink, "replace")
        directory_link = self.root / "linked-directory"
        directory_link.symlink_to(self.root, target_is_directory=True)
        with self.assertRaises(OSError): c.private_write(directory_link / "escape", "bad")

    def test_bounded_and_protected_input(self):
        path = self.root / "input"
        path.write_text("12345")
        path.chmod(0o644)
        with self.assertRaises(ValueError): c.read_text(path, maximum=3)
        with self.assertRaises(ValueError): c.read_text(path, secret=True)
        path.chmod(0o600)
        self.assertEqual("12345", c.read_text(path, secret=True))
        fifo = self.root / "fifo"
        os.mkfifo(fifo)
        with self.assertRaises(ValueError): c.read_text(fifo)

    def test_full_results_and_all_exports(self):
        path = self.report()
        self.assertEqual(0, self.run_cli(["results", path]))
        self.assertIn("8.8.8.12", self.out.getvalue())
        self.assertIn("min_ping", self.out.getvalue())
        self.assertIn("Row 12 attempt details", self.out.getvalue())
        for fmt in ("json", "csv", "txt"):
            output = self.root / ("export." + fmt)
            self.assertEqual(0, self.run_cli(["export", path, "--format", fmt, "--output", str(output)]))
            content = output.read_text()
            self.assertIn("8.8.8.12", content)
            self.assertIn("attempt", content)
            self.assertIn("stddev", content)

    def test_secret_diagnostics_removed(self):
        row = c.clean_row({"ip": "example.com", "uuid": "secret-id", "password": "secret-password",
                           "reality_last_error": "XRAY_START_ERROR vless://secret-id@example.com?pbk=secret",
                           "attempt_diagnostics": [{"attempt": 1, "phase": "reality_probe", "error": "secret-password", "credentials": "secret-id"}]})
        rendered = json.dumps(row)
        self.assertNotIn("secret", rendered)
        self.assertIn("XRAY_START_ERROR", rendered)
        self.assertIn("OPERATION_FAILED", rendered)

    def test_effective_fingerprint_and_dependency_categories_preserved(self):
        row = c.clean_row({"ip": "example.com", "fingerprint": "chrome", "fingerprint_effective": "chrome136",
                           "error": "DEPENDENCY_ERROR: hidden-sensitive-detail", "attempt_diagnostics": [
                               {"attempt": 1, "phase": "browser_tls", "error": "FINGERPRINT_ERROR: hidden-sensitive-detail"}]})
        self.assertEqual("chrome136", row["fingerprint_effective"])
        self.assertEqual("DEPENDENCY_ERROR", row["error"])
        self.assertEqual("FINGERPRINT_ERROR", row["attempt_diagnostics"][0]["error"])
        for format_name in ("json", "csv", "txt"):
            rendered = c.render([row], format_name)
            self.assertIn("chrome136", rendered)
            self.assertIn("DEPENDENCY_ERROR", rendered)
            self.assertIn("FINGERPRINT_ERROR", rendered)
            self.assertNotIn("hidden-sensitive-detail", rendered)

    def test_reality_concurrency_option_is_honest(self):
        parser = c.build_parser()
        args = parser.parse_args(["sni", "8.8.8.8", "one.example.com"])
        self.assertEqual(1, args.reality_workers)
        args = parser.parse_args(["sni", "8.8.8.8", "one.example.com", "--reality-workers", "32", "--reality-config", "unused", "--authorized", "--report-dir", str(self.reports)])
        with patch.object(self.e, "HAVE_CURL_CFFI", True), patch.object(c, "reality_setup", return_value=("/trusted/xray", {"fingerprint": "chrome"})), patch.object(c, "parallel", return_value=([], False)) as batch, contextlib.redirect_stdout(self.out), contextlib.redirect_stderr(self.err):
            self.assertEqual(0, c.command_sni(args))
        self.assertEqual(1, batch.call_args[0][2])
        self.assertIn("one at a time", self.err.getvalue())

    def test_sort_filter_and_individual_details(self):
        path = self.report()
        self.assertEqual(0, self.run_cli(["results", path, "--sort", "avg_ping", "--descending", "--detail", "1"]))
        value = json.loads(self.out.getvalue())
        self.assertEqual("8.8.8.12", value["ip"])
        self.assertEqual(4, value["attempt_diagnostics"][0]["attempt"])

    def test_loopback_scan_and_report(self):
        server = socket.socket()
        server.bind(("127.0.0.1", 0))
        server.listen(10)
        stop = threading.Event()
        def accept():
            server.settimeout(0.1)
            while not stop.is_set():
                try:
                    connection, _ = server.accept()
                    connection.close()
                except socket.timeout:
                    continue
                except OSError:
                    break
        thread = threading.Thread(target=accept, daemon=True)
        thread.start()
        try:
            result = self.run_cli(["ip", "127.0.0.1", "--port", str(server.getsockname()[1]), "--count", "3", "--timeout", "500", "--authorized", "--allow-private", "--report-dir", str(self.reports)])
            self.assertEqual(0, result, self.err.getvalue())
            report = c.load_report(self.saved())
            self.assertEqual(3, report["rows"][0]["success"])
            self.assertEqual(0, report["rows"][0]["packet_loss"])
        finally:
            stop.set(); server.close(); thread.join(1)

    def test_mocked_sni_and_reality(self):
        row = dict(status="Online", count=2, success=2, packet_loss=0, avg_ping=12, tcp_status="Online", alpn="h2")
        with patch.object(self.e, "HAVE_CURL_CFFI", True), patch.object(self.e, "sni_target_test", return_value=row):
            self.assertEqual(0, self.run_cli(["sni", "8.8.8.8", "one.example.com", "two.example.com", "--authorized", "--report-dir", str(self.reports)]))
        self.assertEqual(2, len(c.load_report(self.saved())["rows"]))
        other = self.root / "reality_reports"
        with patch.object(self.e, "HAVE_CURL_CFFI", True), patch.object(c, "reality_setup", return_value=("/trusted/xray", {"fingerprint": "firefox"})), patch.object(self.e, "reality_sni_test", return_value={"reality": {"success": 2}, "tcp": {"ok": True}}), patch.object(self.e, "reality_result_to_row", return_value=dict(row, verdict="VALID")):
            self.assertEqual(0, self.run_cli(["sni", "8.8.8.8", "one.example.com", "--reality-config", "unused", "--authorized", "--report-dir", str(other)]))
        self.assertEqual("firefox", c.load_report(next(other.glob("*.json")))["rows"][0]["fingerprint"])

    def test_reality_fingerprint_explicit_override(self):
        args = c.build_parser().parse_args(["sni", "8.8.8.8", "one.example.com", "--reality-config", "unused", "--xray", "/trusted/xray", "--fingerprint", "safari"])
        with patch.object(self.e, "HAVE_CURL_CFFI", True), patch.object(c, "secret_link", return_value="hidden"), patch.object(self.e, "parse_reality_link", return_value={"fingerprint": "firefox", "error": None}), patch.object(self.e, "set_xray_binary"), patch.object(self.e, "ensure_xray_binary", return_value=("/trusted/xray", "version")):
            _, params = c.reality_setup(args)
        self.assertEqual("safari", params["fingerprint"])

    def test_reality_timeout_reaches_all_network_phases(self):
        args = c.build_parser().parse_args(["sni", "8.8.8.8", "one.example.com", "--count", "2", "--timeout", "1375"])
        row = dict(ip="one.example.com", connect_host="8.8.8.8", port=443,
                   target="example.com", method="reality", fingerprint="firefox")
        params = {"fingerprint": "firefox"}
        with patch.object(self.e, "reality_sni_test", return_value={"reality": {}, "tcp": {}}) as probe, patch.object(self.e, "reality_result_to_row", return_value={"status": "Online"}):
            c.sni_worker(args, row, ("/trusted/xray", params))
        probe.assert_called_once_with("/trusted/xray", params, "8.8.8.8", 443, "one.example.com", 2, 1375,
                                      xray_ready_timeout_s=1.375, probe_timeout_ms=1375)

    def test_viewport_is_compact_and_detail_remains_full(self):
        report = c.load_report(self.report())
        report["rows"][0]["ip"] = "a" * 200 + ".example.com"
        report["rows"][0]["attempt_diagnostics"] = [{"attempt": 1, "phase": "tcp", "error": "TIMEOUT"}]
        with patch.object(c.shutil, "get_terminal_size", return_value=os.terminal_size((100, 24))):
            overview = c.viewport(report["rows"])
        self.assertLessEqual(max(map(len, overview.splitlines())), 100)
        self.assertNotIn("attempt_diagnostics", overview)
        self.assertIn("a" * 200, c.render(report["rows"], "txt"))
        self.assertIn("TIMEOUT", c.render(report["rows"], "txt"))

    def test_port_filter_keeps_filtered_rows(self):
        with patch.object(self.e, "check_port", return_value=False), patch.object(self.e, "tcp_handshake_ping", side_effect=AssertionError("must filter")):
            self.assertEqual(0, self.run_cli(["ip", "8.8.8.8", "--authorized", "--port-filter", "--report-dir", str(self.reports)]))
        self.assertEqual("Filtered", c.load_report(self.saved())["rows"][0]["status"])

    def test_retest_preserves_pinned_destination(self):
        path = self.report()
        calls = []
        def probe(ip, port, count, timeout):
            calls.append((ip, count))
            return dict(ip=ip, status="Online", success=count, count=count, avg_ping=1, packet_loss=0)
        with patch.object(self.e, "tcp_handshake_ping", side_effect=probe), patch.object(self.e, "_getaddrinfo", side_effect=AssertionError("must not resolve")):
            self.assertEqual(0, self.run_cli(["retest", path, "--top", "2", "--count", "8", "--authorized", "--report-dir", str(self.reports)]))
        self.assertEqual({("8.8.8.1", 8), ("8.8.8.2", 8)}, set(calls))

    def test_retest_overrides_method_sni_port_fingerprint(self):
        path = self.report(count=1)
        measured = dict(ip="8.8.8.1", status="Online", count=10, success=10, packet_loss=0, avg_ping=1)
        with patch.object(self.e, "HAVE_CURL_CFFI", True), patch.object(self.e, "browser_tls_ping", return_value=measured) as probe:
            self.assertEqual(0, self.run_cli(["retest", path, "--method", "browser", "--port", "8443", "--sni", "new.example.com", "--fingerprint", "firefox", "--authorized", "--report-dir", str(self.reports)]))
        probe.assert_called_once_with("8.8.8.1", 8443, "new.example.com", 10, 4000, "firefox")
        row = c.load_report(self.saved())["rows"][0]
        self.assertEqual("browser", row["method"])
        self.assertEqual("firefox", row["fingerprint"])

    def test_speed_consent_and_merge_metrics(self):
        path = self.report("reality", 2)
        argv = ["speed", path, "--top", "1", "--authorized", "--download-mb", "1", "--upload-mb", "0", "--report-dir", str(self.reports)]
        with patch.object(c, "reality_setup", side_effect=AssertionError("must require consent")):
            self.assertEqual(1, self.run_cli(argv))
        with patch.object(c, "reality_setup", return_value=("/trusted/xray", {})), patch.object(self.e, "high_accuracy_speed_test", return_value={"download_mbps": 12.5, "upload_mbps": 0, "download_ok": True, "upload_ok": False}):
            self.assertEqual(0, self.run_cli(argv + ["--traffic-consent"]), self.err.getvalue())
        result = c.load_report(self.saved())["rows"][0]
        self.assertEqual(12.5, result["download_mbps"])
        self.assertEqual(3.4, result["jitter"])

    def test_discovery_no_silent_limit_and_export(self):
        with patch.object(self.e, "find_subdomains_via_crtsh", return_value=(["a.example.com", "b.example.com"], None)):
            self.assertEqual(1, self.run_cli(["discover", "example.com", "--limit", "1", "--authorized", "--report-dir", str(self.reports)]))
            output = self.root / "candidates.txt"
            self.assertEqual(0, self.run_cli(["discover", "example.com", "--limit", "2", "--authorized", "--candidates-output", str(output), "--report-dir", str(self.reports)]))
            self.assertEqual("a.example.com\nb.example.com\n", output.read_text())

    def test_sni_json_is_offline(self):
        with patch.object(self.e, "_getaddrinfo", side_effect=AssertionError("network")):
            self.assertEqual(0, self.run_cli(["sni-json", "example.com:443", "one.example.com", "two.example.com"]))
        value = json.loads(self.out.getvalue())
        self.assertEqual(["one.example.com", "two.example.com"], value["realitySettings"]["serverNames"])

    def test_config_rewriting_all_four_protocols(self):
        report = self.report(count=1)
        vmess = "vmess://" + base64.b64encode(json.dumps({"add": "example.com", "port": 443, "id": "private-secret", "ps": "test"}).encode()).decode()
        links = ["vless://private-secret@example.com:443?security=tls", "trojan://private-secret@example.com:443?security=tls", "ss://private-secret@example.com:443", vmess]
        for index, link in enumerate(links):
            secret, output = self.root / f"link-{index}", self.root / f"configs-{index}.txt"
            c.private_write(secret, link)
            self.assertEqual(0, self.run_cli(["configs", report, "--rows", "1", "--config-file", str(secret), "--output", str(output)]))
            text = output.read_text()
            if text.startswith("vmess://"):
                text = base64.b64decode(text[8:]).decode()
            self.assertIn("8.8.8.1", text)
            self.assertEqual(0o600, stat.S_IMODE(output.stat().st_mode))
        self.assertNotIn("private-secret", self.out.getvalue())

    def test_cancellation_saves_completed_rows(self):
        calls = [0]
        def probe(ip, port, count, timeout):
            calls[0] += 1
            if calls[0] == 2:
                self.e._cancel_event.set()
                raise self.e.ScanCancelled()
            self.e._check_cancel()
            return dict(ip=ip, status="Online", success=1, count=1, packet_loss=0, avg_ping=1)
        with patch.object(self.e, "tcp_handshake_ping", side_effect=probe):
            self.assertEqual(130, self.run_cli(["ip", "8.8.8.1", "8.8.8.2", "8.8.8.3", "--workers", "1", "--authorized", "--report-dir", str(self.reports)]))
        report = c.load_report(self.saved())
        self.assertTrue(report["cancelled"])
        self.assertEqual(1, len(report["rows"]))
        self.assertIsNone(self.e._cancel_event)

    def test_dependencies_status_never_executes_or_downloads(self):
        with patch.object(self.e, "ensure_xray_binary", side_effect=AssertionError("execution")):
            self.assertEqual(0, self.run_cli(["dependencies", "status"]))
            self.assertEqual(1, self.run_cli(["dependencies", "install"]))

    def test_wizard_eof_exits_without_looping(self):
        with patch.object(c.sys.stdin, "isatty", return_value=True), patch("builtins.input", side_effect=EOFError):
            self.assertEqual(0, self.run_cli([]))

    def test_discovery_cancellation_keeps_completed_domains(self):
        def discover(base, **kwargs):
            if base == "second.example.com":
                self.e._cancel_event.set()
                raise self.e.ScanCancelled()
            return ["a.first.example.com"], None
        with patch.object(self.e, "find_subdomains_via_crtsh", side_effect=discover):
            self.assertEqual(130, self.run_cli(["discover", "first.example.com", "second.example.com", "--authorized", "--report-dir", str(self.reports)]))
        report = c.load_report(self.saved())
        self.assertTrue(report["cancelled"])
        self.assertEqual("a.first.example.com", report["rows"][0]["ip"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
