#!/usr/bin/env python3
"""Offline regression tests; only local loopback sockets and controlled fixtures.

Run: python3 packaging/test-scanner-engine.py
No package installation, public target scanning, or downloads are performed.
"""
import base64
import importlib.util
import io
import http.server
import json
import os
from pathlib import Path
import socket
import socketserver
import ssl
import stat
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from unittest import mock

sys.dont_write_bytecode = True
SPEC = importlib.util.spec_from_file_location("scanner_engine", Path(__file__).with_name("scanner-engine.py"))
engine = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(engine)

KEY = base64.urlsafe_b64encode(b"x" * 32).decode().rstrip("=")
UUID = "11111111-1111-4111-8111-111111111111"
LINK = f"vless://{UUID}@[::1]:443?security=reality&pbk={KEY}&sid=aabb&sni=example.com"
PARAMS = engine.parse_reality_link(LINK)


class EngineTest(unittest.TestCase):
    def setUp(self):
        engine.set_cancel_event(None)
        engine.set_xray_binary(None)

    def tearDown(self):
        engine.set_cancel_event(None)
        engine.set_xray_binary(None)


class ParsingTests(EngineTest):
    def test_ipv4_ipv6_and_dedup(self):
        addresses, errors, truncated = engine.parse_ip_input("127.0.0.1, ::1 127.0.0.1 2001:db8::/126")
        self.assertEqual(addresses, ["127.0.0.1", "::1", "2001:db8::1", "2001:db8::2", "2001:db8::3"])
        self.assertEqual(errors, [])
        self.assertEqual(truncated, [])

    def test_huge_ipv6_range_is_bounded(self):
        start = time.monotonic()
        addresses, _, truncated = engine.parse_ip_input("::/0", max_per_cidr=4096)
        self.assertEqual(len(addresses), 4096)
        self.assertEqual(truncated[0][2], 4096)
        self.assertLess(time.monotonic() - start, 2)

    def test_combined_cidrs_share_bound(self):
        addresses, _, truncated = engine.parse_ip_input("10.0.0.0/16 192.0.0.0/16 8.8.8.8")
        self.assertEqual(len(addresses), 4096)
        self.assertEqual(truncated[-1], ("8.8.8.8", 1, 0))

    def test_cidr_31_and_32(self):
        self.assertEqual(engine.parse_ip_input("192.0.2.0/31 192.0.2.4/32")[0], ["192.0.2.0", "192.0.2.1", "192.0.2.4"])

    def test_input_size_cap(self):
        with self.assertRaises(ValueError):
            engine.parse_ip_input("1" * (engine.MAX_INPUT_BYTES + 1))

    def test_invalid_and_scoped_ip(self):
        self.assertEqual(engine.parse_ip_input("garbage fe80::1%en0")[1], ["garbage", "fe80::1%en0"])

    def test_domain_urls_normalization(self):
        domains, errors = engine.parse_domain_list("https://EXAMPLE.com:443/path example.com xn--bcher-kva.example")
        self.assertEqual(domains, ["example.com", "xn--bcher-kva.example"])
        self.assertFalse(errors)

    def test_domain_credentials_ports_and_schemes_rejected(self):
        domains, errors = engine.parse_domain_list("https://secret@example.com ftp://example.com example.com:0 example.com:garbage")
        self.assertEqual(domains, [])
        self.assertEqual(len(errors), 4)

    def test_target_ipv6(self):
        self.assertEqual(engine.parse_target_string("[2001:db8::1]:8443", 443), ("2001:db8::1", 8443, None))
        self.assertEqual(engine.parse_target_string("2001:db8::1", 443), ("2001:db8::1", 443, None))

    def test_invalid_targets(self):
        for value in ("a.example:0", "a.example:65536", "a.example:no", "https://user@a.example", "localhost", "fe80::1%lo0"):
            with self.subTest(value=value):
                self.assertIsNotNone(engine.parse_target_string(value, 443)[2])

    def test_target_list_whitespace(self):
        targets, errors = engine.parse_target_list("example.com:443\n[::1]:443, example.com:443 127.0.0.1:80", 443)
        self.assertEqual(len(targets), 3)
        self.assertEqual(errors, [])

    def test_reality_ipv6_and_alias(self):
        self.assertIsNone(PARAMS["error"])
        self.assertEqual(PARAMS["address"], "::1")
        self.assertIs(engine.parse_reality_link, engine.parse_vless_reality_link)

    def test_reality_invalid_keys_credentials_and_duplicates(self):
        for value in (LINK.replace(KEY, "x"), LINK + "&sid=123", LINK.replace("sid=aabb", "sid=123"), LINK.replace(UUID, "not-a-uuid"), LINK.replace(":443?", ":0?")):
            with self.subTest(value=value):
                self.assertIsNotNone(engine.parse_reality_link(value)["error"])

    def test_trojan_secret_decoding(self):
        parsed = engine.parse_reality_link(f"trojan://test%40password@127.0.0.1:443?security=reality&pbk={KEY}")
        self.assertIsNone(parsed["error"])
        self.assertEqual(parsed["password"], "test@password")

    def test_unsupported_reality_transport_links_rejected(self):
        for transport in ("ws", "grpc", "xhttp", "httpupgrade", "h2", "http", "kcp", "quic"):
            with self.subTest(transport=transport):
                parsed = engine.parse_reality_link(LINK + "&type=" + transport)
                self.assertIn("supports tcp/raw only", parsed["error"])

    def test_config_builder_rejects_unsupported_transport_directly(self):
        for transport in ("ws", "grpc", "xhttp"):
            with self.subTest(transport=transport), self.assertRaisesRegex(ValueError, "supports tcp/raw only"):
                engine.build_xray_client_config(dict(PARAMS, network=transport), "::1", 443, "example.com", 18080)

    def test_reality_tcp_and_raw_transport_preserved(self):
        for transport in ("tcp", "raw"):
            parsed = engine.parse_reality_link(LINK + "&type=" + transport)
            self.assertIsNone(parsed["error"])
            config = engine.build_xray_client_config(parsed, "::1", 443, "example.com", 18080)
            self.assertEqual(config["outbounds"][0]["streamSettings"]["network"], transport)

    def test_link_modification_ipv6(self):
        for prefix, credentials in (("vless", UUID), ("trojan", "pass"), ("ss", "dGVzdA==")):
            link = f"{prefix}://{credentials}@[2001:db8::1]:8443#name"
            self.assertIn("@[2001:db8::2]:8443", engine.modify_config_link(link, "2001:db8::2"))

    def test_vmess_link_modification(self):
        original = "vmess://" + base64.b64encode(json.dumps({"add": "1.1.1.1", "ps": "demo"}).encode()).decode()
        changed = engine.modify_config_link(original, "::1")
        self.assertEqual(json.loads(base64.b64decode(changed[8:]))["add"], "::1")

    def test_stats(self):
        stats = engine._ping_stats([10, 30, 20])
        self.assertEqual(stats["jitter"], 15)
        self.assertEqual(stats["min_ping"], 10)
        self.assertIsNone(engine._ping_stats([])["stddev"])


class CancellationAndSocketTests(EngineTest):
    def test_reject_invalid_parameters_before_network(self):
        for count, timeout, port in ((0, 1000, 443), (101, 1000, 443), (1, 0, 443), (1, 120001, 443), (1, 1000, 0)):
            with self.assertRaises(ValueError), mock.patch.object(engine, "_connect_socket") as connect:
                engine.tcp_handshake_ping("127.0.0.1", port, count, timeout)
            connect.assert_not_called()

    def test_cancel_before_network(self):
        event = threading.Event()
        event.set()
        engine.set_cancel_event(event)
        with self.assertRaises(engine.ScanCancelled), mock.patch.object(engine.socket, "socket") as connect:
            engine.tcp_handshake_ping("127.0.0.1", 443, 2, 1000)
        connect.assert_not_called()

    def test_cancel_between_attempts(self):
        event = threading.Event()
        engine.set_cancel_event(event)
        def fail(*_):
            event.set()
            raise OSError("SECRET PASSWORD")
        with mock.patch.object(engine, "_connect_socket", side_effect=fail) as connect:
            with self.assertRaises(engine.ScanCancelled):
                engine.tcp_handshake_ping("127.0.0.1", 443, 10, 1000)
        self.assertEqual(connect.call_count, 1)

    def test_failure_is_redacted_per_attempt(self):
        with mock.patch.object(engine, "_connect_socket", side_effect=OSError("vless://SECRET@example.com")):
            result = engine.tcp_handshake_ping("127.0.0.1", 443, 2, 1000)
        self.assertEqual(result["packet_loss"], 100)
        self.assertEqual(len(result["attempt_diagnostics"]), 2)
        self.assertNotIn("SECRET", json.dumps(result))

    def test_ipv4_loopback(self):
        with socket.socket() as server:
            server.bind(("127.0.0.1", 0))
            server.listen(4)
            result = engine.tcp_handshake_ping("127.0.0.1", server.getsockname()[1], 2, 1000)
        self.assertEqual(result["success"], 2)

    def test_ipv6_loopback(self):
        server = None
        try:
            server = socket.socket(socket.AF_INET6)
            server.bind(("::1", 0))
        except OSError as exc:
            if server is not None:
                server.close()
            self.skipTest(f"IPv6 loopback unavailable: {exc}")
        with server:
            server.listen(4)
            result = engine.tcp_handshake_ping("::1", server.getsockname()[1], 2, 1000)
        self.assertEqual(result["success"], 2)

    def test_dns_wait_is_bounded(self):
        release = threading.Event()
        def blocked(*_, **__):
            release.wait(2)
            return []
        try:
            start = time.monotonic()
            with mock.patch.object(engine.socket, "getaddrinfo", side_effect=blocked):
                with self.assertRaises(TimeoutError):
                    engine._getaddrinfo("example.com", 443, .08)
            self.assertLess(time.monotonic() - start, .5)
        finally:
            release.set()

    def test_dns_cancellation(self):
        event, release = threading.Event(), threading.Event()
        engine.set_cancel_event(event)
        timer = threading.Timer(.05, event.set)
        timer.start()
        try:
            with mock.patch.object(engine.socket, "getaddrinfo", side_effect=lambda *a, **k: release.wait(2)):
                with self.assertRaises(engine.ScanCancelled):
                    engine._getaddrinfo("example.com", 443, 2)
        finally:
            release.set()
            timer.join()

    def test_timed_out_dns_workers_do_not_accumulate(self):
        release, drained = threading.Event(), threading.Event()
        lock = threading.Lock()
        counts = {"started": 0, "finished": 0}
        slots = threading.BoundedSemaphore(engine.MAX_DNS_WORKERS)
        def blocked(*_, **__):
            with lock:
                counts["started"] += 1
            release.wait(2)
            with lock:
                counts["finished"] += 1
                if counts["finished"] == engine.MAX_DNS_WORKERS:
                    drained.set()
            return []
        def lookup():
            try:
                engine._getaddrinfo("example.com", 443, .1)
            except TimeoutError:
                return "timeout"
            return "unexpected success"
        try:
            with mock.patch.object(engine, "_dns_slots", slots), mock.patch.object(engine.socket, "getaddrinfo", side_effect=blocked), engine.ThreadPoolExecutor(max_workers=16) as pool:
                outcomes = list(pool.map(lambda _: lookup(), range(16)))
                self.assertEqual(outcomes, ["timeout"] * 16)
                self.assertEqual(counts["started"], engine.MAX_DNS_WORKERS)
                self.assertEqual(lookup(), "timeout")
                self.assertEqual(counts["started"], engine.MAX_DNS_WORKERS)
        finally:
            release.set()
            self.assertTrue(drained.wait(1), "resolver fixtures did not drain")

    def test_dns_capacity_wait_is_cancellable(self):
        slots = threading.BoundedSemaphore(1)
        slots.acquire()
        event = threading.Event()
        engine.set_cancel_event(event)
        timer = threading.Timer(.02, event.set)
        timer.start()
        try:
            with mock.patch.object(engine, "_dns_slots", slots), mock.patch.object(engine.socket, "getaddrinfo") as resolver:
                with self.assertRaises(engine.ScanCancelled):
                    engine._getaddrinfo("example.com", 443, 1)
            resolver.assert_not_called()
        finally:
            slots.release()
            timer.join()

    def test_dns_thread_start_failure_releases_capacity(self):
        slots = threading.BoundedSemaphore(1)
        with mock.patch.object(engine, "_dns_slots", slots), mock.patch.object(engine.threading.Thread, "start", side_effect=RuntimeError("no thread capacity")):
            with self.assertRaises(RuntimeError):
                engine._getaddrinfo("example.com", 443, .1)
        self.assertTrue(slots.acquire(blocking=False))
        slots.release()

    def test_resolve_ipv6(self):
        self.assertEqual(engine.resolve_host("::1"), ("::1", None))

    def test_tls_wait_honors_timeout_and_closes_socket(self):
        import ssl
        raw, tls = mock.Mock(), mock.Mock()
        tls.do_handshake.side_effect = ssl.SSLWantReadError()
        context = mock.Mock()
        context.wrap_socket.return_value = tls
        with mock.patch.object(engine, "_connect_socket", return_value=raw), mock.patch.object(engine.select, "select", side_effect=lambda *a: time.sleep(.01)):
            with self.assertRaises(TimeoutError):
                engine._tls_connect(context, "::1", 443, "example.com", .03)
        tls.close.assert_called_once()

    def test_tls_cancel_closes_socket(self):
        import ssl
        event = threading.Event()
        engine.set_cancel_event(event)
        raw, tls = mock.Mock(), mock.Mock()
        tls.do_handshake.side_effect = ssl.SSLWantReadError()
        context = mock.Mock()
        context.wrap_socket.return_value = tls
        with mock.patch.object(engine, "_connect_socket", return_value=raw), mock.patch.object(engine.select, "select", side_effect=lambda *a: event.set()):
            with self.assertRaises(engine.ScanCancelled):
                engine._tls_connect(context, "::1", 443, "example.com", 1)
        tls.close.assert_called_once()


class DiscoveryTests(EngineTest):
    def test_discovery_filters_foreign_names(self):
        response = io.BytesIO(json.dumps([{"name_value": "*.one.example.com\nother.example.net\nexample.com"}, {"name_value": None}]).encode())
        with mock.patch.object(engine, "_open_https_url", return_value=response):
            domains, error = engine.find_subdomains_via_crtsh("example.com")
        self.assertIsNone(error)
        self.assertEqual(set(domains), {"one.example.com", "example.com"})

    def test_bad_discovery_shape(self):
        with mock.patch.object(engine, "_open_https_url", return_value=io.BytesIO(b'{}')):
            self.assertIn("PARSE_ERROR", engine.find_subdomains_via_crtsh("example.com")[1])

    def test_bounded_response(self):
        with self.assertRaises(ValueError):
            engine._read_bounded(io.BytesIO(b"x" * 20), 10, 1)

    def test_discovery_merge(self):
        with mock.patch.object(engine, "find_subdomains_via_crtsh", side_effect=lambda base, *_: (["a." + base, "b." + base], None)):
            domains, errors, empty = engine.find_subdomains_for_bases(["example.com", "example.net"], total_limit=3)
        self.assertEqual(domains, ["a.example.com", "a.example.net", "b.example.com"])
        self.assertFalse(errors or empty)

    def test_untrusted_download_url(self):
        for url in ("http://github.com/a", "file:///etc/passwd", "https://user@github.com/a", "https://localhost/a"):
            with self.assertRaises(ValueError):
                engine._open_https_url(url, 1, {"github.com"})


class FakeOptions:
    def __getattr__(self, name):
        return name


class CurlFixture:
    def __init__(self, status=200, response=b"x" * 1024, upload_actual=1024, error=None, impersonate_code=0):
        self.options = {}
        self.status = status
        self.response = response
        self.upload_actual = upload_actual
        self.error = error
        self.impersonate_code = impersonate_code
        self.closed = False

    def setopt(self, key, value):
        self.options[key] = value

    def impersonate(self, value):
        self.fingerprint = value
        return self.impersonate_code

    def perform(self):
        if self.error:
            raise self.error
        if "READFUNCTION" in self.options:
            while self.options["READFUNCTION"](333):
                pass
        if "WRITEFUNCTION" in self.options:
            result = self.options["WRITEFUNCTION"](self.response)
            # Match curl_cffi: short returns (including 0) are ignored, while
            # CURL_WRITEFUNC_ERROR is passed to libcurl as an explicit abort.
            if result == engine.CURL_WRITEFUNC_ERROR:
                raise OSError("Curl write callback aborted")

    def getinfo(self, key):
        return self.status if key == "RESPONSE_CODE" else self.upload_actual

    def close(self):
        self.closed = True


class CurlTests(EngineTest):
    def curl_patches(self, fixtures):
        return mock.patch.multiple(engine, HAVE_CURL_CFFI=True, Curl=mock.Mock(side_effect=fixtures), CurlOpt=FakeOptions(), CurlInfo=FakeOptions())

    def speed(self, fixtures):
        with self.curl_patches(fixtures), mock.patch.object(engine.os.path, "isfile", return_value=True), mock.patch.object(engine, "_find_free_local_port", return_value=18080), mock.patch.object(engine, "run_xray_process", return_value=(None, None, True, None)), mock.patch.object(engine, "stop_xray_process") as stop:
            result = engine.high_accuracy_speed_test("/trusted/xray", PARAMS, "::1", 443, "example.com", 1 / 1024, 1 / 1024, 500)
        stop.assert_called_once()
        return result

    def test_browser_ipv6_pin_and_no_environment_proxy(self):
        fixture = CurlFixture()
        with self.curl_patches([fixture]):
            result = engine.browser_tls_ping("2001:db8::1", 443, "example.com", 1, 500)
        self.assertEqual(result["success"], 1)
        self.assertEqual(fixture.options["RESOLVE"], [b"example.com:443:[2001:db8::1]"])
        self.assertEqual(fixture.options["PROXY"], b"")
        self.assertTrue(fixture.closed)

    def test_browser_errors_redacted(self):
        fixture = CurlFixture(error=RuntimeError("SECRET LINK"))
        with self.curl_patches([fixture]):
            result = engine.browser_tls_ping("127.0.0.1", 443, "example.com", 1, 500)
        self.assertNotIn("SECRET", str(result))
        self.assertEqual(len(result["attempt_diagnostics"]), 1)

    def test_unsupported_browser_fingerprint_never_performs_tls(self):
        fixture = CurlFixture(impersonate_code=43)
        fixture.perform = mock.Mock()
        with self.curl_patches([fixture]):
            result = engine.browser_tls_ping("127.0.0.1", 443, "example.com", 1, 500)
        fixture.perform.assert_not_called()
        self.assertEqual(result["success"], 0)
        self.assertIn("FINGERPRINT_ERROR", result["attempt_diagnostics"][0]["error"])
        self.assertTrue(fixture.closed)

    def test_generic_browser_alias_is_normalized_before_impersonation(self):
        fixture = CurlFixture()
        with self.curl_patches([fixture]), mock.patch.object(engine, "_normalize_browser_type", return_value="chrome136"):
            result = engine.browser_tls_ping("127.0.0.1", 443, "example.com", 1, 500, "chrome")
        self.assertEqual(fixture.fingerprint, "chrome136")
        self.assertEqual(result["fingerprint_effective"], "chrome136")

    def test_speed_counts_exact_bytes_and_post(self):
        fixtures = [CurlFixture(), CurlFixture()]
        result = self.speed(fixtures)
        self.assertTrue(result["download_ok"] and result["upload_ok"])
        self.assertEqual(result["download_bytes"], 1024)
        self.assertEqual(result["upload_bytes"], 1024)
        self.assertEqual(fixtures[1].options["CUSTOMREQUEST"], b"POST")
        self.assertEqual(fixtures[0].options["TIMEOUT_MS"], 500)

    def test_speed_cannot_bypass_socks_via_no_proxy_environment(self):
        fixtures = [CurlFixture(), CurlFixture()]
        with mock.patch.dict(os.environ, {"NO_PROXY": "*", "no_proxy": "cloudflare.com,.cloudflare.com"}):
            result = self.speed(fixtures)
        self.assertTrue(result["download_ok"] and result["upload_ok"])
        for fixture in fixtures:
            self.assertEqual(fixture.options["PROXY"], b"socks5h://127.0.0.1:18080")
            self.assertEqual(fixture.options["NOPROXY"], b"")

    def test_speed_rejects_http_errors(self):
        result = self.speed([CurlFixture(status=403), CurlFixture(status=500)])
        self.assertFalse(result["download_ok"] or result["upload_ok"])

    def test_speed_rejects_short_payloads(self):
        result = self.speed([CurlFixture(response=b"x" * 500), CurlFixture(upload_actual=500)])
        self.assertFalse(result["download_ok"] or result["upload_ok"])

    def test_speed_overlong_payload_aborts_with_curl_sentinel(self):
        fixture = CurlFixture(response=b"x" * 1025)
        result = self.speed([fixture, CurlFixture()])
        self.assertFalse(result["download_ok"])
        self.assertIn("failed", result["error"])
        self.assertEqual(fixture.options["WRITEFUNCTION"](b"x" * 1025), engine.CURL_WRITEFUNC_ERROR)

    def test_speed_cancel_write_callback_uses_curl_sentinel(self):
        fixture = CurlFixture()
        self.speed([fixture, CurlFixture()])
        event = threading.Event()
        event.set()
        engine.set_cancel_event(event)
        self.assertEqual(fixture.options["WRITEFUNCTION"](b"data"), engine.CURL_WRITEFUNC_ERROR)

    def test_older_curl_upload_uses_bounded_postfields_fallback(self):
        fixture = CurlFixture()
        original = fixture.setopt
        def older_setopt(key, value):
            if key == "READFUNCTION":
                raise NotImplementedError("no callback")
            original(key, value)
        fixture.setopt = older_setopt
        result = self.speed([CurlFixture(), fixture])
        self.assertTrue(result["upload_ok"])
        self.assertEqual(fixture.options["UPLOAD"], 0)
        self.assertEqual(fixture.options["POSTFIELDSIZE"], 1024)
        self.assertEqual(len(fixture.options["POSTFIELDS"]), 1024)

    def test_older_curl_large_upload_has_clear_dependency_error(self):
        fixture = CurlFixture()
        original = fixture.setopt
        def older_setopt(key, value):
            if key == "READFUNCTION":
                raise NotImplementedError("no callback")
            original(key, value)
        fixture.setopt = older_setopt
        with self.curl_patches([fixture]):
            with self.assertRaises(engine.CurlCapabilityError) as raised:
                engine._speed_transfer("socks5h://127.0.0.1:18080", "upload", engine.MAX_BUFFERED_UPLOAD_BYTES + 1, 500)
        self.assertNotIn("POSTFIELDS", fixture.options)
        self.assertIn("at most 16 MiB", engine._safe_error(raised.exception))

    def test_speed_does_not_use_read_callback_as_bytes_sent(self):
        result = self.speed([CurlFixture(), CurlFixture(upload_actual=0)])
        self.assertTrue(result["download_ok"])
        self.assertFalse(result["upload_ok"])
        self.assertEqual(result["upload_bytes"], 0)

    def test_speed_error_redaction(self):
        result = self.speed([CurlFixture(error=RuntimeError("SECRET_URL")), CurlFixture(error=RuntimeError("SECRET_PASSWORD"))])
        self.assertNotIn("SECRET", str(result))

    def test_speed_zero_disables_one_direction(self):
        for download, upload in ((0, 1 / 1024), (1 / 1024, 0)):
            fixture = CurlFixture()
            with self.curl_patches([fixture]), mock.patch.object(engine.os.path, "isfile", return_value=True), mock.patch.object(engine, "_find_free_local_port", return_value=18080), mock.patch.object(engine, "run_xray_process", return_value=(None, None, True, None)), mock.patch.object(engine, "stop_xray_process"):
                result = engine.high_accuracy_speed_test("/trusted/xray", PARAMS, "::1", 443, "example.com", download, upload, 500)
            self.assertEqual(result["download_ok"], download > 0)
            self.assertEqual(result["upload_ok"], upload > 0)
            self.assertIsNone(result["error"])

    def test_speed_zero_both_directions_rejected(self):
        with self.assertRaises(ValueError):
            engine.high_accuracy_speed_test("/trusted/xray", PARAMS, "::1", 443, "example.com", 0, 0)

    def test_probe_requires_exact_204_and_verifies_tls(self):
        for status in (200, 302, 204, 500):
            fixture = CurlFixture(status=status)
            with self.curl_patches([fixture]):
                ok, _ = engine.reality_probe_through_tunnel(18080)
            self.assertEqual(ok, status == 204)
            self.assertEqual(fixture.options["SSL_VERIFYPEER"], 1)

    def test_reality_cannot_bypass_socks_via_no_proxy_environment(self):
        fixture = CurlFixture(status=204)
        with mock.patch.dict(os.environ, {"NO_PROXY": "cloudflare.com,.cloudflare.com", "no_proxy": "*"}), self.curl_patches([fixture]):
            ok, _ = engine.reality_probe_through_tunnel(18080)
        self.assertTrue(ok)
        self.assertEqual(fixture.options["PROXY"], b"socks5h://127.0.0.1:18080")
        self.assertEqual(fixture.options["NOPROXY"], b"")

    def test_curl_cancel_callback(self):
        fixture = CurlFixture()
        event = threading.Event()
        engine.set_cancel_event(event)
        with self.curl_patches([]):
            engine._curl_cancel(fixture)
        self.assertEqual(fixture.options["XFERINFOFUNCTION"](), 0)
        event.set()
        self.assertEqual(fixture.options["XFERINFOFUNCTION"](), 1)

    def test_older_curl_without_progress_callback_is_supported(self):
        fixture = CurlFixture()
        original = fixture.setopt
        def unsupported(key, value):
            if key == "XFERINFOFUNCTION":
                raise NotImplementedError("unsupported callback")
            original(key, value)
        fixture.setopt = unsupported
        with self.curl_patches([]):
            self.assertFalse(engine._curl_cancel(fixture))
        self.assertEqual(fixture.options["NOPROGRESS"], 1)

    def test_speed_cancellation_propagates_and_closes_tunnel(self):
        fixture = CurlFixture()
        event = threading.Event()
        engine.set_cancel_event(event)
        def cancel():
            event.set()
            raise RuntimeError("callback aborted")
        fixture.perform = cancel
        with self.curl_patches([fixture]), mock.patch.object(engine.os.path, "isfile", return_value=True), mock.patch.object(engine, "_find_free_local_port", return_value=18080), mock.patch.object(engine, "run_xray_process", return_value=(None, "secret-config", True, None)), mock.patch.object(engine, "stop_xray_process") as stop:
            with self.assertRaises(engine.ScanCancelled):
                engine.high_accuracy_speed_test("/trusted/xray", PARAMS, "::1", 443, "example.com", 1, 1, 500)
        stop.assert_called_once_with(None, "secret-config")
        self.assertTrue(fixture.closed)


class XrayTests(EngineTest):
    def config(self):
        return engine.build_xray_client_config(PARAMS, "::1", 443, "example.com", engine._find_free_local_port())

    def test_no_implicit_path_or_env_discovery(self):
        with mock.patch.object(engine.shutil, "which") as which, mock.patch.dict(os.environ, {"XRAY_PATH": "/tmp/malicious", "PATH": "/tmp"}):
            self.assertIsNone(engine.find_xray_binary())
            with self.assertRaises(FileNotFoundError), mock.patch.object(engine, "_open_https_url") as download:
                engine.ensure_xray_binary()
        which.assert_not_called()
        download.assert_not_called()

    def test_relative_binary_rejected(self):
        with self.assertRaises(ValueError):
            engine.set_xray_binary("xray")

    def test_missing_release_digest_never_executes_download(self):
        response = io.BytesIO(json.dumps({"assets": [{"name": "fixture.zip", "browser_download_url": "https://github.com/fixture"}]}).encode())
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory, mock.patch.object(engine, "_xray_cache_dir", return_value=Path(directory)), mock.patch.object(engine, "_xray_asset_name", return_value="fixture.zip"), mock.patch.object(engine, "_open_https_url", return_value=response) as download, mock.patch.object(engine, "_run_xray_version") as execute:
            with self.assertRaises(RuntimeError):
                engine.ensure_xray_binary(allow_download=True)
            self.assertEqual(list(Path(directory).iterdir()), [])
        self.assertEqual(download.call_count, 1)
        execute.assert_not_called()

    def test_root_rejects_writable_ancestor(self):
        with tempfile.TemporaryDirectory() as directory:
            binary = Path(directory) / "xray"
            binary.write_text("#!/bin/sh\nexit 0\n")
            binary.chmod(0o755)
            with mock.patch.object(engine.os, "geteuid", return_value=0):
                with self.assertRaises(PermissionError):
                    engine.validate_xray_binary(binary)

    def test_binary_selection_is_explicit(self):
        with mock.patch.object(engine, "validate_xray_binary", return_value="/trusted/xray"):
            self.assertEqual(engine.set_xray_binary("/trusted/xray"), "/trusted/xray")
            self.assertEqual(engine.find_xray_binary(), "/trusted/xray")

    def test_environment_drops_injection_and_proxy_variables(self):
        with mock.patch.dict(os.environ, {"LD_PRELOAD": "/tmp/malicious.so", "XRAY_LOCATION_ASSET": "/tmp", "HTTPS_PROXY": "http://malicious"}):
            env = engine._xray_environment()
        self.assertNotIn("LD_PRELOAD", env)
        self.assertNotIn("XRAY_LOCATION_ASSET", env)
        self.assertNotIn("HTTPS_PROXY", env)
        self.assertEqual(env["PATH"], "/usr/bin:/bin")

    def test_popen_failure_removes_secret_file(self):
        original = tempfile.mkstemp
        with tempfile.TemporaryDirectory() as directory:
            with mock.patch.object(engine, "validate_xray_binary", return_value="/trusted/xray"), mock.patch.object(engine.tempfile, "mkstemp", side_effect=lambda **kw: original(dir=directory, **kw)), mock.patch.object(engine.subprocess, "Popen", side_effect=PermissionError("SECRET")):
                process, path, ok, error = engine.run_xray_process("/trusted/xray", self.config(), .1)
            self.assertEqual(list(Path(directory).iterdir()), [])
        self.assertFalse(ok)
        self.assertIsNone(path)
        self.assertNotIn("SECRET", error)

    def test_early_exit_removes_secret_file(self):
        original = tempfile.mkstemp
        fake = mock.Mock()
        fake.poll.return_value = 2
        fake._scanner_lock_held = False
        with tempfile.TemporaryDirectory() as directory:
            with mock.patch.object(engine, "validate_xray_binary", return_value="/trusted/xray"), mock.patch.object(engine.tempfile, "mkstemp", side_effect=lambda **kw: original(dir=directory, **kw)), mock.patch.object(engine.subprocess, "Popen", return_value=fake):
                _, path, ok, error = engine.run_xray_process("/trusted/xray", self.config(), .1)
            self.assertEqual(list(Path(directory).iterdir()), [])
        self.assertFalse(ok)
        self.assertIsNone(path)
        self.assertIn("XRAY_START_ERROR", error)

    def test_noisy_subprocess_readiness_and_secret_cleanup(self):
        with tempfile.TemporaryDirectory() as directory:
            fixture = Path(directory) / "fixture-xray"
            fixture.write_text(f"#!{sys.executable}\n" + "import json, os, socket, sys\nos.write(1, b'x' * 262144)\ncfg=json.load(open(sys.argv[-1]))\ns=socket.socket()\ns.bind(('127.0.0.1', cfg['inbounds'][0]['port']))\ns.listen(4)\nwhile True:\n c,a=s.accept()\n c.recv(3)\n c.sendall(b'\\x05\\x00')\n c.close()\n")
            fixture.chmod(0o700)
            with mock.patch.object(engine, "validate_xray_binary", return_value=str(fixture)):
                # Allow cold interpreter startup under concurrent release checks.
                process, path, ok, error = engine.run_xray_process(str(fixture), self.config(), 5)
            try:
                self.assertTrue(ok, error)
                self.assertTrue(Path(path).is_file())
                self.assertEqual(stat.S_IMODE(Path(path).stat().st_mode), 0o600)
            finally:
                engine.stop_xray_process(process, path)
            self.assertIsNotNone(process.poll())
            self.assertFalse(Path(path).exists())

    def test_existing_listener_is_not_treated_as_child(self):
        with socket.socket() as existing:
            existing.bind(("127.0.0.1", 0))
            existing.listen(1)
            config = engine.build_xray_client_config(PARAMS, "::1", 443, "example.com", existing.getsockname()[1])
            with mock.patch.object(engine, "validate_xray_binary", return_value="/trusted/xray"), mock.patch.object(engine.subprocess, "Popen") as launch:
                self.assertFalse(engine.run_xray_process("/trusted/xray", config, .1)[2])
        launch.assert_not_called()

    def test_startup_cancel_kills_child_and_removes_config(self):
        event = threading.Event()
        engine.set_cancel_event(event)
        original = tempfile.mkstemp
        fake = mock.Mock()
        fake.poll.return_value = None
        fake._scanner_lock_held = False
        def cancel(*_):
            event.set()
            return False
        with tempfile.TemporaryDirectory() as directory:
            with mock.patch.object(engine, "validate_xray_binary", return_value="/trusted/xray"), mock.patch.object(engine.tempfile, "mkstemp", side_effect=lambda **kw: original(dir=directory, **kw)), mock.patch.object(engine.subprocess, "Popen", return_value=fake), mock.patch.object(engine, "_socks_ready", side_effect=cancel):
                with self.assertRaises(engine.ScanCancelled):
                    engine.run_xray_process("/trusted/xray", self.config(), 1)
            self.assertEqual(list(Path(directory).iterdir()), [])
        fake.terminate.assert_called_once()


class RealityTests(EngineTest):
    def reality(self, probe_results):
        with mock.patch.object(engine, "tcp_handshake_ping", return_value={"success": 1, "count": 3, "avg_ping": 1}), mock.patch.object(engine.os.path, "isfile", return_value=True), mock.patch.object(engine, "_find_free_local_port", return_value=18080), mock.patch.object(engine, "run_xray_process", return_value=(None, None, True, None)), mock.patch.object(engine, "stop_xray_process"), mock.patch.object(engine, "reality_probe_through_tunnel", side_effect=probe_results):
            return engine.reality_sni_test("/trusted/xray", PARAMS, "::1", 443, "example.com", len(probe_results), 500)

    def test_valid(self):
        self.assertEqual(self.reality([(True, None), (True, None)])["verdict"], "VALID")

    def test_flaky(self):
        self.assertEqual(self.reality([(True, None), (False, "timeout")])["verdict"], "FLAKY")

    def test_reset_is_inconclusive_network_failure(self):
        result = self.reality([(False, "connection reset SECRET"), (False, "connection refused")])
        self.assertEqual(result["verdict"], "NETWORK_ERROR")
        self.assertNotIn("SECRET", str(result))

    def test_probe_timeout(self):
        self.assertEqual(self.reality([(False, "TIMEOUT")])["verdict"], "PROBE_TIMEOUT")

    def test_unexpected_response(self):
        self.assertEqual(self.reality([(False, "UNEXPECTED_RESPONSE")])["verdict"], "INVALID")

    def test_invalid_ranks_below_network_failures(self):
        rows = [{"verdict": verdict, "avg_ping": 1, "jitter": 0} for verdict in ("INVALID", "NETWORK_ERROR", "TIMEOUT", "PROBE_TIMEOUT", "FLAKY", "VALID")]
        self.assertEqual([r["verdict"] for r in sorted(rows, key=engine.reality_sort_key)], ["VALID", "FLAKY", "PROBE_TIMEOUT", "TIMEOUT", "NETWORK_ERROR", "INVALID"])

    def test_row_shape(self):
        row = engine.reality_result_to_row(self.reality([(True, None)]))
        self.assertEqual(row["status"], "Online")
        self.assertEqual(row["packet_loss"], 0)
        self.assertIn("attempt_diagnostics", row)


@unittest.skipUnless(os.environ.get("UNUNKNOWNTUN_SCANNER_REAL_CURL") == "1" and engine.HAVE_CURL_CFFI,
                     "opt-in actual curl_cffi loopback tests")
class ActualCurlLoopbackTests(EngineTest):
    """Exercise the installed binding against local HTTPS via a local SOCKS server.

    Opt in with UNUNKNOWNTUN_SCANNER_REAL_CURL=1 in an environment with curl_cffi.
    Both fixture servers bind loopback; the proxy rejects every other destination.
    """
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory()
        cls.cert = Path(cls.temporary.name) / "certificate.pem"
        key = Path(cls.temporary.name) / "key.pem"
        if not Path("/usr/bin/openssl").is_file():
            cls.temporary.cleanup()
            raise unittest.SkipTest("local OpenSSL certificate fixture unavailable")
        subprocess.run(["/usr/bin/openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "1", "-keyout", str(key), "-out", str(cls.cert), "-subj", "/CN=localhost", "-addext", "subjectAltName=IP:127.0.0.1,DNS:example.com"], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=15)

        class HTTPSHandler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_GET(self):
                if self.path == "/generate_204":
                    self.send_response(204)
                    self.end_headers()
                    return
                query = engine.urllib.parse.parse_qs(engine.urllib.parse.urlsplit(self.path).query)
                requested = int(query.get("bytes", ["1024"])[0])
                amount = requested + self.server.extra_bytes
                self.send_response(200)
                self.send_header("Content-Length", str(amount))
                self.end_headers()
                try:
                    while amount:
                        chunk = b"x" * min(4096, amount)
                        self.wfile.write(chunk)
                        self.wfile.flush()
                        amount -= len(chunk)
                        if self.server.slow:
                            time.sleep(.01)
                except OSError:
                    pass

            def do_POST(self):
                remaining = int(self.headers.get("Content-Length", 0))
                total = remaining
                while remaining:
                    data = self.rfile.read(min(65536, remaining))
                    if not data:
                        break
                    remaining -= len(data)
                self.server.uploaded_bytes += total - remaining
                self.send_response(200)
                self.send_header("Content-Length", "2")
                self.end_headers()
                self.wfile.write(b"ok")

        cls.https = http.server.ThreadingHTTPServer(("127.0.0.1", 0), HTTPSHandler)
        cls.https.daemon_threads = True
        cls.https.extra_bytes = 0
        cls.https.slow = False
        cls.https.uploaded_bytes = 0
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(str(cls.cert), str(key))
        cls.https.socket = context.wrap_socket(cls.https.socket, server_side=True)
        cls.https_port = cls.https.server_address[1]
        cls.https_thread = threading.Thread(target=cls.https.serve_forever, daemon=True)
        cls.https_thread.start()

        class SocksHandler(socketserver.BaseRequestHandler):
            def exact(self, count):
                result = b""
                while len(result) < count:
                    chunk = self.request.recv(count - len(result))
                    if not chunk:
                        raise OSError("fixture connection closed")
                    result += chunk
                return result

            def handle(self):
                self.request.settimeout(3)
                try:
                    version, methods = self.exact(2)
                    if version != 5:
                        return
                    self.exact(methods)
                    self.request.sendall(b"\x05\x00")
                    version, command, _, kind = self.exact(4)
                    if kind == 1:
                        destination = socket.inet_ntoa(self.exact(4))
                    elif kind == 3:
                        destination = self.exact(self.exact(1)[0]).decode("ascii")
                    else:
                        return
                    port = int.from_bytes(self.exact(2), "big")
                    if version != 5 or command != 1 or destination != "127.0.0.1" or port != cls.https_port:
                        self.request.sendall(b"\x05\x02\x00\x01\x00\x00\x00\x00\x00\x00")
                        return
                    with socket.create_connection(("127.0.0.1", cls.https_port), timeout=3) as upstream:
                        self.server.tunnel_connections += 1
                        self.request.sendall(b"\x05\x00\x00\x01\x7f\x00\x00\x01\x00\x00")
                        deadline = time.monotonic() + 10
                        while time.monotonic() < deadline:
                            readable, _, _ = engine.select.select([self.request, upstream], [], [], .1)
                            for source in readable:
                                data = source.recv(65536)
                                if not data:
                                    return
                                (upstream if source is self.request else self.request).sendall(data)
                except OSError:
                    pass

        class SocksServer(socketserver.ThreadingTCPServer):
            allow_reuse_address = True
            daemon_threads = True
        cls.socks = SocksServer(("127.0.0.1", 0), SocksHandler)
        cls.socks.tunnel_connections = 0
        cls.socks_port = cls.socks.server_address[1]
        cls.socks_thread = threading.Thread(target=cls.socks.serve_forever, daemon=True)
        cls.socks_thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.socks.shutdown()
        cls.socks.server_close()
        cls.socks_thread.join(timeout=2)
        cls.https.shutdown()
        cls.https.server_close()
        cls.https_thread.join(timeout=2)
        cls.temporary.cleanup()

    def setUp(self):
        super().setUp()
        self.https.extra_bytes = 0
        self.https.slow = False
        self.https.uploaded_bytes = 0
        self.real_curl = engine.Curl

    def speed(self, download, upload):
        with mock.patch.object(engine, "Curl", side_effect=lambda: self.real_curl(cacert=str(self.cert))), mock.patch.object(engine, "SPEEDTEST_DEFAULT_HOST", f"127.0.0.1:{self.https_port}"), mock.patch.object(engine, "_find_free_local_port", return_value=self.socks_port), mock.patch.object(engine, "run_xray_process", return_value=(None, None, True, None)), mock.patch.object(engine, "stop_xray_process"), mock.patch.object(engine.os.path, "isfile", return_value=True):
            return engine.high_accuracy_speed_test("/fixture/xray", PARAMS, "127.0.0.1", 443, "example.com", download, upload, 3000)

    def test_actual_browser_default_alias_handshake(self):
        result = engine.browser_tls_ping("127.0.0.1", self.https_port, "example.com", 1, 3000, "chrome")
        self.assertEqual(result["success"], 1, result)
        self.assertNotEqual(result["fingerprint_effective"], "chrome")

    def test_actual_unsupported_fingerprint_fails_before_handshake(self):
        with mock.patch.object(engine, "_normalize_browser_type", return_value="unsupported-fixture-browser"):
            result = engine.browser_tls_ping("127.0.0.1", self.https_port, "example.com", 1, 3000, "chrome")
        self.assertEqual(result["success"], 0)
        self.assertIn("FINGERPRINT_ERROR", result["attempt_diagnostics"][0]["error"])

    def test_actual_reality_probe_forces_socks_with_no_proxy_star(self):
        before = self.socks.tunnel_connections
        with mock.patch.object(engine, "Curl", side_effect=lambda: self.real_curl(cacert=str(self.cert))), mock.patch.object(engine, "REALITY_PROBE_URL", f"https://127.0.0.1:{self.https_port}/generate_204"), mock.patch.dict(os.environ, {"NO_PROXY": "*", "no_proxy": "*"}):
            ok, error = engine.reality_probe_through_tunnel(self.socks_port, 3000)
        self.assertTrue(ok, error)
        self.assertEqual(self.socks.tunnel_connections - before, 1)

    def test_actual_download_upload_forces_socks_and_counts_bytes(self):
        before = self.socks.tunnel_connections
        with mock.patch.dict(os.environ, {"NO_PROXY": "*", "no_proxy": "*"}):
            result = self.speed(1 / 16, 1 / 16)
        self.assertTrue(result["download_ok"], result)
        self.assertTrue(result["upload_ok"], result)
        self.assertEqual(result["download_bytes"], 65536)
        self.assertEqual(result["upload_bytes"], 65536)
        self.assertEqual(self.https.uploaded_bytes, 65536)
        self.assertEqual(self.socks.tunnel_connections - before, 2)

    def test_actual_cancel_aborts_download(self):
        event = threading.Event()
        engine.set_cancel_event(event)
        self.https.slow = True
        timer = threading.Timer(.15, event.set)
        timer.start()
        started = time.monotonic()
        try:
            with self.assertRaises(engine.ScanCancelled):
                self.speed(1, 0)
        finally:
            timer.join()
        self.assertLess(time.monotonic() - started, 1.5)

    def test_actual_excess_download_body_aborts(self):
        self.https.extra_bytes = 65536
        result = self.speed(1 / 16, 0)
        self.assertFalse(result["download_ok"], result)
        self.assertIn("failed", result["error"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
