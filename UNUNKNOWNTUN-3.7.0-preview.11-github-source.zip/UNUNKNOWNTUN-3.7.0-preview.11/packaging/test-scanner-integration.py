#!/usr/bin/env python3
"""Offline packaging/routing/security checks. No public scans or host changes."""
import ast
import contextlib
import importlib.util
import io
import os
from pathlib import Path
import re
import shlex
import stat
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
SOURCE = (ROOT / "packaging/full-installer.template.sh").read_text()
MANAGER = SOURCE.split("<<'CTL'\n", 1)[1].split("\nCTL\n", 1)[0]
DEFINITIONS, DISPATCH = MANAGER.split('\ncommand_name="${1:-help}"', 1)
DISPATCH = '\ncommand_name="${1:-help}"' + DISPATCH
LAUNCH = SOURCE.split("<<'SCANNER_LAUNCH'\n", 1)[1].split("\nSCANNER_LAUNCH\n", 1)[0]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class ScannerIntegrationTests(unittest.TestCase):
    def test_renderer_embeds_every_exact_helper_and_shell_compiles(self):
        tree = ast.parse((ROOT / "packaging/render-complete.py").read_text())
        entries = next(ast.literal_eval(node.value) for node in tree.body
                       if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "helpers" for t in node.targets))
        self.assertTrue({"scanner-console.py", "scanner-engine.py"} <= {entry[0] for entry in entries})
        rendered = SOURCE
        for name, marker, terminator in entries:
            helper = (ROOT / "packaging" / name).read_text().rstrip()
            self.assertEqual(SOURCE.count(marker), 1, name)
            self.assertNotIn(terminator, helper.splitlines(), name)
            compile(helper, name, "exec")
            rendered = rendered.replace(marker, helper)
            embedded = rendered.split("<<'" + terminator + "'\n", 1)[1].split("\n" + terminator + "\n", 1)[0]
            self.assertEqual(embedded, helper, name)
        self.assertNotIn("_SOURCE__", rendered)
        with tempfile.NamedTemporaryFile(mode="w", suffix=".sh") as stream:
            stream.write(rendered)
            stream.flush()
            reply = subprocess.run(["bash", "-n", stream.name], capture_output=True, text=True, timeout=10)
        self.assertEqual(reply.returncode, 0, reply.stderr)

    def test_command_forwards_arguments_without_tunnel_selection_or_mutations(self):
        script = DEFINITIONS + '''
need_root() { :; }
select_id() { echo forbidden-tunnel-selection >&2; exit 91; }
manager_lock() { echo forbidden-lock >&2; exit 92; }
systemctl() { echo forbidden-service >&2; exit 93; }
function /usr/bin/python3() { printf '<%s>\\n' "$@"; local line; read -r line <&3; printf 'stdin=%s\\n' "$line"; }
INSTALL_DIR=/isolated/ununknowntun
''' + DISPATCH
        arguments = ["scanner", "ip", "--targets", "192.0.2.0/28", "literal space;$(false)"]
        reply = subprocess.run(["bash", "-c", script, "scanner-test", *arguments],
                               input="wizard input\n", capture_output=True, text=True, timeout=5)
        self.assertEqual(reply.returncode, 0, reply.stderr)
        self.assertEqual(reply.stdout.splitlines(), ["<-I>", "<->", "</isolated/ununknowntun/share>",
                         "</isolated/ununknowntun/scanner-venv>", *["<" + a + ">" for a in arguments[1:]], "stdin=wizard input"])
        self.assertEqual(reply.stderr, "")

    def test_no_arguments_opens_scanner_not_doctor_or_cdn(self):
        branch = DISPATCH.split("    scanner)\n", 1)[1].split("        ;;", 1)[0]
        for forbidden in ("select_id", "systemctl", "cdn-control", "tunnel-doctor", "manager_lock", "install_"):
            self.assertNotIn(forbidden, branch)
        self.assertIn('"$@" 3<&0', branch)
        self.assertIn("os.dup2(3, 0)", LAUNCH)
        self.assertIn("os.close(3)", LAUNCH)

    def test_installer_and_manager_use_identical_validated_launchers(self):
        menu_launch = SOURCE.split("<<'SCANNER_MENU_LAUNCH'\n", 1)[1].split("\nSCANNER_MENU_LAUNCH\n", 1)[0]
        self.assertEqual(menu_launch, LAUNCH)
        compile(LAUNCH, "scanner-launch", "exec")
        standalone = SOURCE.split("run_full_scanner() (", 1)[1].split("\n)\n", 1)[0]
        for forbidden in ("install_manager", "install_binary", "systemctl", "prepare_tunnel_context", "apt-get"):
            self.assertNotIn(forbidden, standalone)
        self.assertIn("mktemp -d /run/ununknowntun-scanner.XXXXXXXX", standalone)
        self.assertIn("trap 'rm -rf --", standalone)

    def test_menu_entries_are_additive_and_bounded(self):
        validators = "\n".join(line for line in SOURCE.splitlines() if line.startswith(("valid_main_choice()", "valid_manage_choice()")))
        reply = subprocess.run(["bash", "-c", validators + '''
valid_main_choice 7 && valid_main_choice 8 && valid_main_choice 9 && ! valid_main_choice 10 && valid_manage_choice 23 && valid_manage_choice 24 && ! valid_manage_choice 25
'''], capture_output=True, text=True, timeout=5)
        self.assertEqual(reply.returncode, 0, reply.stderr)
        for entry in ('23) "$CTL_PATH" scanner', '24) "$CTL_PATH" cdn-rounds', '22) "$CTL_PATH" cdn-preview',
                      '18) "$CTL_PATH" doctor', '7) run_full_scanner',
                      'scanner) shift; run_full_scanner "$@"'):
            self.assertIn(entry, SOURCE)
        self.assertIn("Full SIKDPI scanner", MANAGER)
        self.assertIn('if [[ "$choice" != 23 ]]; then migrate_legacy_install_if_needed; fi', SOURCE)

    def test_guided_dispatch_selects_tunnel_without_holding_global_edit_lock(self):
        script = DEFINITIONS + '''
need_root() { :; }
select_id() { printf '%s\\n' sample; }
manager_lock() { echo forbidden-early-global-lock >&2; exit 92; }
python3() { printf '<%s>\\n' "$@"; }
INSTALL_DIR=/isolated/ununknowntun
TUNNELS_DIR=/etc/ununknowntun/tunnels
''' + DISPATCH
        result = subprocess.run(["bash", "-c", script, "rounds-dispatch", "cdn-rounds", "sample"], capture_output=True, text=True, timeout=5)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.splitlines(), ["</isolated/ununknowntun/share/cdn-control.py>", "<rounds>", "<--config-dir>", "</etc/ununknowntun/tunnels/sample>"])

    def test_release_pipeline_includes_all_scanner_tests(self):
        pipeline = (ROOT / "packaging/build-complete.sh").read_text()
        for name in ("engine", "console", "integration", "rounds"):
            self.assertIn('packaging/test-scanner-' + name + '.py', pipeline)

    def test_english_guide_has_parseable_command_examples(self):
        english = (ROOT / "docs/SCANNER.md").read_text()
        blocks = lambda text: re.findall(r"```bash\n(.*?)\n```", text, re.DOTALL)
        self.assertIsNone(re.search(r"[\u0600-\u06ff]", english))
        self.assertFalse((ROOT / "docs/SCANNER.fa.md").exists())
        console = load("scanner_docs_console", ROOT / "packaging/scanner-console.py")
        parser = console.build_parser()
        with contextlib.redirect_stdout(io.StringIO()):
            for block in blocks(english):
                for line in block.splitlines():
                    argv = shlex.split(line)
                    if argv[:3] == ["sudo", "ununknowntunctl", "scanner"]:
                        try:
                            parser.parse_args(argv[3:])
                        except SystemExit as exc:
                            self.assertEqual(exc.code, 0, line)

    def test_guides_explain_security_evidence_and_private_runtime(self):
        for name in ("SCANNER.md",):
            text = (ROOT / "docs" / name).read_text()
            for literal in ("--authorized", "--allow-private", "--traffic-consent", "--secret-prompt", "0600", "0700",
                            "packet_loss", "avg_ping", "Ctrl+C", "--rows 1,3-5", "cancelled=true",
                            "/opt/ununknowntun/scanner-venv", "doctor", "cdn-preview", "cdn-scan", "4096", "REALITY"):
                self.assertIn(literal, text)

    def fixture(self):
        module = load("scanner_install_fixture", ROOT / "packaging/test-full-installer.py")
        fixture = module.InstallerTests(methodName="runTest")
        fixture.setUp()
        self.addCleanup(fixture.tearDown)
        return fixture

    def test_installed_helpers_match_source_modes_and_replace_links_safely(self):
        fixture = self.fixture()
        share = fixture.root / "install/share"
        share.mkdir(parents=True)
        victim = fixture.root / "unchanged.txt"
        victim.write_text("must remain unchanged")
        (share / "scanner-console.py").symlink_to(victim)
        fixture.run_shell("install_scanner_helpers\n")
        for name, mode in (("scanner-console.py", 0o755), ("scanner-engine.py", 0o700)):
            path = share / name
            self.assertFalse(path.is_symlink())
            self.assertEqual(path.read_text().rstrip(), (ROOT / "packaging" / name).read_text().rstrip())
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), mode)
        self.assertEqual(victim.read_text(), "must remain unchanged")
        self.assertEqual(list(share.glob(".scanner-stage.*")), [])
        self.assertEqual(fixture.log.read_text(), "")

    def test_upgrade_refreshes_helpers_and_preserves_customer_ledger(self):
        module = load("scanner_upgrade_fixture", ROOT / "packaging/test-editor-integration.py")
        helper = module.EditorIntegrationTests(methodName="runTest")
        fixture, setup = helper.upgrade_fixture()
        self.addCleanup(helper.doCleanups)
        before = (fixture.state / "access-state.json").read_bytes()
        fixture.shell(setup + "upgrade_existing\n", stdin="y\n")
        for name in ("scanner-console.py", "scanner-engine.py"):
            self.assertEqual((fixture.root / "install/share" / name).read_text().rstrip(),
                             (ROOT / "packaging" / name).read_text().rstrip())
        self.assertIn("    scanner)", (fixture.root / "bin/ununknowntunctl").read_text())
        self.assertEqual((fixture.state / "access-state.json").read_bytes(), before)
        log = fixture.fixture.log.read_text()
        self.assertNotIn("systemctl restart", log)
        self.assertNotIn("initialize quota=", log)

    def test_failed_upgrade_restores_previous_scanner_helpers(self):
        module = load("scanner_rollback_fixture", ROOT / "packaging/test-editor-integration.py")
        helper = module.EditorIntegrationTests(methodName="runTest")
        fixture, setup = helper.upgrade_fixture()
        self.addCleanup(helper.doCleanups)
        share = fixture.root / "install/share"
        share.mkdir(parents=True)
        old_console = share / "scanner-console.py"
        old_console.write_text("# previous scanner\n")
        before = (fixture.state / "access-state.json").read_bytes()
        fixture.shell(setup + "patch_upgrade_configuration() { return 1; }\nupgrade_existing\n", expected=1, stdin="y\n")
        self.assertEqual(old_console.read_text(), "# previous scanner\n")
        self.assertFalse((share / "scanner-engine.py").exists())
        self.assertEqual((fixture.state / "access-state.json").read_bytes(), before)

    def test_ui_opens_scanner_without_a_selected_tunnel(self):
        ui = load("scanner_ui_integration", ROOT / "ui/ununknowntun-ui.py")
        backend = mock.Mock(spec=ui.Backend)
        backend.scanner.return_value = 0
        backend.inventory.return_value = []
        backend.notice = ""
        app = ui.App(color=False, backend=backend, input_fn=lambda _: "")
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertTrue(app.dispatch("k"))
        backend.scanner.assert_called_once_with()
        backend.action.assert_not_called()
        backend.doctor.assert_not_called()
        demo = ui.App(demo=True, backend=backend)
        with self.assertRaises(ui.UIError):
            demo.dispatch("k")

    def test_ui_validates_capability_and_helpers_then_inherits_terminal(self):
        ui = load("scanner_ui_backend", ROOT / "ui/ununknowntun-ui.py")
        replies = [SimpleNamespace(returncode=0, stdout="  scanner       Full SIKDPI scanner\n"),
                   SimpleNamespace(returncode=0)]
        with mock.patch.object(ui, "trusted") as trusted, mock.patch.object(ui.subprocess, "run", side_effect=replies) as run:
            self.assertEqual(ui.Backend().scanner(), 0)
            self.assertEqual([call.args[0] for call in trusted.call_args_list],
                             [ui.MANAGER, ui.SCANNER, ui.SCANNER.with_name("scanner-engine.py")])
            self.assertEqual(run.call_args.args[0], [str(ui.MANAGER), "scanner"])
            self.assertNotIn("capture_output", run.call_args.kwargs)
            self.assertFalse(run.call_args.kwargs.get("shell", False))
        with mock.patch.object(ui, "trusted"), mock.patch.object(ui.subprocess, "run", return_value=SimpleNamespace(returncode=0, stdout="  scan Old diagnostics\n")) as run:
            with self.assertRaises(ui.UIError):
                ui.Backend().scanner()
            self.assertEqual(run.call_count, 1)


class LaunchTrustTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix="ununknowntun-scanner-launch-")
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.share = self.root / "share"
        self.make_share()
        self.venv = self.root / "scanner-venv"
        self.bad_owner = self.bad_mode = None
        self.real_lstat = Path.lstat

    def make_share(self):
        # Model installed permissions explicitly, independent of the build
        # user's umask (Ubuntu lab users may default to group-writable 0002).
        self.share.mkdir(mode=0o755)
        self.share.chmod(0o755)
        for name in ("scanner-console.py", "scanner-engine.py"):
            helper = self.share / name
            helper.write_text("# never executed\n")
            helper.chmod(0o755 if name == "scanner-console.py" else 0o700)

    def trusted_fixture_stat(self, path):
        info = self.real_lstat(path)
        mode = info.st_mode
        # Temporary fixture ancestry is simulated as production root ownership.
        # The launcher itself, not the host filesystem, is under test.
        if path in self.root.parents:
            mode = stat.S_IFDIR | 0o755
        if path == self.bad_mode:
            mode |= 0o022
        return SimpleNamespace(st_uid=1000 if path == self.bad_owner else 0,
                               st_mode=mode, st_size=info.st_size)

    def execute(self):
        with mock.patch.object(Path, "lstat", lambda path: self.trusted_fixture_stat(path)), \
                mock.patch.object(sys, "argv", ["launcher", str(self.share), str(self.venv), "results"]), \
                mock.patch.object(os, "execve") as execute, mock.patch.object(os, "dup2") as dup, \
                mock.patch.object(os, "close"), mock.patch.dict(os.environ, {"PYTHONPATH": "/untrusted", "LD_PRELOAD": "bad"}):
            exec(compile(LAUNCH, "scanner-launch", "exec"), {"__name__": "__main__"})
            dup.assert_called_once_with(3, 0)
            return execute.call_args

    def make_venv(self):
        (self.venv / "bin").mkdir(parents=True)
        (self.venv / "pyvenv.cfg").write_text("include-system-site-packages = false\n")
        (self.venv / "bin/python3").symlink_to("/usr/bin/python3")
        (self.venv / "lib").mkdir()
        (self.venv / "lib/dependency.py").write_text("# dependency fixture\n")
        for directory in (self.venv, self.venv / "bin", self.venv / "lib"):
            directory.chmod(0o755)
        for path in (self.venv / "pyvenv.cfg", self.venv / "lib/dependency.py"):
            path.chmod(0o644)

    def test_trusted_fixtures_work_with_group_writable_host_umask(self):
        previous = os.umask(0o002)
        try:
            self.share = self.root / "group-umask-share"
            self.make_share()
            self.make_venv()
        finally:
            os.umask(previous)
        self.assertEqual(self.execute().args[0], str(self.venv / "bin/python3"))

    def test_system_runtime_is_isolated_and_cleans_environment(self):
        call = self.execute()
        self.assertEqual(call.args[1][1:], ["-I", str(self.share / "scanner-console.py"), "results"])
        self.assertNotIn("PYTHONPATH", call.args[2])
        self.assertNotIn("LD_PRELOAD", call.args[2])

    def test_trusted_private_venv_is_automatically_selected(self):
        self.make_venv()
        self.assertEqual(self.execute().args[0], str(self.venv / "bin/python3"))

    def test_untrusted_helper_owner_is_rejected(self):
        self.bad_owner = self.share / "scanner-engine.py"
        with self.assertRaises(SystemExit):
            self.execute()

    def test_writable_dependency_is_rejected_before_interpreter_starts(self):
        self.make_venv()
        self.bad_mode = self.venv / "lib/dependency.py"
        with self.assertRaises(SystemExit):
            self.execute()

    def test_helper_symlink_is_rejected(self):
        helper = self.share / "scanner-console.py"
        helper.unlink()
        helper.symlink_to(self.share / "scanner-engine.py")
        with self.assertRaises(SystemExit):
            self.execute()

    def test_interpreter_symlink_to_untrusted_target_is_rejected(self):
        self.make_venv()
        target = self.root / "malicious-python"
        target.write_text("never execute")
        candidate = self.venv / "bin/python3"
        candidate.unlink()
        candidate.symlink_to(target)
        self.bad_owner = target.resolve()
        with self.assertRaises(SystemExit):
            self.execute()

    def test_virtualenv_directory_symlink_is_rejected(self):
        target = self.root / "untrusted-venv"
        target.mkdir()
        self.venv.symlink_to(target, target_is_directory=True)
        with self.assertRaises(SystemExit):
            self.execute()


if __name__ == "__main__":
    unittest.main(verbosity=2)
