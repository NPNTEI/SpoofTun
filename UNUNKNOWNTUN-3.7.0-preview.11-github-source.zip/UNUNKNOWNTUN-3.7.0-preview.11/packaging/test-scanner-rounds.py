#!/usr/bin/env python3
"""Guided scanner regressions. Fake probes or loopback only; never scan WAN IPs."""
import contextlib
import importlib.util
import io
import json
import re
import socket
import stat
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch

SOURCE = Path(__file__).with_name("scanner-console.py")
spec = importlib.util.spec_from_file_location("scanner_round_console", SOURCE)
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)


class RoundTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name).resolve()
        self.reports = self.root / "reports"
        self.e = c.engine()
        self.out, self.err = io.StringIO(), io.StringIO()

    def tearDown(self):
        self.e.set_cancel_event(None)
        self.temp.cleanup()

    def cli(self, extra=(), answers=("2", "1", "100", "no", "")):
        argv = ["rounds", "--range", "8.8.8.1-8.8.8.3", "--sample", "3",
                "--authorized", "--report-dir", str(self.reports), *extra]
        with patch("builtins.input", side_effect=answers), contextlib.redirect_stdout(self.out), contextlib.redirect_stderr(self.err):
            return c.main(argv)

    @staticmethod
    def good(ip, port, count, timeout):
        return {"success": 1, "avg_ping": 10.0, "latencies": [10.04]}

    def session(self):
        return json.loads(next(self.reports.glob("rounds-*.json")).read_text())

    def round_reports(self):
        return [c.load_report(path) for path in sorted(self.reports.glob("*.json")) if not path.name.startswith("rounds-")]

    def args(self, *extra):
        args = c.build_parser().parse_args(["rounds", "--authorized", *extra])
        args.port, args.round_number = args.port or 443, 1
        return args

    def test_range_sampling_is_distinct_bounded_and_spread(self):
        ips = c.sample_ipv4_range("8.8.8.0/24", 7)
        self.assertEqual(7, len(set(ips)))
        self.assertEqual("8.8.8.1", ips[0])
        self.assertEqual("8.8.8.254", ips[-1])
        self.assertEqual(["8.8.8.0", "8.8.8.1"], c.sample_ipv4_range("8.8.8.0/31", 2))
        self.assertEqual(["8.8.8.8"], c.sample_ipv4_range("8.8.8.8/32", 1))
        self.assertEqual(["8.8.8.2", "8.8.8.5", "8.8.8.9"], c.sample_ipv4_range("8.8.8.2-8.8.8.9", 3))
        # A /8 is represented arithmetically instead of building millions of hosts.
        self.assertEqual(4096, len(c.sample_ipv4_range("8.0.0.0/8", 4096)))

    def test_invalid_ranges_sample_counts_and_metadata_fail_closed(self):
        for value in ("8.8.8.9-8.8.8.1", "::1", "example.com", "8.8.8.0/33", "8.8.8.8\n8.8.4.4"):
            with self.assertRaises(ValueError): c.sample_ipv4_range(value, 1)
        for count in (0, -1, 3, True, 4097):
            with self.assertRaises(ValueError): c.sample_ipv4_range("8.8.8.0/31", count)
        with self.assertRaises(ValueError): c.sample_ipv4_range("127.0.0.1", 1)
        self.assertEqual(["127.0.0.1"], c.sample_ipv4_range("127.0.0.1", 1, True))
        with self.assertRaises(ValueError): c.sample_ipv4_range("169.254.169.254", 1, True)

    def test_port_is_inherited_and_selection_is_private(self):
        selected = self.root / "selected"
        with patch.object(self.e, "tcp_handshake_ping", side_effect=self.good) as probe:
            self.assertEqual(0, self.cli(["--port", "8443", "--selected-output", str(selected)]))
        self.assertEqual({8443}, {call.args[1] for call in probe.call_args_list})
        self.assertEqual("8.8.8.1\n", selected.read_text())
        self.assertEqual(0o600, stat.S_IMODE(selected.stat().st_mode))
        self.assertEqual(0o700, stat.S_IMODE(self.reports.stat().st_mode))
        session = self.session()
        self.assertEqual(8443, session["port"])
        self.assertFalse(session["tunnel_authenticated"])
        self.assertFalse(session["automatic_policy_changed"])
        self.assertFalse(session["configuration_changed"])
        self.assertIn("TCP probe 1/2", self.err.getvalue())
        self.assertIn("[GOOD] 8.8.8.1:8443", self.err.getvalue())

    def test_standalone_port_defaults_to_443(self):
        with patch.object(self.e, "tcp_handshake_ping", side_effect=self.good) as probe:
            self.assertEqual(0, self.cli())
        self.assertEqual({443}, {call.args[1] for call in probe.call_args_list})
        self.assertIn("standalone default 443", self.err.getvalue())

    def test_unknown_port_rejected_before_network(self):
        for port in ("0", "65536", "unknown"):
            with contextlib.redirect_stderr(self.err), patch.object(self.e, "tcp_handshake_ping", side_effect=AssertionError("network")):
                with self.assertRaises(SystemExit): c.build_parser().parse_args(["rounds", "--port", port])

    def test_threshold_uses_unrounded_samples_and_counts_timeout(self):
        args = self.args("--count", "3", "--timeout", "100")
        results = [{"success": 1, "avg_ping": 100.0, "latencies": [100.04]},
                   {"success": 1, "avg_ping": 100.0, "latencies": [100.0]},
                   {"success": 1, "avg_ping": 25.0, "latencies": [25.0]}]
        with patch.object(self.e, "tcp_handshake_ping", side_effect=results):
            row = c.round_worker(args, "8.8.8.8", lambda text: None)
        self.assertEqual((3, 2, 33.3), (row["count"], row["success"], row["packet_loss"]))
        self.assertEqual("TIMEOUT", row["attempt_diagnostics"][0]["error"])
        self.assertEqual([100.0, 25.0], row["latencies"])
        self.assertEqual(62.5, row["avg_ping"])

    def test_nonfinite_negative_and_missing_measurements_fail(self):
        args = self.args("--count", "4", "--timeout", "100")
        results = [{"success": 1, "avg_ping": x} for x in (float("nan"), float("inf"), -1, None)]
        with patch.object(self.e, "tcp_handshake_ping", side_effect=results):
            row = c.round_worker(args, "8.8.8.8", lambda text: None)
        self.assertEqual(0, row["success"])
        self.assertEqual(100, row["packet_loss"])
        self.assertIsNone(row["avg_ping"])

    def test_failed_probe_does_not_discard_previous_success(self):
        args = self.args("--count", "2")
        with patch.object(self.e, "tcp_handshake_ping", side_effect=[self.good(None, None, None, None), TimeoutError()]):
            row = c.round_worker(args, "8.8.8.8", lambda text: None)
        self.assertEqual((2, 1, 50), (row["count"], row["success"], row["packet_loss"]))
        self.assertEqual("TIMEOUT", row["attempt_diagnostics"][0]["error"])

    def test_loss_then_latency_then_jitter_ranking(self):
        rows = [{"ip": "8.8.8.1", "packet_loss": 25, "avg_ping": 1, "jitter": 0},
                {"ip": "8.8.8.2", "packet_loss": 0, "avg_ping": 90, "jitter": 0},
                {"ip": "8.8.8.3", "packet_loss": 0, "avg_ping": 50, "jitter": 5},
                {"ip": "8.8.8.4", "packet_loss": 0, "avg_ping": 50, "jitter": 1},
                {"ip": "8.8.8.5", "packet_loss": 100, "avg_ping": None, "jitter": None}]
        self.assertEqual(["8.8.8.4", "8.8.8.3", "8.8.8.2", "8.8.8.1", "8.8.8.5"],
                         [row["ip"] for row in sorted(rows, key=c.round_rank)])

    def test_100_rounds_repeat_all_questions_and_only_narrow(self):
        # Actual worker flow with a fake network: first sample three, then two, then one.
        answers = []
        for number in range(1, 101):
            answers += [str(1 + number % 2), "1", str(100 + number)]
            if number < 100:
                answers += ["yes", "2" if number == 1 else "1"]
            else:
                answers += ["no", "8.8.8.1"]
        with patch.object(self.e, "tcp_handshake_ping", side_effect=self.good), patch("builtins.input", side_effect=answers) as prompts, contextlib.redirect_stdout(self.out), contextlib.redirect_stderr(self.err):
            self.assertEqual(0, c.main(["rounds", "--range", "8.8.8.1-8.8.8.3", "--sample", "3", "--authorized", "--report-dir", str(self.reports)]))
        session = self.session()
        self.assertEqual(100, len(session["rounds"]))
        self.assertEqual([3, 2, *([1] * 98)], [r["candidates"] for r in session["rounds"]])
        self.assertEqual([100 + n for n in range(1, 101)], [r["maximum_latency_ms"] for r in session["rounds"]])
        prompt_labels = [call.args[0] for call in prompts.call_args_list]
        self.assertEqual(100, sum(label.startswith("Probes per IP") for label in prompt_labels))
        self.assertEqual(100, sum(label.startswith("Simultaneous workers") for label in prompt_labels))
        self.assertEqual(100, sum(label.startswith("Maximum latency") for label in prompt_labels))
        self.assertEqual(99, sum(label.startswith("How many top IPs") for label in prompt_labels))
        previous = None
        for item in session["rounds"]:
            report = c.load_report(self.reports / item["report"])
            candidates = {row["ip"] for row in report["rows"]}
            if previous is not None: self.assertTrue(candidates <= previous)
            previous = candidates

    def test_cancel_preserves_partial_and_stops_scheduling(self):
        calls = []
        def probe(ip, port, count, timeout):
            calls.append(ip)
            if len(calls) == 2:
                self.e._cancel_event.set()
                raise self.e.ScanCancelled()
            return self.good(ip, port, count, timeout)
        with patch.object(self.e, "tcp_handshake_ping", side_effect=probe):
            self.assertEqual(0, self.cli(answers=["4", "1", "100", "no", "8.8.8.1"]))
        self.assertEqual(["8.8.8.1", "8.8.8.1"], calls)
        report = self.round_reports()[0]
        self.assertTrue(report["cancelled"])
        self.assertEqual(1, len(report["rows"]))
        self.assertTrue(report["rows"][0]["partial"])
        self.assertEqual(1, report["rows"][0]["count"])
        self.assertIsNone(self.e._cancel_event)

    def test_concurrent_cancel_never_starts_more_than_worker_limit(self):
        calls, lock, barrier = [], threading.Lock(), threading.Barrier(3)
        def probe(ip, port, count, timeout):
            with lock: calls.append(ip)
            barrier.wait(timeout=2)
            self.e._cancel_event.set()
            raise self.e.ScanCancelled()
        args = self.args("--workers", "3", "--count", "1")
        with patch.object(self.e, "tcp_handshake_ping", side_effect=probe), contextlib.redirect_stderr(self.err):
            rows, cancelled = c.scan_round(args, [f"8.8.8.{n}" for n in range(1, 21)])
        self.assertTrue(cancelled)
        self.assertEqual(3, len(calls))
        self.assertEqual([], rows)

    def test_cancel_without_success_publishes_no_selection(self):
        selected = self.root / "selected"
        def probe(*args):
            self.e._cancel_event.set()
            raise self.e.ScanCancelled()
        with patch.object(self.e, "tcp_handshake_ping", side_effect=probe):
            self.assertEqual(130, self.cli(["--selected-output", str(selected)], answers=["2", "1", "100"]))
        self.assertFalse(selected.exists())
        self.assertIsNone(self.session()["selected_ip"])

    def test_selection_rejects_unknown_and_failed_addresses(self):
        rows = [{"ip": "8.8.8.1", "count": 2, "success": 2}, {"ip": "8.8.8.2", "count": 2, "success": 0}]
        with patch("builtins.input", side_effect=["8.8.4.4", "8.8.8.2", "not-an-ip", "8.8.8.1"]) as prompt, contextlib.redirect_stderr(self.err):
            self.assertEqual("8.8.8.1", c.choose_round_ip(rows))
        self.assertEqual(4, prompt.call_count)

    def test_selected_output_is_never_overwritten_or_followed(self):
        selected = self.root / "selected"
        selected.write_text("previous\n")
        with patch.object(self.e, "tcp_handshake_ping", side_effect=AssertionError("network")):
            self.assertEqual(1, self.cli(["--selected-output", str(selected)], answers=[]))
        self.assertEqual("previous\n", selected.read_text())
        selected.unlink()
        selected.symlink_to(self.root / "missing")
        with patch.object(self.e, "tcp_handshake_ping", side_effect=AssertionError("network")):
            self.assertEqual(1, self.cli(["--selected-output", str(selected)], answers=[]))
        self.assertFalse((self.root / "missing").exists())

    def test_full_round_details_exported_in_every_format(self):
        with patch.object(self.e, "tcp_handshake_ping", side_effect=self.good):
            self.assertEqual(0, self.cli())
        session = self.session()
        report_path = self.reports / session["rounds"][0]["report"]
        for fmt in ("json", "csv", "txt"):
            output = self.root / ("export." + fmt)
            with contextlib.redirect_stdout(self.out), contextlib.redirect_stderr(self.err):
                self.assertEqual(0, c.main(["export", str(report_path), "--format", fmt, "--output", str(output)]))
            content = output.read_text()
            for field in ("round", "planned_count", "max_latency_ms", "partial", "latencies"):
                self.assertIn(field, content)
            self.assertIn("8.8.8.3", content)

    def test_real_loopback_probe(self):
        server = socket.socket()
        server.bind(("127.0.0.1", 0))
        server.listen(8)
        server.settimeout(.1)
        port, stopped = server.getsockname()[1], threading.Event()
        def accept():
            while not stopped.is_set():
                try:
                    connection, _ = server.accept()
                    connection.close()
                except socket.timeout:
                    pass
        thread = threading.Thread(target=accept)
        thread.start()
        try:
            self.assertEqual(0, self.cli(["--range", "127.0.0.1", "--sample", "1", "--allow-private", "--port", str(port)], answers=["2", "1", "1000", "no", "127.0.0.1"]))
            report = self.round_reports()[0]
            self.assertEqual(2, report["rows"][0]["success"])
        finally:
            stopped.set()
            thread.join(timeout=2)
            server.close()

    def test_no_permission_no_probe(self):
        with patch.object(c.sys.stdin, "isatty", return_value=False), patch.object(self.e, "tcp_handshake_ping", side_effect=AssertionError("network")), contextlib.redirect_stderr(self.err):
            self.assertEqual(1, c.main(["rounds", "--range", "8.8.8.8", "--sample", "1"]))

    def test_option_one_enters_guided_rounds(self):
        with patch.object(c.sys.stdin, "isatty", return_value=True), patch("builtins.input", side_effect=["1", "0"]), patch.object(c, "command_rounds", return_value=0) as rounds, contextlib.redirect_stdout(self.out):
            self.assertEqual(0, c.main([]))
        self.assertEqual(1, rounds.call_count)
        self.assertEqual("rounds", rounds.call_args.args[0].command)

    def test_scanner_source_has_no_persian_ui(self):
        for path in (SOURCE, SOURCE.with_name("scanner-engine.py")):
            self.assertIsNone(re.search(r"[\u0600-\u06ff]", path.read_text()))


if __name__ == "__main__":
    unittest.main(verbosity=2)
