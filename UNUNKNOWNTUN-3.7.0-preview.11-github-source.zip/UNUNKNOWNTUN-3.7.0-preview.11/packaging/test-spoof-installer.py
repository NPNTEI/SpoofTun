#!/usr/bin/env python3
"""Offline installer-to-GRE-wizard integration; never install or activate anything.

Synthetic ELF headers exercise the renderer with Go metadata/native execution
mocked. The embedded Python helper and local OpenSSL generation are real; host
mutation/network commands are forbidden and existing fixture files are checked.
"""
import contextlib
import importlib.util
import io
import os
from pathlib import Path
import runpy
import shlex
import shutil
import struct
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch


PACKAGING = Path(__file__).resolve().parent


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, PACKAGING / filename)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


installer = load("spoof_installer_fixture", "test-full-installer.py")
pair = load("spoof_installer_pair", "spoof-pair.py")


@unittest.skipUnless(shutil.which("openssl"), "local OpenSSL required for offline pair generation")
class SpoofInstallerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="gdt-spoof-installer-", dir=str(Path(tempfile.gettempdir()).resolve()))
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.definitions = self.root / "definitions.sh"
        self.definitions.write_text(installer.DEFINITIONS)
        self.stage = self.root / "stages"
        self.stage.mkdir(mode=0o700)
        self.output = self.root / "generated-pair"
        self.guard = self.root / "forbidden.log"
        self.calls = self.root / "helper.log"
        self.stages = self.root / "stages.log"
        for path in (self.guard, self.calls, self.stages):
            path.touch()
        self.existing = self.root / "existing-deployment"
        self.existing.mkdir(mode=0o700)
        self.before = {}
        for name, content in (("token", b"existing-private-token\n"), ("run.sh", b"existing-launcher\n"),
                              ("ununknowntun.service", b"existing-unit\n"), ("nginx.conf", b"existing-site\n")):
            path = self.existing / name
            path.write_bytes(content)
            path.chmod(0o600)
            self.before[name] = (content, path.stat().st_mode)

    def wizard_answers(self, authorization="AUTHORIZED"):
        return "\n".join([authorization, "installer-pair", "/opt/ununknowntun/3.7.0-preview.5/ununknowntun", "",
                          "eth0", "192.0.2.10", "198.51.100.10", "10.77.0.1",
                          "ens3", "192.0.2.20", "198.51.100.20", "10.77.0.2",
                          "127.0.0.1:12055", "127.0.0.1:18082", "18443", "1280", "on", ""])

    def shell(self, body, stdin="", expected=0):
        quote = shlex.quote
        guards = "\n".join(name + '() { deny ' + name + ' "$@"; }' for name in (
            "systemctl", "nginx", "ufw", "apt-get", "apt", "yum", "dnf", "useradd", "chown", "sysctl", "ip",
            "curl", "wget", "install", "require_root", "acquire_install_lock", "detect_os", "install_binary",
            "install_service_unit", "install_foreign", "install_origin", "upgrade_existing"))
        preamble = f'''
source {quote(str(self.definitions))}
FIXTURE_ROOT={quote(str(self.root))}
STAGE_ROOT={quote(str(self.stage))}
STAGE_LOG={quote(str(self.stages))}
HELPER_LOG={quote(str(self.calls))}
GUARD_LOG={quote(str(self.guard))}
EXPECTED_HELPER={quote(str(PACKAGING / "spoof-pair.py"))}
REAL_PYTHON={quote(sys.executable)}
OUTPUT={quote(str(self.output))}
CONFIG_DIR={quote(str(self.existing))}
BASE_CONFIG_DIR="$CONFIG_DIR"
TUNNELS_DIR="$CONFIG_DIR/tunnels"
INSTALL_DIR="$FIXTURE_ROOT/unused-install"
BIN_PATH="$FIXTURE_ROOT/never-run-ununknowntun"
UNIT_PATH="$CONFIG_DIR/ununknowntun.service"
LOCK_PATH="$FIXTURE_ROOT/unused.lock"
deny() {{ printf '%s\\n' "$*" >> "$GUARD_LOG"; return 97; }}
{guards}
mktemp() {{
    [[ "$#" == 1 && "$1" == -d ]] || {{ deny unexpected-mktemp; return 97; }}
    local created
    created="$(command mktemp -d "$STAGE_ROOT/helper.XXXXXXXX")"
    printf '%s\\n' "$created" >> "$STAGE_LOG"
    printf '%s\\n' "$created"
}}
python3() {{
    [[ "$#" == 4 && "$1" == -I && "$2" == "$STAGE_ROOT"/helper.*/spoof-pair.py && "$3" == --output ]] || {{ deny unexpected-python; return 97; }}
    cmp -s "$2" "$EXPECTED_HELPER" || {{ deny wrong-embedded-helper; return 97; }}
    printf 'exact embedded helper\\n' >> "$HELPER_LOG"
    command "$REAL_PYTHON" "$@"
}}
'''
        result = subprocess.run(["bash", "-c", preamble + body], input=stdin, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30)
        self.assertEqual(result.returncode, expected, result.stdout + result.stderr)
        self.assertEqual(self.guard.read_text(), "", "Forbidden host/network operation attempted")
        self.assertEqual(set(path.name for path in self.existing.iterdir()), set(self.before))
        for name, (data, mode) in self.before.items():
            self.assertEqual((self.existing / name).read_bytes(), data)
            self.assertEqual((self.existing / name).stat().st_mode, mode)
        self.assertFalse((self.root / "unused-install").exists())
        self.assertFalse((self.root / "unused.lock").exists())
        self.assertEqual(list(self.stage.iterdir()), [], "Extracted helper directory was not cleaned: " + result.stderr)
        for created in self.stages.read_text().splitlines():
            self.assertFalse(Path(created).exists())
        return result

    def assert_generated_pair(self, result):
        spec = pair.check_pair(str(self.output))
        self.assertEqual(spec["pair_id"], "installer-pair")
        self.assertEqual(spec["origin"]["source_ip"], "198.51.100.10")
        self.assertEqual(spec["egress"]["source_ip"], "198.51.100.20")
        self.assertEqual(self.calls.read_text(), "exact embedded helper\n")
        self.assertEqual(len(self.stages.read_text().splitlines()), 1)
        self.assertIn("PRIVATE PAIR PREPARED", result.stdout)
        self.assertIn("No network test was performed", result.stdout)
        self.assertNotIn((self.output / "origin/token").read_text().strip(), result.stdout + result.stderr)
        self.assertFalse((self.output / "origin/server.key").exists())
        self.assertTrue((self.output / "egress/server.key").is_file())
        for role in ("origin", "egress"):
            self.assertTrue((self.output / role / "run.sh").is_file())
            self.assertTrue((self.output / role / "check.sh").is_file())
            self.assertTrue((self.output / role / "ununknowntun-gre-installer-pair.service").is_file())

    def test_main_choice_six_reaches_real_wizard_without_installation(self):
        result = self.shell('valid_main_choice 6; ! valid_main_choice 7; main_menu\n',
                            stdin="6\n" + str(self.output) + "\n" + self.wizard_answers())
        self.assertIn("6) Native IP spoof / GRE", result.stdout)
        self.assertIn("no deployment", result.stdout)
        self.assert_generated_pair(result)

    def test_spoof_pair_dispatcher_passes_destination_to_real_helper(self):
        dispatcher = installer.DISPATCH + installer.SOURCE.split(installer.DISPATCH, 1)[1]
        result = self.shell('set -- spoof-pair "$OUTPUT"\n' + dispatcher, stdin=self.wizard_answers())
        self.assert_generated_pair(result)

    def test_authorization_failure_propagates_and_cleans_extracted_helper(self):
        result = self.shell('generate_spoof_pair "$OUTPUT"\n', stdin="NO\n", expected=1)
        self.assertIn("Explicit authorization was not given", result.stderr)
        self.assertEqual(self.calls.read_text(), "exact embedded helper\n")
        self.assertEqual(len(self.stages.read_text().splitlines()), 1)
        self.assertFalse(self.output.exists())

    def test_existing_destination_is_unchanged_and_failure_propagates(self):
        self.output.mkdir(mode=0o700)
        marker = self.output / "existing.txt"
        marker.write_text("keep this directory unchanged\n")
        result = self.shell('generate_spoof_pair "$OUTPUT"\n', stdin=self.wizard_answers(), expected=1)
        self.assertIn("Output already exists", result.stderr)
        self.assertEqual(marker.read_text(), "keep this directory unchanged\n")
        self.assertEqual(list(self.output.iterdir()), [marker])

    def test_relative_destination_fails_before_extracting_helper(self):
        result = self.shell('generate_spoof_pair relative-path\n', expected=1)
        self.assertIn("absolute output directory", result.stderr)
        self.assertEqual(self.calls.read_text(), "")
        self.assertEqual(self.stages.read_text(), "")
        self.assertFalse(self.output.exists())

    def test_shell_metacharacters_remain_data_and_are_rejected_by_helper(self):
        injected = str(self.output) + ";touch " + str(self.root / "injected")
        result = self.shell("generate_spoof_pair " + shlex.quote(injected) + "\n",
                            stdin=self.wizard_answers(), expected=1)
        self.assertIn("simple path components", result.stderr)
        self.assertFalse((self.root / "injected").exists())
        self.assertFalse(self.output.exists())

    def test_renderer_rejects_pre_security_fix_toolchain_before_emitting_installer(self):
        output = self.root / "old-toolchain-render"
        binaries = output / "bin"
        binaries.mkdir(parents=True)
        for arch, machine in (("amd64", 62), ("arm64", 183)):
            blob = bytearray(64)
            blob[:6] = b"\x7fELF\x02\x01"
            struct.pack_into("<H", blob, 18, machine)
            (binaries / ("ununknowntun-linux-" + arch)).write_bytes(blob)
        renderer = PACKAGING / "render-complete.py"
        metadata = "fixture: go1.26.9\n\tpath\tununknowntun\n\tbuild\tGOOS=linux\n\tbuild\tGOARCH=amd64\n"
        with patch.object(sys, "argv", [str(renderer), str(output)]), \
                patch("platform.system", return_value="Fixture"), \
                patch.object(subprocess, "check_output", return_value=metadata), \
                patch.object(subprocess, "run") as run:
            with self.assertRaisesRegex(SystemExit, r"requires Go 1\.26\.10"):
                runpy.run_path(str(renderer), run_name="__main__")
            run.assert_not_called()
        self.assertEqual(set(path.name for path in output.iterdir()), {"bin"})

    def test_renderer_embeds_exact_helper_without_unexpanded_markers_or_native_execution(self):
        output = self.root / "rendered"
        binaries = output / "bin"
        binaries.mkdir(parents=True)
        for arch, machine in (("amd64", 62), ("arm64", 183)):
            blob = bytearray(64)
            blob[:6] = b"\x7fELF\x02\x01"
            struct.pack_into("<H", blob, 18, machine)
            (binaries / ("ununknowntun-linux-" + arch)).write_bytes(blob)
        real_run = subprocess.run
        observed = []

        def metadata(command, **kwargs):
            self.assertEqual(command[:3], ["go", "version", "-m"])
            arch = Path(command[3]).name.removeprefix("ununknowntun-linux-")
            self.assertIn(arch, ("amd64", "arm64"))
            observed.append("metadata-" + arch)
            return command[3] + ": go1.26.10\n\tpath\tununknowntun\n\tbuild\tGOOS=linux\n\tbuild\tGOARCH=" + arch + "\n"

        def local_only(command, **kwargs):
            if command[:2] == ["bash", "-n"]:
                observed.append("shell-syntax")
                return real_run(command, **kwargs)
            self.assertEqual(command, [sys.executable, str(PACKAGING / "collect-licenses.py"), str(output)])
            observed.append("licenses-mocked")
            return subprocess.CompletedProcess(command, 0)

        renderer = PACKAGING / "render-complete.py"
        with patch.object(sys, "argv", [str(renderer), str(output)]), \
                patch("platform.system", return_value="Fixture"), \
                patch.object(subprocess, "check_output", side_effect=metadata), \
                patch.object(subprocess, "run", side_effect=local_only), contextlib.redirect_stdout(io.StringIO()):
            runpy.run_path(str(renderer), run_name="__main__")
        version = (PACKAGING.parent / "VERSION").read_text().strip()
        delivered = (output / ("UNUNKNOWNTUN-V3-INSTALLER-" + version + ".sh")).read_text()
        prefix = "    cat > \"$gdt_spoof_stage/spoof-pair.py\" <<'SPOOF_PAIR_PY'\n"
        self.assertEqual(delivered.count(prefix), 1)
        embedded = delivered.split(prefix, 1)[1].split("\nSPOOF_PAIR_PY\n", 1)[0]
        self.assertEqual(embedded, (PACKAGING / "spoof-pair.py").read_text().rstrip())
        compile(embedded, "embedded-spoof-pair.py", "exec")
        self.assertNotIn("__SPOOF_PAIR_SOURCE__", delivered)
        self.assertNotIn("__VERSION__", delivered)
        self.assertIn('spoof-pair) generate_spoof_pair "${2:-}" ;;', delivered)
        self.assertIn("6) generate_spoof_pair ;;", delivered)
        self.assertEqual(observed, ["metadata-amd64", "metadata-arm64", "shell-syntax", "licenses-mocked"])
        self.assertFalse(self.output.exists())


if __name__ == "__main__":
    unittest.main()
