#!/usr/bin/env python3
"""Offline pair-wizard tests: no root, network, services or GRE activation."""
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shlex
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch


MODULE = Path(__file__).with_name("spoof-pair.py")
LOADER = importlib.util.spec_from_file_location("spoof_pair", MODULE)
pair = importlib.util.module_from_spec(LOADER)
LOADER.loader.exec_module(pair)


def sample():
    return {"pair_id": "test-pair", "authorized": True,
            "binary_path": "/opt/ununknowntun/3.7.0-preview.5/ununknowntun",
            "origin": {"interface": "eth0", "real_ip": "192.0.2.10", "source_ip": "198.51.100.10", "inner_ip": "10.77.0.1"},
            "egress": {"interface": "ens3", "real_ip": "192.0.2.20", "source_ip": "198.51.100.20", "inner_ip": "10.77.0.2"}}


class SpecTests(unittest.TestCase):
    def test_defaults_and_exact_crossed_mapping(self):
        value = sample()
        saved = copy.deepcopy(value)
        spec = pair.validate_spec(value)
        self.assertEqual(value, saved)
        self.assertEqual(spec["install_dir"], "/etc/ununknowntun-gre/test-pair")
        self.assertEqual((spec["carrier_port"], spec["mtu"], spec["mux"]), (18443, 1280, "on"))
        self.assertEqual(spec["client_listen"], "127.0.0.1:12055")
        self.assertEqual(spec["target"], "127.0.0.1:18082")
        origin, egress = (pair.gre_config(spec, role) for role in ("origin", "egress"))
        self.assertEqual(origin["peer_ip"], egress["local_ip"])
        self.assertEqual(egress["peer_ip"], origin["local_ip"])
        self.assertEqual(origin["source_ip"], egress["expected_peer_source_ip"])
        self.assertEqual(egress["source_ip"], origin["expected_peer_source_ip"])
        self.assertEqual(origin["inner_local_ip"], egress["inner_peer_ip"])
        self.assertEqual(egress["inner_local_ip"], origin["inner_peer_ip"])
        self.assertEqual(origin["peer_ip"], "192.0.2.20")
        self.assertNotEqual(origin["peer_ip"], origin["expected_peer_source_ip"])
        self.assertNotEqual(origin["tun_name"], egress["tun_name"])
        self.assertEqual(set(origin), {"interface", "tun_name", "local_ip", "peer_ip", "source_ip",
                                      "expected_peer_source_ip", "inner_local_ip", "inner_peer_ip",
                                      "mtu", "carrier_port", "authorized"})

    def test_baseline_defaults_and_boundary_values(self):
        for mtu, port, mux in ((576, 1024, "off"), (1400, 65535, "on")):
            value = sample()
            del value["origin"]["source_ip"]
            del value["egress"]["source_ip"]
            value.update(mtu=mtu, carrier_port=port, mux=mux,
                         client_listen="0.0.0.0:1024", target="127.0.0.1:1")
            value["pair_id"] = "a" * 24
            spec = pair.validate_spec(value)
            self.assertEqual(spec["origin"]["source_ip"], spec["origin"]["real_ip"])
            self.assertLessEqual(len(spec["origin"]["tun_name"]), 15)

    def test_authorization_must_be_exact_true(self):
        for value in (False, 1, "true", None, [], {}):
            with self.subTest(value=value), self.assertRaises(pair.PairError):
                pair.validate_spec(dict(sample(), authorized=value))

    def test_unknown_missing_duplicate_and_malformed_json(self):
        for document in (b'{"a":1,"a":2}', b'{"a":{"b":1,"b":2}}', b'{} {}', b'{"a":NaN}',
                         b'{"a":Infinity}', b'\xff', b'{', b' ' * (pair.MAX_JSON + 1)):
            with self.subTest(document=document[:50]), self.assertRaises(pair.PairError):
                pair.strict_json(document)
        for value in ([], None, {}, dict(sample(), extra="x"), dict(sample(), spoof_dst_ip="198.51.100.20")):
            with self.subTest(value=value), self.assertRaises(pair.PairError):
                pair.validate_spec(value)
        for role in ("origin", "egress"):
            value = sample()
            value[role]["unexpected"] = True
            with self.assertRaises(pair.PairError):
                pair.validate_spec(value)

    def test_pair_names_paths_and_shell_injection_rejected(self):
        for name in ("", "-test", "TEST", "a" * 25, "a/b", "a b", "a\nExecStart=x", "$(id)", "a%u", "a;id"):
            with self.subTest(name=name), self.assertRaises(pair.PairError):
                pair.validate_spec(dict(sample(), pair_id=name))
        for key in ("binary_path", "install_dir"):
            for path in ("ununknowntun", "/", "/opt//ununknowntun", "/opt/../ununknowntun", "/opt/./ununknowntun",
                         "/opt/ununknowntun/", "/opt/ununknowntun name", "/opt/$(id)", "/opt/a;id", "/opt/a%u",
                         "/opt/$HOME", "/opt/a'", "/opt/a\nX", "/opt/`id`", "/opt/a\\b", None):
                with self.subTest(key=key, path=path), self.assertRaises(pair.PairError):
                    pair.validate_spec(dict(sample(), **{key: path}))
        for path in ("/etc/ununknowntun-gre/test-pair", "/etc/ununknowntun-gre/test-pair/ununknowntun"):
            with self.assertRaises(pair.PairError):
                pair.validate_spec(dict(sample(), binary_path=path))

    def test_ipv4_and_inner_safety(self):
        bad = ("example.com", "192.0.2.010", "192.0.2.1/32", "::1", "127.0.0.1", "0.0.0.0",
               "0.1.2.3", "224.1.2.3", "240.1.2.3", "255.255.255.255", "169.254.1.2", "1.2.3.4\n", 1)
        for field in ("real_ip", "source_ip", "inner_ip"):
            for address in bad:
                value = sample()
                value["origin"][field] = address
                with self.subTest(field=field, address=address), self.assertRaises(pair.PairError):
                    pair.validate_spec(value)
        for address in ("192.0.2.5", "100.64.1.1", "172.32.0.1", "198.18.0.1"):
            value = sample()
            value["origin"]["inner_ip"] = address
            with self.assertRaises(pair.PairError):
                pair.validate_spec(value)
        for field in ("real_ip", "inner_ip"):
            value = sample()
            value["egress"][field] = value["origin"][field]
            with self.assertRaises(pair.PairError):
                pair.validate_spec(value)
        for role in ("origin", "egress"):
            value = sample()
            value[role]["source_ip"] = value["origin"]["inner_ip"]
            with self.assertRaises(pair.PairError):
                pair.validate_spec(value)

    def test_names_numeric_limits_and_endpoint_inputs(self):
        for field in ("interface", "tun_name"):
            for name in ("lo", "", "x" * 16, "eth0;id", "eth0\n", "../eth0", "-eth0", "eth 0", 1):
                value = sample()
                value["origin"][field] = name
                with self.subTest(field=field, name=name), self.assertRaises(pair.PairError):
                    pair.validate_spec(value)
        value = sample()
        value["origin"]["tun_name"] = value["origin"]["interface"]
        with self.assertRaises(pair.PairError):
            pair.validate_spec(value)
        for field, values in (("carrier_port", (0, 1023, 65536, True, "18443", 18443.0)),
                              ("mtu", (0, 575, 1401, True, "1280", 1280.0)),
                              ("mux", (True, "auto", "ON", None))):
            for value in values:
                with self.subTest(field=field, value=value), self.assertRaises(pair.PairError):
                    pair.validate_spec(dict(sample(), **{field: value}))
        for field in ("client_listen", "target"):
            for value in ("localhost:1234", "[::1]:1234", "127.0.0.1", "127.0.0.1:0", "127.0.0.1:65536",
                          "127.0.0.1:01234", "127.0.0.1:1234,127.0.0.1:5678", "224.1.1.1:1234", "1.2.3.4:1;id"):
                with self.subTest(field=field, value=value), self.assertRaises(pair.PairError):
                    pair.validate_spec(dict(sample(), **{field: value}))
        with self.assertRaises(pair.PairError):
            pair.validate_spec(dict(sample(), client_listen="127.0.0.1:443"))
        with self.assertRaises(pair.PairError):
            pair.validate_spec(dict(sample(), target="0.0.0.0:443"))


class RenderTests(unittest.TestCase):
    def setUp(self):
        self.spec = pair.validate_spec(sample())
        self.pin = "a" * 64

    def test_launchers_use_exact_arguments_not_shell_interpretation(self):
        for role in ("origin", "egress"):
            for check in (False, True):
                script = pair.launcher(self.spec, role, self.pin, check).decode()
                command = next(line for line in script.splitlines() if line.startswith("exec "))
                args = shlex.split(command)[1:]
                self.assertEqual(args, pair.command_args(self.spec, role, self.pin, check))
                self.assertEqual(args[0], self.spec["binary_path"])
                self.assertNotIn("-token", args)
                self.assertNotIn("-utls-profile", args)
                result = subprocess.run(["/bin/sh", "-n"], input=script, text=True, capture_output=True, timeout=5)
                self.assertEqual(result.returncode, 0, result.stderr)
                if check and role == "egress":
                    self.assertIn("-check-spoof-config", args)
                    self.assertNotIn("-check-spoof", args)
                elif check:
                    self.assertIn("-check-spoof", args)
                    self.assertIn("15s", args)
                else:
                    self.assertEqual(args[args.index("-transport") + 1], "tls")
                    self.assertIn("-stats", args)
                    self.assertNotIn("-stats-every", args)
        origin = pair.command_args(self.spec, "origin", self.pin)
        egress = pair.command_args(self.spec, "egress", self.pin)
        self.assertEqual(origin[origin.index("-connect") + 1], egress[egress.index("-listen") + 1])
        self.assertEqual(origin[origin.index("-target") + 1], egress[egress.index("-allow") + 1])
        self.assertEqual(egress[egress.index("-key") + 1], self.spec["install_dir"] + "/egress/server.key")

    def test_systemd_minimum_caps_devices_and_address_families(self):
        text = pair.service(self.spec, "origin").decode()
        self.assertIn("CapabilityBoundingSet=CAP_NET_ADMIN CAP_NET_RAW\n", text)
        self.assertIn("AmbientCapabilities=CAP_NET_ADMIN CAP_NET_RAW\n", text)
        self.assertIn("RestrictAddressFamilies=AF_INET AF_INET6 AF_NETLINK\n", text)
        self.assertIn("DevicePolicy=closed\nDeviceAllow=/dev/net/tun rw\n", text)
        self.assertIn("PrivateDevices=no\n", text)
        self.assertIn("UMask=0077\n", text)
        self.assertIn("ExecStart=/bin/sh /etc/ununknowntun-gre/test-pair/origin/run.sh\n", text)
        self.assertIn("ExecStart=/bin/sh /etc/ununknowntun-gre/test-pair/egress/run.sh\n", pair.service(self.spec, "egress").decode())
        for bad in ("PrivateNetwork=yes", "PrivateDevices=yes", "PrivateUsers=yes", "CAP_SYS_ADMIN", "ExecStartPre=", "systemctl"):
            self.assertNotIn(bad, text)

    def test_openssl_is_bounded_isolated_and_silent_on_failure(self):
        with patch.object(pair.subprocess, "run", return_value=subprocess.CompletedProcess([], 0, b"public", b"")) as run:
            self.assertEqual(pair.openssl_run("/usr/bin/openssl", ["x509", "-noout"], b"input"), b"public")
        args, options = run.call_args
        self.assertEqual(args[0], ["/usr/bin/openssl", "x509", "-noout"])
        self.assertEqual(options["timeout"], 45)
        self.assertEqual(options["env"], {"PATH": "/usr/bin:/bin", "LC_ALL": "C", "OPENSSL_CONF": "/dev/null", "RANDFILE": "/dev/null"})
        self.assertNotIn("shell", options)
        for failure in (OSError("PRIVATE KEY"), subprocess.TimeoutExpired("openssl", 45, output=b"PRIVATE KEY")):
            with patch.object(pair.subprocess, "run", side_effect=failure), self.assertRaises(pair.PairError) as error:
                pair.openssl_run("/usr/bin/openssl", [])
            self.assertNotIn("PRIVATE KEY", str(error.exception))

    def test_wizard_requires_literal_authorization_and_no_hidden_activation(self):
        with patch("builtins.input", return_value="yes"), contextlib.redirect_stdout(io.StringIO()), self.assertRaises(pair.PairError):
            pair.wizard()
        answers = iter(["AUTHORIZED", "wizard", "/opt/ununknowntun/bin/ununknowntun", "",
                        "", "192.0.2.10", "198.51.100.10", "", "", "192.0.2.20", "198.51.100.20", "",
                        "", "", "", "", "off"])
        with patch("builtins.input", side_effect=lambda _: next(answers)), contextlib.redirect_stdout(io.StringIO()):
            spec = pair.wizard()
        self.assertEqual(spec["pair_id"], "wizard")
        self.assertEqual(spec["mux"], "off")
        self.assertEqual(spec["origin"]["inner_ip"], "10.77.0.1")


@unittest.skipUnless(shutil.which("openssl"), "local OpenSSL required for offline credential tests")
class BundleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cert_material = pair.make_certificate(pair.validate_spec(sample()), pair.openssl_binary())
        cls.other_material = pair.make_certificate(pair.validate_spec(dict(sample(), pair_id="other")), pair.openssl_binary())

    def setUp(self):
        # Resolve only the known system temporary base; the helper itself never resolves output symlinks.
        self.temp = tempfile.TemporaryDirectory(prefix="gdt-spoof-pair-test-", dir=str(Path(tempfile.gettempdir()).resolve()))
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.output = self.root / "pair"

    def generate(self, value=None, output=None):
        with patch.object(pair, "make_certificate", return_value=self.cert_material):
            return pair.generate(value or sample(), str(output or self.output))

    def test_real_openssl_generation_and_complete_offline_check(self):
        spec = pair.generate(sample(), str(self.output))
        self.assertEqual(pair.check_pair(str(self.output)), spec)
        for path in (self.output, self.output / "origin", self.output / "egress"):
            self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o700)
        for role in ("origin", "egress"):
            peer = self.output / role
            for path in peer.iterdir():
                self.assertTrue(path.is_file())
                self.assertEqual(stat.S_IMODE(path.stat().st_mode), 0o600)
            self.assertEqual(json.loads((peer / "gre.json").read_text()), pair.gre_config(spec, role))
        self.assertFalse((self.output / "origin/server.key").exists())
        self.assertIn(b"PRIVATE KEY", (self.output / "egress/server.key").read_bytes())
        self.assertEqual((self.output / "origin/token").read_bytes(), (self.output / "egress/token").read_bytes())
        cert = (self.output / "origin/server.crt").read_bytes()
        der = pair.openssl_run(pair.openssl_binary(), ["x509", "-outform", "DER"], cert)
        self.assertEqual((self.output / "origin/pin.sha256").read_text(), hashlib.sha256(der).hexdigest() + "\n")

    def test_credentials_are_fresh_and_do_not_appear_in_summary(self):
        spec = self.generate()
        second = self.root / "second"
        self.generate(output=second)
        token = (self.output / "origin/token").read_text().strip()
        self.assertNotEqual(token, (second / "origin/token").read_text().strip())
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            pair.summary(spec, str(self.output))
        text = output.getvalue()
        self.assertNotIn(token, text)
        self.assertNotIn("BEGIN", text)
        self.assertIn("No network test was performed", text)

    def test_creation_permissions_ignore_permissive_and_restrictive_umask(self):
        for mask in (0, 0o777):
            output = self.root / ("mask-" + str(mask))
            previous = os.umask(mask)
            try:
                self.generate(output=output)
            finally:
                os.umask(previous)
            self.assertEqual(stat.S_IMODE(output.stat().st_mode), 0o700)
            self.assertEqual(stat.S_IMODE((output / "origin/token").stat().st_mode), 0o600)
            pair.check_pair(str(output))

    def test_preexisting_output_and_symlinks_never_overwritten(self):
        self.output.mkdir()
        marker = self.output / "marker"
        marker.write_text("unchanged")
        with patch.object(pair, "make_certificate") as create, self.assertRaises(pair.PairError):
            pair.generate(sample(), str(self.output))
        create.assert_not_called()
        self.assertEqual(marker.read_text(), "unchanged")
        alias = self.root / "alias"
        alias.symlink_to(self.output, target_is_directory=True)
        with self.assertRaises(pair.PairError):
            self.generate(output=alias)
        with self.assertRaises(OSError):
            self.generate(output=alias / "child")
        self.assertFalse((self.output / "child").exists())

    def test_exclusive_private_writer_does_not_follow_or_replace(self):
        target = self.root / "target"
        target.write_text("original")
        link = self.root / "link"
        link.symlink_to(target)
        with pair.directory(str(self.root)) as parent:
            for name in ("target", "link"):
                with self.assertRaises(FileExistsError):
                    pair.write_private(parent, name, b"modified")
        self.assertEqual(target.read_text(), "original")

    def test_invalid_spec_or_missing_parent_creates_nothing(self):
        with patch.object(pair, "make_certificate") as create:
            for value in (dict(sample(), authorized=False), dict(sample(), binary_path="/opt/a;id")):
                with self.assertRaises(pair.PairError):
                    pair.generate(value, str(self.output))
            with self.assertRaises(OSError):
                pair.generate(sample(), str(self.output / "missing"))
            create.assert_not_called()
        self.assertFalse(self.output.exists())

    def test_failed_openssl_creates_no_output_and_does_not_print_key(self):
        result = subprocess.CompletedProcess([], 1, b"PRIVATE KEY MATERIAL", b"SECRET ERROR")
        with patch.object(pair.subprocess, "run", return_value=result), self.assertRaises(pair.PairError) as error:
            pair.generate(sample(), str(self.output))
        self.assertNotIn("SECRET", str(error.exception))
        self.assertNotIn("PRIVATE KEY", str(error.exception))
        self.assertFalse(self.output.exists())

    def test_checker_rejects_cross_field_token_pin_and_launch_tampering(self):
        self.generate()
        mutations = {
            "origin/gre.json": lambda data: pair.json_bytes(dict(json.loads(data), expected_peer_source_ip="198.51.100.99")),
            "egress/gre.json": lambda data: pair.json_bytes(dict(json.loads(data), peer_ip="192.0.2.99")),
            "egress/token": lambda _: b"b" * 64 + b"\n",
            "origin/pin.sha256": lambda _: b"b" * 64 + b"\n",
            "origin/run.sh": lambda data: data + b"echo unexpected\n",
            "egress/check.sh": lambda data: data.replace(b"-check-spoof-config", b"-check-spoof"),
            "origin/ununknowntun-gre-test-pair.service": lambda data: data.replace(b"CAP_NET_RAW", b"CAP_SYS_ADMIN"),
            "README.txt": lambda _: b"activate immediately\n",
            "pair.json": lambda data: pair.json_bytes(dict(json.loads(data), carrier_port=18444)),
        }
        for name, edit in mutations.items():
            path = self.output / name
            original = path.read_bytes()
            try:
                path.write_bytes(edit(original))
                with self.subTest(name=name), self.assertRaises(pair.PairError):
                    pair.check_pair(str(self.output))
            finally:
                path.write_bytes(original)

    def test_checker_rejects_wrong_key_even_with_matching_cert_and_pin(self):
        self.generate()
        (self.output / "egress/server.key").write_bytes(self.other_material[0])
        with self.assertRaisesRegex(pair.PairError, "private key do not match"):
            pair.check_pair(str(self.output))

    def test_checker_preserves_boolean_integer_and_float_json_types(self):
        self.generate()
        for role in ("origin", "egress"):
            path = self.output / role / "gre.json"
            original = path.read_bytes()
            for key, value in (("authorized", 1), ("authorized", 1.0),
                               ("mtu", 1280.0), ("carrier_port", 18443.0)):
                changed = json.loads(original)
                changed[key] = value
                path.write_bytes(pair.json_bytes(changed))
                try:
                    with self.subTest(role=role, key=key, value=value), self.assertRaisesRegex(pair.PairError, "JSON value types"):
                        pair.check_pair(str(self.output))
                finally:
                    path.write_bytes(original)
        self.assertEqual(pair.check_pair(str(self.output)), pair.validate_spec(sample()))

    def test_checker_rejects_matching_wrong_pins_and_invalid_certificate(self):
        self.generate()
        for role in ("origin", "egress"):
            (self.output / role / "server.crt").write_bytes(self.other_material[1])
        with self.assertRaisesRegex(pair.PairError, "fingerprint"):
            pair.check_pair(str(self.output))
        for role in ("origin", "egress"):
            (self.output / role / "server.crt").write_bytes(b"not a certificate")
        with self.assertRaises(pair.PairError):
            pair.check_pair(str(self.output))

    def test_checker_rejects_loose_permissions_unknown_files_and_extra_origin_key(self):
        self.generate()
        for path, unsafe, original in ((self.output, 0o755, 0o700), (self.output / "origin", 0o755, 0o700),
                                        (self.output / "origin/token", 0o644, 0o600)):
            try:
                path.chmod(unsafe)
                with self.subTest(path=path), self.assertRaises(pair.PairError):
                    pair.check_pair(str(self.output))
            finally:
                path.chmod(original)
        for name in ("origin/server.key", "egress/extra", "unexpected"):
            path = self.output / name
            try:
                path.write_text("unexpected")
                path.chmod(0o600)
                with self.subTest(name=name), self.assertRaises(pair.PairError):
                    pair.check_pair(str(self.output))
            finally:
                path.unlink()

    def test_checker_rejects_symlink_hardlink_fifo_and_oversized_file(self):
        self.generate()
        target = self.output / "origin/token"
        original = target.read_bytes()
        outside = self.root / "outside"
        outside.write_bytes(original)
        outside.chmod(0o600)
        for kind in ("symlink", "hardlink", "fifo", "oversized"):
            target.unlink()
            if kind == "symlink":
                target.symlink_to(outside)
            elif kind == "hardlink":
                os.link(outside, target)
            elif kind == "fifo":
                os.mkfifo(target, 0o600)
            else:
                target.write_bytes(b"a" * (pair.MAX_FILE + 1))
                target.chmod(0o600)
            with self.subTest(kind=kind), self.assertRaises((pair.PairError, OSError)):
                pair.check_pair(str(self.output))
        target.unlink()
        target.write_bytes(original)
        target.chmod(0o600)
        alias = self.root / "alias"
        alias.symlink_to(self.output, target_is_directory=True)
        with self.assertRaises(OSError):
            pair.check_pair(str(alias))

    def test_checker_rejects_symlink_role_directory_and_foreign_owner(self):
        self.generate()
        real = self.root / "real-origin"
        (self.output / "origin").rename(real)
        (self.output / "origin").symlink_to(real, target_is_directory=True)
        with self.assertRaises(OSError):
            pair.check_pair(str(self.output))
        (self.output / "origin").unlink()
        real.rename(self.output / "origin")
        with patch.object(pair.os, "geteuid", return_value=os.geteuid() + 1), self.assertRaises(pair.PairError):
            pair.check_pair(str(self.output))

    def test_spec_file_reader_rejects_symlink_duplicates_and_oversize(self):
        source = self.root / "spec.json"
        source.write_bytes(pair.json_bytes(sample()))
        self.assertEqual(pair.read_spec(str(source)), pair.validate_spec(sample()))
        alias = self.root / "alias.json"
        alias.symlink_to(source)
        with self.assertRaises(OSError):
            pair.read_spec(str(alias))
        for data in (b'{"pair_id":"x","pair_id":"y"}', b" " * (pair.MAX_JSON + 1)):
            source.write_bytes(data)
            with self.assertRaises(pair.PairError):
                pair.read_spec(str(source))

    def test_cli_spec_and_check_do_not_run_the_target_binary(self):
        source = self.root / "spec.json"
        source.write_bytes(pair.json_bytes(sample()))
        with patch.object(pair, "make_certificate", return_value=self.cert_material), contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(pair.main(["--spec", str(source), "--output", str(self.output)]), 0)
        self.assertIn("PRIVATE PAIR PREPARED", output.getvalue())
        with contextlib.redirect_stdout(io.StringIO()) as output:
            self.assertEqual(pair.main(["--check-pair", str(self.output)]), 0)
        self.assertIn("OFFLINE PAIR CHECK PASSED", output.getvalue())
        self.assertNotIn((self.output / "origin/token").read_text().strip(), output.getvalue())
        with contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(pair.main(["--spec", str(source)]), 1)
            self.assertEqual(pair.main(["--check-pair", str(self.output), "--output", str(self.root / "unused")]), 1)
        self.assertFalse((self.root / "unused").exists())

    @unittest.skipUnless(os.environ.get("UNUNKNOWNTUN_TEST_BINARY"), "set UNUNKNOWNTUN_TEST_BINARY for final-core JSON validation")
    def test_final_core_accepts_both_generated_gre_configs(self):
        binary = os.environ["UNUNKNOWNTUN_TEST_BINARY"]
        self.assertTrue(Path(binary).is_absolute())
        spec = self.generate(dict(sample(), binary_path=binary, install_dir=str(self.output)))
        pin = (self.output / "origin/pin.sha256").read_text().strip()
        for role in ("origin", "egress"):
            # The core's early JSON-only action parses every generated argument
            # but exits before any runtime/socket/TUN work. This catches renamed
            # flags as well as config incompatibilities; never run the launcher.
            for check in (False, True):
                command = pair.command_args(spec, role, pin, check)
                if "-check-spoof-config" not in command:
                    command.append("-check-spoof-config")
                result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                        text=True, timeout=10)
                self.assertEqual(result.returncode, 0, role + ": " + result.stdout + result.stderr)
                self.assertIn("PASS", result.stdout)
                self.assertIn("No interfaces, routes or packets", result.stdout)


if __name__ == "__main__":
    unittest.main()
