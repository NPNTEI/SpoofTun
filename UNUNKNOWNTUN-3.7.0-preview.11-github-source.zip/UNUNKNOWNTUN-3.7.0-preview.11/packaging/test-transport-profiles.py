#!/usr/bin/env python3
"""3.4 profile regressions: private fixtures only, no live hosts or CDN accounts."""
import base64
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest
from unittest import mock
import zipfile


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(filename))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


installer = load("transport_installer_tests", "test-full-installer.py")
safety = load("transport_editor_tests", "test-editor-safety.py")
editor = safety.editor


class InstallerProfileTests(unittest.TestCase):
    def setUp(self):
        self.fx = installer.InstallerTests(methodName="runTest")
        self.fx.setUp()
        self.addCleanup(self.fx.tearDown)

    def test_fastly_is_explicit_experimental_and_reprompts(self):
        result = self.fx.run_shell('select_proxy_provider provider "Foreign"; echo "$provider"', stdin="bad\n4\n")
        self.assertIn("fastly", result.stdout)
        self.assertIn("experimental", result.stdout + result.stderr)

    def test_fastly_forces_only_foreign_carrier_not_iran_carrier(self):
        result = self.fx.run_shell('foreign_provider=fastly; iran_provider=none; select_tunnel_profile; echo "$transport/$mux_mode"', stdin="1\n2\n2\n4\n")
        self.assertIn("xhttp/off", result.stdout)
        result = self.fx.run_shell('foreign_provider=none; iran_provider=fastly; select_tunnel_profile; echo "$transport/$mux_mode"', stdin="1\n1\n")
        self.assertIn("wss/on", result.stdout)

    def test_fastly_iran_explicit_entry_and_legacy_entry_default(self):
        result = self.fx.run_shell('iran_provider=fastly; select_entry_profile; echo "$entry_transport"', stdin="1\n2\n")
        self.assertIn("xhttp", result.stdout)
        result = self.fx.run_shell('iran_provider=cloudflare; select_entry_profile; echo "$entry_transport"', stdin="\n")
        self.assertTrue(result.stdout.rstrip().endswith("ws"))

    def test_fragment_is_editable_and_reprompts_only_invalid_range(self):
        result = self.fx.run_shell('foreign_provider=arvan; select_tls_handshake_profile; echo "$ech_mode/$tls_fragment/$fragment_size/$fragment_interval"', stdin="3\n0-9\n120-250\n200-500ms\n2-5ms\n")
        self.assertIn("off/hello/120-250/2-5ms", result.stdout)
        self.assertIn("MIN-MAX", result.stderr)

    def test_strict_ech_any_provider_warns_real_terminator_required(self):
        for provider in ("none", "arvan", "fastly", "cloudflare"):
            result = self.fx.run_shell(f'foreign_provider={provider}; select_tls_handshake_profile; echo "$ech_mode/$tls_fragment"', stdin="2\ny\n")
            self.assertIn("strict/off", result.stdout)
            self.assertIn("fail closed", result.stderr)

    def test_strict_ech_cloudflare(self):
        result = self.fx.run_shell('foreign_provider=cloudflare; select_tls_handshake_profile; echo "$ech_mode/$tls_fragment"', stdin="2\ny\n")
        self.assertIn("strict/off", result.stdout)

    def test_fragment_ranges_reject_overflow_and_reversed_values(self):
        self.fx.run_shell('valid_fragment_size 100-200; valid_fragment_interval 0-3ms; ! valid_fragment_size 200-100; ! valid_fragment_size 0-1; ! valid_fragment_size 15-100; ! valid_fragment_size 4096-4097; ! valid_fragment_interval 9-1ms; ! valid_fragment_interval 0-21ms')

    def test_xhttp_clean_paths_reprompt_and_accept_512_characters(self):
        path = "/" + "a" * 511
        self.fx.run_shell(f'valid_xhttp_path {path}; ! valid_xhttp_path {path}a; ! valid_xhttp_path /private//double-path; ! valid_xhttp_path /private/../path')
        result = self.fx.run_shell('ask_valid xhttp_path "XHTTP path" "" valid_xhttp_path "Invalid clean path"; echo "$xhttp_path"', stdin="/private//double-path\n/private-clean-path\n")
        self.assertTrue(result.stdout.rstrip().endswith("/private-clean-path"))

    def test_xhttp_nginx_has_prefix_streaming_without_grpc(self):
        self.fx.run_shell('transport=xhttp; xhttp_path=/private-xhttp-path; write_nginx_wss_site edge.example 443 /private-wss-path 18080 /private-h2-path 18081 /cert.pem /key.pem')
        site = (self.fx.root / "nginx-available/ununknowntun-edge.example.conf").read_text()
        self.assertIn("location ^~ /private-xhttp-path/", site)
        self.assertIn("proxy_request_buffering off;", site)
        self.assertIn("proxy_set_header Authorization", site)
        self.assertIn("proxy_intercept_errors off;", site)
        self.assertIn("gzip off;", site)
        self.assertIn('proxy_set_header Accept-Encoding "";', site)
        self.assertIn("location /", site)
        self.assertNotIn("grpc_", site)
        self.assertNotIn('Connection "upgrade"', site)

    def test_new_normal_and_legacy_alias_render_have_no_grpc(self):
        self.fx.run_shell('transport=wss; write_nginx_wss_site edge.example 443 /private-wss-path 18080 /private-h2-path 18081 /cert.pem /key.pem')
        path = self.fx.root / "nginx-available/ununknowntun-edge.example.conf"
        self.assertNotIn("grpc_pass", path.read_text())
        self.fx.run_shell('transport=auto; write_nginx_wss_site edge.example 443 /private-wss-path 18080 /private-h2-path 18081 /cert.pem /key.pem')
        self.assertNotIn("grpc_pass", path.read_text())

    def test_iran_entry_does_not_follow_carrier_implicitly(self):
        self.fx.run_shell('transport=xhttp; entry_transport=ws; write_nginx_origin_proxy_site iran.example 443 /client-entry-private-path 19080 /cert.pem /key.pem')
        path = self.fx.root / "nginx-available/ununknowntun-iran.example.conf"
        self.assertIn("location = /client-entry-private-path", path.read_text())
        self.fx.run_shell('transport=wss; entry_transport=xhttp; write_nginx_origin_proxy_site iran.example 443 /client-entry-private-path 19080 /cert.pem /key.pem')
        self.assertIn("location ^~ /client-entry-private-path/", path.read_text())
        self.assertNotIn('Connection "upgrade"', path.read_text())

    def test_v5_roundtrip_and_v3_import_defaults(self):
        self.fx.run_shell('''
transport=xhttp; mux_mode=off; entry_transport=xhttp; xhttp_path=/private-xhttp-path
code="$(create_peer_code edge.example 203.0.113.10 443 /private-wss-path /private-h2-path 0123456789abcdef0123456789abcdef 18082 fastly chrome fastly /client-entry-private-path a1b2c3d4e5f60718)"
decode_peer_code "$code"
[[ "$PEER_FORMAT/$PEER_TRANSPORT/$PEER_MUX_MODE/$PEER_IRAN_ENTRY_TRANSPORT" == UNUNKNOWNTUN_V5_FLEET/xhttp/off/xhttp ]]
''')
        peer = (self.fx.root / "config/peer.env").read_text()
        old = "\n".join(line for line in peer.splitlines() if line.split("=", 1)[0] not in {"TRANSPORT", "XHTTP_PATH", "XHTTP_MODE", "MUX_MODE", "IRAN_ENTRY_TRANSPORT"}).replace("V5_FLEET", "V3_FLEET").replace("fastly", "arvan") + "\n"
        code = base64.b64encode(old.encode()).decode()
        self.fx.run_shell(f'decode_peer_code {code}; [[ "$PEER_TRANSPORT/$PEER_MUX_MODE/$PEER_IRAN_ENTRY_TRANSPORT" == wss/on/ws ]]')
        duplicate = base64.b64encode((peer + "TRANSPORT=wss\n").encode()).decode()
        self.fx.run_shell(f'! decode_peer_code {duplicate}')

    def test_generated_runs_include_explicit_profiles_and_no_legacy_padding(self):
        self.fx.run_shell('''
PROFILE_MAX_MEMORY=268435456; PROFILE_MAX_STREAMS=128
transport=xhttp; mux_mode=off; xhttp_path=/private-xhttp-path
write_foreign_run_script edge.example /private-wss-path 18080 /private-h2-path 18081 18082
''')
        run = (self.fx.root / "config/run.sh").read_text()
        for flag in ("-transport xhttp", "-mux off", "-pad 0", "-xhttp-mode packet-up", "-xhttp-path /private-xhttp-path"):
            self.assertIn(flag, run)

    def test_new_profile_suite_and_guide_are_in_release_pipeline(self):
        root = Path(__file__).resolve().parent.parent
        self.assertIn("test-transport-profiles.py", (root / "packaging/build-complete.sh").read_text())
        self.assertIn('"xhttp-profile.md"', (root / "packaging/package-release.py").read_text())

    def test_local_package_contains_profile_in_runtime_and_source(self):
        root = Path(__file__).resolve().parent.parent
        version = (root / "VERSION").read_text().strip()
        build = self.fx.root / "private-build"
        (build / "bin").mkdir(parents=True)
        (build / "THIRD_PARTY_LICENSES").mkdir()
        (build / f"UNUNKNOWNTUN-V3-INSTALLER-{version}.sh").write_text("# assembly fixture only; not an executable release\n")
        (build / "bin/ununknowntun-linux-amd64").write_text("assembly fixture")
        (build / "bin/ununknowntun-linux-arm64").write_text("assembly fixture arm64")
        (build / "direct-icmp-binaries.json").write_text(json.dumps({
            "version": version,
            "binary_sha256": {arch: hashlib.sha256((build / "bin" / ("ununknowntun-linux-" + arch)).read_bytes()).hexdigest()
                              for arch in ("amd64", "arm64")}}))
        (build / "THIRD_PARTY_LICENSES/INDEX.txt").write_text("fixture notices")
        output = self.fx.root / "private-package"
        result = subprocess.run([sys.executable, str(root / "packaging/package-release.py"), str(build), str(output)], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertEqual((output / "xhttp-profile.md").read_bytes(), (root / "xhttp-profile.md").read_bytes())
        with zipfile.ZipFile(output / f"UNUNKNOWNTUN-{version}-github-source.zip") as archive:
            self.assertIn(f"UNUNKNOWNTUN-{version}/xhttp-profile.md", archive.namelist())
        with zipfile.ZipFile(output / f"UNUNKNOWNTUN-{version}-linux-bundle.zip") as archive:
            self.assertIn("xhttp-profile.md", archive.namelist())

    def test_xhttp_repairs_only_incorrect_path(self):
        result = self.fx.run_shell('''
transport=xhttp; domain=edge.example; direct_ip=203.0.113.10; foreign_ports=443
foreign_provider=none; xhttp_path=/incorrect-private-path; token=0123456789abcdef; ORIGIN_CA_PATH=/ca.pem
probe_websocket_path() { [[ "$4" == /corrected-private-path && "$8" == xhttp ]]; }
confirm_foreign_websocket
[[ "$token" == 0123456789abcdef && "$domain" == edge.example ]]
echo "$xhttp_path"
''', stdin="2\n/corrected-private-path\n")
        self.assertIn("/corrected-private-path", result.stdout)

    def test_v4_missing_profile_field_is_not_silently_legacy(self):
        self.fx.run_shell('create_peer_code edge.example 203.0.113.10 443 /private-wss-path /private-h2-path 0123456789abcdef0123456789abcdef 18082 none chrome none "" a1b2c3d4e5f60718 >/dev/null')
        peer = (self.fx.root / "config/peer.env").read_text()
        code = base64.b64encode("\n".join(line for line in peer.splitlines() if not line.startswith("TRANSPORT=")).encode()).decode()
        self.fx.run_shell(f'! decode_peer_code {code}')

    def test_v4_import_warns_both_peers_must_upgrade(self):
        self.fx.run_shell('transport=xhttp; xhttp_path=/private-xhttp-path; create_peer_code edge.example 203.0.113.10 443 /private-wss-path /private-h2-path 0123456789abcdef0123456789abcdef 18082 none chrome none "" a1b2c3d4e5f60718 >/dev/null')
        old = (self.fx.root / "config/peer.env").read_text().replace("V5_FLEET", "V4_FLEET")
        result = self.fx.run_shell('decode_peer_code ' + base64.b64encode(old.encode()).decode())
        self.assertIn("Upgrade BOTH peers to 3.5", result.stderr)

    def test_local_origin_trust_is_independent_of_public_edge_trust(self):
        self.fx.run_shell('''
LOCAL_TLS_CA_PATH=/private-origin-ca.pem
ORIGIN_CA_PATH=/public-edge-ca.pem
PROFILE_MAX_MEMORY=268435456; PROFILE_MAX_STREAMS=128
curl() { printf '%s\\n' "$*" >> "$MOCK_LOG"; printf '<html>origin</html>'; }
verify_foreign_reverse_endpoint edge.example 443
write_origin_run_script edge.example 203.0.113.10 443 /private-wss-path /private-h2-path 18082 19080 8 0 arvan none chrome off
write_deployment_env origin edge.example 203.0.113.10 443 19080 arvan none
''')
        self.assertIn("--cacert /private-origin-ca.pem", self.fx.log.read_text())
        self.assertIn("-ca /public-edge-ca.pem", (self.fx.root / "config/run.sh").read_text())
        metadata = (self.fx.root / "config/deployment.env").read_text()
        self.assertIn("LOCAL_TLS_CA_PATH=/private-origin-ca.pem", metadata)
        self.assertIn("CA_PATH=/public-edge-ca.pem", metadata)

    def test_new_origin_discards_legacy_pad_argument(self):
        self.fx.run_shell('PROFILE_MAX_MEMORY=268435456; PROFILE_MAX_STREAMS=128; ORIGIN_CA_PATH=/ca.pem; write_origin_run_script edge.example 203.0.113.10 443 /private-wss-path /private-h2-path 18082 19080 8 0.22 none none chrome off')
        self.assertIn("-pad 0 ", (self.fx.root / "config/run.sh").read_text())
        self.assertNotIn("-pad 0.22", (self.fx.root / "config/run.sh").read_text())

    def test_xhttp_import_rejects_double_slash(self):
        self.fx.run_shell('transport=xhttp; xhttp_path=/bad//private-path; create_peer_code edge.example 203.0.113.10 443 /private-wss-path /private-h2-path 0123456789abcdef0123456789abcdef 18082 none chrome none "" a1b2c3d4e5f60718 >/dev/null')
        peer = (self.fx.root / "config/peer.env").read_bytes()
        self.fx.run_shell('! decode_peer_code ' + base64.b64encode(peer).decode())

    @unittest.skipUnless(os.environ.get("UNUNKNOWNTUN_TEST_NGINX"), "set UNUNKNOWNTUN_TEST_NGINX for real XHTTP Nginx parser gate")
    def test_xhttp_carrier_entry_and_customer_routes_parse_with_nginx(self):
        nginx = Path(os.environ["UNUNKNOWNTUN_TEST_NGINX"])
        self.assertTrue(nginx.is_absolute() and nginx.is_file())
        cert, key = self.fx.certificate()
        self.fx.run_shell(f'''
transport=xhttp; entry_transport=xhttp; xhttp_path=/private-xhttp-path
write_nginx_wss_site right.example 443 /private-websocket-path 18080 /private-http2-path 18081 {cert} {key}
write_nginx_origin_proxy_site iran.example 443 /client-private-entry-path 19080 {cert} {key}
''')
        foreign = (self.fx.root / "nginx-available/ununknowntun-right.example.conf").read_text()
        origin = (self.fx.root / "nginx-available/ununknowntun-iran.example.conf").read_text()
        config = {"accounts": [{"id": "alice", "enabled": True, "listen": "127.0.0.1:19081"}]}
        origin = editor.access.build_routes(origin, config, {"alice": "/customer-private-route"}, "/client-private-entry-path", "xhttp")
        source = (foreign + origin).replace("listen 80;", "listen 127.0.0.1:28080;").replace("listen 443 ssl", "listen 127.0.0.1:28443 ssl")
        conf = self.fx.root / "xhttp-nginx.conf"
        conf.write_text(f"pid {self.fx.root}/nginx.pid;\nerror_log {self.fx.root}/nginx-error.log;\nevents {{ worker_connections 32; }}\nhttp {{ access_log off;\n{source}\n}}\n")
        result = subprocess.run([str(nginx), "-t", "-p", str(self.fx.root), "-c", str(conf)], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)


class EditorProfileTests(unittest.TestCase):
    def setUp(self):
        self.fx = safety.EditorSafetyTests(methodName="runTest")
        self.fx.setUp()
        self.addCleanup(self.fx.doCleanups)
        self.editor = self.fx.instance

    def test_mux_edit_is_signed_and_never_changes_ledger(self):
        plan = self.editor.plan("mux", "off")
        self.assertIsNotNone(plan["update"])
        self.assertIn(b"-mux off", plan["changes"][self.fx.directory / "run.sh"])
        self.assertNotIn(self.fx.state / "access-state.json", plan["changes"])

    def test_ech_and_fragment_constraints(self):
        self.assertIn(b"-ech-mode strict", self.editor.plan("ech_mode", "strict")["changes"][self.fx.directory / "run.sh"])
        self.fx.env["FOREIGN_PROXY_PROVIDER"] = "cloudflare"
        self.fx.script = editor.set_flag(self.fx.script, "tls-fragment", "hello")
        self.fx.write_fixture()
        with self.assertRaisesRegex(ValueError, "mutually exclusive"):
            self.editor.plan("ech_mode", "strict")
        self.fx.script = editor.set_flag(self.fx.script, "tls-fragment", "off")
        self.fx.write_fixture()
        self.assertIn(b"-ech-mode strict", self.editor.plan("ech_mode", "strict")["changes"][self.fx.directory / "run.sh"])

    def test_egress_transport_switch_rewrites_only_routes_and_exports_sync(self):
        self.fx.env.update(ROLE="egress", WSS_BACKEND_PORT="18080", H2_BACKEND_PORT="18081")
        site = self.fx.available / "ununknowntun-foreign.example.conf"
        self.fx.env["NGINX_SITE"] = str(site)
        self.fx.script = self.fx.script.replace("-mode origin", "-mode egress")
        self.fx.write_fixture()
        site.write_text('server {\n ssl_certificate /retained/cert.pem;\n location = /transport-websocket-path { proxy_pass http://127.0.0.1:18080; }\n location = /transport-http2-path { grpc_pass grpc://127.0.0.1:18081; }\n location / { try_files $uri /index.html; }\n}\n')
        self.editor.refresh()
        plan = self.editor.plan("transport", "xhttp")
        rendered = plan["changes"][site].decode()
        self.assertNotIn("grpc_pass", rendered)
        self.assertIn("location ^~ /transport-websocket-path/", rendered)
        self.assertIn("ssl_certificate /retained/cert.pem", rendered)
        self.assertIsNotNone(plan["update"])
        self.assertTrue(plan["nginx"])
        self.assertNotIn(self.fx.state / "access-state.json", plan["changes"])

    def test_legacy_arvan_auto_wss_transport_sync_bootstraps_once(self):
        self.fx.script = editor.set_flag(self.fx.script, "transport", "wss")
        self.fx.env["FOREIGN_PROXY_PROVIDER"] = "arvan"
        self.fx.write_fixture()
        self.editor.refresh()
        data = self.fx.valid_data("transport", "xhttp")
        data["previous"] = editor.digest("auto")
        self.assertEqual(self.editor.decode_update(self.fx.signed(data)), ("transport", "xhttp"))
        self.fx.env["TRANSPORT"] = "wss"
        self.fx.write_fixture()
        with self.assertRaises(ValueError):
            self.editor.decode_update(self.fx.signed(data))

    def test_profile_edit_rollback_preserves_live_ledger_and_other_tunnel(self):
        before = (self.fx.directory / "run.sh").read_bytes()
        other = self.fx.directory.parent / "other"
        other.mkdir()
        (other / "run.sh").write_text("do not modify another tunnel")
        self.editor.active = mock.Mock(return_value=True)
        self.editor.wait_service = mock.Mock(side_effect=[RuntimeError("bad startup"), None])
        plan = self.editor.plan("mux", "off")
        with self.assertRaises(RuntimeError), contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            self.editor.commit(plan)
        self.assertEqual((self.fx.directory / "run.sh").read_bytes(), before)
        self.assertEqual((other / "run.sh").read_text(), "do not modify another tunnel")
        self.assertEqual((self.fx.state / "access-state.json").read_text(), "live-use-must-never-be-restored")
        self.assertFalse((self.fx.directory / "last-edit-update.txt").exists())

    def test_fragment_editor_limits_match_core(self):
        for field, value in (("fragment_size", "15-100"), ("fragment_interval", "0-21ms")):
            with self.assertRaises(ValueError):
                self.editor.plan(field, value)

    def test_xhttp_editor_clean_path_and_long_legacy_path(self):
        for value in ("/invalid//private-path", "/invalid/../private-path", "/" + "a" * 512):
            with self.assertRaises(ValueError):
                self.editor.plan("xhttp_path", value)
        path = "/" + "a" * 511
        for field in ("ws_path", "h2_path", "xhttp_path", "entry_path"):
            self.assertEqual(editor.validate(field, path), path)
        self.fx.script = editor.set_flag(self.fx.script, "ws-path", "/legacy//double-path")
        self.fx.write_fixture()
        with self.assertRaisesRegex(ValueError, "double slashes"):
            self.editor.plan("transport", "xhttp")

    def test_customer_xhttp_prefix_rewrites_preserve_uuid_suffix(self):
        config = {"accounts": [{"id": "alice", "enabled": True, "listen": "127.0.0.1:19080"}]}
        site = editor.access.build_routes(editor.access.MARKER, config, {"alice": "/customer-private-path"}, "/original-client-path", "xhttp")
        self.assertIn("location ^~ /customer-private-path/", site)
        self.assertIn("proxy_pass http://127.0.0.1:19080/original-client-path/;", site)
        self.assertNotIn("Upgrade", site)
        self.assertIn("gzip off;", site)


if __name__ == "__main__":
    unittest.main(verbosity=2)
