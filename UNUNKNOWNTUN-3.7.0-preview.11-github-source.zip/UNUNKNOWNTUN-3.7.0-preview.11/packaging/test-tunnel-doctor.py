#!/usr/bin/env python3
"""Diagnostic scanner regressions. No external hosts, services or CDN accounts."""
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import socket
import ssl
import stat
import subprocess
import tempfile
import unittest
from unittest import mock

spec = importlib.util.spec_from_file_location("tunnel_doctor", Path(__file__).with_name("tunnel-doctor.py"))
doctor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(doctor)


class DoctorTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="ununknowntun-doctor-")
        self.addCleanup(self.temp.cleanup)
        self.directory = Path(self.temp.name) / "fixture"
        self.directory.mkdir()
        self.token = "secret-fixture-token-not-for-export"
        (self.directory / "token").write_text(self.token)
        self.env = "ROLE=origin\nFOREIGN_DOMAIN=edge.example\nFOREIGN_PORTS=443\nFOREIGN_PROXY_PROVIDER=arvan\n"
        self.flags = "#!/bin/bash\nexec /usr/local/bin/ununknowntun \\\n  -mode origin \\\n  -connect 192.0.2.10:443 \\\n  -transport wss \\\n  -sni edge.example \\\n  -ws-host edge.example \\\n  -ws-path /private-fixture-path \\\n  -ech-mode off \\\n  -tls-fragment off \\\n  -mux off\n"
        self.save()

    def save(self):
        (self.directory / "deployment.env").write_text(self.env)
        (self.directory / "run.sh").write_text(self.flags)

    def test_endpoint_validation_and_ipv6(self):
        self.assertEqual(doctor.endpoint("[2001:db8::1]:8443"), ("2001:db8::1", 8443))
        self.assertEqual(doctor.endpoint("EXAMPLE.com"), ("example.com", 443))
        for value in ("https://example.com", "10.0.0.0/24", "example.com:0", "example.com:65536", "x;id", "a..example", "a@b", "$(id)"):
            with self.subTest(value=value), self.assertRaises(doctor.DoctorError):
                doctor.endpoint(value)

    def test_duplicate_and_dynamic_flags_rejected_without_execution(self):
        for text in ("  -transport wss\n  -transport xhttp\n", "  -sni $(touch /tmp/not-executed)\n", "  -sni $DOMAIN\n"):
            with self.assertRaises(doctor.DoctorError):
                doctor.parse_flags(text)
        self.assertEqual(doctor.parse_flags("  -ws-path '/safe-private-path' \\\n"), {"ws-path":"/safe-private-path"})

    def test_env_never_runs_shell(self):
        with self.assertRaises(doctor.DoctorError):
            doctor.parse_env("ROLE=origin\nROLE=egress\n")
        with self.assertRaises(doctor.DoctorError):
            doctor.parse_env("ROLE=$(id)\n")
        self.assertEqual(doctor.parse_env("ROLE=origin\nNAME=$'friendly name'\n"), {"ROLE": "origin"})

    def test_offline_has_no_network_or_subprocess_and_no_secrets(self):
        with mock.patch.object(doctor.socket, "create_connection", side_effect=AssertionError("network")), mock.patch.object(doctor.subprocess, "run", side_effect=AssertionError("subprocess")):
            report = doctor.diagnose(self.directory, offline=True)
        self.assertEqual(report["verdict"], "configuration-checked-not-network-tested")
        payload = json.dumps(report)
        for secret in (self.token, "/private-fixture-path", str(self.directory)):
            self.assertNotIn(secret, payload)
        self.assertFalse(report["target_payload_tested"])

    def test_offline_rejects_inconsistent_ech_and_fragment(self):
        self.flags = self.flags.replace("-ech-mode off", "-ech-mode strict").replace("-tls-fragment off", "-tls-fragment hello")
        self.save()
        with self.assertRaisesRegex(doctor.DoctorError, "cannot be combined"):
            doctor.diagnose(self.directory, offline=True)

    def test_redaction_covers_tokens_headers_private_keys_and_paths(self):
        raw = self.token + " /private-fixture-path Authorization: Bearer example\n-----BEGIN PRIVATE KEY-----\nprivate\n-----END PRIVATE KEY-----\n-token replacement"
        clean = doctor.redact(raw, [self.token, "/private-fixture-path"])
        for value in (self.token, "/private-fixture-path", "Bearer example", "\nprivate\n", "replacement"):
            self.assertNotIn(value, clean)

    def test_real_core_command_is_allowlisted_and_never_exposes_token_in_argv(self):
        flags = doctor.parse_flags(self.flags)
        flags.update({"access-config":"/do/not/use", "listen":"0.0.0.0:443", "token":self.token})
        result = subprocess.CompletedProcess([], 0, "authenticated carrier", "")
        with mock.patch.object(doctor.subprocess, "run", return_value=result) as run:
            check = doctor.core_probe("/trusted/ununknowntun", flags, "", self.token, "192.0.2.10", 443, "", 3, [self.token])
        args = run.call_args.args[0]
        self.assertIn("-check-tunnel", args)
        self.assertNotIn("-listen", args)
        self.assertNotIn("-access-config", args)
        self.assertNotIn(self.token, args)
        self.assertEqual(run.call_args.kwargs["env"]["UNUNKNOWNTUN_TOKEN"], self.token)
        self.assertEqual(check["status"], "pass")
        self.assertIn("client separately", check["next_step"])

    def test_token_file_prevents_unrelated_inherited_token(self):
        result = subprocess.CompletedProcess([], 1, "", "HTTP 404")
        with mock.patch.dict(os.environ, {"UNUNKNOWNTUN_TOKEN":"wrong", "V7_TOKEN":"wrong"}), mock.patch.object(doctor.subprocess, "run", return_value=result) as run:
            check = doctor.core_probe("/trusted/ununknowntun", {}, str(self.directory/"token"), self.token, "192.0.2.10", 443, "", 2, [self.token])
        self.assertNotIn("UNUNKNOWNTUN_TOKEN", run.call_args.kwargs["env"])
        self.assertNotIn("V7_TOKEN", run.call_args.kwargs["env"])
        self.assertEqual(check["status"], "fail")
        self.assertIn("cannot identify", check["next_step"])

    def test_core_timeout_is_reported_without_guessing_filter_root_cause(self):
        with mock.patch.object(doctor.subprocess, "run", side_effect=subprocess.TimeoutExpired("ununknowntun", 2)):
            result = doctor.core_probe("ununknowntun", {}, "", self.token, "192.0.2.10", 443, "", 1, [self.token])
        self.assertEqual(result["status"], "fail")
        self.assertIn("no definite", result["next_step"])

    def test_dns_is_bounded_and_literal_ips_need_no_resolver(self):
        with mock.patch.object(doctor.subprocess, "run", side_effect=AssertionError):
            self.assertEqual(doctor.resolve("192.0.2.10", 443, 1), ["192.0.2.10"])
        with mock.patch.object(doctor.subprocess, "run", return_value=subprocess.CompletedProcess([],0,'["192.0.2.10"]',"")) as run:
            self.assertEqual(doctor.resolve("edge.example",443,2), ["192.0.2.10"])
        self.assertEqual(run.call_args.kwargs["timeout"], 2)

    def test_ech_skips_plain_tls_but_uses_actual_core(self):
        self.flags = self.flags.replace("-ech-mode off", "-ech-mode strict")
        self.save()
        with mock.patch.object(doctor.socket, "create_connection", return_value=contextlib.nullcontext()), mock.patch.object(doctor, "tls_probe", side_effect=AssertionError("plain TLS")), mock.patch.object(doctor, "core_probe", return_value={"stage":"actual-carrier","status":"pass","elapsed_ms":12}) as probe:
            report = doctor.diagnose(self.directory)
        self.assertEqual(report["verdict"], "carrier-authenticated")
        self.assertEqual(probe.call_args.args[1]["ech-mode"], "strict")
        self.assertEqual(report["recommended_endpoint"], "192.0.2.10:443")

    def test_partial_results_recommend_only_authenticated_endpoint(self):
        probes = [{"stage":"actual-carrier","status":"fail","elapsed_ms":1}, {"stage":"actual-carrier","status":"pass","elapsed_ms":20}]
        with mock.patch.object(doctor.socket, "create_connection", return_value=contextlib.nullcontext()), mock.patch.object(doctor, "tls_probe", return_value={"stage":"ordinary-tls","status":"pass"}), mock.patch.object(doctor, "core_probe", side_effect=probes):
            report = doctor.diagnose(self.directory,"192.0.2.10,192.0.2.20")
        self.assertEqual(report["verdict"], "partial")
        self.assertEqual(report["recommended_endpoint"], "192.0.2.20:443")

    def test_pinned_profile_uses_actual_pin_check_not_unrelated_ca_policy(self):
        self.env += "CA_PATH=/stale-metadata-ca.pem\n"
        self.flags += "  -fingerprint " + "ab" * 32 + "\n"
        self.save()
        with mock.patch.object(doctor.socket, "create_connection", return_value=contextlib.nullcontext()), mock.patch.object(doctor, "tls_probe", side_effect=AssertionError("CA-only TLS")), mock.patch.object(doctor, "core_probe", return_value={"stage":"actual-carrier","status":"pass","elapsed_ms":12}) as probe:
            report = doctor.diagnose(self.directory)
        self.assertEqual(report["verdict"], "carrier-authenticated")
        self.assertEqual(probe.call_args.args[1]["fingerprint"], "ab" * 32)
        self.assertEqual(probe.call_args.args[6], "")

    def test_explicit_system_ca_overrides_stale_metadata(self):
        self.env += "CA_PATH=/stale-metadata-ca.pem\n"
        self.flags += "  -system-ca\n"
        self.save()
        with mock.patch.object(doctor.socket, "create_connection", return_value=contextlib.nullcontext()), mock.patch.object(doctor, "tls_probe", return_value={"stage":"ordinary-tls","status":"pass"}) as tls, mock.patch.object(doctor, "core_probe", return_value={"stage":"actual-carrier","status":"pass","elapsed_ms":12}) as probe:
            report = doctor.diagnose(self.directory)
        self.assertEqual(report["verdict"], "carrier-authenticated")
        self.assertEqual(probe.call_args.args[6], "")
        self.assertEqual(tls.call_args.args[3], "")

    def test_failed_certificate_is_never_suppressed(self):
        with mock.patch.object(doctor.socket, "create_connection", return_value=contextlib.nullcontext()), mock.patch.object(doctor, "tls_probe", side_effect=ssl.SSLCertVerificationError("certificate verify failed")), mock.patch.object(doctor,"core_probe", return_value={"stage":"actual-carrier","status":"fail"}):
            report = doctor.diagnose(self.directory)
        self.assertEqual(report["verdict"], "failed")
        self.assertIn("Edge and origin", report["endpoints"][0]["checks"][1]["next_step"])

    def test_candidate_limit_and_ranges_cannot_trigger_broad_scan(self):
        with self.assertRaises(doctor.DoctorError):
            doctor.diagnose(self.directory, ",".join("192.0.2."+str(i) for i in range(1,18)))
        with self.assertRaises(doctor.DoctorError):
            doctor.diagnose(self.directory,"192.0.2.0/24")

    def test_private_doh_url_and_ca_paths_are_redacted_in_actual_error(self):
        private_url = "https://resolver.example/query?key=private-value"
        private_ca = "/private/custom-authority.pem"
        self.flags += "  -ech-doh " + private_url + "\n  -ca " + private_ca + "\n"
        self.save()
        failed = subprocess.CompletedProcess([], 1, "", "ECH failed: " + private_url + " CA: " + private_ca)
        with mock.patch.object(doctor.socket, "create_connection", return_value=contextlib.nullcontext()), mock.patch.object(doctor, "tls_probe", return_value={"stage":"ordinary-tls","status":"pass"}), mock.patch.object(doctor.subprocess, "run", return_value=failed):
            report = doctor.diagnose(self.directory)
        payload = json.dumps(report)
        self.assertNotIn("private-value", payload)
        self.assertNotIn(private_ca, payload)
        self.assertEqual(report["verdict"], "failed")

    def test_report_permissions_and_no_overwrite_or_symlink(self):
        output = Path(self.temp.name)/"report.json"
        doctor.write_report(output, "{}\n")
        self.assertEqual(stat.S_IMODE(output.stat().st_mode),0o600)
        with self.assertRaises(FileExistsError):
            doctor.write_report(output,"changed")
        link = Path(self.temp.name)/"link.json"
        link.symlink_to(output)
        with self.assertRaises(OSError):
            doctor.write_report(link,"changed")
        self.assertEqual(output.read_text(),"{}\n")

    def test_cli_offline_report_has_honest_scope(self):
        with contextlib.redirect_stdout(io.StringIO()) as out:
            code = doctor.main(["--config-dir",str(self.directory),"--offline"])
        self.assertEqual(code,0)
        self.assertEqual(json.loads(out.getvalue())["scope"],"offline configuration checks")

    def test_egress_separates_local_origin_ca_from_public_edge_ca(self):
        self.env = self.env.replace("ROLE=origin","ROLE=egress")+"LOCAL_TLS_CA_PATH=/origin-ca.pem\nCA_PATH=/public-ca.pem\n"
        self.save()
        with mock.patch.object(doctor,"resolve",side_effect=lambda h,p,t:["127.0.0.1"] if h=="127.0.0.1" else ["192.0.2.20"]), mock.patch.object(doctor.socket,"create_connection",return_value=contextlib.nullcontext()), mock.patch.object(doctor,"tls_probe",return_value={"stage":"ordinary-tls","status":"pass"}) as tls, mock.patch.object(doctor,"core_probe",return_value={"stage":"actual-carrier","status":"pass","elapsed_ms":1}):
            report = doctor.diagnose(self.directory)
        self.assertEqual(tls.call_args_list[0].args[3],"/origin-ca.pem")
        self.assertEqual(tls.call_args_list[1].args[3],"/public-ca.pem")
        self.assertEqual([e["leg"] for e in report["endpoints"]],["local-origin","cdn-edge"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
