#!/usr/bin/env python3
"""Editor behavior/transaction regressions using private files and fake services."""
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import time
import unittest
from unittest import mock

spec = importlib.util.spec_from_file_location("editor_fixture", Path(__file__).with_name("test-editor-safety.py"))
fixture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture)
editor = fixture.editor


class TunnelEditorTests(unittest.TestCase):
    def setUp(self):
        self.fixture = fixture.EditorSafetyTests(methodName="runTest")
        self.fixture.setUp()
        self.addCleanup(self.fixture.doCleanups)
        self.instance = self.fixture.instance
        self.directory, self.root, self.state = self.fixture.directory, self.fixture.root, self.fixture.state

    def commit(self, plan):
        with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            self.instance.commit(plan)

    def proxy(self):
        site = self.fixture.configure_proxy()
        self.instance = self.fixture.instance
        return site

    def test_name_changes_display_only_keeps_pair_id_service_and_usage(self):
        plan = self.instance.plan("name", "New friendly name")
        self.commit(plan)
        self.assertEqual(self.instance.current("name"), "New friendly name")
        self.assertEqual(self.instance.env["PAIR_ID"], self.fixture.env["PAIR_ID"])
        self.assertEqual(self.instance.id, "sample")
        self.assertFalse(plan["restart"])
        self.assertNotIn(("systemctl", "restart", "ununknowntun@sample"), [c.args for c in self.instance.run.call_args_list])
        self.assertEqual((self.state / "access-state.json").read_text(), "live-use-must-never-be-restored")

    def test_padding_and_limit_changes_preserve_other_flags(self):
        for field, value, flag in (("pad", "0.45", "pad"), ("sessions", "12", "sessions"), ("sessions_min", "3", "sessions-min"), ("max_streams", "1000", "max-streams"), ("max_memory_mb", "512", "max-memory"), ("profile", "firefox", "utls-profile"), ("transport", "wss", "transport"), ("tls_min", "1.2", "tls-min-version"), ("write_timeout", "30s", "write-timeout"), ("edge_timeout", "60s", "edge-write-timeout")):
            with self.subTest(field=field):
                original = self.instance.script
                self.commit(self.instance.plan(field, value))
                expected = str(512 * 1048576) if field == "max_memory_mb" else value
                self.assertEqual(editor.read_flag(self.instance.script, flag), expected)
                for untouched in ("access-config", "access-state", "ws-path", "target", "stats"):
                    self.assertEqual(editor.read_flag(self.instance.script, untouched), editor.read_flag(original, untouched))

    def test_invalid_ranges_and_injection_rejected_at_field(self):
        for field, value in (("pad", "nan"), ("pad", "1.1"), ("sessions", "0"), ("sessions", "65"), ("max_streams", "-2"), ("write_timeout", "0"), ("foreign_domain", "example.com;evil"), ("ws_path", "/path\nfoo"), ("token", "short"), ("entry_ports", "443,443"), ("iran_ip", "127.0.0.1")):
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                self.instance.plan(field, value)

    def test_cross_field_constraints_checked_before_commit(self):
        for field, value in (("sessions_min", "9"), ("sessions", "1"), ("max_streams", "999999"), ("h2_path", "/transport-websocket-path")):
            with self.subTest(field=field), self.assertRaises(ValueError):
                self.instance.plan(field, value)
        self.assertFalse(self.instance.run.called)

    def test_foreign_domain_updates_origin_sni_ws_host_and_proxied_connect(self):
        self.fixture.env["FOREIGN_PROXY_PROVIDER"] = "arvan"
        self.fixture.write_fixture()
        self.instance.refresh()
        self.commit(self.instance.plan("foreign_domain", "new-foreign.example"))
        self.assertEqual(editor.read_flag(self.instance.script, "sni"), "new-foreign.example")
        self.assertEqual(editor.read_flag(self.instance.script, "ws-host"), "new-foreign.example")
        self.assertEqual(editor.read_flag(self.instance.script, "connect"), "new-foreign.example:443,new-foreign.example:8443")

    def test_direct_foreign_domain_keeps_pinned_ip_connect(self):
        self.commit(self.instance.plan("foreign_domain", "new-foreign.example"))
        self.assertEqual(editor.read_flag(self.instance.script, "connect"), "203.0.113.2:443,203.0.113.2:8443")
        self.assertEqual(editor.read_flag(self.instance.script, "sni"), "new-foreign.example")

    def test_domain_rename_preserves_customer_sites_permissions_and_ledger(self):
        site = self.proxy()
        site.chmod(0o640)
        old_ledger = (self.state / "access-state.json").read_bytes()
        self.instance.active.return_value = True
        with mock.patch.object(editor.tls, "validate_certificate", return_value=("/new/fullchain.pem", "/new/key.pem")):
            plan = self.instance.plan("entry_domain", "replacement.example", ("/new/fullchain.pem", "/new/key.pem"))
        self.commit(plan)
        new = self.fixture.available / "ununknowntun-replacement.example.conf"
        self.assertFalse(site.exists())
        self.assertFalse((self.fixture.enabled / site.name).is_symlink())
        self.assertEqual((self.fixture.enabled / new.name).resolve(), new.resolve())
        self.assertEqual(new.stat().st_mode & 0o777, 0o640)
        text = new.read_text()
        self.assertIn("server_name replacement.example;", text)
        self.assertIn("/gdt-c/customer-route-0123456789abcdef", text)
        self.assertIn("http://127.0.0.1:19102/original-client-websocket", text)
        self.assertEqual((self.state / "access-state.json").read_bytes(), old_ledger)
        self.assertIn(("systemctl", "reload", "nginx"), [c.args for c in self.instance.run.call_args_list])

    def test_domain_rename_does_not_enable_disabled_nginx_site(self):
        site = self.proxy()
        (self.fixture.enabled / site.name).unlink()
        with mock.patch.object(editor.tls, "validate_certificate", return_value=("/new/cert", "/new/key")):
            self.commit(self.instance.plan("entry_domain", "replacement.example", ("/new/cert", "/new/key")))
        self.assertFalse((self.fixture.enabled / "ununknowntun-replacement.example.conf").exists())

    def test_bad_certificate_or_domain_collision_makes_no_changes(self):
        site = self.proxy()
        before = site.read_bytes()
        with mock.patch.object(editor.tls, "validate_certificate", side_effect=ValueError("hostname mismatch")), self.assertRaises(ValueError):
            self.instance.plan("entry_domain", "replacement.example", ("/new/cert", "/new/key"))
        self.assertEqual(site.read_bytes(), before)
        self.instance.run.return_value = subprocess.CompletedProcess([], 0, "server_name replacement.example;\n", "")
        with self.assertRaises(ValueError):
            self.instance.plan("entry_domain", "replacement.example", ("/new/cert", "/new/key"))

    def test_certificate_replacement_never_rewrites_private_key_or_exports_it(self):
        site = self.proxy()
        with mock.patch.object(editor.tls, "validate_certificate", return_value=("/new/cert", "/new/key")):
            plan = self.instance.certificate_plan("/new/cert", "/new/key")
        self.assertEqual(list(plan["changes"]), [site])
        self.assertIsNone(plan["update"])
        self.commit(plan)
        self.assertIn("ssl_certificate_key /new/key;", site.read_text())

    def test_failed_nginx_check_restores_site_name_links_and_metadata(self):
        site = self.proxy()
        before = site.read_bytes()
        original_env = (self.directory / "deployment.env").read_bytes()
        with mock.patch.object(editor.tls, "validate_certificate", return_value=("/new/cert", "/new/key")):
            plan = self.instance.plan("entry_domain", "replacement.example", ("/new/cert", "/new/key"))
        def run(*args, **kwargs):
            if args == ("nginx", "-t"):
                raise subprocess.CalledProcessError(1, args)
            return subprocess.CompletedProcess(args, 0, "", "")
        self.instance.run.side_effect = run
        with self.assertRaises(subprocess.CalledProcessError):
            self.commit(plan)
        self.assertEqual(site.read_bytes(), before)
        self.assertEqual((self.fixture.enabled / site.name).resolve(), site.resolve())
        self.assertFalse((self.fixture.available / "ununknowntun-replacement.example.conf").exists())
        self.assertEqual((self.directory / "deployment.env").read_bytes(), original_env)

    def test_running_service_restart_and_failed_restart_rolls_back_only_selected(self):
        self.instance.active.return_value = True
        before = (self.directory / "run.sh").read_bytes()
        restart_count = 0
        def run(*args, **kwargs):
            nonlocal restart_count
            if args == ("systemctl", "restart", self.instance.service):
                restart_count += 1
                if restart_count == 1:
                    raise subprocess.CalledProcessError(1, args)
            return subprocess.CompletedProcess(args, 0, "", "")
        self.instance.run.side_effect = run
        with self.assertRaises(subprocess.CalledProcessError):
            self.commit(self.instance.plan("pad", "0.5"))
        self.assertEqual(restart_count, 2)
        self.assertEqual((self.directory / "run.sh").read_bytes(), before)
        self.assertEqual((self.state / "access-state.json").read_text(), "live-use-must-never-be-restored")

    def test_stopped_service_never_starts_after_edit(self):
        self.commit(self.instance.plan("pad", "0.5"))
        self.assertFalse(self.instance.wait_service.called)
        self.assertFalse(any(c.args[:2] in (("systemctl", "restart"), ("systemctl", "start")) for c in self.instance.run.call_args_list))

    def test_cancel_after_preview_makes_no_files(self):
        before = (self.directory / "deployment.env").read_bytes()
        with mock.patch("builtins.input", side_effect=["Different name", "n"]), contextlib.redirect_stdout(io.StringIO()):
            self.instance.edit("name")
        self.assertEqual((self.directory / "deployment.env").read_bytes(), before)
        self.assertFalse((self.root / "install/backups").exists())

    def test_invalid_padding_retries_only_that_prompt(self):
        with mock.patch("builtins.input", side_effect=["bad", "2.0", "0.4", "y"]) as entered, contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            self.instance.edit("pad")
        self.assertEqual(self.instance.current("pad"), "0.4")
        self.assertEqual(entered.call_count, 4)
        self.assertTrue(all("pad" in c.args[0] for c in entered.call_args_list[:3]))

    def test_existing_inline_or_duplicate_flags_are_not_overwritten(self):
        for script in (self.fixture.script.replace("-connect 203.0.113.2:443,203.0.113.2:8443", "-connect old:443 -sessions 7"), self.fixture.script + "  -connect duplicate:443\n"):
            with self.subTest(script=script), self.assertRaises(ValueError):
                editor.set_flag(script, "connect", "new:443")

    def test_quoted_values_and_final_flag_layout_are_preserved(self):
        source = "#!/bin/sh\nexec /bin/false \\\n  -mode origin \\\n  -connect 'old.example:443' \\\n  -stats 5s\n"
        self.assertEqual(editor.read_flag(source, "connect"), "old.example:443")
        modified = editor.set_flag(source, "connect", "new.example:443")
        self.assertIn("  -stats 5s\n", modified)
        self.assertEqual(editor.read_flag(editor.set_flag(source, "stats", "10s"), "stats"), "10s")

    def test_new_sync_code_is_archived_private_not_only_last(self):
        first = self.instance.plan("iran_ip", "203.0.113.11")
        self.commit(first)
        second = self.instance.plan("foreign_ip", "203.0.113.12")
        self.commit(second)
        files = list(self.directory.glob("edit-update-*.txt"))
        self.assertEqual(len(files), 2)
        self.assertEqual({p.read_text().strip() for p in files}, {first["update"], second["update"]})
        self.assertTrue(all(p.stat().st_mode & 0o777 == 0o600 for p in files))

    def test_wait_service_requires_fresh_ack_and_stable_invocation(self):
        self.instance.wait_service = editor.Editor.wait_service.__get__(self.instance)
        self.instance.active.return_value = True
        self.instance.run.return_value = subprocess.CompletedProcess([], 0, "a" * 32, "")
        status = self.state / "access-state.json.status.json"
        status.write_text(json.dumps({"config_revision": hashlib.sha256((self.directory / "access.json").read_bytes()).hexdigest(), "running": True}))
        with mock.patch.object(editor.time, "sleep"):
            self.instance.wait_service(status.stat().st_mtime_ns - 1)
            with self.assertRaises(RuntimeError):
                self.instance.wait_service(status.stat().st_mtime_ns + 1)
            self.instance.run.side_effect = [subprocess.CompletedProcess([], 0, "a" * 32, ""), subprocess.CompletedProcess([], 0, "b" * 32, "")]
            with self.assertRaises(RuntimeError):
                self.instance.wait_service(status.stat().st_mtime_ns - 1)

    def test_site_file_in_enabled_directory_is_not_replaced(self):
        site = self.proxy()
        link = self.fixture.enabled / site.name
        link.unlink()
        link.write_text("administrator site")
        with self.assertRaises(ValueError):
            self.instance.plan("entry_path", "/replacement-client-path")
        self.assertEqual(link.read_text(), "administrator site")

    def test_origin_cannot_pick_unsupported_foreign_arvan_ports(self):
        self.fixture.env["FOREIGN_PROXY_PROVIDER"] = "arvan"
        self.fixture.write_fixture()
        with self.assertRaises(ValueError):
            self.instance.plan("foreign_ports", "8443")

    def test_unknown_foreign_metadata_requires_first_edit_on_iran(self):
        self.fixture.env.update(ROLE="egress", IRAN_IP="")
        self.fixture.write_fixture()
        with self.assertRaisesRegex(ValueError, "Iran first"):
            self.instance.plan("iran_ip", "203.0.113.4")

    def test_unchanged_value_returns_without_retry_or_backup(self):
        with mock.patch("builtins.input", return_value="") as entered, contextlib.redirect_stdout(io.StringIO()):
            self.instance.edit("name")
        self.assertEqual(entered.call_count, 1)
        self.assertFalse((self.root / "install/backups").exists())

    def test_bad_update_code_retries_only_code_prompt(self):
        data = self.fixture.valid_data()
        with mock.patch("builtins.input", side_effect=["bad-code", self.fixture.signed(data), "y"]) as entered, contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            self.instance.menu("apply-update")
        self.assertEqual(self.instance.current("foreign_ip"), "203.0.113.3")
        self.assertEqual(entered.call_count, 3)
        self.assertEqual(entered.call_args_list[0], entered.call_args_list[1])

    def test_target_port_rejects_transport_and_other_tunnel_ports_before_probe(self):
        self.fixture.env.update(ROLE="egress", WSS_BACKEND_PORT="18080", H2_BACKEND_PORT="18081")
        self.fixture.write_fixture()
        other = self.directory.parent / "other"
        other.mkdir()
        (other / "ports.list").write_text("19010\n")
        with mock.patch.object(editor.socket, "create_connection") as connect:
            for port in ("80", "443", "18080", "18081", "19010"):
                with self.subTest(port=port), self.assertRaises(ValueError):
                    self.instance.plan("target_port", port)
            connect.assert_not_called()
            plan = self.instance.plan("target_port", "19011")
            connect.assert_called_once_with(("127.0.0.1", 19011), timeout=3)
        self.assertIn(b"-allow 127.0.0.1:19011", plan["changes"][self.directory / "run.sh"])
        self.commit(plan)
        self.assertEqual(self.instance.env["H2_BACKEND_PORT"], "18081")
        self.assertIn("18081", (self.directory / "ports.list").read_text().splitlines())

    def test_env_parser_preserves_numbered_identifiers_without_execution(self):
        path = self.root / "numbered.env"
        path.write_text("H2_BACKEND_PORT=18081\n2_INVALID=bad\nLOWERcase=bad\nNAME='$(touch /unexpected)'\n")
        values = editor.access.read_env(path)
        self.assertEqual(values, {"H2_BACKEND_PORT": "18081", "NAME": "$(touch /unexpected)"})

    def test_menu_labels_hide_unavailable_direct_iran_fields(self):
        captured = io.StringIO()
        with mock.patch("builtins.input", return_value="0"), contextlib.redirect_stdout(captured):
            self.instance.menu("menu")
        text = captured.getvalue()
        self.assertIn("Tunnel display name", text)
        self.assertIn("Maximum streams", text)
        self.assertNotIn(") Iran entry domain", text)
        self.assertNotIn(") SSL certificate", text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
