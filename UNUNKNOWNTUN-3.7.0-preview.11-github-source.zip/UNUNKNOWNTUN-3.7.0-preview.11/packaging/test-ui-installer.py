#!/usr/bin/env python3
"""Offline launch, helper-install and rollback regressions. No server mutation."""
import ast
import importlib.util
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parent.parent
SOURCE = (ROOT / 'packaging/full-installer.template.sh').read_text()
MANAGER = SOURCE.split("<<'CTL'\n", 1)[1].split('\nCTL\n', 1)[0]
DEFINITIONS, DISPATCH = MANAGER.split('\ncommand_name="${1:-help}"', 1)
DISPATCH = '\ncommand_name="${1:-help}"' + DISPATCH
LAUNCH = SOURCE.split("<<'UI_LAUNCH'\n", 1)[1].split('\nUI_LAUNCH\n', 1)[0]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class UIInstallerTests(unittest.TestCase):
    def fixture(self):
        module = load('ui_install_fixture', ROOT / 'packaging/test-full-installer.py')
        fixture = module.InstallerTests(methodName='runTest')
        fixture.setUp()
        self.addCleanup(fixture.tearDown)
        return fixture

    def test_renderer_embeds_exact_ui_with_one_marker(self):
        tree = ast.parse((ROOT / 'packaging/render-complete.py').read_text())
        entries = next(ast.literal_eval(node.value) for node in tree.body
                       if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'helpers' for t in node.targets))
        entry = next(entry for entry in entries if entry[1] == '__TERMINAL_UI_SOURCE__')
        self.assertEqual(SOURCE.count(entry[1]), 1)
        text = (ROOT / 'packaging' / entry[0]).read_text().rstrip()
        self.assertEqual(text, (ROOT / 'ui/ununknowntun-ui.py').read_text().rstrip())
        self.assertNotIn(entry[2], text.splitlines())
        rendered = SOURCE.replace(entry[1], text)
        self.assertEqual(rendered.split("<<'TERMINAL_UI_PY'\n", 1)[1].split('\nTERMINAL_UI_PY\n', 1)[0], text)
        compile(text, 'embedded-ui', 'exec')

    def test_manager_keeps_arguments_stdin_and_does_not_select_or_mutate(self):
        script = DEFINITIONS + '''
need_root() { :; }
select_id() { echo forbidden-tunnel-selection >&2; exit 91; }
manager_lock() { echo forbidden-lock >&2; exit 92; }
systemctl() { echo forbidden-service >&2; exit 93; }
function /usr/bin/python3() { printf '<%s>\\n' "$@"; local line; read -r line <&3; printf 'stdin=%s\\n' "$line"; }
INSTALL_DIR=/isolated/ununknowntun
''' + DISPATCH
        args = ['ui', '--preview', 'tunnels', 'literal space;$(false)']
        result = subprocess.run(['bash', '-c', script, 'ui-dispatch', *args], input='user input\n',
                                capture_output=True, text=True, timeout=5)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.splitlines(), ['<-I>', '<->', '</isolated/ununknowntun/share/ununknowntun-ui.py>',
                         *['<' + arg + '>' for arg in args[1:]], 'stdin=user input'])
        self.assertEqual(result.stderr, '')

    def test_standalone_and_installed_launchers_are_identical(self):
        menu = SOURCE.split("<<'UI_MENU_LAUNCH'\n", 1)[1].split('\nUI_MENU_LAUNCH\n', 1)[0]
        self.assertEqual(menu, LAUNCH)
        body = SOURCE.split('run_terminal_ui() (', 1)[1].split('\n)\n', 1)[0]
        self.assertIn('trap', body)
        self.assertIn('mktemp -d /run/ununknowntun-ui.XXXXXXXX', body)
        for forbidden in ('install_manager', 'install_binary', 'systemctl', 'installer_lock', 'migrate_legacy', 'apt-get'):
            self.assertNotIn(forbidden, body)
        self.assertIn('ui) shift; run_terminal_ui "$@"', SOURCE)

    def test_icmp_manager_routes_without_ordinary_migration(self):
        fixture = self.fixture()
        result = fixture.run_shell('''
run_terminal_ui() { printf 'icmp-opened:%s\\n' "$*"; }
require_root() { :; }
management_menu() { echo forbidden-legacy >&2; exit 92; }
install_manager() { echo forbidden-install >&2; exit 93; }
main_menu
''', stdin='3\n2\n')
        self.assertTrue(result.stdout.rstrip().endswith('icmp-opened:--icmp-manage'))
        self.assertEqual(fixture.log.read_text(), '')

    def test_installed_icmp_route_preserves_args_and_stdin(self):
        script = DEFINITIONS + '''
need_root() { :; }
select_id() { exit 91; }
manager_lock() { exit 92; }
function /usr/bin/python3() { printf '<%s>\\n' "$@"; local line; read -r line <&3; printf 'stdin=%s\\n' "$line"; }
INSTALL_DIR=/isolated/ununknowntun
''' + DISPATCH
        result = subprocess.run(['bash', '-c', script, 'icmp-dispatch', 'direct-icmp-manage', '--list'],
                                input='read only\n', capture_output=True, text=True, timeout=5)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(result.stdout.splitlines(), ['<-I>', '<->', '</isolated/ununknowntun/share/ununknowntun-ui.py>',
                         '<--icmp-manage>', '<--list>', 'stdin=read only'])

    def test_main_menu_nine_reaches_ui_without_installing(self):
        fixture = self.fixture()
        result = fixture.run_shell('''
run_terminal_ui() { printf 'ui-opened\\n'; }
management_menu() { echo forbidden-management >&2; exit 92; }
install_manager() { echo forbidden-install >&2; exit 93; }
main_menu
''', stdin='9\n')
        self.assertIn('9) Control Room UI', result.stdout)
        self.assertTrue(result.stdout.rstrip().endswith('ui-opened'))
        self.assertEqual(fixture.log.read_text(), '')

    def test_install_replaces_link_preserves_target_and_exact_ui(self):
        fixture = self.fixture()
        share = fixture.root / 'install/share'
        share.mkdir(parents=True)
        target = fixture.root / 'untouched'
        target.write_text('keep this')
        (share / 'ununknowntun-ui.py').symlink_to(target)
        fixture.run_shell('install_terminal_ui\n')
        ui = share / 'ununknowntun-ui.py'
        self.assertFalse(ui.is_symlink())
        self.assertEqual(ui.read_text().rstrip(), (ROOT / 'ui/ununknowntun-ui.py').read_text().rstrip())
        self.assertEqual(stat.S_IMODE(ui.stat().st_mode), 0o755)
        console = share / 'direct-icmp-console.py'
        self.assertEqual(console.read_text().rstrip(), (ROOT / 'packaging/direct-icmp-console.py').read_text().rstrip())
        self.assertEqual(stat.S_IMODE(console.stat().st_mode), 0o755)
        self.assertEqual(target.read_text(), 'keep this')
        self.assertEqual(list(share.glob('.ui-stage.*')), [])
        self.assertEqual(fixture.log.read_text(), '')

    def test_install_rejects_symlinked_share_without_touching_target(self):
        fixture = self.fixture()
        install = fixture.root / 'install'
        install.mkdir()
        target = fixture.root / 'unowned-share'
        target.mkdir()
        (install / 'share').symlink_to(target, target_is_directory=True)
        fixture.run_shell('install_terminal_ui\n', expected=1)
        self.assertEqual(list(target.iterdir()), [])

    def test_failed_transaction_restores_previous_ui(self):
        fixture = self.fixture()
        share = fixture.root / 'install/share'
        share.mkdir(parents=True)
        ui = share / 'ununknowntun-ui.py'
        ui.write_text('# previous ui\n')
        console = share / 'direct-icmp-console.py'
        console.write_text('# previous console\n')
        fixture.run_shell('transaction_begin origin\ninstall_terminal_ui\nfalse\n', expected=1)
        self.assertEqual(ui.read_text(), '# previous ui\n')
        self.assertEqual(console.read_text(), '# previous console\n')
        self.assertFalse(any('.ui-stage.' in str(path) for path in share.iterdir()))
        self.assertNotIn('systemctl restart', fixture.log.read_text())

    def test_normal_install_refreshes_ui_and_advertises_command(self):
        fixture = self.fixture()
        fixture.run_shell('mkdir -p "$INSTALL_DIR"\ninstall_manager\n')
        self.assertEqual((fixture.root / 'install/share/ununknowntun-ui.py').read_text().rstrip(),
                         (ROOT / 'ui/ununknowntun-ui.py').read_text().rstrip())
        manager = fixture.root / 'bin/ununknowntunctl'
        result = subprocess.run(['bash', str(manager), 'help'], capture_output=True, text=True, timeout=5)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('  ui            Open the Control Room', result.stdout)
        self.assertEqual(fixture.log.read_text(), '')


class UILaunchTrustTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix='ununknowntun-ui-launch-')
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.file = self.root / 'ununknowntun-ui.py'
        self.file.write_text('# never executed\n')
        self.file.chmod(0o755)
        self.bad_owner = self.bad_mode = None
        self.real_lstat = Path.lstat

    def fixture_stat(self, path):
        info = self.real_lstat(path)
        mode = info.st_mode
        if path in self.root.parents:
            mode = stat.S_IFDIR | 0o755
        if path == self.bad_mode:
            mode |= 0o022
        return SimpleNamespace(st_uid=1000 if path == self.bad_owner else 0, st_mode=mode, st_size=info.st_size)

    def execute(self):
        with mock.patch.object(Path, 'lstat', lambda path: self.fixture_stat(path)), \
                mock.patch.object(sys, 'argv', ['launcher', str(self.file), '--preview', 'doctor']), \
                mock.patch.object(os, 'execve') as execute, mock.patch.object(os, 'dup2') as dup, \
                mock.patch.object(os, 'close') as close, \
                mock.patch.dict(os.environ, {'PYTHONPATH': '/untrusted', 'LD_PRELOAD': 'bad', 'BASH_ENV': 'bad',
                                            'UNUNKNOWNTUN_TOKEN': 'private', 'TERM': 'xterm-256color'}):
            exec(compile(LAUNCH, 'ui-launch', 'exec'), {'__name__': '__main__'})
            dup.assert_called_once_with(3, 0)
            close.assert_called_once_with(3)
            return execute.call_args

    def test_isolated_runtime_cleans_environment_and_preserves_terminal(self):
        call = self.execute()
        self.assertEqual(call.args[1][1:], ['-I', str(self.file), '--preview', 'doctor'])
        self.assertEqual(call.args[2]['TERM'], 'xterm-256color')
        for key in ('PYTHONPATH', 'LD_PRELOAD', 'BASH_ENV', 'UNUNKNOWNTUN_TOKEN'):
            self.assertNotIn(key, call.args[2])

    def test_untrusted_file_owner_rejected(self):
        self.bad_owner = self.file
        with self.assertRaises(SystemExit):
            self.execute()

    def test_writable_parent_rejected(self):
        self.bad_mode = self.root
        with self.assertRaises(SystemExit):
            self.execute()

    def test_symlink_rejected(self):
        target = self.root / 'target'
        target.write_text('never execute')
        self.file.unlink()
        self.file.symlink_to(target)
        with self.assertRaises(SystemExit):
            self.execute()

    def test_directory_instead_of_ui_rejected(self):
        self.file.unlink()
        self.file.mkdir()
        with self.assertRaises(SystemExit):
            self.execute()


if __name__ == '__main__':
    unittest.main(verbosity=2)
