#!/usr/bin/env python3
"""Isolated upgrade regression tests; no host services, package or firewall writes."""
import importlib.util
import hashlib
import json
from pathlib import Path
import shlex
import unittest


spec = importlib.util.spec_from_file_location("installer_upgrade_fixture", Path(__file__).with_name("test-full-installer.py"))
fixture_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fixture_module)


class UpgradeTests(unittest.TestCase):
    # Composition deliberately avoids inheriting/discovering the installer
    # suite again. Its temp-directory safety and mocked host commands are reused.
    def setUp(self):
        self.fixture = fixture_module.InstallerTests(methodName="runTest")
        self.fixture.setUp()
        self.root = self.fixture.root
        self.directory = self.root / "config-root/tunnels/test"
        self.directory.mkdir()
        self.state = self.root / "state/test"
        self.state.mkdir()
        self.site = self.root / "nginx-available/ununknowntun-entry.example.conf"
        self.binary = self.root / "bin/ununknowntun"
        self.binary.write_text("original binary")
        self.metadata = self.directory / "deployment.env"
        self.run = self.directory / "run.sh"

    def tearDown(self):
        self.fixture.tearDown()

    def prepare(self, role="origin", provider="arvan", with_site=True, accounting=True):
        env = {
            "ROLE": role, "TUNNEL_ID": "test", "TUNNEL_NAME": "Existing named tunnel",
            "FOREIGN_PROXY_PROVIDER": provider, "IRAN_PROXY_PROVIDER": "arvan" if with_site else "none",
            "FOREIGN_DOMAIN": "entry.example", "IRAN_ENTRY_DOMAIN": "entry.example",
            "FOREIGN_IP": "203.0.113.8", "IRAN_IP": "198.51.100.9", "FOREIGN_PORTS": "443",
            "LOCAL_PORTS": "19080" if with_site else "2053,2054", "PAIR_ID": "a1b2c3d4e5f60718",
            "IRAN_ENTRY_PATH": "/existing-private-entry-path", "CUSTOM_METADATA": "preserve me",
            "NGINX_SITE": str(self.site) if with_site else "",
        }
        self.metadata.write_text("".join(f"{key}={shlex.quote(value)}\n" for key, value in env.items()))
        self.run.write_text(
            "#!/bin/sh\nexec /usr/local/bin/ununknowntun \\\n"
            f"  -mode {role} \\\n"
            "  -transport auto \\\n"
            "  -listen 127.0.0.1:19080 \\\n"
            "  -target 127.0.0.1:18082 \\\n"
            "  -token-file /etc/ununknowntun/tunnels/test/token \\\n"
            "  -sessions 17 \\\n"
            "  -stats 11s\n"
        )
        self.run.chmod(0o750)
        if with_site:
            self.site.write_text(
                "server {\n    listen 443 ssl http2;\n    server_name entry.example;\n"
                "    ssl_protocols TLSv1.3;\n    ssl_certificate /custom/fullchain.pem;\n"
                "    ssl_certificate_key /custom/privkey.pem;\n"
                "    location = /keep-customer-route { proxy_pass http://127.0.0.1:19101; }\n"
                "    location / { return 200; }\n}\n"
            )
        if accounting:
            (self.directory / "access.json").write_text(json.dumps({
                "version": 1, "total_quota_bytes": 500000000000,
                "accounts": [{"id": "existing-customer", "name": "Keep", "listen": "127.0.0.1:19080", "quota_bytes": 100000000000, "enabled": True}],
            }))
            (self.state / "access-state.json").write_text("existing durable accounting must never be rewritten")
            (self.directory / "access-routes.json").write_text('{"existing-customer":"/keep-customer-route"}')
        (self.directory / "token").write_text("existing secret token")

    def test_upgrade_adds_websocket_cache_and_auth_headers_idempotently(self):
        self.prepare(role="egress")
        site = self.site.read_text().replace(
            "    location / { return 200; }",
            "    location = /old-ws-route {\n        proxy_set_header Upgrade $http_upgrade;\n        proxy_buffering off;\n    }\n    location / { return 200; }")
        self.site.write_text(site)
        self.shell("patch_upgrade_configuration\n")
        changed = self.site.read_text()
        self.assertIn('proxy_cache off;', changed)
        self.assertIn('add_header Cache-Control "no-store" always;', changed)
        self.assertIn('proxy_set_header Authorization $http_authorization;', changed)
        self.shell("patch_upgrade_configuration\n")
        self.assertEqual(self.site.read_text(), changed)

    def shell(self, body, expected=0, stdin=None):
        context = '''
CONFIG_DIR="$ROOT/config-root/tunnels/test"
TUNNEL_STATE_DIR="$ROOT/state/test"
SERVICE=ununknowntun@test
SCRIPT_PATH="$INSTALL_DIR/share/ununknowntun-easy.sh"
require_root() { :; }
acquire_install_lock() { :; }
detect_os() { :; }
migrate_legacy_install_if_needed() { :; }
ensure_preflight_tools() { :; }
prepare_tunnel_context() { :; }
write_common_files() {
    TX_SERVICE_TOUCHED=1
    mkdir -p "$INSTALL_DIR/share" "$TUNNEL_STATE_DIR"
    printf 'replacement binary' > "$BIN_PATH"
    printf 'write_common_files\\n' >> "$MOCK_LOG"
}
initialize_customer_access() {
    printf 'initialize quota=%s\\n' "$2" >> "$MOCK_LOG"
    printf '{"version":1,"total_quota_bytes":0,"accounts":[]}' > "$CONFIG_DIR/access.json"
    printf 'new initial ledger' > "$TUNNEL_STATE_DIR/access-state.json"
    printf 'new initial lock' > "$TUNNEL_STATE_DIR/access-state.json.lock"
    printf 'new initial status' > "$TUNNEL_STATE_DIR/access-state.json.status.json"
}
'''
        return self.fixture.run_shell(context + body, expected=expected, stdin=stdin)

    def test_origin_patch_is_idempotent_and_preserves_metadata_routes_and_ledger(self):
        self.prepare()
        before_metadata = self.metadata.read_bytes()
        before_ledger = (self.state / "access-state.json").read_bytes()
        before_routes = (self.directory / "access-routes.json").read_bytes()
        self.shell("patch_upgrade_configuration\n")
        first_run, first_site = self.run.read_bytes(), self.site.read_bytes()
        self.shell("patch_upgrade_configuration\n")
        self.assertEqual(self.run.read_bytes(), first_run)
        self.assertEqual(self.site.read_bytes(), first_site)
        launch = first_run.decode()
        for expected in ("-transport wss", "-pad 0", "-tls-min-version 1.3", "-sessions 17", "-stats 11s", "-target 127.0.0.1:18082"):
            self.assertIn(expected, launch)
        self.assertEqual(launch.count("-access-config"), 1)
        self.assertEqual(launch.count("-access-state"), 1)
        self.assertEqual(self.run.stat().st_mode & 0o777, 0o750)
        self.assertIn("ssl_protocols TLSv1.3;", first_site.decode())
        self.assertIn("ssl_certificate /custom/fullchain.pem;", first_site.decode())
        self.assertIn("/keep-customer-route", first_site.decode())
        self.assertEqual(first_site.decode().count("# UNUNKNOWNTUN_CUSTOMER_ROUTES"), 1)
        self.assertTrue(self.metadata.read_bytes().startswith(before_metadata))
        self.assertIn("TRANSPORT=wss", self.metadata.read_text())
        self.assertEqual((self.state / "access-state.json").read_bytes(), before_ledger)
        self.assertEqual((self.directory / "access-routes.json").read_bytes(), before_routes)

    def test_direct_origin_migrates_auto_transport_preserves_tls13_minimum(self):
        self.prepare(provider="none", with_site=False)
        self.shell("patch_upgrade_configuration\n")
        self.assertIn("-transport wss", self.run.read_text())
        self.assertIn("-tls-min-version 1.3", self.run.read_text())

    def test_egress_patch_migrates_only_retired_launch_fields_without_customer_marker(self):
        self.prepare(role="egress", accounting=False)
        original = self.run.read_bytes()
        self.shell("patch_upgrade_configuration\n")
        expected = original.replace(b"-transport auto", b"-transport wss").replace(b"-mode egress \\\n", b"-mode egress \\\n  -pad 0 \\\n")
        self.assertEqual(self.run.read_bytes(), expected)
        self.assertIn("ssl_protocols TLSv1.3;", self.site.read_text())
        self.assertNotIn("UNUNKNOWNTUN_CUSTOMER_ROUTES", self.site.read_text())

    def test_duplicate_launch_flags_fail_before_rewriting_launch(self):
        self.prepare(with_site=False)
        self.run.write_text(self.run.read_text().replace("  -transport auto", "  -transport auto \\\n  -transport auto"))
        original = self.run.read_bytes()
        result = self.shell("patch_upgrade_configuration\n", expected=1)
        self.assertIn("Duplicate launch flag", result.stderr)
        self.assertEqual(self.run.read_bytes(), original)

    def test_unrecognized_launch_is_rejected_without_overwrite(self):
        self.prepare(with_site=False)
        self.run.write_text("#!/bin/sh\nexec custom-program --special-mode\n")
        original = self.run.read_bytes()
        result = self.shell("patch_upgrade_configuration\n", expected=1)
        self.assertIn("Unrecognized managed origin", result.stderr)
        self.assertEqual(self.run.read_bytes(), original)

    def test_stopped_upgrade_keeps_existing_accounts_and_consumption(self):
        self.prepare()
        original_access = (self.directory / "access.json").read_bytes()
        original_ledger = (self.state / "access-state.json").read_bytes()
        original_metadata = self.metadata.read_bytes()
        self.shell("MOCK_ACTIVE=inactive\nupgrade_existing\n", stdin="y\n")
        log = self.fixture.log.read_text()
        self.assertNotIn("systemctl restart", log)
        self.assertNotIn("systemctl start", log)
        self.assertNotIn("systemctl enable", log)
        self.assertNotIn("initialize quota", log)
        self.assertEqual((self.directory / "access.json").read_bytes(), original_access)
        self.assertEqual((self.state / "access-state.json").read_bytes(), original_ledger)
        self.assertTrue(self.metadata.read_bytes().startswith(original_metadata))

    def test_active_egress_upgrade_restarts_only_selected_service(self):
        self.prepare(role="egress", accounting=False)
        self.shell("upgrade_existing\n", stdin="y\n")
        log = self.fixture.log.read_text()
        restarts = [line for line in log.splitlines() if line.startswith("systemctl restart")]
        self.assertEqual(restarts, ["systemctl restart ununknowntun@test"])
        self.assertNotIn("initialize quota", log)

    def test_active_origin_waits_for_fresh_accounting_acknowledgment(self):
        self.prepare(with_site=False)
        original_ledger = (self.state / "access-state.json").read_bytes()
        self.shell('''
sleep() {
    python3 - "$CONFIG_DIR/access.json" "$TUNNEL_STATE_DIR/access-state.json.status.json" <<'PY'
import datetime, hashlib, json, sys
from pathlib import Path
status = {"running": True, "error": "", "config_revision": hashlib.sha256(Path(sys.argv[1]).read_bytes()).hexdigest(),
          "updated_at": datetime.datetime.now(datetime.timezone.utc).isoformat()}
Path(sys.argv[2]).write_text(json.dumps(status))
PY
}
upgrade_existing
''', stdin="y\n")
        self.assertEqual((self.state / "access-state.json").read_bytes(), original_ledger)
        self.assertIn("-access-config", self.run.read_text())

    def test_active_origin_rejects_stale_matching_accounting_status(self):
        self.prepare(with_site=False)
        original_run, original_ledger = self.run.read_bytes(), (self.state / "access-state.json").read_bytes()
        (self.state / "access-state.json.status.json").write_text(json.dumps({
            "running": True, "error": "", "updated_at": "2000-01-01T00:00:00Z",
            "config_revision": hashlib.sha256((self.directory / "access.json").read_bytes()).hexdigest(),
        }))
        result = self.shell("upgrade_existing\n", expected=1, stdin="y\n")
        self.assertIn("did not acknowledge customer accounting", result.stderr)
        self.assertEqual(self.run.read_bytes(), original_run)
        self.assertEqual((self.state / "access-state.json").read_bytes(), original_ledger)
        self.assertEqual(self.binary.read_text(), "original binary")

    def test_active_upgrade_rejects_service_restart_during_validation(self):
        self.prepare(role="egress", accounting=False)
        original_run, original_site = self.run.read_bytes(), self.site.read_bytes()
        result = self.shell('''
systemctl() {
    printf 'systemctl %s\\n' "$*" >> "$MOCK_LOG"
    case "$1" in
        is-active) echo active ;;
        is-enabled) echo enabled ;;
        show)
            if [[ -e "$ROOT/first-invocation-read" ]]; then
                echo abcdef0123456789abcdef0123456789
            else
                touch "$ROOT/first-invocation-read"
                echo 1234567890abcdef1234567890abcdef
            fi ;;
        *) return 0 ;;
    esac
}
upgrade_existing
''', expected=1, stdin="y\n")
        self.assertIn("restarted during upgrade validation", result.stderr)
        self.assertEqual(self.run.read_bytes(), original_run)
        self.assertEqual(self.site.read_bytes(), original_site)
        self.assertEqual(self.binary.read_text(), "original binary")

    def test_existing_accounts_with_missing_state_stop_before_changes(self):
        self.prepare()
        (self.state / "access-state.json").unlink()
        original = self.run.read_bytes()
        result = self.shell("upgrade_existing\n", expected=1, stdin="y\n")
        self.assertIn("Accounting state is missing", result.stderr)
        self.assertEqual(self.run.read_bytes(), original)
        self.assertEqual(self.binary.read_text(), "original binary")
        self.assertNotIn("write_common_files", self.fixture.log.read_text())

    def test_orphan_state_stops_before_changes(self):
        self.prepare()
        (self.directory / "access.json").unlink()
        original_ledger = (self.state / "access-state.json").read_bytes()
        result = self.shell("upgrade_existing\n", expected=1, stdin="y\n")
        self.assertIn("state exists without its configuration", result.stderr)
        self.assertEqual((self.state / "access-state.json").read_bytes(), original_ledger)
        self.assertNotIn("write_common_files", self.fixture.log.read_text())

    def test_31_upgrade_initializes_accounting_once_and_keeps_stopped(self):
        self.prepare(with_site=False, accounting=False)
        self.shell("MOCK_ACTIVE=inactive\nupgrade_existing\nupgrade_existing\n", stdin="100\ny\ny\n")
        log = self.fixture.log.read_text()
        self.assertEqual(log.count("initialize quota=100"), 1)
        self.assertEqual((self.state / "access-state.json").read_text(), "new initial ledger")
        self.assertNotIn("systemctl restart", log)

    def test_invalid_nginx_rolls_back_files_but_does_not_refund_ledger(self):
        self.prepare()
        original_run, original_site = self.run.read_bytes(), self.site.read_bytes()
        self.shell('''
nginx() {
    printf 'nginx %s\\n' "$*" >> "$MOCK_LOG"
    printf 'consumption advanced during validation' > "$TUNNEL_STATE_DIR/access-state.json"
    return 1
}
upgrade_existing
''', expected=1, stdin="y\n")
        self.assertEqual(self.run.read_bytes(), original_run)
        self.assertEqual(self.site.read_bytes(), original_site)
        self.assertEqual(self.binary.read_text(), "original binary")
        self.assertEqual((self.state / "access-state.json").read_text(), "consumption advanced during validation")

    def test_invalid_site_restores_new_accounting_to_preupgrade_state(self):
        self.prepare(accounting=False)
        self.site.write_text("server { listen 443 ssl; }\n")
        original_run, original_site = self.run.read_bytes(), self.site.read_bytes()
        self.shell("MOCK_ACTIVE=inactive\nupgrade_existing\n", expected=1, stdin="100\ny\n")
        self.assertEqual(self.run.read_bytes(), original_run)
        self.assertEqual(self.site.read_bytes(), original_site)
        self.assertFalse((self.directory / "access.json").exists())
        for suffix in ("", ".lock", ".status.json"):
            self.assertFalse((self.state / ("access-state.json" + suffix)).exists())
        self.assertEqual(self.binary.read_text(), "original binary")

    def test_external_nginx_path_is_rejected_before_mutation(self):
        self.prepare()
        self.metadata.write_text(self.metadata.read_text().replace(str(self.site), "/etc/nginx/unrelated.conf"))
        result = self.shell("upgrade_existing\n", expected=1, stdin="y\n")
        self.assertIn("Unexpected Nginx path", result.stderr)
        self.assertNotIn("write_common_files", self.fixture.log.read_text())
        self.assertEqual(self.binary.read_text(), "original binary")

    def test_legacy_h2_only_upgrade_creates_wss_route_without_touching_custom_routes(self):
        self.prepare(role="egress", accounting=False)
        self.run.write_text(self.run.read_text().replace("-transport auto", "-transport h2").replace("  -stats 11s", "  -ws-path /legacy-websocket-path \\\n  -h2-path /legacy-grpc-path \\\n  -h2-listen 127.0.0.1:19081 \\\n  -pad 0.22 \\\n  -stats 11s"))
        self.site.write_text(self.site.read_text().replace("    location / { return 200; }", "    location = /legacy-grpc-path {\n        grpc_pass grpc://127.0.0.1:19081;\n    }\n    location / { return 200; }"))
        self.shell("patch_upgrade_configuration\n")
        launch, site = self.run.read_text(), self.site.read_text()
        self.assertIn("-transport wss", launch)
        self.assertIn("-pad 0", launch)
        self.assertNotIn("-h2-listen", launch)
        self.assertNotIn("grpc_pass", site)
        self.assertIn("location = /legacy-websocket-path", site)
        self.assertIn("proxy_pass http://127.0.0.1:19080", site)
        self.assertIn("location = /keep-customer-route", site)
        self.assertIn("ssl_certificate /custom/fullchain.pem", site)
        self.shell("patch_upgrade_configuration\n")
        self.assertEqual(self.site.read_text(), site)

    def test_xhttp_upgrade_keeps_carrier_mux_ech_and_refreshes_v5_pairing(self):
        self.prepare(with_site=False)
        self.run.write_text(self.run.read_text().replace("-transport auto", "-transport xhttp").replace("  -stats 11s", "  -ws-path /legacy-websocket-path \\\n  -xhttp-path /actual-xhttp-base-path \\\n  -mux off \\\n  -ech-mode strict \\\n  -pad 0.22 \\\n  -stats 11s"))
        (self.directory / "peer.env").write_text("FORMAT=UNUNKNOWNTUN_V4_FLEET\nTOKEN=retained-secret\n")
        self.shell("patch_upgrade_configuration\n")
        for value in ("-transport xhttp", "-mux off", "-ech-mode strict", "-pad 0"):
            self.assertIn(value, self.run.read_text())
        peer = (self.directory / "peer.env").read_text()
        self.assertIn("FORMAT=UNUNKNOWNTUN_V5_FLEET", peer)
        self.assertIn("XHTTP_PATH=/actual-xhttp-base-path", peer)
        self.assertIn("MUX_MODE=off", peer)
        self.assertIn("TOKEN=retained-secret", peer)


if __name__ == "__main__":
    unittest.main(verbosity=2)
