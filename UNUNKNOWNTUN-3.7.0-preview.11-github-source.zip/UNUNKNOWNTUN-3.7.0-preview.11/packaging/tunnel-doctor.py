#!/usr/bin/env python3
"""Bounded, read-only endpoint scanner and certificate/carrier diagnostics.

Only configured hosts or explicitly supplied candidates are contacted. No port
ranges, CDN-account changes, daemon operations, TLS bypasses or config rewrites.
The optional report is private and exclusive-created, never overwritten.
"""
import argparse
import datetime
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import shlex
import socket
import ssl
import subprocess
import sys
import time

MAX_CANDIDATES = 16
MAX_CONFIG = 1024 * 1024
ENV_FIELDS = {"ROLE", "FOREIGN_DOMAIN", "FOREIGN_PORTS", "FOREIGN_PROXY_PROVIDER", "CA_PATH", "LOCAL_TLS_CA_PATH"}
PROBE_FLAGS = ("transport", "sni", "ws-host", "ws-path", "xhttp-path", "xhttp-mode", "xhttp-padding-bytes", "padding-bytes", "utls-profile", "ech-mode", "ech-config", "ech-doh", "tls-fragment", "tls-fragment-size", "tls-fragment-interval", "tls-min-version", "fingerprint", "mux")


class DoctorError(ValueError):
    pass


def read_small(path):
    with Path(path).open("rb") as stream:
        raw = stream.read(MAX_CONFIG + 1)
    if len(raw) > MAX_CONFIG:
        raise DoctorError("Configuration file is unexpectedly large.")
    return raw.decode("utf-8")


def parse_env(text):
    result = {}
    seen = set()
    for line in text.splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        match = re.fullmatch(r"([A-Z][A-Z0-9_]*)=(.*)", line)
        if not match or match[1] in seen:
            raise DoctorError("Malformed or duplicate deployment setting.")
        seen.add(match[1])
        # Ignore display names and other unrelated shell-escaped metadata;
        # nothing in this file is sourced or evaluated.
        if match[1] not in ENV_FIELDS:
            continue
        values = shlex.split(match[2])
        if len(values) > 1 or "$" in match[2] or "`" in match[2]:
            raise DoctorError("Unsupported deployment quoting; no shell code was executed.")
        result[match[1]] = values[0] if values else ""
    return result


def parse_flags(text):
    result = {}
    for line in text.splitlines():
        if not re.match(r"\s+-[a-z]", line):
            continue
        line = line.strip()
        if line.endswith("\\"):
            line = line[:-1].strip()
        parts = shlex.split(line)
        if not parts or not re.fullmatch(r"-[a-z][a-z0-9-]*", parts[0]) or len(parts) not in (1, 2):
            raise DoctorError("Unsupported launch flag layout; launcher was not executed.")
        name = parts[0][1:]
        if name in result:
            raise DoctorError("Duplicate launch flag: -" + name)
        value = parts[1] if len(parts) == 2 else "true"
        if any(ord(c) < 32 for c in value) or "$" in value or "`" in value:
            raise DoctorError("Dynamic launch flags cannot be safely inspected.")
        result[name] = value
    return result


def endpoint(value, default_port=443):
    value = value.strip()
    if not value or any(c in value for c in "/@?#\\ \t\r\n"):
        raise DoctorError("Use a single IP/domain with an optional port; ranges and URLs are not accepted.")
    if value.startswith("["):
        match = re.fullmatch(r"\[([^]]+)\](?::([0-9]+))?", value)
        if not match:
            raise DoctorError("Malformed IPv6 endpoint.")
        host, port = match[1], match[2] or default_port
    elif value.count(":") == 1:
        host, port = value.rsplit(":", 1)
    else:
        host, port = value, default_port
    try:
        port = int(port)
        if not 1 <= port <= 65535:
            raise ValueError
    except ValueError as error:
        raise DoctorError("Endpoint port must be 1–65535.") from error
    try:
        host = str(ipaddress.ip_address(host))
    except ValueError:
        if len(host) > 253 or not re.fullmatch(r"[a-zA-Z0-9.-]+", host) or any(not label or len(label) > 63 or label.startswith("-") or label.endswith("-") for label in host.split(".")):
            raise DoctorError("Invalid endpoint domain.")
        host = host.lower()
    return host, port


def address(host, port):
    return ("[" + host + "]" if ":" in host else host) + ":" + str(port)


def resolve(host, port, timeout):
    try:
        return [str(ipaddress.ip_address(host))]
    except ValueError:
        pass
    # A subprocess makes resolver deadlines real; getaddrinfo itself cannot be
    # canceled reliably by Python threads, and no lingering worker is retained.
    code = "import socket,json,sys; print(json.dumps(sorted({x[4][0] for x in socket.getaddrinfo(sys.argv[1],int(sys.argv[2]),type=socket.SOCK_STREAM)})[:16]))"
    result = subprocess.run([sys.executable, "-c", code, host, str(port)], capture_output=True, text=True, timeout=timeout)
    if result.returncode:
        raise DoctorError("DNS lookup failed; verify the record/resolver. No TLS test was performed.")
    try:
        values = json.loads(result.stdout)
        if not isinstance(values, list) or not values or len(values) > MAX_CANDIDATES:
            raise ValueError
        return [str(ipaddress.ip_address(x)) for x in values]
    except (ValueError, TypeError) as error:
        raise DoctorError("Resolver returned an invalid result.") from error


def redact(text, secrets=()):
    text = str(text)
    for secret in sorted((s for s in secrets if s), key=len, reverse=True):
        text = text.replace(secret, "[redacted]")
    text = re.sub(r"-----BEGIN [^-]*PRIVATE KEY-----[\s\S]*?-----END [^-]*PRIVATE KEY-----", "[private key redacted]", text)
    text = re.sub(r"(?i)(authorization\s*[:=]\s*)[^\r\n]+", r"\1[redacted]", text)
    text = re.sub(r"(?i)Bearer\s+[^\s]+", "Bearer [redacted]", text)
    text = re.sub(r"(?i)(?:-token|token)\s*[=: ]\s*[^\s]+", "token=[redacted]", text)
    return "".join(c if c in "\n\t" or ord(c) >= 32 else "?" for c in text)[:4096]


def explain(error):
    lowered = str(error).lower()
    if "certificate" in lowered or "x509" in lowered:
        return "Certificate trust/name/expiry failed on the tested TLS leg. Edge and origin certificates are separate; do not disable verification."
    if "ech" in lowered:
        return "The selected ECH handshake/configuration failed. A provider name or ordinary TLS success does not establish ECH support."
    if "403" in lowered or "429" in lowered:
        return "HTTP policy/rate rejection: inspect CDN route-specific WAF, challenge and rate rules. This does not prove a bad tunnel token."
    if "404" in lowered:
        return "The route/Host/authentication was not accepted. Check the paired path, forwarded headers, token and clock; HTTP 404 alone cannot identify which is wrong."
    if any(str(code) in lowered for code in (502, 503, 504, 525, 526)):
        return "Gateway failure: inspect CDN-to-origin address, port, HTTPS/certificate and backend health. The status alone does not prove its cause."
    if "refused" in lowered:
        return "TCP was refused: inspect the selected port/listener or rejecting network policy."
    if "timeout" in lowered or "deadline" in lowered or "timed out" in lowered:
        return "The displayed stage timed out. Possible causes include routing, filtering, CDN buffering or an unresponsive peer; no definite certificate/token/firewall blame is established."
    return "Inspect this exact stage and the paired configuration. No reinstall or certificate replacement is justified by this result alone."


def tls_probe(host, port, sni, ca, minimum, timeout):
    context = ssl.create_default_context(cafile=ca or None)
    context.minimum_version = ssl.TLSVersion.TLSv1_2 if minimum == "1.2" else ssl.TLSVersion.TLSv1_3
    context.set_alpn_protocols(["http/1.1"])
    began = time.monotonic()
    with socket.create_connection((host, port), timeout=timeout) as raw:
        with context.wrap_socket(raw, server_hostname=sni) as secure:
            cert = secure.getpeercert()
            return {"stage": "ordinary-tls", "status": "pass", "elapsed_ms": round((time.monotonic()-began)*1000, 2), "tls_version": secure.version(), "not_after": cert.get("notAfter"), "certificate_sha256": hashlib.sha256(secure.getpeercert(binary_form=True)).hexdigest(), "note": "Verified the tested endpoint certificate, not the CDN's private origin verification policy or tunnel payload."}


def core_probe(binary, flags, token_path, token_value, host, port, ca, timeout, secrets):
    args = [binary, "-check-tunnel", "-mode", "origin", "-probe-timeout", str(timeout)+"s", "-connect", address(host, port)]
    for name in PROBE_FLAGS:
        if flags.get(name):
            args.extend(["-"+name, flags[name]])
    if ca:
        args.extend(["-ca", ca])
    elif not flags.get("fingerprint"):
        args.append("-system-ca")
    environment = os.environ.copy()
    # Never inherit a token from an unrelated session over the selected one.
    environment.pop("UNUNKNOWNTUN_TOKEN", None)
    environment.pop("V7_TOKEN", None)
    if token_path:
        args.extend(["-token-file", token_path])
    else:
        environment["UNUNKNOWNTUN_TOKEN"] = token_value
    began = time.monotonic()
    try:
        result = subprocess.run(args, capture_output=True, text=True, timeout=timeout+2, env=environment)
    except subprocess.TimeoutExpired:
        return {"stage": "actual-carrier", "status": "fail", "error": "Actual-carrier probe exceeded its bounded deadline.", "next_step": explain("timeout")}
    output = redact((result.stdout + "\n" + result.stderr).strip(), secrets)
    # The exit code is the contract. Never infer success from an old session
    # line or from an HTTP website; this is a new isolated core invocation.
    return {"stage": "actual-carrier", "status": "pass" if result.returncode == 0 else "fail", "elapsed_ms": round((time.monotonic()-began)*1000, 2), "detail": output, "next_step": "Authenticated UNUNKNOWNTUN carrier only; test a real Xray client separately." if result.returncode == 0 else explain(output)}


def diagnose(config_dir, candidates="", timeout=8, offline=False, binary="/usr/local/bin/ununknowntun"):
    directory = Path(config_dir)
    env = parse_env(read_small(directory / "deployment.env"))
    flags = parse_flags(read_small(directory / "run.sh"))
    role = env.get("ROLE")
    if role not in ("origin", "egress"):
        raise DoctorError("Unknown tunnel role.")
    mode = flags.get("transport", "wss")
    mode = "wss" if mode in ("auto", "h2") else mode
    if mode not in ("wss", "xhttp", "tls"):
        raise DoctorError("Unsupported carrier.")
    flags["transport"] = mode
    domain = flags.get("sni") or env.get("FOREIGN_DOMAIN", "")
    endpoint(domain)
    flags["sni"] = domain
    flags.setdefault("ws-host", domain)
    ech, fragment = flags.get("ech-mode", "off"), flags.get("tls-fragment", "off")
    minimum = flags.get("tls-min-version", "1.3")
    if ech not in ("off", "strict") or fragment not in ("off", "hello") or minimum not in ("1.2", "1.3"):
        raise DoctorError("Invalid TLS profile.")
    if ech == "strict" and (fragment != "off" or minimum != "1.3"):
        raise DoctorError("Strict ECH requires TLS 1.3 and cannot be combined with fragmentation.")
    if flags.get("mux", "on") not in ("on", "off"):
        raise DoctorError("Invalid MUX setting.")
    token_path = flags.get("token-file", "")
    if not token_path and not flags.get("token"):
        token_path = str(directory / "token")
    token_value = read_small(token_path).strip() if token_path else flags["token"]
    if not token_value:
        raise DoctorError("The selected tunnel token is empty.")
    secrets = [token_value, token_path, flags.get("ws-path", ""), flags.get("xhttp-path", ""), str(directory)]
    secrets.extend(url.strip() for url in flags.get("ech-doh", "").split(",") if url.strip())
    secrets.extend([flags.get("ca", ""), env.get("CA_PATH", ""), env.get("LOCAL_TLS_CA_PATH", "")])
    report = {"schema": 1, "time_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "tunnel_id": directory.name, "role": role, "carrier": mode, "ech": ech, "fragment": fragment, "mux": flags.get("mux", "on"), "scope": "offline configuration checks" if offline else "configured or explicitly supplied endpoints only", "target_payload_tested": False, "cdn_origin_policy_verified": False, "checks": [{"stage": "configuration", "status": "pass"}], "endpoints": [], "provider": env.get("FOREIGN_PROXY_PROVIDER", "none")}
    report["certificate_note"] = "CDN edge HTTPS and origin-server HTTPS are separate legs. A valid origin certificate need not be issued by the CDN. Certificates cannot repair blocked TCP or a wrong tunnel route."
    if offline:
        report["verdict"] = "configuration-checked-not-network-tested"
        return report
    _, first_port = endpoint("localhost:" + env.get("FOREIGN_PORTS", "443").split(",")[0])
    requested = []
    if candidates:
        requested = [("candidate", item) for item in candidates.split(",")]
    elif role == "origin":
        requested = [("configured-foreign", item) for item in flags.get("connect", "").split(",") if item]
    else:
        requested = [("local-origin", "127.0.0.1:"+str(first_port))]
        if env.get("FOREIGN_PROXY_PROVIDER", "none") != "none":
            requested.append(("cdn-edge", domain+":"+str(first_port)))
    if not requested or len(requested) > MAX_CANDIDATES:
        raise DoctorError("Supply between 1 and 16 explicit endpoints; address/port ranges are not scanned.")
    seen, successful = set(), []
    for leg, value in requested:
        host, port = endpoint(value, first_port)
        try:
            addresses = resolve(host, port, timeout)
        except (DoctorError, OSError, subprocess.TimeoutExpired) as error:
            report["endpoints"].append({"leg": leg, "endpoint": address(host, port), "checks": [{"stage": "dns", "status": "fail", "error": redact(error, secrets)}]})
            continue
        for resolved in addresses:
            key = (leg, resolved, port)
            if key in seen:
                continue
            if len(seen) >= MAX_CANDIDATES:
                report["candidate_limit_reached"] = True
                break
            seen.add(key)
            entry = {"leg": leg, "endpoint": address(resolved, port), "sni": domain, "checks": []}
            report["endpoints"].append(entry)
            if leg == "local-origin":
                ca = env.get("LOCAL_TLS_CA_PATH", "")
            elif flags.get("ca"):
                ca = flags["ca"]
            elif flags.get("fingerprint") or flags.get("system-ca") == "true":
                ca = ""
            else:
                ca = env.get("CA_PATH", "")
            actual_flags = dict(flags)
            if leg == "local-origin":
                actual_flags.update({"ech-mode": "off", "tls-fragment": "off"})
            try:
                began = time.monotonic()
                with socket.create_connection((resolved, port), timeout=timeout):
                    pass
                entry["checks"].append({"stage": "tcp", "status": "pass", "elapsed_ms": round((time.monotonic()-began)*1000, 2)})
            except OSError as error:
                entry["checks"].append({"stage": "tcp", "status": "fail", "error": redact(error, secrets), "next_step": explain(error)})
                continue
            if actual_flags.get("ech-mode", "off") == "strict" or actual_flags.get("tls-fragment", "off") != "off":
                entry["checks"].append({"stage": "ordinary-tls", "status": "skipped", "note": "Use the real core handshake below; ordinary TLS cannot reproduce ECH/fragment."})
            elif actual_flags.get("fingerprint") and not ca:
                entry["checks"].append({"stage": "ordinary-tls", "status": "skipped", "note": "This profile verifies a pinned certificate fingerprint. The real core below must verify that pin; a separate CA-only probe would test a different trust policy."})
            else:
                try:
                    entry["checks"].append(tls_probe(resolved, port, domain, ca, minimum, timeout))
                except (OSError, ValueError) as error:
                    entry["checks"].append({"stage": "ordinary-tls", "status": "fail", "error": redact(error, secrets), "next_step": explain(error)})
            try:
                check = core_probe(binary, actual_flags, token_path, token_value, resolved, port, ca, timeout, secrets)
            except OSError as error:
                check = {"stage": "actual-carrier", "status": "fail", "error": redact(error, secrets), "next_step": "Install the matching 3.5+ binary; no service was started or changed."}
            entry["checks"].append(check)
            if check["status"] == "pass":
                successful.append((check["elapsed_ms"], entry["endpoint"]))
    report["authenticated_candidates"] = len(successful)
    report["recommended_endpoint"] = min(successful)[1] if successful else None
    report["recommendation_note"] = "Lowest one-shot authenticated handshake time, not throughput, filtering-resistance or long-term reliability. Configuration was not changed."
    failed = any(c["status"] == "fail" for e in report["endpoints"] for c in e["checks"])
    report["verdict"] = "partial" if successful and failed else "carrier-authenticated" if successful else "failed"
    return report


def write_report(path, payload):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o600)
    with os.fdopen(fd, "w") as stream:
        stream.write(payload)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config-dir", required=True)
    parser.add_argument("--endpoints", default="", help="at most 16 explicit IPs/domains with optional ports; no ranges")
    parser.add_argument("--output", help="create a private sanitized JSON report; existing files are never replaced")
    parser.add_argument("--timeout", type=int, default=8, help="per-stage seconds, 1–20; core has the same bounded total")
    parser.add_argument("--offline", action="store_true", help="inspect configuration only; make no network requests")
    parser.add_argument("--binary", default="/usr/local/bin/ununknowntun", help="matching UNUNKNOWNTUN binary, never the run.sh launcher")
    args = parser.parse_args(argv)
    if not 1 <= args.timeout <= 20:
        parser.error("--timeout must be 1–20 seconds")
    try:
        report = diagnose(args.config_dir, args.endpoints, args.timeout, args.offline, args.binary)
        payload = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
        if args.output:
            write_report(args.output, payload)
        print(payload, end="")
        return 0 if report["verdict"] in ("carrier-authenticated", "configuration-checked-not-network-tested") else 1
    except (DoctorError, OSError, ValueError) as error:
        # Config errors may include private filesystem paths; the shareable
        # failure is deliberately bounded and does not dump configuration.
        message = str(error) if isinstance(error, DoctorError) else "A local configuration/report file could not be read or safely created; no settings were changed."
        print(json.dumps({"verdict": "configuration-error", "error": message}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
