#!/usr/bin/env python3
"""Root-only, transactional edits of one existing UNUNKNOWNTUN tunnel.

Never initializes, copies, restores, or refunds the accounting ledger. Remote
changes are explicit authenticated data, never executable shell instructions.
"""
import argparse
import base64
import copy
import decimal
import fcntl
import hashlib
import hmac
import importlib.util
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import shlex
import signal
import socket
import subprocess
import sys
import tempfile
import time
import urllib.parse


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(filename))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


access = module("editor_access", "access-manager.py")
tls = module("editor_tls", "editor_tls.py")
profiles = module("editor_profiles", "profile-validation.py")
SYNC_FIELDS = {"foreign_ip", "iran_ip", "foreign_ports", "foreign_domain", "entry_domain", "ws_path", "h2_path", "xhttp_path", "entry_path", "target_port", "token", "transport", "mux"}
SYNC_FIELDS.update(("foreign_provider", "entry_profile", "entry_ports"))
ENV_FIELDS = {"name": "TUNNEL_NAME", "foreign_ip": "FOREIGN_IP", "iran_ip": "IRAN_IP", "foreign_ports": "FOREIGN_PORTS", "entry_ports": "IRAN_ENTRY_PORTS", "foreign_domain": "FOREIGN_DOMAIN", "entry_domain": "IRAN_ENTRY_DOMAIN", "entry_path": "IRAN_ENTRY_PATH", "target_port": "TARGET_PORT"}
FLAGS = {"ws_path": "ws-path", "h2_path": "h2-path", "pad": "pad", "sessions": "sessions", "sessions_min": "sessions-min", "max_streams": "max-streams", "max_memory_mb": "max-memory", "profile": "utls-profile", "transport": "transport", "tls_min": "tls-min-version", "write_timeout": "write-timeout", "edge_timeout": "edge-write-timeout", "ca": "ca"}
DEFAULTS = {"pad": "0.22", "sessions": "8", "sessions_min": "2", "max_streams": "2048", "max_memory_mb": "1024", "profile": "chrome", "transport": "auto", "tls_min": "1.3", "write_timeout": "15s", "edge_timeout": "0"}
ORIGIN_ONLY = {"entry_ports", "sessions", "sessions_min", "profile", "tls_min", "ca", "ech_mode", "tls_fragment", "fragment_size", "fragment_interval"}
ORIGIN_ONLY.remove("entry_ports")  # Peer edits synchronize metadata only.
LABELS = {"name": "Tunnel display name", "foreign_ip": "Foreign server IPv4", "iran_ip": "Iran server IPv4", "foreign_ports": "Foreign HTTPS ports", "entry_ports": "Iran public entry ports", "foreign_domain": "Foreign domain", "entry_domain": "Iran entry domain", "ws_path": "Tunnel WebSocket path", "h2_path": "Tunnel HTTP/2 path", "entry_path": "Iran client WebSocket path", "target_port": "Foreign Xray inbound port", "token": "Rotate shared tunnel secret", "certificate": "SSL certificate and private-key files", "pad": "Padding ratio (pad, 0-1)", "sessions": "Maximum parallel sessions", "sessions_min": "Minimum parallel sessions", "max_streams": "Maximum streams", "max_memory_mb": "Memory limit (MiB)", "profile": "TLS fingerprint profile", "transport": "Tunnel transport (auto/wss/h2)", "tls_min": "Minimum TLS version", "write_timeout": "Write timeout", "edge_timeout": "Client write timeout", "ca": "Trusted CA-bundle file"}
FLAGS.update(xhttp_path="xhttp-path", mux="mux", ech_mode="ech-mode", tls_fragment="tls-fragment", fragment_size="tls-fragment-size", fragment_interval="tls-fragment-interval")
ENV_FIELDS.update(foreign_provider="FOREIGN_PROXY_PROVIDER", local_ca="LOCAL_TLS_CA_PATH")
DEFAULTS.update(mux="on", ech_mode="off", tls_fragment="off", fragment_size="100-200", fragment_interval="1-3ms")
LABELS.update(transport="Tunnel type (wss normal / xhttp experimental)", xhttp_path="XHTTP base path", mux="MUX (on/off; off uses one session per client connection)", ech_mode="ECH (off/strict; strict requires supported TLS endpoint)", tls_fragment="TLS ClientHello fragmentation (off/hello; experimental)", fragment_size="Experimental fragment byte range (100-200)", fragment_interval="Experimental fragment delay range (1-3ms)")
LABELS.update(foreign_provider="Foreign CDN provider (none/cloudflare/arvan/fastly)", entry_profile="Iran entry migration: direct/proxy, provider, WS/XHTTP", local_ca="Local origin TLS trust bundle (not the CDN-edge trust bundle)")
ENV_FIELDS.update(connect_host="CONNECT_HOST")
FLAGS.update(tls_sni="sni", http_host="ws-host", ech_source="ech-config", padding_bytes="padding-bytes", xhttp_padding="xhttp-padding-bytes", xhttp_mode="xhttp-mode")
DEFAULTS.update(connect_host="auto", ech_source="auto", padding_bytes="0", xhttp_padding="0", xhttp_mode="packet-up")
ORIGIN_ONLY.update(("connect_host", "tls_sni", "ech_source"))
SYNC_FIELDS.update(("http_host", "xhttp_mode"))
LABELS.update(connect_host="Dial host: clean IP/domain, or auto to inherit", tls_sni="TLS SNI / certificate domain", http_host="HTTP Host (paired change; CDN must route it)", ech_source="ECH config: auto, Base64 list, or domain+resolver", padding_bytes="UNUNKNOWNTUN frame padding bytes (0-1024 or MIN-MAX)", xhttp_padding="XHTTP HTTP-header padding bytes (0-4096 or MIN-MAX)", xhttp_mode="XHTTP mode: auto / packet-up / stream-up / stream-one")
ENTRY_KEYS = {"provider": "IRAN_PROXY_PROVIDER", "transport": "IRAN_ENTRY_TRANSPORT", "domain": "IRAN_ENTRY_DOMAIN", "ports": "IRAN_ENTRY_PORTS", "path": "IRAN_ENTRY_PATH"}
PATH_KEYS = {"interval": ("path-rotation", "PATH_ROTATION", "0"), "count": ("path-count", "PATH_COUNT", "3"), "grace": ("path-grace", "PATH_GRACE", "5m"), "legacy": ("path-legacy", "PATH_LEGACY", "false")}
FLAGS.update(session_renewal="session-renewal")
DEFAULTS.update(session_renewal="0")
ORIGIN_ONLY.add("session_renewal")
SYNC_FIELDS.add("path_profile")
LABELS.update(path_profile="Coordinated paths: interval, backups, overlap (paired change)", session_renewal="Gradual carrier renewal (0=off, e.g. 2h; MUX ON only)", entry_profile="Iran entry: direct TCP / standalone Nginx / CDN, WS/XHTTP")


def provider_ports(provider, value):
    value = ports(value)
    for port in map(int, value.split(",")):
        if port == 80 or (provider in ("arvan", "fastly") and port != 443) or (provider == "cloudflare" and port not in (443, 2053, 2083, 2087, 2096, 8443)):
            raise ValueError("HTTPS ports do not match the selected CDN provider (Arvan/Fastly: 443).")
    return value


def canonical(data):
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key.")
        result[key] = value
    return result


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def read_flag(script, name, default=""):
    pattern = r"(?m)^[ \t]*-" + re.escape(name) + r"[ \t]+(.+?)[ \t]*(?:\\)?$"
    matches = re.findall(pattern, script)
    if len(matches) > 1:
        raise ValueError("Duplicate managed flag: -" + name)
    if not matches:
        return default
    values = shlex.split(matches[0].strip().rstrip("\\").strip())
    if len(values) != 1:
        raise ValueError("Unsupported launch flag layout: -" + name)
    return values[0]


def set_flag(script, name, value):
    # Values are separately validated; quote even so, and preserve all other flags.
    pattern = r"(?m)^([ \t]*)-" + re.escape(name) + r"[ \t]+[^\n]+$"
    matches = list(re.finditer(pattern, script))
    if len(matches) > 1:
        raise ValueError("Duplicate managed flag: -" + name)
    if matches:
        read_flag(script, name)  # Reject inline/custom layouts before replacing.
        return re.sub(pattern, lambda m: m[1] + "-" + name + " " + shlex.quote(value) + (" \\" if m[0].rstrip().endswith("\\") else ""), script)
    match = re.search(r"(?m)^[ \t]*-mode (?:origin|egress)[ \t]+\\$", script)
    if not match:
        raise ValueError("Managed launch layout is unrecognized; no changes applied.")
    return script[:match.end()] + "\n  -" + name + " " + shlex.quote(value) + " \\" + script[match.end():]


def encode_env(env):
    return "".join(key + "=" + shlex.quote(str(value)) + "\n" for key, value in env.items())


def ports(value):
    items = [access.port_number(part.strip()) for part in value.split(",")]
    if not items or len(items) != len(set(items)):
        raise ValueError("Use distinct ports separated by commas.")
    return ",".join(map(str, items))


def public_ip(value):
    address = ipaddress.IPv4Address(value)
    # Documentation ranges are accepted for reproducible tests, consistent with
    # the installer's existing validation; private/multicast/loopback are not.
    if address.is_loopback or address.is_multicast or address.is_link_local or address.packed[0] == 0 or any(address in net for net in map(ipaddress.ip_network, ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "100.64.0.0/10", "240.0.0.0/4"))):
        raise ValueError("Enter a public IPv4 address.")
    return str(address)


def dial_host(value):
    """One host, not a URL, command, host:port or list of endpoints."""
    if not value or value != value.strip() or any(c in value for c in "/\\,@%?#\"' "):
        raise ValueError("Enter one IP/domain without a port, URL, scope or spaces.")
    if value.startswith("[") or value.endswith("]"):
        if not (value.startswith("[") and value.endswith("]")):
            raise ValueError("Invalid IPv6 brackets.")
        value = value[1:-1]
    try:
        return str(ipaddress.ip_address(value))
    except ValueError:
        if ":" in value or re.fullmatch(r"[0-9.]+", value):
            raise ValueError("Invalid IP address or port included with host.") from None
        return tls.validate_domain(value)


def byte_range(value, maximum):
    match = re.fullmatch(r"(0|[1-9][0-9]{0,3})(?:-(0|[1-9][0-9]{0,3}))?", value)
    if not match or not 0 <= int(match[1]) <= int(match[2] or match[1]) <= maximum:
        raise ValueError(f"Use N or MIN-MAX with 0 <= MIN <= MAX <= {maximum}, without leading zeros.")
    return value


def validate_ech_source(value):
    """Offline syntax/structure validation; acceptance needs a real TLS probe."""
    if value == "auto":
        return value
    if not value or len(value) > 90000 or any(c.isspace() for c in value):
        raise ValueError("ECH source is empty, too large or contains whitespace.")
    if "://" in value:
        resolver = value
        prefix = value.split("://", 1)[0]
        if "+" in prefix:
            name, resolver = value.split("+", 1)
            tls.validate_domain(name)
        try:
            parsed = urllib.parse.urlsplit(resolver)
            if parsed.scheme not in ("udp", "tcp", "https") or not parsed.hostname or parsed.username is not None or parsed.password is not None or parsed.fragment:
                raise ValueError()
            if parsed.netloc.endswith(":") or parsed.port is not None and not 1 <= parsed.port <= 65535:
                raise ValueError()
            if parsed.scheme in ("udp", "tcp"):
                if "%" in parsed.hostname:
                    raise ValueError()
                ipaddress.ip_address(parsed.hostname)
                if parsed.path or parsed.query or "?" in resolver:
                    raise ValueError()
            else:
                dial_host(parsed.hostname)
        except ValueError:
            raise ValueError("Use [domain+]udp://IP[:port], tcp://IP[:port], or verified https://resolver/dns-query; no credentials or fragments.") from None
        return value
    try:
        encoded = value.removeprefix("base64:")
        raw = base64.b64decode(encoded, validate=True)
        if base64.b64encode(raw).decode() != encoded or not 6 <= len(raw) <= 65537 or int.from_bytes(raw[:2], "big") != len(raw) - 2:
            raise ValueError()
        at, usable = 2, False
        def vector(data, index, width):
            if index + width > len(data):
                raise ValueError()
            size = int.from_bytes(data[index:index + width], "big")
            start = index + width
            if start + size > len(data):
                raise ValueError()
            return data[start:start + size], start + size
        while at < len(raw):
            if at + 4 > len(raw):
                raise ValueError()
            version = int.from_bytes(raw[at:at + 2], "big")
            body, at = vector(raw, at + 2, 2)
            if version != 0xfe0d:
                continue
            if len(body) < 3:
                raise ValueError()
            kem = int.from_bytes(body[1:3], "big")
            key, pos = vector(body, 3, 2)
            suites, pos = vector(body, pos, 2)
            if pos >= len(body):
                raise ValueError()
            name, pos = vector(body, pos + 1, 1)
            extensions, pos = vector(body, pos, 2)
            if pos != len(body) or not key or not suites or len(suites) % 4:
                raise ValueError()
            tls.validate_domain(name.decode("ascii"))
            offset, kinds, mandatory = 0, set(), False
            while offset < len(extensions):
                if offset + 4 > len(extensions):
                    raise ValueError()
                kind = int.from_bytes(extensions[offset:offset + 2], "big")
                _, offset = vector(extensions, offset + 2, 2)
                if kind in kinds:
                    raise ValueError()
                kinds.add(kind)
                mandatory = mandatory or bool(kind & 0x8000)
            cipher_ok = any(int.from_bytes(suites[i:i + 2], "big") == 1 and int.from_bytes(suites[i + 2:i + 4], "big") in (1, 2, 3) for i in range(0, len(suites), 4))
            usable = usable or kem == 0x20 and len(key) == 32 and cipher_ok and not mandatory
        if not usable:
            raise ValueError()
    except (ValueError, UnicodeError):
        raise ValueError("Use a structurally valid Base64 ECHConfigList with a supported X25519 configuration, not a server private key.") from None
    return value


def validate(field, value):
    if not isinstance(value, str) or any(ord(c) < 32 or ord(c) == 127 for c in value):
        raise ValueError("Control characters are not allowed.")
    if field == "entry_profile":
        try:
            data = json.loads(value, object_pairs_hook=unique_object)
            if not isinstance(data, dict) or set(data) != set(ENTRY_KEYS) or any(not isinstance(v, str) for v in data.values()):
                raise ValueError("Use only provider, transport, domain, ports and path.")
            if data["provider"] != "nginx":
                data["provider"] = validate("foreign_provider", data["provider"])
            if data["transport"] not in ("ws", "xhttp"):
                raise ValueError("Choose WS or XHTTP packet-up for the independent client entry.")
            if data["provider"] == "fastly" and data["transport"] != "xhttp":
                raise ValueError("Fastly requires the experimental XHTTP packet-up entry.")
            if data["provider"] != "none":
                data["domain"] = tls.validate_domain(data["domain"])
                data["ports"] = provider_ports(data["provider"], data["ports"])
            else:
                data["ports"] = ports(data["ports"])
                if data["domain"]:
                    data["domain"] = tls.validate_domain(data["domain"])
            data["path"] = validate("xhttp_path" if data["transport"] == "xhttp" else "entry_path", data["path"])
            return canonical(data).decode()
        except (TypeError, KeyError, json.JSONDecodeError) as error:
            raise ValueError("Invalid entry migration profile.") from error
    if field == "path_profile":
        value = profiles.path_profile(value)
    elif field == "session_renewal":
        if value != "0":
            profiles.duration(value, minimum=60)
    elif field == "connect_host":
        value = value if value == "auto" else dial_host(value)
    elif field in ("tls_sni", "http_host"):
        value = tls.validate_domain(value)
    elif field == "ech_source":
        value = validate_ech_source(value)
    elif field in ("padding_bytes", "xhttp_padding"):
        value = byte_range(value, 1024 if field == "padding_bytes" else 4096)
    elif field == "xhttp_mode":
        if value not in ("auto", "packet-up", "stream-up", "stream-one"):
            raise ValueError("Choose auto, packet-up, stream-up or stream-one.")
    elif field == "foreign_provider":
        if value not in ("none", "cloudflare", "arvan", "fastly"):
            raise ValueError("Choose none, cloudflare, arvan or fastly.")
    elif field == "name":
        if not value or len(value.encode()) > 120 or "=" in value or not value.isprintable():
            raise ValueError("Use a printable name up to 120 UTF-8 bytes without '='.")
    elif field in ("foreign_domain", "entry_domain"):
        value = tls.validate_domain(value)
    elif field in ("foreign_ip", "iran_ip"):
        value = public_ip(value)
    elif field in ("foreign_ports", "entry_ports"):
        value = ports(value)
    elif field in ("ws_path", "h2_path", "xhttp_path", "entry_path"):
        minimum = 15
        if not re.fullmatch(r"/[A-Za-z0-9/_-]{" + str(minimum) + r",511}", value):
            raise ValueError(f"Use a path starting / with {minimum}-511 letters, digits, /, _ or -.")
        if field == "xhttp_path" and "//" in value:
            raise ValueError("XHTTP requires a clean path without double slashes.")
        if value.startswith("/gdt-r/"):
            raise ValueError("The /gdt-r/ namespace is reserved for rotating tunnel routes.")
    elif field == "token":
        if not re.fullmatch(r"[A-Za-z0-9_-]{32,256}", value):
            raise ValueError("Use a secret of 32-256 letters, digits, '_' or '-'.")
    elif field == "target_port":
        value = str(access.port_number(value))
    elif field == "pad":
        try:
            number = decimal.Decimal(value)
            if not number.is_finite() or not 0 <= number <= 1:
                raise ValueError()
            value = str(number)
        except (decimal.InvalidOperation, ValueError):
            raise ValueError("Padding must be between 0 and 1.") from None
    elif field in ("sessions", "sessions_min", "max_streams", "max_memory_mb"):
        maximum = {"sessions": 64, "sessions_min": 64, "max_streams": 1000000, "max_memory_mb": 1048576}[field]
        minimum = 16 if field == "max_memory_mb" else 1
        if not re.fullmatch(r"[0-9]{1,9}", value) or not minimum <= int(value) <= maximum:
            raise ValueError(f"Enter an integer from {minimum} to {maximum}.")
        value = str(int(value))
    elif field in ("profile", "transport", "tls_min", "mux", "ech_mode", "tls_fragment"):
        allowed = {"profile": ("chrome", "firefox", "ios"), "transport": ("auto", "wss", "h2", "xhttp"), "tls_min": ("1.2", "1.3"), "mux": ("on", "off"), "ech_mode": ("off", "strict"), "tls_fragment": ("off", "hello")}[field]
        if value not in allowed:
            raise ValueError("Choose: " + ", ".join(allowed))
    elif field in ("fragment_size", "fragment_interval"):
        suffix = "ms" if field == "fragment_interval" else ""
        match = re.fullmatch(r"([0-9]{1,4})-([0-9]{1,4})" + suffix, value)
        minimum, maximum = (0, 20) if suffix else (16, 4096)
        if not match or not minimum <= int(match[1]) <= int(match[2]) <= maximum:
            raise ValueError(f"Use MIN-MAX{suffix} with {minimum} <= MIN <= MAX <= {maximum}.")
    elif field in ("write_timeout", "edge_timeout"):
        if value == "0" and field == "edge_timeout":
            return value
        match = re.fullmatch(r"([0-9]{1,5})s", value)
        if not match or not 1 <= int(match[1]) <= (60 if field == "write_timeout" else 300):
            raise ValueError("Use whole seconds, e.g. 15s (write: 1-60s; edge: 1-300s or 0).")
    elif field in ("ca", "local_ca"):
        if not re.fullmatch(r"/[A-Za-z0-9_./-]+", value) or not Path(value).is_file():
            raise ValueError("Use an existing absolute CA-bundle path without spaces.")
    else:
        raise ValueError("Unknown or non-editable field.")
    return value


class Link:
    def __init__(self, target):
        self.target = str(target)


def nginx_rotation_pattern(transport):
    # Keep in sync with the installer's nginx_rotation_pattern and core route
    # formats: scheduled 16-byte MAC, or recovery 16-byte nonce + 16-byte MAC.
    base = r"^/gdt-r/([0-9a-f]{32}|[0-9a-f]{64})"
    if transport == "xhttp":
        # stream-one needs the empty suffix; stream-up/packet-up use UUIDs.
        return base + r"/([0-9A-Fa-f]{8}-([0-9A-Fa-f]{4}-){3}[0-9A-Fa-f]{12}(/(0|[1-9][0-9]{0,19}))?)?$"
    return base + "$"


def transport_routes(site, before_script, after_script, env):
    """Replace only recognized egress transport locations, retaining TLS/site data."""
    transport = read_flag(after_script, "transport", "auto")
    backend = access.port_number(env.get("WSS_BACKEND_PORT", ""))
    ws_path = validate("ws_path", read_flag(after_script, "ws-path"))
    h2_path = validate("h2_path", read_flag(after_script, "h2-path"))
    xhttp_path = validate("xhttp_path", read_flag(after_script, "xhttp-path", ws_path))
    blocks = ["    # UNUNKNOWNTUN_TRANSPORT_BEGIN"]
    if transport in ("wss", "auto", "h2", "xhttp"):
        xhttp = transport == "xhttp"
        route = "^~ " + xhttp_path.rstrip("/") + "/" if xhttp else "= " + ws_path
        route_block = [
            "    location " + route + " {", "        access_log off;",
            f"        proxy_pass http://127.0.0.1:{backend};", "        proxy_http_version 1.1;",
            "        proxy_set_header Host $host;", "        proxy_set_header Authorization $http_authorization;",
            '        proxy_set_header Connection "";' if xhttp else '        proxy_set_header Connection "upgrade";',
            ("        client_max_body_size 2m;" if read_flag(after_script, "xhttp-mode", "packet-up") == "packet-up" else "        client_max_body_size 0;") if xhttp else "        proxy_set_header Upgrade $http_upgrade;",
            '        gzip off;\n        proxy_set_header Accept-Encoding "";' if xhttp else "        # WebSocket upgrade",
            "        proxy_buffering off;", "        proxy_request_buffering off;", "        proxy_cache off;",
            '        add_header Cache-Control "no-store" always;', "        proxy_read_timeout 86400s;",
            "        proxy_send_timeout 86400s;", "        proxy_intercept_errors off;", "    }",
        ]
        blocks.extend(route_block)
        rotation_header = 'location ~ "' + nginx_rotation_pattern(transport) + '"'
        blocks.extend([line.replace("location " + route + " {", rotation_header + " {") for line in route_block])
    blocks.append("    # UNUNKNOWNTUN_TRANSPORT_END")
    replacement = "\n".join(blocks)
    begin, end = "# UNUNKNOWNTUN_TRANSPORT_BEGIN", "# UNUNKNOWNTUN_TRANSPORT_END"
    if begin in site or end in site:
        if site.count(begin) != 1 or site.count(end) != 1:
            raise ValueError("Invalid transport route markers; no changes applied.")
        result, count = re.subn(r"(?ms)^[ \t]*# UNUNKNOWNTUN_TRANSPORT_BEGIN.*?^[ \t]*# UNUNKNOWNTUN_TRANSPORT_END", lambda _: replacement, site, count=1)
        if count != 1:
            raise ValueError("Transport route markers are reversed or malformed; no changes applied.")
        return result
    # Pre-marker upgrades can already have a generated rotation block. Remove
    # only recognized blocks pointing to this tunnel's backend before adding
    # the new region, so a stale broad prefix cannot shadow the strict route.
    old_rotation_headers = [r"location\s+\^~\s+/gdt-r/"]
    for old_transport in ("wss", "xhttp"):
        old_rotation_headers.append(re.escape('location ~ "' + nginx_rotation_pattern(old_transport) + '"'))
    old_rotation = (r"(?m)^[ \t]*(?:" + "|".join(old_rotation_headers) + r")\s*\{[^{}]*"
                    + re.escape(f"proxy_pass http://127.0.0.1:{backend};") + r"[^{}]*\}\n?")
    site = re.sub(old_rotation, "", site)
    old_paths = {read_flag(before_script, flag) for flag in ("ws-path", "h2-path", "xhttp-path")} - {""}
    pattern = r"(?m)^[ \t]*location\s+(?:=|\^~)\s+([^\s{]+)\s*\{[^{}]*\}"
    matches = [m for m in re.finditer(pattern, site) if m[1].rstrip("/") in {p.rstrip("/") for p in old_paths}]
    if not matches:
        raise ValueError("Recognized managed transport routes not found; manual/custom Nginx sites are not overwritten.")
    for index, match in reversed(list(enumerate(matches))):
        site = site[:match.start()] + (replacement if index == 0 else "") + site[match.end():]
    return site


class Editor:
    def __init__(self, config_dir, state_dir, install_dir=Path("/opt/ununknowntun"), nginx_available=Path("/etc/nginx/sites-available"), nginx_enabled=Path("/etc/nginx/sites-enabled")):
        self.directory, self.state_dir = Path(config_dir), Path(state_dir)
        self.install_dir = Path(install_dir)
        self.available, self.enabled = Path(nginx_available), Path(nginx_enabled)
        self.id = access.account_id(self.directory.name)
        self.service = "ununknowntun@" + self.id
        self.refresh()

    def refresh(self):
        self.env = access.read_env(self.directory / "deployment.env")
        self.role = self.env.get("ROLE")
        if self.role not in ("origin", "egress"):
            raise ValueError("Upgrade this legacy tunnel first; role metadata is missing.")
        self.script = (self.directory / "run.sh").read_text()
        self.token = (self.directory / "token").read_text().strip()
        self.site = Path(self.env["NGINX_SITE"]) if self.env.get("NGINX_SITE") else None

    def run(self, *args, check=True):
        return subprocess.run(args, check=check, capture_output=True, text=True, env={**os.environ, "LC_ALL": "C"})

    def active(self, service=None):
        return self.run("systemctl", "is-active", "--quiet", service or self.service, check=False).returncode == 0

    def current(self, field):
        if field == "path_profile":
            return canonical({key: read_flag(self.script, flag, default) for key, (flag, _, default) in PATH_KEYS.items()}).decode()
        if field == "entry_profile":
            return canonical({key: self.env.get(name, "ws" if key == "transport" else "none" if key == "provider" else "") for key, name in ENTRY_KEYS.items()}).decode()
        if field == "token":
            return self.token
        if field in ENV_FIELDS:
            return self.env.get(ENV_FIELDS[field], DEFAULTS.get(field, ""))
        if field in FLAGS:
            if field == "xhttp_path":
                return read_flag(self.script, "xhttp-path", read_flag(self.script, "ws-path"))
            default = DEFAULTS.get(field, "")
            value = read_flag(self.script, FLAGS[field], str(int(default) * 1048576) if field == "max_memory_mb" else default)
            return str(int(value) // 1048576) if field == "max_memory_mb" else value
        raise ValueError("Unknown field.")

    def show(self):
        print(f"\nTunnel: {self.id} | Role: {self.role} | Name: {self.current('name')}")
        print("Internal ID and pairing identity remain fixed; quotas and usage are retained.")
        for field in list(ENV_FIELDS) + list(FLAGS) + ["path_profile"]:
            if field in ("pad", "h2_path"):
                continue  # Retired compatibility inputs, not operational controls.
            if field in ORIGIN_ONLY and self.role != "origin":
                continue
            value = self.current(field)
            if value:
                if field == "ech_source" and value != "auto":
                    value = "[manual ECH configuration; value hidden]"
                print(f"  {field}: {value}")
        print("  token: [hidden] (rotation available)")
        if self.site:
            cert, key = tls.certificate_paths(self.site.read_text())
            print(f"  certificate: {cert}\n  certificate key file: {key}")

    def assert_site_owned(self):
        if not self.site or self.site.parent != self.available or not self.site.name.startswith("ununknowntun-") or self.site.is_symlink() or not self.site.is_file():
            raise ValueError("This side has no recognized managed Nginx site.")
        link = self.enabled / self.site.name
        if link.is_symlink():
            if link.resolve() != self.site.resolve():
                raise ValueError("The enabled Nginx entry points to another site; refusing to replace it.")
        elif link.exists():
            raise ValueError("The enabled Nginx entry is an administrator-owned file, not the managed symlink.")
        for path in self.directory.parent.glob("*/deployment.env"):
            if path.parent != self.directory and access.read_env(path).get("NGINX_SITE") == str(self.site):
                raise ValueError("This Nginx site is shared by another tunnel; refusing an isolated edit.")

    def local_domain(self):
        return self.env.get("FOREIGN_DOMAIN" if self.role == "egress" else "IRAN_ENTRY_DOMAIN", "")

    def check_domain(self, domain):
        for path in self.directory.parent.glob("*/deployment.env"):
            if path.parent == self.directory:
                continue
            env = access.read_env(path)
            own_domain = env.get("FOREIGN_DOMAIN" if env.get("ROLE") == "egress" else "IRAN_ENTRY_DOMAIN")
            if domain == own_domain and env.get("NGINX_SITE"):
                raise ValueError("Domain is already assigned to another local tunnel.")
        if domain != self.local_domain():
            result = self.run("nginx", "-T")
            for names in re.findall(r"(?m)^\s*server_name\s+([^;]+);", result.stdout + result.stderr):
                if domain in names.split():
                    raise ValueError("Domain already appears in Nginx; use an unused domain.")

    def check_ports(self, value, old, public_https=False, provider=None):
        old_ports = {int(p) for p in old.split(",") if p}
        provider = provider or self.env.get("FOREIGN_PROXY_PROVIDER" if self.role == "egress" else "IRAN_PROXY_PROVIDER", "none")
        for port in map(int, value.split(",")):
            if port == 80:
                raise ValueError("Port 80 is reserved for certificate challenges.")
            if public_https and ((provider in ("arvan", "fastly") and port != 443) or (provider == "cloudflare" and port not in (443, 2053, 2083, 2087, 2096, 8443))):
                raise ValueError("This HTTPS port is not supported by the selected provider.")
            if port in old_ports:
                continue
            for path in self.directory.parent.glob("*/ports.list"):
                if str(port) in path.read_text().splitlines():
                    env = access.read_env(path.parent / "deployment.env")
                    shared = (env.get("FOREIGN_PORTS", "") if env.get("ROLE") == "egress" else env.get("IRAN_ENTRY_PORTS", "")) if env.get("NGINX_SITE") else ""
                    if not public_https or str(port) not in shared.split(","):
                        raise ValueError(f"Port {port} is reserved by {path.parent.name}.")
            result = self.run("ss", "-H", "-ltnp", "sport = :" + str(port))
            if result.stdout.strip() and (not public_https or any('"nginx"' not in line for line in result.stdout.splitlines())):
                raise ValueError(f"Port {port} is occupied by another listener.")

    def validate_combination(self, field, value):
        if field in ORIGIN_ONLY and self.role != "origin":
            raise ValueError("This setting is edited on the Iran/origin server.")
        proposed = lambda f: value if f == field else self.current(f)
        if field in ("sessions", "sessions_min") and int(proposed("sessions_min")) > int(proposed("sessions")):
            raise ValueError("Minimum sessions cannot exceed maximum sessions; change the other setting first.")
        if field == "session_renewal" and value != "0" and self.current("mux") != "on":
            raise ValueError("MUX OFF already creates a separate carrier per connection; enable MUX before scheduling renewal.")
        if field == "mux" and value == "off" and self.role == "origin" and self.current("session_renewal") != "0":
            raise ValueError("Disable scheduled session renewal before selecting MUX OFF.")
        if field in ("path_profile", "transport", "ws_path", "xhttp_path"):
            rotating = json.loads(value if field == "path_profile" else self.current("path_profile"))["interval"] != "0"
            if rotating:
                transport = proposed("transport")
                if transport not in ("wss", "xhttp", "auto", "h2"):
                    raise ValueError("Path rotation requires a WSS/XHTTP carrier, not raw TLS/GRE.")
                validate("xhttp_path", proposed("xhttp_path" if transport == "xhttp" else "ws_path"))
        if self.role == "origin" and field in ("sessions", "session_renewal", "path_profile", "mux"):
            rotating = json.loads(value if field == "path_profile" else self.current("path_profile"))["interval"] != "0"
            renewal = value if field == "session_renewal" else self.current("session_renewal")
            count = int(value if field == "sessions" else self.current("sessions"))
            if proposed("mux") == "on" and (rotating or renewal != "0") and count > 63:
                raise ValueError("Reserve one replacement carrier: maximum sessions must be at most 63 with rotation/renewal.")
        if field in ("max_memory_mb", "max_streams"):
            memory = int(proposed("max_memory_mb")) * 1048576
            # Match core's default 2*2MiB window plus 64KiB framing allowance.
            stream_memory = int(read_flag(self.script, "max-stream-memory", "4259840"))
            if memory < max(stream_memory, int(proposed("max_streams")) * 65536):
                raise ValueError("Memory must cover per-stream memory and at least 64 KiB per configured stream.")
        if field in ("ws_path", "h2_path") and proposed("ws_path") == proposed("h2_path"):
            raise ValueError("WebSocket and HTTP/2 paths must be different.")
        if field == "entry_path" and self.env.get("IRAN_ENTRY_TRANSPORT", "ws") == "xhttp":
            validate("xhttp_path", value)
        if field == "tls_min" and value == "1.2" and read_flag(self.script, "ech-mode", "off") == "strict":
            raise ValueError("Strict ECH requires TLS 1.3.")
        if field in ("ech_mode", "tls_fragment"):
            if proposed("ech_mode") == "strict" and proposed("tls_fragment") != "off":
                raise ValueError("Strict ECH and ClientHello fragmentation are mutually exclusive. Turn the other mode off first.")
            if field == "ech_mode" and value == "strict":
                if self.current("tls_min") != "1.3":
                    raise ValueError("Strict ECH requires TLS 1.3; change minimum TLS first.")
        if field == "transport" and value != "xhttp" and self.env.get("FOREIGN_PROXY_PROVIDER") == "fastly":
            raise ValueError("This Fastly profile supports only the experimental XHTTP carrier.")
        if field == "foreign_ports":
            provider_ports(self.env.get("FOREIGN_PROXY_PROVIDER", "none"), value)
        if field == "foreign_provider":
            provider_ports(value, self.env.get("FOREIGN_PORTS", ""))
            if value == "fastly" and self.current("transport") != "xhttp":
                raise ValueError("First migrate the carrier to XHTTP on BOTH peers; Fastly cannot use the normal carrier. Then choose HTTPS port 443 before changing provider.")
        return value

    def plan(self, field, value, certificate=None, emit=True):
        self.refresh()
        if field == "entry_profile":
            return self.entry_plan(value, certificate=certificate, emit=emit)
        value = self.validate_combination(field, validate(field, value))
        old = self.current(field)
        if emit and self.role == "egress" and field in ("iran_ip", "entry_domain", "entry_ports") and not old:
            raise ValueError("Iran metadata has not been synchronized yet. Make this edit on Iran first, then apply its signed update code here.")
        if old == value and not certificate:
            raise ValueError("This value is already configured; no changes needed.")
        env, script = dict(self.env), self.script
        changes, public_ports = {}, []
        site_text = self.site.read_text() if self.site else None
        changed_site = False
        access_path = self.directory / "access.json"
        accounts = access.load_json(access_path) if access_path.exists() else None
        new_site = self.site
        attributes = {}
        if field in ENV_FIELDS:
            env[ENV_FIELDS[field]] = value
        if field in FLAGS:
            script = set_flag(script, FLAGS[field], str(int(value) * 1048576) if field == "max_memory_mb" else value)
        if field == "path_profile":
            for key, (flag, env_key, _) in PATH_KEYS.items():
                setting = json.loads(value)[key]
                script = set_flag(script, flag, setting)
                env[env_key] = setting
        if field == "session_renewal":
            env["SESSION_RENEWAL"] = value
        if field == "profile":
            env["SPOOF_PROFILE"] = value
        for key, name in {"transport": "TRANSPORT", "xhttp_path": "XHTTP_PATH", "xhttp_mode": "XHTTP_MODE", "padding_bytes": "PADDING_BYTES", "xhttp_padding": "XHTTP_PADDING_BYTES", "ech_source": "ECH_SOURCE", "mux": "MUX_MODE", "ech_mode": "ECH_MODE", "tls_fragment": "TLS_FRAGMENT", "fragment_size": "TLS_FRAGMENT_SIZE", "fragment_interval": "TLS_FRAGMENT_INTERVAL"}.items():
            if field == key:
                env[name] = value
        if field == "tls_sni":
            env.update(TLS_SNI_EXPLICIT="1", TLS_SNI=value)
        if field == "http_host":
            env.update(HTTP_HOST_EXPLICIT="1", HTTP_HOST=value)
        if field == "transport" and value == "xhttp":
            script = set_flag(script, "xhttp-path", validate("xhttp_path", self.current("xhttp_path")))
            mode = validate("xhttp_mode", self.current("xhttp_mode"))
            script = set_flag(script, "xhttp-mode", mode)
            env.update(XHTTP_PATH=self.current("xhttp_path"), XHTTP_MODE=mode)
        if (field in ("transport", "xhttp_path", "path_profile") or field == "xhttp_mode" and read_flag(script, "transport", "auto") == "xhttp") and self.role == "egress":
            self.assert_site_owned()
            site_text = transport_routes(site_text, self.script, script, env)
            changed_site = True
        if field in ("ca", "local_ca"):
            # Parse the bundle without reading/logging private material.
            import ssl
            ssl.create_default_context(cafile=value)
            env["CA_PATH" if field == "ca" else "LOCAL_TLS_CA_PATH"] = value
        if field == "token":
            changes[self.directory / "token"] = (value + "\n").encode()
        if field in ("foreign_domain", "entry_domain"):
            local = (field == "foreign_domain" and self.role == "egress") or (field == "entry_domain" and self.role == "origin")
            if local:
                self.assert_site_owned()
                self.check_domain(value)
                cert, key = certificate or tls.certificate_paths(site_text)
                tls.validate_certificate(value, cert, key)
                site_text = tls.rewrite_site(site_text, old, value, cert, key)
                new_site = self.available / ("ununknowntun-" + value + ".conf")
                if new_site != self.site and (new_site.exists() or new_site.is_symlink() or (self.enabled / new_site.name).exists() or (self.enabled / new_site.name).is_symlink()):
                    raise ValueError("The new domain's Nginx path already exists; it will not be overwritten.")
                env["NGINX_SITE"] = str(new_site)
                changed_site = True
            if field == "foreign_domain":
                if env.get("HTTP_HOST_EXPLICIT") != "1" and env.get("HTTP_HOST", old) == old:
                    script = set_flag(script, "ws-host", value)
                    env["HTTP_HOST"] = value
                if self.role == "origin" and env.get("TLS_SNI_EXPLICIT") != "1" and env.get("TLS_SNI", old) == old:
                    script = set_flag(script, "sni", value)
                    env["TLS_SNI"] = value
        if field in ("connect_host", "foreign_domain", "foreign_ip", "foreign_ports", "foreign_provider") and self.role == "origin":
            host = env.get("CONNECT_HOST", "auto")
            if host == "auto" or not host:
                host = env["FOREIGN_IP"] if env.get("FOREIGN_PROXY_PROVIDER", "none") == "none" else env["FOREIGN_DOMAIN"]
            host = dial_host(host)
            authority = "[" + host + "]" if ":" in host else host
            script = set_flag(script, "connect", ",".join(authority + ":" + p for p in env["FOREIGN_PORTS"].split(",")))
        if field == "target_port":
            if self.role == "egress":
                if value == "80":
                    raise ValueError("Port 80 is reserved for certificate challenges, not Xray.")
                infrastructure = set()
                for key in ("FOREIGN_PORTS", "WSS_BACKEND_PORT", "H2_BACKEND_PORT"):
                    infrastructure.update(env.get(key, "").split(","))
                if value in infrastructure:
                    raise ValueError("Choose the Xray inbound, not this tunnel's HTTPS or internal transport port.")
                for path in self.directory.parent.glob("*/ports.list"):
                    if value in path.read_text().splitlines():
                        raise ValueError(f"Target port {value} is already reserved by {path.parent.name}; use a dedicated Xray inbound.")
                # A dedicated target already listens; verify rather than reserve/bind it.
                with socket.create_connection(("127.0.0.1", int(value)), timeout=3):
                    pass
            script = set_flag(script, "allow" if self.role == "egress" else "target", "127.0.0.1:" + value)
        active_transport = read_flag(script, "transport", "auto")
        route_active = (field == "ws_path" and active_transport in ("wss", "auto")) or (field == "h2_path" and active_transport in ("h2", "auto"))
        if route_active and self.role == "egress":
            self.assert_site_owned()
            pattern = r"(?m)^(\s*location\s*=\s*)" + re.escape(old) + r"(\s*\{)"
            site_text, count = re.subn(pattern, lambda m: m[1] + value + m[2], site_text)
            if count != 1:
                raise ValueError("Expected managed transport route was not found exactly once.")
            changed_site = True
        if field == "entry_path" and self.role == "origin":
            self.assert_site_owned()
            if env.get("IRAN_ENTRY_TRANSPORT", "ws") == "xhttp":
                validate("xhttp_path", value)
            xhttp_entry = env.get("IRAN_ENTRY_TRANSPORT", "ws") == "xhttp"
            old_route = old.rstrip("/") + "/" if xhttp_entry else old
            new_route = value.rstrip("/") + "/" if xhttp_entry else value
            pattern = r"(?m)^(\s*location\s*(?:=|\^~)\s*)" + re.escape(old_route) + r"(\s*\{)"
            site_text, count = re.subn(pattern, lambda m: m[1] + new_route + m[2], site_text)
            disabled_default = accounts and not next((a["enabled"] for a in accounts["accounts"] if a["id"] == "default"), True)
            if count != 1 and not (count == 0 and disabled_default and access.BEGIN in site_text and access.END in site_text):
                raise ValueError("Original client WebSocket route was not found exactly once.")
            site_text = re.sub(r"(proxy_pass http://127\.0\.0\.1:[0-9]+)" + re.escape(old_route) + r";", lambda m: m[1] + new_route + ";", site_text)
            route_file = self.directory / "access-routes.json"
            if route_file.exists():
                routes = access.load_json(route_file)
                if routes.get("default") == old:
                    routes["default"] = value
                    changes[route_file] = access.encoded_json(routes).encode()
            changed_site = True
        if (field == "entry_ports" and self.role == "origin") or (field == "foreign_ports" and self.role == "egress"):
            https = field == "foreign_ports" or env.get("IRAN_PROXY_PROVIDER", "none") != "none"
            self.check_ports(value, old, https)
            public_ports = [int(p) for p in value.split(",") if p not in old.split(",")]
            if https:
                self.assert_site_owned()
                pattern = r"(?m)^[ \t]*listen [0-9]+ ssl(?: http2)?;[ \t]*\n"
                if not re.search(pattern, site_text):
                    raise ValueError("Managed HTTPS listeners were not found.")
                inserted = False
                def replace(match):
                    nonlocal inserted
                    if inserted:
                        return ""
                    inserted = True
                    return "".join("    listen " + p + " ssl http2;\n" for p in value.split(","))
                site_text = re.sub(pattern, replace, site_text)
                changed_site = True
            else:
                env["LOCAL_PORTS"] = value
                listen = ",".join("0.0.0.0:" + p for p in value.split(","))
                script = set_flag(script, "listen", listen)
                if accounts is not None:
                    default = next((a for a in accounts["accounts"] if a["id"] == "default"), None)
                    if not default:
                        raise ValueError("No default customer exists; edit individual customer ports instead.")
                    default["listen"] = listen
                    changes[access_path] = access.encoded_json(accounts).encode()
        if changed_site:
            self.assert_site_owned()
            changes[new_site] = site_text.encode()
            if new_site != self.site:
                attributes[new_site] = self.capture(self.site)
            if (self.enabled / self.site.name).is_symlink():
                changes[self.enabled / new_site.name] = Link(new_site)
            if new_site != self.site:
                changes[self.site] = None
                changes[self.enabled / self.site.name] = None
        if script != self.script:
            changes[self.directory / "run.sh"] = script.encode()
        changes[self.directory / "deployment.env"] = encode_env(env).encode()
        self.refresh_metadata(changes, env, script, accounts, value if field == "token" else self.token)
        plan = {"field": field, "old": old, "value": value, "changes": changes, "nginx": changed_site, "restart": script != self.script or field == "token" or access_path in changes, "public_ports": public_ports, "update": None, "attributes": attributes}
        if emit and field in SYNC_FIELDS:
            plan["update"] = self.make_update(field, old, value)
            changes[self.directory / "last-edit-update.txt"] = (plan["update"] + "\n").encode()
            changes[self.directory / ("edit-update-" + digest(plan["update"])[:16] + ".txt")] = (plan["update"] + "\n").encode()
        return plan

    def entry_plan(self, value, certificate=None, emit=True, direct_ports=None):
        """Stage a local entry migration; never move accounting state or IDs.

        The authenticated peer sees only public entry metadata, never local
        certificate/key paths or per-customer private listener assignments.
        """
        self.refresh()
        value = validate("entry_profile", value)
        profile, old = json.loads(value), self.current("entry_profile")
        if self.role == "egress" and emit:
            raise ValueError("Initiate entry migrations on Iran, then apply its signed code here.")
        if value == old:
            raise ValueError("Entry profile is unchanged.")
        env, changes, attributes, script = dict(self.env), {}, {}, self.script
        env.update({ENTRY_KEYS[key]: item for key, item in profile.items()})
        env["ENTRY_PROFILE_SYNCED"] = "1"
        accounts_path = self.directory / "access.json"
        accounts = access.load_json(accounts_path) if self.role == "origin" else None
        new_site, public_ports, nginx_changed = self.site, [], False
        if self.role == "origin":
            if not accounts or not accounts.get("accounts"):
                raise ValueError("Upgrade customer accounting before migrating the entry.")
            ids = {a["id"] for a in accounts["accounts"]}
            if len(ids) != len(accounts["accounts"]) or "default" not in ids:
                raise ValueError("A unique default account and unique customer IDs are required.")
            proxied = profile["provider"] != "none"
            was_proxied = self.env.get("IRAN_PROXY_PROVIDER", "none") != "none"
            routes_path = self.directory / "access-routes.json"
            routes = access.load_json(routes_path) if routes_path.exists() else {}
            used = set()
            if proxied:
                self.run("nginx", "-v")  # Missing Nginx is detected before mutations.
                self.check_domain(profile["domain"])
                self.check_ports(profile["ports"], self.env.get("IRAN_ENTRY_PORTS", "") if was_proxied else "", True, profile["provider"])
                used.update(map(int, profile["ports"].split(",")))
                if not was_proxied:
                    env["ENTRY_DIRECT_PORTS"] = canonical({a["id"]: ",".join(str(p.rsplit(":", 1)[1]) for p in a["listen"].split(",")) for a in accounts["accounts"]}).decode()
                for account in accounts["accounts"]:
                    if was_proxied:
                        if not re.fullmatch(r"127\.0\.0\.1:[0-9]{1,5}", account["listen"]):
                            raise ValueError("A proxied account has an unsupported listener layout.")
                        port = access.port_number(account["listen"].rsplit(":", 1)[1])
                    else:
                        port = None
                        for candidate in range(20000, 61000):
                            if candidate in used:
                                continue
                            try:
                                self.check_ports(str(candidate), "")
                            except ValueError:
                                continue
                            port = candidate
                            break
                        if port is None:
                            raise ValueError("No free private customer listener could be reserved.")
                    if port in used:
                        raise ValueError("Customer listener overlaps another customer or public HTTPS port.")
                    used.add(port)
                    account["listen"] = "127.0.0.1:" + str(port)
                    if account["id"] == "default":
                        routes["default"] = profile["path"]
                    else:
                        routes.setdefault(account["id"], "/gdt-c/" + secrets.token_hex(16))
                base = self.site.read_text() if self.site else (self.directory / "entry-site.saved.conf").read_text() if (self.directory / "entry-site.saved.conf").exists() else None
                if self.site:
                    self.assert_site_owned()
                if certificate is None and base:
                    certificate = tls.certificate_paths(base)
                if certificate is None:
                    raise ValueError("Choose an existing certificate and private key covering the Iran entry domain.")
                cert, key = tls.validate_certificate(profile["domain"], *certificate)
                if base:
                    base = tls.rewrite_site(base, self.env.get("IRAN_ENTRY_DOMAIN", "") or profile["domain"], profile["domain"], cert, key)
                    # Remove only the former default entry, outside/inside
                    # customer markers. The marker block is regenerated below.
                    old_path = self.env.get("IRAN_ENTRY_PATH", "")
                    pattern = r"(?m)^[ \t]*location\s+(?:=|\^~)\s+" + re.escape(old_path.rstrip("/")) + r"/?\s*\{[^{}]*\}"
                    base, count = re.subn(pattern, "", base)
                    disabled_default = not next(a for a in accounts["accounts"] if a["id"] == "default")["enabled"]
                    if count != 1 and not (count == 0 and disabled_default and access.BEGIN in base and access.END in base):
                        raise ValueError("The managed default entry route was not found exactly once; no files changed.")
                    listeners = r"(?m)^[ \t]*listen [0-9]+ ssl(?: http2)?;[ \t]*\n"
                    if not re.search(listeners, base):
                        raise ValueError("Managed HTTPS listeners were not found.")
                    base = re.sub(listeners, "", base)
                    at = base.find("ssl_certificate ")
                    base = base[:at] + "\n".join("listen " + p + " ssl http2;" for p in profile["ports"].split(",")) + "\n    " + base[at:]
                else:
                    # A new private site is needed only for direct -> proxy.
                    base = "server {\n    listen 80;\n    server_name " + profile["domain"] + ";\n    root /var/www/ununknowntun-decoy;\n    location ^~ /.well-known/acme-challenge/ { try_files $uri =404; }\n    location / { try_files $uri $uri/ /index.html; }\n}\nserver {\n"
                    base += "".join("    listen " + p + " ssl http2;\n" for p in profile["ports"].split(","))
                    base += "    server_name " + profile["domain"] + ";\n    server_tokens off;\n    ssl_certificate " + cert + ";\n    ssl_certificate_key " + key + ";\n    ssl_protocols TLSv1.2 TLSv1.3;\n    # UNUNKNOWNTUN_CUSTOMER_ROUTES\n    location / { default_type text/html; return 200 '<!doctype html><html><head><title>Service Status</title></head><body><h1>Service Status</h1><p>All systems operational.</p></body></html>'; }\n}\n"
                site_text = access.build_routes(base, accounts, routes, profile["path"], profile["transport"])
                new_site = self.available / ("ununknowntun-" + profile["domain"] + ".conf")
                new_link = self.enabled / new_site.name
                if new_site != self.site and any(p.exists() or p.is_symlink() for p in (new_site, new_link)):
                    raise ValueError("The destination managed site already exists; it will not be overwritten.")
                changes[new_site] = site_text.encode()
                keep_enabled = (self.enabled / self.site.name).is_symlink() if self.site else env.get("ENTRY_SITE_ENABLED", "1") == "1"
                if keep_enabled:
                    changes[new_link] = Link(new_site)
                if self.site and self.site != new_site:
                    attributes[new_site] = self.capture(self.site)
                    changes[self.site] = None
                    changes[self.enabled / self.site.name] = None
                env["NGINX_SITE"] = str(new_site)
                changes[routes_path] = access.encoded_json(routes).encode()
                public_ports = [int(p) for p in profile["ports"].split(",") if not was_proxied or p not in self.env.get("IRAN_ENTRY_PORTS", "").split(",")]
                nginx_changed = True
            else:
                assigned = direct_ports or (json.loads(self.env.get("ENTRY_DIRECT_PORTS", "{}")) if was_proxied else {a["id"]: ",".join(p.rsplit(":", 1)[1] for p in a["listen"].split(",")) for a in accounts["accounts"]})
                if set(assigned) != ids:
                    raise ValueError("Assign dedicated public port(s) to every existing customer; no customer may be dropped.")
                assigned = {key: ports(item) for key, item in assigned.items()}
                if assigned["default"] != profile["ports"]:
                    raise ValueError("Default customer's ports must match the direct entry profile.")
                for account in accounts["accounts"]:
                    value_ports = assigned[account["id"]]
                    numbers = set(map(int, value_ports.split(",")))
                    if used & numbers:
                        raise ValueError("Each customer requires distinct public ports.")
                    old_ports = ",".join(p.rsplit(":", 1)[1] for p in account["listen"].split(",")) if not was_proxied else ""
                    self.check_ports(value_ports, old_ports)
                    used.update(numbers)
                    public_ports.extend(p for p in numbers if str(p) not in old_ports.split(","))
                    account["listen"] = ",".join("0.0.0.0:" + p for p in value_ports.split(","))
                env["ENTRY_DIRECT_PORTS"] = canonical(assigned).decode()
                env["NGINX_SITE"] = ""
                if self.site:
                    self.assert_site_owned()
                    env["ENTRY_SITE_ENABLED"] = "1" if (self.enabled / self.site.name).is_symlink() else "0"
                    changes[self.directory / "entry-site.saved.conf"] = self.site.read_bytes()
                    changes[self.site] = None
                    changes[self.enabled / self.site.name] = None
                    nginx_changed = True
                new_site = None
            default = next(a for a in accounts["accounts"] if a["id"] == "default")
            env["LOCAL_PORTS"] = ",".join(p.rsplit(":", 1)[1] for p in default["listen"].split(","))
            script = set_flag(script, "listen", default["listen"])
            changes[accounts_path] = access.encoded_json(accounts).encode()
        changes[self.directory / "deployment.env"] = encode_env(env).encode()
        if script != self.script:
            changes[self.directory / "run.sh"] = script.encode()
        self.refresh_metadata(changes, env, script, accounts, self.token)
        plan = {"field": "entry_profile", "old": old, "value": value, "changes": changes, "nginx": nginx_changed, "restart": self.role == "origin", "public_ports": sorted(set(public_ports)), "update": None, "attributes": attributes}
        if emit:
            plan["update"] = self.make_update("entry_profile", old, value)
            changes[self.directory / "last-edit-update.txt"] = (plan["update"] + "\n").encode()
            changes[self.directory / ("edit-update-" + digest(plan["update"])[:16] + ".txt")] = (plan["update"] + "\n").encode()
        return plan

    def certificate_plan(self, cert, key):
        self.refresh()
        self.assert_site_owned()
        domain = self.local_domain()
        tls.validate_certificate(domain, cert, key)
        site = tls.rewrite_site(self.site.read_text(), domain, domain, cert, key)
        return {"field": "certificate", "old": "current certificate files", "value": cert, "changes": {self.site: site.encode()}, "nginx": True, "restart": False, "public_ports": [], "update": None}

    def refresh_metadata(self, changes, env, script, accounts, token):
        local = []
        keys = ("FOREIGN_PORTS", "WSS_BACKEND_PORT", "H2_BACKEND_PORT", "TARGET_PORT") if self.role == "egress" else ("LOCAL_PORTS", "IRAN_ENTRY_PORTS")
        for key in keys:
            local.extend(int(p) for p in env.get(key, "").split(",") if p)
        if accounts:
            local.extend(access.listeners(accounts))
        changes[self.directory / "ports.list"] = "".join(str(p) + "\n" for p in sorted(set(local))).encode()
        peer_path = self.directory / "peer.env"
        if peer_path.exists():
            peer = dict(line.split("=", 1) for line in peer_path.read_text().splitlines() if "=" in line)
            for dest, src in {"TUNNEL_NAME": "TUNNEL_NAME", "FOREIGN_IP": "FOREIGN_IP", "DOMAIN": "FOREIGN_DOMAIN", "PORTS": "FOREIGN_PORTS", "TARGET_PORT": "TARGET_PORT", "IRAN_ENTRY_PATH": "IRAN_ENTRY_PATH", "SPOOF_PROFILE": "SPOOF_PROFILE", "FOREIGN_PROXY_PROVIDER": "FOREIGN_PROXY_PROVIDER", "IRAN_PROXY_PROVIDER": "IRAN_PROXY_PROVIDER"}.items():
                if src in env:
                    peer[dest] = env[src]
            peer.update(FORMAT="UNUNKNOWNTUN_V5_FLEET", TOKEN=token, WS_PATH=read_flag(script, "ws-path"), H2_PATH=read_flag(script, "h2-path"), TRANSPORT=read_flag(script, "transport", "wss"), XHTTP_PATH=read_flag(script, "xhttp-path", read_flag(script, "ws-path")), XHTTP_MODE=read_flag(script, "xhttp-mode", "packet-up"), HTTP_HOST=read_flag(script, "ws-host", env.get("FOREIGN_DOMAIN", "")), MUX_MODE=read_flag(script, "mux", "on"), IRAN_ENTRY_TRANSPORT=env.get("IRAN_ENTRY_TRANSPORT", "ws"))
            peer.update({env_key: read_flag(script, flag, default) for flag, env_key, default in PATH_KEYS.values()})
            changes[peer_path] = "".join(k + "=" + v + "\n" for k, v in peer.items()).encode()
        info = [f"UNUNKNOWNTUN tunnel: {self.id}", f"Name: {env.get('TUNNEL_NAME', self.id)}", f"Role: {self.role}", f"Foreign transport endpoint: {env.get('FOREIGN_DOMAIN')} ports {env.get('FOREIGN_PORTS')}", f"Carrier: {read_flag(script, 'transport', 'auto')}; MUX: {read_flag(script, 'mux', 'on')}", f"ECH: {read_flag(script, 'ech-mode', 'off')}; TLS fragmentation: {read_flag(script, 'tls-fragment', 'off')}", f"XHTTP base path: {read_flag(script, 'xhttp-path', read_flag(script, 'ws-path'))}", f"Direct foreign IP: {env.get('FOREIGN_IP')}", f"Iran client address: {env.get('IRAN_ENTRY_DOMAIN') or env.get('IRAN_IP')}", f"Iran internal listeners: {env.get('LOCAL_PORTS', '')}", f"Iran public entry ports: {env.get('IRAN_ENTRY_PORTS', '')}", f"Iran client entry transport: {env.get('IRAN_ENTRY_TRANSPORT', 'ws')}; path: {env.get('IRAN_ENTRY_PATH', '')}", f"Foreign Xray inbound target: 127.0.0.1:{env.get('TARGET_PORT')}", "Get current customer endpoint files: ununknowntunctl customer-export " + self.id, "Transport edits require a real-client check; Xray settings and DNS/CDN are not changed automatically."]
        info.extend((f"Dial host override: {env.get('CONNECT_HOST', 'auto')}", f"TLS SNI: {read_flag(script, 'sni')}; HTTP Host: {read_flag(script, 'ws-host')}", f"XHTTP mode: {read_flag(script, 'xhttp-mode', 'packet-up')}; XHTTP header padding: {read_flag(script, 'xhttp-padding-bytes', '0')}", f"UNUNKNOWNTUN frame padding: {read_flag(script, 'padding-bytes', '0')}", "ECH source: " + ("automatic" if read_flag(script, 'ech-config', 'auto') in ('', 'auto') else "manual (configuration kept in private tunnel files)")))
        info.extend((f"Path rotation: {read_flag(script, 'path-rotation', '0')}; candidates: {read_flag(script, 'path-count', '3')}; overlap: {read_flag(script, 'path-grace', '5m')}", f"Carrier renewal: {read_flag(script, 'session-renewal', '0')}; rotation may also renew carriers"))
        changes[self.directory / "client-info.txt"] = ("\n".join(info) + "\n").encode()
        if accounts and self.role == "origin":
            exports = self.directory / "customer-exports"
            if exports.is_symlink():
                raise ValueError("Customer export directory must not be a symlink.")
            route_file = self.directory / "access-routes.json"
            routes = json.loads(changes[route_file]) if changes.get(route_file) else access.load_json(route_file) if route_file.exists() else {}
            by_id = {a["id"]: a for a in accounts["accounts"]}
            for path in (self.directory / "customer-exports").glob("*.json"):
                if path.is_symlink() or path.stem not in by_id:
                    raise ValueError("Unknown customer export; review it before editing tunnel endpoints.")
                payload = access.load_json(path)
                if payload.get("format") != "UNUNKNOWNTUN_CUSTOMER_ENDPOINT_V1":
                    raise ValueError("Unrecognized customer export format.")
                proxied = env.get("IRAN_PROXY_PROVIDER", "none") != "none"
                payload["address"] = env.get("IRAN_ENTRY_DOMAIN", "") if proxied else env.get("IRAN_IP", "")
                if proxied:
                    payload["tls"] = True
                    payload.update(sni=payload["address"], host=payload["address"], path=routes.get(path.stem, env.get("IRAN_ENTRY_PATH", "") if path.stem == "default" else ""), ports=[int(p) for p in env["IRAN_ENTRY_PORTS"].split(",")])
                    payload["transport"] = "xhttp" if env.get("IRAN_ENTRY_TRANSPORT", "ws") == "xhttp" else "websocket"
                    if payload["transport"] == "xhttp":
                        payload["xhttp_mode"] = "packet-up"
                    else:
                        payload.pop("xhttp_mode", None)
                else:
                    for key in ("sni", "host", "path", "xhttp_mode", "tls", "compatibility"):
                        payload.pop(key, None)
                    payload.update(transport="match the dedicated Xray inbound")
                    payload["ports"] = [int(a.rsplit(":", 1)[1]) for a in by_id[path.stem]["listen"].split(",")]
                changes[path] = access.encoded_json(payload).encode()

    def make_update(self, field, old, value):
        pair = self.env.get("PAIR_ID", "")
        if not re.fullmatch(r"[a-f0-9]{16}", pair):
            raise ValueError("Pair identity is missing; upgrade/import valid pairing metadata first.")
        data = {"format": "UNUNKNOWNTUN_EDIT_V3", "pair": pair, "from": self.role, "field": field, "previous": digest(old), "value": value, "created": int(time.time()), "nonce": secrets.token_hex(16)}
        signature = hmac.new(self.token.encode(), canonical(data), hashlib.sha256).hexdigest()
        return base64.b64encode(canonical({"data": data, "signature": signature})).decode()

    def decode_update(self, code):
        self.refresh()
        if len(code) > 20000:
            raise ValueError("Update code is too large.")
        try:
            envelope = json.loads(base64.b64decode("".join(code.split()), validate=True), object_pairs_hook=unique_object)
            data, signature = envelope["data"], envelope["signature"]
            if set(envelope) != {"data", "signature"} or set(data) != {"format", "pair", "from", "field", "previous", "value", "created", "nonce"}:
                raise ValueError()
            wanted = hmac.new(self.token.encode(), canonical(data), hashlib.sha256).hexdigest()
            if not isinstance(signature, str) or not hmac.compare_digest(signature, wanted):
                raise ValueError()
            if data["format"] != "UNUNKNOWNTUN_EDIT_V3" or data["pair"] != self.env.get("PAIR_ID") or data["from"] != ("egress" if self.role == "origin" else "origin"):
                raise ValueError()
            if type(data["created"]) is not int or not -300 <= time.time() - data["created"] <= 7 * 86400 or not re.fullmatch(r"[a-f0-9]{32}", data["nonce"]):
                raise ValueError()
            field, value = data["field"], data["value"]
            if field not in SYNC_FIELDS:
                raise ValueError()
            if not isinstance(data["previous"], str) or not re.fullmatch(r"[a-f0-9]{64}", data["previous"]):
                raise ValueError()
            value = validate(field, value)
            bootstrap = self.role == "egress" and field in ("iran_ip", "entry_domain", "entry_ports") and self.current(field) == ""
            # The original one-way import has no Iran public ports/domain on
            # egress. A signed first profile from its paired origin can fill
            # these absent fields ONCE; later migrations are strictly stale-checked.
            bootstrap = bootstrap or (self.role == "egress" and field == "entry_profile" and not self.env.get("ENTRY_PROFILE_SYNCED"))
            # Legacy egress accepted auto while Arvan origins deliberately used
            # wss. These are compatible old configurations, not a stale edit.
            # Permit this one migration only before explicit 3.4 metadata exists.
            legacy_transports = {"auto", "wss", "h2"}
            bootstrap = bootstrap or (field == "transport" and "TRANSPORT" not in self.env
                                      and self.current(field) in legacy_transports
                                      and data["previous"] in {digest(mode) for mode in legacy_transports})
            if not bootstrap and digest(self.current(field)) != data["previous"]:
                raise ValueError("stale")
            return field, value
        except (KeyError, TypeError, ValueError, UnicodeError, RecursionError) as error:
            raise ValueError("Invalid, stale, expired, or wrong-peer update code. Use a fresh V3 edit code from the paired server; old V2 codes are not accepted.") from error

    @staticmethod
    def capture(path):
        if path.is_symlink():
            return ("link", os.readlink(path), None, None)
        if not path.exists():
            return ("missing", None, None, None)
        if not path.is_file():
            raise ValueError("Managed edit target is not a regular file: " + str(path))
        stat = path.stat()
        return ("file", path.read_bytes(), stat.st_mode & 0o777, (stat.st_uid, stat.st_gid))

    def write(self, path, value, previous):
        if isinstance(value, Link):
            path.parent.mkdir(parents=True, exist_ok=True)
            staged = path.with_name("." + path.name + ".edit-" + secrets.token_hex(6))
            try:
                staged.symlink_to(value.target)
                os.replace(staged, path)
            finally:
                if staged.is_symlink():
                    staged.unlink()
        elif value is None:
            if path.exists() or path.is_symlink():
                path.unlink()
        else:
            if previous[0] == "link":
                raise ValueError("Refusing to replace an unexpected configuration symlink.")
            private = path.name in ("peer.env", "last-edit-update.txt") or path.name.startswith("edit-update-") or path.parent.name == "customer-exports"
            mode = 0o600 if private else previous[2] if previous[0] == "file" else 0o644 if path.parent == self.available else 0o640
            owner = previous[3]
            if owner is None and path.parent == self.directory and not private:
                stat = (self.directory / "deployment.env").stat()
                owner = (stat.st_uid, stat.st_gid)
            access.atomic_write(path, value, mode=mode, owner=owner)

    def wait_service(self, after_ns):
        invocation = self.run("systemctl", "show", self.service, "-p", "InvocationID", "--value").stdout.strip()
        if not re.fullmatch(r"[a-fA-F0-9]{32}", invocation):
            raise RuntimeError("Service invocation is unavailable after restart.")
        access_path = self.directory / "access.json"
        status_path = self.state_dir / "access-state.json.status.json"
        wanted = hashlib.sha256(access_path.read_bytes()).hexdigest() if self.role == "origin" and access_path.exists() else None
        for _ in range(50):
            if not self.active():
                raise RuntimeError("Edited service is not active.")
            accepted = wanted is None
            if wanted:
                try:
                    status = access.load_json(status_path)
                    accepted = status_path.stat().st_mtime_ns >= after_ns and status.get("running") and not status.get("error") and status.get("config_revision") == wanted
                except (OSError, ValueError):
                    pass
            if accepted:
                time.sleep(.2)
                if not self.active() or self.run("systemctl", "show", self.service, "-p", "InvocationID", "--value").stdout.strip() != invocation:
                    raise RuntimeError("Service restarted during edit validation.")
                return
            time.sleep(.1)
        raise RuntimeError("Fresh customer-accounting acknowledgment was not received.")

    def commit(self, plan, post_validate=None):
        if post_validate is not None and not callable(post_validate):
            raise ValueError("Post-edit validation must be a callable.")
        changes = dict(plan["changes"])
        owned_path = self.directory / "firewall-owned.ports"
        if plan["public_ports"]:
            changes.setdefault(owned_path, owned_path.read_bytes() if owned_path.exists() else b"")
        # A final boundary check protects the traffic ledger even from mistakes
        # in future planner fields. Only selected config, own sites/links allowed.
        allowed_sites = {self.site} if self.site else set()
        if plan["nginx"]:
            if self.site:
                self.assert_site_owned()
            if plan["field"] in ("foreign_domain", "entry_domain"):
                allowed_sites.add(self.available / ("ununknowntun-" + tls.validate_domain(plan["value"]) + ".conf"))
            if plan["field"] == "entry_profile" and self.role == "origin":
                profile = json.loads(validate("entry_profile", plan["value"]))
                if profile["provider"] != "none":
                    allowed_sites.add(self.available / ("ununknowntun-" + profile["domain"] + ".conf"))
        allowed_links = {self.enabled / site.name for site in allowed_sites}
        local_files = {"run.sh", "deployment.env", "token", "access.json", "access-routes.json", "entry-site.saved.conf", "peer.env", "client-info.txt", "ports.list", "firewall-owned.ports", "last-edit-update.txt"}
        exports = self.directory / "customer-exports"
        if exports.is_symlink():
            raise ValueError("Customer export directory must not be a symlink.")
        for path, content in changes.items():
            permitted = (path.parent == self.directory and (path.name in local_files or re.fullmatch(r"edit-update-[a-f0-9]{16}\.txt", path.name))) or (path.parent == exports and path.suffix == ".json" and not path.is_symlink()) or (plan["nginx"] and path in allowed_sites | allowed_links)
            if not permitted or path.name.startswith("access-state"):
                raise ValueError("Edit attempted an out-of-scope path.")
            if isinstance(content, Link) and (path not in allowed_links or Path(content.target) not in allowed_sites or Path(content.target).name != path.name):
                raise ValueError("Edit attempted an unrelated Nginx link.")
        snapshots = {path: self.capture(path) for path in changes}
        (self.install_dir / "backups").mkdir(parents=True, mode=0o700, exist_ok=True)
        backup = Path(tempfile.mkdtemp(prefix="edit-" + self.id + "-", dir=self.install_dir / "backups"))
        os.chmod(backup, 0o700)
        manifest = []
        for index, (path, snapshot) in enumerate(snapshots.items()):
            kind, content, mode, owner = snapshot
            if kind == "file":
                access.atomic_write(backup / str(index), content, mode=0o600)
            manifest.append({"path": str(path), "kind": kind, "file": str(index), "link": content if kind == "link" else None, "mode": mode, "owner": owner})
        access.atomic_write(backup / "manifest.json", access.encoded_json(manifest), mode=0o600)
        was_active = self.active()
        nginx_active = self.active("nginx") if plan["nginx"] else False
        added_rules = []
        restart_attempted = False
        background = plan.get("background") is True
        try:
            if background and not was_active:
                raise RuntimeError("Background endpoint update cancelled because the tunnel is stopped.")
            for path, content in changes.items():
                self.write(path, content, plan.get("attributes", {}).get(path, snapshots[path]))
            self.run("sh", "-n", str(self.directory / "run.sh"))
            if plan["nginx"]:
                self.run("nginx", "-t")
            if plan["public_ports"]:
                import shutil
                if shutil.which("ufw") and "Status: active" in self.run("ufw", "status", check=False).stdout:
                    for port in plan["public_ports"]:
                        result = self.run("ufw", "allow", "proto", "tcp", "from", "0.0.0.0/0", "to", "0.0.0.0/0", "port", str(port))
                        if "Rule added" in result.stdout or "Rules updated" in result.stdout:
                            added_rules.append(port)
                    owned = set(changes[owned_path].decode().splitlines()) | set(map(str, added_rules))
                    self.write(owned_path, ("\n".join(sorted(owned, key=int)) + "\n").encode(), snapshots[owned_path])
            if plan["restart"] and was_active:
                restart_attempted = True
                self.run("systemctl", "try-restart" if background else "restart", self.service)
                if background and not self.active():
                    raise RuntimeError("Tunnel was stopped during the background update; restoring its previous configuration.")
                self.wait_service(time.time_ns())
            if plan["nginx"] and nginx_active:
                self.run("systemctl", "reload", "nginx")
            if post_validate is not None:
                self.refresh()
                if post_validate() is False:
                    raise RuntimeError("Post-edit authenticated validation failed.")
        except BaseException:
            failures = []
            for path, snapshot in reversed(list(snapshots.items())):
                try:
                    kind, content, _, _ = snapshot
                    self.write(path, Link(content) if kind == "link" else content if kind == "file" else None, snapshot)
                except Exception as error:
                    failures.append(str(path) + ": " + str(error))
            for port in added_rules:
                try:
                    self.run("ufw", "--force", "delete", "allow", "proto", "tcp", "from", "0.0.0.0/0", "to", "0.0.0.0/0", "port", str(port))
                except Exception as error:
                    failures.append("firewall: " + str(error))
            if plan["nginx"] and nginx_active and not failures:
                try:
                    self.run("nginx", "-t")
                    self.run("systemctl", "reload", "nginx")
                except Exception as error:
                    failures.append("Nginx recovery: " + str(error))
            if restart_attempted or failures:
                try:
                    if was_active and not failures:
                        self.run("systemctl", "try-restart" if background else "restart", self.service)
                        if not background or self.active():
                            self.wait_service(time.time_ns())
                    else:
                        self.run("systemctl", "stop", self.service)
                except Exception as error:
                    failures.append("Service recovery: " + str(error))
                    self.run("systemctl", "stop", self.service, check=False)
            print("Edit failed; " + ("manual recovery required: " + "; ".join(failures) if failures else "previous managed files/service state restored") + f". Backup: {backup}", file=sys.stderr)
            self.refresh()
            raise
        self.refresh()
        print(f"Edit saved. Backup: {backup}. Usage and customer identities were retained.")
        if not was_active:
            print("The tunnel was stopped and remains stopped; new settings apply when you start it.")
        if plan["nginx"] and not nginx_active:
            print("Nginx was stopped and remains stopped. Start it after checking the planned DNS/CDN/certificate changes.")
        if plan["update"]:
            print("Apply this CONFIDENTIAL code on the paired server with ununknowntunctl edit-apply. It expires in 7 days; coordinate changes before relying on the tunnel:")
            print(plan["update"])
            print("Saved privately in " + str(self.directory / "last-edit-update.txt"))
        if plan["field"] in ("foreign_domain", "entry_domain", "foreign_ip", "iran_ip", "foreign_ports", "entry_ports", "certificate", "foreign_provider", "entry_profile"):
            print("Update DNS/CDN origin settings and customer configurations as appropriate. Previously shared exports are not updated on customer devices; redistribute fresh files.")
        if plan["field"] in ("entry_path", "target_port", "entry_profile"):
            print("The dedicated foreign Xray inbound must match the entry transport (WS or XHTTP packet-up), path and port. Xray configuration was NOT changed automatically. Direct entries inherit the inbound's TLS/protocol; proxy entries terminate public TLS at Nginx and need a non-TLS inbound.")
        print("Local configuration/service checks passed; test a real client after paired changes. Network reachability was not certified.")

    def certificate_prompt(self, domain):
        print(f"Certificate must already cover {domain}. No old certificate is deleted or overwritten.")
        cert, key = "", ""
        candidate = self.site or self.directory / "entry-site.saved.conf"
        if candidate.is_file():
            try:
                cert, key = tls.certificate_paths(candidate.read_text())
            except ValueError:
                pass
        while True:
            cert = access.prompt("Fullchain certificate absolute path", cert)
            key = access.prompt("Private-key absolute path", key)
            try:
                return tls.validate_certificate(domain, cert, key)
            except (ValueError, OSError, subprocess.CalledProcessError) as error:
                print("Certificate rejected: " + str(error), file=sys.stderr)

    def entry_prompt(self):
        if self.role != "origin":
            raise ValueError("Make entry migrations on Iran and apply its signed code on the foreign side.")
        profile = json.loads(self.current("entry_profile"))
        profile["provider"] = access.prompt("Iran entry: none (raw TCP), nginx (HTTPS without CDN), cloudflare/arvan/fastly", profile["provider"], lambda v: v if v == "nginx" else validate("foreign_provider", v))
        profile["transport"] = access.prompt("Client entry protocol: ws/xhttp (independent of tunnel carrier)", "xhttp" if profile["provider"] == "fastly" else profile["transport"], lambda v: v if v in (("xhttp",) if profile["provider"] == "fastly" else ("ws", "xhttp")) else (_ for _ in ()).throw(ValueError("Choose the matching supported client-entry protocol.")))
        profile["path"] = access.prompt("Matching foreign inbound path", profile["path"] or "/gdt-entry/" + secrets.token_hex(12), lambda v: validate("xhttp_path" if profile["transport"] == "xhttp" else "entry_path", v))
        certificate, assigned = None, None
        if profile["provider"] != "none":
            profile["domain"] = access.prompt("Iran public entry domain", profile["domain"], tls.validate_domain)
            def public_ports(value):
                value = provider_ports(profile["provider"], value)
                self.check_ports(value, self.env.get("IRAN_ENTRY_PORTS", "") if self.env.get("IRAN_PROXY_PROVIDER", "none") != "none" else "", True, profile["provider"])
                return value
            profile["ports"] = access.prompt("Iran public HTTPS port(s)", "443", public_ports)
            certificate = self.certificate_prompt(profile["domain"])
        else:
            accounts = access.load_json(self.directory / "access.json")
            saved = json.loads(self.env.get("ENTRY_DIRECT_PORTS", "{}"))
            assigned, used = {}, set()
            for account in accounts["accounts"]:
                old = ",".join(p.rsplit(":", 1)[1] for p in account["listen"].split(",")) if self.env.get("IRAN_PROXY_PROVIDER", "none") == "none" else ""
                def customer_ports(value):
                    value = ports(value)
                    if used & set(map(int, value.split(","))):
                        raise ValueError("Another customer in this plan already uses a selected port.")
                    self.check_ports(value, old)
                    return value
                assigned[account["id"]] = access.prompt("Public port(s) for " + account["name"] + " [" + account["id"] + "]", saved.get(account["id"], old), customer_ports)
                used.update(map(int, assigned[account["id"]].split(",")))
            profile["ports"] = assigned["default"]
        print("Migration changes ONLY this tunnel. Existing customer identities, quotas and recorded usage remain. Existing files are backed up; certificates are neither issued nor deleted.")
        print("You must update DNS/CDN origin routing and match the dedicated foreign Xray inbound to this entry transport/path. Redistribute fresh customer exports after applying the signed peer code.")
        print("Standalone nginx uses direct DNS and verified HTTPS. Raw TCP/TLS client configurations are NOT automatically translated into WS/XHTTP; prepare a dedicated matching inbound and distribute updated client configurations.")
        return self.entry_plan(canonical(profile).decode(), certificate, direct_ports=assigned)

    def path_prompt(self):
        profile = json.loads(self.current("path_profile"))
        profile["interval"] = access.prompt("Rotate every duration, or 0 to disable (e.g. 2h)", profile["interval"], lambda v: v if v == "0" else (profiles.duration(v, minimum=60) and v))
        profile["count"] = access.prompt("Backup paths per set (2-8)", profile["count"], lambda v: v if re.fullmatch(r"[2-8]", v) else (_ for _ in ()).throw(ValueError("Use 2-8.")))
        profile["grace"] = access.prompt("Clock-skew/previous-set overlap (e.g. 5m, or 0)", profile["grace"], lambda v: (profiles.duration(v), v)[1])
        profile["legacy"] = access.prompt("Allow old static path during migration only? true/false", profile["legacy"], lambda v: v if v in ("true", "false") else (_ for _ in ()).throw(ValueError("Use true or false.")))
        return self.plan("path_profile", profiles.path_profile(canonical(profile).decode()))

    def edit(self, field, supplied=None, emit=True):
        self.refresh()
        while True:
            try:
                if field == "certificate":
                    self.assert_site_owned()
                    plan = self.certificate_plan(*self.certificate_prompt(self.local_domain()))
                elif field == "entry_profile" and supplied is None:
                    plan = self.entry_prompt()
                elif field == "path_profile" and supplied is None:
                    plan = self.path_prompt()
                else:
                    if supplied is not None:
                        value = supplied
                    elif field == "token":
                        print("A new cryptographically random token will be generated; no current token is displayed.")
                        value = secrets.token_hex(32)
                    elif field == "ech_source":
                        print("The current ECH source is hidden because a resolver URL can contain a private query parameter.")
                        value = access.prompt("New ECH source (empty keeps current)", "", lambda v: validate("ech_source", v) if v else v) or self.current(field)
                    else:
                        value = access.prompt("New " + LABELS[field], self.current(field), lambda v: self.validate_combination(field, validate(field, v)))
                    if value == self.current(field):
                        print("Value unchanged; nothing was modified.")
                        return
                    certificate = None
                    local_domain = (field == "foreign_domain" and self.role == "egress") or (field == "entry_domain" and self.role == "origin")
                    if local_domain:
                        self.assert_site_owned()
                        self.check_domain(tls.validate_domain(value))
                        certificate = self.certificate_prompt(value)
                    plan = self.plan(field, value, certificate, emit)
                before = "[hidden]" if field in ("token", "ech_source") else plan["old"]
                after = "[new private value]" if field in ("token", "ech_source") else plan["value"]
                print(f"\nOnly tunnel {self.id}: {field}\n  Current: {before}\n  New: {after}")
                print("The selected active service may restart; other tunnel services and recorded usage are not changed.")
                if field in ("transport", "mux", "xhttp_path", "foreign_provider", "entry_profile"):
                    print("Both peers must run 3.5 or newer. Apply the signed synchronization code on the paired server immediately; a temporary interruption is expected. Xray and DNS/CDN settings are NOT changed automatically.")
                if field == "xhttp_mode":
                    print("Both peers must run 3.6 or newer for stream-up/stream-one. Apply the signed mode change to the peer; CDN streaming compatibility still needs a real connection test.")
                if field == "path_profile":
                    print("Both peers must run 3.7 and use this identical profile/token/base path. Apply the signed code on the peer; synchronize clocks and forward /gdt-r/ unchanged through the CDN. A temporary interruption during this manual configuration change is possible. Scheduled path sets then synchronize automatically. Disable legacy static paths after migration.")
                if field in ("connect_host", "tls_sni", "http_host"):
                    print("Dial address, TLS SNI and HTTP Host are separate. TLS still verifies the chosen SNI; the CDN must route the chosen Host. Different names are not a guarantee of domain-fronting support.")
                if field == "http_host":
                    print("Apply the signed HTTP Host update on the peer. Update CDN/origin routing separately if required.")
                if field == "ech_mode" and plan["value"] == "strict":
                    print("Strict ECH is provider-neutral but requires a real ECH-enabled TLS terminator and valid ECH configuration. It fails closed when unavailable/rejected; use ununknowntunctl doctor for an actual handshake. Ordinary managed Nginx alone has no ECH keys.")
                if field == "entry_profile" and self.role == "origin":
                    accounts = json.loads(plan["changes"][self.directory / "access.json"])
                    for account in accounts["accounts"]:
                        print("  Customer " + account["id"] + " -> " + account["listen"] + (" (disabled)" if not account["enabled"] else ""))
                confirm = access.prompt("Apply? y/n", "n", lambda v: v if v in ("y", "n") else (_ for _ in ()).throw(ValueError("Choose y or n.")))
                if confirm == "y":
                    self.commit(plan)
                return
            except (ValueError, OSError, RuntimeError, subprocess.CalledProcessError) as error:
                print("Could not apply edit: " + str(error), file=sys.stderr)
                if supplied is not None:
                    raise
                retry = access.prompt("Retry this field? y/n", "y", lambda v: v if v in ("y", "n") else (_ for _ in ()).throw(ValueError("Choose y or n.")))
                if retry == "n":
                    return

    def menu(self, action):
        if action == "show":
            self.show()
            return
        if action == "apply-update":
            field, value = access.prompt("Paste confidential V3 edit code", validate=self.decode_update)
            self.edit(field, value, emit=False)
            return
        if action == "ip":
            field = access.prompt("Which IP? iran_ip/foreign_ip", "foreign_ip", lambda v: v if v in ("iran_ip", "foreign_ip") else (_ for _ in ()).throw(ValueError("Choose iran_ip or foreign_ip.")))
            self.edit(field)
            return
        if action == "ports":
            self.edit("foreign_ports" if self.role == "egress" else "entry_ports")
            return
        fields = ["name", "foreign_ip", "iran_ip", "foreign_provider", "foreign_ports", "foreign_domain", "http_host", "entry_domain", "ws_path", "xhttp_path", "path_profile", "xhttp_mode", "xhttp_padding", "padding_bytes", "entry_path", "target_port", "token", "certificate", "local_ca", "max_streams", "max_memory_mb", "transport", "mux"]
        if self.role == "origin":
            fields += ["entry_profile", "entry_ports", "connect_host", "tls_sni", "sessions_min", "sessions", "session_renewal", "profile", "tls_min", "ca", "ech_mode", "ech_source", "tls_fragment", "fragment_size", "fragment_interval"]
        fields += ["write_timeout", "edge_timeout"]
        if not self.site:
            fields.remove("certificate")
        if self.env.get("IRAN_PROXY_PROVIDER", "none") == "none":
            fields = [field for field in fields if field not in ("entry_domain", "entry_path")]
        while True:
            self.refresh()
            self.show()
            print("\nSelect setting to edit (customer quotas/ports remain in ununknowntunctl customers):")
            for index, field in enumerate(fields, 1):
                print(f"{index}) {LABELS[field]}")
            print("0) Exit")
            choice = access.prompt("Option", "0", lambda v: int(v) if v.isdigit() and 0 <= int(v) <= len(fields) else (_ for _ in ()).throw(ValueError("Choose a listed number.")))
            if not choice:
                return
            self.edit(fields[choice - 1])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("menu", "show", "apply-update", "ip", "ports"))
    parser.add_argument("--config-dir", required=True)
    parser.add_argument("--state-dir", required=True)
    args = parser.parse_args()
    if os.geteuid() != 0:
        parser.error("Run tunnel editing as root.")
    directory, state = Path(args.config_dir), Path(args.state_dir)
    if directory.parent != Path("/etc/ununknowntun/tunnels") or directory.is_symlink() or state != Path("/var/lib/ununknowntun") / directory.name or state.is_symlink():
        parser.error("Only an installed tunnel's own configuration and state paths may be selected.")
    def interrupted(signum, frame):
        raise KeyboardInterrupt()
    signal.signal(signal.SIGTERM, interrupted)
    with open("/run/ununknowntun-installer.lock", "a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            parser.error("Another tunnel edit is running. Retry after it finishes.")
        Editor(directory, state).menu(args.action)


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, RuntimeError, subprocess.CalledProcessError, KeyboardInterrupt) as error:
        print("Tunnel editor stopped: " + str(error), file=sys.stderr)
        sys.exit(1)
