#!/usr/bin/env python3
"""Local, non-installing preview validation. Records fresh results separately."""
import argparse
import datetime
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("output")
parser.add_argument("--realtime-health", action="store_true", help="Also exercise production watchdog timers on WSS and XHTTP (about 80 seconds)")
args = parser.parse_args()
out = Path(args.output).resolve()
out.mkdir(parents=True, exist_ok=False)
jobs = [
    ("go-test", ["go", "test", "-count=1", "-timeout=180s", "./..."], 210),
    ("go-race", ["go", "test", "-race", "-count=1", "-timeout=240s", "./..."], 270),
    ("go-vet", ["go", "vet", "./..."], 180),
    ("go-resilience", ["go", "test", "-race", "-v", "-count=1", "-timeout=120s", "-run", "TestRotating|TestCarrierRenewal|TestRenewal|TestCarrierHealth|TestRecovery|TestSignedRecovery", "."], 150),
    ("installer-syntax", ["bash", "-n", "packaging/full-installer.template.sh"], 10),
]
jobs += [(path.stem, [sys.executable, "-B", str(path)], 180) for path in sorted((root / "packaging").glob("test-*.py"))]
jobs += [("terminal-ui", [sys.executable, "-B", "ui/run-tests.py"], 180)]
jobs += [("test-gre-wire", [sys.executable, "-B", "tests/test-gre-wire-check.py"], 30)]
jobs += [("test-gre-systemd", [sys.executable, "-I", "tests/spoof-systemd-lab.py", "--self-test"], 30)]
jobs += [("test-icmp-wire", [sys.executable, "-I", "tests/icmp-netns-lab.py", "--self-test"], 30)]
jobs += [("test-icmp-wss", [sys.executable, "-I", "tests/icmp-wss-lab.py", "--self-test"], 30)]
jobs += [("test-direct-icmp-systemd", [sys.executable, "-I", "tests/direct-icmp-systemd-lab.py", "--self-test"], 30)]
jobs += [("test-direct-icmp-systemd-pools", [sys.executable, "-I", "tests/direct-icmp-systemd-pools-lab.py", "--self-test"], 30)]
jobs += [("test-direct-icmp-forward-lab", [sys.executable, "-I", "tests/direct-icmp-forward-lab.py", "--self-test"], 30)]
jobs += [("test-direct-icmp-console-lab", [sys.executable, "-I", "tests/direct-icmp-console-lab.py", "--self-test"], 30)]
if args.realtime_health:
    jobs += [("realtime-health", ["env", "UNUNKNOWNTUN_REALTIME_HEALTH_TEST=1", "go", "test", "-v", "-count=1", "-timeout=125s", "-run", "^TestCarrierHealthRealtimeTransportRecovery$", "."], 150)]
results = []
for name, command, limit in jobs:
    print("Testing " + name, flush=True)
    try:
        completed = subprocess.run(command, cwd=root, env=os.environ.copy(), capture_output=True, text=True, timeout=limit)
        text = completed.stdout + completed.stderr
        code = completed.returncode
    except subprocess.TimeoutExpired:
        text, code = "TIMEOUT: no passing result claimed.\n", 124
    (out / (name + ".log")).write_text(text)
    results.append({"name": name, "exit_code": code, "status": "PASS" if code == 0 else "FAIL"})
    print(name + ": " + results[-1]["status"], flush=True)
summary = {"version": (root / "VERSION").read_text().strip(), "time_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "platform": sys.platform, "results": results,
           "scope": "Local core tests (including loopback TLS), fake-service Python tests and terminal UI. No CDN/provider/server modifications or real Internet path certification."}
(out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
sys.exit(any(item["exit_code"] != 0 for item in results))
