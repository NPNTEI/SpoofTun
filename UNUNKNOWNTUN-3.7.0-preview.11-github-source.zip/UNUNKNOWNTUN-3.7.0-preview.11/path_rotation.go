package main

// Routes are derived locally by both peers. No control packet or working old
// tunnel is needed to learn the next routes. This is availability tooling, not
// evidence that an ISP can read HTTP paths inside TLS or a bypass guarantee.
import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"net"
	"net/http"
	"strings"
	"time"
)

const rotatingPathPrefix = "/gdt-r/"

// A successful HTTP download alone is not a healthy split XHTTP carrier:
// uploads must also carry the UNUNKNOWNTUN authentication round trip. Try another
// route when this fails; never change the certificate verifier or token.
func (t *originTransport) dialAuthenticatedContext(parent context.Context, endpoint string, cfg *Config) (*Session, string, error) {
	label := transportLabel(cfg.Transport, cfg.ECHMode == ECHModeStrict)
	return t.dialAuthenticatedEndpointCandidates(parent, endpoint, label, func(ctx context.Context, path string) (*Session, error) {
		conn, err := t.dialPathWithECH(ctx, endpoint, cfg.Transport, path)
		if err != nil {
			return nil, err
		}
		session, err := authenticateOriginSessionContext(ctx, conn, cfg, endpoint, label, authTimeout)
		if err != nil {
			_ = conn.Close()
		}
		return session, err
	})
}

// The attempt function keeps the selection state independently testable while
// production always requires a completed transport and tunnel authentication.
func (t *originTransport) dialAuthenticatedCandidates(parent context.Context, label string, attempt func(context.Context, string) (*Session, error)) (*Session, string, error) {
	return t.dialAuthenticatedEndpointCandidates(parent, "", label, attempt)
}

func (t *originTransport) dialAuthenticatedEndpointCandidates(parent context.Context, endpoint, label string, attempt func(context.Context, string) (*Session, error)) (*Session, string, error) {
	if err := parent.Err(); err != nil {
		return nil, "", err
	}
	ctx, cancel := context.WithTimeout(parent, 45*time.Second)
	defer cancel()
	candidates, generation := t.recoveryCandidates(time.Now(), endpoint)
	attempted := make(map[string]bool, len(candidates)+1)
	var failures []error
	try := func(candidate routeCandidate) *Session {
		// Another slot's health callback may reject a route after this round
		// captured its candidate list. Recheck before opening a new connection.
		if t.routeQuarantined(candidate.path, time.Now(), endpoint) {
			return nil
		}
		attempted[candidate.path] = true
		session, err := attempt(ctx, candidate.path)
		if err == nil && session != nil && !session.Closed() && session.authenticated.Load() && ctx.Err() == nil {
			t.publishRoute(session, candidate)
			return session
		}
		if session != nil {
			session.Close()
		}
		if err == nil {
			err = errors.New("candidate did not complete authenticated carrier readiness")
		}
		// A caller's cancelled operation is not evidence against this route.
		// Internal transport/round deadlines still quarantine failed candidates.
		if parent.Err() == nil && routeAttemptReachedHTTP(err) {
			t.recordRouteFailure(candidate, generation, time.Now())
		}
		failures = append(failures, err)
		return nil
	}
	for _, candidate := range candidates {
		if ctx.Err() != nil {
			break
		}
		if session := try(candidate); session != nil {
			return session, label, nil
		}
	}
	// If a fixed set is exhausted (including its round deadline), reserve one
	// fresh signed route. A timed-out round leaves it ready for the next retry;
	// a quick 404 round can use it immediately. At most one is added per round.
	var recovery routeCandidate
	if parent.Err() == nil {
		recovery = t.requestRecovery(time.Now(), true, generation, endpoint)
	}
	if recovery.path != "" && !attempted[recovery.path] && ctx.Err() == nil {
		if session := try(recovery); session != nil {
			return session, label, nil
		}
	}
	if ctx.Err() != nil {
		failures = append(failures, ctx.Err())
	}
	if len(failures) == 0 {
		failures = append(failures, errors.New("all candidate routes are temporarily quarantined"))
	}
	return nil, "", errors.Join(failures...)
}

func (t *originTransport) orderedPathIndex(n int, preference uint32, candidates int) int {
	if candidates <= 1 {
		return 0
	}
	return (int(preference)%candidates + n) % candidates
}

// Keep progress even if the whole-round deadline expires. Otherwise a few
// blackholed routes consume every retry's budget and permanently starve a
// working later candidate (including overlap and migration-only legacy).
func (t *originTransport) advancePathChoice(index, candidates int) {
	if candidates > 0 {
		t.pathChoice.Store(uint32((index + 1) % candidates))
	}
}

func (t *originTransport) dialPathWithECH(ctx context.Context, endpoint, kind, path string) (net.Conn, error) {
	attempt, stop := context.WithTimeout(ctx, authTimeout)
	defer stop()
	conn, err := t.dialWithPathContext(attempt, endpoint, kind, path)
	if err != nil && t.cfg.ECHMode == ECHModeStrict && isECHFailure(err) && attempt.Err() == nil {
		if refreshErr := t.refreshECHContext(attempt); refreshErr == nil {
			conn, err = t.dialWithPathContext(attempt, endpoint, kind, path)
		} else {
			return nil, errors.Join(err, refreshErr)
		}
	}
	return conn, err
}

func validateRotationConfig(c *Config) error {
	if c.Mode == "origin" && effectiveSessionRenewal(c) > 0 && c.Sessions >= MaxSessions && effectiveMuxMode(c.MuxMode) != "off" {
		return fmt.Errorf("[session/config] renewal needs one spare carrier: -sessions must be below %d", MaxSessions)
	}
	if c.SessionRenewal < 0 || (c.SessionRenewal > 0 && c.SessionRenewal < time.Minute) || c.SessionRenewal > 168*time.Hour {
		return fmt.Errorf("[session/config] -session-renewal must be 0 or 1m..168h")
	}
	if c.PathRotation == 0 {
		if c.PathLegacy {
			return fmt.Errorf("[path/config] -path-legacy requires -path-rotation")
		}
		return nil
	}
	if c.Transport != TransportWSS && c.Transport != TransportXHTTP {
		return fmt.Errorf("[path/config] rotation requires WSS or XHTTP, not raw TLS/GRE")
	}
	if c.PathRotation < time.Minute || c.PathRotation > 168*time.Hour {
		return fmt.Errorf("[path/config] -path-rotation must be 0 or 1m..168h")
	}
	if c.PathCount < 2 || c.PathCount > 8 {
		return fmt.Errorf("[path/config] -path-count must be 2..8")
	}
	if c.PathGrace < 0 || c.PathGrace > c.PathRotation {
		return fmt.Errorf("[path/config] -path-grace must be between 0 and the rotation interval")
	}
	if len(c.Token) < 16 || len(c.Token) > MaxTokenSize {
		return fmt.Errorf("[path/config] rotation requires the shared tunnel token")
	}
	if err := validateXHTTPPath(configuredTransportPath(c)); err != nil {
		return err
	}
	if strings.HasPrefix(configuredTransportPath(c), rotatingPathPrefix) {
		return fmt.Errorf("[path/config] /gdt-r/ is reserved; use a different static seed path")
	}
	return nil
}

func configuredTransportPath(c *Config) string {
	if c.Transport == TransportXHTTP {
		return c.XHTTPPath
	}
	return c.WSPath
}

func effectiveSessionRenewal(c *Config) time.Duration {
	interval := c.SessionRenewal
	if c.PathRotation > 0 && (interval == 0 || c.PathRotation < interval) {
		interval = c.PathRotation
	}
	return interval
}

func rotatingPath(c *Config, epoch int64, index int) string {
	h := hmac.New(sha256.New, []byte(c.Token))
	// Domain separation and length delimiters prevent transport/host/path reuse.
	for _, part := range []string{"ununknowntun-path-v1", c.Transport, canonicalHost(c.WSHost), configuredTransportPath(c)} {
		fmt.Fprintf(h, "%d:%s;", len(part), part)
	}
	fmt.Fprintf(h, "%d:%d:%d", int64(c.PathRotation), epoch, index)
	return rotatingPathPrefix + hex.EncodeToString(h.Sum(nil)[:16])
}

// Current paths first; adjacent epochs only during the configured overlap.
// UTC Unix time is independent of timezone. Clocks must be synchronized; grace
// is clock-skew tolerance, not a reason to accept arbitrarily old routes.
func transportPaths(c *Config, now time.Time) []string {
	if c.PathRotation == 0 {
		return []string{configuredTransportPath(c)}
	}
	epochs := acceptedPathEpochs(c, now)
	paths := make([]string, 0, len(epochs)*c.PathCount+1)
	for _, e := range epochs {
		for i := 0; i < c.PathCount; i++ {
			paths = append(paths, rotatingPath(c, e, i))
		}
	}
	if c.PathLegacy {
		paths = append(paths, configuredTransportPath(c))
	}
	return paths
}

func acceptsTransportPath(c *Config, path string, now time.Time) bool {
	if _, ok := recoveryPathEpoch(c, path, now); ok {
		return true
	}
	for _, allowed := range transportPaths(c, now) {
		if hmac.Equal([]byte(path), []byte(allowed)) {
			return true
		}
	}
	return false
}

// Extract a route without allocating a map for every possible epoch. Expired
// paths may only continue POSTs of an existing, path-bound authenticated
// XHTTP session. They can never open a new carrier.
func xhttpRequestBase(c *Config, path string) string {
	static := strings.TrimSuffix(c.XHTTPPath, "/") + "/"
	if (c.PathRotation == 0 || c.PathLegacy) && strings.HasPrefix(path, static) {
		return static
	}
	if c.PathRotation > 0 && strings.HasPrefix(path, rotatingPathPrefix) {
		rest := strings.TrimPrefix(path, rotatingPathPrefix)
		for _, size := range []int{32, 64} {
			if len(rest) > size && rest[size] == '/' {
				if raw, err := hex.DecodeString(rest[:size]); err == nil && len(raw) == size/2 && strings.ToLower(rest[:size]) == rest[:size] {
					return rotatingPathPrefix + rest[:size] + "/"
				}
			}
		}
	}
	return ""
}

func (s *xhttpServer) acceptsRequestBase(r *http.Request, base string) bool {
	if base == "" {
		return false
	}
	if s.cfg.PathRotation == 0 {
		return true
	}
	// Every split upload must remain bound to the route that opened it, even
	// if another candidate route is also valid in the current epoch.
	rest := strings.TrimPrefix(r.URL.Path, base)
	if r.Method == http.MethodPost && rest != "" {
		id := strings.SplitN(rest, "/", 2)[0]
		if !validXHTTPID(id) {
			return false
		}
		s.mu.Lock()
		defer s.mu.Unlock()
		session := s.sessions[id]
		return session != nil && session.routeBase == base
	}
	path := strings.TrimSuffix(base, "/")
	if acceptsTransportPath(s.cfg, path, time.Now()) || (s.cfg.PathLegacy && base == strings.TrimSuffix(s.cfg.XHTTPPath, "/")+"/") {
		return true
	}
	return false
}
