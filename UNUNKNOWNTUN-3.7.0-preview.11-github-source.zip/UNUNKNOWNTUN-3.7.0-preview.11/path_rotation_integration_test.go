package main

import (
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/tls"
	"encoding/hex"
	"io"
	"net"
	"net/http"
	"path/filepath"
	"reflect"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"golang.org/x/net/http2"
)

func TestRotatingPathOrderVisitsOverlapAndLegacyOnce(t *testing.T) {
	for _, legacy := range []bool{false, true} {
		cfg := rotationTestConfig()
		cfg.PathGrace = cfg.PathRotation // Both adjacent epochs are in scope.
		cfg.PathLegacy = legacy
		paths := transportPaths(cfg, time.Unix(1800000000, 0))
		wantCount := 3 * cfg.PathCount
		if legacy {
			wantCount++
		}
		if len(paths) != wantCount {
			t.Fatalf("legacy=%t route count=%d want=%d", legacy, len(paths), wantCount)
		}
		transport := &originTransport{cfg: cfg}
		for _, preference := range []uint32{0, 1, 2, 10, ^uint32(0)} {
			seen := make(map[int]bool)
			var order []int
			for n := range paths {
				// A concurrent dial may publish a new preference. This round must
				// nevertheless visit its captured order once, with no skips.
				transport.pathChoice.Store(uint32(n + 1))
				index := transport.orderedPathIndex(n, preference, len(paths))
				if index < 0 || index >= len(paths) || seen[index] {
					t.Fatalf("invalid/repeated index=%d preference=%d paths=%d", index, preference, len(paths))
				}
				seen[index] = true
				order = append(order, index)
			}
			want := make([]int, len(paths))
			for n := range want {
				want[n] = (int(preference)%len(paths) + n) % len(paths)
			}
			if !reflect.DeepEqual(order, want) {
				t.Fatalf("order=%v want=%v", order, want)
			}
		}
	}
	cfg := rotationTestConfig()
	cfg.PathRotation = 0
	transport := &originTransport{cfg: cfg}
	if got := transport.orderedPathIndex(0, ^uint32(0), 1); got != 0 {
		t.Fatalf("disabled rotation changed static path index: %d", got)
	}
}

// Real loopback TCP + browser TLS + rotating HTTP route + UNUNKNOWNTUN
// authentication + target payload. The rejection is an intentional local 404,
// not a simulated/public ISP filtering claim.
func TestRotatingPathTLSAuthenticatedPayloadFailover(t *testing.T) {
	for _, profile := range []struct {
		transport, mode string
		postOnly        bool
	}{
		{TransportWSS, "", false}, {TransportXHTTP, "auto", false},
		{TransportXHTTP, "packet-up", false}, {TransportXHTTP, "stream-up", false},
		{TransportXHTTP, "stream-one", false},
		{TransportXHTTP, "auto", true}, {TransportXHTTP, "packet-up", true},
		{TransportXHTTP, "stream-up", true},
	} {
		name := profile.transport + "/" + profile.mode
		if profile.postOnly {
			name += "/upload-blocked-after-download-open"
		}
		t.Run(name, func(t *testing.T) {
			const host = "rotation-loopback.example.com"
			target := managedTestListener(t, func(c net.Conn) { _, _ = io.Copy(c, c); _ = c.(*net.TCPConn).CloseWrite() })
			allow, err := ParseAllowList(target.Addr().String())
			if err != nil {
				t.Fatal(err)
			}
			dir := t.TempDir()
			cert, err := loadOrCreateCert(filepath.Join(dir, "test.crt"), filepath.Join(dir, "test.key"), host, false)
			if err != nil {
				t.Fatal(err)
			}
			sum := sha256.Sum256(cert.Certificate[0])
			cfg := &Config{Mode: "origin", Transport: profile.transport, XHTTPMode: profile.mode,
				Token: "rotation-local-test-shared-secret", WSHost: host, SNI: host,
				WSPath: "/shared-static-seed", XHTTPPath: "/shared-xhttp-seed",
				UTLSProfile: "chrome", ECHMode: ECHModeOff, Fingerprint: hex.EncodeToString(sum[:]),
				PathRotation: time.Hour, PathCount: 3, PathGrace: 5 * time.Minute, allowList: allow}
			if err := validateRotationConfig(cfg); err != nil {
				t.Fatal(err)
			}
			var rejected, accepted atomic.Int64
			blocked := func(path, method string) bool {
				epoch := time.Now().UnixNano() / int64(cfg.PathRotation)
				primary := rotatingPath(cfg, epoch, 0)
				if (!profile.postOnly || method == http.MethodPost) && (path == primary || strings.HasPrefix(path, primary+"/")) {
					rejected.Add(1)
					return true
				}
				accepted.Add(1)
				return false
			}
			limiter := NewAdaptiveRateLimiter(20, 10)
			xhttp := newXHTTPServer(cfg, func(c net.Conn, ip string) { dispatchEgressConn(c, ip, cfg, limiter) })
			t.Cleanup(xhttp.Close)
			handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				if blocked(r.URL.Path, r.Method) {
					http.NotFound(w, r)
					return
				}
				xhttp.ServeHTTP(w, r)
			})
			server := managedTestListener(t, func(raw net.Conn) {
				alpn := "http/1.1"
				if profile.transport == TransportXHTTP {
					alpn = "h2"
				}
				_ = raw.SetDeadline(time.Now().Add(5 * time.Second))
				conn := tls.Server(raw, &tls.Config{Certificates: []tls.Certificate{cert}, MinVersion: tls.VersionTLS13, NextProtos: []string{alpn}})
				if err := conn.Handshake(); err != nil {
					return
				}
				_ = raw.SetDeadline(time.Time{})
				if profile.transport == TransportXHTTP {
					(&http2.Server{}).ServeConn(conn, &http2.ServeConnOpts{Handler: handler})
					return
				}
				ws, ip, err := acceptServerWebSocketPaths(conn, host, cfg.Token, func(path string) bool {
					return !blocked(path, http.MethodGet) && acceptsTransportPath(cfg, path, time.Now())
				})
				if err == nil {
					dispatchEgressConn(ws, ip, cfg, limiter)
				}
			})
			transport, err := newOriginTransport(cfg)
			if err != nil {
				t.Fatal(err)
			}
			ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
			defer cancel()
			for round := 0; round < 2; round++ {
				beforeRejected := rejected.Load()
				session, _, err := transport.dialAuthenticatedContext(ctx, server.Addr().String(), cfg)
				if err != nil {
					t.Fatalf("round %d authentication: %v", round, err)
				}
				t.Cleanup(session.Close)
				client, edge := tcpTestPair(t)
				_ = edge.SetDeadline(time.Time{})
				if err := session.OpenStream(target.Addr().String(), edge); err != nil {
					t.Fatal(err)
				}
				payload := bytes.Repeat([]byte("rotating-route-authenticated-payload"), 4096)
				written := make(chan error, 1)
				go func() { _, err := writeFull(client, payload); written <- err }()
				reply := make([]byte, len(payload))
				if _, err := io.ReadFull(client, reply); err != nil {
					t.Fatal(err)
				}
				if err := <-written; err != nil {
					t.Fatal(err)
				}
				if !bytes.Equal(payload, reply) {
					t.Fatal("payload corrupted after path failover")
				}
				_ = client.Close()
				session.Close()
				if round == 0 && rejected.Load() == 0 {
					t.Fatal("test never exercised the blocked primary path")
				}
				if round == 1 && rejected.Load() != beforeRejected {
					t.Fatal("second carrier did not remember a working backup path")
				}
			}
			if accepted.Load() == 0 {
				t.Fatal("no alternate route was requested")
			}
		})
	}
}
