package main

import (
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/tls"
	"encoding/hex"
	"errors"
	"io"
	"math/rand"
	"net"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func assertRotationSchedule(t testing.TB, seed uint64, seconds uint32, count uint8, fraction uint16) {
	t.Helper()
	c := rotationTestConfig()
	c.PathRotation = time.Duration(60+uint64(seconds)%(7*24*3600-59)) * time.Second
	c.PathCount = 2 + int(count%7)
	c.PathGrace = time.Duration(uint64(fraction) * uint64(c.PathRotation) / 65535)
	// Keep the wall clock in the supported UnixNano range; real timezone offsets
	// must not affect either peer's epoch calculation.
	now := time.Unix(1700000000+int64(seed%1000000000), int64(seed%1000000000))
	phase := time.Duration(now.UnixNano() % int64(c.PathRotation))
	pathSet := func(at time.Time) map[string]bool {
		set := make(map[string]bool)
		for _, p := range transportPaths(c, at) {
			set[p] = true
		}
		return set
	}
	for _, at := range []time.Time{now, now.Add(-phase), now.Add(-phase).Add(c.PathRotation - time.Nanosecond)} {
		paths := transportPaths(c, at)
		if len(paths) < c.PathCount || len(paths) > 3*c.PathCount {
			t.Fatalf("unbounded schedule: %d paths", len(paths))
		}
		seen := make(map[string]bool, len(paths))
		otherZone, expired := pathSet(at.In(time.FixedZone("other-peer", -11*3600))), pathSet(at.Add(4*c.PathRotation))
		for _, p := range paths {
			if seen[p] || !otherZone[p] {
				t.Fatalf("duplicate or timezone-dependent path %q", p)
			}
			seen[p] = true
			if expired[p] {
				t.Fatal("expired route admits a new carrier")
			}
		}
		if c.PathGrace > 0 {
			// Current routes remain usable if relative clock error is strictly
			// smaller than grace, including either side of an epoch boundary.
			skew := time.Duration(seed % uint64(c.PathGrace))
			for _, delta := range []time.Duration{-skew, skew} {
				skewed := pathSet(at.Add(delta))
				for _, p := range paths[:c.PathCount] {
					if !skewed[p] {
						t.Fatalf("clock skew inside grace rejected route: period=%v grace=%v skew=%v phase=%v", c.PathRotation, c.PathGrace, delta, at.UnixNano()%int64(c.PathRotation))
					}
				}
			}
		}
	}
}

func TestRotationRandomizedClockBoundaries(t *testing.T) {
	r := rand.New(rand.NewSource(3700))
	for i := 0; i < 2000; i++ {
		assertRotationSchedule(t, r.Uint64(), r.Uint32(), uint8(r.Uint32()), uint16(r.Uint32()))
	}
}

func FuzzRotationSchedule(f *testing.F) {
	f.Add(uint64(0), uint32(60), uint8(0), uint16(0))
	f.Add(uint64(1800000000), uint32(7200), uint8(6), uint16(65535))
	f.Add(^uint64(0), ^uint32(0), uint8(255), uint16(32768))
	f.Fuzz(func(t *testing.T, seed uint64, seconds uint32, count uint8, fraction uint16) {
		assertRotationSchedule(t, seed, seconds, count, fraction)
	})
}

// Exercise the actual HTTP handler, upload sequence queue and application pipe:
// expired leases may deliver existing payload but may not create/cross carriers.
func TestRotatingXHTTPExpiredLeaseDeliversPayload(t *testing.T) {
	c := rotationTestConfig()
	c.Transport, c.XHTTPMode = TransportXHTTP, "packet-up"
	const id = "00112233-4455-4677-8899-aabbccddeeff"
	epoch := time.Now().UnixNano()/int64(c.PathRotation) - 4
	base := rotatingPath(c, epoch, 0) + "/"
	app, wire := net.Pipe()
	session := &xhttpServerSession{routeBase: base, app: app, wire: wire, mode: "packet-up",
		pending: make(map[uint64]*xhttpPendingUpload), changed: make(chan struct{}, 1), closed: make(chan struct{}), gapTimeout: time.Second}
	server := newXHTTPServer(c, func(net.Conn, string) { t.Error("expired route opened a new carrier") })
	server.sessions[id] = session
	t.Cleanup(server.Close)
	loopDone := make(chan struct{})
	go func() { defer close(loopDone); session.uploadLoop() }()
	t.Cleanup(func() { session.close(); awaitDone(t, loopDone) })
	payload := bytes.Repeat([]byte("leased-upload-after-epoch-expiry/"), 128)
	received := make(chan error, 1)
	go func() {
		_ = app.SetReadDeadline(time.Now().Add(2 * time.Second))
		got := make([]byte, len(payload))
		_, err := io.ReadFull(app, got)
		if err == nil && !bytes.Equal(got, payload) {
			err = errors.New("lease upload bytes changed")
		}
		received <- err
	}()
	request := func(method, path string, body []byte) *httptest.ResponseRecorder {
		r := httptest.NewRequest(method, "https://"+c.WSHost+path, bytes.NewReader(body))
		auth, err := makeWebSocketAuthorization(c.Token, c.WSHost, path, time.Now())
		if err != nil {
			t.Fatal(err)
		}
		r.Header.Set("Authorization", auth)
		w := httptest.NewRecorder()
		server.ServeHTTP(w, r)
		return w
	}
	if w := request(http.MethodPost, base+id+"/0", payload); w.Code != http.StatusOK {
		t.Fatalf("leased POST: %d %s", w.Code, w.Body.String())
	}
	if err := <-received; err != nil {
		t.Fatal(err)
	}
	for _, path := range []string{base + id, base + "10112233-4455-4677-8899-aabbccddeeff"} {
		if w := request(http.MethodGet, path, nil); w.Code != http.StatusNotFound {
			t.Fatalf("expired GET: %d", w.Code)
		}
	}
	current := transportPaths(c, time.Now())[0] + "/"
	if w := request(http.MethodPost, current+id+"/1", []byte("cross-route")); w.Code != http.StatusNotFound {
		t.Fatalf("cross-route upload: %d", w.Code)
	}
	server.mu.Lock()
	delete(server.sessions, id)
	server.mu.Unlock()
	if w := request(http.MethodPost, base+id+"/1", []byte("after-close")); w.Code != http.StatusNotFound {
		t.Fatalf("closed lease reused: %d", w.Code)
	}
}

func TestRotatingDialCancellationReleasesConnections(t *testing.T) {
	var inflight atomic.Int64
	var accepted atomic.Int64
	server := managedTestListener(t, func(c net.Conn) {
		inflight.Add(1)
		accepted.Add(1)
		defer inflight.Add(-1)
		_, _ = io.Copy(io.Discard, c) // Stall during TLS, until caller closes.
	})
	c := rotationTestConfig()
	c.SNI, c.Fingerprint, c.UTLSProfile = c.WSHost, strings.Repeat("a", 64), "chrome"
	transport, err := newOriginTransport(c)
	if err != nil {
		t.Fatal(err)
	}
	for i := 0; i < 12; i++ {
		ctx, cancel := context.WithTimeout(context.Background(), 40*time.Millisecond)
		started := time.Now()
		session, _, err := transport.dialAuthenticatedContext(ctx, server.Addr().String(), c)
		cancel()
		if session != nil {
			session.Close()
			t.Fatal("stalled server authenticated")
		}
		if !errors.Is(err, context.DeadlineExceeded) || time.Since(started) > time.Second {
			t.Fatalf("cancellation was not bounded: %v", err)
		}
	}
	deadline := time.Now().Add(time.Second)
	for inflight.Load() != 0 && time.Now().Before(deadline) {
		time.Sleep(time.Millisecond)
	}
	if inflight.Load() != 0 || accepted.Load() != 12 {
		t.Fatalf("connections leaked/missing: accepted=%d inflight=%d", accepted.Load(), inflight.Load())
	}
	before := accepted.Load()
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	_, _, err = transport.dialAuthenticatedContext(ctx, server.Addr().String(), c)
	if !errors.Is(err, context.Canceled) || accepted.Load() != before {
		t.Fatalf("pre-cancelled dial made a connection: %v", err)
	}
}

func TestRotatingAuthenticationCancellationAfterUpgrade(t *testing.T) {
	c := rotationTestConfig()
	c.SNI, c.UTLSProfile = c.WSHost, "chrome"
	dir := t.TempDir()
	cert, err := loadOrCreateCert(filepath.Join(dir, "local.crt"), filepath.Join(dir, "local.key"), c.WSHost, false)
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(cert.Certificate[0])
	c.Fingerprint = hex.EncodeToString(sum[:])
	upgraded, released := make(chan struct{}, 1), make(chan struct{}, 1)
	server := managedTestListener(t, func(raw net.Conn) {
		conn := tls.Server(raw, &tls.Config{Certificates: []tls.Certificate{cert}, MinVersion: tls.VersionTLS13, NextProtos: []string{"http/1.1"}})
		_ = conn.SetDeadline(time.Now().Add(2 * time.Second))
		if conn.Handshake() != nil {
			return
		}
		ws, _, err := acceptServerWebSocketPaths(conn, c.WSHost, c.Token, func(path string) bool { return acceptsTransportPath(c, path, time.Now()) })
		if err != nil {
			return
		}
		upgraded <- struct{}{}
		_, _ = io.Copy(io.Discard, ws) // Do not send UNUNKNOWNTUN authentication reply.
		released <- struct{}{}
	})
	transport, err := newOriginTransport(c)
	if err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	result := make(chan error, 1)
	go func() {
		s, _, err := transport.dialAuthenticatedContext(ctx, server.Addr().String(), c)
		if s != nil {
			s.Close()
			err = errors.New("unresponsive authentication succeeded")
		}
		result <- err
	}()
	select {
	case <-upgraded:
	case <-time.After(2 * time.Second):
		t.Fatal("HTTP upgrade failed")
	}
	cancel()
	select {
	case err := <-result:
		if !errors.Is(err, context.Canceled) {
			t.Fatalf("authentication cancellation missing: %v", err)
		}
	case <-time.After(time.Second):
		t.Fatal("authentication ignored cancellation")
	}
	select {
	case <-released:
	case <-time.After(time.Second):
		t.Fatal("post-upgrade carrier leaked after cancellation")
	}
}
