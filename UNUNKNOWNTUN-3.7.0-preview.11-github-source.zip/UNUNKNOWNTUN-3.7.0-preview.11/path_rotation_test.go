package main

import (
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func rotationTestConfig() *Config {
	return &Config{Mode: "origin", Transport: TransportWSS, Token: "rotation-test-secret-0123456789", WSHost: "rotation.example", WSPath: "/private-seed", XHTTPPath: "/private-seed", PathRotation: 2 * time.Hour, PathCount: 3, PathGrace: 5 * time.Minute, Sessions: 8}
}

func TestRotatingPathsSharedScheduleAndOverlap(t *testing.T) {
	c := rotationTestConfig()
	boundary := time.Unix(1800000000, 0).Truncate(c.PathRotation)
	middle := boundary.Add(c.PathRotation / 2)
	paths := transportPaths(c, middle)
	if len(paths) != 3 {
		t.Fatalf("paths=%v", paths)
	}
	other := *c
	other.Mode = "egress"
	if strings.Join(paths, ",") != strings.Join(transportPaths(&other, middle.In(time.FixedZone("Tehran", 12600))), ",") {
		t.Fatal("peers/timezones disagree")
	}
	for _, p := range paths {
		if !acceptsTransportPath(c, p, middle) || acceptsTransportPath(c, p, middle.Add(c.PathRotation)) {
			t.Fatal("epoch isolation")
		}
		if !strings.HasPrefix(p, rotatingPathPrefix) || len(p) != len(rotatingPathPrefix)+32 {
			t.Fatal("unsafe route shape")
		}
		if strings.Contains(p, c.Token) || strings.Contains(p, c.WSPath) {
			t.Fatal("route leaked seed")
		}
	}
	seen := map[string]bool{}
	for _, p := range paths {
		if seen[p] {
			t.Fatal("duplicate candidate")
		}
		seen[p] = true
	}
	old := transportPaths(c, boundary.Add(-c.PathRotation/2))[0]
	if !acceptsTransportPath(c, old, boundary.Add(c.PathGrace-time.Second)) || acceptsTransportPath(c, old, boundary.Add(c.PathGrace)) {
		t.Fatal("previous grace boundary")
	}
	new := transportPaths(c, boundary.Add(c.PathRotation/2))[0]
	if !acceptsTransportPath(c, new, boundary.Add(-c.PathGrace)) || acceptsTransportPath(c, new, boundary.Add(-c.PathGrace-time.Second)) {
		t.Fatal("next grace boundary")
	}
	if len(transportPaths(c, boundary)) > 3*c.PathCount+1 {
		t.Fatal("unbounded route set")
	}
	for _, mutate := range []func(*Config){func(v *Config) { v.Token += "x" }, func(v *Config) { v.WSPath += "x" }, func(v *Config) { v.WSHost = "other.example" }, func(v *Config) { v.PathRotation = time.Hour }, func(v *Config) { v.Transport = TransportXHTTP }} {
		v := *c
		mutate(&v)
		if acceptsTransportPath(&v, paths[0], middle) {
			t.Fatal("seed/domain separation failure")
		}
	}
}

func TestRotatingPathsOptInAndValidation(t *testing.T) {
	c := rotationTestConfig()
	if err := validateRotationConfig(c); err != nil {
		t.Fatal(err)
	}
	if acceptsTransportPath(c, c.WSPath, time.Now()) {
		t.Fatal("legacy admitted implicitly")
	}
	c.PathLegacy = true
	if !acceptsTransportPath(c, c.WSPath, time.Now()) {
		t.Fatal("migration legacy missing")
	}
	c.PathLegacy = false
	c.PathRotation = 0
	if paths := transportPaths(c, time.Now()); len(paths) != 1 || paths[0] != c.WSPath {
		t.Fatal("old config changed")
	}
	for _, mutate := range []func(*Config){
		func(v *Config) { v.PathRotation = -1 }, func(v *Config) { v.PathRotation = time.Second },
		func(v *Config) { v.PathCount = 1 }, func(v *Config) { v.PathCount = 9 },
		func(v *Config) { v.PathGrace = -1 }, func(v *Config) { v.PathGrace = 3 * time.Hour },
		func(v *Config) { v.Transport = TransportTLS }, func(v *Config) { v.Token = "short" },
		func(v *Config) { v.SessionRenewal = time.Second }, func(v *Config) { v.SessionRenewal = 169 * time.Hour },
		func(v *Config) { v.Sessions = MaxSessions }, func(v *Config) { v.WSPath = "/bad?query" },
	} {
		v := rotationTestConfig()
		mutate(v)
		if validateRotationConfig(v) == nil {
			t.Fatalf("accepted invalid %+v", v)
		}
	}
	c = rotationTestConfig()
	c.SessionRenewal = time.Hour
	if effectiveSessionRenewal(c) != time.Hour {
		t.Fatal("renewal should use shorter explicit interval")
	}
	c.SessionRenewal = 0
	if effectiveSessionRenewal(c) != c.PathRotation {
		t.Fatal("path rotation must renew carriers")
	}
}

func TestRotatingXHTTPLeaseCannotOpenOldOrCrossPath(t *testing.T) {
	c := rotationTestConfig()
	c.Transport = TransportXHTTP
	s := newXHTTPServer(c, func(net.Conn, string) { t.Fatal("unexpected carrier") })
	now := time.Now()
	old := rotatingPath(c, now.UnixNano()/int64(c.PathRotation)-3, 0) + "/"
	id := "01234567-89ab-4cde-8abc-0123456789ab"
	s.sessions[id] = &xhttpServerSession{routeBase: old}
	req := func(method, path string) *http.Request {
		return httptest.NewRequest(method, "https://"+c.WSHost+path, nil)
	}
	if !s.acceptsRequestBase(req(http.MethodPost, old+id+"/0"), old) {
		t.Fatal("existing expired upload lost lease")
	}
	if s.acceptsRequestBase(req(http.MethodGet, old+id), old) {
		t.Fatal("expired path opened carrier")
	}
	if s.acceptsRequestBase(req(http.MethodPost, old+"11234567-89ab-4cde-8abc-0123456789ab/0"), old) {
		t.Fatal("unknown ID admitted")
	}
	current := transportPaths(c, now)[0] + "/"
	if s.acceptsRequestBase(req(http.MethodPost, current+id+"/0"), current) {
		t.Fatal("cross-route upload admitted")
	}
	delete(s.sessions, id)
	if s.acceptsRequestBase(req(http.MethodPost, old+id+"/0"), old) {
		t.Fatal("deleted session kept lease")
	}
	// Final lookup must also bind the route: a reused ID must not turn a
	// previously validated old POST into an upload to a newly created session.
	for _, mode := range []string{"packet-up", "stream-up"} {
		s.sessions[id] = &xhttpServerSession{routeBase: current, mode: mode}
		w := httptest.NewRecorder()
		if mode == "packet-up" {
			s.upload(w, req(http.MethodPost, old+id+"/0"), id, 0)
		} else {
			s.streamUpload(w, req(http.MethodPost, old+id), id)
		}
		if w.Code != http.StatusGone {
			t.Fatal("reused session ID bypassed route lease")
		}
	}
	for _, path := range []string{"/gdt-r/", "/gdt-r/../../", old[:len(old)-1], "/gdt-r/" + strings.Repeat("G", 32) + "/"} {
		if xhttpRequestBase(c, path) != "" {
			t.Fatalf("malformed route admitted: %s", path)
		}
	}
}

func TestRotatingWebSocketAuthenticatesEveryCandidate(t *testing.T) {
	c := rotationTestConfig()
	paths := transportPaths(c, time.Now())
	for _, item := range []struct {
		path, token string
		accepted    bool
	}{
		{paths[0], c.Token, true}, {paths[1], c.Token, true}, {paths[2], c.Token, true},
		{paths[0], "incorrect-token-123456789", false}, {"/unknown", c.Token, false}, {c.WSPath, c.Token, false},
	} {
		t.Run(item.path+item.token[:2], func(t *testing.T) {
			server, client := net.Pipe()
			defer server.Close()
			defer client.Close()
			done := make(chan error, 1)
			go func() {
				conn, _, err := acceptServerWebSocketPaths(server, c.WSHost, c.Token, func(path string) bool { return acceptsTransportPath(c, path, time.Now()) })
				if err == nil {
					_, err = conn.Write([]byte("ok"))
				}
				done <- err
			}()
			conn, err := clientWebSocket(client, c.WSHost, item.path, item.token)
			if (err == nil) != item.accepted {
				t.Fatalf("accept=%t err=%v", item.accepted, err)
			}
			if err == nil {
				body := make([]byte, 2)
				if _, err = io.ReadFull(conn, body); err != nil || string(body) != "ok" {
					t.Fatalf("payload %q %v", body, err)
				}
			}
			if err = <-done; (err == nil) != item.accepted {
				t.Fatalf("server acceptance err=%v", err)
			}
		})
	}
}

func TestRotatingPathRoundsResumeAfterDeadline(t *testing.T) {
	cfg := rotationTestConfig()
	transport := &originTransport{cfg: cfg}
	// Three epochs plus an explicitly enabled migration route. Each bounded
	// round can visit only two slow candidates before its deadline expires.
	const candidates = 10
	seen := make(map[int]bool)
	for round := 0; round < 5; round++ {
		preference := transport.pathChoice.Load()
		for attempt := 0; attempt < 2; attempt++ {
			index := transport.orderedPathIndex(attempt, preference, candidates)
			seen[index] = true
			transport.advancePathChoice(index, candidates)
		}
	}
	if len(seen) != candidates {
		t.Fatalf("bounded retries starved routes: visited=%v", seen)
	}
	// A successful fallback stays preferred for the next round, even when it
	// belongs to the overlap or legacy tail rather than the current epoch.
	transport.pathChoice.Store(candidates - 1)
	if got := transport.orderedPathIndex(0, transport.pathChoice.Load(), candidates); got != candidates-1 {
		t.Fatalf("successful tail fallback lost preference: %d", got)
	}
	// The overlap set can shrink at an epoch boundary. A stale index must
	// remain in bounds and still visit every available candidate exactly once.
	seen = make(map[int]bool)
	for attempt := 0; attempt < cfg.PathCount; attempt++ {
		index := transport.orderedPathIndex(attempt, transport.pathChoice.Load(), cfg.PathCount)
		if index < 0 || index >= cfg.PathCount || seen[index] {
			t.Fatalf("invalid boundary order index=%d seen=%v", index, seen)
		}
		seen[index] = true
	}
	if got := transport.orderedPathIndex(0, 99, 1); got != 0 {
		t.Fatalf("static single-path behavior changed: %d", got)
	}
}
