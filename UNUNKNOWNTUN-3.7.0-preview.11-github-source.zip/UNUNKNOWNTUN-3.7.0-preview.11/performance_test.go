package main

import (
	"bytes"
	"fmt"
	"io"
	"net"
	"testing"
	"time"
)

func BenchmarkSessionReceive(b *testing.B) {
	for _, n := range []int{1024, 32768, 65536} {
		b.Run(fmt.Sprint(n), func(b *testing.B) {
			c := &discardBenchConn{}
			s := newSession(c, "origin", 0, nil)
			defer s.Close()
			s.markAuthenticated()
			st := newStream(1, s)
			st.state.Store(StateOpen)
			if err := s.registerStream(1, st); err != nil {
				b.Fatal(err)
			}
			payload := bytes.Repeat([]byte("s"), n)
			b.SetBytes(int64(n))
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				// Read-loop-equivalent allocation and ownership transfer into a stream queue.
				buf := acquireReceiveBuffer(n)
				copy(buf.data, payload)
				s.handleReceivedFrame(dataHeader(1, 0), buf.data, buf)
				p, _, ok := st.rbuf.Pop()
				if !ok {
					b.Fatal("stream closed")
				}
				st.releaseRecv(len(p.data))
				p.release()
			}
		})
	}
}

type discardBenchConn struct{}

func (*discardBenchConn) Read([]byte) (int, error)         { return 0, io.EOF }
func (*discardBenchConn) Write(p []byte) (int, error)      { return len(p), nil }
func (*discardBenchConn) Close() error                     { return nil }
func (*discardBenchConn) LocalAddr() net.Addr              { return testAddr("local") }
func (*discardBenchConn) RemoteAddr() net.Addr             { return testAddr("remote") }
func (*discardBenchConn) SetDeadline(time.Time) error      { return nil }
func (*discardBenchConn) SetReadDeadline(time.Time) error  { return nil }
func (*discardBenchConn) SetWriteDeadline(time.Time) error { return nil }

func BenchmarkSessionWriteBatch(b *testing.B) {
	s := &Session{conn: &discardBenchConn{}}
	batch := []frameRequest{{h: dataHeader(1, 0), payload: make([]byte, ReadChunkSize)}}
	b.SetBytes(ReadChunkSize)
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if err := s.rawWriteBatch(batch); err != nil {
			b.Fatal(err)
		}
	}
}
