package main

import (
	"encoding/binary"
	"errors"
	"io"
	"net"
	"sync/atomic"
	"testing"
	"time"
)

func TestRetiredSlotRefusesStaleAcquireAndRedial(t *testing.T) {
	sess := newSession(nil, "origin", 0, nil)
	t.Cleanup(sess.Close)
	p := &SessionPool{min: 1, slots: []*sessionSlot{{}, {sess: sess}}}
	p.desired.Store(2)
	stale := p.slots[1] // Get selected this slot before the shrink.
	if !p.retireOne() {
		t.Fatal("retirement failed")
	}
	if got, _ := stale.acquire(); got != nil {
		t.Fatal("stale selection acquired the retired slot")
	}
	var calls int
	_, err := stale.get(func() (*Session, error) {
		calls++
		return newSession(nil, "origin", 0, nil), nil
	})
	if !errors.Is(err, errSessionSlotRetired) || calls != 0 {
		t.Fatalf("retired get = %v, dial calls = %d", err, calls)
	}
}

func TestPoolGetRetriesActiveRangeWhenDialIsRetired(t *testing.T) {
	done := make(chan struct{})
	close(done) // No background drain needs to outlive this deterministic test.
	started, resume := make(chan struct{}), make(chan struct{})
	retiredDial := newSession(nil, "origin", 0, nil)
	live := newSession(nil, "origin", 0, nil)
	t.Cleanup(retiredDial.Close)
	t.Cleanup(live.Close)
	var calls atomic.Int32
	p := &SessionPool{min: 2, done: done, slots: []*sessionSlot{{}, {}, {}}}
	p.desired.Store(3)
	p.next.Store(1) // The stale selection starts at slot 2.
	p.dial = func() (*Session, error) {
		calls.Add(1)
		close(started)
		<-resume
		return retiredDial, nil
	}
	type result struct {
		sess    *Session
		release func()
		err     error
	}
	resultCh := make(chan result, 1)
	go func() {
		s, release, err := p.Get()
		resultCh <- result{s, release, err}
	}()
	<-started
	p.slots[0].mu.Lock()
	p.slots[0].sess = live
	p.slots[0].mu.Unlock()
	if !p.retireOne() {
		t.Fatal("retirement failed")
	}
	close(resume)
	select {
	case got := <-resultCh:
		if got.release != nil {
			defer got.release()
		}
		if got.err != nil || got.sess != live {
			t.Fatalf("Get returned %p, %v; want active %p", got.sess, got.err, live)
		}
	case <-time.After(time.Second):
		t.Fatal("Get did not rescan after its dial was retired")
	}
	if !retiredDial.Closed() || p.slots[2].current() != nil || calls.Load() != 1 {
		t.Fatal("retired dial remained installed or triggered another dial")
	}
}

func TestRejectedRegistrationCancelsChildContext(t *testing.T) {
	sess := newSession(nil, "origin", 0, nil)
	t.Cleanup(sess.Close)
	first := newStream(1, sess)
	if err := sess.registerStream(1, first); err != nil {
		t.Fatal(err)
	}
	duplicate := newStream(1, sess)
	if err := sess.registerStream(1, duplicate); err == nil || duplicate.ctx.Err() == nil {
		t.Fatal("duplicate rejection did not cancel its child context")
	}
	before := activeStreams.Load()
	limit := maxStreamsGlobal.Load()
	maxStreamsGlobal.Store(before)
	t.Cleanup(func() { maxStreamsGlobal.Store(limit) })
	rejected := newStream(3, sess)
	if err := sess.registerStream(3, rejected); err == nil || rejected.ctx.Err() == nil {
		t.Fatal("global-limit rejection did not cancel its child context")
	}
	if got := activeStreams.Load(); got != before {
		t.Fatalf("rejection changed active count from %d to %d", before, got)
	}
}

func TestNegotiatedInitialCreditSurvivesOpenResizeOrdering(t *testing.T) {
	for _, direction := range []string{"origin-to-egress", "egress-to-origin"} {
		for _, expand := range []bool{false, true} {
			for _, receiverFirst := range []bool{false, true} {
				name := direction + "/shrink/"
				if expand {
					name = direction + "/expand/"
				}
				if receiverFirst {
					name += "receiver-registered"
				} else {
					name += "receiver-not-yet-registered"
				}
				t.Run(name, func(t *testing.T) {
					a := newSession(discardNetConn{}, "origin", 0, nil)
					b := newSession(discardNetConn{}, "egress", 0, nil)
					t.Cleanup(a.Close)
					t.Cleanup(b.Close)
					a.fixedInitialWindow.Store(true)
					b.fixedInitialWindow.Store(true)
					sender, receiver := a, b
					if direction == "egress-to-origin" {
						sender, receiver = b, a
					}
					oldLimit, newLimit := flowSettings.normalWindow, flowSettings.degradedWindow
					if expand {
						oldLimit, newLimit = newLimit, oldLimit
					}
					sender.peerWindow.Store(oldLimit)
					receiver.localWindow.Store(oldLimit)
					send := newStream(1, sender)
					if err := sender.registerStream(1, send); err != nil {
						t.Fatal(err)
					}
					recv := newStream(1, receiver)
					if receiverFirst {
						if err := receiver.registerStream(1, recv); err != nil {
							t.Fatal(err)
						}
					}
					if err := receiver.setLocalWindow(newLimit); err != nil {
						t.Fatal(err)
					}
					if !sender.applyPeerWindow(newLimit) {
						t.Fatal("resize rejected")
					}
					if !receiverFirst {
						if err := receiver.registerStream(1, recv); err != nil {
							t.Fatal(err)
						}
					}
					if send.sendWindow != flowSettings.normalWindow || recv.recvWindow != send.sendWindow {
						t.Fatalf("initial credit mismatch: send=%d receive=%d", send.sendWindow, recv.recvWindow)
					}
					// Exhaust a complete initial burst before the target drains. This
					// reproduces the old shrink-overrun trigger without network timing.
					for left := flowSettings.normalWindow; left > 0; left -= MaxFramePayload {
						quota := send.acquireSend(MaxFramePayload)
						if quota != MaxFramePayload || !recv.consumeRecv(quota) {
							t.Fatal("valid initial burst overran the receiver")
						}
					}
					for left := flowSettings.normalWindow; left > 0; left -= MaxFramePayload {
						if credit := recv.releaseRecv(MaxFramePayload); credit > 0 && !send.addSendWindow(credit) {
							t.Fatal("drained credit exceeded sender ceiling")
						}
					}
					if send.sendWindow != newLimit || recv.recvWindow != newLimit {
						t.Fatalf("credit did not converge without stalling: send=%d recv=%d want=%d", send.sendWindow, recv.recvWindow, newLimit)
					}
				})
			}
		}
	}
}

func capabilityTestRead(conn net.Conn) (Header, []byte, error) {
	var raw [HeaderSize]byte
	if _, err := io.ReadFull(conn, raw[:]); err != nil {
		return Header{}, nil, err
	}
	h, err := DecodeHeader(raw[:])
	if err != nil {
		return h, nil, err
	}
	body := make([]byte, int(h.Length)+int(h.PadLen))
	_, err = io.ReadFull(conn, body)
	return h, body[:h.Length], err
}

func capabilityTestWrite(conn net.Conn, cmd byte, payload []byte) error {
	h := ctrlHeader(cmd, 0, 0)
	h.Length = uint32(len(payload))
	wire := make([]byte, HeaderSize+len(payload))
	h.encodeTo(wire)
	copy(wire[HeaderSize:], payload)
	_, err := writeFull(conn, wire)
	return err
}

func TestInitialWindowCapabilityNewPeer(t *testing.T) {
	a, b := net.Pipe()
	_ = a.SetDeadline(time.Now().Add(time.Second))
	_ = b.SetDeadline(time.Now().Add(time.Second))
	origin, egress := newSession(a, "origin", 0, nil), newSession(b, "egress", 0, nil)
	t.Cleanup(origin.Close)
	t.Cleanup(egress.Close)
	origin.markAuthenticated()
	egress.markAuthenticated()
	go egress.readLoop()
	if err := negotiateInitialStreamWindow(origin); err != nil {
		t.Fatal(err)
	}
	if !origin.fixedInitialWindow.Load() || !egress.fixedInitialWindow.Load() {
		t.Fatal("new peers did not agree on fixed initial credit")
	}
}

func TestInitialWindowCapabilityLegacyEchoAndResize(t *testing.T) {
	a, b := net.Pipe()
	_ = a.SetDeadline(time.Now().Add(time.Second))
	_ = b.SetDeadline(time.Now().Add(time.Second))
	origin := newSession(a, "origin", 0, nil)
	t.Cleanup(origin.Close)
	t.Cleanup(func() { _ = b.Close() })
	origin.markAuthenticated()
	errCh := make(chan error, 1)
	go func() {
		h, payload, err := capabilityTestRead(b)
		if err == nil && h.Cmd != CmdPing {
			err = errors.New("expected legacy-compatible Ping")
		}
		if err == nil {
			resize := make([]byte, 4)
			binary.BigEndian.PutUint32(resize, uint32(flowSettings.degradedWindow))
			err = capabilityTestWrite(b, CmdWindowResize, resize)
		}
		if err == nil {
			err = capabilityTestWrite(b, CmdPong, payload)
		}
		errCh <- err
	}()
	if err := negotiateInitialStreamWindow(origin); err != nil {
		t.Fatal(err)
	}
	if err := <-errCh; err != nil {
		t.Fatal(err)
	}
	if origin.fixedInitialWindow.Load() {
		t.Fatal("ordinary legacy echo falsely enabled the capability")
	}
	st := newStream(1, origin)
	if err := origin.registerStream(1, st); err != nil {
		t.Fatal(err)
	}
	if st.sendWindow != flowSettings.degradedWindow {
		t.Fatal("legacy initial credit rules changed")
	}
	receiver := newSession(nil, "egress", 0, nil)
	t.Cleanup(receiver.Close)
	receiver.localWindow.Store(flowSettings.degradedWindow)
	recv := newStream(1, receiver)
	if err := receiver.registerStream(1, recv); err != nil {
		t.Fatal(err)
	}
	// Several complete windows must still circulate, not merely fit once.
	for round := 0; round < 3; round++ {
		for left := flowSettings.degradedWindow; left > 0; left -= MaxFramePayload {
			quota := st.acquireSend(MaxFramePayload)
			if quota != MaxFramePayload || !recv.consumeRecv(quota) {
				t.Fatal("legacy stream exhausted mismatched credit")
			}
			if credit := recv.releaseRecv(quota); credit > 0 && !st.addSendWindow(credit) {
				t.Fatal("legacy credit update rejected")
			}
		}
	}
	if st.sendWindow != flowSettings.degradedWindow {
		t.Fatal("legacy stream lost credit after draining")
	}
}

func TestInitialWindowCapabilityRejectsWrongNonce(t *testing.T) {
	a, b := net.Pipe()
	_ = a.SetDeadline(time.Now().Add(time.Second))
	_ = b.SetDeadline(time.Now().Add(time.Second))
	origin := newSession(a, "origin", 0, nil)
	t.Cleanup(origin.Close)
	t.Cleanup(func() { _ = b.Close() })
	origin.markAuthenticated()
	go func() {
		_, payload, err := capabilityTestRead(b)
		if err != nil {
			return
		}
		binary.BigEndian.PutUint32(payload, initialWindowReplyPrefix)
		payload[7] ^= 1
		_ = capabilityTestWrite(b, CmdPong, payload)
	}()
	if err := negotiateInitialStreamWindow(origin); err == nil || origin.fixedInitialWindow.Load() {
		t.Fatal("mismatched capability response was accepted")
	}
}

func TestInitialWindowCapabilityMissingReplyIsBounded(t *testing.T) {
	a, b := net.Pipe()
	_ = a.SetDeadline(time.Now().Add(100 * time.Millisecond))
	origin := newSession(a, "origin", 0, nil)
	t.Cleanup(origin.Close)
	t.Cleanup(func() { _ = b.Close() })
	origin.markAuthenticated()
	readDone := make(chan struct{})
	go func() { _, _, _ = capabilityTestRead(b); close(readDone) }()
	if err := negotiateInitialStreamWindow(origin); err == nil || origin.fixedInitialWindow.Load() {
		t.Fatal("missing response silently selected capability or legacy mode")
	}
	<-readDone
}

func TestInitialWindowCapabilityCannotChangeExistingCarrier(t *testing.T) {
	egress := newSession(nil, "egress", 0, nil)
	t.Cleanup(egress.Close)
	egress.initialStreamSeen.Store(true)
	query := make([]byte, 8)
	binary.BigEndian.PutUint32(query, initialWindowQueryPrefix)
	if egress.acceptInitialWindowCapability(query) || egress.fixedInitialWindow.Load() {
		t.Fatal("late capability query changed initial credit on an existing carrier")
	}
}
