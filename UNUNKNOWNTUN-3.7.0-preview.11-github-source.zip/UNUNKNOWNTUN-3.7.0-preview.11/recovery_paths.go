package main

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"strings"
	"sync"
	"time"
)

const (
	recoveryPathCooldown      = 30 * time.Second
	recoveryPathQuarantine    = 120 * time.Second
	recoveryPathRejectedLimit = 64
)

type routeCandidate struct {
	path     string
	endpoint string
	epoch    int64
	rotating bool
	index    int
	recovery bool
}

type routeRejectionKey struct {
	endpoint string
	path     string
}

func (c routeCandidate) rejectionKey() routeRejectionKey {
	return routeRejectionKey{endpoint: c.endpoint, path: c.path}
}

func candidateEndpoint(endpoints []string) string {
	if len(endpoints) > 0 {
		return endpoints[0]
	}
	return ""
}

// All path failure and preference state is per origin transport and bounded.
// Quarantine entries identify both endpoint and route; one broken proxy must
// not suppress the same authenticated route on a different configured endpoint.
// Callbacks capture a successful selection generation so an older failed
// carrier cannot overwrite a newer healthy selection of that same route.
type routeRecoveryState struct {
	mu                sync.Mutex
	rejected          map[routeRejectionKey]time.Time
	preferred         string
	preferredEndpoint string
	generation        uint64
	path              string
	epoch             int64
	nextGeneration    time.Time
	requested         bool
	priority          bool
}

func acceptedPathEpochs(c *Config, now time.Time) []int64 {
	if c.PathRotation <= 0 {
		return nil
	}
	period := int64(c.PathRotation)
	epoch, phase := now.UnixNano()/period, time.Duration(now.UnixNano()%period)
	epochs := []int64{epoch}
	if phase < c.PathGrace {
		epochs = append(epochs, epoch-1)
	}
	if c.PathRotation-phase <= c.PathGrace {
		epochs = append(epochs, epoch+1)
	}
	return epochs
}

func signedRecoveryPath(c *Config, epoch int64, nonce []byte) string {
	if len(nonce) != 16 {
		return ""
	}
	h := hmac.New(sha256.New, []byte(c.Token))
	for _, part := range []string{"ununknowntun-recovery-path-v1", c.Transport, canonicalHost(c.WSHost), configuredTransportPath(c)} {
		fmt.Fprintf(h, "%d:%s;", len(part), part)
	}
	fmt.Fprintf(h, "%d:%d:", int64(c.PathRotation), epoch)
	_, _ = h.Write(nonce)
	return rotatingPathPrefix + hex.EncodeToString(nonce) + hex.EncodeToString(h.Sum(nil)[:16])
}

// Recovery routes have a random 128-bit nonce and a domain-separated 128-bit
// MAC. Verification has no server-side route table and admits only the same
// current/adjacent epochs as fixed routes. Tunnel authentication still follows.
func recoveryPathEpoch(c *Config, path string, now time.Time) (int64, bool) {
	if c.PathRotation <= 0 || !strings.HasPrefix(path, rotatingPathPrefix) {
		return 0, false
	}
	rest := strings.TrimPrefix(path, rotatingPathPrefix)
	if len(rest) != 64 || strings.ToLower(rest) != rest {
		return 0, false
	}
	raw, err := hex.DecodeString(rest)
	if err != nil {
		return 0, false
	}
	for _, epoch := range acceptedPathEpochs(c, now) {
		if hmac.Equal([]byte(path), []byte(signedRecoveryPath(c, epoch, raw[:16]))) {
			return epoch, true
		}
	}
	return 0, false
}

func (r *routeRecoveryState) pruneLocked(now time.Time) {
	for path, until := range r.rejected {
		if !now.Before(until) {
			delete(r.rejected, path)
		}
	}
}

func (r *routeRecoveryState) rejectLocked(key routeRejectionKey, now time.Time) {
	r.pruneLocked(now)
	if r.rejected == nil {
		r.rejected = make(map[routeRejectionKey]time.Time)
	}
	if _, exists := r.rejected[key]; !exists && len(r.rejected) >= recoveryPathRejectedLimit {
		var oldest routeRejectionKey
		var until time.Time
		var found bool
		for p, expires := range r.rejected {
			if !found || expires.Before(until) {
				oldest, until = p, expires
				found = true
			}
		}
		delete(r.rejected, oldest)
	}
	r.rejected[key] = now.Add(recoveryPathQuarantine)
}

func (t *originTransport) ensureRecoveryLocked(now time.Time) {
	r := &t.recovery
	if t.cfg.PathRotation <= 0 || !r.requested || now.Before(r.nextGeneration) {
		return
	}
	// Reserve the cooldown even if OS randomness is temporarily unavailable.
	r.nextGeneration = now.Add(recoveryPathCooldown)
	var nonce [16]byte
	if _, err := rand.Read(nonce[:]); err != nil {
		return
	}
	r.epoch = now.UnixNano() / int64(t.cfg.PathRotation)
	r.path = signedRecoveryPath(t.cfg, r.epoch, nonce[:])
	r.requested = false
}

func (t *originTransport) requestRecovery(now time.Time, priority bool, observedGeneration uint64, endpoints ...string) routeCandidate {
	r := &t.recovery
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.generation != observedGeneration && r.preferred != "" {
		return routeCandidate{}
	}
	r.requested = true
	r.priority = r.priority || priority
	t.ensureRecoveryLocked(now)
	endpoint := candidateEndpoint(endpoints)
	if t.cfg.PathRotation <= 0 || r.path == "" || r.epoch != now.UnixNano()/int64(t.cfg.PathRotation) || now.Before(r.rejected[routeRejectionKey{endpoint: endpoint, path: r.path}]) {
		return routeCandidate{}
	}
	return routeCandidate{path: r.path, endpoint: endpoint, epoch: r.epoch, rotating: true, index: -1, recovery: true}
}

func (t *originTransport) recordRouteFailure(candidate routeCandidate, observedGeneration uint64, now time.Time) {
	r := &t.recovery
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.generation != observedGeneration && r.preferred == candidate.path && r.preferredEndpoint == candidate.endpoint {
		return
	}
	r.rejectLocked(candidate.rejectionKey(), now)
	if candidate.recovery {
		r.priority = false
	}
}

func (t *originTransport) routeQuarantined(path string, now time.Time, endpoints ...string) bool {
	if t.cfg.PathRotation <= 0 {
		return false
	}
	r := &t.recovery
	r.mu.Lock()
	defer r.mu.Unlock()
	return now.Before(r.rejected[routeRejectionKey{endpoint: candidateEndpoint(endpoints), path: path}])
}

// A connection or TLS failure happened before any HTTP route was requested.
// Do not attribute endpoint availability problems to an untried HTTP route.
func routeAttemptReachedHTTP(err error) bool {
	if err == nil {
		return true
	}
	message := err.Error()
	for _, stage := range []string{"[tcp-connect]", "[tls-handshake]", "[tls-clienthello]", "[tls-alpn]", "reverse proxy negotiated TLS version", "reverse proxy did not accept Encrypted Client Hello"} {
		if strings.Contains(message, stage) {
			return false
		}
	}
	return true
}

func (t *originTransport) recordRouteHealthFailure(candidate routeCandidate, generation uint64, now time.Time) {
	r := &t.recovery
	r.mu.Lock()
	defer r.mu.Unlock()
	if r.generation != generation && r.preferred == candidate.path && r.preferredEndpoint == candidate.endpoint {
		return
	}
	r.rejectLocked(candidate.rejectionKey(), now)
	// An old slot can reject only its own route. It cannot replace the new
	// selection (especially a working random route) with another recovery path.
	if r.generation != generation && r.preferred != "" {
		return
	}
	if r.preferred == candidate.path && r.preferredEndpoint == candidate.endpoint {
		r.preferred = ""
		r.preferredEndpoint = ""
		r.priority = true
	}
	r.requested = true
	t.ensureRecoveryLocked(now)
}

func (t *originTransport) publishRoute(session *Session, candidate routeCandidate) {
	r := &t.recovery
	r.mu.Lock()
	r.generation++
	generation := r.generation
	r.preferred = candidate.path
	r.preferredEndpoint = candidate.endpoint
	r.requested = false
	delete(r.rejected, candidate.rejectionKey())
	r.priority = false
	if candidate.index >= 0 {
		t.pathChoice.Store(uint32(candidate.index))
	}
	r.mu.Unlock()
	session.route.Store(&carrierRoute{epoch: candidate.epoch, rotating: candidate.rotating, onFailure: func() {
		t.recordRouteHealthFailure(candidate, generation, time.Now())
	}})
}

func (t *originTransport) recoveryCandidates(now time.Time, endpoints ...string) ([]routeCandidate, uint64) {
	r := &t.recovery
	r.mu.Lock()
	defer r.mu.Unlock()
	r.pruneLocked(now)
	t.ensureRecoveryLocked(now)
	fixed := transportPaths(t.cfg, now)
	endpoint := candidateEndpoint(endpoints)
	if t.cfg.PathRotation <= 0 {
		return []routeCandidate{{path: fixed[0], endpoint: endpoint, index: 0}}, r.generation
	}
	epochs := acceptedPathEpochs(t.cfg, now)
	var current, overlap []routeCandidate
	for i, path := range fixed {
		if now.Before(r.rejected[routeRejectionKey{endpoint: endpoint, path: path}]) {
			continue
		}
		candidate := routeCandidate{path: path, endpoint: endpoint, index: i}
		if i < len(epochs)*t.cfg.PathCount {
			candidate.epoch, candidate.rotating = epochs[i/t.cfg.PathCount], true
		}
		if i < t.cfg.PathCount {
			current = append(current, candidate)
		} else {
			overlap = append(overlap, candidate)
		}
	}
	prefer := func(items []routeCandidate) []routeCandidate {
		for i := range items {
			if items[i].path == r.preferred {
				item := items[i]
				copy(items[1:i+1], items[:i])
				items[0] = item
				break
			}
		}
		return items
	}
	current, overlap = prefer(current), prefer(overlap)
	if r.path != "" && r.epoch == epochs[0] && !now.Before(r.rejected[routeRejectionKey{endpoint: endpoint, path: r.path}]) {
		recovery := routeCandidate{path: r.path, endpoint: endpoint, epoch: r.epoch, rotating: true, index: -1, recovery: true}
		if r.priority || r.preferred == r.path {
			current = append([]routeCandidate{recovery}, current...)
		} else {
			current = append(current, recovery)
		}
	}
	return append(current, overlap...), r.generation
}
