package main

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func TestRecoveryPathSignatureAndSharedContext(t *testing.T) {
	cfg := rotationTestConfig()
	now := time.Unix(1800000000, 0).Truncate(cfg.PathRotation).Add(cfg.PathRotation / 2)
	epoch := now.UnixNano() / int64(cfg.PathRotation)
	path := signedRecoveryPath(cfg, epoch, bytes.Repeat([]byte{0x37}, 16))
	if len(path) != len(rotatingPathPrefix)+64 || !acceptsTransportPath(cfg, path, now) {
		t.Fatal("valid signed random route was not accepted")
	}
	peer := *cfg
	peer.Mode = "egress"
	if !acceptsTransportPath(&peer, path, now.In(time.FixedZone("peer", -8*3600))) {
		t.Fatal("mode/timezone changed route validation")
	}
	for _, mutate := range []func(*Config){
		func(c *Config) { c.Token += "wrong" }, func(c *Config) { c.WSHost = "wrong.example" },
		func(c *Config) { c.WSPath += "wrong" }, func(c *Config) { c.Transport = TransportXHTTP },
		func(c *Config) { c.PathRotation = time.Minute }, func(c *Config) { c.PathRotation = 0 },
	} {
		other := *cfg
		mutate(&other)
		if acceptsTransportPath(&other, path, now) {
			t.Fatal("signed route accepted wrong shared context")
		}
	}
	for _, malformed := range []string{path + "/", path + "0", path[:len(path)-1], strings.ToUpper(path), path[:len(path)-1] + "g", rotatingPathPrefix + strings.Repeat("0", 64)} {
		if acceptsTransportPath(cfg, malformed, now) {
			t.Fatalf("invalid signed route accepted: %q", malformed)
		}
	}
	if acceptsTransportPath(cfg, path, now.Add(2*cfg.PathRotation)) {
		t.Fatal("expired signed route accepted")
	}
	if signedRecoveryPath(cfg, epoch, []byte{1}) != "" {
		t.Fatal("invalid nonce length accepted")
	}
	if !acceptsTransportPath(cfg, rotatingPath(cfg, epoch, 0), now) {
		t.Fatal("fixed route compatibility lost")
	}
}

func TestRecoveryPathOverlapAndXHTTPLease(t *testing.T) {
	cfg := rotationTestConfig()
	cfg.Transport = TransportXHTTP
	boundary := time.Unix(1800000000, 0).Truncate(cfg.PathRotation)
	epoch := boundary.UnixNano() / int64(cfg.PathRotation)
	previous := signedRecoveryPath(cfg, epoch-1, bytes.Repeat([]byte{1}, 16))
	current := signedRecoveryPath(cfg, epoch, bytes.Repeat([]byte{2}, 16))
	if !acceptsTransportPath(cfg, previous, boundary.Add(cfg.PathGrace-time.Nanosecond)) || acceptsTransportPath(cfg, previous, boundary.Add(cfg.PathGrace)) {
		t.Fatal("previous recovery overlap mismatch")
	}
	if !acceptsTransportPath(cfg, current, boundary.Add(-cfg.PathGrace)) || acceptsTransportPath(cfg, current, boundary.Add(-cfg.PathGrace-time.Nanosecond)) {
		t.Fatal("future recovery overlap mismatch")
	}
	server := newXHTTPServer(cfg, nil)
	id := "01234567-89ab-4cde-8abc-0123456789ab"
	leaseEpoch := time.Now().UnixNano() / int64(cfg.PathRotation)
	base := signedRecoveryPath(cfg, leaseEpoch-3, bytes.Repeat([]byte{3}, 16)) + "/"
	server.sessions[id] = &xhttpServerSession{routeBase: base}
	post := httptest.NewRequest(http.MethodPost, "https://"+cfg.WSHost+base+id+"/0", nil)
	if xhttpRequestBase(cfg, post.URL.Path) != base || !server.acceptsRequestBase(post, base) {
		t.Fatal("existing path-bound recovery upload lost its lease")
	}
	get := httptest.NewRequest(http.MethodGet, "https://"+cfg.WSHost+base+id, nil)
	if server.acceptsRequestBase(get, base) {
		t.Fatal("expired recovery route opened a new XHTTP carrier")
	}
	otherBase := signedRecoveryPath(cfg, leaseEpoch, bytes.Repeat([]byte{4}, 16)) + "/"
	cross := httptest.NewRequest(http.MethodPost, "https://"+cfg.WSHost+otherBase+id+"/0", nil)
	if server.acceptsRequestBase(cross, otherBase) {
		t.Fatal("recovery XHTTP upload crossed route binding")
	}
	delete(server.sessions, id)
	if server.acceptsRequestBase(post, base) {
		t.Fatal("deleted recovery lease remained valid")
	}
}

func TestRecoveryAfterEntireFixedSetFails(t *testing.T) {
	cfg := rotationTestConfig()
	cfg.PathGrace = 0
	transport := &originTransport{cfg: cfg}
	var attempted []string
	session, _, err := transport.dialAuthenticatedCandidates(context.Background(), "test", func(_ context.Context, path string) (*Session, error) {
		attempted = append(attempted, path)
		if len(path) == len(rotatingPathPrefix)+32 {
			return nil, errors.New("fixed route blackholed")
		}
		if !acceptsTransportPath(cfg, path, time.Now()) {
			t.Fatal("recovery route cannot be independently validated by peer")
		}
		return renewalTestSession(t), nil
	})
	if err != nil || session == nil || len(attempted) != cfg.PathCount+1 {
		t.Fatalf("recovery after fixed failure: attempts=%d err=%v", len(attempted), err)
	}
	epoch, known := session.routeEpoch()
	if !known || epoch != time.Now().UnixNano()/int64(cfg.PathRotation) {
		t.Fatal("authenticated recovery lost its actual route epoch")
	}
}

func TestRecoveryHealthFailureChangesPathAndPreservesNewerChoice(t *testing.T) {
	cfg := rotationTestConfig()
	cfg.PathGrace = 0
	transport := &originTransport{cfg: cfg}
	session, _, err := transport.dialAuthenticatedCandidates(context.Background(), "test", func(context.Context, string) (*Session, error) { return renewalTestSession(t), nil })
	if err != nil {
		t.Fatal(err)
	}
	oldRoute := session.route.Load()
	oldPath := transport.recovery.preferred
	session.failCarrierHealth("fixture payload blackhole")
	candidates, _ := transport.recoveryCandidates(time.Now())
	if len(candidates) == 0 || !candidates[0].recovery || candidates[0].path == oldPath {
		t.Fatal("health failure did not prioritize a fresh signed route")
	}
	for _, candidate := range candidates {
		if candidate.path == oldPath {
			t.Fatal("failed route immediately redialed")
		}
	}
	newSession, _, err := transport.dialAuthenticatedCandidates(context.Background(), "test", func(context.Context, string) (*Session, error) { return renewalTestSession(t), nil })
	if err != nil {
		t.Fatal(err)
	}
	preferred := transport.recovery.preferred
	oldRoute.onFailure()
	if transport.recovery.preferred != preferred || transport.recovery.path != preferred || newSession.Closed() {
		t.Fatal("stale slot failure displaced a newer healthy random route")
	}
}

func TestRecoveryGenerationCooldownQuarantineAndBounds(t *testing.T) {
	cfg := rotationTestConfig()
	transport := &originTransport{cfg: cfg}
	now := time.Unix(1800000000, 0)
	first := transport.requestRecovery(now, true, 0)
	second := transport.requestRecovery(now.Add(recoveryPathCooldown-time.Nanosecond), true, 0)
	if first.path == "" || first.path != second.path {
		t.Fatal("recovery generation exceeded cooldown")
	}
	third := transport.requestRecovery(now.Add(recoveryPathCooldown), true, 0)
	if third.path == "" || third.path == first.path {
		t.Fatal("exhausted recovery route did not get a fresh nonce after cooldown")
	}
	for i := 0; i < 200; i++ {
		transport.recordRouteFailure(routeCandidate{path: fmt.Sprintf("fixture-%d", i)}, 0, now)
	}
	if len(transport.recovery.rejected) != recoveryPathRejectedLimit {
		t.Fatal("route rejection memory not bounded")
	}
	transport.recoveryCandidates(now.Add(recoveryPathQuarantine))
	if len(transport.recovery.rejected) != 0 {
		t.Fatal("expired rejection did not leave quarantine")
	}
}

func TestRecoveryRejectedByOldPeerDoesNotStarveFixedRoutes(t *testing.T) {
	cfg := rotationTestConfig()
	cfg.PathGrace = 0
	transport := &originTransport{cfg: cfg}
	transport.requestRecovery(time.Now(), true, 0)
	var attempts []string
	session, _, err := transport.dialAuthenticatedCandidates(context.Background(), "test", func(_ context.Context, path string) (*Session, error) {
		attempts = append(attempts, path)
		if len(path) == len(rotatingPathPrefix)+64 {
			return nil, errors.New("old peer 404")
		}
		return renewalTestSession(t), nil
	})
	if err != nil || session == nil || len(attempts) != 2 || len(attempts[1]) != len(rotatingPathPrefix)+32 {
		t.Fatalf("recovery incompatibility starved fixed route: %v %v", attempts, err)
	}
}

func TestRecoveryCurrentEpochPrecedesPreferredOverlap(t *testing.T) {
	cfg := rotationTestConfig()
	now := time.Unix(1800000000, 0).Truncate(cfg.PathRotation).Add(time.Second)
	transport := &originTransport{cfg: cfg}
	epoch := now.UnixNano() / int64(cfg.PathRotation)
	previous := routeCandidate{path: rotatingPath(cfg, epoch-1, 0), epoch: epoch - 1, rotating: true, index: cfg.PathCount}
	transport.publishRoute(renewalTestSession(t), previous)
	candidates, _ := transport.recoveryCandidates(now)
	if len(candidates) < cfg.PathCount+1 || candidates[0].epoch != epoch {
		t.Fatal("preferred overlap route displaced current epoch routes")
	}
	for i := 0; i < cfg.PathCount; i++ {
		if candidates[i].epoch != epoch {
			t.Fatal("overlap interrupted current epoch candidates")
		}
	}
	current := renewalTestSession(t)
	transport.publishRoute(current, candidates[0])
	if actual, known := current.routeEpoch(); !known || actual != epoch {
		t.Fatal("new epoch not published on authenticated session")
	}
}

func TestRecoveryConcurrentFailuresAndDials(t *testing.T) {
	cfg := rotationTestConfig()
	transport := &originTransport{cfg: cfg}
	now := time.Now()
	var wg sync.WaitGroup
	for worker := 0; worker < 8; worker++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := 0; i < 50; i++ {
				candidates, generation := transport.recoveryCandidates(now)
				if len(candidates) > 0 {
					transport.recordRouteFailure(candidates[0], generation, now)
				}
				transport.requestRecovery(now, true, generation)
			}
		}()
	}
	wg.Wait()
	if len(transport.recovery.rejected) > recoveryPathRejectedLimit {
		t.Fatal("concurrent rejection exceeded memory cap")
	}
	if transport.recovery.path == "" || !transport.recovery.nextGeneration.Equal(now.Add(recoveryPathCooldown)) {
		t.Fatal("concurrent recovery requests exceeded generation cooldown")
	}
}

func TestRecoveryCallerCancellationDoesNotRejectRoute(t *testing.T) {
	cfg := rotationTestConfig()
	transport := &originTransport{cfg: cfg}
	ctx, cancel := context.WithCancel(context.Background())
	_, _, err := transport.dialAuthenticatedCandidates(ctx, "test", func(context.Context, string) (*Session, error) {
		cancel()
		return nil, context.Canceled
	})
	if !errors.Is(err, context.Canceled) || len(transport.recovery.rejected) != 0 || transport.recovery.path != "" {
		t.Fatal("caller cancellation poisoned routes or generated unnecessary recovery")
	}
}

func TestRecoveryConcurrentRejectionSkipsCapturedCandidate(t *testing.T) {
	cfg := rotationTestConfig()
	cfg.PathGrace = 0
	transport := &originTransport{cfg: cfg}
	paths := transportPaths(cfg, time.Now())
	var attempts []string
	session, _, err := transport.dialAuthenticatedCandidates(context.Background(), "test", func(_ context.Context, path string) (*Session, error) {
		attempts = append(attempts, path)
		if path == paths[0] {
			transport.recordRouteFailure(routeCandidate{path: paths[1]}, 0, time.Now())
			return nil, errors.New("fixture first route failure")
		}
		return renewalTestSession(t), nil
	})
	if err != nil || session == nil || len(attempts) != 2 || attempts[1] != paths[2] {
		t.Fatal("captured candidate list redialed a concurrently rejected route")
	}
}

func TestRecoveryOldFailureCannotQuarantineNewerSamePathSuccess(t *testing.T) {
	cfg := rotationTestConfig()
	transport := &originTransport{cfg: cfg}
	candidates, _ := transport.recoveryCandidates(time.Now())
	old, current := renewalTestSession(t), renewalTestSession(t)
	transport.publishRoute(old, candidates[0])
	oldCallback := old.route.Load().onFailure
	transport.publishRoute(current, candidates[0])
	oldCallback()
	if transport.routeQuarantined(candidates[0].path, time.Now()) || transport.recovery.path != "" || transport.recovery.preferred != candidates[0].path {
		t.Fatal("older carrier failure poisoned a newer successful connection to its path")
	}
}

func TestRecoveryConcurrentAuthenticatedPublicationAndHealthFailure(t *testing.T) {
	cfg := rotationTestConfig()
	transport := &originTransport{cfg: cfg}
	var wg sync.WaitGroup
	var established atomic.Int64
	for worker := 0; worker < 8; worker++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := 0; i < 10; i++ {
				session, _, err := transport.dialAuthenticatedCandidates(context.Background(), "test", func(context.Context, string) (*Session, error) {
					return renewalTestSession(t), nil
				})
				if err == nil && session != nil {
					established.Add(1)
					if i%2 == 0 {
						session.route.Load().onFailure()
					}
					session.Close()
				}
			}
		}()
	}
	wg.Wait()
	if established.Load() == 0 || len(transport.recovery.rejected) > recoveryPathRejectedLimit {
		t.Fatal("concurrent authenticated selections failed or exceeded rejection cap")
	}
}

func TestRecoveryConnectionFailureDoesNotPoisonAlternateEndpoint(t *testing.T) {
	for _, stage := range []string{"tcp-connect", "tls-handshake", "tls-clienthello", "tls-alpn"} {
		t.Run(stage, func(t *testing.T) {
			cfg := rotationTestConfig()
			cfg.PathGrace = 0
			transport := &originTransport{cfg: cfg}
			_, _, err := transport.dialAuthenticatedCandidates(context.Background(), "endpoint-a", func(context.Context, string) (*Session, error) {
				return nil, fmt.Errorf("[%s] fixture endpoint unavailable before HTTP", stage)
			})
			if err == nil || len(transport.recovery.rejected) != 0 {
				t.Fatal("pre-HTTP failure globally quarantined a shared route")
			}
			var attempts int
			session, _, err := transport.dialAuthenticatedCandidates(context.Background(), "endpoint-b", func(_ context.Context, path string) (*Session, error) {
				attempts++
				if len(path) == len(rotatingPathPrefix)+64 {
					return nil, errors.New("old endpoint peer: recovery route 404")
				}
				return renewalTestSession(t), nil
			})
			if err != nil || session == nil || attempts != 2 {
				t.Fatalf("working alternate endpoint lost its fixed route: attempts=%d err=%v", attempts, err)
			}
		})
	}
}

func TestRecoveryEndpointHTTPOrAuthFailureNeverStarvesHealthyEndpoint(t *testing.T) {
	for _, failure := range []string{"HTTP 404", "[gdt-auth/read-accept-header] authentication rejected"} {
		for _, legacy := range []bool{false, true} {
			t.Run(fmt.Sprintf("%s/legacy=%t", failure, legacy), func(t *testing.T) {
				cfg := rotationTestConfig()
				cfg.PathGrace = 0
				transport := &originTransport{cfg: cfg}
				var firstRecovery string
				var firstGenerationDeadline time.Time
				for round := 0; round < 3; round++ {
					_, _, err := transport.dialAuthenticatedEndpointCandidates(context.Background(), "bad-endpoint:443", "test", func(context.Context, string) (*Session, error) {
						return nil, errors.New(failure)
					})
					if err == nil {
						t.Fatal("bad endpoint unexpectedly authenticated")
					}
					if round == 0 {
						firstRecovery, firstGenerationDeadline = transport.recovery.path, transport.recovery.nextGeneration
					}
					var attempts int
					session, _, err := transport.dialAuthenticatedEndpointCandidates(context.Background(), "healthy-endpoint:443", "test", func(_ context.Context, path string) (*Session, error) {
						attempts++
						if legacy && len(path) == len(rotatingPathPrefix)+64 {
							return nil, errors.New("legacy recovery route 404")
						}
						return renewalTestSession(t), nil
					})
					if err != nil || session == nil || attempts == 0 || attempts > 2 {
						t.Fatalf("round %d working endpoint starved: attempts=%d err=%v", round, attempts, err)
					}
					if transport.recovery.preferredEndpoint != "healthy-endpoint:443" || len(transport.recovery.rejected) > recoveryPathRejectedLimit {
						t.Fatal("endpoint preference or global rejection bound was lost")
					}
					if transport.recovery.path != firstRecovery || !transport.recovery.nextGeneration.Equal(firstGenerationDeadline) {
						t.Fatal("endpoint retries bypassed the shared recovery generation cooldown")
					}
					session.Close()
				}
			})
		}
	}
}

func TestRecoveryStaleCallbackScopesFailureToItsEndpoint(t *testing.T) {
	cfg := rotationTestConfig()
	transport := &originTransport{cfg: cfg}
	now := time.Now()
	paths, _ := transport.recoveryCandidates(now, "endpoint-a:443")
	old := renewalTestSession(t)
	transport.publishRoute(old, paths[0])
	oldCallback := old.route.Load().onFailure
	newCandidate := paths[0]
	newCandidate.endpoint = "endpoint-b:443"
	current := renewalTestSession(t)
	transport.publishRoute(current, newCandidate)
	oldCallback()
	if !transport.routeQuarantined(paths[0].path, now, "endpoint-a:443") || transport.routeQuarantined(paths[0].path, now, "endpoint-b:443") {
		t.Fatal("old carrier failure was applied to the wrong endpoint")
	}
	if transport.recovery.preferredEndpoint != "endpoint-b:443" || transport.recovery.path != "" {
		t.Fatal("old endpoint failure replaced the newer healthy preference")
	}
	callback := current.route.Load().onFailure
	transport.publishRoute(renewalTestSession(t), newCandidate)
	callback()
	if transport.routeQuarantined(newCandidate.path, time.Now(), newCandidate.endpoint) {
		t.Fatal("stale same-endpoint failure poisoned a newer successful carrier")
	}
}

func TestRecoveryEndpointQuarantineUsesOneGlobalBound(t *testing.T) {
	transport := &originTransport{cfg: rotationTestConfig()}
	now := time.Unix(1800000000, 0)
	for i := 0; i < 200; i++ {
		transport.recordRouteFailure(routeCandidate{path: "/shared-route", endpoint: fmt.Sprintf("endpoint-%d:443", i)}, 0, now)
	}
	if len(transport.recovery.rejected) != recoveryPathRejectedLimit {
		t.Fatal("endpoint scoping multiplied the global rejection bound")
	}
	transport.recoveryCandidates(now.Add(recoveryPathQuarantine), "other-endpoint:443")
	if len(transport.recovery.rejected) != 0 {
		t.Fatal("endpoint-scoped rejection records did not expire")
	}
}
