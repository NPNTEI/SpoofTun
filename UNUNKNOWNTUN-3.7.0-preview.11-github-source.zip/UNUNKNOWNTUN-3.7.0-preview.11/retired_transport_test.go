package main

import (
	"bytes"
	"net"
	"os"
	"strings"
	"testing"
	"time"
)

func TestRemovedTransportNamesAreOnlyWSSAliases(t *testing.T) {
	for _, mode := range []string{TransportH2, TransportAuto, " H2 "} {
		cfg := &Config{Transport: mode, H2Listen: "127.0.0.1:9999", H2Path: "/old-grpc", PadRatio: 1}
		current, err := currentRuntimeConfig(cfg)
		if err != nil {
			t.Fatal(err)
		}
		if current.Transport != TransportWSS || current.H2Listen != "" || current.H2Path != "" || current.PadRatio != 0 {
			t.Fatalf("legacy runtime settings survived: %+v", current)
		}
		if cfg.Transport != mode || cfg.PadRatio != 1 {
			t.Fatal("normalizing a configuration modified the caller's shared object")
		}
	}
	if _, err := currentTransport("grpc"); err == nil {
		t.Fatal("accepted unsupported transport")
	}
}

func TestLegacyGRPCCarrierCodeWasRemoved(t *testing.T) {
	// These checks supplement the real WSS alias integration cases: retired
	// code must not remain dormant and accidentally become reachable later.
	source, err := os.ReadFile("main.go")
	if err != nil {
		t.Fatal(err)
	}
	for _, forbidden := range []string{"type h2StreamConn", "func clientH2(", "func serveH2Tunnel(", "application/grpc", "Grpc-Status", "type padRNG", "paddingLocked(", "fillPaddingLocked("} {
		if bytes.Contains(source, []byte(forbidden)) {
			t.Errorf("removed runtime implementation still present: %s", forbidden)
		}
	}
}

type unpaddedRecordingConn struct {
	discardBenchConn
	data bytes.Buffer
}

func (c *unpaddedRecordingConn) Write(p []byte) (int, error) { return c.data.Write(p) }

func TestOutgoingFramesNeverEmitLegacyPadding(t *testing.T) {
	for _, oldSetting := range []float64{0, 0.22, 1} {
		conn := &unpaddedRecordingConn{}
		sess := newSession(nil, "origin", oldSetting, nil)
		sess.conn = conn
		batch := []frameRequest{
			{h: dataHeader(1, 0), payload: []byte("payload")},
			{h: ctrlHeader(CmdPing, 0, 0), payload: make([]byte, 8)},
		}
		batch[0].h.PadLen = MaxPadding // Caller metadata may not re-enable padding.
		if err := sess.rawWriteBatch(batch); err != nil {
			t.Fatal(err)
		}
		wire := conn.data.Bytes()
		if len(wire) != 2*HeaderSize+15 {
			t.Fatalf("legacy setting %v added bytes: %d", oldSetting, len(wire))
		}
		for _, frame := range batch {
			h, err := DecodeHeader(wire[:HeaderSize])
			if err != nil {
				t.Fatal(err)
			}
			if h.PadLen != 0 || int(h.Length) != len(frame.payload) {
				t.Fatalf("unexpected padding/header: %+v", h)
			}
			if !bytes.Equal(wire[HeaderSize:HeaderSize+int(h.Length)], frame.payload) {
				t.Fatal("payload changed")
			}
			wire = wire[HeaderSize+int(h.Length):]
		}
		sess.Close()
	}
}

func TestOldPeerPaddingRemainsDecodable(t *testing.T) {
	baselineStreams, baselineMemory := activeStreams.Load(), memoryBudget.Load()
	origin, peer := net.Pipe()
	sess := newSession(origin, "origin", 0, nil)
	sess.markAuthenticated()
	st := newStream(1, sess)
	st.state.Store(StateOpen)
	if err := sess.registerStream(st.id, st); err != nil {
		t.Fatal(err)
	}
	readDone := make(chan struct{})
	go func() { defer close(readDone); sess.readLoop() }()
	t.Cleanup(func() {
		peer.Close()
		sess.Close()
		awaitDone(t, readDone)
		waitForStreamBaseline(t, baselineStreams, baselineMemory)
	})
	payload := []byte("old peer payload")
	h := dataHeader(st.id, 0)
	h.Length, h.PadLen = uint32(len(payload)), 23
	wire := make([]byte, HeaderSize+len(payload)+int(h.PadLen))
	h.encodeTo(wire)
	copy(wire[HeaderSize:], payload)
	copy(wire[HeaderSize+len(payload):], strings.Repeat("P", int(h.PadLen)))
	if _, err := writeFull(peer, wire); err != nil {
		t.Fatal(err)
	}
	result := make(chan []byte, 1)
	go func() {
		chunk, _, ok := st.rbuf.Pop()
		if !ok {
			result <- nil
			return
		}
		data := bytes.Clone(chunk.data)
		chunk.release()
		result <- data
	}()
	select {
	case got := <-result:
		if !bytes.Equal(got, payload) {
			t.Fatalf("padding leaked into payload: %q", got)
		}
	case <-time.After(2 * time.Second):
		t.Fatal("old padded frame did not decode")
	}
	if sess.bytesIn.Load() != uint64(len(wire)) {
		t.Fatal("incoming legacy padding was not included in traffic accounting")
	}
}
