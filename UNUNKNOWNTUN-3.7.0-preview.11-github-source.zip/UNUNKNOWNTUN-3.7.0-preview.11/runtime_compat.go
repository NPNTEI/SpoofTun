package main

import (
	"fmt"
	"log"
	"strings"
)

// H2 and auto are launch-script aliases only. No gRPC transport remains in
// this runtime; a former H2-only deployment needs both ends reconfigured.
func currentTransport(value string) (string, error) {
	switch strings.ToLower(strings.TrimSpace(value)) {
	case "", TransportWSS:
		return TransportWSS, nil
	case TransportTLS:
		return TransportTLS, nil
	case TransportXHTTP:
		return TransportXHTTP, nil
	case TransportH2, TransportAuto:
		log.Printf("[config/deprecated] transport %q now selects WSS; H2/gRPC was removed. H2-only setups require both peers and reverse-proxy routes to be upgraded", value)
		return TransportWSS, nil
	default:
		return "", fmt.Errorf("[config] transport must be wss, xhttp, or tls; got %q", value)
	}
}

func currentRuntimeConfig(cfg *Config) (*Config, error) {
	if cfg == nil {
		return nil, fmt.Errorf("[config] missing tunnel configuration")
	}
	copy := *cfg
	var err error
	copy.Transport, err = currentTransport(copy.Transport)
	if err != nil {
		return nil, err
	}
	if copy.PadRatio != 0 {
		log.Print("[config/deprecated] legacy -pad ratio is ignored; use -padding-bytes for explicit WSS/XHTTP padding")
	}
	copy.PadRatio = 0
	copy.H2Listen, copy.H2Path = "", ""
	if err := validateRotationConfig(&copy); err != nil {
		return nil, err
	}
	padding, err := parseBytePadding(copy.PaddingBytes)
	if err != nil {
		return nil, err
	}
	if copy.Transport == TransportTLS && padding.max != 0 {
		return nil, fmt.Errorf("[padding/config] byte padding is available for WSS/XHTTP only")
	}
	if _, err := normalizeXHTTPMode(copy.XHTTPMode); err != nil {
		return nil, err
	}
	if _, err := parseXHTTPPadding(copy.XHTTPPaddingBytes); err != nil {
		return nil, err
	}
	if copy.GRE != nil {
		greCopy := *copy.GRE
		copy.GRE = &greCopy
		if err := validateGREForTunnel(copy.GRE, &copy); err != nil {
			return nil, err
		}
	}
	return &copy, nil
}
