package main

import (
	"log"
	"time"
)

const (
	sessionRenewalPoll           = time.Second
	sessionRenewalPause          = 5 * time.Second
	sessionRenewalRetry          = 30 * time.Second
	sessionRenewalDegradedMinAge = 30 * time.Second
	// An installed replacement gives the old carrier this long to finish
	// streams and peer completion acknowledgements before it is closed. This
	// bounds both retained resources and delay of subsequent slot/route renewal.
	sessionRenewalDrainGrace = 2 * time.Minute
	// Selection leases normally last only through OpenStream registration. A
	// stuck lease may delay this candidate, but must not monopolize the spare.
	sessionRenewalLeaseWait = 30 * time.Second
)

// sessionRenewalState belongs to one supervisor. There is at most one spare
// carrier: either a ready replacement waiting for a selection lease, or the
// replaced carrier draining existing streams. A draining carrier has a bounded
// grace period; a pending candidate has a bounded selection-lease wait. Neither
// can block all subsequent renewals indefinitely. Internal stream IDs never
// change in place.
type sessionRenewalState struct {
	index              int
	old                *Session
	pending            *Session
	pendingConnectedAt time.Time
	pendingDeadline    time.Time
	draining           *Session
	drainDeadline      time.Time
	nextAttempt        time.Time
	nextIndex          int
	hasAttempted       bool
	// Only slot indices are stored, so this map is bounded by the pool size.
	leaseRetryAfter map[int]time.Time
}

func (s *Session) noteStreamPeerCompletion(id uint64) {
	s.smu.Lock()
	delete(s.drainPending, id)
	s.smu.Unlock()
}

// Both sides may send FIN before the egress finishes writing buffered uploads
// to a slow target. CmdClose is its existing completion acknowledgement. This
// predicate is also used by ordinary adaptive scale-down so both retirement
// paths preserve those final writes.
func (s *Session) renewalDrainReady() bool {
	s.smu.RLock()
	defer s.smu.RUnlock()
	return len(s.streams) == 0 && len(s.drainPending) == 0 && !s.drainUnsafe
}

func (p *SessionPool) renewalStopped() bool {
	select {
	case <-p.done:
		return true
	default:
		return false
	}
}

func (p *SessionPool) startRenewal(interval time.Duration) {
	if interval <= 0 {
		return
	}
	p.renewalOnce.Do(func() {
		go func() {
			state := &sessionRenewalState{}
			defer state.closePending()
			ticker := time.NewTicker(sessionRenewalPoll)
			defer ticker.Stop()
			for {
				select {
				case <-p.done:
					// Existing streams, including a draining carrier, belong to
					// the registry's graceful-shutdown budget, not this supervisor.
					return
				case <-ticker.C:
					// A slow dial may leave an older tick buffered. Route epochs
					// and grace deadlines must use the time actually observed.
					p.renewalStep(time.Now(), interval, state)
				}
			}
		}()
	})
}

func (state *sessionRenewalState) closePending() {
	if state.pending != nil {
		state.pending.Close()
	}
	state.pending, state.old = nil, nil
	state.pendingConnectedAt, state.pendingDeadline = time.Time{}, time.Time{}
}

// renewalStep is deliberately serial: a failed/slow authenticated dial cannot
// start another replacement. The production dial already has TCP, TLS and
// authentication deadlines and observes the origin shutdown context.
func (p *SessionPool) renewalStep(now time.Time, interval time.Duration, state *sessionRenewalState) {
	if p.renewalStopped() || interval <= 0 {
		state.closePending()
		return
	}
	if state.draining != nil {
		ready := state.draining.Closed() || state.draining.renewalDrainReady()
		if !ready && now.Before(state.drainDeadline) {
			return
		}
		state.draining.Close()
		state.draining = nil
		state.drainDeadline = time.Time{}
		if ready {
			log.Printf("[origin] renewed carrier finished draining; next renewal may proceed")
		} else {
			log.Printf("[origin] renewed carrier drain grace expired after %s; previous carrier closed so renewal may continue", sessionRenewalDrainGrace)
		}
	}
	if state.pending != nil {
		p.installRenewedCarrier(now, state)
		return
	}
	if now.Before(state.nextAttempt) {
		return
	}

	startIndex := -1
	if state.hasAttempted {
		startIndex = state.nextIndex
	}
	index, old, reason := p.renewalCandidateWithRetry(now, interval, state.leaseRetryAfter, startIndex)
	if old == nil {
		return
	}
	// Start with the oldest carrier, then give every eligible slot a turn.
	// A cooldown alone cannot ensure fairness when several leases remain held
	// longer than the cooldown, or route boundaries repeatedly expire candidates.
	state.nextIndex, state.hasAttempted = (index+1)%len(p.slots), true
	state.nextAttempt = now.Add(sessionRenewalRetry)
	dialStarted := time.Now()
	replacement, err := p.dial()
	// Keep the step's clock consistent for deterministic supervision tests,
	// while still noticing a route boundary crossed by a slow real dial.
	now = now.Add(time.Since(dialStarted))
	if err != nil || replacement == nil || replacement.Closed() || !replacement.authenticated.Load() {
		state.nextAttempt = now.Add(sessionRenewalRetry)
		if replacement != nil {
			replacement.Close()
		}
		log.Printf("[origin] carrier renewal deferred: replacement was not authenticated and ready; existing carrier retained")
		return
	}
	if p.renewalStopped() {
		replacement.Close()
		return
	}
	state.index, state.old, state.pending = index, old, replacement
	state.pendingConnectedAt = now
	state.pendingDeadline = now.Add(sessionRenewalLeaseWait)
	log.Printf("[origin] authenticated replacement ready for carrier %d/%d (%s)", index+1, len(p.slots), reason)
	p.installRenewedCarrier(now, state)
}

func (p *SessionPool) renewalCandidate(now time.Time, interval time.Duration) (int, *Session, string) {
	return p.renewalCandidateWithRetry(now, interval, nil, -1)
}

func (p *SessionPool) renewalCandidateWithRetry(now time.Time, interval time.Duration, retryAfter map[int]time.Time, startIndex int) (int, *Session, string) {
	p.scaleMu.Lock()
	defer p.scaleMu.Unlock()
	n := int(p.desired.Load())
	if n > len(p.slots) {
		n = len(p.slots)
	}
	index := -1
	var oldest *Session
	var oldestTime time.Time
	reason := "scheduled lifetime"
	for offset := 0; offset < n; offset++ {
		i := offset
		if startIndex >= 0 {
			i = (startIndex + offset) % n
		}
		if now.Before(retryAfter[i]) {
			continue
		}
		slot := p.slots[i]
		slot.mu.Lock()
		sess, connectedAt := slot.sess, slot.connectedAt
		eligible := !slot.retired && !slot.dialing && sess != nil && !sess.Closed() && !connectedAt.IsZero()
		slot.mu.Unlock()
		if !eligible {
			continue
		}
		age := now.Sub(connectedAt)
		// The receive-window health flag also represents local RAM pressure.
		// Creating an extra carrier cannot repair that condition and would add
		// memory precisely when the process is protecting itself from OOM.
		degraded := sess.windowDegraded.Load() && sess.streamCount() > 0 && age >= sessionRenewalDegradedMinAge
		if degraded && sess.memoryUsage != nil && sess.memoryUsage() > MemoryHighPercent {
			degraded = false
		}
		staleRoute := p.renewalRouteStale(sess, connectedAt, now)
		if age < interval && !degraded && !staleRoute {
			continue
		}
		if oldest == nil || connectedAt.Before(oldestTime) {
			index, oldest, oldestTime = i, sess, connectedAt
			reason = "scheduled lifetime"
			if staleRoute {
				reason = "route epoch advanced"
			} else if degraded {
				reason = "sustained active-carrier degradation"
			}
		}
		if startIndex >= 0 {
			return index, oldest, reason
		}
	}
	return index, oldest, reason
}

// The actual authenticated route takes precedence over connection age: during
// overlap a newly connected carrier may still be using the previous epoch.
// Legacy transports and tests without route metadata use their connection time.
func (p *SessionPool) renewalRouteStale(sess *Session, connectedAt, now time.Time) bool {
	if p.pathRotation <= 0 {
		return false
	}
	epoch, known := sess.routeEpoch()
	if !known {
		epoch = connectedAt.UnixNano() / int64(p.pathRotation)
	}
	return epoch < now.UnixNano()/int64(p.pathRotation)
}

func (p *SessionPool) installRenewedCarrier(now time.Time, state *sessionRenewalState) {
	p.scaleMu.Lock()
	defer p.scaleMu.Unlock()
	if state.pending == nil {
		return
	}
	if p.renewalStopped() || state.index < 0 || state.index >= int(p.desired.Load()) || state.index >= len(p.slots) || state.pending.Closed() {
		state.closePending()
		return
	}
	if p.renewalRouteStale(state.pending, state.pendingConnectedAt, now) {
		state.closePending()
		state.nextAttempt = now.Add(sessionRenewalRetry)
		log.Printf("[origin] carrier renewal deferred: candidate route epoch expired before installation; existing carrier retained")
		return
	}
	if !now.Before(state.pendingDeadline) {
		if state.leaseRetryAfter == nil {
			state.leaseRetryAfter = make(map[int]time.Time)
		}
		state.leaseRetryAfter[state.index] = now.Add(sessionRenewalRetry)
		state.closePending()
		state.nextAttempt = now.Add(sessionRenewalPause)
		log.Printf("[origin] carrier renewal deferred: selection lease wait exceeded %s; existing carrier retained and other slots may renew", sessionRenewalLeaseWait)
		return
	}
	slot := p.slots[state.index]
	slot.mu.Lock()
	if slot.retired || slot.dialing || slot.sess != state.old || state.old.Closed() {
		slot.mu.Unlock()
		state.closePending()
		return
	}
	if slot.leases != 0 {
		// acquire()/release() protects OpenStream registration. Swapping before
		// its lease ended could close an apparently idle old session too early.
		slot.mu.Unlock()
		return
	}
	slot.sess = state.pending
	slot.connectedAt = state.pendingConnectedAt
	slot.nextAttempt = time.Time{}
	slot.failures = 0
	slot.mu.Unlock()
	state.draining = state.old
	state.drainDeadline = now.Add(sessionRenewalDrainGrace)
	state.pending, state.old = nil, nil
	state.pendingConnectedAt, state.pendingDeadline = time.Time{}, time.Time{}
	delete(state.leaseRetryAfter, state.index)
	state.nextAttempt = now.Add(sessionRenewalPause)
	log.Printf("[origin] new streams now use renewed carrier %d/%d; existing streams drain on the previous carrier", state.index+1, len(p.slots))
}
