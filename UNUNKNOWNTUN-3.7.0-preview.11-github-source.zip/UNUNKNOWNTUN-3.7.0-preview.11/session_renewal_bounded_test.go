package main

import (
	"context"
	"testing"
	"time"
)

func renewalTestLongStream(t *testing.T, sess *Session) *Stream {
	t.Helper()
	stream := newStream(sess.allocID(), sess)
	if err := sess.registerStream(stream.id, stream); err != nil {
		t.Fatal(err)
	}
	return stream
}

func TestCarrierRenewalBoundedDrainAcrossSuccessiveEpochs(t *testing.T) {
	now := time.Unix(1800000000, 0).Truncate(time.Minute).Add(time.Second)
	old := renewalTestSession(t)
	renewalTestLongStream(t, old)
	carriers := []*Session{old}
	var calls int
	p := renewalTestPool(nil, old, func() (*Session, error) {
		calls++
		s := renewalTestSession(t)
		carriers = append(carriers, s)
		alive := 0
		for _, carrier := range carriers {
			if !carrier.Closed() {
				alive++
			}
		}
		if alive > 2 {
			t.Fatalf("renewal exceeded one slot plus one spare: %d live carriers", alive)
		}
		return s, nil
	})
	p.pathRotation = time.Minute
	p.slots[0].connectedAt = now.Add(-2 * time.Second)
	state := &sessionRenewalState{}
	for epoch := 0; epoch < 5; epoch++ {
		previous := p.slots[0].current()
		p.renewalStep(now, 10*time.Minute, state)
		current := p.slots[0].current()
		if calls != epoch+1 || current == previous || state.draining != previous || previous.Closed() {
			t.Fatalf("epoch %d did not install a live replacement before draining", epoch)
		}
		renewalTestLongStream(t, current)
		p.renewalStep(state.drainDeadline.Add(-time.Nanosecond), 10*time.Minute, state)
		if calls != epoch+1 || previous.Closed() {
			t.Fatalf("epoch %d did not preserve the full drain grace", epoch)
		}
		now = state.drainDeadline
	}
	// Close the final drain at its exact deadline without starting a new dial.
	state.nextAttempt = now.Add(time.Hour)
	lastDrain := state.draining
	p.renewalStep(now, 10*time.Minute, state)
	if !lastDrain.Closed() || state.draining != nil || p.slots[0].current() == nil {
		t.Fatal("bounded retirement failed to retain the installed current carrier")
	}
}

func TestCarrierRenewalBoundedDrainIncludesUnacknowledgedCompletion(t *testing.T) {
	for _, unsafe := range []bool{false, true} {
		t.Run(map[bool]string{false: "missing-peer-completion", true: "tracking-overflow"}[unsafe], func(t *testing.T) {
			old, next := renewalTestSession(t), renewalTestSession(t)
			if unsafe {
				old.drainUnsafe = true
			} else {
				stream := renewalTestLongStream(t, old)
				stream.Close()
				old.removeStream(stream.id)
			}
			p := renewalTestPool(nil, old, func() (*Session, error) { return next, nil })
			state := &sessionRenewalState{}
			p.renewalStep(time.Now(), time.Hour, state)
			deadline := state.drainDeadline
			state.nextAttempt = deadline.Add(time.Hour)
			p.renewalStep(deadline.Add(-time.Nanosecond), time.Hour, state)
			if old.Closed() {
				t.Fatal("unacknowledged completion did not receive full drain grace")
			}
			p.renewalStep(deadline, time.Hour, state)
			if !old.Closed() || state.draining != nil || next.Closed() {
				t.Fatal("unacknowledged completion blocked renewal beyond its grace")
			}
		})
	}
}

func TestCarrierRenewalBoundedDrainLetsOtherSlotsRenew(t *testing.T) {
	now := time.Unix(1800000000, 0)
	first, second := renewalTestSession(t), renewalTestSession(t)
	renewalTestLongStream(t, first)
	renewalTestLongStream(t, second)
	carriers := []*Session{first, second}
	p := renewalTestPool(nil, first, func() (*Session, error) {
		s := renewalTestSession(t)
		carriers = append(carriers, s)
		alive := 0
		for _, carrier := range carriers {
			if !carrier.Closed() {
				alive++
			}
		}
		if alive > 3 {
			t.Fatalf("renewal exceeded two slots plus one spare: %d", alive)
		}
		return s, nil
	})
	p.slots[0].connectedAt = now.Add(-2 * time.Hour)
	p.slots = append(p.slots, &sessionSlot{sess: second, connectedAt: now.Add(-time.Hour)})
	p.desired.Store(2)
	state := &sessionRenewalState{}
	p.renewalStep(now, time.Minute, state)
	firstReplacement := p.slots[0].current()
	if firstReplacement == first || state.draining != first {
		t.Fatal("oldest slot did not renew first")
	}
	p.renewalStep(state.drainDeadline, time.Minute, state)
	if !first.Closed() || firstReplacement.Closed() || p.slots[0].current() != firstReplacement {
		t.Fatal("drain expiry closed the wrong carrier")
	}
	if p.slots[1].current() == second || state.draining != second || second.Closed() {
		t.Fatal("long stream in first slot prevented second slot from renewing")
	}
}

func TestCarrierRenewalFailedCandidateNeverStartsDrainDeadline(t *testing.T) {
	for _, rejectedAuth := range []bool{false, true} {
		t.Run(map[bool]string{false: "dial-deadline", true: "rejected-auth"}[rejectedAuth], func(t *testing.T) {
			old := renewalTestSession(t)
			renewalTestLongStream(t, old)
			var candidates []*Session
			p := renewalTestPool(nil, old, func() (*Session, error) {
				if !rejectedAuth {
					return nil, context.DeadlineExceeded
				}
				s := newSession(nil, "origin", 0, nil)
				t.Cleanup(s.Close)
				candidates = append(candidates, s)
				return s, nil
			})
			state := &sessionRenewalState{}
			now := time.Now()
			for attempt := 0; attempt < 5; attempt++ {
				p.renewalStep(now, time.Minute, state)
				if old.Closed() || p.slots[0].current() != old || state.draining != nil || !state.drainDeadline.IsZero() {
					t.Fatal("failed candidate started retirement of the only healthy current carrier")
				}
				for _, candidate := range candidates {
					if !candidate.Closed() {
						t.Fatal("rejected authentication leaked a spare")
					}
				}
				now = now.Add(2 * sessionRenewalDrainGrace)
			}
		})
	}
}

func TestCarrierRenewalStaleLeaseYieldsToOtherSlots(t *testing.T) {
	now := time.Unix(1800000000, 0)
	old, other := renewalTestSession(t), renewalTestSession(t)
	var candidates []*Session
	p := renewalTestPool(nil, old, func() (*Session, error) {
		s := renewalTestSession(t)
		candidates = append(candidates, s)
		return s, nil
	})
	p.slots[0].connectedAt = now.Add(-2 * time.Hour)
	p.slots = append(p.slots, &sessionSlot{sess: other, connectedAt: now.Add(-time.Hour)})
	p.desired.Store(2)
	_, release := p.slots[0].acquire()
	defer release()
	state := &sessionRenewalState{}
	p.renewalStep(now, time.Minute, state)
	if state.pending == nil || state.draining != nil {
		t.Fatal("fixture did not hold an authenticated candidate behind a lease")
	}
	deadline := state.pendingDeadline
	p.renewalStep(deadline.Add(-time.Nanosecond), time.Minute, state)
	if candidates[0].Closed() || old.Closed() {
		t.Fatal("candidate or old carrier closed before lease wait deadline")
	}
	p.renewalStep(deadline, time.Minute, state)
	if !candidates[0].Closed() || old.Closed() || state.pending != nil {
		t.Fatal("stuck lease did not discard only its candidate at deadline")
	}
	p.renewalStep(state.nextAttempt, time.Minute, state)
	if len(candidates) != 2 || p.slots[1].current() != candidates[1] || p.slots[0].current() != old {
		t.Fatal("stuck oldest slot prevented another slot from renewing")
	}
	if state.draining != other {
		t.Fatal("wrong slot entered draining after blocked-slot cooldown")
	}
	release()
	// The abandoned candidate cannot reappear after the stale lease releases.
	now = deadline.Add(sessionRenewalRetry)
	p.renewalStep(now, time.Minute, state)
	if len(candidates) != 3 || p.slots[0].current() != candidates[2] || !candidates[0].Closed() {
		t.Fatal("released slot did not retry with a fresh candidate")
	}
}

func TestCarrierRenewalPendingCandidateCannotCrossRouteEpoch(t *testing.T) {
	boundary := time.Unix(1800000000, 0).Truncate(time.Minute)
	now := boundary.Add(-time.Second)
	old, replacement := renewalTestSession(t), renewalTestSession(t)
	p := renewalTestPool(nil, old, func() (*Session, error) { return replacement, nil })
	p.pathRotation = time.Minute
	p.slots[0].connectedAt = now.Add(-time.Hour)
	_, release := p.slots[0].acquire()
	state := &sessionRenewalState{}
	p.renewalStep(now, time.Minute, state)
	if state.pending != replacement {
		t.Fatal("fixture failed to create a pending candidate")
	}
	release()
	p.renewalStep(boundary, time.Minute, state)
	if !replacement.Closed() || old.Closed() || p.slots[0].current() != old || state.pending != nil || state.draining != nil {
		t.Fatal("expired pending route replaced a healthy current carrier")
	}
}

func TestCarrierRenewalMultipleStaleLeasesCannotStarveLaterSlot(t *testing.T) {
	now := time.Unix(1800000000, 0)
	old := []*Session{renewalTestSession(t), renewalTestSession(t), renewalTestSession(t)}
	var candidates []*Session
	p := renewalTestPool(nil, old[0], func() (*Session, error) {
		s := renewalTestSession(t)
		candidates = append(candidates, s)
		return s, nil
	})
	p.slots[0].connectedAt = now.Add(-3 * time.Hour)
	for i := 1; i < len(old); i++ {
		p.slots = append(p.slots, &sessionSlot{sess: old[i], connectedAt: now.Add(-time.Duration(3-i) * time.Hour)})
	}
	p.desired.Store(3)
	for i := 0; i < 2; i++ {
		_, release := p.slots[i].acquire()
		defer release()
	}
	state := &sessionRenewalState{}
	for i := 0; i < 2; i++ {
		p.renewalStep(now, time.Minute, state)
		if state.index != i || state.pending == nil {
			t.Fatalf("attempt %d did not select the next eligible slot", i)
		}
		p.renewalStep(state.pendingDeadline, time.Minute, state)
		if !candidates[i].Closed() || old[i].Closed() {
			t.Fatal("expired selection lease did not preserve its current carrier")
		}
		now = state.nextAttempt
	}
	// Slot 0's cooldown has elapsed by now. Fair ordering must still let the
	// third slot proceed instead of alternating forever between blocked slots.
	p.renewalStep(now, time.Minute, state)
	if len(candidates) != 3 || state.index != 2 || p.slots[2].current() != candidates[2] || state.draining != old[2] {
		t.Fatal("multiple stale leases starved a later healthy slot")
	}
}

func TestCarrierRenewalEpochAndLeaseExpiryYieldToAnotherSlot(t *testing.T) {
	boundary := time.Unix(1800000000, 0).Truncate(time.Minute)
	now := boundary.Add(-sessionRenewalLeaseWait)
	old, other := renewalTestSession(t), renewalTestSession(t)
	var candidates []*Session
	p := renewalTestPool(nil, old, func() (*Session, error) {
		s := renewalTestSession(t)
		candidates = append(candidates, s)
		return s, nil
	})
	p.pathRotation = time.Minute
	p.slots[0].connectedAt = now.Add(-2 * time.Hour)
	p.slots = append(p.slots, &sessionSlot{sess: other, connectedAt: now.Add(-time.Hour)})
	p.desired.Store(2)
	_, release := p.slots[0].acquire()
	defer release()
	state := &sessionRenewalState{}
	p.renewalStep(now, time.Minute, state)
	p.renewalStep(state.pendingDeadline, time.Minute, state)
	if !candidates[0].Closed() || old.Closed() {
		t.Fatal("simultaneous epoch/lease expiry failed to discard only the candidate")
	}
	p.renewalStep(state.nextAttempt, time.Minute, state)
	if len(candidates) != 2 || p.slots[1].current() != candidates[1] || p.slots[0].current() != old {
		t.Fatal("epoch expiration caused the held oldest slot to starve another slot")
	}
}

func TestCarrierRenewalRouteBoundaryPrecedesLifetime(t *testing.T) {
	boundary := time.Unix(1800000000, 0).Truncate(time.Minute)
	old := renewalTestSession(t)
	p := renewalTestPool(nil, old, nil)
	p.pathRotation = time.Minute
	p.slots[0].connectedAt = boundary.Add(-time.Second)
	if _, candidate, _ := p.renewalCandidate(boundary.Add(-time.Nanosecond), time.Hour); candidate != nil {
		t.Fatal("carrier renewed before its route epoch ended")
	}
	if _, candidate, reason := p.renewalCandidate(boundary, time.Hour); candidate != old || reason != "route epoch advanced" {
		t.Fatal("route boundary waited for connection lifetime instead of renewing")
	}
}

func TestCarrierRenewalActualRouteEpochOverridesConnectionTime(t *testing.T) {
	boundary := time.Unix(1800000000, 0).Truncate(time.Minute)
	currentEpoch := boundary.UnixNano() / int64(time.Minute)
	for _, offset := range []int64{-1, 0, 1} {
		t.Run(map[int64]string{-1: "previous-route-new-connection", 0: "current-route-old-connection", 1: "future-route-in-overlap"}[offset], func(t *testing.T) {
			old := renewalTestSession(t)
			old.setRouteEpoch(currentEpoch + offset)
			p := renewalTestPool(nil, old, nil)
			p.pathRotation = time.Minute
			now := boundary.Add(time.Second)
			p.slots[0].connectedAt = now
			if offset >= 0 {
				p.slots[0].connectedAt = boundary.Add(-time.Second)
			}
			_, candidate, reason := p.renewalCandidate(now, time.Hour)
			if offset < 0 {
				if candidate != old || reason != "route epoch advanced" {
					t.Fatal("new connection on a previous overlap route was considered current")
				}
			} else if candidate != nil {
				t.Fatal("connection age epoch overrode the actual current/future route")
			}
		})
	}
}

func TestCarrierRenewalRejectsNewCandidateUsingPreviousOverlapRoute(t *testing.T) {
	now := time.Unix(1800000000, 0).Truncate(time.Minute).Add(time.Second)
	old, replacement := renewalTestSession(t), renewalTestSession(t)
	replacement.setRouteEpoch(now.UnixNano()/int64(time.Minute) - 1)
	p := renewalTestPool(nil, old, func() (*Session, error) { return replacement, nil })
	p.pathRotation = time.Minute
	p.slots[0].connectedAt = now.Add(-time.Hour)
	state := &sessionRenewalState{}
	p.renewalStep(now, time.Minute, state)
	if !replacement.Closed() || old.Closed() || p.slots[0].current() != old || state.pending != nil || state.draining != nil {
		t.Fatal("newly authenticated previous-epoch overlap route was installed as current")
	}
}

func TestCarrierRenewalPendingFutureRouteSurvivesEpochBoundary(t *testing.T) {
	boundary := time.Unix(1800000000, 0).Truncate(time.Minute)
	old, replacement := renewalTestSession(t), renewalTestSession(t)
	replacement.setRouteEpoch(boundary.UnixNano() / int64(time.Minute))
	p := renewalTestPool(nil, old, func() (*Session, error) { return replacement, nil })
	p.pathRotation = time.Minute
	p.slots[0].connectedAt = boundary.Add(-time.Hour)
	_, release := p.slots[0].acquire()
	state := &sessionRenewalState{}
	p.renewalStep(boundary.Add(-time.Second), time.Minute, state)
	if state.pending != replacement {
		t.Fatal("fixture did not hold a future-epoch overlap candidate")
	}
	release()
	p.renewalStep(boundary, time.Minute, state)
	if replacement.Closed() || old.Closed() || p.slots[0].current() != replacement || state.draining != old {
		t.Fatal("actual current route was rejected because connection time preceded the boundary")
	}
}
