package main

import (
	"testing"
	"time"
)

func TestCarrierRenewalShrinkReactivateDuringDial(t *testing.T) {
	for _, busy := range []bool{false, true} {
		t.Run(map[bool]string{false: "idle-old-is-closed", true: "busy-old-stays-draining"}[busy], func(t *testing.T) {
			done := make(chan struct{})
			defer close(done)
			old, spare, first := renewalTestSession(t), renewalTestSession(t), renewalTestSession(t)
			if busy {
				stream := newStream(1, old)
				if err := old.registerStream(1, stream); err != nil {
					t.Fatal(err)
				}
			}
			started, releaseDial, finished := make(chan struct{}), make(chan struct{}), make(chan struct{})
			p := renewalTestPool(done, first, func() (*Session, error) {
				close(started)
				<-releaseDial
				return spare, nil
			})
			p.slots[0].connectedAt = time.Now()
			p.slots = append(p.slots, &sessionSlot{sess: old, connectedAt: time.Now().Add(-time.Hour), reconnectCh: make(chan struct{}, 1)})
			p.desired.Store(2)
			state := &sessionRenewalState{}
			go func() { defer close(finished); p.renewalStep(time.Now(), time.Minute, state) }()
			awaitDone(t, started)
			if !p.retireOne() || p.desired.Load() != 1 {
				t.Fatal("concurrent shrink failed")
			}
			if !p.activateNext("stress reactivation") || p.desired.Load() != 2 {
				t.Fatal("concurrent reactivation failed")
			}
			close(releaseDial)
			awaitDone(t, finished)
			if busy {
				if old.Closed() || spare.Closed() || state.draining != old || p.slots[1].current() != spare {
					t.Fatal("reactivation broke a live stream or lost its replacement")
				}
			} else if !old.Closed() || !spare.Closed() || state.draining != nil || p.slots[1].current() != nil {
				t.Fatal("stale dial resurrected a closed, retired carrier")
			}
		})
	}
}

func TestCarrierRenewalDoesNotAmplifyMemoryPressure(t *testing.T) {
	old := renewalTestSession(t)
	stream := newStream(1, old)
	if err := old.registerStream(1, stream); err != nil {
		t.Fatal(err)
	}
	old.windowDegraded.Store(true)
	old.memoryUsage = func() float64 { return MemoryHighPercent + 1 }
	p := renewalTestPool(nil, old, nil)
	now := time.Now()
	p.slots[0].connectedAt = now.Add(-time.Minute)
	if _, candidate, _ := p.renewalCandidate(now, time.Hour); candidate != nil {
		t.Fatal("local RAM pressure triggered an additional early carrier")
	}
	old.memoryUsage = func() float64 { return 0 }
	if _, candidate, _ := p.renewalCandidate(now, time.Hour); candidate != old {
		t.Fatal("active network degradation no longer renews early")
	}
	old.memoryUsage = func() float64 { return MemoryHighPercent + 1 }
	if _, candidate, _ := p.renewalCandidate(now.Add(2*time.Hour), time.Hour); candidate != old {
		t.Fatal("explicit lifetime renewal was disabled by health guard")
	}
}
