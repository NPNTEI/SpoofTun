package main

import (
	"bytes"
	"context"
	"errors"
	"io"
	"net"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func renewalTestSession(t *testing.T) *Session {
	t.Helper()
	s := newSession(nil, "origin", 0, nil)
	s.markAuthenticated()
	t.Cleanup(s.Close)
	return s
}

func renewalTestPool(done <-chan struct{}, old *Session, dial func() (*Session, error)) *SessionPool {
	p := &SessionPool{min: 1, done: done, dial: dial, slots: []*sessionSlot{{
		sess: old, connectedAt: time.Now().Add(-time.Hour), reconnectCh: make(chan struct{}, 1),
	}}}
	p.desired.Store(1)
	return p
}

func TestCarrierRenewalReplacesBeforeDraining(t *testing.T) {
	old, replacement := renewalTestSession(t), renewalTestSession(t)
	stream := newStream(old.allocID(), old)
	if err := old.registerStream(stream.id, stream); err != nil {
		t.Fatal(err)
	}
	var calls int
	p := renewalTestPool(nil, old, func() (*Session, error) {
		calls++
		if old.Closed() || old.getStream(stream.id) != stream {
			t.Fatal("old stream changed before replacement authenticated")
		}
		return replacement, nil
	})
	state := &sessionRenewalState{}
	now := time.Now()
	p.renewalStep(now, time.Minute, state)
	if p.slots[0].current() != replacement || old.Closed() || state.draining != old {
		t.Fatal("make-before-break replacement did not preserve old stream")
	}
	selected, release, err := p.Get()
	if err != nil || selected != replacement {
		t.Fatalf("new streams select %p, %v; want replacement", selected, err)
	}
	release()
	if stream.id != 1 || old.nextID.Load() != 3 || replacement.nextID.Load() != 1 {
		t.Fatal("renewal mutated a live stream ID or reused its carrier")
	}
	p.renewalStep(now.Add(30*time.Second), time.Minute, state)
	if calls != 1 || old.Closed() {
		t.Fatal("another renewal started before the old live stream drained")
	}
	stream.Close()
	old.removeStream(stream.id)
	p.renewalStep(now.Add(40*time.Second), time.Minute, state)
	if old.Closed() {
		t.Fatal("local completion was mistaken for remote target-write completion")
	}
	old.handleFrame(ctrlHeader(CmdClose, stream.id, 0), nil)
	state.nextAttempt = now.Add(time.Hour)
	p.renewalStep(now.Add(50*time.Second), time.Minute, state)
	if !old.Closed() || state.draining != nil || replacement.Closed() {
		t.Fatal("old carrier was not retired after both sides drained")
	}
}

func TestCarrierRenewalWaitsForOpenStreamLease(t *testing.T) {
	old, replacement := renewalTestSession(t), renewalTestSession(t)
	p := renewalTestPool(nil, old, func() (*Session, error) { return replacement, nil })
	leased, release := p.slots[0].acquire()
	if leased != old {
		t.Fatal("missing initial lease")
	}
	state := &sessionRenewalState{}
	p.renewalStep(time.Now(), time.Minute, state)
	if state.pending != replacement || p.slots[0].current() != old || old.Closed() {
		t.Fatal("renewal swapped the session while OpenStream held a lease")
	}
	stream := newStream(1, old)
	if err := old.registerStream(1, stream); err != nil {
		t.Fatal(err)
	}
	release()
	p.renewalStep(time.Now(), time.Minute, state)
	if state.pending != nil || state.draining != old || p.slots[0].current() != replacement || old.Closed() {
		t.Fatal("lease release did not safely publish the new session")
	}
}

func TestCarrierRenewalFailureKeepsOldAndBacksOff(t *testing.T) {
	for _, failure := range []string{"dial", "nil", "unauthenticated", "closed"} {
		t.Run(failure, func(t *testing.T) {
			old := renewalTestSession(t)
			var candidate *Session
			var calls int
			p := renewalTestPool(nil, old, func() (*Session, error) {
				calls++
				switch failure {
				case "dial":
					return nil, errors.New("fixture dial failure")
				case "nil":
					return nil, nil
				case "unauthenticated":
					candidate = newSession(nil, "origin", 0, nil)
				default:
					candidate = renewalTestSession(t)
					candidate.Close()
				}
				return candidate, nil
			})
			state := &sessionRenewalState{}
			now := time.Now()
			p.renewalStep(now, time.Minute, state)
			p.renewalStep(now.Add(time.Second), time.Minute, state)
			if calls != 1 || old.Closed() || p.slots[0].current() != old || state.pending != nil || state.draining != nil {
				t.Fatal("failed renewal disrupted old session or retried without backoff")
			}
			if candidate != nil && !candidate.Closed() {
				t.Fatal("unusable replacement leaked")
			}
		})
	}
}

func TestCarrierRenewalDiscardsReplacementAfterRetirement(t *testing.T) {
	old, replacement := renewalTestSession(t), renewalTestSession(t)
	p := renewalTestPool(nil, old, nil)
	p.dial = func() (*Session, error) {
		p.slots[0].mu.Lock()
		p.slots[0].retired = true
		p.slots[0].mu.Unlock()
		return replacement, nil
	}
	state := &sessionRenewalState{}
	p.renewalStep(time.Now(), time.Minute, state)
	if !replacement.Closed() || old.Closed() || p.slots[0].current() != old {
		t.Fatal("stale renewal overwrote retired slot")
	}
}

func TestCarrierRenewalShutdownDiscardsPendingButPreservesDrain(t *testing.T) {
	for _, pending := range []bool{false, true} {
		t.Run(map[bool]string{false: "draining", true: "pending"}[pending], func(t *testing.T) {
			done := make(chan struct{})
			old, replacement := renewalTestSession(t), renewalTestSession(t)
			p := renewalTestPool(done, old, func() (*Session, error) { return replacement, nil })
			var release func()
			if pending {
				_, release = p.slots[0].acquire()
				defer release()
			}
			state := &sessionRenewalState{}
			p.renewalStep(time.Now(), time.Minute, state)
			close(done)
			p.renewalStep(time.Now(), time.Minute, state)
			if old.Closed() {
				t.Fatal("supervisor bypassed registry shutdown drain")
			}
			if replacement.Closed() != pending {
				t.Fatal("wrong replacement lifetime on shutdown")
			}
		})
	}
}

func TestCarrierRenewalShutdownDuringDial(t *testing.T) {
	done := make(chan struct{})
	old, replacement := renewalTestSession(t), renewalTestSession(t)
	p := renewalTestPool(done, old, func() (*Session, error) {
		close(done)
		return replacement, nil
	})
	p.renewalStep(time.Now(), time.Minute, &sessionRenewalState{})
	if old.Closed() || !replacement.Closed() || p.slots[0].current() != old {
		t.Fatal("late authenticated replacement was installed after shutdown")
	}
}

func TestCarrierRenewalHealthAndAgeSelection(t *testing.T) {
	old := renewalTestSession(t)
	p := renewalTestPool(nil, old, nil)
	now := time.Now()
	p.slots[0].connectedAt = now.Add(-sessionRenewalDegradedMinAge)
	old.windowDegraded.Store(true)
	if _, candidate, _ := p.renewalCandidate(now, time.Hour); candidate != nil {
		t.Fatal("idle degradation must not create carrier churn")
	}
	st := newStream(1, old)
	if err := old.registerStream(1, st); err != nil {
		t.Fatal(err)
	}
	if _, candidate, reason := p.renewalCandidate(now, time.Hour); candidate != old || reason != "sustained active-carrier degradation" {
		t.Fatal("sustained active degradation did not permit early replacement")
	}
	p.slots[0].connectedAt = now.Add(-time.Second)
	if _, candidate, _ := p.renewalCandidate(now, time.Hour); candidate != nil {
		t.Fatal("new carrier was renewed immediately for a transient health sample")
	}
}

func TestCarrierRenewalBoundedCompletionTracking(t *testing.T) {
	s := renewalTestSession(t)
	for id := uint64(1); id <= maxTombstones+1; id++ {
		st := newStream(id, s)
		if err := s.registerStream(id, st); err != nil {
			t.Fatal(err)
		}
		st.Close()
		s.removeStream(id)
	}
	if len(s.drainPending) != maxTombstones || !s.drainUnsafe || s.renewalDrainReady() {
		t.Fatal("unacknowledged completions were unbounded or unsafe to retire")
	}
	for id := uint64(1); id <= maxTombstones; id++ {
		s.noteStreamPeerCompletion(id)
	}
	if len(s.drainPending) != 0 || s.renewalDrainReady() {
		t.Fatal("overflow must conservatively retain the untracked carrier")
	}
}

func TestAdaptiveRetirementWaitsForPeerCompletion(t *testing.T) {
	s := renewalTestSession(t)
	st := newStream(1, s)
	if err := s.registerStream(1, st); err != nil {
		t.Fatal(err)
	}
	st.Close()
	s.removeStream(1)
	slot := &sessionSlot{sess: s, retired: true}
	if slot.retireIfIdle() || s.Closed() {
		t.Fatal("scale-down closed an upload awaiting peer completion")
	}
	s.handleFrame(ctrlHeader(CmdClose, 1, 0), nil)
	if !slot.retireIfIdle() || !s.Closed() {
		t.Fatal("scale-down did not retire a fully completed carrier")
	}
}

func TestCarrierRenewalConcurrentSelection(t *testing.T) {
	old, replacement := renewalTestSession(t), renewalTestSession(t)
	p := renewalTestPool(nil, old, func() (*Session, error) { return replacement, nil })
	var wg sync.WaitGroup
	var selected atomic.Int32
	for i := 0; i < 8; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for n := 0; n < 500; n++ {
				s, release, err := p.Get()
				if err == nil && s != nil {
					selected.Add(1)
					release()
				}
			}
		}()
	}
	state := &sessionRenewalState{}
	p.renewalStep(time.Now(), time.Minute, state)
	wg.Wait()
	p.renewalStep(time.Now(), time.Minute, state)
	if selected.Load() != 4000 || p.slots[0].current() != replacement {
		t.Fatal("concurrent selectors lost availability across replacement")
	}
}

// Two real loopback WSS/TLS/authenticated carriers carry independent clients.
// The old TCP stream must keep delivering payload after new selections switch
// to the replacement. This is a local correctness check, not a WAN benchmark.
func TestCarrierRenewalWSSPayloadContinuity(t *testing.T) {
	baselineStreams, baselineMemory := activeStreams.Load(), memoryBudget.Load()
	t.Cleanup(func() { waitForStreamBaseline(t, baselineStreams, baselineMemory) })
	old, oldTarget := localTestTunnel(t, TransportWSS)
	replacement, newTarget := localTestTunnel(t, TransportWSS)
	p := renewalTestPool(nil, old, func() (*Session, error) { return replacement, nil })
	openClient := func(target string) *net.TCPConn {
		t.Helper()
		client, edge := tcpTestPair(t)
		_ = edge.SetDeadline(time.Time{})
		_ = client.SetDeadline(time.Now().Add(10 * time.Second))
		s, release, err := p.Get()
		if err != nil {
			t.Fatal(err)
		}
		err = s.OpenStream(target, edge)
		release()
		if err != nil {
			t.Fatal(err)
		}
		return client
	}
	assertEcho := func(client *net.TCPConn, marker string) {
		t.Helper()
		payload := bytes.Repeat([]byte(marker), 8192)
		if _, err := writeFull(client, payload); err != nil {
			t.Fatal(err)
		}
		reply := make([]byte, len(payload))
		if _, err := io.ReadFull(client, reply); err != nil {
			t.Fatal(err)
		}
		if !bytes.Equal(payload, reply) {
			t.Fatal("payload changed across carrier renewal")
		}
	}
	oldClient := openClient(oldTarget)
	assertEcho(oldClient, "before-renewal-")
	state := &sessionRenewalState{}
	p.renewalStep(time.Now(), time.Minute, state)
	if state.draining != old || old.Closed() || p.slots[0].current() != replacement {
		t.Fatal("WSS replacement did not preserve the original client")
	}
	newClient := openClient(newTarget)
	assertEcho(oldClient, "old-carrier-still-delivers-")
	assertEcho(newClient, "new-carrier-delivers-")
	if err := oldClient.CloseWrite(); err != nil {
		t.Fatal(err)
	}
	if tail, err := io.ReadAll(oldClient); err != nil || len(tail) != 0 {
		t.Fatalf("old client completion: tail=%d error=%v", len(tail), err)
	}
	deadline := time.Now().Add(3 * time.Second)
	for !old.renewalDrainReady() && time.Now().Before(deadline) {
		time.Sleep(time.Millisecond)
	}
	state.nextAttempt = time.Now().Add(time.Hour)
	p.renewalStep(time.Now(), time.Minute, state)
	if !old.Closed() || state.draining != nil {
		t.Fatal("completed WSS carrier did not drain after peer acknowledgement")
	}
	assertEcho(newClient, "after-old-deletion-")
	_ = newClient.CloseWrite()
	if _, err := io.ReadAll(newClient); err != nil {
		t.Fatal(err)
	}
}

type renewalSlowTarget struct {
	discardNetConn
	release chan struct{}
	closed  chan struct{}
	started chan struct{}
	once    sync.Once
	start   sync.Once
	mu      sync.Mutex
	data    []byte
}

func (c *renewalSlowTarget) Write(payload []byte) (int, error) {
	c.start.Do(func() { close(c.started) })
	select {
	case <-c.release:
	case <-c.closed:
		return 0, net.ErrClosed
	}
	c.mu.Lock()
	c.data = append(c.data, payload...)
	c.mu.Unlock()
	return len(payload), nil
}

func (c *renewalSlowTarget) Close() error {
	c.once.Do(func() { close(c.closed) })
	return nil
}

func (c *renewalSlowTarget) CloseWrite() error { return nil }

// The target half-closes its response immediately, then blocks upload writes.
// Both local FINs can complete while the remote upload remains buffered. A
// stream-count-only retirement would truncate this exact case.
func TestCarrierRenewalPreservesSlowTargetUpload(t *testing.T) {
	baselineStreams, baselineMemory := activeStreams.Load(), memoryBudget.Load()
	t.Cleanup(func() { waitForStreamBaseline(t, baselineStreams, baselineMemory) })
	target := &renewalSlowTarget{release: make(chan struct{}), closed: make(chan struct{}), started: make(chan struct{})}
	t.Cleanup(func() { _ = target.Close() })
	allow, err := ParseAllowList("127.0.0.1:12345")
	if err != nil {
		t.Fatal(err)
	}
	originWire, egressWire := net.Pipe()
	old := newSession(originWire, "origin", 0, nil)
	egress := newSession(egressWire, "egress", 0, allow)
	old.markAuthenticated()
	egress.markAuthenticated()
	egress.dialContext = func(context.Context, string, string) (net.Conn, error) { return target, nil }
	t.Cleanup(old.Close)
	t.Cleanup(egress.Close)
	go old.readLoop()
	go egress.readLoop()
	client, edge := tcpTestPair(t)
	_ = edge.SetDeadline(time.Time{})
	_ = client.SetDeadline(time.Now().Add(5 * time.Second))
	if err := old.OpenStream("127.0.0.1:12345", edge); err != nil {
		t.Fatal(err)
	}
	payload := bytes.Repeat([]byte("slow-target-upload-"), 4096)
	if _, err := writeFull(client, payload); err != nil {
		t.Fatal(err)
	}
	_ = client.CloseWrite()
	if _, err := io.ReadAll(client); err != nil {
		t.Fatal(err)
	}
	awaitDone(t, target.started)
	deadline := time.Now().Add(2 * time.Second)
	for old.streamCount() != 0 && time.Now().Before(deadline) {
		time.Sleep(time.Millisecond)
	}
	if old.streamCount() != 0 || old.renewalDrainReady() {
		t.Fatal("fixture did not reach locally-finished, remotely-buffered upload")
	}
	replacement := renewalTestSession(t)
	p := renewalTestPool(nil, old, func() (*Session, error) { return replacement, nil })
	state := &sessionRenewalState{}
	p.renewalStep(time.Now(), time.Minute, state)
	p.renewalStep(time.Now(), time.Minute, state)
	if old.Closed() || state.draining != old {
		t.Fatal("renewal truncated upload before target accepted it")
	}
	close(target.release)
	deadline = time.Now().Add(2 * time.Second)
	for !old.renewalDrainReady() && time.Now().Before(deadline) {
		time.Sleep(time.Millisecond)
	}
	p.renewalStep(time.Now(), time.Minute, state)
	if !old.Closed() || state.draining != nil {
		t.Fatal("renewal did not retire the old carrier after remote target drain")
	}
	target.mu.Lock()
	got := append([]byte(nil), target.data...)
	target.mu.Unlock()
	if !bytes.Equal(got, payload) {
		t.Fatalf("slow upload truncated: got %d, want %d bytes", len(got), len(payload))
	}
}
