package main

// Independent, minimal RFC 2784 IPv4/GRE underlay. This is not linked to,
// derived from source of, or claimed interoperable with Backhaul Premium.
// GRE is NOT authenticated: exact packet filters narrow exposure, while the
// unchanged UNUNKNOWNTUN TLS certificate verification + token protect the carrier.

import (
	"bytes"
	"context"
	"encoding/binary"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/netip"
	"regexp"
	"strconv"
	"time"
)

const greIPv4Overhead = 24

type GREConfig struct {
	Interface            string `json:"interface"`
	TUNName              string `json:"tun_name"`
	LocalIP              string `json:"local_ip"`
	PeerIP               string `json:"peer_ip"`
	SourceIP             string `json:"source_ip"`
	ExpectedPeerSourceIP string `json:"expected_peer_source_ip"`
	InnerLocalIP         string `json:"inner_local_ip"`
	InnerPeerIP          string `json:"inner_peer_ip"`
	MTU                  int    `json:"mtu"`
	CarrierPort          int    `json:"carrier_port"`
	Authorized           bool   `json:"authorized"`
	// Derived from the UNUNKNOWNTUN role, never trusted from a JSON file.
	Role string `json:"-"`
}

type GREStats struct {
	Sent, Received, Rejected, Dropped                       uint64
	TxRejected, RxRejected, RxIdentityMismatch, RxTruncated uint64
}

// ErrGREIdentityMismatch identifies a well-formed outer IPv4 header whose
// source or destination does not match the configured receive identity.
// It does not identify which host or network changed or supplied the packet.
var ErrGREIdentityMismatch = errors.New("outer source/destination does not match configured receive identity")

type greUnderlay interface {
	Close() error
	Errors() <-chan error
	Stats() GREStats
}

var greInterfaceName = regexp.MustCompile(`^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,14}$`)

func greUnicastIPv4(value string) (netip.Addr, error) {
	a, err := netip.ParseAddr(value)
	if err != nil || !a.Is4() || a.String() != value || !a.IsGlobalUnicast() || a.IsLoopback() {
		return netip.Addr{}, errors.New("must be a literal unicast IPv4 address (not hostname, range, loopback or multicast)")
	}
	b := a.As4()
	if b[0] == 0 || b[0] >= 240 {
		return netip.Addr{}, errors.New("reserved IPv4 source/destination range is not supported")
	}
	return a, nil
}

func (c *GREConfig) validate() error {
	if c == nil {
		return errors.New("[spoof/config] missing GRE configuration")
	}
	if !c.Authorized {
		return errors.New("[spoof/config] authorized must be true only for endpoints and source addresses you are permitted to use")
	}
	if c.Role != "origin" && c.Role != "egress" {
		return errors.New("[spoof/config] role must be origin or egress")
	}
	if !greInterfaceName.MatchString(c.Interface) || c.Interface == "lo" || !greInterfaceName.MatchString(c.TUNName) || c.TUNName == "lo" || c.Interface == c.TUNName {
		return errors.New("[spoof/config] distinct physical interface and TUN names required (1..15 safe characters, not lo)")
	}
	if c.MTU < 576 || c.MTU > 1400 {
		return errors.New("[spoof/config] mtu must be 576..1400; outer IPv4/GRE adds 24 bytes")
	}
	if c.CarrierPort < 1024 || c.CarrierPort > 65535 {
		return errors.New("[spoof/config] carrier_port must be 1024..65535")
	}
	addresses := map[string]string{"local_ip": c.LocalIP, "peer_ip": c.PeerIP, "source_ip": c.SourceIP, "expected_peer_source_ip": c.ExpectedPeerSourceIP, "inner_local_ip": c.InnerLocalIP, "inner_peer_ip": c.InnerPeerIP}
	for field, value := range addresses {
		if _, err := greUnicastIPv4(value); err != nil {
			return fmt.Errorf("[spoof/config] %s: %w", field, err)
		}
	}
	local, _ := netip.ParseAddr(c.InnerLocalIP)
	peer, _ := netip.ParseAddr(c.InnerPeerIP)
	if !local.IsPrivate() || !peer.IsPrivate() || local == peer {
		return errors.New("[spoof/config] inner addresses must be two distinct private RFC1918 IPv4 addresses")
	}
	if c.LocalIP == c.PeerIP {
		return errors.New("[spoof/config] outer local_ip and peer_ip must differ")
	}
	for _, outer := range []string{c.LocalIP, c.PeerIP, c.SourceIP, c.ExpectedPeerSourceIP} {
		if outer == c.InnerLocalIP || outer == c.InnerPeerIP {
			return errors.New("[spoof/config] inner addresses must not equal any outer address")
		}
	}
	return nil
}

// Strict bounded JSON: no duplicate/unknown fields, extra documents or symlinks.
// The file contains no tokens, but must remain private to avoid accidental edits.
func loadGREConfig(path, role string) (*GREConfig, error) {
	f, err := openPrivateGREConfig(path)
	if err != nil {
		return nil, fmt.Errorf("[spoof/config/file] %w", err)
	}
	defer f.Close()
	data, err := io.ReadAll(io.LimitReader(f, 16385))
	if err != nil || len(data) > 16384 {
		return nil, errors.New("[spoof/config/file] unreadable or oversized file")
	}
	return parseGREConfig(data, role)
}

func parseGREConfig(data []byte, role string) (*GREConfig, error) {
	if len(data) > 16384 {
		return nil, errors.New("[spoof/config] JSON exceeds 16 KiB")
	}
	d := json.NewDecoder(bytes.NewReader(data))
	t, err := d.Token()
	if err != nil || t != json.Delim('{') {
		return nil, errors.New("[spoof/config] expected JSON object")
	}
	seen := make(map[string]bool)
	for d.More() {
		keyToken, err := d.Token()
		if err != nil {
			return nil, fmt.Errorf("[spoof/config] invalid JSON key: %w", err)
		}
		key, ok := keyToken.(string)
		if !ok || seen[key] {
			return nil, errors.New("[spoof/config] duplicate or invalid JSON field")
		}
		seen[key] = true
		var v json.RawMessage
		if err := d.Decode(&v); err != nil {
			return nil, fmt.Errorf("[spoof/config] invalid JSON value: %w", err)
		}
		if bytes.Equal(bytes.TrimSpace(v), []byte("null")) {
			return nil, errors.New("[spoof/config] null values are not accepted")
		}
	}
	if _, err := d.Token(); err != nil {
		return nil, fmt.Errorf("[spoof/config] unterminated JSON: %w", err)
	}
	if _, err := d.Token(); err != io.EOF {
		return nil, errors.New("[spoof/config] unexpected trailing JSON")
	}
	// Exact lowercase spelling also rules out encoding/json's case-insensitive
	// aliases being used to bypass duplicate-key checks.
	allowed := map[string]bool{"interface": true, "tun_name": true, "local_ip": true, "peer_ip": true, "source_ip": true, "expected_peer_source_ip": true, "inner_local_ip": true, "inner_peer_ip": true, "mtu": true, "carrier_port": true, "authorized": true}
	for key := range seen {
		if !allowed[key] {
			return nil, fmt.Errorf("[spoof/config] unknown field %q", key)
		}
	}
	var c GREConfig
	if err := json.Unmarshal(data, &c); err != nil {
		return nil, fmt.Errorf("[spoof/config] %w", err)
	}
	c.Role = role
	if err := c.validate(); err != nil {
		return nil, err
	}
	return &c, nil
}

func validateGREForTunnel(c *GREConfig, cfg *Config) error {
	if c == nil {
		return nil
	}
	if err := c.validate(); err != nil {
		return err
	}
	if cfg == nil || cfg.Mode != c.Role {
		return errors.New("[spoof/config] tunnel role mismatch")
	}
	if cfg.Transport != TransportTLS {
		return errors.New("[spoof/unsupported] this preview supports direct TLS only; ordinary HTTP CDN/WSS/XHTTP routes cannot carry raw GRE. Use spoof OFF for existing proxy modes")
	}
	if cfg.ECHMode != "" && cfg.ECHMode != ECHModeOff {
		return errors.New("[spoof/unsupported] ECH is not available on direct TLS")
	}
	if cfg.TLSFragment != "" && cfg.TLSFragment != "off" {
		return errors.New("[spoof/unsupported] TLS ClientHello fragmentation is not implemented on this direct-TLS path")
	}
	endpoint, address := cfg.Listen, c.InnerLocalIP
	if c.Role == "origin" {
		endpoint, address = cfg.Connect, c.InnerPeerIP
	}
	want := net.JoinHostPort(address, strconv.Itoa(c.CarrierPort))
	if endpoint != want {
		return fmt.Errorf("[spoof/config] %s endpoint must be exactly %s; no DNS/CDN/fallback endpoints are permitted", c.Role, want)
	}
	return nil
}

func greChecksum(p []byte) uint16 {
	var sum uint32
	for len(p) >= 2 {
		sum += uint32(binary.BigEndian.Uint16(p))
		p = p[2:]
	}
	if len(p) == 1 {
		sum += uint32(p[0]) << 8
	}
	for sum>>16 != 0 {
		sum = (sum & 0xffff) + (sum >> 16)
	}
	return ^uint16(sum)
}

func greIPv4Header(packet []byte, protocol byte, maxLen int) error {
	if len(packet) < 20 || len(packet) > maxLen || packet[0] != 0x45 {
		return errors.New("invalid IPv4 length/version or unsupported IP options")
	}
	if int(binary.BigEndian.Uint16(packet[2:4])) != len(packet) {
		return errors.New("IPv4 total length mismatch")
	}
	if binary.BigEndian.Uint16(packet[6:8]) & ^uint16(0x4000) != 0 {
		return errors.New("IP fragments/reserved flags are not supported")
	}
	if packet[8] == 0 || packet[9] != protocol || greChecksum(packet[:20]) != 0 {
		return errors.New("IPv4 TTL/protocol/header checksum invalid")
	}
	return nil
}

func greSameIP(raw []byte, address string) bool {
	ip, err := netip.ParseAddr(address)
	if err != nil || !ip.Is4() || len(raw) != 4 {
		return false
	}
	a := ip.As4()
	return bytes.Equal(raw, a[:])
}

func validateGREInner(c *GREConfig, packet []byte, receiving bool) error {
	if err := greIPv4Header(packet, 6, c.MTU); err != nil {
		return err
	}
	if len(packet) < 40 {
		return errors.New("short TCP packet")
	}
	src, dst := c.InnerLocalIP, c.InnerPeerIP
	originToEgress := c.Role == "origin"
	if receiving {
		src, dst = dst, src
		originToEgress = !originToEgress
	}
	if !greSameIP(packet[12:16], src) || !greSameIP(packet[16:20], dst) {
		return errors.New("inner source/destination outside exact tunnel pair")
	}
	tcp := packet[20:]
	headerLen := int(tcp[12]>>4) * 4
	if headerLen < 20 || headerLen > len(tcp) || binary.BigEndian.Uint16(tcp[:2]) == 0 || binary.BigEndian.Uint16(tcp[2:4]) == 0 {
		return errors.New("invalid TCP header/port")
	}
	port := binary.BigEndian.Uint16(tcp[:2])
	if originToEgress {
		port = binary.BigEndian.Uint16(tcp[2:4])
	}
	if int(port) != c.CarrierPort {
		return errors.New("TCP packet is not for configured UNUNKNOWNTUN carrier port")
	}
	// Verify pseudo-header + complete TCP payload before host-stack injection.
	pseudo := make([]byte, 12+len(tcp))
	copy(pseudo[:8], packet[12:20])
	pseudo[9] = 6
	binary.BigEndian.PutUint16(pseudo[10:12], uint16(len(tcp)))
	copy(pseudo[12:], tcp)
	if greChecksum(pseudo) != 0 {
		return errors.New("TCP checksum invalid")
	}
	return nil
}

func encodeGREPacket(c *GREConfig, inner []byte, id uint16) ([]byte, error) {
	if err := c.validate(); err != nil {
		return nil, err
	}
	if err := validateGREInner(c, inner, false); err != nil {
		return nil, fmt.Errorf("[spoof/tx/filter] %w", err)
	}
	p := make([]byte, greIPv4Overhead+len(inner))
	p[0] = 0x45
	binary.BigEndian.PutUint16(p[2:4], uint16(len(p)))
	binary.BigEndian.PutUint16(p[4:6], id)
	binary.BigEndian.PutUint16(p[6:8], 0x4000)
	p[8] = 64
	p[9] = 47
	src, _ := netip.ParseAddr(c.SourceIP)
	dst, _ := netip.ParseAddr(c.PeerIP)
	sa, da := src.As4(), dst.As4()
	copy(p[12:16], sa[:])
	copy(p[16:20], da[:])
	binary.BigEndian.PutUint16(p[10:12], greChecksum(p[:20]))
	p[22] = 8 // flags/version=0, protocol type=IPv4 0x0800.
	copy(p[24:], inner)
	return p, nil
}

func decodeGREPacket(c *GREConfig, packet []byte) ([]byte, error) {
	if err := c.validate(); err != nil {
		return nil, err
	}
	if err := greIPv4Header(packet, 47, c.MTU+greIPv4Overhead); err != nil {
		return nil, fmt.Errorf("[spoof/rx/filter] %w", err)
	}
	if len(packet) < 64 {
		return nil, errors.New("[spoof/rx/filter] short GRE payload")
	}
	if !greSameIP(packet[12:16], c.ExpectedPeerSourceIP) || !greSameIP(packet[16:20], c.LocalIP) {
		return nil, fmt.Errorf("[spoof/rx/filter] %w", ErrGREIdentityMismatch)
	}
	if !bytes.Equal(packet[20:24], []byte{0, 0, 8, 0}) {
		return nil, errors.New("[spoof/rx/filter] only basic GRE version 0 / IPv4 is supported")
	}
	inner := packet[24:]
	if err := validateGREInner(c, inner, true); err != nil {
		return nil, fmt.Errorf("[spoof/rx/filter] %w", err)
	}
	return inner, nil
}

// An explicit bounded native-GRE check. Unlike -check-tunnel it intentionally
// creates a temporary owned underlay. The peer must already be running its
// UNUNKNOWNTUN GRE egress; failure never proves a provider/DPI is responsible.
func checkGREContext(ctx context.Context, cfg *Config, timeout time.Duration) (GREStats, error) {
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	return checkGREWith(ctx, cfg, timeout, func(c *GREConfig) (greUnderlay, error) {
		return startGREUnderlayContext(ctx, c)
	}, checkTunnelContext)
}

func checkGREWith(ctx context.Context, cfg *Config, timeout time.Duration,
	start func(*GREConfig) (greUnderlay, error),
	probe func(context.Context, *Config, time.Duration) (string, string, error)) (GREStats, error) {
	if cfg == nil || cfg.Mode != "origin" || cfg.GRE == nil {
		return GREStats{}, errors.New("[spoof/check/config] requires origin mode and spoof configuration")
	}
	if timeout <= 0 || timeout > 60*time.Second {
		return GREStats{}, errors.New("[spoof/check/config] deadline must be greater than zero and at most 60s")
	}
	if err := validateGREForTunnel(cfg.GRE, cfg); err != nil {
		return GREStats{}, err
	}
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	if err := ctx.Err(); err != nil {
		return GREStats{}, err
	}
	u, err := start(cfg.GRE)
	if err != nil {
		return GREStats{}, err
	}
	defer u.Close()
	// The real probe honors its context; preserve a concurrent underlay failure
	// even if the probe returns just as the watcher is asked to stop.
	watchDone := make(chan struct{})
	watchStopped := make(chan struct{})
	watchFailure := make(chan error, 1)
	go func() {
		defer close(watchStopped)
		select {
		case failure, ok := <-u.Errors():
			if !ok || failure == nil {
				failure = errors.New("underlay error stream stopped without a diagnostic")
			}
			watchFailure <- failure
			cancel()
		case <-watchDone:
		case <-ctx.Done():
		}
	}()
	_, _, err = probe(ctx, cfg, timeout)
	close(watchDone)
	<-watchStopped
	var underlayErr error
	select {
	case underlayErr = <-watchFailure:
	default:
	}
	// Before our own Close, a closed stream or nil event is unexpected. After
	// Close a stream may close normally, so do not lose this distinction.
	select {
	case failure, ok := <-u.Errors():
		if !ok || failure == nil {
			failure = errors.New("underlay error stream stopped without a diagnostic")
		}
		underlayErr = errors.Join(underlayErr, failure)
	default:
	}
	closeErr := u.Close()
	s := u.Stats()
	select {
	case failure, ok := <-u.Errors():
		if ok {
			if failure == nil {
				failure = errors.New("underlay emitted an empty error event")
			}
			underlayErr = errors.Join(underlayErr, failure)
		}
	default:
	}
	if underlayErr != nil {
		return s, fmt.Errorf("[spoof/check/underlay] %w", errors.Join(underlayErr, closeErr))
	}
	if err != nil {
		return s, fmt.Errorf("[spoof/check/inconclusive] no authenticated GRE carrier: %w; check both endpoint configs, GRE filtering, routing, rp_filter and MTU; do not infer a DPI cause from timeout. %s", errors.Join(err, closeErr), GREReceiveDiagnosticHint)
	}
	if closeErr != nil {
		return s, fmt.Errorf("[spoof/check/cleanup] %w", closeErr)
	}
	if ctx.Err() != nil {
		return s, fmt.Errorf("[spoof/check/inconclusive] %w", ctx.Err())
	}
	if s.Sent == 0 || s.Received == 0 {
		return s, errors.New("[spoof/check/inconclusive] authenticated carrier but no bidirectional GRE counters; refusing path success")
	}
	return s, nil
}
