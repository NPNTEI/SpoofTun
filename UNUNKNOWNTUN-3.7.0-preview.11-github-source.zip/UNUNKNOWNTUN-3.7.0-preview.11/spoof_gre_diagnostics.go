package main

import (
	"errors"
	"fmt"
	"sync"
)

// GREReceiveDiagnosticHint is guidance, not a diagnosis or a request to disable
// filtering. AF_INET delivery happens after some host-kernel policy checks.
const GREReceiveDiagnosticHint = "AF_INET raw receive can lose packets to host firewall or rp_filter before counters; zero received/rejected does not prove provider blocking. Read-only checks: verify the reverse route for expected_peer_source_ip uses the intended interface, and inspect effective rp_filter and firewall policy on both hosts; do not disable protections blindly."

// GREWirePlan describes configuration only, never observed/captured traffic.
// Quoted fields keep even an invalid caller-supplied string on one log line.
// No token, certificate material, or other authentication secret is included.
func GREWirePlan(c *GREConfig) string {
	if c == nil {
		return "configuration_only=true packet_capture=false spoof=off"
	}
	return fmt.Sprintf("configuration_only=true packet_capture=false outer_tx=%q->%q expected_outer_rx=%q->%q inner_tx=%q->%q expected_inner_rx=%q->%q",
		c.SourceIP, c.PeerIP, c.ExpectedPeerSourceIP, c.LocalIP,
		c.InnerLocalIP, c.InnerPeerIP, c.InnerPeerIP, c.InnerLocalIP)
}

// String retains the original aggregate names for existing log consumers.
// Received counts packets successfully injected into the TUN, not raw arrivals.
// Rejected is TxRejected + RxRejected; the last two counters are RX subsets.
func (s GREStats) String() string {
	return fmt.Sprintf("sent=%d received=%d rejected=%d dropped=%d tx_rejected=%d rx_rejected=%d rx_identity_mismatch=%d rx_truncated=%d",
		s.Sent, s.Received, s.Rejected, s.Dropped, s.TxRejected, s.RxRejected,
		s.RxIdentityMismatch, s.RxTruncated)
}

// Rejection accounting is kept separate from packet processing so it can be
// tested without privileges or network I/O. The lock provides coherent aggregate
// and subset snapshots; it is used only for rejection events and stats reads.
type greRejectionCounters struct {
	mu                              sync.Mutex
	tx, rx, rxIdentity, rxTruncated uint64
}

func (c *greRejectionCounters) rejectTX() {
	c.mu.Lock()
	c.tx++
	c.mu.Unlock()
}

func (c *greRejectionCounters) rejectRX(err error, truncated bool) {
	c.mu.Lock()
	c.rx++
	if truncated {
		c.rxTruncated++
	} else if errors.Is(err, ErrGREIdentityMismatch) {
		c.rxIdentity++
	}
	c.mu.Unlock()
}

func (c *greRejectionCounters) snapshot() GREStats {
	c.mu.Lock()
	defer c.mu.Unlock()
	return GREStats{Rejected: c.tx + c.rx, TxRejected: c.tx, RxRejected: c.rx,
		RxIdentityMismatch: c.rxIdentity, RxTruncated: c.rxTruncated}
}
