//go:build !linux && !darwin

package main

import (
	"errors"
	"os"
)

func openPrivateGREConfig(path string) (*os.File, error) {
	return nil, errors.New("[spoof/config/file] secure GRE configuration loading is supported only on Linux and macOS; the native underlay requires Linux")
}
