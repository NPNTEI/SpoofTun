//go:build linux || darwin

package main

import (
	"errors"
	"fmt"
	"os"

	"golang.org/x/sys/unix"
)

// Open the final component without following a symlink, and never block on a
// FIFO/device swapped in before open. Check the actual descriptor before read.
func openPrivateGREConfig(path string) (*os.File, error) {
	fd, err := unix.Open(path, unix.O_RDONLY|unix.O_NONBLOCK|unix.O_NOFOLLOW|unix.O_CLOEXEC, 0)
	if err != nil {
		return nil, fmt.Errorf("[spoof/config/file] secure open: %w", err)
	}
	f := os.NewFile(uintptr(fd), path)
	if f == nil {
		_ = unix.Close(fd)
		return nil, errors.New("[spoof/config/file] could not adopt descriptor")
	}
	var st unix.Stat_t
	if err := unix.Fstat(fd, &st); err != nil {
		_ = f.Close()
		return nil, fmt.Errorf("[spoof/config/file] stat descriptor: %w", err)
	}
	if st.Mode&unix.S_IFMT != unix.S_IFREG || st.Mode&0077 != 0 || st.Uid != uint32(os.Geteuid()) || st.Size > 16384 {
		_ = f.Close()
		return nil, errors.New("[spoof/config/file] require an effective-user-owned regular file, private permissions (chmod 600), and size at most 16 KiB")
	}
	return f, nil
}
