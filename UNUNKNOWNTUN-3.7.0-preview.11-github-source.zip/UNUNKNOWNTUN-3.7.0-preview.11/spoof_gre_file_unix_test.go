//go:build linux || darwin

package main

import (
	"os"
	"path/filepath"
	"testing"
	"time"

	"golang.org/x/sys/unix"
)

func TestGREPrivateConfigOpen(t *testing.T) {
	dir := t.TempDir()
	good := filepath.Join(dir, "config.json")
	if err := os.WriteFile(good, []byte(`{}`), 0600); err != nil {
		t.Fatal(err)
	}
	f, err := openPrivateGREConfig(good)
	if err != nil {
		t.Fatal(err)
	}
	_ = f.Close()
	link := filepath.Join(dir, "link.json")
	if err := os.Symlink(good, link); err != nil {
		t.Fatal(err)
	}
	if f, err := openPrivateGREConfig(link); err == nil {
		f.Close()
		t.Fatal("followed symlink")
	}
	if err := os.Chmod(good, 0644); err != nil {
		t.Fatal(err)
	}
	if f, err := openPrivateGREConfig(good); err == nil {
		f.Close()
		t.Fatal("accepted nonprivate permissions")
	}
	if f, err := openPrivateGREConfig(dir); err == nil {
		f.Close()
		t.Fatal("accepted directory")
	}
	large := filepath.Join(dir, "large.json")
	if err := os.WriteFile(large, make([]byte, 16385), 0600); err != nil {
		t.Fatal(err)
	}
	if f, err := openPrivateGREConfig(large); err == nil {
		f.Close()
		t.Fatal("accepted oversized config")
	}
}

func TestGREPrivateConfigFIFOIsNonblocking(t *testing.T) {
	p := filepath.Join(t.TempDir(), "fifo")
	if err := unix.Mkfifo(p, 0600); err != nil {
		t.Fatal(err)
	}
	started := time.Now()
	if f, err := openPrivateGREConfig(p); err == nil {
		f.Close()
		t.Fatal("accepted FIFO")
	}
	if time.Since(started) > time.Second {
		t.Fatal("FIFO config open blocked")
	}
}
