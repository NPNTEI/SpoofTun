//go:build linux

package main

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"net"
	"net/netip"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"

	"golang.org/x/sys/unix"
)

// This is an owned, ephemeral point-to-point underlay. It never enables host
// forwarding, changes firewall rules, replaces a route, or persists a TUN.
type linuxGREUnderlay struct {
	config                  GREConfig
	tunFD, rawFD            int
	peer                    unix.SockaddrInet4
	stop, finished          chan struct{}
	errors                  chan error
	closeOnce               sync.Once
	closeErr                error
	sent, received, dropped atomic.Uint64
	rejections              greRejectionCounters
}

func startGREUnderlay(c *GREConfig) (greUnderlay, error) {
	return startGREUnderlayContext(context.Background(), c)
}

func startGREUnderlayContext(ctx context.Context, c *GREConfig) (greUnderlay, error) {
	if err := ctx.Err(); err != nil {
		return nil, fmt.Errorf("[gre/setup-cancelled] %w", err)
	}
	if c == nil {
		return nil, errors.New("[gre/config] missing configuration")
	}
	if err := c.validate(); err != nil {
		return nil, err
	}
	if !c.Authorized {
		return nil, errors.New("[gre/authorization] authorized source-address confirmation is required")
	}
	// Fail before opening a privileged socket or changing any network state.
	ipPath, err := greTrustedIPExecutable()
	if err != nil {
		return nil, err
	}
	iface, err := net.InterfaceByName(c.Interface)
	if err != nil {
		return nil, fmt.Errorf("[gre/interface] %w", err)
	}
	if iface.Flags&net.FlagUp == 0 || iface.Flags&(net.FlagLoopback|net.FlagPointToPoint) != 0 {
		return nil, errors.New("[gre/interface] physical interface must be up, non-loopback and not another point-to-point tunnel")
	}
	if c.MTU+24 > iface.MTU {
		return nil, fmt.Errorf("[gre/mtu] inner MTU %d plus 24-byte IPv4/GRE overhead exceeds physical MTU %d", c.MTU, iface.MTU)
	}
	addrs, err := iface.Addrs()
	if err != nil {
		return nil, fmt.Errorf("[gre/interface-addresses] %w", err)
	}
	assigned := false
	for _, a := range addrs {
		prefix, parseErr := netip.ParsePrefix(a.String())
		if parseErr == nil && prefix.Addr().String() == c.LocalIP {
			assigned = true
		}
	}
	if !assigned {
		return nil, errors.New("[gre/interface-addresses] local_ip is not assigned to the physical interface")
	}
	interfaces, err := net.Interfaces()
	if err != nil {
		return nil, fmt.Errorf("[gre/interfaces] %w", err)
	}
	for _, existing := range interfaces {
		if existing.Name == c.TUNName {
			return nil, fmt.Errorf("[gre/interface-conflict] %s already exists; it will not be changed", c.TUNName)
		}
	}
	if c.TUNName == c.Interface {
		return nil, errors.New("[gre/interface-conflict] TUN and physical interface must differ")
	}
	rules, err := greRunIPContext(ctx, ipPath, "-j", "-4", "rule", "show")
	if err != nil {
		return nil, err
	}
	if err := greCheckRules(rules); err != nil {
		return nil, err
	}
	routes, err := greRunIPContext(ctx, ipPath, "-j", "-4", "route", "show", "table", "all")
	if err != nil {
		return nil, err
	}
	if err := greCheckRoutes(routes, c.InnerLocalIP, c.InnerPeerIP); err != nil {
		return nil, err
	}
	outerRoute, err := greRunIPContext(ctx, ipPath, "-j", "-4", "route", "get", c.PeerIP, "from", c.LocalIP)
	if err != nil {
		return nil, err
	}
	if err := greCheckOuterRoute(outerRoute, c); err != nil {
		return nil, err
	}

	u := &linuxGREUnderlay{config: *c, tunFD: -1, rawFD: -1,
		stop: make(chan struct{}), finished: make(chan struct{}), errors: make(chan error, 1)}
	var started bool
	defer func() {
		if !started {
			if u.rawFD >= 0 {
				_ = unix.Close(u.rawFD)
			}
			if u.tunFD >= 0 {
				_ = unix.Close(u.tunFD)
			}
		}
	}()
	if err := ctx.Err(); err != nil {
		return nil, fmt.Errorf("[gre/setup-cancelled] %w", err)
	}
	u.rawFD, err = unix.Socket(unix.AF_INET, unix.SOCK_RAW|unix.SOCK_NONBLOCK|unix.SOCK_CLOEXEC, unix.IPPROTO_GRE)
	if err != nil {
		return nil, fmt.Errorf("[gre/raw-socket] CAP_NET_RAW and provider permission are required: %w", err)
	}
	for _, option := range []struct{ level, name, value int }{
		{unix.IPPROTO_IP, unix.IP_HDRINCL, 1},
		{unix.SOL_SOCKET, unix.SO_RCVBUF, 256 * 1024},
		{unix.SOL_SOCKET, unix.SO_SNDBUF, 256 * 1024},
	} {
		if err := unix.SetsockoptInt(u.rawFD, option.level, option.name, option.value); err != nil {
			return nil, fmt.Errorf("[gre/socket-option] %w", err)
		}
	}
	if err := unix.SetsockoptString(u.rawFD, unix.SOL_SOCKET, unix.SO_BINDTODEVICE, c.Interface); err != nil {
		return nil, fmt.Errorf("[gre/socket-interface] %w", err)
	}
	local := netip.MustParseAddr(c.LocalIP).As4()
	if err := unix.Bind(u.rawFD, &unix.SockaddrInet4{Addr: local}); err != nil {
		return nil, fmt.Errorf("[gre/socket-bind] %w", err)
	}
	u.peer.Addr = netip.MustParseAddr(c.PeerIP).As4()
	if err := ctx.Err(); err != nil {
		return nil, fmt.Errorf("[gre/setup-cancelled] %w", err)
	}
	u.tunFD, err = unix.Open("/dev/net/tun", unix.O_RDWR|unix.O_NONBLOCK|unix.O_CLOEXEC, 0)
	if err != nil {
		return nil, fmt.Errorf("[gre/tun-open] Linux TUN support and CAP_NET_ADMIN are required: %w", err)
	}
	ifr, err := unix.NewIfreq(c.TUNName)
	if err != nil {
		return nil, fmt.Errorf("[gre/tun-name] %w", err)
	}
	ifr.SetUint16(unix.IFF_TUN | unix.IFF_NO_PI | unix.IFF_TUN_EXCL)
	if err := ctx.Err(); err != nil {
		return nil, fmt.Errorf("[gre/setup-cancelled] %w", err)
	}
	if err := unix.IoctlIfreq(u.tunFD, unix.TUNSETIFF, ifr); err != nil {
		return nil, fmt.Errorf("[gre/tun-create] exclusive creation failed; existing interfaces are never adopted: %w", err)
	}
	if ifr.Name() != c.TUNName {
		return nil, errors.New("[gre/tun-create] kernel returned an unexpected interface name")
	}
	// The codec requires complete per-packet TCP checksums, never virtio/GSO
	// metadata or checksum-offload placeholders. This affects only our TUN.
	if err := ctx.Err(); err != nil {
		return nil, fmt.Errorf("[gre/setup-cancelled] %w", err)
	}
	if err := unix.IoctlSetInt(u.tunFD, unix.TUNSETOFFLOAD, 0); err != nil {
		return nil, fmt.Errorf("[gre/tun-offload] could not disable offloads on owned TUN: %w", err)
	}
	// noprefixroute prevents an automatic broad route. Closing the only TUN FD
	// removes its local address and exact peer route, including on setup failure.
	for _, args := range [][]string{
		{"-4", "address", "add", c.InnerLocalIP + "/32", "peer", c.InnerPeerIP + "/32", "dev", c.TUNName, "noprefixroute"},
		{"link", "set", "dev", c.TUNName, "mtu", strconv.Itoa(c.MTU), "up"},
		{"-4", "route", "add", c.InnerPeerIP + "/32", "dev", c.TUNName, "src", c.InnerLocalIP, "scope", "link"},
	} {
		if _, err := greRunIPContext(ctx, ipPath, args...); err != nil {
			return nil, err
		}
	}
	if err := ctx.Err(); err != nil {
		return nil, fmt.Errorf("[gre/setup-cancelled] %w", err)
	}
	started = true
	go u.run()
	return u, nil
}

// Binding only an inner source address does not prevent Linux from rerouting
// an established socket if the TUN route disappears. Bind the socket to the
// owned TUN's device index as well, for both the dialer and TLS listener.
func bindGRESocket(c *GREConfig, raw syscall.RawConn) error {
	if c == nil || raw == nil || !greInterfaceName.MatchString(c.TUNName) || c.TUNName == "lo" {
		return errors.New("[gre/socket-isolation] invalid TUN interface")
	}
	var socketErr error
	err := raw.Control(func(fd uintptr) {
		socketErr = unix.SetsockoptString(int(fd), unix.SOL_SOCKET, unix.SO_BINDTODEVICE, c.TUNName)
	})
	if err != nil {
		return fmt.Errorf("[gre/socket-isolation] socket control: %w", err)
	}
	if socketErr != nil {
		return fmt.Errorf("[gre/socket-isolation] cannot bind socket to owned TUN: %w", socketErr)
	}
	return nil
}

func (u *linuxGREUnderlay) Errors() <-chan error { return u.errors }

func (u *linuxGREUnderlay) Stats() GREStats {
	s := u.rejections.snapshot()
	s.Sent, s.Received, s.Dropped = u.sent.Load(), u.received.Load(), u.dropped.Load()
	return s
}

func (u *linuxGREUnderlay) Close() error {
	u.closeOnce.Do(func() {
		close(u.stop)
		<-u.finished
		// The worker is the only reader/writer. Never close/reuse a descriptor
		// underneath poll or packet processing.
		u.closeErr = errors.Join(unix.Close(u.rawFD), unix.Close(u.tunFD))
	})
	return u.closeErr
}

func (u *linuxGREUnderlay) run() {
	defer close(u.finished)
	fail := func(stage string, err error) {
		select {
		case u.errors <- fmt.Errorf("[gre/%s] %w", stage, err):
		default:
		}
	}
	fds := []unix.PollFd{{Fd: int32(u.tunFD), Events: unix.POLLIN}, {Fd: int32(u.rawFD), Events: unix.POLLIN}}
	innerBuffer := make([]byte, u.config.MTU+1)
	outerBuffer := make([]byte, u.config.MTU+24)
	var id uint16
	for {
		select {
		case <-u.stop:
			return
		default:
		}
		_, err := unix.Poll(fds, 200)
		if errors.Is(err, unix.EINTR) {
			continue
		}
		if err != nil {
			fail("poll", err)
			return
		}
		select {
		case <-u.stop:
			return
		default:
		}
		for _, p := range fds {
			if p.Revents&(unix.POLLERR|unix.POLLHUP|unix.POLLNVAL) != 0 {
				fail("descriptor", fmt.Errorf("network descriptor became unavailable (poll flags=%d)", p.Revents))
				return
			}
		}
		if fds[0].Revents&unix.POLLIN != 0 {
			n, err := unix.Read(u.tunFD, innerBuffer)
			if err != nil && !greWouldBlock(err) {
				fail("tun-read", err)
				return
			}
			if err == nil {
				if n == 0 {
					fail("tun-read", errors.New("unexpected end of TUN stream"))
					return
				}
				if n > u.config.MTU {
					u.rejections.rejectTX()
				} else {
					id++
					packet, encodeErr := encodeGREPacket(&u.config, innerBuffer[:n], id)
					if encodeErr != nil {
						u.rejections.rejectTX()
					} else {
						err = unix.Sendto(u.rawFD, packet, unix.MSG_DONTWAIT, &u.peer)
						if greWouldBlock(err) || errors.Is(err, unix.ENOBUFS) {
							u.dropped.Add(1)
						} else if err != nil {
							fail("raw-send", err)
							return
						} else {
							u.sent.Add(1)
						}
					}
				}
			}
		}
		if fds[1].Revents&unix.POLLIN != 0 {
			n, _, flags, _, err := unix.Recvmsg(u.rawFD, outerBuffer, nil, unix.MSG_DONTWAIT|unix.MSG_TRUNC)
			if err != nil && !greWouldBlock(err) {
				fail("raw-receive", err)
				return
			}
			if err == nil {
				if n > len(outerBuffer) || flags&unix.MSG_TRUNC != 0 {
					u.rejections.rejectRX(nil, true)
					continue
				}
				inner, decodeErr := decodeGREPacket(&u.config, outerBuffer[:n])
				if decodeErr != nil {
					u.rejections.rejectRX(decodeErr, false)
					continue
				}
				written, writeErr := unix.Write(u.tunFD, inner)
				if greWouldBlock(writeErr) || errors.Is(writeErr, unix.ENOBUFS) {
					u.dropped.Add(1)
				} else if writeErr != nil {
					fail("tun-write", writeErr)
					return
				} else if written != len(inner) {
					fail("tun-write", errors.New("short packet write"))
					return
				} else {
					u.received.Add(1)
				}
			}
		}
	}
}

func greWouldBlock(err error) bool {
	return errors.Is(err, unix.EAGAIN) || errors.Is(err, unix.EWOULDBLOCK) || errors.Is(err, unix.EINTR)
}

func greTrustedIPExecutable() (string, error) {
	for _, candidate := range []string{"/usr/sbin/ip", "/sbin/ip", "/usr/bin/ip", "/bin/ip"} {
		resolved, err := filepath.EvalSymlinks(candidate)
		if err != nil {
			continue
		}
		if err := greCheckTrustedPath(resolved); err != nil {
			continue
		}
		return resolved, nil
	}
	return "", errors.New("[gre/iproute2] a root-owned, non-writable-by-others ip executable in /usr/sbin, /sbin, /usr/bin or /bin is required")
}

func greCheckTrustedPath(path string) error {
	if !filepath.IsAbs(path) {
		return errors.New("path must be absolute")
	}
	for current := path; ; current = filepath.Dir(current) {
		info, err := os.Lstat(current)
		if err != nil {
			return err
		}
		stat, ok := info.Sys().(*syscall.Stat_t)
		if !ok || stat.Uid != 0 || info.Mode().Perm()&0022 != 0 || info.Mode()&os.ModeSymlink != 0 {
			return errors.New("path is not root-controlled")
		}
		if current == path && (!info.Mode().IsRegular() || info.Mode().Perm()&0111 == 0) {
			return errors.New("not an executable regular file")
		}
		if current != path && !info.IsDir() {
			return errors.New("parent is not a directory")
		}
		if current == "/" {
			return nil
		}
	}
}

type greBoundedOutput struct {
	bytes.Buffer
	exceeded bool
}

func (b *greBoundedOutput) Write(p []byte) (int, error) {
	const limit = 1024 * 1024
	n := len(p)
	remaining := limit - b.Len()
	if len(p) > remaining {
		p = p[:remaining]
		b.exceeded = true
	}
	_, _ = b.Buffer.Write(p)
	return n, nil
}

func greRunIP(path string, args ...string) ([]byte, error) {
	return greRunIPContext(context.Background(), path, args...)
}

func greRunIPContext(parent context.Context, path string, args ...string) ([]byte, error) {
	if err := parent.Err(); err != nil {
		return nil, fmt.Errorf("[gre/setup-cancelled] %w", err)
	}
	ctx, cancel := context.WithTimeout(parent, 5*time.Second)
	defer cancel()
	cmd := exec.CommandContext(ctx, path, args...)
	cmd.Env = []string{"PATH=/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL=C"}
	var output greBoundedOutput
	cmd.Stdout, cmd.Stderr = &output, &output
	if err := cmd.Run(); err != nil {
		detail := strings.TrimSpace(output.String())
		if len(detail) > 1024 {
			detail = detail[:1024] + " [truncated]"
		}
		return nil, fmt.Errorf("[gre/iproute2] %s: %w (%s)", strings.Join(args, " "), err, detail)
	}
	if output.exceeded {
		return nil, errors.New("[gre/iproute2] output exceeded safety limit")
	}
	return output.Bytes(), nil
}
