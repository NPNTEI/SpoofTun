//go:build linux

package main

import (
	"context"
	"errors"
	"sync"
	"testing"
	"time"

	"golang.org/x/sys/unix"
)

func TestGRELinuxCanceledCommandDoesNotExecute(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	_, err := greRunIPContext(ctx, "/this-must-not-be-executed", "address", "add")
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("expected cancellation before command execution, got %v", err)
	}
}

type greFailedRawControl struct{}

func (greFailedRawControl) Control(func(uintptr)) error    { return unix.EBADF }
func (greFailedRawControl) Read(func(uintptr) bool) error  { return unix.EBADF }
func (greFailedRawControl) Write(func(uintptr) bool) error { return unix.EBADF }

func TestGRELinuxSocketIsolationFailsClosed(t *testing.T) {
	if err := bindGRESocket(&GREConfig{TUNName: "gdt-test"}, greFailedRawControl{}); err == nil {
		t.Fatal("accepted socket isolation failure")
	}
	if err := bindGRESocket(nil, nil); err == nil {
		t.Fatal("accepted missing isolation parameters")
	}
}

// Pipes exercise polling/cancellation without TUN, raw sockets or network I/O.
func TestGRELinuxCloseWaitsAndIsIdempotent(t *testing.T) {
	tunPipe, rawPipe := make([]int, 2), make([]int, 2)
	if err := unix.Pipe2(tunPipe, unix.O_NONBLOCK|unix.O_CLOEXEC); err != nil {
		t.Fatal(err)
	}
	defer unix.Close(tunPipe[1])
	if err := unix.Pipe2(rawPipe, unix.O_NONBLOCK|unix.O_CLOEXEC); err != nil {
		unix.Close(tunPipe[0])
		t.Fatal(err)
	}
	defer unix.Close(rawPipe[1])
	u := &linuxGREUnderlay{config: GREConfig{MTU: 1320}, tunFD: tunPipe[0], rawFD: rawPipe[0], stop: make(chan struct{}), finished: make(chan struct{}), errors: make(chan error, 1)}
	go u.run()
	var wg sync.WaitGroup
	started := time.Now()
	for i := 0; i < 8; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if err := u.Close(); err != nil {
				t.Error(err)
			}
		}()
	}
	wg.Wait()
	if time.Since(started) > time.Second {
		t.Fatal("close did not finish within bounded poll period")
	}
	if u.Stats() != (GREStats{}) {
		t.Fatal("idle underlay recorded network traffic")
	}
}

// Local pipes and an AF_UNIX datagram socketpair exercise the real rejection
// paths without any IP socket, TUN, route, elevated privilege or network packet.
func TestGRELinuxWorkerClassifiesRejections(t *testing.T) {
	tunPipe := make([]int, 2)
	if err := unix.Pipe2(tunPipe, unix.O_NONBLOCK|unix.O_CLOEXEC); err != nil {
		t.Fatal(err)
	}
	defer unix.Close(tunPipe[1])
	rawPair, err := unix.Socketpair(unix.AF_UNIX, unix.SOCK_DGRAM|unix.SOCK_NONBLOCK|unix.SOCK_CLOEXEC, 0)
	if err != nil {
		unix.Close(tunPipe[0])
		t.Fatal(err)
	}
	defer unix.Close(rawPair[1])
	origin, egress := greTestConfigPair()
	u := &linuxGREUnderlay{config: *egress, tunFD: tunPipe[0], rawFD: rawPair[0],
		stop: make(chan struct{}), finished: make(chan struct{}), errors: make(chan error, 1)}
	go u.run()
	t.Cleanup(func() {
		if err := u.Close(); err != nil {
			t.Error(err)
		}
	})
	waitFor := func(want GREStats) {
		t.Helper()
		deadline := time.Now().Add(time.Second)
		for time.Now().Before(deadline) {
			if u.Stats() == want {
				return
			}
			select {
			case err := <-u.Errors():
				t.Fatalf("worker failed: %v", err)
			default:
			}
			time.Sleep(time.Millisecond)
		}
		t.Fatalf("stats = %s, want %s", u.Stats(), want)
	}
	write := func(fd int, packet []byte) {
		t.Helper()
		if n, err := unix.Write(fd, packet); err != nil || n != len(packet) {
			t.Fatalf("fixture write = %d/%d, err=%v", n, len(packet), err)
		}
	}
	write(tunPipe[1], []byte{0})
	waitFor(GREStats{Rejected: 1, TxRejected: 1})
	write(tunPipe[1], make([]byte, egress.MTU+1))
	waitFor(GREStats{Rejected: 2, TxRejected: 2})
	wrongIdentity := greTestEncoded(t, origin, greTestInner(origin, nil))
	wrongIdentity[15] ^= 1
	greTestFixIPv4(wrongIdentity)
	write(rawPair[1], wrongIdentity)
	waitFor(GREStats{Rejected: 3, TxRejected: 2, RxRejected: 1, RxIdentityMismatch: 1})
	write(rawPair[1], []byte{0})
	waitFor(GREStats{Rejected: 4, TxRejected: 2, RxRejected: 2, RxIdentityMismatch: 1})
	write(rawPair[1], make([]byte, egress.MTU+greIPv4Overhead+1))
	waitFor(GREStats{Rejected: 5, TxRejected: 2, RxRejected: 3, RxIdentityMismatch: 1, RxTruncated: 1})
}
