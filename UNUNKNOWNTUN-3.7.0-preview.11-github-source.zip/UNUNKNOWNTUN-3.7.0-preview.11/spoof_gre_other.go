//go:build !linux

package main

import (
	"context"
	"errors"
	"syscall"
)

func startGREUnderlay(c *GREConfig) (greUnderlay, error) {
	return startGREUnderlayContext(context.Background(), c)
}

func startGREUnderlayContext(ctx context.Context, c *GREConfig) (greUnderlay, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	return nil, errors.New("[gre/platform] the optional native GRE/TUN underlay requires Linux; ordinary UNUNKNOWNTUN transports remain available")
}

func bindGRESocket(c *GREConfig, raw syscall.RawConn) error {
	return errors.New("[gre/platform] binding a GRE carrier to its TUN requires Linux")
}
