package main

import (
	"context"
	"errors"
	"testing"
)

func TestGREStartupCanceledBeforeResources(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	u, err := startGREUnderlayContext(ctx, nil)
	if u != nil || !errors.Is(err, context.Canceled) {
		t.Fatalf("expected canceled startup before validation/resource creation, got underlay=%v err=%v", u, err)
	}
}
