package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"net/netip"
)

func greCheckRules(data []byte) error {
	var rules []map[string]json.RawMessage
	if err := json.Unmarshal(data, &rules); err != nil {
		return fmt.Errorf("[gre/policy-routing] invalid rules JSON: %w", err)
	}
	if len(rules) != 3 {
		return errors.New("[gre/policy-routing] custom/missing routing rules are unsupported; no rules were changed")
	}
	want := map[int]string{0: "local", 32766: "main", 32767: "default"}
	for _, rule := range rules {
		var priority int
		if err := json.Unmarshal(rule["priority"], &priority); err != nil {
			return errors.New("[gre/policy-routing] rule has no valid priority")
		}
		expected, ok := want[priority]
		if !ok {
			return errors.New("[gre/policy-routing] nonstandard rule priority")
		}
		var table string
		if err := json.Unmarshal(rule["table"], &table); err != nil {
			return errors.New("[gre/policy-routing] unsupported table format")
		}
		if table != expected {
			return errors.New("[gre/policy-routing] nonstandard table selection")
		}
		for key, value := range rule {
			switch key {
			case "priority", "table":
			case "src":
				if string(value) != `"all"` {
					return errors.New("[gre/policy-routing] source-selective rules are unsupported")
				}
			case "protocol":
				if string(value) != `"kernel"` {
					return errors.New("[gre/policy-routing] non-kernel rule metadata")
				}
			case "flags":
				if string(value) != "[]" {
					return errors.New("[gre/policy-routing] rule flags are unsupported")
				}
			default:
				return fmt.Errorf("[gre/policy-routing] unsupported rule field %q", key)
			}
		}
		delete(want, priority)
	}
	return nil
}

func greCheckRoutes(data []byte, local, peer string) error {
	var routes []map[string]json.RawMessage
	if err := json.Unmarshal(data, &routes); err != nil {
		return fmt.Errorf("[gre/routes] invalid route JSON: %w", err)
	}
	if len(routes) == 0 {
		return errors.New("[gre/routes] empty route inventory cannot prove the inner pair is unused")
	}
	localIP, err := netip.ParseAddr(local)
	if err != nil {
		return err
	}
	peerIP, err := netip.ParseAddr(peer)
	if err != nil {
		return err
	}
	for _, route := range routes {
		var dst string
		if err := json.Unmarshal(route["dst"], &dst); err != nil {
			return errors.New("[gre/routes] route lacks a readable destination")
		}
		if dst == "default" || dst == "0.0.0.0/0" {
			continue
		}
		prefix, err := netip.ParsePrefix(dst)
		if err != nil {
			addr, addrErr := netip.ParseAddr(dst)
			if addrErr != nil || !addr.Is4() {
				return fmt.Errorf("[gre/routes] unsupported route destination %q", dst)
			}
			prefix = netip.PrefixFrom(addr, 32)
		}
		if !prefix.Addr().Is4() {
			return errors.New("[gre/routes] unexpected non-IPv4 route")
		}
		if prefix.Contains(localIP) || prefix.Contains(peerIP) {
			return fmt.Errorf("[gre/routes] inner address overlaps existing route %s; choose another pair", dst)
		}
	}
	return nil
}

func greCheckOuterRoute(data []byte, c *GREConfig) error {
	var routes []struct {
		Dev     string          `json:"dev"`
		Src     string          `json:"src"`
		PrefSrc string          `json:"prefsrc"`
		From    string          `json:"from"`
		Type    string          `json:"type"`
		Table   json.RawMessage `json:"table"`
	}
	if err := json.Unmarshal(data, &routes); err != nil || len(routes) != 1 {
		return errors.New("[gre/outer-route] expected one unambiguous route to the real peer")
	}
	r := routes[0]
	if r.Dev != c.Interface || (r.Type != "" && r.Type != "unicast") {
		return errors.New("[gre/outer-route] peer route does not use the configured physical interface")
	}
	for _, src := range []string{r.Src, r.PrefSrc, r.From} {
		if src != "" && src != c.LocalIP {
			return errors.New("[gre/outer-route] peer route selects an unexpected local address")
		}
	}
	if len(r.Table) != 0 && string(r.Table) != `"main"` && string(r.Table) != "254" {
		return errors.New("[gre/outer-route] peer uses a non-main routing table")
	}
	return nil
}
