package main

import "testing"

func TestGRERulePolicy(t *testing.T) {
	valid := `[{"priority":0,"src":"all","table":"local"},{"priority":32766,"src":"all","table":"main"},{"priority":32767,"src":"all","table":"default"}]`
	if err := greCheckRules([]byte(valid)); err != nil {
		t.Fatal(err)
	}
	for name, input := range map[string]string{
		"empty": `[]`, "null": `null`, "invalid": `{`,
		"extra":            `[{"priority":0,"src":"all","table":"local"},{"priority":32766,"src":"all","table":"main"},{"priority":32767,"src":"all","table":"default"},{"priority":100,"table":"vpn"}]`,
		"duplicate":        `[{"priority":0,"src":"all","table":"local"},{"priority":0,"src":"all","table":"local"},{"priority":32767,"src":"all","table":"default"}]`,
		"source selective": `[{"priority":0,"src":"all","table":"local"},{"priority":32766,"src":"10.0.0.0/8","table":"main"},{"priority":32767,"src":"all","table":"default"}]`,
		"fwmark":           `[{"priority":0,"src":"all","table":"local"},{"priority":32766,"src":"all","table":"main","fwmark":"0x1"},{"priority":32767,"src":"all","table":"default"}]`,
		"wrong table":      `[{"priority":0,"src":"all","table":"local"},{"priority":32766,"src":"all","table":"vpn"},{"priority":32767,"src":"all","table":"default"}]`,
	} {
		t.Run(name, func(t *testing.T) {
			if err := greCheckRules([]byte(input)); err == nil {
				t.Fatal("accepted unsupported routing policy")
			}
		})
	}
}

func TestGRERouteOverlap(t *testing.T) {
	local, peer := "10.231.12.1", "10.231.12.2"
	for name, input := range map[string]string{
		"normal":            `[{"dst":"default","gateway":"192.0.2.1","dev":"eth0"},{"dst":"192.0.2.0/24","dev":"eth0"},{"type":"local","dst":"192.0.2.5","dev":"eth0"}]`,
		"explicit default":  `[{"dst":"0.0.0.0/0"}]`,
		"unrelated private": `[{"dst":"172.18.0.0/16","dev":"docker0"}]`,
	} {
		t.Run(name, func(t *testing.T) {
			if err := greCheckRoutes([]byte(input), local, peer); err != nil {
				t.Fatal(err)
			}
		})
	}
	for name, input := range map[string]string{
		"local host":          `[{"type":"local","dst":"10.231.12.1"}]`,
		"peer host":           `[{"dst":"10.231.12.2/32"}]`,
		"supernet":            `[{"dst":"10.0.0.0/8"}]`,
		"subnet":              `[{"dst":"10.231.12.0/24"}]`,
		"blackhole":           `[{"type":"blackhole","dst":"10.231.12.2"}]`,
		"invalid destination": `[{"dst":"bad"}]`,
		"missing destination": `[{"dev":"eth0"}]`,
		"ipv6":                `[{"dst":"::/0"}]`,
		"null":                `null`, "empty": `[]`, "invalid JSON": `{`,
	} {
		t.Run(name, func(t *testing.T) {
			if err := greCheckRoutes([]byte(input), local, peer); err == nil {
				t.Fatal("accepted ambiguous or overlapping route")
			}
		})
	}
}

func TestGREOuterRoutePolicy(t *testing.T) {
	c := &GREConfig{Interface: "eth0", LocalIP: "192.0.2.5"}
	for _, input := range []string{
		`[{"dev":"eth0","from":"192.0.2.5","table":"main"}]`,
		`[{"dev":"eth0","prefsrc":"192.0.2.5","table":254,"type":"unicast"}]`,
	} {
		if err := greCheckOuterRoute([]byte(input), c); err != nil {
			t.Fatal(err)
		}
	}
	for name, input := range map[string]string{
		"wrong dev":             `[{"dev":"tun0"}]`,
		"wrong source":          `[{"dev":"eth0","prefsrc":"192.0.2.6"}]`,
		"wrong explicit source": `[{"dev":"eth0","from":"192.0.2.6"}]`,
		"wrong table":           `[{"dev":"eth0","table":"vpn"}]`,
		"wrong type":            `[{"dev":"eth0","type":"blackhole"}]`,
		"multiple":              `[{"dev":"eth0"},{"dev":"eth1"}]`,
		"none":                  `[]`, "null": `null`, "invalid": `{`,
	} {
		t.Run(name, func(t *testing.T) {
			if err := greCheckOuterRoute([]byte(input), c); err == nil {
				t.Fatal("accepted wrong or ambiguous physical path")
			}
		})
	}
}
