package main

// These tests are pure-memory codec/config checks. They never create a socket,
// TUN interface, route, probe packet, process, or network connection.

import (
	"bytes"
	"context"
	"encoding/binary"
	"encoding/json"
	"errors"
	"math/rand"
	"net"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func greTestConfigPair() (*GREConfig, *GREConfig) {
	origin := &GREConfig{
		Interface: "eth0", TUNName: "gdtgre0", LocalIP: "192.0.2.10", PeerIP: "192.0.2.20",
		SourceIP: "198.51.100.10", ExpectedPeerSourceIP: "198.51.100.20",
		InnerLocalIP: "10.77.0.1", InnerPeerIP: "10.77.0.2", MTU: 1280,
		CarrierPort: 31080, Authorized: true, Role: "origin",
	}
	egress := &GREConfig{
		Interface: "eth0", TUNName: "gdtgre1", LocalIP: "192.0.2.20", PeerIP: "192.0.2.10",
		SourceIP: "198.51.100.20", ExpectedPeerSourceIP: "198.51.100.10",
		InnerLocalIP: "10.77.0.2", InnerPeerIP: "10.77.0.1", MTU: 1280,
		CarrierPort: 31080, Authorized: true, Role: "egress",
	}
	return origin, egress
}

func TestGREWirePlanIsConfigurationOnlyAndNilSafe(t *testing.T) {
	if got := GREWirePlan(nil); got != "configuration_only=true packet_capture=false spoof=off" {
		t.Fatalf("unexpected disabled plan: %s", got)
	}
	origin, egress := greTestConfigPair()
	for _, c := range []*GREConfig{origin, egress} {
		got := GREWirePlan(c)
		for _, want := range []string{
			"configuration_only=true", "packet_capture=false",
			`outer_tx="` + c.SourceIP + `"->"` + c.PeerIP + `"`,
			`expected_outer_rx="` + c.ExpectedPeerSourceIP + `"->"` + c.LocalIP + `"`,
			`inner_tx="` + c.InnerLocalIP + `"->"` + c.InnerPeerIP + `"`,
			`expected_inner_rx="` + c.InnerPeerIP + `"->"` + c.InnerLocalIP + `"`,
		} {
			if !strings.Contains(got, want) {
				t.Fatalf("%s wire plan lacks %q: %s", c.Role, want, got)
			}
		}
	}
	origin.SourceIP = "invalid\nlog injection\t"
	if got := GREWirePlan(origin); strings.ContainsAny(got, "\n\r\t") {
		t.Fatalf("diagnostic allowed multiline field: %q", got)
	}
}

func TestGREStatsDiagnosticString(t *testing.T) {
	s := GREStats{Sent: 7, Received: 9, Rejected: 5, Dropped: 2,
		TxRejected: 2, RxRejected: 3, RxIdentityMismatch: 1, RxTruncated: 1}
	want := "sent=7 received=9 rejected=5 dropped=2 tx_rejected=2 rx_rejected=3 rx_identity_mismatch=1 rx_truncated=1"
	if got := s.String(); got != want {
		t.Fatalf("stats = %q, want %q", got, want)
	}
	for _, text := range []string{"AF_INET", "before counters", "does not prove provider blocking", "reverse route", "rp_filter"} {
		if !strings.Contains(GREReceiveDiagnosticHint, text) {
			t.Fatalf("receive guidance omitted %q", text)
		}
	}
}

func TestGRERejectionCountersKeepCoherentAggregateAndSubsets(t *testing.T) {
	var counters greRejectionCounters
	wrappedIdentity := errors.Join(errors.New("receive filter"), ErrGREIdentityMismatch)
	const workers, rounds = 8, 100
	var wg sync.WaitGroup
	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := 0; j < rounds; j++ {
				counters.rejectTX()
				counters.rejectRX(errors.New("malformed packet"), false)
				counters.rejectRX(wrappedIdentity, false)
				counters.rejectRX(nil, true)
			}
		}()
	}
	for i := 0; i < workers*rounds; i++ {
		s := counters.snapshot()
		if s.Rejected != s.TxRejected+s.RxRejected || s.RxIdentityMismatch+s.RxTruncated > s.RxRejected {
			t.Fatalf("incoherent rejection snapshot: %s", s)
		}
	}
	wg.Wait()
	n := uint64(workers * rounds)
	want := GREStats{Rejected: 4 * n, TxRejected: n, RxRejected: 3 * n, RxIdentityMismatch: n, RxTruncated: n}
	if got := counters.snapshot(); got != want {
		t.Fatalf("counters = %s, want %s", got, want)
	}
}

func TestGREDecodeIdentityDiagnosticIsSpecific(t *testing.T) {
	origin, egress := greTestConfigPair()
	for _, tc := range []struct {
		name     string
		mutate   func([]byte) []byte
		identity bool
	}{
		{"source", func(p []byte) []byte { p[15] ^= 1; greTestFixIPv4(p); return p }, true},
		{"destination", func(p []byte) []byte { p[19] ^= 1; greTestFixIPv4(p); return p }, true},
		{"checksum", func(p []byte) []byte { p[10] ^= 1; return p }, false},
		{"gre_flags", func(p []byte) []byte { p[20] = 1; return p }, false},
		{"short", func(p []byte) []byte {
			p = p[:60]
			binary.BigEndian.PutUint16(p[2:4], uint16(len(p)))
			greTestFixIPv4(p)
			return p
		}, false},
	} {
		t.Run(tc.name, func(t *testing.T) {
			packet := tc.mutate(greTestEncoded(t, origin, greTestInner(origin, nil)))
			_, err := decodeGREPacket(egress, packet)
			if err == nil || errors.Is(err, ErrGREIdentityMismatch) != tc.identity {
				t.Fatalf("identity classification = %v, want identity=%t", err, tc.identity)
			}
		})
	}
}

// Independent checksum implementation, not the implementation under test.
func greTestChecksum(data []byte) uint16 {
	var sum uint32
	for len(data) >= 2 {
		sum += uint32(data[0])<<8 | uint32(data[1])
		data = data[2:]
	}
	if len(data) != 0 {
		sum += uint32(data[0]) << 8
	}
	for sum > 0xffff {
		sum = (sum & 0xffff) + (sum >> 16)
	}
	return ^uint16(sum)
}

func greTestFixIPv4(packet []byte) {
	packet[10], packet[11] = 0, 0
	binary.BigEndian.PutUint16(packet[10:12], greTestChecksum(packet[:20]))
}

func greTestFixTCP(inner []byte) {
	inner[36], inner[37] = 0, 0
	pseudo := make([]byte, 12+len(inner)-20)
	copy(pseudo[0:4], inner[12:16])
	copy(pseudo[4:8], inner[16:20])
	pseudo[9] = 6
	binary.BigEndian.PutUint16(pseudo[10:12], uint16(len(inner)-20))
	copy(pseudo[12:], inner[20:])
	binary.BigEndian.PutUint16(inner[36:38], greTestChecksum(pseudo))
}

func greTestInner(config *GREConfig, payload []byte) []byte {
	inner := make([]byte, 40+len(payload))
	inner[0], inner[8], inner[9] = 0x45, 64, 6
	binary.BigEndian.PutUint16(inner[2:4], uint16(len(inner)))
	binary.BigEndian.PutUint16(inner[4:6], 0x2468)
	binary.BigEndian.PutUint16(inner[6:8], 0x4000)
	copy(inner[12:16], net.ParseIP(config.InnerLocalIP).To4())
	copy(inner[16:20], net.ParseIP(config.InnerPeerIP).To4())
	source, destination := uint16(40000), uint16(config.CarrierPort)
	if config.Role == "egress" {
		source, destination = destination, source
	}
	binary.BigEndian.PutUint16(inner[20:22], source)
	binary.BigEndian.PutUint16(inner[22:24], destination)
	binary.BigEndian.PutUint32(inner[24:28], 100)
	binary.BigEndian.PutUint32(inner[28:32], 200)
	inner[32], inner[33] = 5<<4, 0x18
	binary.BigEndian.PutUint16(inner[34:36], 8192)
	copy(inner[40:], payload)
	greTestFixTCP(inner)
	greTestFixIPv4(inner)
	return inner
}

func greTestEncoded(t *testing.T, config *GREConfig, inner []byte) []byte {
	t.Helper()
	packet, err := encodeGREPacket(config, inner, 0x1234)
	if err != nil {
		t.Fatal(err)
	}
	return packet
}

func TestSpoofGREConfigValidRoles(t *testing.T) {
	origin, egress := greTestConfigPair()
	for _, config := range []*GREConfig{origin, egress} {
		if err := config.validate(); err != nil {
			t.Fatalf("%s configuration rejected: %v", config.Role, err)
		}
	}
}

func TestSpoofGREConfigRejectsUnsafeInputs(t *testing.T) {
	cases := []struct {
		name string
		edit func(*GREConfig)
	}{
		{"authorization", func(c *GREConfig) { c.Authorized = false }},
		{"role", func(c *GREConfig) { c.Role = "both" }},
		{"empty_interface", func(c *GREConfig) { c.Interface = "" }},
		{"interface_injection", func(c *GREConfig) { c.Interface = "eth0;true" }},
		{"interface_long", func(c *GREConfig) { c.Interface = "abcdefghijklmnop" }},
		{"empty_tun", func(c *GREConfig) { c.TUNName = "" }},
		{"tun_path", func(c *GREConfig) { c.TUNName = "../gdt" }},
		{"tun_same_as_interface", func(c *GREConfig) { c.TUNName = c.Interface }},
		{"source_unspecified", func(c *GREConfig) { c.SourceIP = "0.0.0.0" }},
		{"source_this_network", func(c *GREConfig) { c.SourceIP = "0.1.2.3" }},
		{"source_multicast", func(c *GREConfig) { c.SourceIP = "224.0.0.1" }},
		{"source_loopback", func(c *GREConfig) { c.SourceIP = "127.0.0.1" }},
		{"source_reserved", func(c *GREConfig) { c.SourceIP = "240.0.0.1" }},
		{"source_broadcast", func(c *GREConfig) { c.SourceIP = "255.255.255.255" }},
		{"source_linklocal", func(c *GREConfig) { c.SourceIP = "169.254.1.2" }},
		{"source_hostname", func(c *GREConfig) { c.SourceIP = "example.com" }},
		{"source_cidr", func(c *GREConfig) { c.SourceIP = "192.0.2.0/24" }},
		{"source_ipv6", func(c *GREConfig) { c.SourceIP = "2001:db8::1" }},
		{"local_hostname", func(c *GREConfig) { c.LocalIP = "example.com" }},
		{"peer_unspecified", func(c *GREConfig) { c.PeerIP = "0.0.0.0" }},
		{"peer_same_local", func(c *GREConfig) { c.PeerIP = c.LocalIP }},
		{"expected_source_multicast", func(c *GREConfig) { c.ExpectedPeerSourceIP = "224.0.0.1" }},
		{"inner_same", func(c *GREConfig) { c.InnerPeerIP = c.InnerLocalIP }},
		{"inner_loopback", func(c *GREConfig) { c.InnerLocalIP = "127.0.0.1" }},
		{"inner_unspecified", func(c *GREConfig) { c.InnerPeerIP = "0.0.0.0" }},
		{"mtu_zero", func(c *GREConfig) { c.MTU = 0 }},
		{"mtu_below_ipv4_min", func(c *GREConfig) { c.MTU = 575 }},
		{"mtu_too_large", func(c *GREConfig) { c.MTU = 65535 }},
		{"port_zero", func(c *GREConfig) { c.CarrierPort = 0 }},
		{"port_privileged", func(c *GREConfig) { c.CarrierPort = 1023 }},
		{"port_negative", func(c *GREConfig) { c.CarrierPort = -1 }},
		{"port_too_large", func(c *GREConfig) { c.CarrierPort = 65536 }},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			config, _ := greTestConfigPair()
			tc.edit(config)
			if err := config.validate(); err == nil {
				t.Fatal("unsafe configuration accepted")
			}
		})
	}
}

func TestSpoofGREConfigNilAndValidBoundaries(t *testing.T) {
	var empty *GREConfig
	if empty.validate() == nil {
		t.Fatal("nil configuration accepted")
	}
	if _, err := encodeGREPacket(nil, nil, 0); err == nil {
		t.Fatal("encoder accepted nil configuration")
	}
	if _, err := decodeGREPacket(nil, nil); err == nil {
		t.Fatal("decoder accepted nil configuration")
	}
	for _, mtu := range []int{576, 1400} {
		for _, port := range []int{1024, 65535} {
			config, _ := greTestConfigPair()
			config.MTU, config.CarrierPort = mtu, port
			if err := config.validate(); err != nil {
				t.Fatalf("valid mtu=%d port=%d rejected: %v", mtu, port, err)
			}
		}
	}
}

func greTestConfigJSON(t testing.TB) []byte {
	t.Helper()
	config, _ := greTestConfigPair()
	data, err := json.Marshal(config)
	if err != nil {
		t.Fatal(err)
	}
	return data
}

func TestSpoofGREStrictConfigJSON(t *testing.T) {
	valid := greTestConfigJSON(t)
	for _, role := range []string{"origin", "egress"} {
		config, err := parseGREConfig(valid, role)
		if err != nil || config.Role != role {
			t.Fatalf("role is not derived from CLI: %+v %v", config, err)
		}
	}
	cases := map[string][]byte{
		"empty":           nil,
		"array":           []byte("[]"),
		"null":            []byte("null"),
		"unterminated":    valid[:len(valid)-1],
		"two_documents":   append(bytes.Clone(valid), valid...),
		"trailing_scalar": append(bytes.Clone(valid), []byte("true")...),
		"unknown":         bytes.Replace(valid, []byte("{"), []byte(`{"unknown":1,`), 1),
		"role_override":   bytes.Replace(valid, []byte("{"), []byte(`{"role":"egress",`), 1),
		"duplicate":       bytes.Replace(valid, []byte("{"), []byte(`{"mtu":1280,`), 1),
		"escaped_alias":   bytes.Replace(valid, []byte("{"), []byte(`{"\u006dtu":1280,`), 1),
		"case_alias":      bytes.Replace(valid, []byte(`"mtu"`), []byte(`"MTU"`), 1),
		"null_mtu":        bytes.Replace(valid, []byte(`"mtu":1280`), []byte(`"mtu":null`), 1),
		"fractional_mtu":  bytes.Replace(valid, []byte(`"mtu":1280`), []byte(`"mtu":1280.0`), 1),
		"overflow_mtu":    bytes.Replace(valid, []byte(`"mtu":1280`), []byte(`"mtu":1e999`), 1),
		"string_mtu":      bytes.Replace(valid, []byte(`"mtu":1280`), []byte(`"mtu":"1280"`), 1),
		"string_auth":     bytes.Replace(valid, []byte(`"authorized":true`), []byte(`"authorized":"true"`), 1),
		"nested_auth":     bytes.Replace(valid, []byte(`"authorized":true`), []byte(`"authorized":{"value":true}`), 1),
		"missing_auth":    bytes.Replace(valid, []byte(`,"authorized":true`), nil, 1),
		"oversized":       append(bytes.Clone(valid), bytes.Repeat([]byte(" "), 16385)...),
	}
	for name, data := range cases {
		t.Run(name, func(t *testing.T) {
			if _, err := parseGREConfig(data, "origin"); err == nil {
				t.Fatal("malformed configuration JSON accepted")
			}
		})
	}
	if _, err := parseGREConfig(valid, "invalid"); err == nil {
		t.Fatal("invalid derived role accepted")
	}
	boundary := append(bytes.Clone(valid), bytes.Repeat([]byte(" "), 16384-len(valid))...)
	if _, err := parseGREConfig(boundary, "origin"); err != nil {
		t.Fatalf("valid config padded to exact byte bound rejected: %v", err)
	}
	if _, err := parseGREConfig(append(boundary, ' '), "origin"); err == nil {
		t.Fatal("one byte over config bound accepted")
	}
}

func TestSpoofGREPrivateConfigFile(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "gre.json")
	data := greTestConfigJSON(t)
	if err := os.WriteFile(path, data, 0600); err != nil {
		t.Fatal(err)
	}
	config, err := loadGREConfig(path, "origin")
	if err != nil || config.Role != "origin" {
		t.Fatalf("private config rejected: %v", err)
	}
	link := filepath.Join(dir, "symlink.json")
	if err := os.Symlink(path, link); err != nil {
		t.Fatal(err)
	}
	if _, err := loadGREConfig(link, "origin"); err == nil {
		t.Fatal("symlink config accepted")
	}
	if _, err := loadGREConfig(dir, "origin"); err == nil {
		t.Fatal("directory accepted as config")
	}
	if _, err := loadGREConfig(filepath.Join(dir, "missing"), "origin"); err == nil {
		t.Fatal("missing file accepted")
	}
	for _, mode := range []os.FileMode{0644, 0640, 0604, 0660} {
		if err := os.Chmod(path, mode); err != nil {
			t.Fatal(err)
		}
		if _, err := loadGREConfig(path, "origin"); err == nil {
			t.Fatalf("nonprivate file mode %o accepted", mode)
		}
	}
	if err := os.Chmod(path, 0600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(path, bytes.Repeat([]byte(" "), 16385), 0600); err != nil {
		t.Fatal(err)
	}
	if _, err := loadGREConfig(path, "origin"); err == nil {
		t.Fatal("oversized private file accepted")
	}
}

func TestSpoofGRETunnelBinding(t *testing.T) {
	origin, egress := greTestConfigPair()
	if err := validateGREForTunnel(nil, nil); err != nil {
		t.Fatal("spoof-off nil config changed legacy path")
	}
	for _, config := range []*GREConfig{origin, egress} {
		t.Run(config.Role, func(t *testing.T) {
			valid := &Config{Mode: config.Role, Transport: TransportTLS,
				Connect: "10.77.0.2:31080", Listen: "10.77.0.2:31080",
				ECHMode: ECHModeOff, TLSFragment: "off"}
			if err := validateGREForTunnel(config, valid); err != nil {
				t.Fatal(err)
			}
			if err := validateGREForTunnel(config, nil); err == nil {
				t.Fatal("nil tunnel config accepted with GRE enabled")
			}
			mutations := map[string]func(*Config){
				"mode":      func(c *Config) { c.Mode = "other" },
				"wss":       func(c *Config) { c.Transport = "wss" },
				"xhttp":     func(c *Config) { c.Transport = "xhttp" },
				"ech":       func(c *Config) { c.ECHMode = "strict" },
				"fragment":  func(c *Config) { c.TLSFragment = "on" },
				"hostname":  func(c *Config) { c.Connect, c.Listen = "peer.example:31080", "peer.example:31080" },
				"wrong_ip":  func(c *Config) { c.Connect, c.Listen = "10.77.0.3:31080", "10.77.0.3:31080" },
				"wrongport": func(c *Config) { c.Connect, c.Listen = "10.77.0.2:31081", "10.77.0.2:31081" },
				"wildcard":  func(c *Config) { c.Connect, c.Listen = "0.0.0.0:31080", "0.0.0.0:31080" },
				"fallback": func(c *Config) {
					c.Connect, c.Listen = "10.77.0.2:31080,peer.example:443", "10.77.0.2:31080,peer.example:443"
				},
			}
			for name, mutate := range mutations {
				t.Run(name, func(t *testing.T) {
					bad := *valid
					mutate(&bad)
					if err := validateGREForTunnel(config, &bad); err == nil {
						t.Fatal("unsafe tunnel binding accepted")
					}
				})
			}
		})
	}
}

func TestSpoofGREWireRoundTripBothRoles(t *testing.T) {
	origin, egress := greTestConfigPair()
	for _, pair := range [][2]*GREConfig{{origin, egress}, {egress, origin}} {
		t.Run(pair[0].Role, func(t *testing.T) {
			for _, payload := range [][]byte{nil, []byte("odd"), bytes.Repeat([]byte{0xa7}, 1240)} {
				inner := greTestInner(pair[0], payload)
				packet := greTestEncoded(t, pair[0], inner)
				if len(packet) != 24+len(inner) || packet[0] != 0x45 || packet[9] != 47 || packet[8] == 0 {
					t.Fatalf("bad IPv4 GRE header: %x", packet[:20])
				}
				if got := int(binary.BigEndian.Uint16(packet[2:4])); got != len(packet) {
					t.Fatalf("outer length = %d, want %d", got, len(packet))
				}
				if binary.BigEndian.Uint16(packet[4:6]) != 0x1234 || binary.BigEndian.Uint16(packet[6:8])&0x3fff != 0 {
					t.Fatal("wrong identifier or fragmented outer packet")
				}
				if greTestChecksum(packet[:20]) != 0 || greTestChecksum(inner[:20]) != 0 {
					t.Fatal("invalid IPv4 checksum")
				}
				if !net.IP(packet[12:16]).Equal(net.ParseIP(pair[0].SourceIP)) || !net.IP(packet[16:20]).Equal(net.ParseIP(pair[0].PeerIP)) {
					t.Fatal("wrong outer source or destination")
				}
				if !bytes.Equal(packet[20:24], []byte{0, 0, 8, 0}) {
					t.Fatalf("not standard minimal GRE v0 IPv4 header: %x", packet[20:24])
				}
				decoded, err := decodeGREPacket(pair[1], packet)
				if err != nil {
					t.Fatal(err)
				}
				if !bytes.Equal(decoded, inner) {
					t.Fatal("inner packet changed during codec round trip")
				}
			}
		})
	}
}

func TestSpoofGRETCPHandshakeOptionsPreserved(t *testing.T) {
	origin, egress := greTestConfigPair()
	// Common SYN options: MSS, SACK permitted, timestamps, NOP/window scale.
	options := []byte{2, 4, 4, 224, 4, 2, 8, 10, 0, 0, 0, 1, 0, 0, 0, 0, 1, 3, 3, 7}
	for _, pair := range [][2]*GREConfig{{origin, egress}, {egress, origin}} {
		inner := greTestInner(pair[0], options)
		inner[32], inner[33] = 10<<4, 0x02
		if pair[0].Role == "egress" {
			inner[33] = 0x12 // SYN+ACK on return direction.
		}
		greTestFixTCP(inner)
		packet := greTestEncoded(t, pair[0], inner)
		decoded, err := decodeGREPacket(pair[1], packet)
		if err != nil || !bytes.Equal(inner, decoded) {
			t.Fatalf("%s TCP handshake options not preserved: %v", pair[0].Role, err)
		}
	}
}

func TestSpoofGRERejectsMalformedOuter(t *testing.T) {
	origin, egress := greTestConfigPair()
	valid := greTestEncoded(t, origin, greTestInner(origin, []byte("payload")))
	cases := []struct {
		name string
		edit func([]byte) []byte
		fix  bool
	}{
		{"truncated_ipv4", func(p []byte) []byte { return p[:19] }, false},
		{"truncated_gre", func(p []byte) []byte { return p[:23] }, false},
		{"truncated_inner", func(p []byte) []byte { return p[:40] }, false},
		{"ipv6_version", func(p []byte) []byte { p[0] = 0x65; return p }, true},
		{"ip_options", func(p []byte) []byte { p[0] = 0x46; return p }, true},
		{"short_ihl", func(p []byte) []byte { p[0] = 0x44; return p }, true},
		{"zero_ttl", func(p []byte) []byte { p[8] = 0; return p }, true},
		{"udp_protocol", func(p []byte) []byte { p[9] = 17; return p }, true},
		{"bad_checksum", func(p []byte) []byte { p[10] ^= 1; return p }, false},
		{"more_fragments", func(p []byte) []byte { p[6] |= 0x20; return p }, true},
		{"fragment_offset", func(p []byte) []byte { p[7] = 1; return p }, true},
		{"reserved_fragment_flag", func(p []byte) []byte { p[6] |= 0x80; return p }, true},
		{"wrong_source", func(p []byte) []byte { p[15] ^= 1; return p }, true},
		{"wrong_destination", func(p []byte) []byte { p[19] ^= 1; return p }, true},
		{"length_short", func(p []byte) []byte { binary.BigEndian.PutUint16(p[2:4], uint16(len(p)-1)); return p }, true},
		{"length_long", func(p []byte) []byte { binary.BigEndian.PutUint16(p[2:4], uint16(len(p)+1)); return p }, true},
		{"trailing_bytes", func(p []byte) []byte { return append(p, 0) }, false},
		{"gre_version", func(p []byte) []byte { p[21] = 1; return p }, false},
		{"gre_checksum_flag", func(p []byte) []byte { p[20] = 0x80; return p }, false},
		{"gre_key_flag", func(p []byte) []byte { p[20] = 0x20; return p }, false},
		{"gre_sequence_flag", func(p []byte) []byte { p[20] = 0x10; return p }, false},
		{"gre_wrong_ethertype", func(p []byte) []byte { p[22], p[23] = 0x86, 0xdd; return p }, false},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			packet := tc.edit(bytes.Clone(valid))
			if tc.fix {
				greTestFixIPv4(packet)
			}
			if _, err := decodeGREPacket(egress, packet); err == nil {
				t.Fatal("malformed outer packet accepted")
			}
		})
	}
}

func TestSpoofGRERejectsMalformedInnerBothDirections(t *testing.T) {
	origin, egress := greTestConfigPair()
	cases := []struct {
		name string
		edit func([]byte) []byte
		ip   bool
		tcp  bool
	}{
		{"short_ipv4", func(p []byte) []byte { return p[:19] }, false, false},
		{"short_tcp", func(p []byte) []byte { return p[:39] }, true, false},
		{"ipv6", func(p []byte) []byte { p[0] = 0x65; return p }, true, false},
		{"ip_options", func(p []byte) []byte { p[0] = 0x46; return p }, true, false},
		{"zero_ttl", func(p []byte) []byte { p[8] = 0; return p }, true, false},
		{"udp", func(p []byte) []byte { p[9] = 17; return p }, true, false},
		{"bad_ip_checksum", func(p []byte) []byte { p[10] ^= 1; return p }, false, false},
		{"bad_tcp_checksum", func(p []byte) []byte { p[36] ^= 1; return p }, false, false},
		{"more_fragments", func(p []byte) []byte { p[6] |= 0x20; return p }, true, false},
		{"fragment_offset", func(p []byte) []byte { p[7] = 1; return p }, true, false},
		{"reserved_flag", func(p []byte) []byte { p[6] |= 0x80; return p }, true, false},
		{"wrong_source", func(p []byte) []byte { p[15] ^= 1; return p }, true, true},
		{"wrong_destination", func(p []byte) []byte { p[19] ^= 1; return p }, true, true},
		{"zero_source_port", func(p []byte) []byte { p[20], p[21] = 0, 0; return p }, false, true},
		{"zero_destination_port", func(p []byte) []byte { p[22], p[23] = 0, 0; return p }, false, true},
		{"short_tcp_offset", func(p []byte) []byte { p[32] = 4 << 4; return p }, false, true},
		{"oversize_tcp_offset", func(p []byte) []byte { p[32] = 15 << 4; return p }, false, true},
		{"length_short", func(p []byte) []byte { binary.BigEndian.PutUint16(p[2:4], uint16(len(p)-1)); return p }, true, false},
		{"length_long", func(p []byte) []byte { binary.BigEndian.PutUint16(p[2:4], uint16(len(p)+1)); return p }, true, false},
	}
	for _, pair := range [][2]*GREConfig{{origin, egress}, {egress, origin}} {
		for _, tc := range cases {
			t.Run(pair[0].Role+"/"+tc.name, func(t *testing.T) {
				inner := tc.edit(greTestInner(pair[0], []byte("payload")))
				if tc.tcp {
					greTestFixTCP(inner)
				}
				if tc.ip {
					greTestFixIPv4(inner)
				}
				if _, err := encodeGREPacket(pair[0], inner, 1); err == nil {
					t.Fatal("malformed inner packet accepted for encode")
				}
				valid := greTestEncoded(t, pair[0], greTestInner(pair[0], nil))
				packet := append(bytes.Clone(valid[:24]), inner...)
				binary.BigEndian.PutUint16(packet[2:4], uint16(len(packet)))
				greTestFixIPv4(packet)
				if _, err := decodeGREPacket(pair[1], packet); err == nil {
					t.Fatal("malformed inner packet accepted for decode")
				}
			})
		}
	}
}

func TestSpoofGRECarrierPortAndMTUBounds(t *testing.T) {
	origin, egress := greTestConfigPair()
	for _, pair := range [][2]*GREConfig{{origin, egress}, {egress, origin}} {
		t.Run(pair[0].Role, func(t *testing.T) {
			inner := greTestInner(pair[0], nil)
			if pair[0].Role == "origin" {
				binary.BigEndian.PutUint16(inner[22:24], uint16(pair[0].CarrierPort+1))
			} else {
				binary.BigEndian.PutUint16(inner[20:22], uint16(pair[0].CarrierPort+1))
			}
			greTestFixTCP(inner)
			if _, err := encodeGREPacket(pair[0], inner, 1); err == nil {
				t.Fatal("wrong direction-specific carrier port accepted")
			}
			oversized := greTestInner(pair[0], make([]byte, pair[0].MTU-40+1))
			if _, err := encodeGREPacket(pair[0], oversized, 1); err == nil {
				t.Fatal("inner packet larger than MTU accepted")
			}
			packet := greTestEncoded(t, pair[0], greTestInner(pair[0], make([]byte, pair[0].MTU-40)))
			smaller := *pair[1]
			smaller.MTU--
			if _, err := decodeGREPacket(&smaller, packet); err == nil {
				t.Fatal("receiver MTU ignored")
			}
		})
	}
}

func TestSpoofGREMalformedInputNeverPanics(t *testing.T) {
	origin, egress := greTestConfigPair()
	rng := rand.New(rand.NewSource(42))
	for length := 0; length <= 1600; length++ {
		packet := make([]byte, length)
		_, _ = rng.Read(packet)
		_, _ = decodeGREPacket(egress, packet)
		_, _ = encodeGREPacket(origin, packet, 1)
	}
	valid := greTestEncoded(t, origin, greTestInner(origin, []byte("bounded mutation corpus")))
	for i := range valid {
		for _, value := range []byte{0, 1, 0x7f, 0xff} {
			packet := bytes.Clone(valid)
			packet[i] = value
			_, _ = decodeGREPacket(egress, packet)
		}
	}
}

func FuzzSpoofGREDecode(f *testing.F) {
	origin, egress := greTestConfigPair()
	seed, err := encodeGREPacket(origin, greTestInner(origin, []byte("offline seed")), 1)
	if err != nil {
		f.Fatal(err)
	}
	f.Add(seed)
	f.Add([]byte{})
	f.Add([]byte{0x45, 0, 0, 20})
	f.Fuzz(func(t *testing.T, data []byte) {
		if len(data) > 2048 {
			return
		}
		_, _ = decodeGREPacket(egress, data)
		_, _ = encodeGREPacket(origin, data, 1)
	})
}

func FuzzSpoofGREConfig(f *testing.F) {
	f.Add(greTestConfigJSON(f))
	f.Add([]byte(`{}`))
	f.Add([]byte(`{"mtu":1,"mtu":2}`))
	f.Add([]byte(strings.Repeat("[", 1000)))
	f.Fuzz(func(t *testing.T, data []byte) {
		if len(data) > 16400 {
			return
		}
		_, _ = parseGREConfig(data, "origin")
		_, _ = parseGREConfig(data, "egress")
	})
}

type greTestUnderlay struct {
	stats      GREStats
	errors     chan error
	closed     atomic.Bool
	closeCalls atomic.Int32
	once       sync.Once
	closeErr   error
}

func (u *greTestUnderlay) Errors() <-chan error { return u.errors }
func (u *greTestUnderlay) Stats() GREStats      { return u.stats }
func (u *greTestUnderlay) Close() error {
	u.closeCalls.Add(1)
	u.once.Do(func() {
		u.closed.Store(true)
		close(u.errors)
	})
	return u.closeErr
}

func greTestCheckConfig() *Config {
	origin, _ := greTestConfigPair()
	return &Config{Mode: "origin", GRE: origin, Transport: TransportTLS,
		Connect: "10.77.0.2:31080", ECHMode: ECHModeOff, TLSFragment: "off"}
}

func TestSpoofGRECheckSuccessCleansOwnedUnderlay(t *testing.T) {
	u := &greTestUnderlay{stats: GREStats{Sent: 3, Received: 4}, errors: make(chan error, 1)}
	startCalls, probeCalls := 0, 0
	stats, err := checkGREWith(context.Background(), greTestCheckConfig(), time.Second,
		func(config *GREConfig) (greUnderlay, error) {
			startCalls++
			return u, nil
		},
		func(ctx context.Context, cfg *Config, timeout time.Duration) (string, string, error) {
			probeCalls++
			if _, ok := ctx.Deadline(); !ok || timeout != time.Second {
				t.Fatal("probe did not receive bounded context/timeout")
			}
			return cfg.Connect, "tls", nil
		})
	if err != nil || stats != u.stats || startCalls != 1 || probeCalls != 1 || !u.closed.Load() {
		t.Fatalf("unexpected success/cleanup state stats=%+v err=%v start=%d probe=%d closed=%v", stats, err, startCalls, probeCalls, u.closed.Load())
	}
}

func TestSpoofGRECheckAuthFailureStillCleans(t *testing.T) {
	u := &greTestUnderlay{stats: GREStats{Sent: 5, Received: 5}, errors: make(chan error, 1)}
	_, err := checkGREWith(context.Background(), greTestCheckConfig(), time.Second,
		func(*GREConfig) (greUnderlay, error) { return u, nil },
		func(context.Context, *Config, time.Duration) (string, string, error) {
			return "", "", errors.New("synthetic authentication failure")
		})
	if err == nil || !strings.Contains(err.Error(), "inconclusive") || !u.closed.Load() {
		t.Fatalf("failed auth not inconclusive/cleaned: err=%v closed=%v", err, u.closed.Load())
	}
}

func TestSpoofGRECheckNoBidirectionalTrafficInconclusive(t *testing.T) {
	for _, stats := range []GREStats{{}, {Sent: 2}, {Received: 3}} {
		u := &greTestUnderlay{stats: stats, errors: make(chan error, 1)}
		_, err := checkGREWith(context.Background(), greTestCheckConfig(), time.Second,
			func(*GREConfig) (greUnderlay, error) { return u, nil },
			func(context.Context, *Config, time.Duration) (string, string, error) { return "", "", nil })
		if err == nil || !strings.Contains(err.Error(), "inconclusive") || !u.closed.Load() {
			t.Fatalf("zero-direction GRE stats %+v treated as success: %v", stats, err)
		}
	}
}

func TestSpoofGRECheckStartFailureSkipsAuth(t *testing.T) {
	probeCalled := false
	startErr := errors.New("synthetic privilege failure")
	_, err := checkGREWith(context.Background(), greTestCheckConfig(), time.Second,
		func(*GREConfig) (greUnderlay, error) { return nil, startErr },
		func(context.Context, *Config, time.Duration) (string, string, error) {
			probeCalled = true
			return "", "", nil
		})
	if !errors.Is(err, startErr) || probeCalled {
		t.Fatalf("unexpected start failure handling: err=%v probe=%v", err, probeCalled)
	}
}

func TestSpoofGRECheckCanceledBeforeStart(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	startCalled := false
	_, err := checkGREWith(ctx, greTestCheckConfig(), time.Second,
		func(*GREConfig) (greUnderlay, error) { startCalled = true; return nil, nil },
		func(context.Context, *Config, time.Duration) (string, string, error) {
			t.Fatal("probe called for already-canceled check")
			return "", "", nil
		})
	if err == nil || startCalled {
		t.Fatalf("already-canceled check started resources: %v", err)
	}
}

func TestSpoofGRECheckTimeoutCleans(t *testing.T) {
	u := &greTestUnderlay{errors: make(chan error, 1)}
	start := time.Now()
	_, err := checkGREWith(context.Background(), greTestCheckConfig(), 5*time.Millisecond,
		func(*GREConfig) (greUnderlay, error) { return u, nil },
		func(ctx context.Context, _ *Config, _ time.Duration) (string, string, error) {
			<-ctx.Done()
			return "", "", ctx.Err()
		})
	if err == nil || !strings.Contains(err.Error(), "inconclusive") || !u.closed.Load() {
		t.Fatalf("timeout not inconclusive/cleaned: err=%v closed=%v", err, u.closed.Load())
	}
	if time.Since(start) > time.Second {
		t.Fatal("cooperative probe exceeded bounded timeout")
	}
}

func TestSpoofGRECheckQueuedPlaneErrorNeverPasses(t *testing.T) {
	// Repetition exposes the watcher race when both watchDone and Errors are
	// ready before its select. No real network or scheduling sleeps are used.
	for i := 0; i < 100; i++ {
		u := &greTestUnderlay{stats: GREStats{Sent: 1, Received: 1}, errors: make(chan error, 1)}
		u.errors <- errors.New("synthetic data-plane failure")
		_, err := checkGREWith(context.Background(), greTestCheckConfig(), time.Second,
			func(*GREConfig) (greUnderlay, error) { return u, nil },
			func(context.Context, *Config, time.Duration) (string, string, error) { return "", "", nil })
		if err == nil || !u.closed.Load() {
			t.Fatalf("iteration %d: queued data-plane failure ignored: err=%v closed=%v", i, err, u.closed.Load())
		}
	}
}

func TestSpoofGRECheckPrematureErrorStreamClosureNeverPasses(t *testing.T) {
	for i := 0; i < 100; i++ {
		u := &greTestUnderlay{stats: GREStats{Sent: 1, Received: 1}, errors: make(chan error, 1)}
		// Simulate a data-plane worker that has already stopped before the
		// check owns cleanup; Close remains idempotent in this fixture.
		u.once.Do(func() { u.closed.Store(true); close(u.errors) })
		_, err := checkGREWith(context.Background(), greTestCheckConfig(), time.Second,
			func(*GREConfig) (greUnderlay, error) { return u, nil },
			func(context.Context, *Config, time.Duration) (string, string, error) { return "", "", nil })
		if err == nil {
			t.Fatalf("iteration %d: already-stopped underlay was reported successful", i)
		}
	}
}

func TestSpoofGRECheckNilErrorEventNeverPasses(t *testing.T) {
	for i := 0; i < 100; i++ {
		u := &greTestUnderlay{stats: GREStats{Sent: 1, Received: 1}, errors: make(chan error, 1)}
		u.errors <- nil
		_, err := checkGREWith(context.Background(), greTestCheckConfig(), time.Second,
			func(*GREConfig) (greUnderlay, error) { return u, nil },
			func(context.Context, *Config, time.Duration) (string, string, error) { return "", "", nil })
		if err == nil || !u.closed.Load() {
			t.Fatalf("iteration %d: malformed nil error event ignored: %v", i, err)
		}
	}
}

func TestSpoofGRECheckCleanupFailureNotPass(t *testing.T) {
	u := &greTestUnderlay{stats: GREStats{Sent: 1, Received: 1}, errors: make(chan error, 1), closeErr: errors.New("synthetic cleanup failure")}
	_, err := checkGREWith(context.Background(), greTestCheckConfig(), time.Second,
		func(*GREConfig) (greUnderlay, error) { return u, nil },
		func(context.Context, *Config, time.Duration) (string, string, error) { return "", "", nil })
	if err == nil || !strings.Contains(err.Error(), "cleanup") || !u.closed.Load() {
		t.Fatalf("cleanup failure treated as success: %v", err)
	}
}

func TestSpoofGRECheckRejectsConfigBeforeSetup(t *testing.T) {
	cases := []struct {
		name    string
		config  *Config
		timeout time.Duration
	}{
		{"nil", nil, time.Second},
		{"no_gre", &Config{Mode: "origin"}, time.Second},
		{"zero_timeout", greTestCheckConfig(), 0},
		{"long_timeout", greTestCheckConfig(), 61 * time.Second},
	}
	egress := greTestCheckConfig()
	egress.Mode, egress.GRE.Role = "egress", "egress"
	cases = append(cases, struct {
		name    string
		config  *Config
		timeout time.Duration
	}{"egress", egress, time.Second})
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			_, err := checkGREWith(context.Background(), tc.config, tc.timeout,
				func(*GREConfig) (greUnderlay, error) { t.Fatal("start called for invalid config"); return nil, nil },
				func(context.Context, *Config, time.Duration) (string, string, error) {
					t.Fatal("probe called for invalid config")
					return "", "", nil
				})
			if err == nil {
				t.Fatal("invalid check config accepted")
			}
		})
	}
}
