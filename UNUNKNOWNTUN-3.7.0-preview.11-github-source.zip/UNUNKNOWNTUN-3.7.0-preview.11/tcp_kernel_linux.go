package main

import (
	"net"
	"time"

	"golang.org/x/sys/unix"
)

func setTCPCongestion(tc *net.TCPConn, algorithm string) error {
	if algorithm == "" {
		return nil
	}
	raw, err := tc.SyscallConn()
	if err != nil {
		return err
	}
	var optionErr error
	if err := raw.Control(func(fd uintptr) {
		optionErr = unix.SetsockoptString(int(fd), unix.IPPROTO_TCP, unix.TCP_CONGESTION, algorithm)
	}); err != nil {
		return err
	}
	return optionErr
}

func readKernelTCPInfo(tc *net.TCPConn) (kernelTCPInfo, error) {
	var result kernelTCPInfo
	raw, err := tc.SyscallConn()
	if err != nil {
		return result, err
	}
	var socketErr error
	if err := raw.Control(func(fd uintptr) {
		var info *unix.TCPInfo
		info, socketErr = unix.GetsockoptTCPInfo(int(fd), unix.IPPROTO_TCP, unix.TCP_INFO)
		if socketErr != nil {
			return
		}
		result = kernelTCPInfo{
			rtt:          time.Duration(info.Rtt) * time.Microsecond,
			rto:          time.Duration(info.Rto) * time.Microsecond,
			dataSegments: info.Data_segs_out,
			totalRetrans: info.Total_retrans,
			unacked:      info.Unacked,
			lost:         info.Lost,
			backoff:      info.Backoff,
		}
	}); err != nil {
		return result, err
	}
	return result, socketErr
}
