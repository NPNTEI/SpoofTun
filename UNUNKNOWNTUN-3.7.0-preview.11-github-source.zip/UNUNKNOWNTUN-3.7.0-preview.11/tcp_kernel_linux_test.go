package main

import (
	"net"
	"testing"

	"golang.org/x/sys/unix"
)

func assertKernelTCPInfo(t *testing.T, tc *net.TCPConn) {
	t.Helper()
	if info, err := readKernelTCPInfo(tc); err != nil || info.rtt <= 0 {
		t.Fatalf("TCP_INFO unavailable after WSS handshake: info=%+v err=%v", info, err)
	}
}

func congestionOf(t *testing.T, tc *net.TCPConn) string {
	t.Helper()
	raw, err := tc.SyscallConn()
	if err != nil {
		t.Fatal(err)
	}
	var name string
	var optionErr error
	err = raw.Control(func(fd uintptr) {
		name, optionErr = unix.GetsockoptString(int(fd), unix.IPPROTO_TCP, unix.TCP_CONGESTION)
	})
	if err != nil || optionErr != nil {
		t.Fatalf("read TCP congestion: %v %v", err, optionErr)
	}
	return name
}

func TestTCPCongestionKernelPolicy(t *testing.T) {
	a, _ := tcpTestPair(t)
	initial := congestionOf(t, a)
	if err := setTCPCongestion(a, ""); err != nil || congestionOf(t, a) != initial {
		t.Fatal("default changed kernel policy")
	}
	if err := setTCPCongestion(a, initial); err != nil || congestionOf(t, a) != initial {
		t.Fatal("setting supported congestion failed")
	}
	if err := setTCPCongestion(a, "gdt_missing"); err == nil {
		t.Fatal("unsupported algorithm unexpectedly exists")
	}
	if congestionOf(t, a) != initial {
		t.Fatal("failed option changed current algorithm")
	}
}
