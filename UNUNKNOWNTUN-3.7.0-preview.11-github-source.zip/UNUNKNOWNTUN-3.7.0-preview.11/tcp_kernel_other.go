//go:build !linux

package main

import (
	"errors"
	"fmt"
	"net"
)

// Releases target Linux. Other platforms can exercise portable protocol code
// without pretending that their kernel counters have Linux TCP_INFO semantics.
func readKernelTCPInfo(_ *net.TCPConn) (kernelTCPInfo, error) {
	return kernelTCPInfo{}, fmt.Errorf("Linux TCP_INFO: %w", errors.ErrUnsupported)
}

func setTCPCongestion(_ *net.TCPConn, algorithm string) error {
	if algorithm == "" {
		return nil
	}
	return fmt.Errorf("Linux TCP_CONGESTION: %w", errors.ErrUnsupported)
}
