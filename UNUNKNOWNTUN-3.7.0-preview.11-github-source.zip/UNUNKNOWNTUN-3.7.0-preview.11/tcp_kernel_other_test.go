//go:build !linux

package main

import (
	"errors"
	"net"
	"testing"
)

func assertKernelTCPInfo(t *testing.T, tc *net.TCPConn) {
	t.Helper()
	if info, err := readKernelTCPInfo(tc); !errors.Is(err, errors.ErrUnsupported) || info != (kernelTCPInfo{}) {
		t.Fatalf("non-Linux telemetry must report unsupported: info=%+v err=%v", info, err)
	}
}

func TestTCPCongestionNonLinuxReportsUnsupported(t *testing.T) {
	a, _ := tcpTestPair(t)
	if err := setTCPCongestion(a, "bbr"); !errors.Is(err, errors.ErrUnsupported) {
		t.Fatalf("non-Linux congestion must report unsupported: %v", err)
	}
}
