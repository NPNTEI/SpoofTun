package main

import (
	"fmt"
	"log"
	"net"
	"strings"
	"sync"
)

// Written once by main before listeners and dialers start. Empty means inherit
// the kernel's policy. No sysctl, module loading or privileged setup is done.
var tcpCongestionAlgorithm string
var tcpCongestionWarning sync.Once

func normalizeTCPCongestion(value string) (string, error) {
	value = strings.ToLower(strings.TrimSpace(value))
	if value == "" || value == "default" {
		return "", nil
	}
	if len(value) > 15 {
		return "", fmt.Errorf("TCP congestion name must be at most 15 characters")
	}
	for _, r := range value {
		if (r < 'a' || r > 'z') && (r < '0' || r > '9') && r != '_' && r != '-' {
			return "", fmt.Errorf("invalid TCP congestion algorithm name")
		}
	}
	return value, nil
}

func configureTCPCongestion(tc *net.TCPConn) {
	if err := setTCPCongestion(tc, tcpCongestionAlgorithm); err != nil {
		tcpCongestionWarning.Do(func() {
			log.Printf("[warn] TCP congestion %q could not be applied (%v); connections continue with kernel policy", tcpCongestionAlgorithm, err)
		})
	}
}
