#!/usr/bin/env python3
"""Executable-level, loopback-only TLS/core/doctor integration; NOT a Nginx test.

Build the standard-library test frontend explicitly, then run this fixture:
  go build -o /path/to/private-test-dir/tls-proxy tests/loopback_tls_proxy.go
  python3 tests/core_doctor_integration.py --binary ./ununknowntun --tls-proxy /path/to/private-test-dir/tls-proxy

Exercises real subprocesses, TLS1.3, WSS/XHTTP, all XHTTP modes, MUX on/off, padding, fragmentation,
legacy aliases, positive/negative doctor reports, payload/FIN, cleanup and
new-stream recovery after killing only this fixture's own egress process.
No installation, public DNS resolution, external hosts or global state changes.
"""
import argparse
import json
from pathlib import Path
import shutil
import tempfile

from nginx_integration import run


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", required=True, type=Path)
    parser.add_argument("--tls-proxy", required=True, type=Path)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--payload-kib", type=int, default=256)
    parser.add_argument("--keep-logs", action="store_true")
    parser.add_argument("--profile-set", choices=("all", "legacy", "new"), default="all",
                        help="all:20 profiles; legacy:10 existing profiles; new:10 padded 3.6 profiles")
    args = parser.parse_args()
    if not 1 <= args.workers <= 32 or not 1 <= args.payload_kib <= 8192:
        parser.error("workers must be 1..32; payload-kib must be 1..8192")
    binary, proxy = str(args.binary.resolve(strict=True)), str(args.tls_proxy.resolve(strict=True))
    root = Path(tempfile.mkdtemp(prefix="ununknowntun-core-doctor-test-"))
    try:
        result = run(binary, proxy, root, args.workers, args.payload_kib * 1024, frontend_kind="go", profile_set=args.profile_set)
    except BaseException as exc:
        result = {"status":"FAIL", "error":str(exc), "scope":"loopback Go TLS proxy, not Nginx", "logs":str(root)}
        args.keep_logs = True
    if args.keep_logs:
        result["logs"] = str(root)
        (root / "report.json").write_text(json.dumps(result, indent=2) + "\n")
    else:
        shutil.rmtree(root)
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
