#!/usr/bin/env python3
"""Opt-in Direct ICMP console lifecycle lab for a disposable root Linux VM.

python3 -I tests/direct-icmp-console-lab.py --self-test
sudo python3 -I tests/direct-icmp-console-lab.py --run-local-lab \
  --binary /absolute/ununknowntun --output /absolute/new-report.json \
  --installer /absolute/matching-installer.sh

The real console is driven through a PTY, including exact identity confirmations.
Only random generated endpoints in owned network namespaces are changed. Existing
services, firewall rules, routes and sysctls are not altered. Work is bounded to
150 seconds plus 45 seconds cleanup; generated services also have lifetime caps.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import pty
import re
import secrets
import select
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock

sys.dont_write_bytecode = True
SOURCE = Path(__file__).resolve().parent.parent
_SPEC = importlib.util.spec_from_file_location("icmp_console_lab_helpers", Path(__file__).with_name("direct-icmp-systemd-pools-lab.py"))
lab = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(lab)
LabError, require, command = lab.LabError, lab.require, lab.command


def terminal_command(argv, replies, timeout=25):
    """Bounded terminal execution; no shell and no inherited secret environment."""
    master, slave = pty.openpty()
    process = None
    output = bytearray()
    try:
        process = subprocess.Popen([str(item) for item in argv], stdin=slave, stdout=slave, stderr=slave,
                                   start_new_session=True, close_fds=True,
                                   env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C", "TERM": "dumb"})
        os.close(slave)
        slave = -1
        payload = ("\n".join(replies) + "\n").encode()
        offset = 0
        while offset < len(payload):
            offset += os.write(master, payload[offset:])
        deadline = time.monotonic() + timeout
        while True:
            require(time.monotonic() < deadline, "Console terminal action exceeded its deadline.")
            ready, _, _ = select.select([master], [], [], .1)
            if ready:
                try:
                    data = os.read(master, 8192)
                except OSError:
                    data = b""
                if data:
                    output.extend(data)
                    require(len(output) <= 262144, "Console output exceeded its bound.")
                elif process.poll() is not None:
                    break
            elif process.poll() is not None:
                break
        require(process.wait(timeout=2) == 0, "Console process returned a nonzero status.")
        return output.decode("utf-8", errors="replace")
    finally:
        if process is not None and process.poll() is None:
            try:
                os.killpg(process.pid, signal.SIGTERM)
                process.wait(timeout=2)
            except (ProcessLookupError, subprocess.TimeoutExpired):
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait(timeout=2)
        os.close(master)
        if slave != -1:
            os.close(slave)


def selected_number(listing, identity):
    matches = re.findall(r"(?m)^(\d+)\) " + re.escape(identity) + r"  \[", listing)
    require(len(matches) == 1, "Owned endpoint is absent or ambiguous in console inventory.")
    return matches[0]


def action(console, identity, choice, mutating=False, confirmed=True):
    listing = command([sys.executable, "-I", console, "--list"], timeout=8).stdout
    replies = [selected_number(listing, identity), str(choice)]
    if mutating:
        replies.append(identity if confirmed else "")
    if not mutating or confirmed:
        replies.append("")
    replies.append("q")
    result = terminal_command([sys.executable, "-I", console], replies)
    if mutating and not confirmed:
        require("Cancelled; nothing executed." in result and "Manager exit=" not in result, "Cancelled mutation executed a manager action.")
    else:
        require("Manager exit=0." in result and "[STOP]" not in result, "Console manager action did not complete successfully.")
    return result


def run_lab(binary, helper, console, output, installer=None):
    vm = lab.preflight(binary, helper, output, installer)
    require(console.is_file() and not console.is_symlink(), "Regular console helper required.")
    # The shared existing lab provides only command/verification helpers. This
    # lab owns its separate random services, endpoint folders and namespaces.
    token = secrets.token_hex(5)
    pair_name = "lab-ui-" + token
    namespaces = {"origin": "gcuo" + token, "egress": "gcue" + token}
    links = {"origin": "gcvo" + token, "egress": "gcve" + token}
    outer = {"origin": "192.0.2.11", "egress": "192.0.2.12"}
    inner = {"origin": "10.79.232.1", "egress": "10.79.232.2"}
    stage = Path(tempfile.mkdtemp(prefix="gdt-console-lab-", dir="/var/tmp"))
    stage.chmod(0o700)
    digest = hashlib.sha256(binary.read_bytes()).hexdigest()
    arch = {"x86_64": "amd64", "aarch64": "arm64", "arm64": "arm64"}.get(platform.machine().lower())
    require(arch, "Unsupported VM architecture.")
    report = {"status": "FAIL", "kind": "local-direct-icmp-console-lifecycle", "vm": vm, "runtime_architecture": arch,
              "binary_sha256": digest, "console_sha256": hashlib.sha256(console.read_bytes()).hexdigest(), "checks": {}, "cleanup": {},
              "limitations": ["Disposable local VM and isolated namespaces only; no WAN or provider claim.", "Only this runtime architecture was executed."]}
    installed, owned_namespaces, dropins = {}, {}, {}
    created_links = False
    target, target_existed = None, True
    started = time.monotonic()
    firewall_before = command(["nft", "-j", "list", "ruleset"]).stdout
    def deadline(_signum, _frame):
        raise LabError("Console lab deadline exceeded.")
    previous = {sig: signal.signal(sig, deadline) for sig in (signal.SIGALRM, signal.SIGINT, signal.SIGTERM)}
    signal.alarm(150)
    try:
        hashes = {"amd64": "0" * 64, "arm64": "0" * 64}
        hashes[arch] = digest
        spec = {"pair_id": pair_name, "binary_sha256": hashes, "mtu": 1200, "poll_ms": 20,
                "timeout_seconds": 5, "rekey_seconds": 3600, "fec_mode": "off", "source_rotation": "off",
                "forwards": [{"iran_port": 12055, "foreign_port": 18082, "protocol": "tcp", "relay_port": 28082}],
                **{role: {"interface": "gdt0", "real_ip": outer[role], "inner_ip": inner[role]} for role in namespaces}}
        pair = stage / "pair"
        spec_file = stage / "spec.json"
        lab.private_write(spec_file, (json.dumps(spec) + "\n").encode())
        command([sys.executable, "-I", helper, "--spec", spec_file, "--output", pair], timeout=10)
        command([sys.executable, "-I", helper, "--check-pair", pair], timeout=10)
        for role, namespace in namespaces.items():
            require(not (Path("/run/netns") / namespace).exists(), "Random namespace already exists.")
            command(["ip", "netns", "add", namespace])
            owned_namespaces[namespace] = lab.identity(Path("/run/netns") / namespace)
        for link in links.values():
            require(command(["ip", "link", "show", link], check=False).returncode != 0, "Random link already exists.")
        command(["ip", "link", "add", links["origin"], "type", "veth", "peer", "name", links["egress"]])
        created_links = True
        for role, namespace in namespaces.items():
            command(["ip", "link", "set", links[role], "netns", namespace])
            command(["ip", "-n", namespace, "link", "set", links[role], "name", "gdt0"])
            command(["ip", "-n", namespace, "address", "add", outer[role] + "/24", "dev", "gdt0"])
            command(["ip", "-n", namespace, "link", "set", "gdt0", "up"])
            command(["ip", "-n", namespace, "link", "set", "lo", "up"])
        for role in ("egress", "origin"):
            folder = pair / role
            metadata = json.loads((folder / "endpoint.json").read_text())
            destination = Path(metadata["install_dir"])
            unit = metadata["unit_name"]
            unit_path = Path("/etc/systemd/system") / unit
            require(not destination.exists() and not destination.is_symlink() and not unit_path.exists() and not unit_path.is_symlink(), "Refusing existing endpoint/unit.")
            if target is None:
                target = Path(metadata["binary_path"])
                target_existed = target.exists() or target.is_symlink()
            command([sys.executable, "-I", folder / "manage.py", "install", "--binary", binary], timeout=20)
            installed[role] = {"folder": destination, "unit": unit, "metadata": metadata}
            require(command(["systemctl", "is-active", "--quiet", unit], check=False).returncode != 0, "Install unexpectedly started service.")
            dropin = Path("/run/systemd/system") / (unit + ".d")
            require(not dropin.exists() and not dropin.is_symlink(), "Refusing existing service drop-in.")
            dropin.mkdir(mode=0o700)
            payload = ("[Unit]\nStartLimitIntervalSec=300s\nStartLimitBurst=3\n[Service]\nNetworkNamespacePath=/run/netns/" + namespaces[role] + "\nRuntimeMaxSec=100s\n").encode()
            lab.private_write(dropin / "10-lab.conf", payload)
            dropins[role] = dropin, payload
        command(["systemctl", "daemon-reload"], timeout=15)
        shutil.rmtree(pair)
        report["checks"]["generated_install_without_start"] = True
        listing = command([sys.executable, "-I", console, "--list"], timeout=8).stdout
        for role in installed:
            selected_number(listing, pair_name + "/" + role)
        require("0.0.0.0:12055" in listing and "127.0.0.1:18082" in listing, "Forward mapping missing from list.")
        for item in installed.values():
            require((item["folder"] / "icmp.key").read_text().strip() not in listing, "List disclosed a key.")
            require(command(["systemctl", "is-active", "--quiet", item["unit"]], check=False).returncode != 0, "Read-only list started a service.")
        report["checks"]["console_list_private_mapping_and_no_mutation"] = True
        if installer is not None:
            standalone = command(["/bin/bash", installer, "direct-icmp-manage", "--list"], timeout=20).stdout
            for role in installed:
                selected_number(standalone, pair_name + "/" + role)
            for item in installed.values():
                require(command(["systemctl", "is-active", "--quiet", item["unit"]], check=False).returncode != 0,
                        "Standalone read-only inventory changed a service.")
            report["checks"]["standalone_direct_icmp_manage_list"] = True
            report["installer_sha256"] = hashlib.sha256(installer.read_bytes()).hexdigest()
        for role in ("egress", "origin"):
            action(console, pair_name + "/" + role, 2, mutating=True)
        def wait_ping():
            until = time.monotonic() + 12
            while command(["ip", "netns", "exec", namespaces["origin"], "ping", "-n", "-c", "1", "-W", "1", inner["egress"]], timeout=3, check=False).returncode:
                require(time.monotonic() < until, "Private tunnel ping did not recover.")
        wait_ping()
        for role, item in installed.items():
            report["checks"][role] = lab.verify_process(lab.systemd_state(item["unit"]), namespaces[role])
            status = action(console, pair_name + "/" + role, 1)
            require("active (running)" in status, "Console status did not report the running service.")
            info = action(console, pair_name + "/" + role, 7)
            require('"port_forwards"' in info and '"pair_id": "' + pair_name + '"' in info, "Console info lacks safe mapping summary.")
            require((item["folder"] / "icmp.key").read_text().strip() not in info, "Info disclosed a key.")
        report["checks"]["console_start_status_info_real_systemd"] = True
        peer_pid = lab.systemd_state(installed["egress"]["unit"])["MainPID"]
        origin_pid = lab.systemd_state(installed["origin"]["unit"])["MainPID"]
        action(console, pair_name + "/origin", 4, mutating=True, confirmed=False)
        require(lab.systemd_state(installed["origin"]["unit"])["MainPID"] == origin_pid, "Cancelled restart changed the service.")
        action(console, pair_name + "/origin", 4, mutating=True)
        wait_ping()
        require(lab.systemd_state(installed["origin"]["unit"])["MainPID"] not in ("0", origin_pid), "Confirmed restart did not replace process.")
        action(console, pair_name + "/origin", 3, mutating=True)
        require(command(["systemctl", "is-active", "--quiet", installed["origin"]["unit"]], check=False).returncode != 0, "Console stop left service active.")
        action(console, pair_name + "/origin", 2, mutating=True)
        wait_ping()
        require(lab.systemd_state(installed["egress"]["unit"])["MainPID"] == peer_pid, "Origin lifecycle changed peer process.")
        report["checks"]["confirmed_restart_stop_start_and_peer_preservation"] = True
        for role, item in installed.items():
            action(console, pair_name + "/" + role, 8, mutating=True)
            require(not item["folder"].exists() and not (Path("/etc/systemd/system") / item["unit"]).exists(), "Confirmed uninstall left endpoint/unit.")
            item["removed"] = True
        report["checks"]["exact_identity_console_uninstall"] = True
        require(command(["nft", "-j", "list", "ruleset"]).stdout == firewall_before, "Host firewall changed.")
        report["checks"]["host_firewall_preserved"] = True
        report["status"] = "PASS"
    except BaseException as error:
        report["error"] = str(error)[:1600] or type(error).__name__
    finally:
        signal.alarm(45)
        errors = []
        for role, item in installed.items():
            try:
                if not item.get("removed"):
                    command([sys.executable, "-I", item["folder"] / "manage.py", "uninstall"], timeout=18)
                report["cleanup"][role + "_endpoint"] = not item["folder"].exists()
            except Exception as error:
                errors.append("endpoint " + role + ": " + str(error)[:300])
                unit_path = Path("/etc/systemd/system") / item["unit"]
                if unit_path.is_file() and not unit_path.is_symlink() and hashlib.sha256(unit_path.read_bytes()).hexdigest() == item["metadata"]["files"][item["unit"]]:
                    command(["systemctl", "disable", "--now", item["unit"]], check=False, timeout=18)
        for role, (folder, payload) in dropins.items():
            try:
                path = folder / "10-lab.conf"
                require(not path.is_symlink() and path.read_bytes() == payload and {p.name for p in folder.iterdir()} == {"10-lab.conf"}, "Owned drop-in changed.")
                path.unlink()
                folder.rmdir()
            except Exception as error:
                errors.append("drop-in " + role + ": " + str(error)[:300])
        if installed:
            command(["systemctl", "daemon-reload"], timeout=10, check=False)
            for item in installed.values():
                command(["systemctl", "reset-failed", item["unit"]], timeout=3, check=False)
        for name, expected in owned_namespaces.items():
            try:
                path = Path("/run/netns") / name
                require(path.exists() and lab.identity(path) == expected, "Namespace ownership changed.")
                command(["ip", "netns", "delete", name], timeout=5)
                report["cleanup"][name] = not path.exists()
            except Exception as error:
                errors.append("namespace " + name + ": " + str(error)[:300])
        if created_links:
            for link in links.values():
                if command(["ip", "link", "show", link], check=False, timeout=3).returncode == 0:
                    command(["ip", "link", "delete", link], check=False, timeout=3)
        if target is not None and not target_existed and target.exists():
            try:
                remaining = list(Path("/etc/ununknowntun-direct-icmp").glob("*/*/endpoint.json"))
                used = any(json.loads(path.read_text()).get("binary_path") == str(target) for path in remaining)
                if not used and not target.is_symlink() and hashlib.sha256(target.read_bytes()).hexdigest() == digest:
                    target.unlink()
                    target.parent.rmdir()
                    report["cleanup"]["owned_binary_removed"] = True
            except Exception as error:
                errors.append("binary: " + str(error)[:300])
        if errors:
            report["status"] = "FAIL"
            report["cleanup_errors"] = errors
            report["retained_private_fixture"] = str(stage)
        else:
            shutil.rmtree(stage)
            report["cleanup"]["private_fixture_removed"] = True
        signal.alarm(0)
        for sig, handler in previous.items():
            signal.signal(sig, handler)
        report["elapsed_seconds"] = round(time.monotonic() - started, 3)
        lab.private_write(output, (json.dumps(report, indent=2, sort_keys=True) + "\n").encode())
    print(json.dumps({"status": report["status"], "report": str(output), "runtime_architecture": arch}))
    return 0 if report["status"] == "PASS" else 1


class OfflineTests(unittest.TestCase):
    def test_index_is_exact_pair_role(self):
        self.assertEqual(selected_number("1) other/origin  [v]\n2) lab/origin  [v]\n", "lab/origin"), "2")
        with self.assertRaises(LabError):
            selected_number("1) lab/origin-extra  [v]\n", "lab/origin")
        with self.assertRaises(LabError):
            selected_number("1) lab/origin  [v]\n2) lab/origin  [v]\n", "lab/origin")

    def test_pty_is_real_terminal_and_captures_input(self):
        script = "import sys; assert sys.stdin.isatty() and sys.stdout.isatty(); print('got='+input())"
        self.assertIn("got=hello", terminal_command([sys.executable, "-I", "-c", script], ["hello"], timeout=5))

    def test_timeout_is_bounded(self):
        with self.assertRaises(LabError):
            terminal_command([sys.executable, "-I", "-c", "import time; time.sleep(30)"], [], timeout=.2)

    def test_action_requires_exact_confirmation_and_real_success(self):
        with mock.patch(__name__ + ".command", return_value=type("Reply", (), {"stdout": "2) demo/origin  [v]\n"})()), \
                mock.patch(__name__ + ".terminal_command", return_value="Manager exit=0.") as terminal:
            action(Path("/fixed/console.py"), "demo/origin", 8, mutating=True)
            self.assertEqual(terminal.call_args.args[1], ["2", "8", "demo/origin", "", "q"])
            terminal.return_value = "Manager exit=1."
            with self.assertRaises(LabError):
                action(Path("/fixed/console.py"), "demo/origin", 1)

    def test_cancel_has_no_success_claim(self):
        with mock.patch(__name__ + ".command", return_value=type("Reply", (), {"stdout": "1) demo/origin  [v]\n"})()), \
                mock.patch(__name__ + ".terminal_command", return_value="Cancelled; nothing executed.") as terminal:
            action(Path("/fixed/console.py"), "demo/origin", 4, mutating=True, confirmed=False)
            self.assertEqual(terminal.call_args.args[1], ["1", "4", "", "q"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--run-local-lab", action="store_true")
    parser.add_argument("--binary", type=Path)
    parser.add_argument("--helper", type=Path, default=SOURCE / "packaging/direct-icmp-pair.py")
    parser.add_argument("--console", type=Path, default=SOURCE / "packaging/direct-icmp-console.py")
    parser.add_argument("--installer", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.self_test:
        require(not args.run_local_lab and args.binary is None and args.output is None and args.installer is None, "Self-test cannot run a live lab.")
        result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(OfflineTests))
        return 0 if result.wasSuccessful() else 1
    require(args.run_local_lab and args.binary and args.output, "Explicit --run-local-lab --binary --output required.")
    return run_lab(args.binary.absolute(), args.helper.absolute(), args.console.absolute(), args.output.absolute(),
                   args.installer.absolute() if args.installer is not None else None)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (LabError, OSError, subprocess.SubprocessError) as error:
        print("DIRECT ICMP CONSOLE LAB ERROR: " + str(error), file=sys.stderr)
        raise SystemExit(1)
