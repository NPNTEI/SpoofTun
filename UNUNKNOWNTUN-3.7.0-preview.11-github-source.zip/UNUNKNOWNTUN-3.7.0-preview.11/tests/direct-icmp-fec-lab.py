#!/usr/bin/env python3
"""Opt-in FEC loss comparison in newly owned local Linux VM namespaces.

No public endpoints or host firewall/routing changes. UDP packets are sent once
at a controlled application rate, not retried, so recovery is distinguishable
from TCP or application retransmission. Reports random-netem evidence, not WAN
performance guarantees or deterministic cross-mode bandwidth comparisons.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import secrets
import shutil
import signal
import sys
import tempfile
import time

sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location("fec_lab_base", Path(__file__).with_name("direct-icmp-netns-lab.py"))
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
require = base.require
COUNT = 800
RATE = 80
PAYLOAD = 700
RECEIVER = r'''
import socket,time,json,sys
ip,count,size=sys.argv[1],int(sys.argv[2]),int(sys.argv[3])
s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.bind((ip,19003)); s.settimeout(.2)
seen=set(); duplicates=0; corrupt=0; end=time.monotonic()+13
print('READY',flush=True)
while time.monotonic()<end:
    try: b,_=s.recvfrom(65535)
    except socket.timeout: continue
    seq=int.from_bytes(b[:4],'big')
    expected=seq.to_bytes(4,'big')+bytes([seq%251])*(size-4)
    if seq>=count or b!=expected: corrupt+=1; continue
    if seq in seen: duplicates+=1
    seen.add(seq)
print('RESULT='+json.dumps(dict(received=len(seen),duplicates=duplicates,corrupt=corrupt)),flush=True)
'''
SENDER = r'''
import socket,time,sys,json
ip,count,rate,size=sys.argv[1],int(sys.argv[2]),int(sys.argv[3]),int(sys.argv[4])
s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.connect((ip,19003)); start=time.monotonic()
for seq in range(count):
    delay=start+seq/rate-time.monotonic()
    if delay>0: time.sleep(delay)
    b=seq.to_bytes(4,'big')+bytes([seq%251])*(size-4)
    assert s.send(b)==size
print(json.dumps(dict(sent=count,bytes=count*size)),flush=True)
'''


class FECLab(base.Lab):
    modes = ("off", "fixed", "adaptive")
    burst_loss = False
    def execute(self, binary):
        require(platform.system() == "Linux" and os.geteuid() == 0, "Requires local disposable Linux VM/root")
        for tool in ("ip", "timeout", "ping", "tc", "systemd-detect-virt"):
            self.tools[tool] = shutil.which(tool, path="/usr/sbin:/usr/bin:/sbin:/bin")
            require(self.tools[tool], "Missing " + tool)
        self.run([self.tools["systemd-detect-virt"], "--vm", "--quiet"])
        base.common.verify_lab_parent(Path("/var/tmp"))
        os.umask(0o077)
        self.directory = Path(tempfile.mkdtemp(prefix=self.prefix + "-fec-", dir="/var/tmp"))
        self.directory_identity = base.common.identity(self.directory)
        exe, digest = self.snapshot_binary(Path(binary))
        version = self.run([str(exe), "-version"])[1].strip()
        self.host_routes = self.ip("-j", "-4", "route", "show", "table", "all")[1]
        self.forwarding = Path("/proc/sys/net/ipv4/ip_forward").read_text()
        a, b = self.prefix + "-a", self.prefix + "-b"
        self.own_namespace(a); self.own_namespace(b)
        self.ip("-n", a, "link", "add", "dic-a", "type", "veth", "peer", "name", "dic-b", "netns", b)
        for ns, dev, ips in ((a, "dic-a", base.OUTER), (b, "dic-b", base.OUTER[::-1])):
            self.ip("-n", ns, "link", "set", "lo", "up")
            self.ip("-n", ns, "address", "add", ips[0] + "/32", "dev", dev)
            self.ip("-n", ns, "link", "set", dev, "up")
            self.ip("-n", ns, "route", "add", ips[1] + "/32", "dev", dev, "src", ips[0])
        secret = secrets.token_hex(32); self.private_values.append(secret)
        self.private_file(self.directory / "key", secret + "\n")
        runs = []
        for mode in self.modes:
            processes = []
            for role, ns, dev, ips, inners in (("origin", a, "dic-a", base.OUTER, base.INNER), ("egress", b, "dic-b", base.OUTER[::-1], base.INNER[::-1])):
                cfg = dict(role=role, interface=dev, tun_name="dic-tun", local_ip=ips[0], peer_ip=ips[1],
                           inner_local_ip=inners[0], inner_peer_ip=inners[1], key_file=str(self.directory / "key"),
                           mtu=1200, poll_ms=5, timeout_seconds=5, rekey_seconds=60,
                           fec_mode=mode, fec_percent=20, fec_max_percent=25, fec_block_ms=20)
                path = self.directory / (mode + "-" + role + ".json")
                self.private_file(path, json.dumps(cfg))
                processes.append(self.start(ns, [str(exe), "-direct-icmp-config", str(path)], mode + "-" + role))
            self.wait_ping(a, base.INNER[1]); self.wait_ping(b, base.INNER[0])
            transfers = []
            for label, src, dst, dev, target in (("uplink", a, b, "dic-a", base.INNER[1]), ("downlink", b, a, "dic-b", base.INNER[0])):
                # Independent 8% loss, or a two-state burst model. Different modes
                # receive independent random samples, recorded as such.
                model = ["gemodel", "5%", "50%", "90%", "0%"] if self.burst_loss else ["8%"]
                self.run(self.ns(src, [self.tools["tc"], "qdisc", "add", "dev", dev, "root", "netem", "loss", *model]))
                name = mode + "-" + label + "-receiver"
                receiver = self.start(dst, [sys.executable, "-I", "-u", "-c", RECEIVER, target, str(COUNT), str(PAYLOAD)], name)
                log = self.directory / (name + ".log")
                deadline = time.monotonic() + 3
                while time.monotonic() < deadline and "READY" not in log.read_text(): time.sleep(.05)
                require("READY" in log.read_text(), "Receiver failed to bind")
                _, output, _ = self.run(self.ns(src, [sys.executable, "-I", "-c", SENDER, target, str(COUNT), str(RATE), str(PAYLOAD)]), seconds=14)
                sent = json.loads(output)
                receiver.wait(timeout=6)
                records = [json.loads(line[7:]) for line in log.read_text().splitlines() if line.startswith("RESULT=")]
                require(receiver.returncode == 0 and len(records) == 1, "Missing UDP receiver result")
                measured = records[0]
                require(measured["corrupt"] == 0 and measured["duplicates"] == 0, "Corrupt or duplicate inner datagram")
                require(COUNT*.6 < measured["received"] <= COUNT, "Excessive data loss or duplicate counting")
                self.run(self.ns(src, [self.tools["tc"], "qdisc", "del", "dev", dev, "root"]))
                transfers.append(dict(direction=label, **sent, **measured, loss_percent=round(100*(COUNT-measured["received"])/COUNT,2)))
            self.wait_ping(a, base.INNER[1]); self.wait_ping(b, base.INNER[0])
            for p in processes:
                self.stop(p)
                require(p.returncode == 0, "Tunnel failed graceful stop")
            stats = {}
            for role in ("origin", "egress"):
                content = (self.directory / (mode + "-" + role + ".log")).read_text()
                final = [line for line in content.splitlines() if "stopped; owned TUN/routes removed; engine=" in line]
                require(len(final) == 1, "Missing final authenticated runtime statistics")
                content = final[0]
                values = {}
                for key in ("FECPercent", "FECRawSamples", "FECRawLost", "FECResidualLost", "FECRecovered", "FECRepairPackets", "FECSourcePackets", "FECFeedbackReports", "LocalSendFailures", "WireSuccessful", "RateBurst"):
                    found = re.findall(r"\b" + key + r":(\d+)", content)
                    require(found, "Missing final engine statistic " + key)
                    values[key] = int(found[-1])
                print(json.dumps(dict(mode=mode, role=role, transfers=transfers, stats=values)), file=sys.stderr, flush=True)
                if mode != "off":
                    require(values["FECRecovered"] > 0, "No FEC recovery observed for " + role)
                    require(values["FECRepairPackets"] > 0, "No repair packets transmitted for " + role)
                    require(values["FECRepairPackets"]*100 <= values["FECSourcePackets"]*(20 if mode == "fixed" else 25), "Repair packet cap exceeded")
                if mode == "adaptive":
                    require(values["FECRawSamples"] >= 64 and values["FECRawLost"] > 0, "No authenticated directional loss evidence")
                stats[role] = values
            runs.append(dict(mode=mode, transfers=transfers, stats=stats))
            for ns in (a,b):
                require(self.ip("-n",ns,"link","show","dic-tun",check=False)[0]!=0,"Owned TUN left behind")
        require(self.ip("-j","-4","route","show","table","all")[1]==self.host_routes and
                Path("/proc/sys/net/ipv4/ip_forward").read_text()==self.forwarding,"Host routing/sysctl changed")
        return dict(status="PASS", binary_version=version, binary_sha256=digest, architecture=platform.machine(), loss_model=("gemodel 5% 50% 90% 0%" if self.burst_loss else "independent 8%"), runs=runs,
                    scope="Local Linux namespace UDP, netem loss one direction at a time; random samples differ across runs; no WAN/provider/production claim")


def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument("--binary",required=True); p.add_argument("--mode", action="append", choices=("off","fixed","adaptive")); p.add_argument("--burst",action="store_true"); args=p.parse_args()
    lab=FECLab(); lab.burst_loss=args.burst; report=None
    if args.mode: lab.modes=tuple(dict.fromkeys(args.mode))
    for sig in (signal.SIGTERM,signal.SIGINT): signal.signal(sig,lambda *_:setattr(lab,"interrupted",True))
    try: report=lab.execute(args.binary)
    except Exception as e:
        lab.diagnostics(); print("FAIL:",base.common.diagnostic_text(str(e),lab.private_values),file=sys.stderr)
    finally:
        failures=lab.cleanup()
        if failures: print("CLEANUP FAILURE:",failures,file=sys.stderr); report=None
    if report: print(json.dumps(report,indent=2,sort_keys=True)); return 0
    return 1

if __name__=="__main__": raise SystemExit(main())
