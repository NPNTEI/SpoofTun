#!/usr/bin/env python3
"""Opt-in application forwarding test inside disposable Linux VM namespaces.

Actual concurrent TCP/UDP -> built-in origin relay -> encrypted ICMP -> egress
relay -> wildcard-bound application, with private source pools enabled. No
public traffic, production service, host route/firewall or global sysctl change.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import secrets
import shutil
import signal
import sys
import tempfile
import time
import unittest

sys.dont_write_bytecode = True
loader = importlib.util.spec_from_file_location("forward_pool_lab", Path(__file__).with_name("direct-icmp-pools-lab.py"))
pools = importlib.util.module_from_spec(loader)
loader.loader.exec_module(pools)
base, require = pools.base, pools.require
OUTER, INNER, POOLS = pools.OUTER, pools.INNER, pools.POOLS
ENTRY_PORTS = (12055, 12056)
RELAY_PORT, SERVICE_PORT = 45082, 18082

SERVER = r'''
import socket,threading,time,sys
port=int(sys.argv[1]);tcp=socket.socket();tcp.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
tcp.bind(('0.0.0.0',port));tcp.listen(32)
udp=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);udp.bind(('0.0.0.0',port))
def echo(c):
 with c:
  c.settimeout(20)
  try:
   while True:
    data=c.recv(65536)
    if not data:break
    c.sendall(data)
  except OSError:pass
def accept():
 while True:
  c,_=tcp.accept();threading.Thread(target=echo,args=(c,),daemon=True).start()
def datagrams():
 while True:
  data,addr=udp.recvfrom(65535);udp.sendto(data,addr)
threading.Thread(target=accept,daemon=True).start();threading.Thread(target=datagrams,daemon=True).start()
print('READY',flush=True);time.sleep(145)
'''

CLIENT = r'''
import socket,hashlib,json,sys,concurrent.futures,threading
proto=sys.argv[1];ports=[int(p) for p in sys.argv[2:]]
def exercise(index):
 port=ports[index%len(ports)];size=65536 if proto=='tcp' else 4000
 payload=(bytes([index])+bytes(range(256)))*((size//257)+1);payload=payload[:size]
 with socket.socket(socket.AF_INET,socket.SOCK_STREAM if proto=='tcp' else socket.SOCK_DGRAM) as s:
  s.settimeout(15);s.connect(('127.0.0.1',port))
  if proto=='tcp':
   errors=[]
   def send():
    try:s.sendall(payload);s.shutdown(socket.SHUT_WR)
    except OSError as e:errors.append(str(e))
   worker=threading.Thread(target=send,daemon=True);worker.start();result=b''
   while True:
    chunk=s.recv(65536)
    if not chunk:break
    result+=chunk
    assert len(result)<=len(payload),'extra TCP bytes'
   worker.join(15);assert not worker.is_alive() and not errors,errors
  else:
   s.settimeout(2);result=b''
   for attempt in range(4):
    s.send(payload)
    try:result=s.recv(65535);break
    except socket.timeout:pass
  assert result==payload,(proto,index,len(result),len(payload))
  return {'client':index,'port':port,'bytes':len(result),'sha256':hashlib.sha256(result).hexdigest()}
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
 results=list(executor.map(exercise,range(6)))
print(json.dumps({'protocol':proto,'clients':results,'verified':True},sort_keys=True))
'''

# Packet sockets stay inside the owned egress namespace. SOCK_DGRAM removes
# link headers, including on a TUN, so each received frame starts at IPv4.
POOL_CAPTURE = r'''
import socket,struct,time,json,signal,sys
active=True
def stop(*unused):
 global active
 active=False
signal.signal(signal.SIGTERM,stop)
s=socket.socket(socket.AF_PACKET,socket.SOCK_DGRAM,0);s.bind((sys.argv[1],0x0800));s.settimeout(.2)
target=socket.inet_aton(sys.argv[2]);port=int(sys.argv[3]);sources={};end=time.monotonic()+145
print('READY',flush=True)
while active and time.monotonic()<end:
 try:packet=s.recv(65536)
 except socket.timeout:continue
 if len(packet)<24 or packet[0]>>4!=4 or packet[9] not in (6,17) or packet[16:20]!=target:continue
 header=(packet[0]&15)*4
 if len(packet)<header+4 or int.from_bytes(packet[6:8],'big')&0x1fff:continue
 if int.from_bytes(packet[header+2:header+4],'big')!=port:continue
 proto=str(packet[9]);sources.setdefault(proto,set()).add(socket.inet_ntoa(packet[12:16]))
print('RESULT='+json.dumps({'complete':not active,'sources':{p:sorted(v) for p,v in sources.items()}}),flush=True)
'''

PORTS_FREE = r'''
import socket,sys
opened=[]
try:
 for port in map(int,sys.argv[1:]):
  for kind in (socket.SOCK_STREAM,socket.SOCK_DGRAM):
   s=socket.socket(socket.AF_INET,kind);opened.append(s)
   if kind==socket.SOCK_STREAM:s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
   s.bind(('0.0.0.0',port))
 print('FREE')
finally:
 for s in opened:s.close()
'''


def config(role, key_path, fec_mode='off'):
    require(fec_mode in ('off', 'fixed', 'adaptive'), 'Unsupported FEC mode')
    origin = role == 'origin'
    ips, inners, ranges = (OUTER, INNER, POOLS) if origin else (OUTER[::-1], INNER[::-1], POOLS[::-1])
    target = INNER[1] + ':' + str(RELAY_PORT)
    forwards = ([{'protocol': proto, 'listen': '0.0.0.0:' + str(port), 'target': target}
                 for port in ENTRY_PORTS for proto in ('tcp', 'udp')] if origin else
                [{'protocol': proto, 'listen': target, 'target': '127.0.0.1:' + str(SERVICE_PORT)} for proto in ('tcp', 'udp')])
    return {'role': role, 'interface': 'dic-a' if origin else 'dic-b', 'tun_name': 'dic-tun',
            'local_ip': ips[0], 'peer_ip': ips[1], 'inner_local_ip': inners[0], 'inner_peer_ip': inners[1],
            'key_file': str(key_path), 'local_pool_cidr': ranges[0], 'peer_pool_cidr': ranges[1],
            'source_rotation': 'round-robin', 'mtu': 1200, 'poll_ms': 5, 'timeout_seconds': 5,
            'rekey_seconds': 60, 'fec_mode': fec_mode, 'fec_percent': 20, 'fec_max_percent': 25,
            'fec_block_ms': 20, 'forward_idle_seconds': 30, 'port_forwards': forwards}


def validate_result(result, protocol):
    require(result['protocol'] == protocol and result['verified'] is True and len(result['clients']) == 6,
            'Missing concurrent client evidence')
    require({row['client'] for row in result['clients']} == set(range(6)), 'Missing/duplicate client')
    for row in result['clients']:
        size = 65536 if protocol == 'tcp' else 4000
        payload = ((bytes([row['client']]) + bytes(range(256))) * (size // 257 + 1))[:size]
        require(row['port'] == ENTRY_PORTS[row['client'] % 2] and row['bytes'] == size and
                row['sha256'] == hashlib.sha256(payload).hexdigest(), 'Forwarded payload SHA256 differs')


class Lab(pools.Lab):
    def __init__(self, fec_mode='off'):
        super().__init__()
        self.fec_mode = fec_mode
        self.prefix = 'gdt-fw-' + secrets.token_hex(4)
        self.work_end = self.started + 135
        self.end = self.started + 165

    def wait_ready(self, process, name):
        end = min(self.work_end, time.monotonic() + 5)
        while time.monotonic() < end:
            self.remaining()
            require(process.poll() is None, name + ' exited before readiness')
            if 'READY' in (self.directory / (name + '.log')).read_text():
                return
            time.sleep(.05)
        require(False, name + ' readiness deadline expired')

    def clients(self, namespace):
        results = []
        for proto in ('tcp', 'udp'):
            output = self.run(self.ns(namespace, [sys.executable, '-I', '-c', CLIENT, proto, *map(str, ENTRY_PORTS)]), seconds=35)[1]
            result = json.loads(output)
            validate_result(result, proto)
            results.append(result)
        return results

    def execute(self, binary):
        require(platform.system() == 'Linux' and os.geteuid() == 0, 'Requires disposable Linux VM/root')
        for tool in ('ip', 'timeout', 'ping', 'nft', 'systemd-detect-virt'):
            self.tools[tool] = shutil.which(tool, path='/usr/sbin:/usr/bin:/sbin:/bin')
            require(self.tools[tool], 'Missing tool: ' + tool)
        self.run([self.tools['systemd-detect-virt'], '--vm', '--quiet'])
        base.common.verify_lab_parent(Path('/var/tmp'))
        os.umask(0o077)
        self.directory = Path(tempfile.mkdtemp(prefix=self.prefix + '-', dir='/var/tmp'))
        self.directory_identity = base.common.identity(self.directory)
        exe, digest = self.snapshot_binary(Path(binary))
        version = self.run([str(exe), '-version'])[1].strip()
        host_routes = self.ip('-j', '-4', 'route', 'show', 'table', 'all')[1]
        host_forwarding = Path('/proc/sys/net/ipv4/ip_forward').read_text()
        host_nft = self.run([self.tools['nft'], '-j', 'list', 'ruleset'])[1]
        a, b = self.prefix + '-a', self.prefix + '-b'
        self.own_namespace(a); self.own_namespace(b)
        self.ip('-n', a, 'link', 'add', 'dic-a', 'type', 'veth', 'peer', 'name', 'dic-b', 'netns', b)
        table = 'gdt_icmp_' + hashlib.sha256(b'dic-tun').hexdigest()[:16]
        for ns, dev, ips in ((a, 'dic-a', OUTER), (b, 'dic-b', OUTER[::-1])):
            self.ip('-n', ns, 'link', 'set', 'lo', 'up')
            self.ip('-n', ns, 'addr', 'add', ips[0] + '/32', 'dev', dev)
            self.ip('-n', ns, 'link', 'set', dev, 'up')
            self.ip('-n', ns, 'route', 'add', ips[1] + '/32', 'dev', dev, 'src', ips[0])
            inode = self.run(self.ns(ns, [sys.executable, '-I', '-c', "import os;print(os.stat('/proc/self/ns/net').st_ino)"]))[1].strip()
            self.lease_files.append(Path('/run/ununknowntun-icmp-rr') / (inode + '-' + table + '.lock'))
        key = secrets.token_hex(32); self.private_values.append(key)
        self.private_file(self.directory / 'key', key + '\n')
        paths = []
        for role in ('origin', 'egress'):
            path = self.directory / (role + '.json')
            self.private_file(path, json.dumps(config(role, self.directory / 'key', self.fec_mode)))
            paths.append(path)
            self.run([str(exe), '-check-direct-icmp-config', str(path)])
        # The real application already owns both wildcard service ports before
        # ICMP starts. A same-port private relay would fail this setup.
        server = self.start(b, [sys.executable, '-I', '-u', '-c', SERVER, str(SERVICE_PORT)], 'server-app')
        self.wait_ready(server, 'server-app')
        peer = self.start(b, [str(exe), '-direct-icmp-config', str(paths[1])], 'egress')
        client = self.start(a, [str(exe), '-direct-icmp-config', str(paths[0])], 'origin')
        self.wait_ping(a, INNER[1]); self.wait_ping(b, INNER[0])
        capture = self.start(b, [sys.executable, '-I', '-u', '-c', POOL_CAPTURE, 'dic-tun', INNER[1], str(RELAY_PORT)], 'inner-capture')
        self.wait_ready(capture, 'inner-capture')
        self.checks['concurrent_clients_tcp_halfclose_udp_fragment_sha256'] = self.clients(a)
        require(server.poll() is None and client.poll() is None and peer.poll() is None, 'Payload test killed a service')
        self.checks['wildcard_application_private_relay_coexist'] = True
        self.stop(capture)
        records = [json.loads(line[7:]) for line in (self.directory / 'inner-capture.log').read_text().splitlines() if line.startswith('RESULT=')]
        require(len(records) == 1 and records[0]['complete'], 'Missing complete private-flow capture')
        for proto in ('6', '17'):
            require(set(records[0]['sources'].get(proto, [])) == {'10.79.1.1', '10.79.1.2'}, 'Forward connections did not traverse both private source pool addresses')
        self.checks['forward_dials_traverse_round_robin_pool'] = records[0]
        self.stop(client); self.stop(peer)
        for ns, ports in ((a, ENTRY_PORTS), (b, (RELAY_PORT,))):
            output = self.run(self.ns(ns, [sys.executable, '-I', '-c', PORTS_FREE, *map(str, ports)]))[1]
            require(output.strip() == 'FREE', 'Forward listener leaked after tunnel stop')
            require(self.ip('-n', ns, 'link', 'show', 'dic-tun', check=False)[0] != 0, 'Owned TUN leaked')
            require(self.nft(ns, 'list', 'table', 'ip', table, check=False)[0] != 0, 'Owned source-pool table leaked')
        require(server.poll() is None, 'Stopping tunnel killed unrelated application')
        self.checks['stop_closes_tcp_udp_listeners_preserves_application'] = True
        # Reuse the exact same ports after graceful cleanup, then prove payload
        # again. This is a service lifecycle test, not an outage-free claim.
        peer = self.start(b, [str(exe), '-direct-icmp-config', str(paths[1])], 'egress-restarted')
        client = self.start(a, [str(exe), '-direct-icmp-config', str(paths[0])], 'origin-restarted')
        self.wait_ping(a, INNER[1])
        self.clients(a)
        self.stop(client); self.stop(peer)
        self.checks['same_port_restart_payload'] = True
        require(host_routes == self.ip('-j', '-4', 'route', 'show', 'table', 'all')[1], 'Host routes changed')
        require(host_forwarding == Path('/proc/sys/net/ipv4/ip_forward').read_text(), 'Host forwarding changed')
        require(host_nft == self.run([self.tools['nft'], '-j', 'list', 'ruleset'])[1], 'Host firewall changed')
        self.checks['host_routes_firewall_forwarding_unchanged'] = True
        return {'status': 'PASS', 'binary_version': version, 'binary_sha256': digest, 'checks': self.checks,
                'fec_mode': self.fec_mode,
                'scope': 'isolated Linux namespace evidence; not WAN/provider/production validation'}


class SelfTests(unittest.TestCase):
    def test_config_maps_entry_to_private_relay_to_application(self):
        a, b = config('origin', '/private/key'), config('egress', '/private/key')
        self.assertEqual(len(a['port_forwards']), 4)
        self.assertEqual(len(b['port_forwards']), 2)
        self.assertEqual(a['local_pool_cidr'], b['peer_pool_cidr'])
        self.assertEqual(a['peer_pool_cidr'], b['local_pool_cidr'])
        self.assertEqual({r['target'] for r in a['port_forwards']}, {r['listen'] for r in b['port_forwards']})
        self.assertNotEqual(RELAY_PORT, SERVICE_PORT)
        self.assertEqual({r['target'] for r in b['port_forwards']}, {'127.0.0.1:' + str(SERVICE_PORT)})

    def test_embedded_scripts_compile_without_running(self):
        for name in ('SERVER', 'CLIENT', 'POOL_CAPTURE', 'PORTS_FREE'):
            compile(globals()[name], name, 'exec')

    def test_fec_modes_are_explicit_and_matched(self):
        for mode in ('off', 'adaptive', 'fixed'):
            with self.subTest(mode=mode):
                a, b = (config(role, '/private/key', mode) for role in ('origin', 'egress'))
                for key in ('fec_mode', 'fec_percent', 'fec_max_percent', 'fec_block_ms'):
                    self.assertEqual(a[key], b[key])
                self.assertEqual(a['fec_mode'], mode)
                self.assertEqual(a['fec_percent'], 20)
                self.assertEqual(a['fec_max_percent'], 25)
                self.assertEqual(a['fec_block_ms'], 20)
        with self.assertRaises(base.common.LabError):
            config('origin', '/private/key', 'unknown')

    def test_payload_digest_checks_reject_changed_bytes(self):
        for proto in ('tcp', 'udp'):
            size = 65536 if proto == 'tcp' else 4000
            rows = [{'client': i, 'port': ENTRY_PORTS[i % 2], 'bytes': size,
                     'sha256': hashlib.sha256(((bytes([i]) + bytes(range(256))) * (size // 257 + 1))[:size]).hexdigest()}
                    for i in range(6)]
            result = {'protocol': proto, 'verified': True, 'clients': rows}
            validate_result(result, proto)
            rows[0]['sha256'] = '0' * 64
            with self.assertRaises(base.common.LabError):
                validate_result(result, proto)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary')
    parser.add_argument('--fec-mode', choices=('off', 'adaptive', 'fixed'), default='off')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args(argv)
    if args.self_test:
        return 0 if unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromTestCase(SelfTests)).wasSuccessful() else 1
    parser.error('--binary is required unless --self-test is selected') if not args.binary else None
    lab, report = Lab(args.fec_mode), None
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, lambda *_: setattr(lab, 'interrupted', True))
    try:
        report = lab.execute(args.binary)
    except Exception as error:
        lab.diagnostics()
        print('FAIL:', base.common.diagnostic_text(str(error), lab.private_values), file=sys.stderr)
    finally:
        failures = lab.cleanup()
        if failures:
            print('CLEANUP FAILURE:', failures, file=sys.stderr)
            report = None
    if report:
        print(json.dumps(report, indent=2, sort_keys=True))
        return 0
    return 1


if __name__ == '__main__':
    raise SystemExit(main())
