#!/usr/bin/env python3
"""Opt-in Direct ICMP L3 integration test inside a disposable local Linux VM.

Two newly owned namespaces; no public network/default route/host firewall or
sysctl changes. Tests actual TUN IPv4 ping/TCP/UDP, fragmentation, wrong keys,
restart/blackhole/loss recovery, encrypted outer wire and owned TUN cleanup.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import secrets
import shutil
import signal
import socket
import struct
import subprocess
import sys
import tempfile
import time

sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location("direct_lab_common", Path(__file__).with_name("spoof-systemd-lab.py"))
common = importlib.util.module_from_spec(spec)
spec.loader.exec_module(common)
require = common.require
OUTER = ("192.0.2.10", "192.0.2.20")
INNER = ("10.79.0.1", "10.79.0.2")
MARKER = "UNUNKNOWNTUN_DIRECT_ICMP_LAB_PLAINTEXT_MUST_NOT_LEAK_927641"

SERVER = r'''
import socket, threading, time, sys
ip = sys.argv[1]
def tcp():
    s=socket.socket(); s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
    s.bind((ip,19001)); s.listen(10); s.settimeout(.3)
    def echo(c):
        with c:
            c.settimeout(20)
            try:
                while True:
                    b=c.recv(65536)
                    if not b: break
                    c.sendall(b)
            except OSError: pass
    while True:
        try: c,_=s.accept()
        except socket.timeout: continue
        threading.Thread(target=echo,args=(c,),daemon=True).start()
def udp():
    s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.bind((ip,19002))
    while True:
        b,a=s.recvfrom(65535); s.sendto(b,a)
threading.Thread(target=tcp,daemon=True).start()
threading.Thread(target=udp,daemon=True).start()
print('READY',flush=True)
time.sleep(230)
'''

CLIENT = r'''
import socket,sys,hashlib,threading
ip,kind,amount=sys.argv[1],sys.argv[2],int(sys.argv[3])
marker=b'UNUNKNOWNTUN_DIRECT_ICMP_LAB_PLAINTEXT_MUST_NOT_LEAK_927641'
data=(marker+bytes(range(256)))*((amount//(len(marker)+256))+1); data=data[:amount]
s=socket.socket(socket.AF_INET,socket.SOCK_STREAM if kind=='tcp' else socket.SOCK_DGRAM)
s.settimeout(18); s.connect((ip,19001 if kind=='tcp' else 19002))
with s:
    if kind=='tcp':
        errors=[]
        def send():
            try: s.sendall(data); s.shutdown(socket.SHUT_WR)
            except OSError as e: errors.append(str(e))
        t=threading.Thread(target=send,daemon=True); t.start(); result=b''
        while True:
            b=s.recv(65536)
            if not b: break
            result+=b
        t.join(18)
        assert not t.is_alive() and not errors,errors
    else:
        # Retries are explicit application datagrams; ICMP mode itself is not
        # advertised as a reliable replacement for UDP.
        s.settimeout(2)
        for _ in range(5):
            s.send(data)
            try: result=s.recv(65535); break
            except socket.timeout: continue
        else: raise SystemExit('UDP exchange timed out')
    assert result==data,(len(result),len(data))
print(hashlib.sha256(result).hexdigest())
'''

CAPTURE = r'''
import socket,struct,time,json,signal,sys
active=True
def stop(*a):
    global active
    active=False
signal.signal(signal.SIGTERM,stop)
s=socket.socket(socket.AF_PACKET,socket.SOCK_RAW,0); s.bind((sys.argv[1],3)); s.settimeout(.2)
s.setsockopt(socket.SOL_SOCKET,socket.SO_RCVBUF,2097152)
marker=b'UNUNKNOWNTUN_DIRECT_ICMP_LAB_PLAINTEXT_MUST_NOT_LEAK_927641'
counts={}; directions={}; leaked=False; maxlen=0; end=time.monotonic()+230
print('READY',flush=True)
while active and time.monotonic()<end:
    try: b=s.recv(65536)
    except socket.timeout: continue
    if len(b)<34 or b[12:14]!=b'\x08\x00': continue
    ip=b[14:]; p=ip[9]; counts[p]=counts.get(p,0)+1
    if p==1:
        ihl=(ip[0]&15)*4
        directions[ip[ihl]]=directions.get(ip[ihl],0)+1
        maxlen=max(maxlen,int.from_bytes(ip[2:4],'big'))
        leaked|=marker in ip
print('RESULT='+json.dumps({'protocols':counts,'echo_types':directions,'plaintext_leak':leaked,'max_ipv4_bytes':maxlen,'complete':not active}),flush=True)
'''


class Lab(common.Lab):
    def __init__(self, fec_mode="off"):
        super().__init__()
        self.fec_mode = fec_mode
        self.prefix = "gdt-dic-" + secrets.token_hex(4)
        self.work_end = self.started + 225
        self.end = self.started + 250
        self.children = []
        self.checks = {}

    def private_file(self, path, data):
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, "w") as f:
            f.write(data)

    def ns(self, namespace, command):
        self.verify_namespace(namespace)
        return [self.tools["ip"], "netns", "exec", namespace, *command]

    def start(self, namespace, command, name):
        log = self.directory / (name + ".log")
        fd = os.open(log, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, "wb") as f:
            p = subprocess.Popen(self.ns(namespace, [self.tools["timeout"], "--kill-after=3", "230", *command]),
                                 stdout=f, stderr=f, start_new_session=True,
                                 env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"})
        self.children.append((p, log))
        return p

    def stop(self, p):
        if p.poll() is None:
            try:
                os.killpg(p.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                p.wait(timeout=3)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)
                p.wait(timeout=3)

    def wait_ping(self, namespace, destination, seconds=15, expected=True):
        end = min(self.work_end, time.monotonic() + seconds)
        passed = False
        while time.monotonic() < end:
            rc, _, _ = self.run(self.ns(namespace, [self.tools["ping"], "-n", "-c", "1", "-W", "1", destination]), seconds=2, check=False)
            if rc == 0:
                passed = True
                break
        require(passed == expected, "Ping outcome mismatch, expected=" + str(expected))

    def exchange(self, namespace, destination, kind, amount):
        _, output, _ = self.run(self.ns(namespace, [sys.executable, "-I", "-c", CLIENT, destination, kind, str(amount)]), seconds=22)
        marker = MARKER.encode()
        data = ((marker + bytes(range(256))) * (amount // (len(marker) + 256) + 1))[:amount]
        require(output.strip() == hashlib.sha256(data).hexdigest(), "End-to-end SHA256 differs")

    def execute(self, binary):
        require(platform.system() == "Linux" and os.geteuid() == 0, "Requires disposable Linux VM/root")
        for tool in ("ip", "timeout", "ping", "tc", "systemd-detect-virt"):
            self.tools[tool] = shutil.which(tool, path="/usr/sbin:/usr/bin:/sbin:/bin")
            require(self.tools[tool], "Missing local test tool: " + tool)
        self.run([self.tools["systemd-detect-virt"], "--vm", "--quiet"])
        common.verify_lab_parent(Path("/var/tmp"))
        os.umask(0o077)
        self.directory = Path(tempfile.mkdtemp(prefix=self.prefix + "-", dir="/var/tmp"))
        self.directory_identity = common.identity(self.directory)
        exe, digest = self.snapshot_binary(Path(binary))
        version = self.run([str(exe), "-version"])[1].strip()
        self.host_routes = self.ip("-j", "-4", "route", "show", "table", "all")[1]
        self.forwarding = Path("/proc/sys/net/ipv4/ip_forward").read_text()
        a, b = self.prefix + "-a", self.prefix + "-b"
        self.own_namespace(a)
        self.own_namespace(b)
        self.ip("-n", a, "link", "add", "dic-a", "type", "veth", "peer", "name", "dic-b", "netns", b)
        for ns, dev, ips in ((a, "dic-a", OUTER), (b, "dic-b", OUTER[::-1])):
            self.ip("-n", ns, "link", "set", "lo", "up")
            self.ip("-n", ns, "address", "add", ips[0] + "/32", "dev", dev)
            self.ip("-n", ns, "link", "set", dev, "up")
            self.ip("-n", ns, "route", "add", ips[1] + "/32", "dev", dev, "src", ips[0])
        for ns, ip in ((a, "192.168.91.1"), (b, "192.168.92.1")):
            self.ip("-n", ns, "address", "add", ip + "/32", "dev", "lo")
        key = secrets.token_hex(32)
        self.private_values.append(key)
        self.private_file(self.directory / "key", key + "\n")
        cfgs = []
        for role, dev, ips, inners in (("origin", "dic-a", OUTER, INNER), ("egress", "dic-b", OUTER[::-1], INNER[::-1])):
            cfg = {"role": role, "interface": dev, "tun_name": "dic-tun", "local_ip": ips[0], "peer_ip": ips[1],
                   "inner_local_ip": inners[0], "inner_peer_ip": inners[1], "key_file": str(self.directory / "key"),
                   "mtu": 1200, "poll_ms": 5, "timeout_seconds": 5, "rekey_seconds": 60}
            if self.fec_mode != "off":
                cfg.update(fec_mode=self.fec_mode, fec_percent=20, fec_max_percent=25, fec_block_ms=20)
            cfg["local_cidrs"] = ["192.168.91.0/24" if role == "origin" else "192.168.92.0/24"]
            cfg["peer_cidrs"] = ["192.168.92.0/24" if role == "origin" else "192.168.91.0/24"]
            path = self.directory / (role + ".json")
            self.private_file(path, json.dumps(cfg))
            cfgs.append(path)
            self.run([str(exe), "-check-direct-icmp-config", str(path)])
        peer = self.start(b, [str(exe), "-direct-icmp-config", str(cfgs[1])], "egress")
        wrong = dict(json.loads(cfgs[0].read_text()), key_file=str(self.directory / "wrong.key"))
        self.private_file(self.directory / "wrong.key", secrets.token_hex(32) + "\n")
        self.private_file(self.directory / "wrong.json", json.dumps(wrong))
        bad = self.start(a, [str(exe), "-direct-icmp-config", str(self.directory / "wrong.json")], "wrong-key")
        self.wait_ping(a, INNER[1], seconds=5, expected=False)
        require(peer.poll() is None and bad.poll() is None, "Negative test did not exercise live peers")
        self.stop(bad)
        require(self.ip("-n", a, "link", "show", "dic-tun", check=False)[0] != 0, "Wrong-key TUN not cleaned")
        self.checks["wrong_key_no_inner_reply"] = True
        capture = self.start(b, [sys.executable, "-I", "-u", "-c", CAPTURE, "dic-b"], "wire")
        client = self.start(a, [str(exe), "-direct-icmp-config", str(cfgs[0])], "origin")
        self.wait_ping(a, INNER[1])
        self.wait_ping(b, INNER[0])
        self.checks["bidirectional_inner_ping"] = True
        self.wait_ping(a, "192.168.92.1")
        self.wait_ping(b, "192.168.91.1")
        self.checks["explicit_private_routed_prefixes"] = True
        for ns, ip, label in ((a, INNER[0], "server-a"), (b, INNER[1], "server-b")):
            self.start(ns, [sys.executable, "-I", "-u", "-c", SERVER, ip], label)
        time.sleep(.3)
        for ns, ip, label in ((a, INNER[1], "origin_to_egress"), (b, INNER[0], "egress_to_origin")):
            self.exchange(ns, ip, "tcp", 256 * 1024)
            self.exchange(ns, ip, "udp", 1000)
            self.exchange(ns, ip, "udp", 4000)
            self.checks[label + "_tcp_udp_fragment_sha256"] = True
        self.stop(peer)
        require(self.ip("-n", b, "link", "show", "dic-tun", check=False)[0] != 0, "Egress TUN not cleaned")
        peer = self.start(b, [str(exe), "-direct-icmp-config", str(cfgs[1])], "egress-restarted")
        self.wait_ping(a, INNER[1], seconds=18)
        self.exchange(a, INNER[1], "tcp", 32768)
        self.checks["egress_restart_recovered"] = True
        self.stop(client)
        client = self.start(a, [str(exe), "-direct-icmp-config", str(cfgs[0])], "origin-restarted")
        self.wait_ping(a, INNER[1], seconds=18)
        self.checks["origin_restart_recovered"] = True
        self.run(self.ns(a, [self.tools["tc"], "qdisc", "add", "dev", "dic-a", "root", "netem", "loss", "100%"]))
        self.wait_ping(a, INNER[1], seconds=7, expected=False)
        self.run(self.ns(a, [self.tools["tc"], "qdisc", "del", "dev", "dic-a", "root"]))
        self.wait_ping(a, INNER[1], seconds=18)
        require(peer.poll() is None and client.poll() is None, "Blackhole recovery required process restart")
        self.checks["blackhole_timeout_recovered_without_restart"] = True
        self.run(self.ns(a, [self.tools["tc"], "qdisc", "add", "dev", "dic-a", "root", "netem", "delay", "10ms", "2ms", "loss", "2%"]))
        self.exchange(a, INNER[1], "tcp", 65536)
        self.run(self.ns(a, [self.tools["tc"], "qdisc", "del", "dev", "dic-a", "root"]))
        self.checks["tcp_sha256_under_loss_delay"] = True
        # Keep checking actual payload through at least one 60-second rekey.
        end = time.monotonic() + 65
        probes = 0
        while time.monotonic() < end:
            self.wait_ping(a, INNER[1], seconds=8)
            probes += 1
            time.sleep(2)
        self.exchange(a, INNER[1], "tcp", 32768)
        require(peer.poll() is None and client.poll() is None, "Soak required process restart")
        self.checks["periodic_rekey_window_payload_probes"] = probes
        for role in ("origin", "egress"):
            stats = (self.directory / (role + "-restarted.log")).read_text()
            rotations = [int(n) for n in re.findall(r"Rekeys:(\d+)", stats)]
            require(rotations and max(rotations) >= 1, "Periodic key rotation was not observed for " + role)
            self.checks[role + "_periodic_rekeys"] = max(rotations)
        self.stop(capture)
        wire = (self.directory / "wire.log").read_text()
        records = [json.loads(x[7:]) for x in wire.splitlines() if x.startswith("RESULT=")]
        require(len(records) == 1, "Missing complete wire capture")
        evidence = records[0]
        require(evidence["complete"] and not evidence["plaintext_leak"], "Unfinished capture or plaintext leak")
        require(set(evidence["protocols"]) == {"1"}, "Outer traffic was not exclusively ICMP")
        require({"0", "8"} <= set(evidence["echo_types"]), "Missing ICMP request/reply")
        require(evidence["max_ipv4_bytes"] <= 1500, "Outer packet exceeded physical MTU")
        self.checks["encrypted_outer_icmp_wire"] = evidence
        self.stop(client)
        self.stop(peer)
        for ns in (a, b):
            require(self.ip("-n", ns, "link", "show", "dic-tun", check=False)[0] != 0, "Owned TUN left after graceful stop")
            routes = json.loads(self.ip("-n", ns, "-j", "route", "show")[1])
            require(len(routes) == 1, "Owned route left after graceful stop")
        require(self.ip("-j", "-4", "route", "show", "table", "all")[1] == self.host_routes and
                Path("/proc/sys/net/ipv4/ip_forward").read_text() == self.forwarding, "Host network was changed")
        self.checks["owned_resources_cleaned_host_unchanged"] = True
        return {"status": "PASS", "binary_version": version, "binary_sha256": digest, "checks": self.checks,
                "fec_mode": self.fec_mode, "scope": "isolated Linux VM network namespaces; not Internet/WAN/provider/DPI evidence"}

    def cleanup(self):
        self.cleaning = True
        for p, _ in reversed(self.children):
            self.stop(p)
        return super().cleanup()

    def diagnostics(self):
        for p, log in self.children:
            if "server-" in log.name or log.name == "wire.log":
                continue
            text = "\n".join(log.read_text(errors="replace").splitlines()[-6:])
            print(log.name, "exit=" + str(p.poll()), common.diagnostic_text(text, self.private_values), file=sys.stderr)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", required=True)
    parser.add_argument("--fec-mode", choices=("off", "fixed", "adaptive"), default="off")
    args = parser.parse_args()
    lab = Lab(args.fec_mode)
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, lambda *_: setattr(lab, "interrupted", True))
    report = None
    try:
        report = lab.execute(args.binary)
    except Exception as error:
        lab.diagnostics()
        print("FAIL:", common.diagnostic_text(str(error), lab.private_values), file=sys.stderr)
    finally:
        failures = lab.cleanup()
        if failures:
            print("CLEANUP FAILURE:", failures, file=sys.stderr)
            report = None
    if report:
        print(json.dumps(report, indent=2, sort_keys=True))
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
