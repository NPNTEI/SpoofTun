#!/usr/bin/env python3
"""Opt-in private-pool ICMP integration inside disposable Linux VM namespaces.

Proves new-flow round-robin, TCP/UDP flow pinning and reply delivery, route-loss
recovery, ownership-safe crash recovery, and preservation of unrelated tables.
No public traffic, host firewall mutation, default route or global sysctl change.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import secrets
import shutil
import signal
import sys
import tempfile
import time

sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location("icmp_lab", Path(__file__).with_name("direct-icmp-netns-lab.py"))
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
require = base.require
OUTER = base.OUTER
POOLS = ("10.79.1.0/30", "10.79.2.0/30")
INNER = ("10.79.1.1", "10.79.2.1")

SERVER = r'''
import socket,threading,time,json,sys
ip=sys.argv[1]
def tcp():
 s=socket.socket();s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);s.bind((ip,19001));s.listen(32)
 def connection(c,a):
  with c:
   c.settimeout(12);f=c.makefile('rwb')
   try:
    for line in f:
     f.write(json.dumps([a[0],line.decode().strip()]).encode()+b'\n');f.flush()
   except OSError:pass
 while True:
  c,a=s.accept();threading.Thread(target=connection,args=(c,a),daemon=True).start()
def udp():
 s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);s.bind((ip,19002))
 while True:
  b,a=s.recvfrom(65535);s.sendto(json.dumps([a[0],b.decode()]).encode(),a)
threading.Thread(target=tcp,daemon=True).start();threading.Thread(target=udp,daemon=True).start()
print('READY',flush=True);time.sleep(230)
'''
CLIENT = r'''
import socket,json,sys
ip,proto,pool=sys.argv[1:];prefix=pool.rsplit('.',1)[0]+'.';expected={prefix+'1',prefix+'2'}
def connect():
 s=socket.socket(socket.AF_INET,socket.SOCK_STREAM if proto=='tcp' else socket.SOCK_DGRAM);s.settimeout(6);s.connect((ip,19001 if proto=='tcp' else 19002));return s
files={}
def exchange(s,tag):
 payload=(tag+'-'+'q'*1024)
 if proto=='tcp':
  if s not in files:files[s]=s.makefile('rwb')
  f=files[s];f.write(payload.encode()+b'\n');f.flush();data=f.readline()
 else:s.send(payload.encode());data=s.recv(65535)
 source,echo=json.loads(data);assert echo==payload;assert source in expected,source;return source
held=connect();pinned=exchange(held,'held-start');new=[]
for i in range(8):
 s=connect();seen=exchange(s,'new'+str(i));assert exchange(s,'repeat'+str(i))==seen
 new.append(seen)
 if s in files:files.pop(s).close()
 s.close()
 assert exchange(held,'held'+str(i))==pinned,'long-lived flow source changed'
assert set(new)==expected,new
assert all(new[i]!=new[i-1] for i in range(1,len(new))),new
if held in files:files[held].close()
held.close()
print(json.dumps({'protocol':proto,'new_sources':new,'pinned_source':pinned,'echo_verified':True}))
'''

class Lab(base.Lab):
    def __init__(self):
        super().__init__()
        self.prefix = "gdt-rr-" + secrets.token_hex(4)
        self.lease_files = []

    def nft(self, ns, *args, check=True):
        return self.run(self.ns(ns, [self.tools["nft"], *args]), check=check)

    def check_flows(self, ns, dest, sourcepool):
        results = []
        for proto in ("tcp", "udp"):
            output = self.run(self.ns(ns, [sys.executable, "-I", "-c", CLIENT, dest, proto, sourcepool]), seconds=35)[1]
            results.append(json.loads(output))
        return results

    def execute(self, binary):
        require(platform.system() == "Linux" and os.geteuid() == 0, "Requires disposable Linux VM/root")
        for tool in ("ip", "timeout", "ping", "nft", "systemd-detect-virt"):
            self.tools[tool] = shutil.which(tool, path="/usr/sbin:/usr/bin:/sbin:/bin")
            require(self.tools[tool], "Missing tool: " + tool)
        self.run([self.tools["systemd-detect-virt"], "--vm", "--quiet"])
        base.common.verify_lab_parent(Path("/var/tmp"))
        os.umask(0o077)
        self.directory = Path(tempfile.mkdtemp(prefix=self.prefix + "-", dir="/var/tmp"))
        self.directory_identity = base.common.identity(self.directory)
        exe, digest = self.snapshot_binary(Path(binary))
        version = self.run([str(exe), "-version"])[1].strip()
        host_routes = self.ip("-j", "-4", "route", "show", "table", "all")[1]
        forwarding = Path("/proc/sys/net/ipv4/ip_forward").read_text()
        host_nft = self.run([self.tools["nft"], "-j", "list", "ruleset"])[1]
        a, b = self.prefix + "-a", self.prefix + "-b"
        self.own_namespace(a); self.own_namespace(b)
        self.ip("-n", a, "link", "add", "dic-a", "type", "veth", "peer", "name", "dic-b", "netns", b)
        table = "gdt_icmp_" + hashlib.sha256(b"dic-tun").hexdigest()[:16]
        sentinel = "gdt_lab_unrelated"
        for ns, dev, ips in ((a, "dic-a", OUTER), (b, "dic-b", OUTER[::-1])):
            self.ip("-n", ns, "link", "set", "lo", "up")
            self.ip("-n", ns, "addr", "add", ips[0] + "/32", "dev", dev)
            self.ip("-n", ns, "link", "set", dev, "up")
            self.ip("-n", ns, "route", "add", ips[1] + "/32", "dev", dev, "src", ips[0])
            self.nft(ns, "add", "table", "ip", sentinel)
            inode = self.run(self.ns(ns, [sys.executable, "-I", "-c", "import os;print(os.stat('/proc/self/ns/net').st_ino)"]))[1].strip()
            self.lease_files.append(Path("/run/ununknowntun-icmp-rr") / (inode + "-" + table + ".lock"))
        key = secrets.token_hex(32); self.private_values.append(key)
        self.private_file(self.directory / "key", key + "\n")
        configs = []
        for role, dev, ips, inners, pools in (("origin", "dic-a", OUTER, INNER, POOLS), ("egress", "dic-b", OUTER[::-1], INNER[::-1], POOLS[::-1])):
            cfg = {"role": role, "interface": dev, "tun_name": "dic-tun", "local_ip": ips[0], "peer_ip": ips[1],
                   "inner_local_ip": inners[0], "inner_peer_ip": inners[1], "key_file": str(self.directory / "key"),
                   "local_pool_cidr": pools[0], "peer_pool_cidr": pools[1], "source_rotation": "round-robin",
                   "mtu": 1200, "poll_ms": 5, "timeout_seconds": 5, "rekey_seconds": 60}
            path = self.directory / (role + ".json"); self.private_file(path, json.dumps(cfg)); configs.append(path)
            self.run([str(exe), "-check-direct-icmp-config", str(path)])
        # A table with a colliding name but no matching private lease must survive.
        self.nft(a, "add", "table", "ip", table)
        bad = self.start(a, [str(exe), "-direct-icmp-config", str(configs[0])], "unowned-collision")
        bad.wait(timeout=10)
        require(bad.returncode != 0, "Existing unowned table was adopted")
        self.nft(a, "list", "table", "ip", table)
        require(self.ip("-n", a, "link", "show", "dic-tun", check=False)[0] != 0, "Failed setup leaked TUN")
        self.nft(a, "delete", "table", "ip", table)  # Exact table created by this test.
        self.checks["unowned_table_refused_and_setup_rolled_back"] = True
        peer = self.start(b, [str(exe), "-direct-icmp-config", str(configs[1])], "egress")
        client = self.start(a, [str(exe), "-direct-icmp-config", str(configs[0])], "origin")
        self.wait_ping(a, INNER[1]); self.wait_ping(b, INNER[0])
        self.wait_ping(a, "10.79.2.2"); self.wait_ping(b, "10.79.1.2")
        for ns, ip, label in ((a, INNER[0], "server-a"), (b, INNER[1], "server-b")):
            self.start(ns, [sys.executable, "-I", "-u", "-c", SERVER, ip], label)
        time.sleep(.3)
        self.checks["origin_new_flow_rotation_and_reply_pinning"] = self.check_flows(a, INNER[1], POOLS[0])
        self.checks["egress_new_flow_rotation_and_reply_pinning"] = self.check_flows(b, INNER[0], POOLS[1])
        # Force an actual sendto route error, rather than merely dropping a packet.
        self.ip("-n", a, "route", "del", OUTER[1] + "/32")
        self.ip("-n", a, "route", "add", "unreachable", OUTER[1] + "/32")
        self.ip("-n", a, "link", "set", "dic-a", "down")
        time.sleep(2)
        require(client.poll() is None and peer.poll() is None, "Temporary route loss killed runtime")
        self.ip("-n", a, "link", "show", "dic-tun")
        self.ip("-n", a, "route", "del", "unreachable", OUTER[1] + "/32")
        self.ip("-n", a, "link", "set", "dic-a", "up")
        self.ip("-n", a, "route", "add", OUTER[1] + "/32", "dev", "dic-a", "src", OUTER[0])
        self.wait_ping(a, INNER[1], seconds=18)
        self.check_flows(a, INNER[1], POOLS[0])
        require("temporary network failure" in (self.directory / "origin.log").read_text(), "Route error was not exercised")
        self.checks["sendto_route_error_recovered_same_process"] = True
        # SIGKILL leaves the nft table but releases the private flock. A new
        # instance may reclaim exactly its marker, then rebuild the same pool.
        os.killpg(client.pid, signal.SIGKILL); client.wait(timeout=3)
        self.nft(a, "list", "table", "ip", table)
        client = self.start(a, [str(exe), "-direct-icmp-config", str(configs[0])], "origin-after-kill")
        self.wait_ping(a, INNER[1], seconds=18)
        self.check_flows(a, INNER[1], POOLS[0])
        require("reclaimed owned table" in (self.directory / "origin-after-kill.log").read_text(), "No stale ownership recovery evidence")
        self.checks["sigkill_reclaimed_only_owned_table"] = True
        self.stop(client); self.stop(peer)
        for ns in (a, b):
            require(self.nft(ns, "list", "table", "ip", table, check=False)[0] != 0, "Owned table leaked on stop")
            self.nft(ns, "list", "table", "ip", sentinel)
            require(self.ip("-n", ns, "link", "show", "dic-tun", check=False)[0] != 0, "Owned TUN leaked on stop")
            require(len(json.loads(self.ip("-n", ns, "-j", "route", "show")[1])) == 1, "Owned routes leaked")
        require(host_routes == self.ip("-j", "-4", "route", "show", "table", "all")[1], "Host routes changed")
        require(forwarding == Path("/proc/sys/net/ipv4/ip_forward").read_text(), "Host forwarding changed")
        require(host_nft == self.run([self.tools["nft"], "-j", "list", "ruleset"])[1], "Host firewall changed")
        self.checks["graceful_cleanup_unrelated_tables_and_host_unchanged"] = True
        return {"status": "PASS", "binary_version": version, "binary_sha256": digest, "checks": self.checks,
                "scope": "isolated Linux namespace evidence; not WAN/provider/production validation"}

    def cleanup(self):
        result = super().cleanup()
        # Processes and owned namespaces are gone; only our exact netns-specific
        # private empty/crash lease files are removed, never another instance's.
        if not result:
            for path in self.lease_files:
                try:
                    info = path.lstat()
                    require(path.is_file() and not path.is_symlink() and info.st_uid == 0 and info.st_nlink == 1, "Unsafe lab lease cleanup")
                    path.unlink()
                except FileNotFoundError:
                    pass
        return result


def main():
    parser = argparse.ArgumentParser(description=__doc__); parser.add_argument("--binary", required=True)
    args = parser.parse_args(); lab = Lab(); report = None
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, lambda *_: setattr(lab, "interrupted", True))
    try:
        report = lab.execute(args.binary)
    except Exception as error:
        lab.diagnostics(); print("FAIL:", base.common.diagnostic_text(str(error), lab.private_values), file=sys.stderr)
    finally:
        failures = lab.cleanup()
        if failures: print("CLEANUP FAILURE:", failures, file=sys.stderr); report = None
    if report: print(json.dumps(report, indent=2, sort_keys=True)); return 0
    return 1

if __name__ == "__main__":
    raise SystemExit(main())
