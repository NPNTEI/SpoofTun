#!/usr/bin/env python3
"""Opt-in generated Direct ICMP systemd lifecycle lab for a disposable local VM.

sudo python3 -I tests/direct-icmp-systemd-lab.py --run-local-lab \
  --binary /absolute/final/ununknowntun --output /absolute/new-report.json
Add --installer /absolute/UNUNKNOWNTUN-V3-INSTALLER-3.7.0-preview.11.sh to exercise
the standalone embedded wizard and binary installation instead of helper install.
python3 -I tests/direct-icmp-systemd-lab.py --self-test

No production host: requires root Linux, a virtual-machine identity and systemd.
Creates random owned namespaces/veths and generated named endpoint services.
Only the lab services receive /run NetworkNamespacePath drop-ins. Their generated
security sandbox stays intact. Work limit110s; cleanup35s. RuntimeMaxSec80s plus
one-start limit prevent an abandoned process from restarting indefinitely.
No firewall, default-route, sysctl, package or existing-service changes.
"""
import argparse
import contextlib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import secrets
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import time
import unittest

sys.dont_write_bytecode = True
SOURCE = Path(__file__).resolve().parent.parent
CAPS = (1 << 12) | (1 << 13)


class LabError(RuntimeError):
    pass


def require(ok, message):
    if not ok:
        raise LabError(message)


def command(argv, timeout=20, check=True, input_text=None):
    result = subprocess.run([str(v) for v in argv], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            text=True, timeout=timeout, input=input_text, env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"})
    if check and result.returncode:
        message = result.stderr.strip() or result.stdout.strip()
        # Output from these fixed local commands never contains configuration/key dumps.
        raise LabError("Command failed: " + str(argv[0]) + " " + str(argv[1]) + ": " + message[:1200])
    return result


def private_write(path, data):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "wb", closefd=False) as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
    finally:
        os.close(fd)


def identity(path):
    info = path.stat()
    return info.st_dev, info.st_ino


def parse_properties(text):
    result = {}
    for line in text.splitlines():
        key, separator, value = line.partition("=")
        require(separator and key not in result, "Malformed systemd properties.")
        result[key] = value
    return result


def verify_process(state, namespace):
    require(state.get("ActiveState") == "active" and state.get("SubState") == "running", "Service is not running.")
    require(state.get("NetworkNamespacePath") == "/run/netns/" + namespace, "Wrong service namespace binding.")
    require(state.get("RuntimeMaxUSec") in ("1min 20s", "80s", "80000000"), "Missing bounded service lifetime.")
    require(state.get("StartLimitBurst") == "1" and state.get("StartLimitIntervalUSec") in ("5min", "300s", "300000000"), "Missing one-start watchdog guard.")
    require(state.get("NoNewPrivileges") == "yes" and state.get("ProtectSystem") == "strict", "Generated sandbox weakened.")
    pid = int(state.get("MainPID", "0"))
    require(pid > 1, "Missing service process.")
    proc = Path("/proc") / str(pid)
    require(identity(proc / "ns/net") == identity(Path("/run/netns") / namespace), "Process did not enter owned namespace.")
    values = {}
    for line in (proc / "status").read_text().splitlines():
        key, _, value = line.partition(":")
        values[key] = value.strip()
    for key in ("CapEff", "CapPrm", "CapBnd", "CapAmb"):
        require(int(values.get(key, "0"), 16) == CAPS, "Process capabilities differ from exact NET_ADMIN+NET_RAW: " + key)
    require(values.get("NoNewPrivs") == "1", "Process NoNewPrivs missing.")
    return {"pid": pid, "namespace_verified": True, "effective_capabilities": "NET_ADMIN NET_RAW", "no_new_privileges": True}


def systemd_state(unit):
    fields = ("ActiveState", "SubState", "MainPID", "NetworkNamespacePath", "RuntimeMaxUSec", "StartLimitBurst", "StartLimitIntervalUSec", "NoNewPrivileges", "ProtectSystem")
    args = ["/usr/bin/systemctl", "show", unit, "--no-pager"]
    for field in fields:
        args += ["-p", field]
    return parse_properties(command(args, timeout=10).stdout)


def preflight(binary, helper, output, installer=None):
    require(platform.system() == "Linux" and os.geteuid() == 0, "This live lab requires root in a disposable Linux VM.")
    detected = command(["/usr/bin/systemd-detect-virt", "--vm"], check=False, timeout=5)
    require(detected.returncode == 0 and detected.stdout.strip() not in ("", "none"), "Refusing a host without a detected VM identity.")
    require(Path("/run/systemd/system").is_dir(), "systemd must be running in the lab VM.")
    require(Path("/dev/net/tun").exists(), "TUN device is unavailable.")
    for executable in ("ip", "ping", "systemctl", "journalctl"):
        require(shutil.which(executable), "Required local tool missing: " + executable)
    for path in (binary, helper) + ((installer,) if installer is not None else ()):
        require(path.is_file() and not path.is_symlink(), "Regular binary/helper/installer required.")
    require(output.is_absolute() and output.parent.is_dir() and not output.exists() and not output.is_symlink(), "Report must be a new absolute file in an existing directory.")
    return detected.stdout.strip()


def wizard_answers(pair_name, outer, inner):
    # Exact human wizard order: peers, timings, FEC, then L3-only port-forward choice.
    return "\n".join([pair_name, outer["origin"], "gdt0", inner["origin"],
                      outer["egress"], "gdt0", inner["egress"], "1200", "20", "5", "3600",
                      "adaptive", "25", "20", "no"]) + "\n"


def run_lab(binary, helper, output, installer=None):
    vm = preflight(binary, helper, output, installer)
    start = time.monotonic()
    token = secrets.token_hex(5)
    pair_name = "lab-" + token
    namespaces = {"origin": "gdlo" + token, "egress": "gdle" + token}
    links = ["gdo" + token, "gde" + token]
    octet = 100 + int(token[:2], 16) % 100
    inner = {"origin": f"10.79.{octet}.1", "egress": f"10.79.{octet}.2"}
    outer = {"origin": "192.0.2.11", "egress": "192.0.2.12"}
    stage = Path(tempfile.mkdtemp(prefix="gdt-direct-systemd-", dir="/var/tmp"))
    stage.chmod(0o700)
    digest = hashlib.sha256(binary.read_bytes()).hexdigest()
    arch = {"x86_64": "amd64", "amd64": "amd64", "aarch64": "arm64", "arm64": "arm64"}.get(platform.machine().lower())
    require(arch, "Unsupported VM architecture.")
    pair = stage / "pair"
    report = {"status": "FAIL", "kind": "local-generated-direct-icmp-systemd", "runtime_architecture": arch,
              "binary_sha256": digest, "vm": vm, "checks": {}, "cleanup": {}, "limitations":
              ["Local isolated namespaces only; no WAN/provider/DPI claim.", "Only this runtime architecture was executed."]}
    if installer is not None:
        report["kind"] = "local-standalone-direct-icmp-systemd"
        report["installer_sha256"] = hashlib.sha256(installer.read_bytes()).hexdigest()
    owned_ns, installed, dropins = {}, {}, {}
    created_links = False
    binary_target = None
    binary_existed = True
    error = None
    def timeout_handler(_signum, _frame):
        raise LabError("Lab work deadline exceeded.")
    old_alarm = signal.signal(signal.SIGALRM, timeout_handler)
    old_int = signal.signal(signal.SIGINT, timeout_handler)
    old_term = signal.signal(signal.SIGTERM, timeout_handler)
    signal.alarm(110)
    try:
        version = command([binary, "-version"], timeout=5).stdout.strip()
        require(version.startswith("ununknowntun "), "Unexpected binary version output.")
        report["version"] = version.split(" ", 1)[1]
        # Only the host architecture will run. The other architecture has an
        # explicit unused fixture digest; no second architecture is claimed.
        hashes = {"amd64": "0" * 64, "arm64": "0" * 64}
        hashes[arch] = digest
        spec = {"pair_id": pair_name, "binary_sha256": hashes, "mtu": 1200, "poll_ms": 20,
                "timeout_seconds": 5, "rekey_seconds": 3600,
                "fec_mode": "adaptive", "fec_percent": 20, "fec_max_percent": 25, "fec_block_ms": 20,
                **{role: {"interface": "gdt0", "real_ip": outer[role], "inner_ip": inner[role]} for role in namespaces}}
        spec_path = stage / "spec.json"
        private_write(spec_path, (json.dumps(spec) + "\n").encode())
        if installer is None:
            command([sys.executable, "-I", helper, "--spec", spec_path, "--output", pair], timeout=10)
        else:
            command(["/bin/bash", installer, "direct-icmp-pair", pair], timeout=20,
                    input_text=wizard_answers(pair_name, outer, inner))
            report["checks"]["standalone_embedded_wizard"] = True
        command([sys.executable, "-I", helper, "--check-pair", pair], timeout=10)
        report["checks"]["matched_private_pair"] = True
        for role, name in namespaces.items():
            require(not (Path("/run/netns") / name).exists(), "Random namespace already exists.")
            command(["ip", "netns", "add", name])
            owned_ns[name] = identity(Path("/run/netns") / name)
        require(command(["ip", "link", "show", links[0]], check=False).returncode != 0 and
                command(["ip", "link", "show", links[1]], check=False).returncode != 0, "Random veth already exists.")
        command(["ip", "link", "add", links[0], "type", "veth", "peer", "name", links[1]])
        created_links = True
        for role, link in zip(("origin", "egress"), links):
            name = namespaces[role]
            command(["ip", "link", "set", link, "netns", name])
            command(["ip", "-n", name, "link", "set", link, "name", "gdt0"])
            command(["ip", "-n", name, "address", "add", outer[role] + "/24", "dev", "gdt0"])
            command(["ip", "-n", name, "link", "set", "gdt0", "up"])
            command(["ip", "-n", name, "link", "set", "lo", "up"])
        for role in ("egress", "origin"):
            folder = pair / role
            meta = json.loads((folder / "endpoint.json").read_text())
            destination = Path(meta["install_dir"])
            unit = meta["unit_name"]
            target = Path(meta["binary_path"])
            if binary_target is None:
                binary_target = target
                binary_existed = target.exists() or target.is_symlink()
            require(not destination.exists() and not destination.is_symlink(), "Refusing existing endpoint path.")
            require(not (Path("/etc/systemd/system") / unit).exists(), "Refusing existing unit path.")
            require(meta["binary_sha256"][arch] == digest, "Generated pair does not match the final binary under test.")
            if installer is None:
                command([sys.executable, "-I", folder / "manage.py", "install", "--binary", binary], timeout=20)
            else:
                command(["/bin/bash", installer, "direct-icmp-install", folder], timeout=25)
            installed[role] = {"folder": folder, "destination": destination, "unit": unit, "metadata": meta}
            require(target.is_file() and not target.is_symlink() and hashlib.sha256(target.read_bytes()).hexdigest() == digest,
                    "Installed binary differs from final runtime under test.")
            require((Path("/etc/systemd/system") / unit).read_bytes() == (folder / unit).read_bytes(),
                    "Installed service differs from generated unit.")
            require(command(["/usr/bin/systemctl", "is-active", "--quiet", unit], check=False).returncode != 0,
                    "Install unexpectedly started its service.")
            dropin = Path("/run/systemd/system") / (unit + ".d")
            require(not dropin.exists() and not dropin.is_symlink(), "Refusing an existing drop-in directory.")
            dropin.mkdir(mode=0o700)
            payload = ("[Unit]\nStartLimitIntervalSec=300s\nStartLimitBurst=1\n[Service]\nNetworkNamespacePath=/run/netns/" +
                       namespaces[role] + "\nRuntimeMaxSec=80s\n").encode()
            private_write(dropin / "10-lab.conf", payload)
            dropins[role] = dropin, payload
        command(["/usr/bin/systemctl", "daemon-reload"], timeout=15)
        report["checks"]["install_without_start"] = True
        if installer is not None:
            report["checks"]["standalone_embedded_install"] = True
        for role in ("egress", "origin"):
            item = installed[role]
            command([sys.executable, "-I", item["folder"] / "manage.py", "start"], timeout=20)
        deadline = time.monotonic() + 15
        while True:
            result = command(["ip", "netns", "exec", namespaces["origin"], "ping", "-n", "-c", "1", "-W", "1", inner["egress"]],
                             timeout=3, check=False)
            if result.returncode == 0:
                break
            require(time.monotonic() < deadline, "No inner ICMP reply before connection deadline.")
            time.sleep(0.2)
        for role, remote in (("origin", "egress"), ("egress", "origin")):
            command(["ip", "netns", "exec", namespaces[role], "ping", "-n", "-c", "3", "-i", "0.2", "-W", "2", inner[remote]], timeout=9)
            item = installed[role]
            report["checks"][role] = verify_process(systemd_state(item["unit"]), namespaces[role])
            report["checks"][role]["inner_ping"] = True
            status = command([sys.executable, "-I", item["folder"] / "manage.py", "status"], timeout=10)
            require("active (running)" in status.stdout, "Manager status did not show running service.")
        report["checks"]["generated_systemd_sandbox"] = True
        for role in ("origin", "egress"):
            item = installed[role]
            command([sys.executable, "-I", item["folder"] / "manage.py", "stop"], timeout=20)
            require(command(["/usr/bin/systemctl", "is-active", "--quiet", item["unit"]], check=False).returncode != 0,
                    "Manager stop left service active.")
            command([sys.executable, "-I", item["folder"] / "manage.py", "uninstall"], timeout=20)
            require(not item["destination"].exists() and not (Path("/etc/systemd/system") / item["unit"]).exists(),
                    "Manager uninstall left endpoint/unit behind.")
            item["uninstalled"] = True
        report["checks"]["manager_stop_uninstall"] = True
        report["status"] = "PASS"
    except BaseException as failure:
        error = str(failure)[:1600] or type(failure).__name__
        report["error"] = error
        diagnostics = {}
        for role, item in installed.items():
            try:
                diagnostics[role] = command(["/usr/bin/journalctl", "-u", item["unit"], "-n", "15", "--no-pager"],
                                            timeout=5, check=False).stdout[-3000:]
            except Exception:
                diagnostics[role] = "diagnostic command unavailable"
        if diagnostics:
            # Runtime logs never include the private key. Keep a defensive
            # removal for exact generated values before persisting diagnostics.
            for key_path in pair.glob("*/icmp.key"):
                key = key_path.read_text().strip()
                diagnostics = {role: value.replace(key, "[key redacted]") for role, value in diagnostics.items()}
            report["diagnostics"] = diagnostics
    finally:
        signal.alarm(35)
        cleanup_errors = []
        for role, item in list(installed.items()):
            try:
                if not item.get("uninstalled"):
                    command([sys.executable, "-I", item["folder"] / "manage.py", "uninstall"], timeout=20)
                report["cleanup"][role + "_endpoint"] = not item["destination"].exists()
            except Exception as failure:
                cleanup_errors.append("endpoint " + role + ": " + str(failure)[:300])
        for role, (directory, data) in dropins.items():
            try:
                path = directory / "10-lab.conf"
                require(path.is_file() and not path.is_symlink() and path.read_bytes() == data and
                        set(p.name for p in directory.iterdir()) == {"10-lab.conf"}, "Owned drop-in changed; refusing removal.")
                path.unlink();directory.rmdir()
            except Exception as failure:
                cleanup_errors.append("drop-in " + role + ": " + str(failure)[:300])
        if installed:
            try:
                command(["/usr/bin/systemctl", "daemon-reload"], timeout=10)
                for item in installed.values():
                    command(["/usr/bin/systemctl", "reset-failed", item["unit"]], timeout=5, check=False)
            except Exception as failure:
                cleanup_errors.append("reload: " + str(failure)[:300])
        for name, expected in owned_ns.items():
            try:
                path = Path("/run/netns") / name
                require(path.exists() and identity(path) == expected, "Namespace identity changed; refusing deletion.")
                command(["ip", "netns", "delete", name], timeout=5)
                report["cleanup"][name] = not path.exists()
            except Exception as failure:
                cleanup_errors.append("namespace " + name + ": " + str(failure)[:300])
        if created_links:
            # A link left in the root namespace only occurs on setup failure.
            for link in links:
                result = command(["ip", "link", "show", link], timeout=3, check=False)
                if result.returncode == 0:
                    command(["ip", "link", "delete", link], timeout=3, check=False)
        if binary_target is not None and not binary_existed and binary_target.exists():
            try:
                remaining = list(Path("/etc/ununknowntun-direct-icmp").glob("*/*/endpoint.json"))
                in_use = any(json.loads(path.read_text()).get("binary_path") == str(binary_target) for path in remaining)
                if not in_use and not binary_target.is_symlink() and hashlib.sha256(binary_target.read_bytes()).hexdigest() == digest:
                    binary_target.unlink()
                    binary_target.parent.rmdir()
                    report["cleanup"]["owned_versioned_binary"] = True
                else:
                    report["cleanup"]["versioned_binary_preserved"] = True
            except Exception as failure:
                cleanup_errors.append("binary: " + str(failure)[:300])
        try:
            # This entire directory was created by this run; all subprocesses
            # have bounded completion and no installed unit points into it.
            if not cleanup_errors:
                shutil.rmtree(stage)
                report["cleanup"]["private_fixture_removed"] = True
            else:
                report["retained_private_fixture"] = str(stage)
        except Exception as failure:
            cleanup_errors.append("fixture: " + str(failure)[:300])
        if cleanup_errors:
            report["status"] = "FAIL"
            report["cleanup_errors"] = cleanup_errors
        report["elapsed_seconds"] = round(time.monotonic() - start, 3)
        signal.alarm(0)
        signal.signal(signal.SIGALRM, old_alarm)
        signal.signal(signal.SIGINT, old_int)
        signal.signal(signal.SIGTERM, old_term)
        private_write(output, (json.dumps(report, indent=2, sort_keys=True) + "\n").encode())
    print(json.dumps({"status": report["status"], "report": str(output), "runtime_architecture": arch}))
    return 0 if report["status"] == "PASS" else 1


class OfflineTests(unittest.TestCase):
    def test_properties_reject_duplicates(self):
        with self.assertRaises(LabError):parse_properties("MainPID=1\nMainPID=2\n")

    def test_properties_reject_malformed(self):
        with self.assertRaises(LabError):parse_properties("not a property")

    def test_properties_roundtrip(self):
        self.assertEqual(parse_properties("MainPID=23\nActiveState=active\n"), {"MainPID":"23", "ActiveState":"active"})

    def test_private_file_exclusive(self):
        with tempfile.TemporaryDirectory() as name:
            path=Path(name)/"report.json";private_write(path,b"safe")
            self.assertEqual(stat.S_IMODE(path.stat().st_mode),0o600)
            with self.assertRaises(FileExistsError):private_write(path,b"overwrite")
            self.assertEqual(path.read_bytes(),b"safe")

    def test_no_root_host_mutation_from_self_test(self):
        self.assertEqual(CAPS,0x3000)

    def test_standalone_wizard_inputs(self):
        result = wizard_answers("lab-example", {"origin":"192.0.2.11", "egress":"192.0.2.12"},
                                {"origin":"10.79.1.1", "egress":"10.79.1.2"})
        self.assertEqual(result.splitlines(), ["lab-example", "192.0.2.11", "gdt0", "10.79.1.1",
                                              "192.0.2.12", "gdt0", "10.79.1.2", "1200", "20", "5", "3600",
                                              "adaptive", "25", "20", "no"])

    def test_command_stdin_transport(self):
        result = command([sys.executable, "-I", "-c", "import sys; print(len(sys.stdin.read()))"], input_text="abcdef")
        self.assertEqual(result.stdout.strip(), "6")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-local-lab",action="store_true")
    parser.add_argument("--binary",type=Path)
    parser.add_argument("--helper",type=Path,default=SOURCE/"packaging/direct-icmp-pair.py")
    parser.add_argument("--output",type=Path)
    parser.add_argument("--installer",type=Path,help="Matching rendered standalone installer; exercises its wizard and embedded binary installation.")
    parser.add_argument("--self-test",action="store_true")
    args=parser.parse_args()
    if args.self_test:
        require(not args.run_local_lab and args.binary is None and args.output is None and args.installer is None,"Self-test cannot run a live lab.")
        suite=unittest.defaultTestLoader.loadTestsFromTestCase(OfflineTests)
        return 0 if unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful() else 1
    require(args.run_local_lab and args.binary and args.output,"Explicit --run-local-lab --binary --output required.")
    return run_lab(args.binary.absolute(),args.helper.absolute(),args.output.absolute(),
                   args.installer.absolute() if args.installer is not None else None)

if __name__=="__main__":
    try:
        raise SystemExit(main())
    except (LabError,OSError,subprocess.SubprocessError) as error:
        print("DIRECT ICMP SYSTEMD LAB ERROR: "+str(error),file=sys.stderr)
        raise SystemExit(1)
