#!/usr/bin/env bash
# Opt-in isolated local lab. Evidence is produced only by an explicit lab run.
# All packet sockets and test listeners run inside newly created net namespaces.
set -euo pipefail
if [[ $# -ne 2 || $1 != --run-local-lab || $2 != /* ]]; then
    printf '%s\n' 'NOT RUN. Usage: sudo bash tests/gre-netns-lab.sh --run-local-lab /absolute/path/to/trusted-linux-ununknowntun'
    exit 2
fi
# Resolve even the first platform check through system paths only.
export PATH=/usr/sbin:/usr/bin:/sbin:/bin
if [[ $(uname -s) != Linux || $EUID -ne 0 ]]; then
    printf '%s\n' 'This opt-in lab requires Linux and root; nothing was changed.' >&2
    exit 2
fi
command -v python3 >/dev/null || { printf '%s\n' 'python3 is required.' >&2; exit 2; }
script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
exec python3 -I - "$2" "$script_dir/gre-wire-check.py" "$script_dir/../packaging/spoof-pair.py" <<'PY'
import contextlib
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import secrets
import shutil
import signal
import stat
import struct
import subprocess
import sys
import tempfile
import time

TOTAL_SECONDS = 180
CASE_SECONDS = 75
PAYLOAD_BYTES = 32768
MAX_LOG_BYTES = 1048576
started = time.monotonic()
case_deadline = None
lab_dir = None
lab_identity = None
owned_namespaces = []
pending_namespaces = set()
children = []
log_handles = []
secrets_to_redact = []
cleaned_namespaces = []


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def interrupted(signum, _frame):
    raise InterruptedError('Interrupted; removing only owned lab resources')


@contextlib.contextmanager
def defer_interrupts():
    # Registration and creation must be atomic with respect to our handlers.
    # Pending signals are delivered after exact ownership has been recorded.
    previous = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGINT, signal.SIGTERM})
    try:
        yield
    finally:
        signal.pthread_sigmask(signal.SIG_SETMASK, previous)


def budget(seconds=8):
    left = TOTAL_SECONDS - (time.monotonic() - started)
    if case_deadline is not None:
        left = min(left, case_deadline - time.monotonic())
    require(left > 0, 'Overall lab deadline exceeded')
    return min(seconds, left)


def run(argv, timeout=8, namespace=None, check=True, input_data=None):
    if namespace:
        argv = [ip, 'netns', 'exec', namespace] + list(argv)
    result = subprocess.run(argv, input=input_data, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=budget(timeout),
                            cwd=str(lab_dir) if lab_dir else '/',
                            env=clean_env)
    if check and result.returncode:
        # Helpers receive no shared token in their command-line arguments.
        detail = result.stderr.decode('utf-8', errors='replace')[-1200:]
        raise RuntimeError(f'Helper failed ({result.returncode}): {argv[0]}: {detail}')
    return result


def identity(path):
    info = os.stat(path, follow_symlinks=False)
    return info.st_dev, info.st_ino


def namespace_path(name):
    return Path('/run/netns') / name


def check_owned_namespace(name, expected):
    return identity(namespace_path(name)) == expected


def private_file(path, content):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as output:
        output.write(content.encode() if isinstance(content, str) else content)


def child_limits():
    # Limits concern only a new lab child, never the host or shell running it.
    import resource
    resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_LOG_BYTES, MAX_LOG_BYTES))
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    signal.pthread_sigmask(signal.SIG_SETMASK, set())


def start_child(namespace, argv, label):
    path = lab_dir / (label + '.log')
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    output = os.fdopen(fd, 'wb')
    log_handles.append(output)
    with defer_interrupts():
        process = subprocess.Popen([ip, 'netns', 'exec', namespace] + list(argv),
                                   stdout=output, stderr=subprocess.STDOUT,
                                   cwd=lab_dir, env=clean_env,
                                   start_new_session=True, preexec_fn=child_limits)
        children.append((process, namespace, path))
    return process, path


def stop_child(process):
    if process.poll() is None:
        # A live, unreaped direct child cannot have had its PID reused.
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            process.wait(timeout=3)
            return
        try:
            process.wait(timeout=3)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait(timeout=3)


def log_text(path):
    with path.open('rb') as handle:
        data = handle.read(MAX_LOG_BYTES + 1)
    require(len(data) <= MAX_LOG_BYTES, 'Child exceeded its bounded log size')
    return data.decode('utf-8', errors='replace')


def wait_for(predicate, processes, seconds, description):
    end = time.monotonic() + budget(seconds)
    while time.monotonic() < end:
        for process in processes:
            require(process.poll() is None, f'Lab child exited while waiting for {description}')
        if predicate():
            return
        time.sleep(0.05)
    raise RuntimeError(f'Timed out waiting for {description}')


def completed_child(namespace, argv, label, seconds):
    # Even generation/check subprocess groups are namespace-owned and tracked,
    # so a timeout cannot leave their binary/OpenSSL child outside cleanup.
    process, log = start_child(namespace, argv, label)
    wait_for(lambda: process.poll() is not None, [], seconds, label)
    require(process.returncode == 0, label + ' failed; see bounded diagnostic log')
    return log


def cleanup_case(names):
    errors = []
    for process, namespace, _path in reversed(children):
        if namespace in names:
            try:
                stop_child(process)
            except (OSError, subprocess.TimeoutExpired) as exc:
                errors.append(f'child cleanup: {exc}')
    for name, expected in reversed(owned_namespaces[:]):
        if name not in names:
            continue
        try:
            require(check_owned_namespace(name, expected), f'Namespace identity changed: {name}; NOT deleting')
            # No blanket kill and no host link deletion. A veth is created wholly
            # inside this namespace pair and disappears with the owned pair.
            pids = subprocess.run([ip, 'netns', 'pids', name], capture_output=True,
                                  timeout=5, env=clean_env)
            require(pids.returncode == 0 and not pids.stdout.strip(),
                    f'Namespace {name} still has processes; refusing to remove its handle')
            subprocess.run([ip, 'netns', 'del', name], check=True,
                           capture_output=True, timeout=5, env=clean_env)
            require(not namespace_path(name).exists(), f'Namespace cleanup unconfirmed: {name}')
            owned_namespaces.remove((name, expected))
            cleaned_namespaces.append(name)
        except (OSError, RuntimeError, subprocess.SubprocessError) as exc:
            errors.append(str(exc))
    return errors


ECHO = r'''
import socket, sys, time
deadline = time.monotonic() + 95
server = socket.socket()
server.bind(('127.0.0.1', 18082)); server.listen(4); server.settimeout(0.5)
print('READY', flush=True)
accepted = total = 0
while time.monotonic() < deadline and accepted < 4 and total < 65536:
    try: connection, address = server.accept()
    except socket.timeout: continue
    accepted += 1
    print('ACCEPT', flush=True)
    with connection:
        connection.settimeout(8)
        try:
            while total < 65536 and time.monotonic() < deadline:
                block = connection.recv(min(4096, 65536-total))
                if not block: break
                total += len(block)
                connection.sendall(block)
        except (OSError, socket.timeout): pass
    print('BYTES', total, flush=True)
server.close()
'''

CLIENT = r'''
import hashlib, json, socket, sys, time
negative = sys.argv[1] == 'negative'
payload = b'UNUNKNOWNTUN wrong-token local lab' if negative else bytes(range(256))*128
deadline = time.monotonic() + (5 if negative else 12)
connection = None
while time.monotonic() < deadline:
    try:
        connection = socket.create_connection(('127.0.0.1', 12055), timeout=0.5)
        break
    except (ConnectionRefusedError, socket.timeout): time.sleep(0.05)
if connection is None: raise SystemExit('origin listener never became ready')
received = bytearray()
failure = None
with connection:
    try:
        connection.settimeout(max(0.1, deadline-time.monotonic()))
        connection.sendall(payload)
        while len(received) < len(payload) and time.monotonic() < deadline:
            connection.settimeout(max(0.1, deadline-time.monotonic()))
            block = connection.recv(len(payload)-len(received))
            if not block: break
            received.extend(block)
    except OSError as error: failure = type(error).__name__
if negative:
    if received: raise SystemExit('FAIL: negative case produced target bytes')
    print(json.dumps({'negative_no_payload': True, 'sent_bytes': len(payload)}))
else:
    if received != payload: raise SystemExit('FAIL: payload truncated, changed or timed out: '+str(failure))
    print(json.dumps({'echo_bytes': len(received), 'sha256': hashlib.sha256(received).hexdigest()}))
'''


def make_config(path, interface, tun, local, peer, source, expected, inner, remote):
    private_file(path, json.dumps({
        'interface': interface, 'tun_name': tun,
        'local_ip': local, 'peer_ip': peer,
        'source_ip': source, 'expected_peer_source_ip': expected,
        'inner_local_ip': inner, 'inner_peer_ip': remote,
        'mtu': 1280, 'carrier_port': 18443, 'authorized': True,
    }, indent=2) + '\n')


def new_namespace(name):
    require(not namespace_path(name).exists(), f'Resource already exists: {name}')
    pending_namespaces.add(name)
    with defer_interrupts():
        run([ip, 'netns', 'add', name])
        owned_namespaces.append((name, identity(namespace_path(name))))
        pending_namespaces.remove(name)


def case(mux):
    global case_deadline
    case_start = time.monotonic()
    case_deadline = case_start + CASE_SECONDS
    suffix = secrets.token_hex(5)
    origin_ns, egress_ns = f'gdt-grelab-{suffix}-o', f'gdt-grelab-{suffix}-e'
    origin_link, egress_link = 'gl' + suffix + 'o', 'gl' + suffix + 'e'
    names = {origin_ns, egress_ns}
    try:
        new_namespace(origin_ns)
        new_namespace(egress_ns)
        # No veth ever enters the host namespace. No bridge, default route,
        # firewall mutation, forwarding or sysctl command is used anywhere.
        run([ip, '-n', origin_ns, 'link', 'add', origin_link, 'type', 'veth',
             'peer', 'name', egress_link, 'netns', egress_ns])
        for namespace, link, local, peer, expected in [
            (origin_ns, origin_link, '192.0.2.10', '192.0.2.20', '198.51.100.20'),
            (egress_ns, egress_link, '192.0.2.20', '192.0.2.10', '198.51.100.10'),
        ]:
            run([ip, '-n', namespace, 'link', 'set', 'lo', 'up'])
            run([ip, '-n', namespace, 'address', 'add', local + '/32', 'dev', link])
            run([ip, '-n', namespace, 'link', 'set', link, 'mtu', '1500', 'up'])
            run([ip, '-n', namespace, '-4', 'route', 'add', peer + '/32',
                 'dev', link, 'src', local])
            # A reverse route for the synthetic source keeps strict reverse-path
            # filtering satisfied without changing any sysctl, even inside labs.
            run([ip, '-n', namespace, '-4', 'route', 'add', expected + '/32', 'dev', link])
            links = json.loads(run([ip, '-n', namespace, '-j', 'link', 'show']).stdout)
            require({entry['ifname'] for entry in links} == {'lo', link}, 'Namespace has an unexpected interface')
            routes = json.loads(run([ip, '-n', namespace, '-j', '-4', 'route', 'show']).stdout)
            require(len(routes) == 2 and all(r.get('dst') != 'default' and r.get('dev') == link for r in routes),
                    'Namespace route isolation check failed')

        pair_dir = lab_dir / f'{mux}-pair'
        pair_spec = lab_dir / f'{mux}-pair-spec.json'
        private_file(pair_spec, json.dumps({
            'pair_id': 'lab-' + mux + '-' + suffix, 'authorized': True,
            'binary_path': str(binary), 'install_dir': str(pair_dir),
            'mux': mux, 'mtu': 1280, 'carrier_port': 18443,
            'client_listen': '127.0.0.1:12055', 'target': '127.0.0.1:18082',
            'origin': {'interface': origin_link, 'tun_name': 'gdtorigin', 'real_ip': '192.0.2.10',
                       'source_ip': '198.51.100.10', 'inner_ip': '10.77.0.1'},
            'egress': {'interface': egress_link, 'tun_name': 'gdtegress', 'real_ip': '192.0.2.20',
                       'source_ip': '198.51.100.20', 'inner_ip': '10.77.0.2'},
        }))
        completed_child(origin_ns, [python, '-I', str(pair_helper), '--spec', str(pair_spec),
                                   '--output', str(pair_dir)], f'{mux}-generate-pair', 25)
        completed_child(origin_ns, [python, '-I', str(pair_helper), '--check-pair', str(pair_dir)],
                        f'{mux}-check-pair', 15)
        token_file = pair_dir / 'origin' / 'token'
        secrets_to_redact.append(token_file.read_text().strip())
        fingerprint = (pair_dir / 'origin' / 'pin.sha256').read_text().strip()
        bad_token_file = lab_dir / f'{mux}-wrong-token'
        wrong_token = secrets.token_hex(32)
        secrets_to_redact.append(wrong_token)
        private_file(bad_token_file, wrong_token + '\n')
        bad_config = lab_dir / f'{mux}-bad-origin.json'
        mismatch_config = lab_dir / f'{mux}-mismatch-origin.json'
        make_config(bad_config, origin_link, 'gdtbad', '192.0.2.10', '192.0.2.20',
                    '198.51.100.10', '198.51.100.20', '10.77.0.1', '10.77.0.2')
        make_config(mismatch_config, origin_link, 'gdtmismatch', '192.0.2.10', '192.0.2.20',
                    '198.51.100.10', '198.51.100.99', '10.77.0.1', '10.77.0.2')
        echo, echo_log = start_child(egress_ns, [python, '-I', '-u', '-c', ECHO], f'{mux}-echo')
        wait_for(lambda: 'READY' in log_text(echo_log), [echo], 5, 'bounded echo server')
        common = [str(binary), '-transport', 'tls', '-mux', mux,
                  '-sessions-min', '1', '-sessions', '1', '-max-streams', '8',
                  '-ech-mode', 'off', '-tls-fragment', 'off', '-stats', '1s']
        completed_child(egress_ns, ['/bin/sh', str(pair_dir / 'egress' / 'check.sh')],
                        f'{mux}-generated-egress-check', 5)
        egress, egress_log = start_child(egress_ns, ['/bin/sh', str(pair_dir / 'egress' / 'run.sh')],
                                        f'{mux}-egress')
        # Read namespace state, without opening an unauthenticated probe socket.
        listener_check = "from pathlib import Path; import sys; sys.exit(0 if any(x.split()[1]=='02004D0A:480B' and x.split()[3]=='0A' for x in Path('/proc/net/tcp').read_text().splitlines()[1:]) else 1)"
        wait_for(lambda: run([python, '-I', '-c', listener_check], namespace=egress_ns, check=False).returncode == 0,
                 [echo, egress], 8, 'egress TLS listener')
        completed_child(origin_ns, ['/bin/sh', str(pair_dir / 'origin' / 'check.sh')],
                        f'{mux}-generated-origin-check', 18)
        wait_for(lambda: run([ip, '-n', origin_ns, 'link', 'show', 'dev', 'gdtorigin'], check=False).returncode != 0,
                 [echo, egress], 5, 'generated origin-check TUN cleanup')
        require('ACCEPT' not in log_text(echo_log), 'Generated authentication check reached the target backend')
        print(f'PASS generated pair mux={mux}: private generation/integrity, egress check.sh, origin live check.sh', flush=True)
        origin_args = ['-mode', 'origin', '-listen', '127.0.0.1:12055',
                       '-connect', '10.77.0.2:18443', '-target', '127.0.0.1:18082',
                       '-fingerprint', fingerprint]
        bad_origin, _ = start_child(origin_ns, common + origin_args + [
            '-token-file', str(bad_token_file), '-spoof-config', str(bad_config)], f'{mux}-bad-origin')
        run([python, '-I', '-c', CLIENT, 'negative'], namespace=origin_ns, timeout=7)
        wait_for(lambda: '[egress] authentication failed from ' in log_text(egress_log),
                 [echo, egress, bad_origin], 5, 'explicit wrong-token rejection')
        require('ACCEPT' not in log_text(echo_log), 'Wrong token reached the echo backend')
        stop_child(bad_origin)
        wait_for(lambda: run([ip, '-n', origin_ns, 'link', 'show', 'dev', 'gdtbad'], check=False).returncode != 0,
                 [echo, egress], 5, 'bad-origin TUN cleanup')
        leftover_routes = json.loads(run([ip, '-n', origin_ns, '-j', '-4', 'route', 'show', 'table', 'all']).stdout)
        require(not any(r.get('dev') == 'gdtbad' for r in leftover_routes), 'Bad-origin route was not removed')

        # The real outer destination and the sending source remain correct.
        # Only the origin's expected remote source is intentionally wrong.
        # Count actual received-but-rejected GRE, not merely a client timeout.
        mismatch, mismatch_log = start_child(origin_ns, common + origin_args + [
            '-token-file', str(token_file), '-spoof-config', str(mismatch_config)], f'{mux}-mismatch-origin')
        run([python, '-I', '-c', CLIENT, 'negative'], namespace=origin_ns, timeout=7)
        stats_pattern = (r'\[spoof/stats\] sent=(\d+) received=(\d+) rejected=\d+ dropped=\d+'
                         r'[^\n]*\brx_identity_mismatch=(\d+)\b')
        def mismatch_rejected():
            rows = re.findall(stats_pattern, log_text(mismatch_log))
            return any(int(sent) > 0 and int(received) == 0 and int(identity_mismatch) > 0
                       for sent, received, identity_mismatch in rows)
        wait_for(mismatch_rejected, [echo, egress, mismatch], 5, 'explicit expected-peer-source rejection')
        require('[origin] tunnel session established ' not in log_text(mismatch_log),
                'Wrong expected peer source established an authenticated carrier')
        require('ACCEPT' not in log_text(echo_log), 'Wrong expected peer source reached the echo backend')
        stop_child(mismatch)
        wait_for(lambda: run([ip, '-n', origin_ns, 'link', 'show', 'dev', 'gdtmismatch'], check=False).returncode != 0,
                 [echo, egress], 5, 'mismatched-origin TUN cleanup')
        leftover_routes = json.loads(run([ip, '-n', origin_ns, '-j', '-4', 'route', 'show', 'table', 'all']).stdout)
        require(not any(r.get('dev') == 'gdtmismatch' for r in leftover_routes), 'Mismatched-origin route was not removed')

        origin, origin_log = start_child(origin_ns, ['/bin/sh', str(pair_dir / 'origin' / 'run.sh')],
                                        f'{mux}-origin')
        origin_listener_check = "from pathlib import Path; import sys; sys.exit(0 if any(x.split()[1]=='0100007F:2F17' and x.split()[3]=='0A' for x in Path('/proc/net/tcp').read_text().splitlines()[1:]) else 1)"
        wait_for(lambda: run([python, '-I', '-c', origin_listener_check], namespace=origin_ns, check=False).returncode == 0,
                 [echo, egress, origin], 5, 'origin client listener before wire capture')
        # MUX OFF establishes its carrier lazily on the first client connection.
        # Wait only for the listener here; both captures must be ready before
        # that connection triggers authentication and the exact client payload.
        # Negative-case raw-socket teardown has already completed.
        captures = []
        for role, namespace, link in [('origin', origin_ns, origin_link), ('egress', egress_ns, egress_link)]:
            capture_path = lab_dir / f'{mux}-{role}.wire'
            capture_process, capture_log = start_child(namespace, [python, '-I', '-u', str(wire_helper),
                'capture', '--interface', link, '--output', str(capture_path), '--seconds', '70'], f'{mux}-{role}-capture')
            captures.append((capture_process, capture_log, capture_path))
            wait_for(lambda path=capture_log: 'READY bounded AF_PACKET capture' in log_text(path),
                     [echo, egress, origin, capture_process], 3, role + ' wire capture')
        result = json.loads(run([python, '-I', '-c', CLIENT, 'positive'], namespace=origin_ns, timeout=15).stdout)
        require(result.get('echo_bytes') == PAYLOAD_BYTES, 'Unexpected payload count')
        expected_hash = hashlib.sha256(bytes(range(256))*128).hexdigest()
        require(result.get('sha256') == expected_hash, 'Echo digest mismatch')
        wait_for(lambda: '[origin] tunnel session established ' in log_text(origin_log),
                 [echo, egress, origin], 3, 'authenticated origin session')
        require(log_text(echo_log).count('ACCEPT') == 1, 'Unexpected backend connection count')
        # Signal both first to minimize tail skew, then reap both before any
        # parser reads a capture. A SIGKILL/missing footer never passes evidence.
        for process, _log, _path in captures:
            require(process.poll() is None, 'Wire capture exited before explicit stop')
            os.killpg(process.pid, signal.SIGTERM)
        for process, _log, _path in captures:
            stop_child(process)
            require(process.returncode == 0, 'Wire capture did not stop cleanly')
        wire = json.loads(run([python, '-I', str(wire_helper), 'verify',
                              str(captures[0][2]), str(captures[1][2])], timeout=5).stdout)
        print('PASS wire mux=' + mux + ': ' + json.dumps(wire, sort_keys=True), flush=True)
        require(time.monotonic() - case_start <= CASE_SECONDS, 'Case deadline exceeded')
        print(f'PASS mux={mux}: wrong token and wrong expected peer source rejected before target; '
              f'{PAYLOAD_BYTES} bytes echoed exactly through generated run.sh launchers; '
              'bidirectional captured GRE headers verified', flush=True)
    finally:
        errors = cleanup_case(names)
        case_deadline = None
        if errors:
            raise RuntimeError('Owned-resource cleanup needs attention: ' + '; '.join(errors))


failure = None
try:
    signal.signal(signal.SIGINT, interrupted)
    signal.signal(signal.SIGTERM, interrupted)
    require(sys.platform.startswith('linux') and os.geteuid() == 0, 'Linux root required')
    clean_env = {'PATH': '/usr/sbin:/usr/bin:/sbin:/bin', 'LANG': 'C', 'LC_ALL': 'C'}
    ip = shutil.which('ip', path=clean_env['PATH'])
    python = shutil.which('python3', path=clean_env['PATH'])
    openssl = shutil.which('openssl', path=clean_env['PATH'])
    require(all((ip, python, openssl)), 'iproute2, python3 and openssl must already be installed; nothing is downloaded')
    require(Path('/dev/net/tun').is_char_device(), '/dev/net/tun must already exist; this lab never loads kernel modules')
    source = Path(sys.argv[1])
    require(source.is_absolute(), 'Binary path must be absolute')
    source_fd = os.open(source, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(source_fd, 'rb') as executable:
        info = os.fstat(executable.fileno())
        require(stat.S_ISREG(info.st_mode) and info.st_mode & 0o111, 'Binary must be a regular executable, not a symlink')
        require(not info.st_mode & (0o022 | stat.S_ISUID | stat.S_ISGID), 'Binary must not be group/world writable or set-ID')
        require(0 < info.st_size <= 128*1024*1024, 'Unexpected binary size')
        header = executable.read(64)
        machines = {'x86_64': 62, 'aarch64': 183}
        require(header[:6] == b'\x7fELF\x02\x01' and len(header) == 64,
                'Only a trusted 64-bit little-endian Linux ELF build is supported')
        require(struct.unpack_from('<H', header, 18)[0] == machines.get(platform.machine()), 'Binary architecture does not match this lab host')
        os.umask(0o077)
        with defer_interrupts():
            lab_dir = Path(tempfile.mkdtemp(prefix='gdt-gre-lab-', dir='/tmp'))
            lab_identity = identity(lab_dir)
        binary = lab_dir / 'ununknowntun-lab'
        # Execute an owned snapshot, not a mutable caller path. This is not a
        # security sandbox for an untrusted executable: only use your own build.
        executable.seek(0)
        with binary.open('xb') as snapshot:
            copied = 0
            while copied <= info.st_size:
                block = executable.read(min(1024*1024, info.st_size + 1 - copied))
                if not block:
                    break
                snapshot.write(block)
                copied += len(block)
            require(copied == info.st_size, 'Binary changed size while taking its private snapshot')
        after_copy = os.fstat(executable.fileno())
        require((info.st_size, info.st_mtime_ns, info.st_ctime_ns) ==
                (after_copy.st_size, after_copy.st_mtime_ns, after_copy.st_ctime_ns),
                'Binary changed while taking its private snapshot')
        os.chmod(binary, 0o700)
    for helper_argument, helper_name in [(sys.argv[2], 'gre-wire-check.py'), (sys.argv[3], 'spoof-pair.py')]:
        helper_source = Path(helper_argument)
        require(helper_source.is_absolute(), 'Helper path must be absolute')
        helper_fd = os.open(helper_source, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(helper_fd, 'rb') as helper:
            info = os.fstat(helper.fileno())
            require(stat.S_ISREG(info.st_mode) and not info.st_mode & (0o022 | stat.S_ISUID | stat.S_ISGID)
                    and 0 < info.st_size <= 128*1024, 'Helper must be a bounded, non-writable regular file')
            content = helper.read(128*1024 + 1)
            after_copy = os.fstat(helper.fileno())
            require(len(content) == info.st_size and (info.st_size, info.st_mtime_ns, info.st_ctime_ns) ==
                    (after_copy.st_size, after_copy.st_mtime_ns, after_copy.st_ctime_ns), 'Helper changed during snapshot')
            private_file(lab_dir / helper_name, content)
    wire_helper, pair_helper = lab_dir / 'gre-wire-check.py', lab_dir / 'spoof-pair.py'
    print('LOCAL LAB ONLY: two isolated namespace pairs, no external destination or default route.', flush=True)
    case('off')
    case('on')
except (OSError, RuntimeError, ValueError, subprocess.SubprocessError, InterruptedError) as exc:
    failure = str(exc)
finally:
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
    cleanup_errors = cleanup_case({name for name, _ in owned_namespaces}) if owned_namespaces else []
    # A timed-out creation helper may have created a handle without returning
    # proof of success. Report that exact name; never adopt/delete it by guess.
    uncertain_names = sorted(name for name in pending_namespaces if namespace_path(name).exists())
    if uncertain_names:
        cleanup_errors.append('Unconfirmed creation handles NOT deleted; inspect exact names: ' + ', '.join(uncertain_names))
    if cleanup_errors:
        failure = (failure + '; ' if failure else '') + '; '.join(cleanup_errors)
    if failure and lab_dir:
        print('FAIL: ' + failure, file=sys.stderr)
        for _process, _namespace, log in children:
            try:
                excerpt = '\n'.join(log_text(log).splitlines()[-12:])[-2500:]
                for secret in secrets_to_redact:
                    excerpt = excerpt.replace(secret, '[REDACTED]')
                if excerpt:
                    print(f'--- {log.name} (bounded diagnostic excerpt) ---\n{excerpt}', file=sys.stderr)
            except (OSError, RuntimeError):
                pass
    for output in log_handles:
        output.close()
    if lab_dir:
        try:
            require(lab_dir.parent == Path('/tmp') and lab_dir.name.startswith('gdt-gre-lab-')
                    and identity(lab_dir) == lab_identity and not lab_dir.is_symlink(),
                    f'Temporary directory identity changed; NOT deleting {lab_dir}')
            shutil.rmtree(lab_dir)
            require(not lab_dir.exists(), 'Temporary-directory cleanup unconfirmed')
        except (OSError, RuntimeError) as exc:
            failure = (failure + '; ' if failure else '') + str(exc)
    if failure:
        print('FAIL: ' + failure, file=sys.stderr)
        if owned_namespaces:
            print('Owned namespace handles requiring manual inspection: ' + ', '.join(n for n, _ in owned_namespaces), file=sys.stderr)
        sys.exit(1)
    print(f'PASS cleanup: {len(cleaned_namespaces)} owned namespaces and private temporary files removed.', flush=True)
    print('LOCAL RESULT ONLY: no ISP, Internet, performance, or Backhaul interoperability claim.', flush=True)
PY
