#!/usr/bin/env python3
"""Independent, bounded wire evidence for gre-netns-lab.sh, not a packet injector.

Capture runs only when explicitly invoked inside an owned Linux lab namespace.
Verification is offline and uses no tunnel codec, packet library, or network.
The tiny capture format records the AF_PACKET direction as well as Ethernet bytes.
Only a gracefully stopped, non-dropping capture is accepted as evidence.
"""

import argparse
import hashlib
import ipaddress
import json
import os
import signal
import socket
import stat
import struct
import sys
import time
from pathlib import Path

MAGIC = b"GDTWIRE1"
MAX_BYTES = 1048576
MAX_RECORDS = 4096
MAX_FRAME = 1514
MIN_PAYLOAD = 32768
PORT = 18443
OUTER = {"origin": ("198.51.100.10", "192.0.2.20"),
         "egress": ("198.51.100.20", "192.0.2.10")}
INNER = {"origin": ("10.77.0.1", "10.77.0.2"),
         "egress": ("10.77.0.2", "10.77.0.1")}
REAL = {"192.0.2.10", "192.0.2.20"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def checksum(data):
    """Internet one's-complement checksum, implemented independently of Go."""
    if len(data) % 2:
        data += b"\0"
    value = sum(struct.unpack("!%dH" % (len(data) // 2), data))
    while value >> 16:
        value = (value & 65535) + (value >> 16)
    return (~value) & 65535


def capture(interface, output, seconds):
    require(sys.platform.startswith("linux"), "capture requires Linux")
    require(0 < len(interface) <= 15 and interface.isalnum(), "unexpected lab interface name")
    require(1 <= seconds <= 100, "capture duration must be bounded to 100 seconds")
    require(Path(output).is_absolute(), "capture output must be absolute")
    stopped = False

    def stop(_signum, _frame):
        nonlocal stopped
        stopped = True

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    # ETH_P_ALL also receives outgoing packets. ETH_P_IP alone is insufficient
    # on kernels which deliver outgoing packets only through the ptype_all tap.
    # Protocol zero keeps the socket inactive until bind selects this interface;
    # otherwise a busy TUN/loopback packet could enter before the veth bind.
    with socket.socket(socket.AF_PACKET, socket.SOCK_RAW, 0) as wire:
        wire.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, MAX_BYTES)
        wire.bind((interface, 3))
        wire.settimeout(0.1)
        fd = os.open(output, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(fd, "wb") as evidence:
            evidence.write(MAGIC)
            records = frame_bytes = 0
            stored = len(MAGIC)
            deadline = time.monotonic() + seconds
            print("READY bounded AF_PACKET capture", flush=True)
            while not stopped:
                require(time.monotonic() < deadline, "capture deadline reached before explicit stop")
                try:
                    frame, _ancillary, flags, address = wire.recvmsg(65536)
                except socket.timeout:
                    continue
                require(not flags & socket.MSG_TRUNC, "truncated packet capture")
                require(14 <= len(frame) <= MAX_FRAME, "unexpected captured Ethernet size")
                require(records < MAX_RECORDS, "capture packet bound exceeded")
                require(stored + 4 + len(frame) + 512 <= MAX_BYTES, "capture byte bound exceeded")
                packet_type = address[2]
                require(0 <= packet_type <= 4, "unexpected packet direction")
                evidence.write(b"P" + struct.pack("!BH", packet_type, len(frame)) + frame)
                records += 1
                frame_bytes += len(frame)
                stored += 4 + len(frame)
            # Linux tpacket_stats is two native unsigned ints. A zero-drop
            # footer is required even when all expected payload was observed.
            packets, drops = struct.unpack("=II", wire.getsockopt(263, 6, 8))
            metadata = json.dumps({"records": records, "frame_bytes": frame_bytes,
                                   "socket_packets": packets, "drops": drops,
                                   "stop_reason": "signal", "complete": True},
                                  sort_keys=True, separators=(",", ":")).encode("ascii")
            require(len(metadata) <= 507, "capture footer too large")
            evidence.write(b"E" + struct.pack("!I", len(metadata)) + metadata)
            evidence.flush()
            os.fsync(evidence.fileno())
            print("STOPPED " + metadata.decode("ascii"), flush=True)
            require(drops == 0, "kernel dropped captured packets")


def read_capture(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        require(stat.S_ISREG(info.st_mode) and 0 < info.st_size <= MAX_BYTES,
                "capture is not a bounded regular file")
        data = stream.read(MAX_BYTES + 1)
    require(len(data) <= MAX_BYTES and data.startswith(MAGIC), "invalid capture size or magic")
    position, records, frame_bytes = len(MAGIC), [], 0
    while position < len(data):
        tag = data[position:position + 1]
        position += 1
        if tag == b"E":
            require(position + 4 <= len(data), "truncated capture footer length")
            size = struct.unpack_from("!I", data, position)[0]
            position += 4
            require(0 < size <= 507 and position + size == len(data), "invalid capture footer boundary")
            metadata = json.loads(data[position:].decode("ascii"))
            require(isinstance(metadata, dict), "invalid capture footer")
            require(metadata.get("complete") is True and metadata.get("stop_reason") == "signal",
                    "capture was not explicitly stopped and finalized")
            require(type(metadata.get("drops")) is int and metadata["drops"] == 0,
                    "capture reported packet loss")
            require(type(metadata.get("socket_packets")) is int and metadata["socket_packets"] >= len(records),
                    "invalid socket packet count")
            require(type(metadata.get("records")) is int and metadata["records"] == len(records)
                    and type(metadata.get("frame_bytes")) is int and metadata["frame_bytes"] == frame_bytes,
                    "capture footer counts do not match records")
            require(records, "empty capture")
            return records, metadata
        require(tag == b"P" and position + 3 <= len(data), "invalid packet record")
        packet_type, size = struct.unpack_from("!BH", data, position)
        position += 3
        require(0 <= packet_type <= 4 and 14 <= size <= MAX_FRAME and position + size <= len(data),
                "invalid packet boundary or direction")
        require(len(records) < MAX_RECORDS, "capture record bound exceeded")
        records.append((packet_type, data[position:position + size]))
        frame_bytes += size
        position += size
    raise ValueError("capture lacks a completed footer")


def ipv4(packet, label, exact=True):
    require(len(packet) >= 20 and packet[0] == 0x45, label + " is not option-free IPv4")
    total = struct.unpack_from("!H", packet, 2)[0]
    require(20 <= total <= len(packet), label + " invalid IPv4 length")
    if exact:
        require(total == len(packet), label + " trailing bytes")
    else:
        # Ethernet may pad a small IPv4 packet to a 60-byte frame.
        require(total == len(packet) or (len(packet) <= 46 and not any(packet[total:])),
                label + " unexpected Ethernet padding")
    packet = packet[:total]
    require(checksum(packet[:20]) == 0, label + " IPv4 checksum mismatch")
    require(struct.unpack_from("!H", packet, 6)[0] & ~0x4000 == 0, label + " fragmentation or reserved flag")
    require(packet[8] > 0, label + " invalid TTL")
    return packet, (socket.inet_ntoa(packet[12:16]), socket.inet_ntoa(packet[16:20]))


def check_arp(frame):
    arp = frame[14:]
    require(len(arp) >= 28 and arp[:6] == b"\x00\x01\x08\x00\x06\x04", "unexpected ARP format")
    require(struct.unpack_from("!H", arp, 6)[0] in (1, 2), "unexpected ARP operation")
    require(socket.inet_ntoa(arp[14:18]) in REAL | {"0.0.0.0"}
            and socket.inet_ntoa(arp[24:28]) in REAL, "ARP escaped the isolated real-peer pair")
    require(len(arp) == 28 or (len(arp) <= 46 and not any(arp[28:])), "unexpected ARP padding")


def check_ipv6_control(frame):
    packet = frame[14:]
    require(len(packet) >= 40 and packet[0] >> 4 == 6, "invalid IPv6 link-control packet")
    length = struct.unpack_from("!H", packet, 4)[0]
    require(len(packet) == 40 + length, "IPv6 length mismatch")
    source = ipaddress.IPv6Address(packet[8:24])
    destination = ipaddress.IPv6Address(packet[24:40])
    require(source.is_link_local or source.is_unspecified, "unexpected IPv6 source")
    require(destination.is_link_local or destination in ipaddress.IPv6Network("ff02::/16"),
            "IPv6 destination escaped the isolated link")
    next_header, position = packet[6], 40
    if next_header == 0:  # Kernel MLD includes one Hop-by-Hop Router Alert.
        require(position + 8 <= len(packet), "truncated IPv6 hop-by-hop header")
        next_header, extension_length = packet[position], (packet[position + 1] + 1) * 8
        require(extension_length <= 64 and position + extension_length <= len(packet),
                "invalid IPv6 hop-by-hop header")
        position += extension_length
    require(next_header == 58 and position + 8 <= len(packet)
            and packet[position] in (130, 131, 132, 133, 134, 135, 136, 143),
            "unexpected IPv6 traffic (only local neighbor/MLD control is allowed)")


def inspect(records, role):
    result = {direction: {"packets": 0, "tcp_payload_bytes": 0, "hashes": set()}
              for direction in OUTER}
    result["arp"] = result["ipv6_control"] = 0
    for packet_type, frame in records:
        ethertype = struct.unpack_from("!H", frame, 12)[0]
        if ethertype == 0x0806:
            check_arp(frame)
            result["arp"] += 1
            continue
        if ethertype == 0x86dd:
            check_ipv6_control(frame)
            result["ipv6_control"] += 1
            continue
        require(ethertype == 0x0800, "unexpected Ethernet protocol")
        require(packet_type in (0, 4), "unexpected IPv4 AF_PACKET direction")
        direction = role if packet_type == 4 else ("egress" if role == "origin" else "origin")
        outer, pair = ipv4(frame[14:], "outer", exact=False)
        require(pair == OUTER[direction], "outer source/destination or wire direction mismatch")
        require(outer[9] == 47, "non-GRE IPv4 traffic leaked onto carrier link")
        require(len(outer) >= 44 and outer[20:24] == b"\0\0\x08\x00", "unexpected GRE header")
        inner, pair = ipv4(outer[24:], "inner")
        require(pair == INNER[direction], "inner source/destination mismatch")
        require(inner[9] == 6, "inner payload is not carrier TCP")
        tcp = inner[20:]
        require(len(tcp) >= 20, "truncated carrier TCP")
        source, destination = struct.unpack_from("!HH", tcp)
        require(source > 0 and destination > 0 and
                (destination == PORT if direction == "origin" else source == PORT),
                "unexpected carrier TCP port")
        header_length = (tcp[12] >> 4) * 4
        require(20 <= header_length <= len(tcp), "invalid TCP header length")
        pseudo = inner[12:20] + b"\0\x06" + struct.pack("!H", len(tcp))
        require(checksum(pseudo + tcp) == 0, "carrier TCP checksum mismatch")
        result[direction]["packets"] += 1
        result[direction]["tcp_payload_bytes"] += len(tcp) - header_length
        result[direction]["hashes"].add(hashlib.sha256(outer).hexdigest())
    for direction in OUTER:
        require(result[direction]["packets"] > 0, role + " capture lacks " + direction + " packets")
        require(result[direction]["tcp_payload_bytes"] >= MIN_PAYLOAD,
                role + " capture lacks the bounded payload in " + direction + " direction")
    return result


def verify(origin_path, egress_path):
    captures = {}
    for role, path in (("origin", origin_path), ("egress", egress_path)):
        records, metadata = read_capture(path)
        captures[role] = inspect(records, role)
        captures[role]["frame_bytes"] = metadata["frame_bytes"]
        captures[role]["captured_frames"] = metadata["records"]
    common = {}
    for direction in OUTER:
        common[direction] = len(captures["origin"][direction]["hashes"] &
                                captures["egress"][direction]["hashes"])
        require(common[direction] > 0, "no identical " + direction + " wire packets on both links")
        for role in captures:
            del captures[role][direction]["hashes"]
    return {"outer_pairs": OUTER, "inner_pairs": INNER, "carrier_tcp_port": PORT,
            "captures": captures, "identical_packets_both_links": common,
            "unexpected_ipv4_packets": 0, "ipv4_and_tcp_checksums": "valid",
            "capture_byte_bound": MAX_BYTES, "capture_packet_bound": MAX_RECORDS}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    live = commands.add_parser("capture")
    live.add_argument("--interface", required=True)
    live.add_argument("--output", required=True)
    live.add_argument("--seconds", required=True, type=int)
    offline = commands.add_parser("verify")
    offline.add_argument("origin")
    offline.add_argument("egress")
    args = parser.parse_args()
    try:
        if args.command == "capture":
            capture(args.interface, args.output, args.seconds)
        else:
            print(json.dumps(verify(args.origin, args.egress), sort_keys=True))
    except (OSError, ValueError, struct.error) as error:
        parser.exit(1, "WIRE CHECK FAILED: " + str(error) + "\n")


if __name__ == "__main__":
    main()
