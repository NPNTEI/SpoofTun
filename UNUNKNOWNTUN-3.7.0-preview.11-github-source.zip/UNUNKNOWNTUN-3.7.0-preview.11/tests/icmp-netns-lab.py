#!/usr/bin/env python3
"""Opt-in native ICMP wire/payload lab; disposable local Linux VM only.

sudo python3 -I tests/icmp-netns-lab.py --binary /absolute/ununknowntun \
    --helper /absolute/packaging/icmp-pair.py
python3 -I tests/icmp-netns-lab.py --self-test

Creates only random private files, two new isolated namespaces and their veth.
No Internet/default route, firewall, sysctl, service or existing tunnel changes.
Uses generated native-icmp launchers. Requires sibling spoof-systemd-lab.py for
safe common lab primitives. WSS/Nginx is a separate test, not claimed here.
130s work plus20s cleanup; hard150s overall. Every child has its own watchdog.
"""
import argparse
import hashlib
import hmac
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import secrets
import shlex
import shutil
import signal
import socket
import stat
import struct
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock


sys.dont_write_bytecode = True
_loader = importlib.util.spec_from_file_location("icmp_lab_primitives", Path(__file__).with_name("spoof-systemd-lab.py"))
common = importlib.util.module_from_spec(_loader)
_loader.loader.exec_module(common)
require, LabError = common.require, common.LabError
MAX_CAPTURE = 2 * 1024 * 1024
PAYLOAD = bytes(range(256)) * 128
REVERSE_PAYLOAD = bytes(reversed(range(256))) * 128
OUTER = ("192.0.2.10", "192.0.2.20")
INNER = ("10.78.0.1", "10.78.0.2")
MAC_CONTEXT = b"ununknowntun-native-icmp-v1\x00"

CAPTURE = r'''
import json, os, signal, socket, struct, sys, time
active = True
def stop(*_):
    global active
    active = False
signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)
# Activate only on the owned interface. ETH_P_ALL is required for outgoing
# packets on kernels whose egress tap does not deliver ETH_P_IP subscriptions.
s = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, 0)
s.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 2097152)
s.bind((sys.argv[1], 3)); s.settimeout(0.2)
end = time.monotonic() + 100
size = packets = 0
fd = os.open(sys.argv[2], os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW, 0o600)
with os.fdopen(fd, 'wb') as out:
    print('READY', flush=True)
    while active and time.monotonic() < end:
        try: frame, _, flags, _ = s.recvmsg(2048)
        except socket.timeout: continue
        if flags & socket.MSG_TRUNC: raise SystemExit('capture packet truncated')
        if len(frame) < 34 or frame[12:14] != b'\x08\x00' or frame[23] != 1: continue
        ip = frame[14:]
        total = struct.unpack('!H', ip[2:4])[0]
        if not 20 <= total <= len(ip): raise SystemExit('truncated capture')
        ip = ip[:total]
        size += len(ip)+4; packets += 1
        if size > 2097152 or packets > 10000: raise SystemExit('capture bound exceeded')
        out.write(struct.pack('!I', len(ip))); out.write(ip)
    out.flush()
    os.fsync(out.fileno())
captured, drops = struct.unpack('=II', s.getsockopt(263, 6, 8))
s.close()
print('CAPTURE_RESULT=' + json.dumps({'records':packets,'drops':drops,'complete':not active}), flush=True)
if active or drops: raise SystemExit('incomplete or dropped capture')
'''

DUPLEX_SERVER = r'''
import hashlib, json, socket, threading, time
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(('127.0.0.1', 18082)); s.listen(1); s.settimeout(0.25)
print('READY', flush=True)
end = time.monotonic()+100
while time.monotonic() < end:
    try: c, _ = s.accept(); break
    except socket.timeout: continue
else: raise SystemExit('no application connection')
print('ACCEPT', flush=True)
with c:
    c.settimeout(15)
    outbound = bytes(reversed(range(256)))*128
    errors = []
    def send():
        try: c.sendall(outbound)
        except Exception as error: errors.append(type(error).__name__)
    writer = threading.Thread(target=send, daemon=True); writer.start()
    data = bytearray()
    while len(data) < 32768:
        chunk = c.recv(32768-len(data))
        if not chunk: raise SystemExit('short upstream')
        data.extend(chunk)
    writer.join(16)
    if writer.is_alive() or errors or data != bytes(range(256))*128: raise SystemExit('duplex mismatch')
print(json.dumps({'upstream_bytes':len(data),'upstream_sha256':hashlib.sha256(data).hexdigest()}), flush=True)
s.close()
'''

DUPLEX_CLIENT = r'''
import hashlib, json, socket, sys, threading, time
negative = sys.argv[1] == 'negative'
end = time.monotonic()+(6 if negative else 20)
connection = None
while time.monotonic() < end:
    try: connection = socket.create_connection(('127.0.0.1', 12055), timeout=0.25); break
    except OSError: time.sleep(0.05)
if connection is None: raise SystemExit('client listener unavailable')
with connection as c:
    c.settimeout(max(0.1,end-time.monotonic()))
    if negative:
        data = b''
        try: c.sendall(b'wrong-key probe'); data = c.recv(32768)
        except OSError: pass
        if data: raise SystemExit('wrong key delivered payload')
        print(json.dumps({'negative_no_payload':True})); raise SystemExit(0)
    errors = []
    def send():
        try: c.sendall(bytes(range(256))*128)
        except Exception as error: errors.append(type(error).__name__)
    writer = threading.Thread(target=send, daemon=True); writer.start()
    data = bytearray()
    while len(data) < 32768:
        chunk = c.recv(32768-len(data))
        if not chunk: raise SystemExit('short downstream')
        data.extend(chunk)
    writer.join(20)
    if writer.is_alive() or errors or data != bytes(reversed(range(256)))*128: raise SystemExit('duplex mismatch')
print(json.dumps({'downstream_bytes':len(data),'downstream_sha256':hashlib.sha256(data).hexdigest()}))
'''


def checksum(data):
    if len(data) % 2:
        data += b"\x00"
    total = sum(struct.unpack("!" + "H" * (len(data) // 2), data))
    while total >> 16:
        total = (total & 65535) + (total >> 16)
    return (~total) & 65535


def packet_mac(key, packet):
    return hmac.new(key, MAC_CONTEXT + packet[12:20] + packet[20:22] + packet[24:-32], hashlib.sha256).digest()


def inspect_packet(packet, key):
    """Independent parser; returns metadata only, never payload/key bytes."""
    require(96 <= len(packet) <= 1496 and packet[0] == 0x45 and packet[9] == 1,
            "Invalid native IPv4 header/protocol/length")
    require(struct.unpack_from("!H", packet, 2)[0] == len(packet) and checksum(packet[:20]) == 0 and
            struct.unpack_from("!H", packet, 6)[0] & 0xbfff == 0, "Invalid IPv4 checksum/fragmentation")
    source, destination = socket.inet_ntoa(packet[12:16]), socket.inet_ntoa(packet[16:20])
    require((source, destination) in (OUTER, OUTER[::-1]), "Unexpected outer IP tuple")
    require(packet[20] in (0, 8) and packet[21] == 0 and checksum(packet[20:]) == 0,
            "Invalid ICMP type/code/checksum")
    require(packet[28:32] == b"GDI1" and packet[32] == 1 and packet[35] == 0 and packet[62:64] == b"\x00\x00",
            "Invalid native protocol marker/version/reserved fields")
    direction, kind = packet[33], packet[34]
    sequence = struct.unpack_from("!Q", packet, 52)[0]
    body = packet[64:-32]
    require(sequence > 0 and any(packet[36:52]) and packet[24:26] == packet[36:38] and
            struct.unpack_from("!H", packet, 26)[0] == sequence & 65535 and
            struct.unpack_from("!H", packet, 60)[0] == len(body), "Invalid native correlation/body length")
    # Linux may automatically reflect Echo requests. Their copied direction
    # and MAC are NOT a native authenticated egress response.
    if (source, destination) == OUTER[::-1] and packet[20] == 0 and direction == 1:
        reflected = bytearray(packet)
        reflected[12:16], reflected[16:20] = packet[16:20], packet[12:16]
        reflected[20] = 8
        require(hmac.compare_digest(packet[-32:], packet_mac(key, reflected)), "Unrecognized/unauthenticated kernel reflection")
        return {"classification": "kernel_reflection", "direction": direction, "kind": kind, "body_bytes": len(body)}
    request = (source, destination) == OUTER
    require((direction, packet[20]) == ((1, 8) if request else (2, 0)), "Wrong authenticated direction/type")
    require((kind == 1 and request and not body) or (kind == 2 and not request and len(body) == 16) or
            (kind == 3 and request and len(body) == 16) or (kind == 4 and not request and not body) or
            (kind == 5 and (not body or len(body) >= 40)), "Invalid message kind/body")
    require(hmac.compare_digest(packet[-32:], packet_mac(key, packet)), "Native ICMP MAC mismatch")
    if kind == 5 and body:
        require(body[0] == 0x45 and body[9] == 6 and checksum(body[:20]) == 0 and
                struct.unpack_from("!H", body, 2)[0] == len(body) and struct.unpack_from("!H", body, 6)[0] & 0xbfff == 0,
                "Invalid inner IPv4/TCP carrier")
        require((socket.inet_ntoa(body[12:16]), socket.inet_ntoa(body[16:20])) == (INNER if request else INNER[::-1]),
                "Wrong inner TCP address tuple")
        source_port, destination_port = struct.unpack_from("!HH", body, 20)
        require((destination_port == 18443 and source_port > 0) if request else (source_port == 18443 and destination_port > 0),
                "Wrong inner TCP carrier port")
        require(20 <= (body[32] >> 4) * 4 <= len(body) - 20 and
                checksum(body[12:20] + b"\x00\x06" + struct.pack("!H", len(body) - 20) + body[20:]) == 0,
                "Invalid inner TCP header/checksum")
    return {"classification": "authenticated", "direction": direction, "kind": kind, "body_bytes": len(body)}


def read_capture(path):
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_size <= MAX_CAPTURE, "Unsafe or oversized capture")
    data = path.read_bytes()
    packets, offset = [], 0
    while offset < len(data):
        require(offset + 4 <= len(data), "Truncated capture record")
        size = struct.unpack_from("!I", data, offset)[0]
        offset += 4
        require(96 <= size <= 1496 and offset + size <= len(data), "Invalid capture record length")
        packets.append(data[offset:offset + size])
        offset += size
        require(len(packets) <= 10000, "Capture packet count exceeded")
    return packets


def wire_proof(packets, key, wrong_key=None):
    rows, wrong_requests, ignored = [], 0, 0
    for packet in packets:
        try:
            rows.append(inspect_packet(packet, key))
        except LabError:
            if wrong_key is None:
                raise
            row = inspect_packet(packet, wrong_key)
            if row["classification"] == "authenticated":
                require(row["direction"] == 1, "Wrong-key peer unexpectedly received an authenticated reply")
                wrong_requests += 1
            else:
                ignored += 1
    if wrong_key is not None:
        require(wrong_requests > 0, "No real wrong-key request was captured at egress")
        require(not any(row["classification"] == "authenticated" and row["direction"] == 2 for row in rows),
                "Egress authenticated the mismatched key")
        return {"wrong_key_requests_at_egress": wrong_requests, "kernel_reflections_excluded": ignored,
                "authenticated_wrong_key_replies": 0}
    authenticated = [row for row in rows if row["classification"] == "authenticated"]
    require({(1, 1), (2, 2), (1, 3), (2, 4)} <= {(row["direction"], row["kind"]) for row in authenticated},
            "Incomplete authenticated native handshake capture")
    counts = {direction: sum(row["direction"] == direction and row["kind"] == 5 and row["body_bytes"] > 0 for row in authenticated)
              for direction in (1, 2)}
    require(all(counts.values()), "No authenticated inner TCP carrier data in both directions")
    return {"protocol": 1, "outer_origin_to_egress": list(OUTER), "inner_origin_to_egress": list(INNER),
            "inner_carrier_port": 18443, "authenticated_data_packets": counts,
            "kernel_reflections_excluded": sum(row["classification"] == "kernel_reflection" for row in rows)}


class Lab(common.Lab):
    def __init__(self):
        super().__init__()
        self.work_end = self.started + 130
        self.end = self.started + 150
        self.prefix = "gdt-icmplab-" + secrets.token_hex(5)
        self.children = []

    def hard_deadline(self, _signum, _frame):
        state = {"namespaces": sorted(set(self.namespaces) | self.pending_namespaces),
                 "child_pids": [child.pid for child, _ in self.children], "directory": str(self.directory)}
        os.write(2, ("FAIL:150s deadline; inspect only owned resources: " + json.dumps(state) + "\n").encode())
        os._exit(124)

    def private_file(self, path, data):
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        with os.fdopen(descriptor, "wb") as output:
            output.write(data if isinstance(data, bytes) else data.encode())

    def namespace_command(self, namespace, arguments):
        self.verify_namespace(namespace)
        return [self.tools["ip"], "netns", "exec", namespace, *arguments]

    def start(self, namespace, arguments, label):
        log = self.directory / (label + ".log")
        remaining = min(100, self.end - time.monotonic() - 8)
        require(remaining > 0, "No child watchdog budget remains")
        arguments = [self.tools["timeout"], "--signal=TERM", "--kill-after=3s", str(round(remaining, 2)) + "s", *arguments]
        descriptor = os.open(log, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        def limits():
            import resource
            resource.setrlimit(resource.RLIMIT_FSIZE, (MAX_CAPTURE, MAX_CAPTURE))
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        with os.fdopen(descriptor, "wb") as output:
            child = subprocess.Popen(self.namespace_command(namespace, arguments), stdout=output, stderr=output,
                                     cwd=self.directory, env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"},
                                     start_new_session=True, preexec_fn=limits)
        self.children.append((child, log))
        return child, log

    def stop(self, child):
        if child.poll() is None:
            try:
                os.killpg(child.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                child.wait(timeout=min(2, self.remaining()))
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=min(2, self.remaining()))

    def log_text(self, log):
        with log.open("rb") as source:
            value = source.read(MAX_CAPTURE + 1)
        require(len(value) <= MAX_CAPTURE, "Child log exceeded size bound")
        return value.decode(errors="replace")

    def wait_for(self, predicate, seconds, description, children=()):
        end = time.monotonic() + min(seconds, self.remaining())
        while time.monotonic() < end:
            require(all(child.poll() is None for child in children), "Child exited before " + description)
            if predicate():
                return
            self.remaining()
            time.sleep(0.05)
        raise LabError("Timed out: " + description)

    def capture(self, namespace, link, label):
        path = self.directory / (label + ".capture")
        child, log = self.start(namespace, [sys.executable, "-I", "-u", "-c", CAPTURE, link, str(path)], label)
        self.wait_for(lambda: "READY" in self.log_text(log), 5, "capture readiness", [child])
        return child, path

    def finish_capture(self, child, path):
        require(child.poll() is None, "Capture exited before explicit completion")
        self.stop(child)
        log = next(log for process, log in self.children if process is child)
        results = [json.loads(line.split("=", 1)[1]) for line in self.log_text(log).splitlines() if line.startswith("CAPTURE_RESULT=")]
        require(len(results) == 1 and results[0].get("complete") is True and results[0].get("drops") == 0,
                "Capture completion/drop check failed")
        packets = read_capture(path)
        require(results[0].get("records") == len(packets), "Capture record count mismatch")
        return packets

    def execute(self, binary, helper):
        require(platform.system() == "Linux" and os.geteuid() == 0, "Requires explicit disposable local Linux VM/root")
        require(Path("/dev/net/tun").exists(), "/dev/net/tun required")
        for name in ("ip", "timeout", "systemd-detect-virt", "openssl"):
            self.tools[name] = shutil.which(name, path="/usr/sbin:/usr/bin:/sbin:/bin")
            require(self.tools[name], "Missing preinstalled tool: " + name)
        self.run([self.tools["systemd-detect-virt"], "--vm", "--quiet"])
        helper = Path(helper)
        require(helper.is_absolute() and helper.name == "icmp-pair.py" and helper.is_file() and not helper.is_symlink(), "Use explicit trusted absolute icmp-pair.py")
        parent = Path("/var/tmp")
        common.verify_lab_parent(parent)
        os.umask(0o077)
        self.directory = Path(tempfile.mkdtemp(prefix=self.prefix + "-", dir=parent))
        self.directory_identity = common.identity(self.directory)
        snapshot, digest = self.snapshot_binary(Path(binary))
        origin, egress = self.prefix + "-o", self.prefix + "-e"
        self.own_namespace(origin)
        self.own_namespace(egress)
        self.ip("-n", origin, "link", "add", "gdi-o", "type", "veth", "peer", "name", "gdi-e", "netns", egress)
        for namespace, link, local, peer in ((origin, "gdi-o", *OUTER), (egress, "gdi-e", *OUTER[::-1])):
            self.ip("-n", namespace, "link", "set", "lo", "up")
            self.ip("-n", namespace, "address", "add", local + "/32", "dev", link)
            self.ip("-n", namespace, "link", "set", link, "mtu", "1500", "up")
            self.ip("-n", namespace, "-4", "route", "add", peer + "/32", "dev", link, "src", local)
            routes = json.loads(self.ip("-n", namespace, "-j", "-4", "route", "show")[1])
            links = json.loads(self.ip("-n", namespace, "-j", "link", "show")[1])
            require(len(routes) == 1 and routes[0].get("dst") in (peer, peer + "/32") and routes[0].get("dev") == link,
                    "Unexpected/default namespace route")
            require({item["ifname"] for item in links} == {"lo", link}, "Unexpected namespace interface")
        pair_dir = self.directory / "pair"
        spec = {"mode": "native-icmp", "pair_id": "lab-" + self.prefix.rsplit("-", 1)[1], "authorized": True,
                "binary_path": str(snapshot), "install_dir": str(pair_dir), "mtu": 1200, "poll_ms": 20,
                "origin": {"interface": "gdi-o", "tun_name": "gdi-origin", "real_ip": OUTER[0], "inner_ip": INNER[0]},
                "egress": {"interface": "gdi-e", "tun_name": "gdi-egress", "real_ip": OUTER[1], "inner_ip": INNER[1]}}
        spec_path = self.directory / "spec.json"
        self.private_file(spec_path, json.dumps(spec))
        self.run(self.namespace_command(origin, [sys.executable, "-I", str(helper), "--spec", str(spec_path), "--output", str(pair_dir)]), seconds=25)
        self.run(self.namespace_command(origin, [sys.executable, "-I", str(helper), "--check-pair", str(pair_dir)]), seconds=15)
        key = bytes.fromhex((pair_dir / "origin/icmp.key").read_text().strip())
        wrong = secrets.token_bytes(32)
        require(wrong != key, "Random negative key collided")
        self.private_values += [key.hex(), wrong.hex(), (pair_dir / "origin/token").read_text().strip()]
        for role, namespace in (("origin", origin), ("egress", egress)):
            self.run(self.namespace_command(namespace, ["/bin/sh", str(pair_dir / role / "check.sh")]), seconds=8)
        target, target_log = self.start(egress, [sys.executable, "-I", "-u", "-c", DUPLEX_SERVER], "duplex-target")
        self.wait_for(lambda: "READY" in self.log_text(target_log), 5, "target readiness", [target])
        server, _ = self.start(egress, ["/bin/sh", str(pair_dir / "egress/run.sh")], "egress")
        listener = "from pathlib import Path; import sys; sys.exit(0 if any(x.split()[1]=='02004E0A:480B' and x.split()[3]=='0A' for x in Path('/proc/net/tcp').read_text().splitlines()[1:]) else 1)"
        self.wait_for(lambda: self.run(self.namespace_command(egress, [sys.executable, "-I", "-c", listener]), check=False)[0] == 0,
                      10, "egress inner TLS listener", [server, target])
        bad_key = self.directory / "wrong.key"
        self.private_file(bad_key, wrong.hex() + "\n")
        bad_config = json.loads((pair_dir / "origin/icmp.json").read_text())
        bad_config.update(key_file=str(bad_key), tun_name="gdi-bad")
        bad_path = self.directory / "wrong.json"
        self.private_file(bad_path, json.dumps(bad_config))
        args = shlex.split((pair_dir / "origin/run.sh").read_text().split("exec ", 1)[1])
        args[args.index("-icmp-config") + 1] = str(bad_path)
        capture, captured = self.capture(egress, "gdi-e", "wrong-key-wire")
        bad, _ = self.start(origin, args, "wrong-key-origin")
        negative = json.loads(self.run(self.namespace_command(origin, [sys.executable, "-I", "-c", DUPLEX_CLIENT, "negative"]), seconds=8)[1])
        require(negative == {"negative_no_payload": True} and "ACCEPT" not in self.log_text(target_log), "Wrong key reached target")
        require(server.poll() is None and bad.poll() is None, "Wrong-key phase failed without live peers")
        self.stop(bad)
        negative_wire = wire_proof(self.finish_capture(capture, captured), key, wrong)
        self.wait_for(lambda: self.ip("-n", origin, "link", "show", "dev", "gdi-bad", check=False)[0] != 0,
                      5, "negative owned TUN removal", [server, target])
        capture, captured = self.capture(egress, "gdi-e", "positive-wire")
        client, _ = self.start(origin, ["/bin/sh", str(pair_dir / "origin/run.sh")], "origin")
        positive = json.loads(self.run(self.namespace_command(origin, [sys.executable, "-I", "-c", DUPLEX_CLIENT, "positive"]), seconds=23)[1])
        require(positive == {"downstream_bytes": len(REVERSE_PAYLOAD), "downstream_sha256": hashlib.sha256(REVERSE_PAYLOAD).hexdigest()},
                "Downstream payload mismatch")
        self.wait_for(lambda: target.poll() is not None, 5, "upstream target completion", [client, server])
        require(target.returncode == 0, "Target did not verify upstream payload")
        upstream = json.loads(self.log_text(target_log).splitlines()[-1])
        require(upstream == {"upstream_bytes": len(PAYLOAD), "upstream_sha256": hashlib.sha256(PAYLOAD).hexdigest()}, "Upstream payload mismatch")
        positive_wire = wire_proof(self.finish_capture(capture, captured), key)
        return {"result": "PASS", "mode": "native-icmp", "mux": "on", "binary_sha256": digest,
                "payload": dict(positive, **upstream), "wire": positive_wire, "negative": negative_wire,
                "scope": "isolated local VM; not WAN/provider or WSS evidence"}

    def cleanup(self):
        self.cleaning = True
        failures = []
        for child, _ in reversed(self.children):
            try:
                self.stop(child)
                require(child.poll() is not None, "Owned child still running: " + str(child.pid))
            except Exception as error:
                failures.append("Owned child " + str(child.pid) + ": " + str(error))
        return failures + super().cleanup()

    def diagnostics(self):
        for child, log in self.children[-8:]:
            try:
                lines = self.log_text(log).splitlines()[-8:]
                print("OWNED CHILD " + log.name + " exit=" + str(child.poll()) + ": " +
                      common.diagnostic_text("\n".join(lines), self.private_values), file=sys.stderr, flush=True)
            except Exception:
                print("Owned child diagnostic unavailable: " + log.name, file=sys.stderr)


def test_packet(key, direction=1, kind=1, body=b"", sequence=1):
    packet = bytearray(96 + len(body))
    packet[0], packet[8], packet[9] = 0x45, 64, 1
    struct.pack_into("!H", packet, 2, len(packet))
    struct.pack_into("!H", packet, 6, 0x4000)
    source, destination = OUTER if direction == 1 else OUTER[::-1]
    packet[12:16], packet[16:20] = socket.inet_aton(source), socket.inet_aton(destination)
    packet[20] = 8 if direction == 1 else 0
    packet[28:32], packet[32], packet[33], packet[34] = b"GDI1", 1, direction, kind
    packet[36:52] = b"s" * 16
    packet[24:26] = packet[36:38]
    struct.pack_into("!H", packet, 26, sequence & 65535)
    struct.pack_into("!Q", packet, 52, sequence)
    struct.pack_into("!H", packet, 60, len(body))
    packet[64:-32] = body
    packet[-32:] = packet_mac(key, packet)
    struct.pack_into("!H", packet, 10, checksum(packet[:20]))
    struct.pack_into("!H", packet, 22, checksum(packet[20:]))
    return bytes(packet)


class OfflineTests(unittest.TestCase):
    def test_valid_handshake_auth_and_wrong_keys(self):
        key = b"k" * 32
        for direction, kind, body in ((1, 1, b""), (2, 2, b"c" * 16), (1, 3, b"c" * 16), (2, 4, b"")):
            packet = test_packet(key, direction, kind, body)
            self.assertEqual(inspect_packet(packet, key)["classification"], "authenticated")
            with self.assertRaises(LabError):
                inspect_packet(packet, b"x" * 32)

    def test_kernel_reflection_is_not_authenticated_downlink(self):
        key = b"k" * 32
        packet = bytearray(test_packet(key))
        packet[12:16], packet[16:20] = packet[16:20], packet[12:16]
        packet[20] = 0
        packet[10:12], packet[22:24] = b"\0\0", b"\0\0"
        struct.pack_into("!H", packet, 10, checksum(packet[:20]))
        struct.pack_into("!H", packet, 22, checksum(packet[20:]))
        self.assertEqual(inspect_packet(bytes(packet), key)["classification"], "kernel_reflection")
        with self.assertRaises(LabError):
            wire_proof([bytes(packet)], key)

    def test_wire_negative_requires_real_authenticated_wrong_key_requests(self):
        good, bad = b"g" * 32, b"b" * 32
        result = wire_proof([test_packet(bad)], good, bad)
        self.assertEqual(result["wrong_key_requests_at_egress"], 1)
        with self.assertRaises(LabError):
            wire_proof([], good, bad)
        with self.assertRaises(LabError):
            wire_proof([test_packet(bad), test_packet(good, 2, 2, b"c" * 16)], good, bad)

    def test_complete_positive_wire_proof_requires_inner_tcp_both_ways(self):
        key = b"k" * 32
        packets = [test_packet(key, direction, kind, body) for direction, kind, body in
                   ((1, 1, b""), (2, 2, b"c" * 16), (1, 3, b"c" * 16), (2, 4, b""))]
        with self.assertRaises(LabError):
            wire_proof(packets, key)
        for direction in (1, 2):
            body = bytearray(40)
            body[0], body[8], body[9], body[32] = 0x45, 64, 6, 0x50
            struct.pack_into("!H", body, 2, len(body))
            source, destination = INNER if direction == 1 else INNER[::-1]
            body[12:16], body[16:20] = socket.inet_aton(source), socket.inet_aton(destination)
            struct.pack_into("!HH", body, 20, *((45000, 18443) if direction == 1 else (18443, 45000)))
            struct.pack_into("!H", body, 10, checksum(body[:20]))
            pseudo = body[12:20] + b"\x00\x06" + struct.pack("!H", 20)
            struct.pack_into("!H", body, 36, checksum(pseudo + body[20:]))
            packets.append(test_packet(key, direction, 5, bytes(body), sequence=2))
            corrupt = bytearray(body)
            corrupt[36] ^= 1
            with self.assertRaises(LabError):
                inspect_packet(test_packet(key, direction, 5, bytes(corrupt), sequence=3), key)
        self.assertEqual(wire_proof(packets, key)["authenticated_data_packets"], {1: 1, 2: 1})

    def test_truncation_checksum_tuple_and_mac_corruption_rejected(self):
        key = b"k" * 32
        packet = test_packet(key)
        for index in (0, 2, 6, 9, 12, 16, 20, 21, 28, 32, 33, 34, 35, 36, 52, 60, 62, 70):
            data = bytearray(packet)
            data[index] ^= 1
            with self.subTest(index=index), self.assertRaises(LabError):
                inspect_packet(bytes(data), key)
        for size in (0, 20, 95, len(packet) - 1):
            with self.assertRaises(LabError):
                inspect_packet(packet[:size], key)

    def test_capture_bounds_and_child_code_syntax(self):
        for name, source in (("capture", CAPTURE), ("server", DUPLEX_SERVER), ("client", DUPLEX_CLIENT)):
            compile(source, name, "exec")
        with tempfile.TemporaryDirectory(prefix="gdt-icmp-wire-") as directory:
            path = Path(directory) / "capture"
            packet = test_packet(b"k" * 32)
            path.write_bytes(struct.pack("!I", len(packet)) + packet)
            self.assertEqual(read_capture(path), [packet])
            for contents in (b"\0", struct.pack("!I", 100000), struct.pack("!I", 96) + packet[:80]):
                path.write_bytes(contents)
                with self.assertRaises(LabError):
                    read_capture(path)

    def test_budget_cleanup_continues_and_no_systemd_units(self):
        lab = Lab()
        self.assertAlmostEqual(lab.work_end - lab.started, 130)
        self.assertAlmostEqual(lab.end - lab.started, 150)
        self.assertEqual(lab.units, {})
        child = mock.Mock(pid=123)
        lab.children = [(child, Path("/owned/log"))]
        lab.stop = mock.Mock(side_effect=OSError("synthetic stop failure"))
        with mock.patch.object(common.Lab, "cleanup", return_value=[]) as cleanup:
            errors = lab.cleanup()
        cleanup.assert_called_once()
        self.assertIn("Owned child123", errors[0].replace("child ", "child"))

    def test_capture_requires_explicit_completion_zero_drops_and_exact_records(self):
        lab = Lab()
        child = mock.Mock()
        child.poll.return_value = None
        lab.children = [(child, Path("/owned/capture.log"))]
        lab.stop = mock.Mock()
        with mock.patch(__name__ + ".read_capture", return_value=[b"packet"]):
            for metadata in ({"complete": False, "drops": 0, "records": 1}, {"complete": True, "drops": 1, "records": 1},
                             {"complete": True, "drops": 0, "records": 2}):
                lab.log_text = mock.Mock(return_value="CAPTURE_RESULT=" + json.dumps(metadata))
                with self.assertRaises(LabError):
                    lab.finish_capture(child, Path("/owned/capture"))
            lab.log_text = mock.Mock(return_value='CAPTURE_RESULT={"complete":true,"drops":0,"records":1}')
            self.assertEqual(lab.finish_capture(child, Path("/owned/capture")), [b"packet"])


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--binary", help="absolute trusted matching Linux binary")
    parser.add_argument("--helper", help="absolute paired icmp-pair.py with sibling spoof-pair.py")
    parser.add_argument("--mode", choices=("native-icmp",), default="native-icmp")
    parser.add_argument("--nginx", help="reserved; this lab does not claim WSS/Nginx coverage")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args(argv)
    if args.self_test:
        require(not args.binary and not args.helper and not args.nginx, "Offline self-test cannot activate a lab")
        result = unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromTestCase(OfflineTests))
        return 0 if result.wasSuccessful() else 1
    parser.error("--binary and --helper required; --nginx needs the separate WSS lab") if not args.binary or not args.helper or args.nginx else None
    lab = Lab()
    signal.signal(signal.SIGALRM, lab.hard_deadline)
    signal.setitimer(signal.ITIMER_REAL, max(0.1, lab.end - time.monotonic()))
    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, lambda *_: setattr(lab, "interrupted", True))
    report, error = None, None
    try:
        report = lab.execute(args.binary, args.helper)
    except Exception as failure:
        error = common.diagnostic_text(str(failure), lab.private_values)
        lab.diagnostics()
    finally:
        cleanup = lab.cleanup()
        signal.setitimer(signal.ITIMER_REAL, 0)
    if error or cleanup:
        print("FAIL: " + (error or "cleanup incomplete"), file=sys.stderr)
        for failure in cleanup:
            print("CLEANUP ATTENTION: " + common.diagnostic_text(failure, lab.private_values), file=sys.stderr)
        return 1
    report["cleanup"] = "owned children reaped; namespaces/veth/private files removed"
    report["elapsed_seconds"] = round(time.monotonic() - lab.started, 3)
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
