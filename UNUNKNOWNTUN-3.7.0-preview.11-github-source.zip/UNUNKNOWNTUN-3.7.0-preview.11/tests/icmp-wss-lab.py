#!/usr/bin/env python3
"""Opt-in full WSS/Nginx/real ICMP Echo lab; disposable local Linux VM only.

sudo python3 -I tests/icmp-wss-lab.py --run-local-lab \
    --binary /absolute/ununknowntun --nginx /usr/sbin/nginx
python3 -I tests/icmp-wss-lab.py --self-test

Needs existing iproute2, timeout, openssl, systemd-detect-virt, Nginx, and sibling
nginx_integration.py, icmp-netns-lab.py and spoof-systemd-lab.py. Installs nothing.
All four services run in one new isolated network namespace; a second namespace
is the real kernel Echo target. Only their private veth, addresses and neighbor
entry change. No host route, firewall, sysctl, service, Internet or public DNS.
90s work +30s cleanup; hard120s, with child watchdogs. SIGKILL/kernel failures
may leave the exact named resources reported by the hard watchdog.
PASS proves local WSS + Nginx + matched ICMP payload, not Cloudflare/WAN/ECH
reachability, system ping support, a TUN adapter, or generated-service sandboxing.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import re
import secrets
import shutil
import signal
import socket
import ssl
import stat
import struct
import sys
import tempfile
import time
import unittest
from unittest import mock

sys.dont_write_bytecode = True


def sibling(name, file):
    loader = importlib.util.spec_from_file_location(name, Path(__file__).with_name(file))
    module = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(module)
    return module


native = sibling("icmp_wss_lab_primitives", "icmp-netns-lab.py")
fixture = sibling("icmp_wss_nginx_fixture", "nginx_integration.py")
common = native.common
require, LabError = common.require, common.LabError
SOURCE, TARGET = "192.0.2.10", "192.0.2.20"
PAYLOAD_BYTES = 64


def read_echo_capture(path):
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_size <= 65536,
            "Unsafe or oversized Echo capture")
    data = path.read_bytes()
    packets, offset = [], 0
    while offset < len(data):
        require(offset + 4 <= len(data), "Truncated Echo capture record")
        size = struct.unpack_from("!I", data, offset)[0]
        offset += 4
        require(28 <= size <= 2048 and offset + size <= len(data), "Invalid Echo capture record length")
        packets.append(data[offset:offset + size])
        offset += size
        require(len(packets) <= 128, "Echo capture packet-count bound exceeded")
    return packets


def echo_wire_proof(packets, expected_requests, expected_replies):
    requests, replies = {}, {}
    for packet in packets:
        require(len(packet) >= 28 and packet[0] >> 4 == 4 and packet[9] == 1, "Non-IPv4/ICMP capture")
        ihl = (packet[0] & 15) * 4
        require(20 <= ihl <= 60 and ihl + 8 <= len(packet) and
                struct.unpack_from("!H", packet, 2)[0] == len(packet) and
                struct.unpack_from("!H", packet, 6)[0] & 0x3fff == 0 and
                native.checksum(packet[:ihl]) == 0, "Invalid captured IPv4 header")
        echo = packet[ihl:]
        require(len(echo) == 8 + 16 + PAYLOAD_BYTES and echo[1] == 0 and
                native.checksum(echo) == 0, "Captured Echo size/code/checksum mismatch")
        source, target = socket.inet_ntoa(packet[12:16]), socket.inet_ntoa(packet[16:20])
        if echo[0] == 8 and (source, target) == (SOURCE, TARGET):
            rows = requests
        elif echo[0] == 0 and (source, target) == (TARGET, SOURCE):
            rows = replies
        else:
            raise LabError("Captured packet has wrong Echo type/source/destination")
        key = (echo[4:8], echo[8:])  # exact id + sequence + nonce + full payload
        require(key not in rows, "Duplicate raw Echo packet was captured")
        rows[key] = struct.unpack_from("!H", echo, 6)[0]
    require(len(requests) == expected_requests and len(replies) == expected_replies,
            "Raw Echo request/reply count differs from the bounded test")
    require(set(replies).issubset(requests), "Echo reply identity/nonce/payload did not exactly match its request")
    if expected_requests == expected_replies:
        require(set(requests) == set(replies), "Missing matched raw Echo reply")
    require(sorted(requests.values()) == list(range(1, expected_requests + 1)),
            "Raw Echo sequence or retransmission mismatch")
    return {"captured_requests": len(requests), "captured_matching_replies": len(replies),
            "source_destination_checksum_id_sequence_nonce_payload_verified": True,
            "configured_payload_bytes": PAYLOAD_BYTES, "internal_nonce_bytes": 16}


def validate_ping_output(code, text, expected_count):
    value = json.loads(text)
    require(type(value) is dict and value.get("target") == TARGET, "Ping result target mismatch")
    require(type(value.get("sent")) is int and type(value.get("received")) is int and
            type(value.get("replies")) is list, "Invalid ping result schema")
    if expected_count:
        require(code == 0 and value["sent"] == expected_count and value["received"] == expected_count and
                len(value["replies"]) == expected_count, "Real ICMP ping did not fully succeed")
        for sequence, row in enumerate(value["replies"], 1):
            require(row.get("sequence") == sequence and row.get("bytes") == PAYLOAD_BYTES and
                    type(row.get("round_trip_ms")) in (int, float) and 0 <= row["round_trip_ms"] <= 3000 and
                    type(row.get("icmp_rtt_ms")) in (int, float) and 0 <= row["icmp_rtt_ms"] <= 3000,
                    "Invalid ICMP reply/RTT evidence")
    else:
        require(code != 0 and value["received"] == 0 and not value["replies"],
                "Negative test reported successful ICMP")
    return value


class Lab(native.Lab):
    def __init__(self):
        super().__init__()
        self.work_end = self.started + 90
        self.end = self.started + 120
        self.prefix = "gdt-iwlab-" + secrets.token_hex(5)

    def hard_deadline(self, _signum, _frame):
        state = {"namespaces": sorted(set(self.namespaces) | self.pending_namespaces),
                 "child_pids": [child.pid for child, _ in self.children], "directory": str(self.directory)}
        os.write(2, ("FAIL:120s deadline; inspect only owned resources: " + json.dumps(state) + "\n").encode())
        os._exit(124)

    def ping(self, namespace, binary, path):
        started = time.monotonic()
        code, output, error = self.run(self.namespace_command(namespace, [str(binary), "-icmp-ping", str(path)]),
                                       seconds=12, check=False)
        require(len(output) < 16384 and len(error) < 16384, "Adapter output exceeded diagnostic bound")
        return code, output, time.monotonic() - started

    def finish_echo_capture(self, child, path):
        # The inherited gate requires alive-before-stop, explicit completion,
        # zero kernel capture drops and a matching record count. An empty or
        # failed observer alone can never prove that no ICMP packet was sent.
        verified = self.finish_capture(child, path)
        require(verified == read_echo_capture(path), "Echo capture changed after completion")
        return verified

    def execute(self, binary, nginx):
        require(platform.system() == "Linux" and os.geteuid() == 0,
                "Explicit lab requires root on a disposable local Linux VM")
        for name in ("ip", "timeout", "systemd-detect-virt", "openssl"):
            self.tools[name] = shutil.which(name, path="/usr/sbin:/usr/bin:/sbin:/bin")
            require(self.tools[name], "Missing preinstalled local tool: " + name)
        self.run([self.tools["systemd-detect-virt"], "--vm", "--quiet"])
        nginx = Path(nginx)
        require(nginx.is_absolute() and nginx.is_file() and not nginx.is_symlink() and
                os.access(nginx, os.X_OK), "Use an absolute trusted existing Nginx executable, not a symlink")
        require(nginx.stat().st_mode & 0o6022 == 0, "Nginx must be non-set-ID and not group/world writable")
        parent = Path("/var/tmp")
        common.verify_lab_parent(parent)
        os.umask(0o077)
        self.directory = Path(tempfile.mkdtemp(prefix=self.prefix + "-", dir=parent))
        self.directory_identity = common.identity(self.directory)
        snapshot, digest = self.snapshot_binary(Path(binary))
        version = self.run([str(snapshot), "-version"])[1].strip()
        nginx_version = self.run([str(nginx), "-v"], check=False)[2].strip()
        main_ns, target_ns = self.prefix + "-m", self.prefix + "-t"
        self.own_namespace(main_ns)
        self.own_namespace(target_ns)
        self.ip("-n", main_ns, "link", "add", "gdiw-m", "type", "veth", "peer", "name", "gdiw-t", "netns", target_ns)
        for namespace, link, address in ((main_ns, "gdiw-m", SOURCE), (target_ns, "gdiw-t", TARGET)):
            self.ip("-n", namespace, "link", "set", "lo", "up")
            self.ip("-n", namespace, "address", "add", address + "/24", "dev", link)
            self.ip("-n", namespace, "link", "set", link, "up")
        # This instance has no host connection and no default route.
        self.run([self.tools["openssl"], "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "1",
                  "-subj", "/CN=" + fixture.HOST, "-keyout", str(self.directory / "key.pem"),
                  "-out", str(self.directory / "certificate.pem")], seconds=8)
        fingerprint = hashlib.sha256(ssl.PEM_cert_to_DER_cert((self.directory / "certificate.pem").read_text())).hexdigest()
        (self.directory / "logs").mkdir(mode=0o700)
        token, key, wrong_key = secrets.token_hex(32), secrets.token_hex(32), secrets.token_hex(32)
        self.private_values += [token, key, wrong_key]
        self.private_file(self.directory / "token", token + "\n")
        self.private_file(self.directory / "icmp.key", key + "\n")
        self.private_file(self.directory / "wrong.key", wrong_key + "\n")
        front, backend, origin, relay = 18443, 18084, 12056, 18083
        endpoint = "127.0.0.1:" + str(relay)
        common_config = {"target": TARGET, "key_file": str(self.directory / "icmp.key"),
                         "authorized": True, "timeout_ms": 3000}
        relay_config = dict(common_config, role="egress", listen=endpoint)
        ping_config = dict(common_config, role="origin", connect="127.0.0.1:" + str(origin),
                           count=3, interval_ms=1000, payload_bytes=PAYLOAD_BYTES)
        for name, config in (("relay.json", relay_config), ("ping.json", ping_config),
                             ("wrong.json", dict(ping_config, key_file=str(self.directory / "wrong.key")))):
            self.private_file(self.directory / name, json.dumps(config))
            self.run([str(snapshot), "-check-icmp-relay-config", str(self.directory / name)])
        conf = self.directory / "nginx.conf"
        self.private_file(conf, fixture.nginx_config(self.directory, front, backend))
        self.run(self.namespace_command(main_ns, [str(nginx), "-p", str(self.directory) + "/", "-c", str(conf), "-t"]))
        frontend, _ = self.start(main_ns, [str(nginx), "-p", str(self.directory) + "/", "-c", str(conf)], "nginx")
        adapter, _ = self.start(main_ns, [str(snapshot), "-icmp-relay", str(self.directory / "relay.json")], "relay")
        tunnel_common = ["-transport", "wss", "-mux", "on", "-ech-mode", "off", "-tls-fragment", "off",
                         "-ws-host", fixture.HOST, "-ws-path", fixture.WS_PATH, "-path-rotation", "0",
                         "-token-file", str(self.directory / "token"), "-stats", "1s", "-max-streams", "16",
                         "-max-memory", "134217728", "-write-timeout", "5s"]
        egress, egress_log = self.start(main_ns, [str(snapshot), "-mode", "egress", "-listen", "127.0.0.1:" + str(backend),
                                               "-allow", endpoint] + tunnel_common, "egress")
        self.wait_for(lambda: "[egress] listening on" in self.log_text(egress_log), 10, "WSS backend", [frontend, adapter, egress])
        client, client_log = self.start(main_ns, [str(snapshot), "-mode", "origin", "-listen", "127.0.0.1:" + str(origin),
                                               "-connect", "127.0.0.1:" + str(front), "-target", endpoint,
                                               "-sni", fixture.HOST, "-fingerprint", fingerprint,
                                               "-sessions-min", "1", "-sessions", "1"] + tunnel_common, "origin")
        self.wait_for(lambda: "tunnel session established" in self.log_text(client_log) and
                      "[origin] listening on" in self.log_text(client_log), 15, "real WSS carrier",
                      [frontend, adapter, egress, client])
        capture, path = self.capture(main_ns, "gdiw-m", "positive-wire")
        code, output, elapsed = self.ping(main_ns, snapshot, self.directory / "ping.json")
        positive = validate_ping_output(code, output, 3)
        # The raw client and packet observer are independent processes. Allow
        # the observer to drain the final already-received kernel Echo reply.
        self.remaining()
        time.sleep(0.25)
        positive_wire = echo_wire_proof(self.finish_echo_capture(capture, path), 3, 3)
        capture, path = self.capture(main_ns, "gdiw-m", "wrong-key-wire")
        code, output, wrong_elapsed = self.ping(main_ns, snapshot, self.directory / "wrong.json")
        wrong = validate_ping_output(code, output, 0)
        require(wrong["sent"] == 0 and wrong_elapsed < 5, "Wrong key reached raw-probe submission or exceeded deadline")
        wrong_wire = echo_wire_proof(self.finish_echo_capture(capture, path), 0, 0)
        # Pin only this namespace's known neighbor, then unassign only the owned
        # target address. A request goes onto the veth but no host owns its IP.
        self.verify_namespace(target_ns)
        link = json.loads(self.ip("-j", "-n", target_ns, "link", "show", "dev", "gdiw-t")[1])
        mac = link[0]["address"]
        require(re.fullmatch(r"(?:[0-9a-f]{2}:){5}[0-9a-f]{2}", mac), "Invalid owned veth MAC")
        self.ip("-n", main_ns, "neighbor", "replace", TARGET, "lladdr", mac, "nud", "permanent", "dev", "gdiw-m")
        self.ip("-n", target_ns, "address", "del", TARGET + "/24", "dev", "gdiw-t")
        capture, path = self.capture(main_ns, "gdiw-m", "no-reply-wire")
        code, output, no_reply_elapsed = self.ping(main_ns, snapshot, self.directory / "ping.json")
        no_reply = validate_ping_output(code, output, 0)
        require(no_reply["sent"] == 1 and no_reply_elapsed <= 5, "No-reply test retried, sent multiple probes, or exceeded bound")
        no_reply_wire = echo_wire_proof(self.finish_echo_capture(capture, path), 1, 0)
        self.stop(client)
        self.stop(egress)
        access = self.directory / "nginx-access.log"
        self.wait_for(lambda: access.exists() and "TLSv1.3 HTTP/1.1 101" in self.log_text(access), 3,
                      "Nginx TLS1.3 WebSocket101 access proof", [frontend])
        return {"status": "PASS", "binary_sha256": digest, "binary_version": version, "nginx_version": nginx_version,
                "transport": "wss", "mux": "on", "scope": "isolated local Linux namespaces; real Nginx TLS1.3/WSS and kernel ICMP Echo; not Cloudflare, WAN, ECH, system ping, TUN or service sandbox proof",
                "positive": {"ping": positive, "wire": positive_wire, "seconds": round(elapsed, 3)},
                "wrong_key": {"nonzero_exit": True, "received": 0, "sent": 0, "wire": wrong_wire,
                              "seconds": round(wrong_elapsed, 3)},
                "no_reply": {"nonzero_exit": True, "received": 0, "sent": 1, "wire": no_reply_wire,
                             "seconds": round(no_reply_elapsed, 3)}, "nginx_tls13_websocket101": True,
                "host_routes_firewall_sysctl_services_changed": False}


def test_packet(reply=False, sequence=1):
    packet = bytearray(20 + 8 + 16 + PAYLOAD_BYTES)
    packet[0], packet[8], packet[9] = 0x45, 64, 1
    struct.pack_into("!H", packet, 2, len(packet))
    source, target = (TARGET, SOURCE) if reply else (SOURCE, TARGET)
    packet[12:16], packet[16:20] = socket.inet_aton(source), socket.inet_aton(target)
    packet[20] = 0 if reply else 8
    struct.pack_into("!HH", packet, 24, 456, sequence)
    packet[28:] = bytes(range(16 + PAYLOAD_BYTES))
    struct.pack_into("!H", packet, 22, native.checksum(packet[20:]))
    struct.pack_into("!H", packet, 10, native.checksum(packet[:20]))
    return bytes(packet)


class OfflineTests(unittest.TestCase):
    def test_exact_echo_capture_and_negative_counts(self):
        proof = echo_wire_proof([test_packet(), test_packet(True)], 1, 1)
        self.assertEqual(proof["captured_matching_replies"], 1)
        self.assertEqual(echo_wire_proof([], 0, 0)["captured_requests"], 0)
        self.assertEqual(echo_wire_proof([test_packet()], 1, 0)["captured_matching_replies"], 0)
        for packets, request, reply in (([test_packet()], 1, 1), ([test_packet(), test_packet()], 1, 0),
                                         ([test_packet(), test_packet(True, 2)], 1, 1)):
            with self.assertRaises(LabError):
                echo_wire_proof(packets, request, reply)

    def test_capture_corruption_and_size(self):
        good = test_packet()
        for index in (0, 2, 6, 9, 12, 16, 20, 21, 22, 24, 26, 28, len(good) - 1):
            bad = bytearray(good)
            bad[index] ^= 1
            with self.subTest(index=index), self.assertRaises(LabError):
                echo_wire_proof([bytes(bad)], 1, 0)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "capture"
            path.write_bytes(struct.pack("!I", len(good)) + good)
            self.assertEqual(read_echo_capture(path), [good])
            for bad in (b"x", struct.pack("!I", 9999), struct.pack("!I", len(good)) + good[:-1]):
                path.write_bytes(bad)
                with self.assertRaises(LabError):
                    read_echo_capture(path)

    def test_result_requires_real_replies_and_nonzero_negative_exit(self):
        result = {"target": TARGET, "sent": 1, "received": 1,
                  "replies": [{"sequence": 1, "bytes": PAYLOAD_BYTES, "round_trip_ms": 2, "icmp_rtt_ms": 1}]}
        validate_ping_output(0, json.dumps(result), 1)
        with self.assertRaises(LabError):
            validate_ping_output(0, json.dumps(result), 0)
        with self.assertRaises(LabError):
            validate_ping_output(1, json.dumps(dict(result, received=0)), 0)
        with self.assertRaises(LabError):
            validate_ping_output(0, json.dumps(dict(result, received=True)), 1)

    def test_budget_and_cleanup_inherits_identity_checks(self):
        lab = Lab()
        self.assertAlmostEqual(lab.work_end - lab.started, 90)
        self.assertAlmostEqual(lab.end - lab.started, 120)
        self.assertEqual(lab.units, {})
        child = mock.Mock(pid=123)
        lab.children = [(child, Path("/owned/log"))]
        lab.stop = mock.Mock(side_effect=OSError("synthetic cleanup failure"))
        with mock.patch.object(common.Lab, "cleanup", return_value=[]) as cleanup:
            errors = lab.cleanup()
        cleanup.assert_called_once()
        self.assertTrue(errors)

    def test_zero_packet_proof_requires_complete_drop_free_capture(self):
        lab = Lab()
        child = mock.Mock()
        child.poll.return_value = None
        lab.children = [(child, Path("/owned/log"))]
        lab.stop = mock.Mock()
        with tempfile.TemporaryDirectory() as directory:
            capture = Path(directory) / "capture"
            capture.write_bytes(b"")
            for result in ({"complete": False, "drops": 0, "records": 0},
                           {"complete": True, "drops": 1, "records": 0},
                           {"complete": True, "drops": 0, "records": 1}):
                lab.log_text = mock.Mock(return_value="CAPTURE_RESULT=" + json.dumps(result))
                with self.assertRaises(LabError):
                    lab.finish_echo_capture(child, capture)
            lab.log_text = mock.Mock(return_value="CAPTURE_RESULT=" + json.dumps({"complete": True, "drops": 0, "records": 0}))
            self.assertEqual(lab.finish_echo_capture(child, capture), [])
            child.poll.return_value = 1
            with self.assertRaises(LabError):
                lab.finish_echo_capture(child, capture)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--run-local-lab", action="store_true", help="explicit opt-in to disposable Linux VM namespaces")
    parser.add_argument("--binary", help="absolute trusted matching Linux UNUNKNOWNTUN binary")
    parser.add_argument("--nginx", help="absolute existing trusted Nginx binary")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args(argv)
    if args.self_test:
        require(not args.run_local_lab and not args.binary and not args.nginx, "Offline self-test cannot activate a lab")
        result = unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromTestCase(OfflineTests))
        return 0 if result.wasSuccessful() else 1
    if not args.run_local_lab or not args.binary or not args.nginx:
        parser.error("--run-local-lab, --binary and --nginx are all required")
    lab = Lab()
    signal.signal(signal.SIGALRM, lab.hard_deadline)
    signal.setitimer(signal.ITIMER_REAL, max(0.1, lab.end - time.monotonic()))
    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, lambda *_: setattr(lab, "interrupted", True))
    report, error = None, None
    try:
        report = lab.execute(args.binary, args.nginx)
    except Exception as failure:
        error = common.diagnostic_text(str(failure), lab.private_values)
        lab.diagnostics()
    finally:
        cleanup = lab.cleanup()
        signal.setitimer(signal.ITIMER_REAL, 0)
    if error or cleanup:
        print(json.dumps({"status": "FAIL", "error": error, "cleanup_errors":
                         [common.diagnostic_text(item, lab.private_values) for item in cleanup]}, sort_keys=True))
        return 1
    report["cleanup"] = "owned children reaped; namespaces/veth/private files removed"
    report["elapsed_seconds"] = round(time.monotonic() - lab.started, 3)
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
