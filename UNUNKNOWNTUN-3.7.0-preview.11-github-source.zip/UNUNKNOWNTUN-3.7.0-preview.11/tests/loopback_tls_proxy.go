//go:build ignore

// A test-only TLS reverse proxy. Build this explicit file with go build.
// It is not a production/CDN/Nginx replacement and accepts only IPv4 loopback
// listen/backend addresses. It never contacts external hosts or system services.
package main

import (
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"errors"
	"flag"
	"fmt"
	"log"
	"math/big"
	"net"
	"net/http"
	"net/http/httputil"
	"net/url"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
)

type frontendProtocolKey struct{}

func requireLoopback(address string) {
	host, port, err := net.SplitHostPort(address)
	n, numberErr := strconv.Atoi(port)
	if err != nil || numberErr != nil || host != "127.0.0.1" || n < 1 || n > 65535 {
		log.Fatal("fixture permits only explicit 127.0.0.1:PORT addresses")
	}
}

func createCertificate(host, certPath, keyPath string) error {
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return err
	}
	serial, err := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 128))
	if err != nil {
		return err
	}
	template := x509.Certificate{SerialNumber: serial, Subject: pkix.Name{CommonName: host}, DNSNames: []string{host},
		NotBefore: time.Now().Add(-time.Hour), NotAfter: time.Now().Add(24 * time.Hour),
		IsCA: true, BasicConstraintsValid: true,
		KeyUsage:    x509.KeyUsageDigitalSignature | x509.KeyUsageCertSign,
		ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}}
	der, err := x509.CreateCertificate(rand.Reader, &template, &template, &key.PublicKey, key)
	if err != nil {
		return err
	}
	keyDER, err := x509.MarshalPKCS8PrivateKey(key)
	if err != nil {
		return err
	}
	for _, file := range []struct {
		path  string
		block *pem.Block
	}{
		{certPath, &pem.Block{Type: "CERTIFICATE", Bytes: der}},
		{keyPath, &pem.Block{Type: "PRIVATE KEY", Bytes: keyDER}},
	} {
		f, err := os.OpenFile(file.path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
		if err != nil {
			return err
		}
		err = pem.Encode(f, file.block)
		closeErr := f.Close()
		if err != nil {
			return err
		}
		if closeErr != nil {
			return closeErr
		}
	}
	return nil
}

func main() {
	listen := flag.String("listen", "", "explicit loopback endpoint")
	backend := flag.String("backend", "", "explicit loopback backend")
	cert := flag.String("cert", "", "test certificate path")
	key := flag.String("key", "", "test private key path")
	host := flag.String("host", "tunnel.example.com", "certificate DNS name; never resolved")
	makeCert := flag.Bool("make-cert", false, "create exclusive test certificate/key files and exit")
	wsPath := flag.String("ws-path", "", "exact WSS endpoint")
	xhttpPath := flag.String("xhttp-path", "", "XHTTP base endpoint")
	flag.Parse()
	if *makeCert {
		if err := createCertificate(*host, *cert, *key); err != nil {
			log.Fatal(err)
		}
		return
	}
	requireLoopback(*listen)
	requireLoopback(*backend)
	if !strings.HasPrefix(*wsPath, "/") || !strings.HasPrefix(*xhttpPath, "/") {
		log.Fatal("explicit test paths required")
	}
	upstream := &url.URL{Scheme: "http", Host: *backend}
	proxy := httputil.NewSingleHostReverseProxy(upstream)
	proxy.FlushInterval = -1
	proxy.Transport = &http.Transport{Proxy: nil, DialContext: (&net.Dialer{Timeout: 3 * time.Second}).DialContext,
		DisableCompression: true, MaxIdleConns: 128, MaxIdleConnsPerHost: 64, IdleConnTimeout: 10 * time.Second,
		ResponseHeaderTimeout: 15 * time.Second}
	var observed sync.Map
	proxy.ModifyResponse = func(response *http.Response) error {
		request := response.Request
		front, _ := request.Context().Value(frontendProtocolKey{}).(string)
		mode := request.Header.Get("X-Ununknowntun-Xhttp-Mode")
		if mode == "" {
			mode = "packet-up"
		}
		if response.StatusCode == http.StatusSwitchingProtocols {
			mode = "wss"
		}
		// Only fixed protocol metadata and booleans are recorded. No paths,
		// token/auth headers, payload bytes, certificates or request values.
		metadata := fmt.Sprintf("front=%s backend=%s mode=%s request-padding=%t response-padding=%t",
			front, response.Proto, mode, request.Header.Get("Referer") != "", response.Header.Get("X-Padding") != "")
		if _, seen := observed.LoadOrStore(metadata, true); !seen {
			log.Printf("[fixture] observed %s", metadata)
		}
		return nil
	}
	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == *wsPath || strings.HasPrefix(r.URL.Path, strings.TrimSuffix(*xhttpPath, "/")+"/") {
			proxy.ServeHTTP(w, r.WithContext(context.WithValue(r.Context(), frontendProtocolKey{}, r.Proto)))
			return
		}
		w.Header().Set("Content-Type", "text/html")
		_, _ = fmt.Fprintln(w, "<!doctype html><title>Local test</title>local-test-only")
	})
	server := &http.Server{Addr: *listen, Handler: handler, ReadHeaderTimeout: 5 * time.Second,
		IdleTimeout: 15 * time.Second, MaxHeaderBytes: 16384,
		TLSConfig: &tls.Config{MinVersion: tls.VersionTLS13}}
	listener, err := net.Listen("tcp", *listen)
	if err != nil {
		log.Fatal(err)
	}
	stop, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()
	go func() {
		<-stop.Done()
		ctx, done := context.WithTimeout(context.Background(), 2*time.Second)
		defer done()
		_ = server.Shutdown(ctx)
		_ = server.Close()
	}()
	log.Printf("[fixture] TLS proxy listening on %s", listener.Addr())
	if err := server.ServeTLS(listener, *cert, *key); err != nil && !errors.Is(err, http.ErrServerClosed) {
		log.Fatal(err)
	}
}
