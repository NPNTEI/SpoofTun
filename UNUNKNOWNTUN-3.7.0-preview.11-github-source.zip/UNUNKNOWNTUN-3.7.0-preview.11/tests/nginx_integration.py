#!/usr/bin/env python3
"""LOCAL TEST HOST ONLY: isolated real-Nginx UNUNKNOWNTUN correctness tests.

All listeners bind 127.0.0.1 and use randomly assigned unprivileged ports.
No systemd, installer, global Nginx configuration, or remote host is touched.
Requires an existing nginx binary with HTTP SSL and HTTP/2 modules,
openssl, and the freshly built UNUNKNOWNTUN executable. This script does not
install dependencies or change kernel/network/firewall settings.

Example, on a development/test host only:
  python3 tests/nginx_integration.py --binary ./dist/bin/ununknowntun-linux-amd64

The JSON report is a local correctness/recovery result, not a WAN benchmark
or proof of compatibility with every Nginx release or production network.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import contextlib
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import shlex
import shutil
import socket
import socketserver
import ssl
import subprocess
import sys
import tempfile
import threading
import time


HOST = "tunnel.example.com"
WS_PATH = "/assets/7daec8d62774d54f9822238e235168a4"
XHTTP_PATH = "/assets/125f759d090501202f6a0a4c45ca502d"
TEST_TOKEN = "local-test-only-0123456789abcdef0123456789abcdef"


def free_port() -> int:
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def wait_until(predicate, description: str, timeout: float = 15) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return
        time.sleep(0.1)
    raise AssertionError(f"timeout waiting for {description}")


class ManagedProcess:
    def __init__(self, argv: list[str], log: Path):
        self.log = log
        self.output = log.open("wb")
        try:
            self.process = subprocess.Popen(
                argv, stdin=subprocess.DEVNULL, stdout=self.output,
                stderr=subprocess.STDOUT, close_fds=True,
            )
        except BaseException:
            self.output.close()
            raise

    def text(self) -> str:
        return self.log.read_text(errors="replace")

    def alive(self) -> bool:
        return self.process.poll() is None

    def require_alive(self) -> None:
        if not self.alive():
            raise AssertionError(f"process exited ({self.process.returncode}):\n{self.text()[-6000:]}")

    def wait_log(self, phrase: str, timeout: float = 15, offset: int = 0) -> None:
        def found():
            self.require_alive()
            return phrase in self.text()[offset:]
        wait_until(found, phrase, timeout)

    def stop(self, abrupt: bool = False) -> None:
        if self.alive():
            if abrupt:
                self.process.kill()
            else:
                self.process.terminate()
            try:
                self.process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=5)
        self.output.close()


class EchoServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(self):
        self.lock = threading.Lock()
        self.active: set[socket.socket] = set()
        super().__init__(("127.0.0.1", 0), EchoHandler)

    def close_clients(self) -> None:
        with self.lock:
            clients = list(self.active)
        for conn in clients:
            with contextlib.suppress(OSError):
                conn.shutdown(socket.SHUT_RDWR)
            conn.close()


class EchoHandler(socketserver.BaseRequestHandler):
    def handle(self):
        conn = self.request
        with self.server.lock:
            self.server.active.add(conn)
        try:
            conn.settimeout(35)
            while True:
                data = conn.recv(65536)
                if not data:
                    conn.shutdown(socket.SHUT_WR)
                    break
                conn.sendall(data)
        except (ConnectionError, OSError):
            pass
        finally:
            with self.server.lock:
                self.server.active.discard(conn)


def roundtrip(port: int, size: int, slow: bool = False, started=None) -> dict:
    payload = os.urandom(size)
    expected = hashlib.sha256(payload).hexdigest()
    received = hashlib.sha256()
    count = 0
    started_at = time.monotonic()
    deadline = started_at + 30
    write_errors = []
    with socket.socket() as conn:
        conn.settimeout(30)
        if slow:
            conn.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 65536)
        conn.connect(("127.0.0.1", port))

        def send():
            try:
                conn.sendall(payload)
                conn.shutdown(socket.SHUT_WR)
            except BaseException as exc:
                write_errors.append(exc)

        writer = threading.Thread(target=send, daemon=True)
        writer.start()
        if started is not None:
            started.set()
        if slow:
            time.sleep(1.5)
        # Read until EOF, not just the expected byte count: this tests FIN
        # propagation and detects duplicate bytes after the expected payload.
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise AssertionError("roundtrip exceeded its 30-second total deadline")
            conn.settimeout(remaining)
            block = conn.recv(16384 if slow else 65536)
            if not block:
                break
            count += len(block)
            if count > size:
                raise AssertionError("echo contained unexpected extra bytes")
            received.update(block)
            if slow:
                time.sleep(0.001)
        writer.join(timeout=3)
        if writer.is_alive():
            raise AssertionError("sender did not finish after receiving EOF")
    if write_errors:
        raise write_errors[0]
    if count != size or received.hexdigest() != expected:
        raise AssertionError(f"echo integrity failure: expected {size}, received {count}")
    return {"bytes_each_direction": size, "sha256_verified": True,
            "fin_eof_verified": True, "seconds": round(time.monotonic() - started_at, 3)}


def wait_clean(process: ManagedProcess, offset: int) -> None:
    def clean():
        process.require_alive()
        matches = re.findall(r"\[stats\].*", process.text()[offset:])
        return bool(matches and re.search(r"\bstreams=0\b", matches[-1])
                    and "queued=0 B" in matches[-1])
    wait_until(clean, "streams=0 and queued=0 B after FIN cleanup", 15)


def nginx_config(root: Path, front: int, backend: int, streaming_uploads: bool = False) -> str:
    # Paths come only from the private mkdtemp directory, not user input.
    # Retain the test harness's existing UID, never switch identity. This
    # private single-process test instance must also work in UID-mapped
    # containers where the nginx default nobody account is not mapped.
    current_user = pwd.getpwuid(os.geteuid()).pw_name
    # A continuous upload is not a finite packet-up POST; applying the old
    # 128 KiB total body limit would cut a healthy streaming carrier. This
    # setting belongs only to the private fixture's XHTTP location. Packet-up
    # remains independently bounded to 64 KiB per POST inside the actual core.
    body_limit = "0" if streaming_uploads else "128k"
    return f"""user {current_user};
daemon off;
master_process off;
worker_processes 1;
pid {root}/nginx.pid;
error_log {root}/nginx-error.log warn;
events {{ worker_connections 1024; }}
http {{
  log_format test '$ssl_protocol $server_protocol $status';
  access_log {root}/nginx-access.log test;
  client_body_temp_path {root}/client-body;
  proxy_temp_path {root}/proxy-temp;
  fastcgi_temp_path {root}/fastcgi-temp;
  uwsgi_temp_path {root}/uwsgi-temp;
  scgi_temp_path {root}/scgi-temp;
  server {{
    listen 127.0.0.1:{front} ssl http2;
    server_name {HOST};
    ssl_certificate {root}/certificate.pem;
    ssl_certificate_key {root}/key.pem;
    ssl_protocols TLSv1.3;
    location = {WS_PATH} {{
      proxy_pass http://127.0.0.1:{backend};
      proxy_http_version 1.1;
      proxy_set_header Host $host;
      proxy_set_header Authorization $http_authorization;
      proxy_set_header Upgrade $http_upgrade;
      proxy_set_header Connection "upgrade";
      proxy_set_header X-Real-IP $remote_addr;
      proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
      proxy_buffering off;
      proxy_request_buffering off;
      proxy_socket_keepalive on;
      proxy_read_timeout 120s;
      proxy_send_timeout 120s;
    }}
    location ^~ {XHTTP_PATH}/ {{
      client_max_body_size {body_limit};
      proxy_pass http://127.0.0.1:{backend};
      proxy_http_version 1.1;
      proxy_set_header Host $host;
      proxy_set_header Authorization $http_authorization;
      proxy_set_header X-Real-IP $remote_addr;
      proxy_set_header Connection "";
      proxy_set_header Accept-Encoding "";
      proxy_buffering off;
      proxy_request_buffering off;
      proxy_cache off;
      gzip off;
      proxy_read_timeout 120s;
      proxy_send_timeout 120s;
      add_header Cache-Control "no-store" always;
    }}
    location / {{ root {root}/www; }}
  }}
}}
"""


def doctor_check(binary: str, root: Path, argv: list[str], label: str) -> dict:
    """Execute the shipped doctor against the real binary, never mock results."""
    directory = root / ("doctor-" + label)
    directory.mkdir()
    flags = dict(zip(argv[1::2], argv[2::2]))
    (directory / "deployment.env").write_text(
        f"ROLE=origin\nFOREIGN_DOMAIN={HOST}\nFOREIGN_PORTS={flags['-connect'].rsplit(':', 1)[1]}\nFOREIGN_PROXY_PROVIDER=none\n")
    # The doctor parses, but never sources or executes, this managed layout.
    launcher = "#!/bin/sh\nexec " + shlex.quote(binary) + " \\\n" + " \\\n".join(
        "  " + key + " " + shlex.quote(value) for key, value in flags.items()) + "\n"
    (directory / "run.sh").write_text(launcher)
    before = {p.name: p.read_bytes() for p in directory.iterdir()}
    helper = Path(__file__).resolve().parents[1] / "packaging" / "tunnel-doctor.py"
    command = [sys.executable, str(helper), "--config-dir", str(directory), "--binary", binary, "--timeout", "4"]
    checked = subprocess.run(command, capture_output=True, text=True, timeout=15)
    if checked.returncode:
        raise AssertionError("doctor rejected the live carrier: " + checked.stdout + checked.stderr)
    report = json.loads(checked.stdout)
    if report.get("verdict") != "carrier-authenticated" or report.get("authenticated_candidates") != 1:
        raise AssertionError("doctor did not verify exactly one actual local carrier")
    if report.get("target_payload_tested") is not False:
        raise AssertionError("doctor falsely claimed target-payload validation")
    if before != {p.name: p.read_bytes() for p in directory.iterdir()}:
        raise AssertionError("doctor modified the supplied configuration")
    if any(secret in checked.stdout for secret in (TEST_TOKEN, WS_PATH, XHTTP_PATH, str(directory))):
        raise AssertionError("doctor exposed a protected token/path")
    # A wrong private route must fail even though ordinary TLS/website works.
    changed = dict(flags)
    changed["-xhttp-path" if flags["-transport"] == "xhttp" else "-ws-path"] = "/not-the-private-tunnel-route"
    (directory / "run.sh").write_text("#!/bin/sh\nexec " + shlex.quote(binary) + " \\\n" + " \\\n".join("  " + k + " " + shlex.quote(v) for k, v in changed.items()) + "\n")
    failed = subprocess.run(command, capture_output=True, text=True, timeout=15)
    negative = json.loads(failed.stdout)
    if failed.returncode == 0 or negative.get("verdict") != "failed" or negative.get("authenticated_candidates") != 0:
        raise AssertionError("doctor mistook website/TLS success for a working private carrier")
    if not any(c.get("stage") == "actual-carrier" and c.get("status") == "fail" for e in negative.get("endpoints", []) for c in e["checks"]):
        raise AssertionError("doctor negative test lacks an actual-carrier failure")
    return {"actual_subprocess": True, "authenticated": True, "wrong_route_rejected": True,
            "configuration_unchanged": True, "secrets_redacted": True, "does_not_claim_target_payload": True}


def test_profiles(profile_set: str) -> list[dict]:
    """Keep the legacy matrix intact; add independently labelled 3.6 cases."""
    if profile_set not in {"all", "legacy", "new"}:
        raise ValueError("profile-set must be all, legacy, or new")
    profiles = []
    if profile_set in {"all", "legacy"}:
        legacy = [(mode, mux, fragment) for mode in ("wss", "xhttp")
                  for mux in ("on", "off") for fragment in ("off", "hello")]
        legacy += [("auto", "on", "off"), ("h2", "on", "off")]
        profiles += [{"transport": mode, "mux": mux, "fragment": fragment,
                      "xhttp_mode": "packet-up", "padding_bytes": "0", "xhttp_padding_bytes": "0",
                      "label": f"{mode}-mux-{mux}-fragment-{fragment}"}
                     for mode, mux, fragment in legacy]
    if profile_set in {"all", "new"}:
        for mux in ("on", "off"):
            profiles.append({"transport": "wss", "mux": mux, "fragment": "off",
                             "xhttp_mode": "packet-up", "padding_bytes": "32-128", "xhttp_padding_bytes": "0",
                             "label": f"wss-padded-mux-{mux}"})
            for mode in ("auto", "packet-up", "stream-up", "stream-one"):
                profiles.append({"transport": "xhttp", "mux": mux, "fragment": "off",
                                 "xhttp_mode": mode, "padding_bytes": "32-128", "xhttp_padding_bytes": "100-200",
                                 "label": f"xhttp-{mode}-padded-mux-{mux}"})
    return profiles


def run(binary: str, nginx: str, root: Path, workers: int, payload: int, frontend_kind: str = "nginx", profile_set: str = "all") -> dict:
    if not getattr(ssl, "HAS_TLSv1_3", False):
        raise RuntimeError("This Python SSL runtime cannot negotiate TLS1.3 (" + ssl.OPENSSL_VERSION + "); use a Python built with TLS1.3-capable OpenSSL. No tunnel profile was tested.")
    original_binary = binary
    binary_snapshot = root / "ununknowntun-under-test"
    shutil.copyfile(binary, binary_snapshot)
    binary_snapshot.chmod(0o700)
    binary = str(binary_snapshot)
    result = {"scope": "loopback-only, " + ("real Nginx" if frontend_kind == "nginx" else "Go standard-library TLS proxy; NOT Nginx") + ", TLS1.3; not a WAN benchmark",
              "binary": original_binary,
              "binary_sha256": hashlib.sha256(Path(binary).read_bytes()).hexdigest(),
              "binary_version": subprocess.check_output([binary, "-version"], text=True).strip(),
              "frontend_kind": frontend_kind, "profile_set": profile_set,
              "modes": []}
    if frontend_kind == "nginx":
        result["nginx_version"] = subprocess.check_output([nginx, "-v"], stderr=subprocess.STDOUT, text=True).strip()
        subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
                    "-days", "1", "-subj", f"/CN={HOST}", "-addext", f"subjectAltName=DNS:{HOST}",
                    "-keyout", str(root / "key.pem"), "-out", str(root / "certificate.pem")],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True, timeout=15)
    else:
        subprocess.run([nginx, "-make-cert", "-host", HOST, "-cert", str(root / "certificate.pem"), "-key", str(root / "key.pem")], check=True, timeout=10)
    cert_der = ssl.PEM_cert_to_DER_cert((root / "certificate.pem").read_text())
    fingerprint = hashlib.sha256(cert_der).hexdigest()
    token_file = root / "test-token"
    token_file.write_text(TEST_TOKEN)
    token_file.chmod(0o600)
    ports = set()
    while len(ports) < 2:
        ports.add(free_port())
    front, backend = tuple(ports)
    processes = []
    config = root / "nginx.conf"
    echo = EchoServer()
    echo_thread = threading.Thread(target=echo.serve_forever, kwargs={"poll_interval": 0.1}, daemon=True)
    echo_thread.start()
    target = f"127.0.0.1:{echo.server_address[1]}"
    common = ["-ws-host", HOST, "-ws-path", WS_PATH, "-xhttp-path", XHTTP_PATH,
              "-token-file", str(token_file), "-stats", "1s",
              "-max-streams", "64", "-max-memory", str(128 * 1024 * 1024),
              "-edge-write-timeout", "0"]
    egress_argv = []
    generation = 0

    def start_egress():
        nonlocal generation
        generation += 1
        process = ManagedProcess(egress_argv, root / f"egress-{generation}.log")
        processes.append(process)
        process.wait_log("HTTP backend listening on" if "xhttp" in egress_argv else "[egress] listening on")
        return process

    try:
        profiles = test_profiles(profile_set)
        streaming_uploads = any(p["transport"] == "xhttp" and p["xhttp_mode"] in {"stream-up", "stream-one"} for p in profiles)
        config.write_text(nginx_config(root, front, backend, streaming_uploads=streaming_uploads))
        (root / "www").mkdir()
        (root / "logs").mkdir()
        (root / "www" / "index.html").write_text("local-test-only\n")
        if frontend_kind == "nginx":
            config_check = subprocess.run([nginx, "-p", str(root) + "/", "-c", str(config), "-t"],
                                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=10)
            if config_check.returncode:
                raise AssertionError(f"Nginx test configuration rejected:\n{config_check.stdout}")
            frontend_argv = [nginx, "-p", str(root) + "/", "-c", str(config)]
        else:
            frontend_argv = [nginx, "-listen", f"127.0.0.1:{front}", "-backend", f"127.0.0.1:{backend}",
                             "-cert", str(root / "certificate.pem"), "-key", str(root / "key.pem"),
                             "-ws-path", WS_PATH, "-xhttp-path", XHTTP_PATH]
        frontend = ManagedProcess(frontend_argv, root / "frontend.log")
        processes.append(frontend)
        context = ssl.create_default_context(cafile=str(root / "certificate.pem"))
        context.minimum_version = ssl.TLSVersion.TLSv1_3
        context.set_alpn_protocols(["h2", "http/1.1"])

        def frontend_ready():
            frontend.require_alive()
            try:
                with socket.create_connection(("127.0.0.1", front), timeout=1) as raw:
                    with context.wrap_socket(raw, server_hostname=HOST) as secure:
                        result["frontend_tls"] = secure.version()
                        result["frontend_alpn"] = secure.selected_alpn_protocol()
                        return secure.version() == "TLSv1.3" and secure.selected_alpn_protocol() == "h2"
            except OSError:
                return False
        wait_until(frontend_ready, "local frontend TLS1.3 and h2 ALPN")

        website_context = ssl.create_default_context(cafile=str(root / "certificate.pem"))
        website_context.set_alpn_protocols(["http/1.1"])
        with socket.create_connection(("127.0.0.1", front), timeout=3) as raw:
            with website_context.wrap_socket(raw, server_hostname=HOST) as secure:
                secure.sendall(f"GET / HTTP/1.1\r\nHost: {HOST}\r\nConnection: close\r\n\r\n".encode())
                response = b""
                while len(response) < 65536:
                    block = secure.recv(4096)
                    if not block:
                        break
                    response += block
        if b" 200 " not in response.split(b"\r\n", 1)[0] or b"local-test-only" not in response:
            raise AssertionError("ordinary website fallback failed")
        result["website_fallback_verified"] = True

        for profile in profiles:
            mode, mux, fragment = profile["transport"], profile["mux"], profile["fragment"]
            origin_port = free_port()
            expected = "wss" if mode in ("auto", "h2") else mode
            label = profile["label"]
            profile_flags = ["-xhttp-mode", profile["xhttp_mode"],
                             "-padding-bytes", profile["padding_bytes"],
                             "-xhttp-padding-bytes", profile["xhttp_padding_bytes"]]
            egress_argv = [binary, "-mode", "egress", "-transport", expected,
                           "-listen", f"127.0.0.1:{backend}", "-allow", target,
                           "-mux", mux] + common + profile_flags
            egress = start_egress()
            origin_common = list(common)
            origin_argv = [binary, "-mode", "origin", "-transport", mode, "-mux", mux,
                 "-tls-fragment", fragment,
                 "-listen", f"127.0.0.1:{origin_port}",
                 "-connect", f"127.0.0.1:{front}", "-target", target, "-sni", HOST,
                 "-fingerprint", fingerprint, "-sessions-min", "2", "-sessions", "4"] + origin_common + profile_flags
            origin = ManagedProcess(origin_argv, root / f"origin-{label}.log")
            processes.append(origin)
            try:
                origin.wait_log("[origin] listening on", 20)
                stage = {"mode": mode, "selected_transport": expected, "mux": mux, "fragment": fragment, "workers": workers,
                         "profile": label, "xhttp_mode": profile["xhttp_mode"] if expected == "xhttp" else None,
                         "xhttp_selected_mode": ("packet-up" if profile["xhttp_mode"] == "auto" else profile["xhttp_mode"]) if expected == "xhttp" else None,
                         "padding_bytes": profile["padding_bytes"], "xhttp_padding_bytes": profile["xhttp_padding_bytes"],
                         "frontend_protocol": "HTTP/2" if expected == "xhttp" else "HTTP/1.1 WebSocket",
                         "backend_protocol": "HTTP/1.1"}
                # Exercise the new isolated diagnostic contract against the
                # actual TLS + Nginx + carrier + authentication chain.
                probe = subprocess.run([binary, "-check-tunnel", "-mode", "origin",
                    "-probe-timeout", "8s", "-transport", expected, "-mux", mux,
                    "-connect", f"127.0.0.1:{front}", "-sni", HOST,
                    "-fingerprint", fingerprint, "-tls-fragment", fragment] + common + profile_flags,
                    capture_output=True, text=True, timeout=10)
                if probe.returncode:
                    raise AssertionError("actual-carrier probe failed: " + probe.stderr)
                stage["authenticated_probe_passed"] = True
                if frontend_kind == "go":
                    observed_mode = stage["xhttp_selected_mode"] if expected == "xhttp" else "wss"
                    observed_front = "HTTP/2.0" if expected == "xhttp" else "HTTP/1.1"
                    proof = f"front={observed_front} backend=HTTP/1.1 mode={observed_mode}"
                    frontend.wait_log(proof, timeout=5)
                    stage["proxy_protocol_conversion_observed"] = True
                    if expected == "xhttp" and profile["xhttp_padding_bytes"] != "0":
                        frontend.wait_log(proof + " request-padding=true response-padding=true", timeout=5)
                        stage["http_padding_headers_observed"] = True
                stage["doctor"] = doctor_check(binary, root, origin_argv, label)
                def exchange(index):
                    # MUX-off opens a new authenticated carrier per client;
                    # respect the shipped 10/s burst-5 handshake limiter.
                    if mux == "off":
                        time.sleep(index * .15)
                    return roundtrip(origin_port, payload)
                with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
                    futures = [pool.submit(exchange, i) for i in range(workers)]
                    exchanges = [future.result(timeout=40) for future in futures]
                stage["concurrent_bytes_each_direction"] = sum(x["bytes_each_direction"] for x in exchanges)
                stage["new_carrier_dial_stagger_ms"] = 150 if mux == "off" else 0
                stage["all_sha256_and_fin_verified"] = True
                origin.wait_log(f"via {expected}", 20)
                offset = len(origin.text())
                wait_clean(origin, offset)
                wait_clean(egress, len(egress.text()))

                slow_started = threading.Event()
                with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
                    slow = pool.submit(roundtrip, origin_port, 2 * 1024 * 1024, True, slow_started)
                    if not slow_started.wait(timeout=5):
                        raise AssertionError("slow stream did not start")
                    fast = pool.submit(roundtrip, origin_port, 65536)
                    stage["fast_stream_during_slow_consumer"] = fast.result(timeout=10)
                    stage["slow_consumer"] = slow.result(timeout=40)
                offset = len(origin.text())
                wait_clean(origin, offset)
                wait_clean(egress, len(egress.text()))

                # Crash only the egress process created by this harness, not
                # any existing service. Existing streams cannot survive a
                # lost carrier; verify a NEW stream after automatic recovery.
                offset = len(origin.text())
                egress.stop(abrupt=True)
                time.sleep(0.3)
                egress = start_egress()
                if mux == "on":
                    origin.wait_log("tunnel session established", 30, offset)
                stage["new_stream_after_egress_restart"] = roundtrip(origin_port, payload)
                offset = len(origin.text())
                wait_clean(origin, offset)
                wait_clean(egress, len(egress.text()))
                stage["stream_and_queue_cleanup_verified"] = True
                result["modes"].append(stage)
            finally:
                origin.stop()
                egress.stop()
            frontend.require_alive()
        result["status"] = "PASS"
        return result
    finally:
        for process in reversed(processes):
            process.stop()
        echo.shutdown()
        echo.close_clients()
        echo.server_close()
        echo_thread.join(timeout=3)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", required=True, type=Path)
    parser.add_argument("--nginx", default=shutil.which("nginx"))
    parser.add_argument("--workers", type=int, default=16)
    parser.add_argument("--payload-kib", type=int, default=512)
    parser.add_argument("--keep-logs", action="store_true")
    parser.add_argument("--profile-set", choices=("all", "legacy", "new"), default="all",
                        help="all:20 profiles; legacy:10 existing profiles; new:10 padded 3.6 profiles")
    args = parser.parse_args()
    if not args.nginx:
        parser.error("nginx is unavailable; provide --nginx /absolute/path/to/an/existing/nginx")
    if not 1 <= args.workers <= 32 or not 1 <= args.payload_kib <= 8192:
        parser.error("workers must be 1..32 and payload-kib must be 1..8192")
    binary = str(args.binary.resolve(strict=True))
    nginx = str(Path(args.nginx).resolve(strict=True))
    root = Path(tempfile.mkdtemp(prefix="ununknowntun-nginx-test-"))
    try:
        result = run(binary, nginx, root, args.workers, args.payload_kib * 1024, profile_set=args.profile_set)
    except BaseException as exc:
        result = {"status": "FAIL", "error": str(exc), "logs": str(root)}
        args.keep_logs = True
    if args.keep_logs:
        result["logs"] = str(root)
        (root / "report.json").write_text(json.dumps(result, indent=2) + "\n")
    else:
        shutil.rmtree(root)
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
