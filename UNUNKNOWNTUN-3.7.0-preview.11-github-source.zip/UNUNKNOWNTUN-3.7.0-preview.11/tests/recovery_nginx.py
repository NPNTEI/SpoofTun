#!/usr/bin/env python3
"""Bounded loopback executable test of signed recovery through real Nginx.

Requires existing --binary and --nginx executables. Runs WSS and packet-up
XHTTP concurrently, rejects every new fixed-route GET, and verifies automatic
signed-route recovery, target echo/FIN, and negative authorization checks.
Only private processes, temporary files, and 127.0.0.1 ports are used. No
system service, production configuration, VM, public DNS or firewall is used.
"""

from __future__ import annotations

import argparse
import base64
import concurrent.futures
import hashlib
import hmac
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import socket
import ssl
import subprocess
import tempfile
import threading
import time
import uuid

from nginx_integration import (EchoServer, HOST, TEST_TOKEN, WS_PATH, XHTTP_PATH,
                               ManagedProcess, free_port, nginx_config)


def load_editor():
    path = Path(__file__).resolve().parents[1] / "packaging" / "tunnel-editor.py"
    spec = importlib.util.spec_from_file_location("recovery_nginx_editor", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


EDITOR = load_editor()


def remaining(deadline: float, limit: float = 5) -> float:
    value = min(limit, deadline - time.monotonic())
    if value <= 0:
        raise TimeoutError("35-second total test budget exhausted")
    return value


def wait_for(predicate, description: str, deadline: float, limit: float = 8):
    end = min(deadline, time.monotonic() + limit)
    while time.monotonic() < end:
        value = predicate()
        if value:
            return value
        time.sleep(.05)
    raise AssertionError("timeout waiting for " + description)


def config_for(root: Path, front: int, backend: int, transport: str) -> str:
    text = nginx_config(root, front, backend)
    # Retain the established fixture's TLS/listener/temp-path isolation, but
    # remove its static routes: only the editor-generated rotation matcher can
    # forward this test's carrier traffic.
    for header in ("location = " + WS_PATH, "location ^~ " + XHTTP_PATH + "/"):
        text, count = re.subn(r"    " + re.escape(header) + r" \{.*?\n    \}\n", "", text, flags=re.S)
        if count != 1:
            raise AssertionError("fixture static-route layout changed")
    text = text.replace("log_format test '$ssl_protocol $server_protocol $status';",
                        "log_format test '$request_method $uri $status $upstream_status';")
    text = text.replace("  server {", '  map "$request_method:$uri" $deny_fixed {\n'
                        '    default 0;\n    "~^GET:/gdt-r/[0-9a-f]{32}(/|$)" 1;\n  }\n  server {', 1)
    pattern = EDITOR.nginx_rotation_pattern(transport)
    upgrade = 'proxy_set_header Upgrade $http_upgrade;' if transport == "wss" else 'proxy_set_header Accept-Encoding "";'
    connection = '"upgrade"' if transport == "wss" else '""'
    block = f'''    location ~ "{pattern}" {{
      if ($deny_fixed) {{ return 404; }}
      client_max_body_size 2m;
      proxy_pass http://127.0.0.1:{backend};
      proxy_http_version 1.1;
      proxy_set_header Host $host;
      proxy_set_header Authorization $http_authorization;
      {upgrade}
      proxy_set_header Connection {connection};
      proxy_set_header X-Real-IP $remote_addr;
      proxy_buffering off;
      proxy_request_buffering off;
      proxy_cache off;
      gzip off;
      proxy_read_timeout 10s;
      proxy_send_timeout 10s;
    }}
    location / {{ return 404; }}'''
    fallback = f"    location / {{ root {root}/www; }}"
    if text.count(fallback) != 1:
        raise AssertionError("fixture fallback layout changed")
    return text.replace(fallback, block)


def transport_authorization(path: str) -> str:
    timestamp = str(int(time.time()))
    nonce = base64.urlsafe_b64encode(os.urandom(18)).decode().rstrip("=")
    message = "\n".join((timestamp, nonce, HOST, path)).encode()
    tag = base64.urlsafe_b64encode(hmac.new(TEST_TOKEN.encode(), message, hashlib.sha256).digest()).decode().rstrip("=")
    return "Bearer " + ".".join((timestamp, nonce, tag))


def http_status(front: int, context: ssl.SSLContext, path: str, transport: str,
                authorization: str, deadline: float) -> int:
    headers = [f"GET {path} HTTP/1.1", f"Host: {HOST}", "Connection: close",
               "Authorization: " + authorization]
    if transport == "wss":
        headers[2] = "Connection: Upgrade"
        headers += ["Upgrade: websocket", "Sec-WebSocket-Version: 13",
                    "Sec-WebSocket-Key: " + base64.b64encode(os.urandom(16)).decode()]
    with socket.create_connection(("127.0.0.1", front), timeout=remaining(deadline, 2)) as raw:
        with context.wrap_socket(raw, server_hostname=HOST) as conn:
            conn.settimeout(remaining(deadline, 2))
            conn.sendall(("\r\n".join(headers) + "\r\n\r\n").encode())
            response = b""
            while b"\r\n\r\n" not in response and len(response) < 16384:
                data = conn.recv(4096)
                if not data:
                    break
                response += data
    match = re.match(rb"HTTP/1\.[01] ([0-9]{3}) ", response)
    if not match:
        raise AssertionError("negative probe returned no bounded HTTP status")
    return int(match[1])


def exchange(port: int, deadline: float) -> dict:
    payload = os.urandom(65536)
    received = bytearray()
    with socket.create_connection(("127.0.0.1", port), timeout=remaining(deadline, 3)) as conn:
        conn.settimeout(remaining(deadline, 6))
        conn.sendall(payload)
        conn.shutdown(socket.SHUT_WR)
        while True:
            conn.settimeout(remaining(deadline, 6))
            data = conn.recv(65536)
            if not data:
                break
            received.extend(data)
            if len(received) > len(payload):
                raise AssertionError("echo duplicated bytes")
    if received != payload:
        raise AssertionError("target echo truncated or changed payload")
    return {"bytes_each_direction": len(payload), "sha256_verified": True,
            "fin_eof_verified": True, "sha256": hashlib.sha256(payload).hexdigest()}


def access_rows(root: Path) -> list[tuple[str, str, str, str]]:
    path = root / "nginx-access.log"
    if not path.exists():
        return []
    return [tuple(line.split()) for line in path.read_text().splitlines() if len(line.split()) == 4]


def profile(binary: str, nginx: str, root: Path, shared: Path, transport: str, deadline: float) -> dict:
    root.mkdir()
    (root / "logs").mkdir()
    for name in ("certificate.pem", "key.pem"):
        shutil.copyfile(shared / name, root / name)
    fingerprint = hashlib.sha256(ssl.PEM_cert_to_DER_cert((root / "certificate.pem").read_text())).hexdigest()
    token = root / "token"
    token.write_text(TEST_TOKEN)
    token.chmod(0o600)
    ports = set()
    while len(ports) < 3:
        ports.add(free_port())
    front, backend, listen = tuple(ports)
    conf = root / "nginx.conf"
    conf.write_text(config_for(root, front, backend, transport))
    checked = subprocess.run([nginx, "-p", str(root) + "/", "-c", str(conf), "-t"],
                             capture_output=True, text=True, timeout=remaining(deadline))
    if checked.returncode:
        raise AssertionError("real Nginx rejected generated route: " + checked.stdout + checked.stderr)
    echo = EchoServer()
    thread = threading.Thread(target=echo.serve_forever, kwargs={"poll_interval": .05}, daemon=True)
    thread.start()
    target = f"127.0.0.1:{echo.server_address[1]}"
    common = ["-transport", transport, "-mux", "on", "-ws-host", HOST,
              "-ws-path", WS_PATH, "-xhttp-path", XHTTP_PATH, "-xhttp-mode", "packet-up",
              "-token-file", str(token), "-stats", "1s", "-path-rotation", "1h",
              "-path-count", "2", "-path-grace", "5m", "-max-streams", "64",
              "-max-memory", "134217728", "-write-timeout", "5s"]
    processes = []
    try:
        frontend = ManagedProcess([nginx, "-p", str(root) + "/", "-c", str(conf)], root / "frontend.log")
        processes.append(frontend)
        egress = ManagedProcess([binary, "-mode", "egress", "-listen", f"127.0.0.1:{backend}",
                                 "-allow", target] + common, root / "egress.log")
        processes.append(egress)
        def egress_ready():
            egress.require_alive()
            return "HTTP backend listening on" in egress.text() if transport == "xhttp" else "[egress] listening on" in egress.text()
        wait_for(egress_ready, transport + " egress", deadline)
        context = ssl.create_default_context(cafile=str(root / "certificate.pem"))
        context.set_alpn_protocols(["http/1.1"])
        def frontend_ready():
            frontend.require_alive()
            try:
                return http_status(front, context, "/ready", transport, "Bearer invalid", deadline) == 404
            except OSError:
                return False
        wait_for(frontend_ready, transport + " TLS frontend", deadline)
        origin = ManagedProcess([binary, "-mode", "origin", "-listen", f"127.0.0.1:{listen}",
                                 "-connect", f"127.0.0.1:{front}", "-target", target, "-sni", HOST,
                                 "-fingerprint", fingerprint, "-sessions-min", "1", "-sessions", "1"] + common,
                                root / "origin.log")
        processes.append(origin)
        def origin_ready():
            origin.require_alive()
            return "tunnel session established" in origin.text() and "[origin] listening on" in origin.text()
        wait_for(origin_ready, transport + " automatic signed recovery", deadline, 12)
        if "authenticated 1KiB carrier payload roundtrip confirmed" not in origin.text():
            raise AssertionError("carrier was published without full payload health proof")
        result = {"transport": transport, "xhttp_mode": "packet-up" if transport == "xhttp" else None,
                  "generated_nginx_pattern": EDITOR.nginx_rotation_pattern(transport),
                  "nginx_parser_passed": True, "initial_payload_proof": True,
                  "echo": exchange(listen, deadline)}
        # Nginx records a WebSocket GET only when the tunnel closes. Finish
        # this private origin after payload/FIN, leaving the egress/frontend
        # alive for independent backend-authentication rejection checks.
        origin.stop(abrupt=True)
        expected = "101" if transport == "wss" else "200"
        def successful_signed_rows():
            return [row for row in access_rows(root) if row[0] == "GET" and
                    re.match(r"^/gdt-r/[0-9a-f]{64}(?:/|$)", row[1]) and row[2:] == (expected, expected)]
        signed = wait_for(successful_signed_rows, transport + " signed-route upstream access evidence", deadline, 3)
        base = re.match(r"^/gdt-r/[0-9a-f]{64}", signed[0][1])[0]
        fixed = [row for row in access_rows(root) if row[0] == "GET" and
                 re.match(r"^/gdt-r/[0-9a-f]{32}(?:/|$)", row[1])]
        if len({row[1].split("/")[2] for row in fixed}) < 2 or any(row[2:] != ("404", "-") for row in fixed):
            raise AssertionError("fixed candidates did not all fail at the Nginx gate")
        result.update(fixed_gets_denied_at_nginx=len(fixed), signed64_successful_gets=len(signed),
                      signed64_upstream_status=expected, actual_signed_route_observed=True,
                      observed_route_sha256=hashlib.sha256(base.encode()).hexdigest())
        suffix = "/" + str(uuid.uuid4()) if transport == "xhttp" else ""
        wrong_base = base[:-1] + ("0" if base[-1] != "0" else "1")
        checks = (("wrong_route_mac", wrong_base + suffix, True, "404"),
                  ("wrong_transport_auth", base + suffix, False, "404"),
                  ("malformed_hex", base[:-1] + "g" + suffix, True, "-"),
                  ("wrong_route_length", base[:-1] + suffix, True, "-"))
        result["negative_checks"] = []
        for label, path, valid_auth, upstream in checks:
            authorization = transport_authorization(path) if valid_auth else "Bearer invalid"
            if http_status(front, context, path, transport, authorization, deadline) != 404:
                raise AssertionError(label + " was not rejected")
            rows = wait_for(lambda: [row for row in access_rows(root) if row[1] == path],
                            label + " access evidence", deadline, 2)
            if rows[-1][2:] != ("404", upstream):
                raise AssertionError(label + " rejected at unexpected layer: " + str(rows[-1][2:]))
            result["negative_checks"].append({"case": label, "rejected": True,
                                               "layer": "backend" if upstream != "-" else "nginx"})
        frontend.require_alive()
        egress.require_alive()
        return result
    finally:
        for process in reversed(processes):
            process.stop(abrupt=True)
        echo.shutdown()
        echo.close_clients()
        echo.server_close()
        thread.join(timeout=1)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", required=True, type=Path)
    parser.add_argument("--nginx", required=True, type=Path)
    parser.add_argument("--keep-logs", action="store_true")
    args = parser.parse_args()
    binary, nginx = str(args.binary.resolve(strict=True)), str(args.nginx.resolve(strict=True))
    root = Path(tempfile.mkdtemp(prefix="ununknowntun-recovery-nginx-"))
    started = time.monotonic()
    deadline = started + 35
    report = {"status": "FAIL", "scope": "loopback-only real Nginx; WSS and packet-up XHTTP signed-route recovery; not WAN/CDN or long-duration certification",
              "binary": binary, "binary_sha256": hashlib.sha256(Path(binary).read_bytes()).hexdigest(),
              "profiles_concurrent": True, "work_budget_seconds": 35}
    try:
        snapshot = root / "ununknowntun-under-test"
        shutil.copyfile(binary, snapshot)
        snapshot.chmod(0o700)
        report["binary_sha256"] = hashlib.sha256(snapshot.read_bytes()).hexdigest()
        report["binary_version"] = subprocess.check_output([str(snapshot), "-version"], text=True, timeout=remaining(deadline)).strip()
        report["nginx_version"] = subprocess.check_output([nginx, "-v"], stderr=subprocess.STDOUT, text=True, timeout=remaining(deadline)).strip()
        subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "1",
                        "-subj", f"/CN={HOST}", "-addext", f"subjectAltName=DNS:{HOST}",
                        "-keyout", str(root / "key.pem"), "-out", str(root / "certificate.pem")],
                       check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=remaining(deadline, 8))
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            futures = [pool.submit(profile, str(snapshot), nginx, root / mode, root, mode, deadline)
                       for mode in ("wss", "xhttp")]
            report["modes"] = [future.result() for future in futures]
        report["status"] = "PASS"
    except Exception as error:
        report["error"] = f"{type(error).__name__}: {error}"
        args.keep_logs = True
    report["elapsed_seconds"] = round(time.monotonic() - started, 3)
    if args.keep_logs:
        report["logs"] = str(root)
        (root / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    else:
        shutil.rmtree(root)
    print(json.dumps(report, indent=2))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
