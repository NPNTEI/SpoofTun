#!/usr/bin/env python3
"""Loopback-only real-process rotation/renewal soak (~190 seconds).

Runs WSS and XHTTP packet-up concurrently through a private real Nginx instance
per profile. Requires existing native binaries; does not install or modify any
service, production configuration, public DNS, or firewall. Private synthetic
route-denial files affect NEW GET carriers only, not established uploads.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import hmac
import json
from pathlib import Path
import re
import shutil
import socket
import ssl
import subprocess
import tempfile
import threading
import time

from nginx_integration import (EchoServer, HOST, TEST_TOKEN, WS_PATH, XHTTP_PATH,
                               ManagedProcess, free_port, nginx_config, roundtrip,
                               wait_clean)


def route(transport: str, epoch: int, index: int) -> str:
    seed = XHTTP_PATH if transport == "xhttp" else WS_PATH
    parts = ("ununknowntun-path-v1", transport, HOST, seed)
    message = "".join(f"{len(p)}:{p};" for p in parts) + f"60000000000:{epoch}:{index}"
    return "/gdt-r/" + hmac.new(TEST_TOKEN.encode(), message.encode(), hashlib.sha256).hexdigest()[:32]


class ContinuousEcho:
    def __init__(self, port: int):
        self.conn = socket.create_connection(("127.0.0.1", port), timeout=5)
        self.conn.settimeout(5)
        self.bytes = 0
        self.started_epoch = int(time.time() // 60)
        self.epochs = {self.started_epoch}

    def tick(self) -> None:
        payload = hashlib.sha256(str(self.bytes).encode()).digest() * 128
        self.conn.sendall(payload)
        got = b""
        while len(got) < len(payload):
            block = self.conn.recv(len(payload) - len(got))
            if not block:
                raise AssertionError("live stream ended during rotation")
            got += block
        if got != payload:
            raise AssertionError("live stream payload changed")
        self.bytes += len(payload)
        self.epochs.add(int(time.time() // 60))

    def close(self) -> dict:
        try:
            self.conn.shutdown(socket.SHUT_WR)
            if self.conn.recv(1) != b"":
                raise AssertionError("unexpected duplicate payload after FIN")
        finally:
            self.conn.close()
        return {"bytes_each_direction": self.bytes, "epochs": sorted(self.epochs),
                "payload_and_fin_verified": True}


def profile(binary: str, nginx: str, root: Path, transport: str, duration: int) -> dict:
    root.mkdir()
    cert, key = root / "certificate.pem", root / "key.pem"
    subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "1",
                    "-subj", f"/CN={HOST}", "-addext", f"subjectAltName=DNS:{HOST}",
                    "-keyout", str(key), "-out", str(cert)], check=True, timeout=15,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    fingerprint = hashlib.sha256(ssl.PEM_cert_to_DER_cert(cert.read_text())).hexdigest()
    token = root / "token"
    token.write_text(TEST_TOKEN)
    token.chmod(0o600)
    denied = root / "deny" / "gdt-r"
    denied.mkdir(parents=True)
    # Reject the primary route of every epoch before the core sees it. At
    # runtime, reject the next epoch's backup too, then restore it later.
    first_epoch = int(time.time() // 60)
    for epoch in range(first_epoch - 1, first_epoch + 8):
        (root / "deny" / route(transport, epoch, 0).lstrip("/")).touch()
    ports = set()
    while len(ports) < 3:
        ports.add(free_port())
    front, backend, listen = tuple(ports)
    config = nginx_config(root, front, backend)
    config = config.replace("log_format test '$ssl_protocol $server_protocol $status';",
                            "log_format test '$msec $request_time $request_method $uri $status';")
    marker = "  server {"
    config = config.replace(marker, '  map $uri $route_base { default ""; "~^(/gdt-r/[a-f0-9]{32})" $1; }\n' + marker, 1)
    block = f"""    location ^~ /gdt-r/ {{
      set $deny_new 0;
      if (-f {root}/deny$route_base) {{ set $deny_new 1; }}
      set $deny_method "$deny_new:$request_method";
      if ($deny_method = "1:GET") {{ return 404; }}
      proxy_pass http://127.0.0.1:{backend};
      proxy_http_version 1.1;
      proxy_set_header Host $host;
      proxy_set_header Authorization $http_authorization;
      proxy_set_header Upgrade $http_upgrade;
      proxy_set_header Connection {'"upgrade"' if transport == 'wss' else '""'};
      proxy_buffering off;
      proxy_request_buffering off;
      proxy_cache off;
      proxy_read_timeout 240s;
      proxy_send_timeout 240s;
    }}
"""
    config = config.replace("    location / {", block + "    location / {")
    conf = root / "nginx.conf"
    conf.write_text(config)
    (root / "www").mkdir()
    (root / "logs").mkdir()
    subprocess.run([nginx, "-p", str(root) + "/", "-c", str(conf), "-t"],
                   check=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=10)
    echo = EchoServer()
    thread = threading.Thread(target=echo.serve_forever, kwargs={"poll_interval": .1}, daemon=True)
    thread.start()
    target = f"127.0.0.1:{echo.server_address[1]}"
    common = ["-transport", transport, "-mux", "on", "-ws-host", HOST, "-ws-path", WS_PATH,
              "-xhttp-path", XHTTP_PATH, "-xhttp-mode", "packet-up", "-token-file", str(token),
              "-stats", "1s", "-path-rotation", "1m", "-path-count", "3", "-path-grace", "10s",
              "-session-renewal", "1m", "-max-streams", "64", "-max-memory", "134217728"]
    processes, live = [], None
    result = {"transport": transport, "duration_seconds": duration, "continuous_streams": []}
    try:
        frontend = ManagedProcess([nginx, "-p", str(root) + "/", "-c", str(conf)], root / "frontend.log")
        processes.append(frontend)
        egress = ManagedProcess([binary, "-mode", "egress", "-listen", f"127.0.0.1:{backend}", "-allow", target] + common,
                                root / "egress.log")
        processes.append(egress)
        egress.wait_log("HTTP backend listening on" if transport == "xhttp" else "[egress] listening on")
        origin = ManagedProcess([binary, "-mode", "origin", "-listen", f"127.0.0.1:{listen}",
                                 "-connect", f"127.0.0.1:{front}", "-target", target, "-sni", HOST,
                                 "-fingerprint", fingerprint, "-sessions-min", "1", "-sessions", "1"] + common,
                                root / "origin.log")
        processes.append(origin)
        origin.wait_log("[origin] listening on", 20)
        start = time.monotonic()
        wall_start = time.time()
        live = ContinuousEcho(listen)
        injected, healed, recovered_backup_forced = False, False, False
        failures = []
        short_streams, epochs = 0, set()
        # Three long-lived streams straddle successive renewal opportunities.
        closed_stages = set()
        while time.monotonic() - start < duration:
            elapsed = time.monotonic() - start
            for process in processes:
                process.require_alive()
            epochs.add(int(time.time() // 60))
            live.tick()
            roundtrip(listen, 8192)
            short_streams += 1
            if not injected and elapsed > 25:
                for epoch in range(int(time.time() // 60), first_epoch + 8):
                    path = root / "deny" / route(transport, epoch, 1).lstrip("/")
                    path.touch()
                    failures.append(path)
                injected = True
            if not healed and elapsed > 95:
                for path in failures:
                    path.unlink()
                healed = True
            if not recovered_backup_forced and elapsed > 150:
                for epoch in range(int(time.time() // 60), first_epoch + 8):
                    (root / "deny" / route(transport, epoch, 2).lstrip("/")).touch()
                recovered_backup_forced = True
            for stage in (80, 155):
                if elapsed >= stage and stage not in closed_stages:
                    result["continuous_streams"].append(live.close())
                    live = ContinuousEcho(listen)
                    closed_stages.add(stage)
            time.sleep(1)
        result["continuous_streams"].append(live.close())
        live = None
        wait_clean(origin, len(origin.text()))
        wait_clean(egress, len(egress.text()))
        text = origin.text()
        renewals = text.count("new streams now use renewed carrier")
        if renewals < 3:
            raise AssertionError(f"expected at least 3 real-minute renewals, observed {renewals}")
        counts = [int(v) for v in re.findall(r"\[stats\] sessions=(\d+)", text)]
        if not counts or max(counts) > 2:
            raise AssertionError(f"one-slot plus one-spare bound violated: {counts}")
        if len(epochs) < 3:
            raise AssertionError("not enough actual wall-clock epochs")
        # Access records for GETs are emitted when the corresponding carrier
        # closes, so close only these fixture-owned processes before parsing.
        for process in reversed(processes):
            process.stop()
        access = (root / "nginx-access.log").read_text()
        success_status = "101" if transport == "wss" else "200"
        carrier_records = re.findall(r"^(\S+) (\S+) GET /gdt-r/([a-f0-9]{32})(?:/[^ ]*)? " + success_status + r"$", access, re.M)
        seen = {record[2] for record in carrier_records}
        route_epochs = set()
        successful_indices = set()
        for epoch in epochs:
            for index in range(3):
                if route(transport, epoch, index).rsplit("/", 1)[1] in seen:
                    route_epochs.add(epoch)
                    successful_indices.add(index)
        if len(route_epochs) < 3 or " 404\n" not in access:
            raise AssertionError("missing epoch route changes or injected route rejection")
        if not {1, 2}.issubset(successful_indices):
            raise AssertionError("no successful backup failure/recovery in frontend evidence")
        recovered = any(float(completed) - float(seconds) >= wall_start + 150
                        and path == route(transport, epoch, 1).rsplit("/", 1)[1]
                        for completed, seconds, path in carrier_records for epoch in epochs)
        if not recovered:
            raise AssertionError("healed backup was not used by a later new carrier")
        result.update(status="PASS", short_streams=short_streams, actual_epochs=sorted(epochs),
                      observed_route_epochs=sorted(route_epochs), renewals=renewals,
                      max_sampled_carriers=max(counts), carrier_bound=2,
                      primary_rejection_and_backup_fault_recovery=True,
                      healed_backup_used_by_later_carrier=True,
                      zero_streams_and_queued_bytes_after_fin=True)
        return result
    finally:
        if live is not None:
            live.conn.close()
        for process in reversed(processes):
            process.stop()
        echo.shutdown()
        echo.close_clients()
        echo.server_close()
        thread.join(timeout=2)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--nginx", type=Path, required=True)
    parser.add_argument("--duration", type=int, default=190)
    args = parser.parse_args()
    if not 185 <= args.duration <= 300:
        parser.error("duration must be 185..300 seconds")
    root = Path(tempfile.mkdtemp(prefix="ununknowntun-rotation-soak-"))
    binary = root / "ununknowntun-under-test"
    shutil.copyfile(args.binary.resolve(strict=True), binary)
    binary.chmod(0o700)
    result = {"scope": "loopback-only real Nginx, synthetic new-carrier GET rejection; not ISP/WAN testing",
              "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
              "binary_version": subprocess.check_output([str(binary), "-version"], text=True).strip(),
              "logs": str(root), "profiles": []}
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            futures = [executor.submit(profile, str(binary), str(args.nginx.resolve(strict=True)), root / mode, mode, args.duration)
                       for mode in ("wss", "xhttp")]
            result["profiles"] = [future.result() for future in futures]
        result["status"] = "PASS"
    except BaseException as exc:
        result.update(status="FAIL", error=str(exc))
    (root / "report.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
