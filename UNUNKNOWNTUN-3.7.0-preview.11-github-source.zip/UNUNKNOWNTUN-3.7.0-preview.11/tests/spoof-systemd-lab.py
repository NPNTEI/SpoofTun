#!/usr/bin/env python3
"""Opt-in disposable Linux VM test of the generated GRE service sandbox.

Run only on a disposable local systemd VM you control:
  sudo python3 -I tests/spoof-systemd-lab.py --run-local-lab /absolute/ununknowntun
Offline parser checks (no privileges or network operations):
  python3 -I tests/spoof-systemd-lab.py --self-test

Creates only a random root-owned private /var/tmp directory, two isolated namespaces/veths and
two random transient units. No default routes, Internet destinations, firewall,
sysctl, persistent unit, package installation or existing service changes. The
actual generated run.sh files run with their complete Service settings plus an
owned NetworkNamespacePath, a 60-second RuntimeMaxSec and a one-start guard
(StartLimitBurst=1 over 300s, so Restart=on-failure cannot extend the lab). Work is capped at 90s,
with 30s reserved for cleanup (120s total). A PASS is local sandbox/payload
evidence, not provider permission, WAN reachability or Backhaul interoperability.
SIGKILL/kernel failure can leave exact named lab resources; inspect those only.
"""
import argparse
import configparser
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import platform
import re
import secrets
import shlex
import shutil
import signal
import stat
import struct
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock


sys.dont_write_bytecode = True
SOURCE = Path(__file__).resolve().parent.parent
SERVICE_KEYS = {
    "Type", "User", "Group", "UMask", "ExecStart", "Restart", "RestartSec", "TimeoutStopSec",
    "CapabilityBoundingSet", "AmbientCapabilities", "NoNewPrivileges", "RestrictAddressFamilies",
    "PrivateDevices", "DevicePolicy", "DeviceAllow", "ProtectSystem", "ProtectHome",
    "ProtectKernelTunables", "ProtectControlGroups", "ProtectKernelModules", "RestrictSUIDSGID", "LockPersonality",
}
CAPS = {"cap_net_admin", "cap_net_raw"}
FAMILIES = {"AF_INET", "AF_INET6", "AF_NETLINK"}
PAYLOAD = bytes(range(256)) * 128
DIAGNOSTIC_FIELDS = ("LoadState", "ActiveState", "SubState", "Result", "ExecMainCode", "ExecMainStatus", "MainPID", "InvocationID")

ECHO = r'''
import socket, time
end = time.monotonic() + 60
s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(('127.0.0.1', 18082)); s.listen(1); s.settimeout(0.25)
print('READY', flush=True)
while time.monotonic() < end:
    try: c, _ = s.accept()
    except socket.timeout: continue
    c.settimeout(12); total = 0
    with c:
        while total < 32768:
            data = c.recv(min(4096, 32768-total))
            if not data: raise SystemExit('short client payload')
            c.sendall(data); total += len(data)
    print('ECHO_BYTES=' + str(total), flush=True)
    break
else: raise SystemExit('echo lifetime expired')
s.close()
'''

CLIENT = r'''
import hashlib, json, socket, time
end = time.monotonic() + 8
while True:
    try: c = socket.create_connection(('127.0.0.1', 12055), timeout=0.5); break
    except OSError:
        if time.monotonic() >= end: raise SystemExit('client listener unavailable')
        time.sleep(0.1)
payload = bytes(range(256))*128
with c:
    c.settimeout(12); c.sendall(payload); received = bytearray()
    while len(received) < len(payload):
        data = c.recv(len(payload)-len(received))
        if not data: raise SystemExit('short echo')
        received.extend(data)
if received != payload: raise SystemExit('echo mismatch')
print(json.dumps({'bytes':len(received),'sha256':hashlib.sha256(received).hexdigest()}))
'''


class LabError(RuntimeError):
    pass


def require(value, message):
    if not value:
        raise LabError(message)


def helper_module():
    path = SOURCE / "packaging/spoof-pair.py"
    loader = importlib.util.spec_from_file_location("systemd_lab_pair", path)
    module = importlib.util.module_from_spec(loader)
    loader.loader.exec_module(module)
    return module


def service_settings(data, expected_launcher):
    parser = configparser.ConfigParser(interpolation=None, strict=True)
    parser.optionxform = str
    parser.read_string(data)
    require(not parser.defaults() and set(parser.sections()) == {"Unit", "Service", "Install"},
            "Unsupported service template sections/defaults")
    require(set(parser["Unit"]) == {"Description", "Wants", "After"} and
            set(parser["Install"]) == {"WantedBy"}, "Unsupported unit dependencies/install fields")
    settings = dict(parser["Service"])
    require(set(settings) == SERVICE_KEYS, "Unsupported or missing service sandbox property")
    require(all("\n" not in value and "\r" not in value for value in settings.values()),
            "Multiline service properties are unsupported")
    require(shlex.split(settings.pop("ExecStart")) == ["/bin/sh", expected_launcher],
            "Service ExecStart is not the exact generated launcher")
    require(settings["Type"] == "simple" and settings["User"] == settings["Group"] == "root",
            "Unsupported service execution identity/type")
    for field in ("CapabilityBoundingSet", "AmbientCapabilities"):
        require(set(settings[field].lower().split()) == CAPS, "Unexpected service capabilities")
    require(set(settings["RestrictAddressFamilies"].split()) == FAMILIES, "Unexpected socket families")
    require(settings["PrivateDevices"] == "no" and settings["DevicePolicy"] == "closed" and
            settings["DeviceAllow"] == "/dev/net/tun rw", "TUN device policy differs from expected sandbox")
    require(settings["NoNewPrivileges"] == "yes" and settings["ProtectSystem"] == "strict",
            "Required sandbox protection is missing")
    # Unit network-online dependencies and Install activation are intentionally
    # not started: these transient lab units use already-prepared namespaces.
    return settings


def identity(path):
    item = os.stat(path)
    return item.st_dev, item.st_ino


def process_identity(pid):
    try:
        value = Path("/proc") / str(pid) / "stat"
        return value.read_text().rsplit(")", 1)[1].split()[19]
    except (FileNotFoundError, ProcessLookupError):
        return None


def lab_properties(namespace):
    # Retain the generated restart policy, but prevent even one automatic
    # restart after the runtime limit if this harness itself is killed.
    return {"NetworkNamespacePath": "/run/netns/" + namespace, "RuntimeMaxSec": "60s",
            "StartLimitIntervalSec": "300s", "StartLimitBurst": "1"}


def verify_lab_bounds(state, namespace):
    require(state.get("NetworkNamespacePath") == "/run/netns/" + namespace and
            state.get("RuntimeMaxUSec") in ("1min", "60s", "60000000") and
            state.get("StartLimitIntervalUSec") in ("5min", "300s", "300000000") and
            state.get("StartLimitBurst") == "1", "Manager lifetime/namespace/start bound differs")


def diagnostic_text(value, private_values=()):
    # Sanitize before clipping: a truncated credential must not escape as a
    # prefix. Never retain PEM, config/file dumps or long encoded credentials.
    text = str(value)
    for secret in sorted(private_values, key=len, reverse=True):
        if secret:
            text = text.replace(secret, "[private value redacted]")
    text = re.sub(r"-----BEGIN [^-\r\n]+-----.*?(?:-----END [^-\r\n]+-----|$)",
                  "[PEM redacted]", text, flags=re.DOTALL)
    text = re.sub(r"(?i)\b(token|password|secret|private[_-]?key)\s*[:=]\s*[^\s,;]+",
                  r"\1=[redacted]", text)
    text = re.sub(r"[A-Za-z0-9_+/=-]{32,}", "[encoded value redacted]", text)
    lines = []
    for line in text.splitlines()[:4]:
        if re.search(r"[{}]|^\s*\"[^\"]+\"\s*:", line):
            line = "[structured/file content redacted]"
        line = "".join(character if character.isprintable() else "?" for character in line)
        lines.append(line[:512])
    return " | ".join(lines)[:1024]


def verify_lab_parent(parent):
    require(parent == Path("/var/tmp") and parent.resolve() == parent and not parent.is_symlink(),
            "Lab parent must be the real /var/tmp directory")
    info = parent.stat()
    require(stat.S_ISDIR(info.st_mode) and info.st_uid == 0 and
            (not info.st_mode & 0o022 or info.st_mode & stat.S_ISVTX),
            "Lab parent must be root-owned and non-writable by others or sticky")
    flags = os.statvfs(parent).f_flag
    require(hasattr(os, "ST_NOEXEC") and not flags & os.ST_NOEXEC and not flags & os.ST_RDONLY,
            "/var/tmp must allow execution and writes; no mount or permission changes will be made")


class Lab:
    def __init__(self):
        self.started = time.monotonic()
        self.work_end = self.started + 90
        self.end = self.started + 120
        self.interrupted = False
        self.cleaning = False
        self.directory = None
        self.directory_identity = None
        self.namespaces = {}
        self.pending_namespaces = set()
        self.units = {}
        self.echo = None
        self.echo_log = None
        self.prefix = "gdt-gresd-" + secrets.token_hex(5)
        self.tools = {}
        self.private_values = []

    def remaining(self):
        if self.interrupted and not self.cleaning:
            raise LabError("Interrupted; cleaning only owned lab resources")
        remaining = (self.end if self.cleaning else self.work_end) - time.monotonic()
        require(remaining > 0, "Lab deadline reached")
        return remaining

    def hard_deadline(self, _signum, _frame):
        # Last resort only. Normal errors use verified cleanup below. Do not
        # let an unexpectedly stalled cleanup defeat the overall 120s bound;
        # name only owned resources for manual inspection, never their secrets.
        pending = {"units": sorted(self.units), "namespaces": sorted(set(self.namespaces) | self.pending_namespaces),
                   "private_directory": str(self.directory) if self.directory else None,
                   "echo_pid": self.echo.pid if self.echo is not None else None}
        os.write(2, ("FAIL: 120-second hard deadline; inspect only these owned lab resources: " +
                     json.dumps(pending, sort_keys=True) + "\n").encode())
        os._exit(124)

    def run(self, command, seconds=5, check=True):
        timeout = min(seconds, self.remaining())
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   start_new_session=True, env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C"})
        try:
            stdout, stderr = process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            # This process group was created by this invocation only. It may
            # contain the helper's OpenSSL child, never a service manager unit.
            with contextlib.suppress(ProcessLookupError):
                os.killpg(process.pid, signal.SIGKILL)
            process.communicate(timeout=min(2, max(0.1, self.end - time.monotonic())))
            raise LabError("Timed out local command: " + Path(command[0]).name) from None
        require(len(stdout) <= 65536 and len(stderr) <= 65536, "Local diagnostic output exceeded limit")
        if check:
            require(process.returncode == 0,
                    "Local command failed: " + Path(command[0]).name + " (" + stderr.decode(errors="replace")[:1200].strip() + ")")
        return process.returncode, stdout.decode(), stderr.decode(errors="replace")

    def ip(self, *arguments, **options):
        return self.run([self.tools["ip"], *arguments], **options)

    def unit_state(self, name, seconds=5):
        fields = ("LoadState", "Description", "Transient", "InvocationID", "MainPID", "ActiveState", "SubState",
                  "CapabilityBoundingSet", "AmbientCapabilities", "RestrictAddressFamilies", "PrivateDevices",
                  "DevicePolicy", "NetworkNamespacePath", "RuntimeMaxUSec", "StartLimitIntervalUSec", "StartLimitBurst",
                  "Result", "ExecMainCode", "ExecMainStatus")
        command = [self.tools["systemctl"], "show", name, "--no-pager"]
        for field in fields:
            command += ["--property", field]
        code, output, _ = self.run(command, seconds=seconds, check=False)
        state = dict(line.split("=", 1) for line in output.splitlines() if "=" in line)
        require(code == 0 or state.get("LoadState") == "not-found", "Cannot inspect exact transient unit")
        return state

    def failure_diagnostics(self):
        """Read only exact owned invocations, bounded to eight work seconds."""
        reports = []
        deadline = min(self.work_end, time.monotonic() + 8)
        for name, owned in self.units.items():
            report = {"unit": name}
            try:
                require(deadline - time.monotonic() > 0, "Diagnostic budget exhausted")
                state = self.unit_state(name, seconds=min(2, deadline - time.monotonic()))
                if state.get("LoadState") != "not-found":
                    require(state.get("Description") == owned["description"] and state.get("Transient") == "yes",
                            "Unit identity changed; diagnostics refused")
                    require(not owned["invocation"] or state.get("InvocationID") == owned["invocation"],
                            "Unit invocation changed; diagnostics refused")
                report["state"] = {key: diagnostic_text(state[key], self.private_values)
                                   for key in DIAGNOSTIC_FIELDS if key in state}
                if re.fullmatch(r"[0-9a-f]{32}", state.get("InvocationID", "")):
                    report["state"]["InvocationID"] = state["InvocationID"]
                invocation = owned["invocation"] or state.get("InvocationID", "")
                require(re.fullmatch(r"[0-9a-f]{32}", invocation) and "since" in owned,
                        "No verified invocation journal available")
                require(self.tools.get("journalctl"), "journalctl unavailable")
                require(deadline - time.monotonic() > 0, "Diagnostic budget exhausted")
                command = [self.tools["journalctl"], "--no-pager", "--quiet", "--lines=25", "--output=json",
                           "--output-fields=MESSAGE", "--since=@" + owned["since"],
                           "_SYSTEMD_UNIT=" + name, "_SYSTEMD_INVOCATION_ID=" + invocation]
                code, output, _ = self.run(command, seconds=min(2, deadline - time.monotonic()), check=False)
                require(code == 0, "Exact invocation journal unavailable")
                messages = []
                for line in output.splitlines()[-25:]:
                    item = json.loads(line)
                    value = item.get("MESSAGE")
                    if isinstance(value, str):
                        messages.append(diagnostic_text(value, self.private_values))
                report["journal_messages"] = messages
            except Exception as error:
                report["diagnostic_note"] = diagnostic_text(str(error), self.private_values)
            reports.append(report)
        return reports

    def remember_private_values(self, pair_dir):
        # Reuse the helper's no-symlink, private-owner/mode, bounded reader.
        # Values are retained only in memory for redaction, never printed.
        helper = helper_module()
        with helper.directory(str(pair_dir / "egress"), private=True) as directory:
            for name in ("token", "server.key"):
                value = helper.read_file(directory, name, limit=16384).decode("ascii")
                self.private_values += [value, *value.splitlines()]

    def own_namespace(self, name):
        path = Path("/run/netns") / name
        require(not path.exists(), "Random namespace name already exists")
        self.pending_namespaces.add(name)
        self.ip("netns", "add", name)
        # Signal handlers only set a flag, so identity registration cannot be
        # interrupted between a successful creation and this record.
        self.namespaces[name] = identity(path)
        self.pending_namespaces.remove(name)

    def verify_namespace(self, name):
        require(identity(Path("/run/netns") / name) == self.namespaces[name], "Namespace identity changed; refusing mutation")

    def start_unit(self, role, namespace, pair_dir, pair_id):
        name = self.prefix + "-" + role + ".service"
        description = "UNUNKNOWNTUN isolated GRE sandbox lab " + self.prefix + " " + role
        require(self.unit_state(name).get("LoadState") == "not-found", "Random unit name already exists")
        launcher = str(pair_dir / role / "run.sh")
        unit_path = pair_dir / role / ("ununknowntun-gre-" + pair_id + ".service")
        settings = service_settings(unit_path.read_text(), launcher)
        self.verify_namespace(namespace)
        command = [self.tools["systemd-run"], "--quiet", "--collect", "--no-block", "--unit", name,
                   "--description", description]
        for key, value in settings.items():
            command += ["--property", key + "=" + value]
        for key, value in lab_properties(namespace).items():
            command += ["--property", key + "=" + value]
        command += ["--", "/bin/sh", launcher]
        # Register the exact requested identity before dispatch: a command
        # timeout may still leave a manager-owned unit requiring cleanup.
        self.units[name] = {"description": description, "namespace": namespace, "pid": 0, "start": None,
                            "invocation": None, "since": format(time.time(), ".6f")}
        self.run(command, seconds=8)
        deadline = min(self.work_end, time.monotonic() + 12)
        while time.monotonic() < deadline:
            state = self.unit_state(name)
            require(state.get("Description") == description and state.get("Transient") == "yes",
                    "Transient unit ownership could not be verified")
            if state.get("ActiveState") == "active" and state.get("SubState") == "running":
                pid = int(state.get("MainPID", "0"))
                require(pid > 1 and re.fullmatch(r"[0-9a-f]{32}", state.get("InvocationID", "")), "Missing service process identity")
                require(identity("/proc/" + str(pid) + "/ns/net") == self.namespaces[namespace], "Service escaped its owned network namespace")
                for field in ("CapabilityBoundingSet", "AmbientCapabilities"):
                    require(set(state[field].lower().split()) == CAPS, "Manager did not retain exact GRE capabilities")
                require(set(state["RestrictAddressFamilies"].split()) == FAMILIES and state["PrivateDevices"] == "no" and
                        state["DevicePolicy"] == "closed", "Manager sandbox properties differ from generated template")
                verify_lab_bounds(state, namespace)
                self.units[name].update(pid=pid, start=process_identity(pid), invocation=state["InvocationID"])
                return name
            require(state.get("ActiveState") not in ("failed", "inactive"), "Generated service failed before readiness")
            self.remaining()
            time.sleep(0.1)
        raise LabError("Generated service did not reach running state")

    def snapshot_binary(self, source):
        require(source.is_absolute(), "Binary path must be absolute")
        fd = os.open(source, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        try:
            info = os.fstat(fd)
            require(stat.S_ISREG(info.st_mode) and info.st_mode & 0o6022 == 0 and
                    64 <= info.st_size <= 128 * 1024 * 1024, "Binary must be regular, <=128 MiB, non-set-ID and not group/world writable")
            header = os.read(fd, 64)
            machine = {"x86_64": 62, "amd64": 62, "aarch64": 183, "arm64": 183}.get(platform.machine().lower())
            require(machine is not None and header[:6] == b"\x7fELF\x02\x01" and struct.unpack_from("<H", header, 18)[0] == machine,
                    "Binary architecture does not match this Linux VM")
            os.lseek(fd, 0, os.SEEK_SET)
            destination = self.directory / "ununknowntun"
            digest = hashlib.sha256()
            with open(destination, "xb") as output:
                os.chmod(destination, 0o700)
                while True:
                    self.remaining()
                    data = os.read(fd, 1024 * 1024)
                    if not data:
                        break
                    digest.update(data)
                    output.write(data)
            after = os.fstat(fd)
            require((info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns) ==
                    (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), "Binary changed during snapshot")
            return destination, digest.hexdigest()
        finally:
            os.close(fd)

    def execute(self, binary):
        require(platform.system() == "Linux" and os.geteuid() == 0, "Explicit lab requires root on a disposable Linux VM")
        require(Path("/run/systemd/system").is_dir() and Path("/dev/net/tun").exists(), "systemd and /dev/net/tun are required")
        for tool in ("ip", "systemctl", "systemd-run", "systemd-detect-virt", "openssl"):
            self.tools[tool] = shutil.which(tool)
            require(self.tools[tool], "Missing preinstalled local tool: " + tool)
        self.tools["journalctl"] = shutil.which("journalctl")
        self.run([self.tools["systemd-detect-virt"], "--vm", "--quiet"])
        os.umask(0o077)
        parent = Path("/var/tmp")
        verify_lab_parent(parent)
        self.directory = Path(tempfile.mkdtemp(prefix=self.prefix + "-", dir=str(parent)))
        self.directory_identity = identity(self.directory)
        directory_info = self.directory.stat()
        require(directory_info.st_uid == 0 and stat.S_IMODE(directory_info.st_mode) == 0o700,
                "Private lab directory must be root-owned and mode0700")
        require(not os.statvfs(self.directory).f_flag & os.ST_NOEXEC, "Private lab directory is on a noexec filesystem")
        snapshot, digest = self.snapshot_binary(Path(binary))
        origin, egress = self.prefix + "-o", self.prefix + "-e"
        self.own_namespace(origin)
        self.own_namespace(egress)
        self.ip("-n", origin, "link", "add", "gdt-sdo", "type", "veth", "peer", "name", "gdt-sde", "netns", egress)
        for name, link, local, peer, expected in ((origin, "gdt-sdo", "192.0.2.10", "192.0.2.20", "198.51.100.20"),
                                                 (egress, "gdt-sde", "192.0.2.20", "192.0.2.10", "198.51.100.10")):
            self.ip("-n", name, "link", "set", "lo", "up")
            self.ip("-n", name, "address", "add", local + "/32", "dev", link)
            self.ip("-n", name, "link", "set", link, "mtu", "1500", "up")
            self.ip("-n", name, "-4", "route", "add", peer + "/32", "dev", link, "src", local)
            self.ip("-n", name, "-4", "route", "add", expected + "/32", "dev", link)
            routes = json.loads(self.ip("-n", name, "-j", "-4", "route", "show")[1])
            links = json.loads(self.ip("-n", name, "-j", "link", "show")[1])
            require(len(routes) == 2 and all(route.get("dev") == link and route.get("dst") != "default" for route in routes),
                    "Namespace has an unexpected/default route")
            require({entry["ifname"] for entry in links} == {"lo", link}, "Namespace has an unexpected interface")
        pair_dir = self.directory / "pair"
        pair_id = "sd-" + self.prefix.rsplit("-", 1)[1]
        spec = {"pair_id": pair_id, "authorized": True, "binary_path": str(snapshot), "install_dir": str(pair_dir),
                "origin": {"interface": "gdt-sdo", "real_ip": "192.0.2.10", "source_ip": "198.51.100.10", "inner_ip": "10.77.0.1"},
                "egress": {"interface": "gdt-sde", "real_ip": "192.0.2.20", "source_ip": "198.51.100.20", "inner_ip": "10.77.0.2"}}
        spec_path = self.directory / "spec.json"
        spec_path.write_text(json.dumps(spec))
        helper = str(SOURCE / "packaging/spoof-pair.py")
        self.run([sys.executable, "-I", helper, "--spec", str(spec_path), "--output", str(pair_dir)], seconds=20)
        self.run([sys.executable, "-I", helper, "--check-pair", str(pair_dir)], seconds=10)
        self.remember_private_values(pair_dir)
        self.echo_log = self.directory / "echo.log"
        with open(self.echo_log, "xb") as log:
            self.echo = subprocess.Popen([self.tools["ip"], "netns", "exec", egress, sys.executable, "-I", "-u", "-c", ECHO],
                                         stdout=log, stderr=log, start_new_session=True)
        deadline = min(self.work_end, time.monotonic() + 5)
        while "READY" not in self.echo_log.read_text():
            require(self.echo.poll() is None and time.monotonic() < deadline, "Bounded echo server did not start")
            self.remaining()
            time.sleep(0.1)
        self.start_unit("egress", egress, pair_dir, pair_id)
        self.start_unit("origin", origin, pair_dir, pair_id)
        result = json.loads(self.ip("netns", "exec", origin, sys.executable, "-I", "-c", CLIENT, seconds=22)[1])
        require(result == {"bytes": len(PAYLOAD), "sha256": hashlib.sha256(PAYLOAD).hexdigest()}, "Exact payload echo proof failed")
        for name, owned in self.units.items():
            state = self.unit_state(name)
            require(state.get("ActiveState") == "active" and state.get("InvocationID") == owned["invocation"] and
                    int(state.get("MainPID", "0")) == owned["pid"] and process_identity(owned["pid"]) == owned["start"],
                    "Service restarted/stopped during payload verification")
        return {"result": "PASS", "payload_bytes": len(PAYLOAD), "payload_sha256": result["sha256"], "binary_sha256": digest,
                "service_sandbox": "generated Service settings", "capabilities": sorted(CAPS),
                "address_families": sorted(FAMILIES), "runtime_max_seconds": 60, "scope": "isolated local VM only"}

    def cleanup(self):
        self.cleaning = True
        failures = []
        stoppable = []
        for name, owned in self.units.items():
            try:
                state = self.unit_state(name)
                if state.get("LoadState") == "not-found":
                    continue
                require(state.get("Description") == owned["description"] and state.get("Transient") == "yes",
                        "Transient unit identity changed; refusing stop: " + name)
                stoppable.append(name)
            except Exception as error:
                failures.append(str(error))
        if stoppable:
            try:
                self.run([self.tools["systemctl"], "stop", *stoppable], seconds=18)
            except Exception as error:
                failures.append(str(error))
        try:
            if self.echo is not None and self.echo.poll() is None:
                with contextlib.suppress(ProcessLookupError):
                    os.killpg(self.echo.pid, signal.SIGTERM)
                try:
                    self.echo.wait(timeout=min(2, max(0.1, self.end - time.monotonic())))
                except subprocess.TimeoutExpired:
                    with contextlib.suppress(ProcessLookupError):
                        os.killpg(self.echo.pid, signal.SIGKILL)
                    self.echo.wait(timeout=min(2, max(0.1, self.end - time.monotonic())))
        except Exception as error:
            # A stuck/vanished child must not skip unit, namespace or private
            # file cleanup. Report the exact owned PID without killing others.
            failures.append("Echo child cleanup failed (PID " + str(self.echo.pid) + "): " + str(error))
        for name, owned in self.units.items():
            try:
                require(not owned["pid"] or process_identity(owned["pid"]) != owned["start"], "Owned service PID still exists: " + name)
                state = self.unit_state(name)
                require(state.get("LoadState") == "not-found" or
                        state.get("ActiveState") in ("inactive", "failed") and state.get("MainPID", "0") == "0",
                        "Transient unit remains running: " + name)
            except Exception as error:
                failures.append(str(error))
        for name in reversed(list(self.namespaces)):
            try:
                self.verify_namespace(name)
                require(not self.ip("netns", "pids", name)[1].strip(), "Namespace still contains processes; refusing deletion: " + name)
                self.ip("netns", "delete", name)
                require(not (Path("/run/netns") / name).exists(), "Owned namespace remains: " + name)
            except Exception as error:
                failures.append(str(error))
        failures += ["Namespace creation outcome uncertain; inspect exact name: " + name for name in sorted(self.pending_namespaces)]
        if self.directory is not None:
            try:
                require(identity(self.directory) == self.directory_identity and shutil.rmtree.avoids_symlink_attacks,
                        "Private lab directory identity/safe cleanup unavailable; refusing deletion")
                shutil.rmtree(self.directory)
            except Exception as error:
                failures.append(str(error))
        return failures


class OfflineTests(unittest.TestCase):
    def spec(self):
        return helper_module().validate_spec({"pair_id": "offline", "authorized": True, "binary_path": "/opt/ununknowntun/bin/ununknowntun",
            "origin": {"interface": "eth0", "real_ip": "192.0.2.10", "inner_ip": "10.77.0.1"},
            "egress": {"interface": "eth0", "real_ip": "192.0.2.20", "inner_ip": "10.77.0.2"}})

    def test_complete_generated_sandbox_whitelist(self):
        helper, spec = helper_module(), self.spec()
        for role in ("origin", "egress"):
            settings = service_settings(helper.service(spec, role).decode(), spec["install_dir"] + "/" + role + "/run.sh")
            self.assertEqual(set(settings), SERVICE_KEYS - {"ExecStart"})
            self.assertEqual(settings["DeviceAllow"], "/dev/net/tun rw")
            self.assertNotIn("PrivateNetwork", settings)

    def test_unknown_and_weakened_properties_fail_closed(self):
        helper, spec = helper_module(), self.spec()
        data = helper.service(spec, "origin").decode()
        path = spec["install_dir"] + "/origin/run.sh"
        for changed in (data.replace("Type=simple", "Type=simple\nPrivateNetwork=yes"),
                        data.replace("CAP_NET_ADMIN CAP_NET_RAW", "CAP_SYS_ADMIN"),
                        data.replace("PrivateDevices=no", "PrivateDevices=yes"),
                        data.replace("AF_INET AF_INET6 AF_NETLINK", "AF_INET AF_INET6"),
                        data.replace("NoNewPrivileges=yes", "NoNewPrivileges=no"),
                        data.replace("/origin/run.sh", "/other/run.sh")):
            with self.assertRaises(LabError):
                service_settings(changed, path)

    def test_payload_helpers_compile_and_deadlines_are_bounded(self):
        compile(ECHO, "lab-echo", "exec")
        compile(CLIENT, "lab-client", "exec")
        lab = Lab()
        self.assertEqual(lab.work_end - lab.started, 90)
        self.assertEqual(lab.end - lab.started, 120)
        lab.interrupted = True
        with self.assertRaises(LabError):
            lab.remaining()

    def test_manager_lifetime_cannot_be_extended_by_generated_restart(self):
        helper, spec = helper_module(), self.spec()
        settings = service_settings(helper.service(spec, "origin").decode(), spec["install_dir"] + "/origin/run.sh")
        self.assertEqual(settings["Restart"], "on-failure")
        self.assertEqual(lab_properties("owned"), {"NetworkNamespacePath": "/run/netns/owned", "RuntimeMaxSec": "60s",
                                                 "StartLimitIntervalSec": "300s", "StartLimitBurst": "1"})
        state = {"NetworkNamespacePath": "/run/netns/owned", "RuntimeMaxUSec": "1min",
                 "StartLimitIntervalUSec": "5min", "StartLimitBurst": "1"}
        verify_lab_bounds(state, "owned")
        for key, bad in (("StartLimitIntervalUSec", "0"), ("StartLimitBurst", "2"), ("RuntimeMaxUSec", "infinity")):
            with self.assertRaises(LabError):
                verify_lab_bounds(dict(state, **{key: bad}), "owned")

    def test_echo_stop_errors_do_not_skip_remaining_cleanup(self):
        for fault in (subprocess.TimeoutExpired("owned-echo", 2), OSError("synthetic wait failure")):
            with self.subTest(fault=type(fault).__name__):
                lab = Lab()
                lab.echo = mock.Mock(pid=12345)
                lab.echo.poll.return_value = None
                lab.echo.wait.side_effect = [subprocess.TimeoutExpired("owned-echo", 2), fault]
                lab.units["owned.service"] = {"description": "owned", "pid": 0, "start": None}
                lab.unit_state = mock.Mock(return_value={"LoadState": "not-found"})
                lab.directory = Path("/offline-only-owned-directory")
                lab.directory_identity = (1, 2)
                with mock.patch.object(os, "killpg") as kill, mock.patch(__name__ + ".identity", return_value=(1, 2)), \
                        mock.patch.object(shutil, "rmtree") as remove:
                    remove.avoids_symlink_attacks = True
                    failures = lab.cleanup()
                    remove.assert_called_once_with(lab.directory)
                    self.assertEqual(kill.call_count, 2)
                self.assertEqual(lab.unit_state.call_count, 2)
                self.assertEqual(len(failures), 1)
                self.assertIn("Echo child cleanup failed (PID 12345)", failures[0])

    def test_hard_deadline_names_only_owned_resources(self):
        lab = Lab()
        lab.namespaces["owned-netns"] = (1, 2)
        lab.pending_namespaces.add("owned-pending")
        lab.units["owned.service"] = {"description": "not printed"}
        with mock.patch.object(os, "write") as write, mock.patch.object(os, "_exit") as stop:
            lab.hard_deadline(None, None)
        stop.assert_called_once_with(124)
        output = write.call_args[0][1].decode()
        for name in ("owned-netns", "owned-pending", "owned.service"):
            self.assertIn(name, output)
        self.assertNotIn("not printed", output)

    def test_fifo_binary_is_rejected_without_blocking_open(self):
        original_open = os.open

        def guarded_open(path, flags):
            self.assertTrue(flags & os.O_NONBLOCK)
            return original_open(path, flags)

        with tempfile.TemporaryDirectory(prefix="gdt-systemd-offline-") as temporary:
            fifo = Path(temporary) / "not-a-binary"
            os.mkfifo(fifo, 0o600)
            with mock.patch.object(os, "open", side_effect=guarded_open), self.assertRaises(LabError):
                Lab().snapshot_binary(fifo)

    def test_failure_diagnostics_filter_invocation_and_redact_secrets(self):
        lab = Lab()
        token = "ab" * 32
        key = "private-key-body-not-for-output"
        invocation = "cd" * 16
        lab.private_values = [token, key]
        lab.tools["journalctl"] = "/usr/bin/journalctl"
        lab.units["owned.service"] = {"description": "owned", "invocation": invocation, "since": "1234.500000"}
        lab.unit_state = mock.Mock(return_value={"Description": "owned", "Transient": "yes", "LoadState": "loaded",
            "ActiveState": "failed", "Result": "exit-code", "ExecMainStatus": "1", "InvocationID": invocation,
            "Environment": "MUST NOT APPEAR"})
        messages = ["socket: operation not permitted", "token=" + token, "key: " + key,
                    "-----BEGIN PRIVATE KEY-----\nPRIVATECONTENT\n-----END PRIVATE KEY-----", '{"authorized":true}']
        lab.run = mock.Mock(return_value=(0, "\n".join(json.dumps({"MESSAGE": item, "ENVIRONMENT": "NEVER"}) for item in messages), ""))
        result = lab.failure_diagnostics()
        encoded = json.dumps(result)
        for private in (token, key, "PRIVATECONTENT", "authorized", "MUST NOT APPEAR", "NEVER"):
            self.assertNotIn(private, encoded)
        self.assertIn("socket: operation not permitted", encoded)
        self.assertEqual(result[0]["state"]["ExecMainStatus"], "1")
        command = lab.run.call_args[0][0]
        for exact in ("_SYSTEMD_UNIT=owned.service", "_SYSTEMD_INVOCATION_ID=" + invocation,
                      "--since=@1234.500000", "--lines=25", "--output-fields=MESSAGE"):
            self.assertIn(exact, command)
        self.assertLessEqual(lab.run.call_args[1]["seconds"], 2)

    def test_failure_diagnostics_refuse_changed_identity_and_bound_output(self):
        lab = Lab()
        lab.units["owned.service"] = {"description": "owned", "invocation": "ab" * 16, "since": "1234"}
        lab.unit_state = mock.Mock(return_value={"Description": "not-owned", "LoadState": "loaded", "Transient": "yes"})
        lab.run = mock.Mock()
        self.assertIn("refused", lab.failure_diagnostics()[0]["diagnostic_note"])
        lab.run.assert_not_called()
        self.assertLessEqual(len(diagnostic_text(("normal message " * 1000 + "\n") * 30)), 1024)
        self.assertNotIn("\x1b", diagnostic_text("message\x1b[31m"))

    def test_lab_parent_rejects_noexec_readonly_or_untrusted_directories(self):
        parent = Path("/var/tmp")
        info = mock.Mock(st_mode=stat.S_IFDIR | 0o1777, st_uid=0)
        with mock.patch.object(Path, "resolve", return_value=parent), mock.patch.object(Path, "is_symlink", return_value=False), \
                mock.patch.object(Path, "stat", return_value=info), mock.patch.object(os, "ST_NOEXEC", 8, create=True), \
                mock.patch.object(os, "statvfs") as filesystem:
            filesystem.return_value.f_flag = 0
            verify_lab_parent(parent)
            for flags in (os.ST_NOEXEC, os.ST_RDONLY):
                filesystem.return_value.f_flag = flags
                with self.assertRaises(LabError):
                    verify_lab_parent(parent)
            filesystem.return_value.f_flag = 0
            for mode, owner in ((stat.S_IFDIR | 0o777, 0), (stat.S_IFDIR | 0o1777, 1000)):
                info.st_mode, info.st_uid = mode, owner
                with self.assertRaises(LabError):
                    verify_lab_parent(parent)
        with self.assertRaises(LabError):
            verify_lab_parent(Path("/run"))


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--run-local-lab", metavar="TRUSTED_LINUX_BINARY")
    action.add_argument("--self-test", action="store_true")
    arguments = parser.parse_args()
    if arguments.self_test:
        result = unittest.TextTestRunner().run(unittest.defaultTestLoader.loadTestsFromTestCase(OfflineTests))
        return 0 if result.wasSuccessful() else 1
    lab = Lab()
    signal.signal(signal.SIGALRM, lab.hard_deadline)
    signal.setitimer(signal.ITIMER_REAL, max(0.1, lab.end - time.monotonic()))
    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, lambda _signum, _frame: setattr(lab, "interrupted", True))
    report, error = None, None
    try:
        report = lab.execute(arguments.run_local_lab)
    except Exception as failure:
        error = diagnostic_text(str(failure), lab.private_values)
        for diagnostic in lab.failure_diagnostics():
            print("OWNED UNIT DIAGNOSTIC: " + json.dumps(diagnostic, sort_keys=True), file=sys.stderr, flush=True)
    finally:
        cleanup = lab.cleanup()
        signal.setitimer(signal.ITIMER_REAL, 0)
    if error or cleanup:
        print("FAIL: " + (error or "cleanup incomplete"), file=sys.stderr)
        for failure in cleanup:
            print("CLEANUP ATTENTION: " + failure, file=sys.stderr)
        return 1
    report["cleanup"] = "owned transient units stopped; PIDs gone; two namespaces and private files removed"
    report["elapsed_seconds"] = round(time.monotonic() - lab.started, 3)
    print(json.dumps(report, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
