#!/usr/bin/env python3
"""Opt-in local Linux smoke for the shipped Control Room launch paths.

This runs no install/upgrade branch. The installed-manager case is extracted
into a private /run fixture, never written to /usr/local/bin. Live UI sessions
read the local inventory and receive only q. Protected files and UNUNKNOWNTUN
service identities are compared before/after; no remote connectivity is tested.
"""
import argparse
import datetime
import errno
import hashlib
import json
import os
from pathlib import Path
import pty
import re
import select
import signal
import stat
import subprocess
import sys
import tempfile
import time
import unittest


LIMIT = 2 * 1024 * 1024
SAFE_PATH = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
PROTECTED = ("/etc/ununknowntun", "/etc/ununknowntun-direct-icmp", "/opt/ununknowntun",
             "/usr/local/bin/ununknowntun", "/usr/local/bin/ununknowntunctl")


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def environment():
    env = {key: value for key, value in os.environ.items()
           if not key.startswith(("PYTHON", "LD_", "DYLD_", "BASH_FUNC_"))
           and key not in {"BASH_ENV", "ENV", "SHELLOPTS", "BASHOPTS",
                           "UNUNKNOWNTUN_TOKEN", "V7_TOKEN"}}
    env.update(PATH=SAFE_PATH, TERM="xterm-256color", LC_ALL="C.UTF-8")
    return env


def heredoc(text, terminator):
    marker = "<<'" + terminator + "'\n"
    require(text.count(marker) == 1, "Expected one " + terminator + " heredoc")
    return text.split(marker, 1)[1].split("\n" + terminator + "\n", 1)[0]


def run(command, cwd=None):
    result = subprocess.run(command, cwd=cwd, env=environment(), capture_output=True,
                            text=True, timeout=35)
    require(len(result.stdout) + len(result.stderr) <= LIMIT, "Unexpected command output size")
    require(result.returncode == 0, "Smoke command failed (exit " + str(result.returncode) + ")")
    return result.stdout


def interactive(command, expected_version, cwd=None, prefix_input=b""):
    """Drive actual terminal stdin through the heredoc launcher, bounded to 35s."""
    master, slave = pty.openpty()
    child = None
    data = bytearray()
    sent = False
    try:
        child = subprocess.Popen(command, cwd=cwd, env=environment(), stdin=slave,
                                 stdout=slave, stderr=slave, start_new_session=True)
        os.close(slave)
        slave = -1
        if prefix_input:
            os.write(master, prefix_input)
        deadline = time.monotonic() + 35
        while time.monotonic() < deadline:
            ready, _, _ = select.select([master], [], [], 0.1)
            if ready:
                try:
                    chunk = os.read(master, 65536)
                except OSError as error:
                    if error.errno == errno.EIO:
                        break
                    raise
                if not chunk:
                    break
                data.extend(chunk)
                require(len(data) <= LIMIT, "Unexpected terminal output size")
                if not sent and b"ununknowntun > " in data and b"CONTROL ROOM" in data:
                    os.write(master, b"q\n")
                    sent = True
            if child.poll() is not None and not ready:
                break
        require(sent, "Interactive dashboard prompt did not appear")
        require(child.wait(timeout=3) == 0, "Interactive UI did not exit cleanly")
        text = data.decode("utf-8", errors="replace")
        require(expected_version in text, "Interactive UI version mismatch")
        require("LIVE LOCAL VIEW" in text, "Expected live local inventory mode")
        require("SAMPLE DATA - DEMO ONLY" not in text, "Unexpected demo mode")
        return {"exit_code": 0, "control_room": True, "live_local_view": True,
                "terminal_input_q": True, "output_bytes": len(data)}
    finally:
        if child is not None and child.poll() is None:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=3)
        if slave >= 0:
            os.close(slave)
        os.close(master)


def file_inventory(roots=PROTECTED):
    """Hash protected configuration/code, never expose contents in the report."""
    inventory = {}
    for name in roots:
        root = Path(name)
        paths = [root]
        if root.is_dir() and not root.is_symlink():
            paths.extend(root.rglob("*"))
        for path in sorted(paths):
            try:
                info = path.lstat()
            except FileNotFoundError:
                inventory[str(path)] = None
                continue
            value = [info.st_mode, info.st_uid, info.st_gid, info.st_mtime_ns,
                     info.st_size, info.st_ino]
            if stat.S_ISREG(info.st_mode):
                require(info.st_size <= 100 * 1024 * 1024, "Protected file too large for bounded snapshot")
                digest = hashlib.sha256()
                with path.open("rb") as stream:
                    for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                        digest.update(chunk)
                value.append(digest.hexdigest())
            elif stat.S_ISLNK(info.st_mode):
                value.append(os.readlink(path))
            inventory[str(path)] = value
    return inventory


def service_inventory():
    output = run(["/usr/bin/systemctl", "list-units", "--all", "--type=service",
                  "--no-legend", "--no-pager", "--plain", "ununknowntun*.service"])
    units = []
    for line in output.splitlines():
        words = line.split()
        if words and re.fullmatch(r"ununknowntun[a-zA-Z0-9@_.:-]*\.service", words[0]):
            units.append(words[0])
    result = {}
    for unit in sorted(units):
        result[unit] = run(["/usr/bin/systemctl", "show", unit, "--no-pager",
                            "-p", "ActiveState", "-p", "SubState", "-p", "MainPID",
                            "-p", "NRestarts", "-p", "ExecMainStartTimestampMonotonic"])
    return result


def stages():
    return sorted(str(path) for path in Path("/run").glob("ununknowntun-ui.*"))


def exercise(installer, source):
    version = (source / "VERSION").read_text().strip()
    rendered = installer.read_text()
    require('VERSION="' + version + '"' in rendered, "Installer/release version mismatch")
    embedded = heredoc(rendered, "TERMINAL_UI_PY")
    require(embedded == (source / "ui/ununknowntun-ui.py").read_text().rstrip(),
            "Shipped installer UI differs from release source")
    manager = heredoc(rendered, "CTL")
    require(manager.count('INSTALL_DIR="/opt/ununknowntun"') == 1,
            "Cannot isolate manager installation root")
    protected_before = file_inventory()
    services_before = service_inventory()
    stages_before = stages()
    checks = []
    with tempfile.TemporaryDirectory(prefix="gdt-ui-smoke-", dir="/run") as temporary:
        stage = Path(temporary)
        stage.chmod(0o700)
        share = stage / "share"
        share.mkdir(mode=0o700)
        helper = share / "ununknowntun-ui.py"
        helper.write_text(embedded + "\n")
        helper.chmod(0o644)
        ctl = stage / "ununknowntunctl"
        ctl.write_text(manager.replace('INSTALL_DIR="/opt/ununknowntun"',
                                       'INSTALL_DIR="' + str(stage) + '"') + "\n")
        ctl.chmod(0o700)
        # /run may be mounted noexec. The real manager is a Bash script;
        # invoke its interpreter explicitly so this private fixture does not
        # require executable temporary storage or alter a production path.
        for label, command in (("embedded-installer", ["/bin/bash", str(installer), "ui"]),
                               ("installed-manager-fixture", ["/bin/bash", str(ctl), "ui"])):
            for page in ("tunnels", "tuning", "doctor"):
                output = run(command + ["--preview", page, "--no-color"], cwd=stage)
                require("CONTROL ROOM" in output and version in output,
                        label + " preview missing expected UI/version")
                require("SAMPLE DATA - DEMO ONLY" in output, "Preview must identify sample data")
                checks.append({"name": label + "-preview-" + page, "status": "PASS"})
            checks.append({"name": label + "-live-pty-quit", "status": "PASS",
                           **interactive(command + ["--no-color"], version, cwd=stage)})
        checks.append({"name": "installer-main-menu-9-live-pty-quit", "status": "PASS",
                       **interactive(["/bin/bash", str(installer)], version,
                                     cwd=stage, prefix_input=b"9\n")})
    require(stages() == stages_before, "Embedded UI staging directory was not cleaned up")
    require(file_inventory() == protected_before, "Protected configuration/code changed during UI smoke")
    require(service_inventory() == services_before, "UNUNKNOWNTUN service identity/state changed during UI smoke")
    return {"version": version, "status": "PASS",
            "time_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "installer_sha256": hashlib.sha256(installer.read_bytes()).hexdigest(),
            "ui_sha256": hashlib.sha256((embedded + "\n").encode()).hexdigest(),
            "checks": checks, "protected_entries_unchanged": len(protected_before),
            "ununknowntun_services_unchanged": len(services_before), "stages_cleaned": True,
            "scope": "Actual local Linux embedded/manager-fixture launch and PTY input. No installation, remote connectivity, or UI mutation actions tested."}


class SelfTests(unittest.TestCase):
    def test_heredoc_requires_unique_embed(self):
        self.assertEqual(heredoc("x <<'UI'\nhello\nUI\n", "UI"), "hello")
        with self.assertRaises(RuntimeError):
            heredoc("nothing", "UI")
        with self.assertRaises(RuntimeError):
            heredoc("<<'UI'\na\nUI\n<<'UI'\nb\nUI\n", "UI")

    def test_environment_has_fixed_path(self):
        env = environment()
        self.assertEqual(env["PATH"], SAFE_PATH)
        self.assertNotIn("BASH_ENV", env)
        self.assertNotIn("PYTHONPATH", env)

    def test_snapshot_detects_changes_without_contents(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "config"
            path.write_text("private-fixture-one")
            first = file_inventory((directory,))
            self.assertNotIn("private-fixture-one", repr(first))
            path.write_text("private-fixture-two")
            self.assertNotEqual(file_inventory((directory,)), first)

    def test_pty_preserves_interactive_input_and_clean_exit(self):
        program = ("import sys; assert sys.stdin.isatty() and sys.stdout.isatty(); "
                   "print('CONTROL ROOM 9.9 LIVE LOCAL VIEW', flush=True); "
                   "assert input('ununknowntun > ') == 'q'")
        result = interactive([sys.executable, "-I", "-c", program], "9.9")
        self.assertTrue(result["terminal_input_q"])
        self.assertEqual(result["exit_code"], 0)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--run-local-lab", action="store_true")
    parser.add_argument("--installer", type=Path)
    parser.add_argument("--source", type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.self_test:
        suite = unittest.defaultTestLoader.loadTestsFromTestCase(SelfTests)
        return 0 if unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful() else 1
    if not args.run_local_lab or args.installer is None or args.output is None:
        parser.error("Use --run-local-lab --installer FILE --output NEW_JSON on an isolated Linux lab")
    if sys.platform != "linux" or os.geteuid() != 0:
        parser.error("The opt-in local Linux lab requires root")
    if args.output.exists() or args.output.is_symlink():
        parser.error("Output must be a new file")
    installer = args.installer.resolve(strict=True)
    source = args.source.resolve(strict=True)
    report = exercise(installer, source)
    with args.output.open("x") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"status": report["status"], "checks": len(report["checks"]),
                      "report": str(args.output)}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
