#!/usr/bin/env python3
"""Offline parser regressions: no privileged operation, socket, or VM required."""

import importlib.util
import ast
import json
import os
import re
from pathlib import Path
import socket
import struct
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location("gre_wire_check", Path(__file__).with_name("gre-wire-check.py"))
WIRE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(WIRE)


def fix_checksum(data, offset):
    data[offset:offset + 2] = b"\0\0"
    # A separate byte-pair implementation rather than calling the parser.
    total = sum((data[i] << 8) + (data[i + 1] if i + 1 < len(data) else 0)
                for i in range(0, len(data), 2))
    while total > 65535:
        total = (total & 65535) + (total >> 16)
    struct.pack_into("!H", data, offset, 65535 - total)


def ip_packet(source, destination, protocol, payload, identification=1):
    header = bytearray(struct.pack("!BBHHHBBH4s4s", 0x45, 0, 20 + len(payload),
                                  identification, 0x4000, 64, protocol, 0,
                                  socket.inet_aton(source), socket.inet_aton(destination)))
    fix_checksum(header, 10)
    return header + payload


def ethernet(direction="origin", marker=0, payload_size=1024):
    source, destination = WIRE.INNER[direction]
    ports = (42000, WIRE.PORT) if direction == "origin" else (WIRE.PORT, 42000)
    tcp = bytearray(struct.pack("!HHIIBBHHH", *ports, marker, 1, 0x50, 0x18, 65535, 0, 0)
                    + bytes([marker % 256]) * payload_size)
    pseudo = bytearray(socket.inet_aton(source) + socket.inet_aton(destination)
                       + b"\0\x06" + struct.pack("!H", len(tcp)))
    checked = pseudo + tcp
    fix_checksum(checked, len(pseudo) + 16)
    tcp[16:18] = checked[len(pseudo) + 16:len(pseudo) + 18]
    inner = ip_packet(source, destination, 6, tcp, marker)
    outer = ip_packet(*WIRE.OUTER[direction], 47, b"\0\0\x08\x00" + inner, marker)
    return bytes.fromhex("0200000000020200000000010800") + outer


def records(role):
    result = []
    for direction in ("origin", "egress"):
        packet_type = 4 if direction == role else 0
        result.extend((packet_type, ethernet(direction, marker)) for marker in range(32))
    return result


def encoded(packet_records, **overrides):
    body = bytearray(WIRE.MAGIC)
    for direction, frame in packet_records:
        body.extend(b"P" + struct.pack("!BH", direction, len(frame)) + frame)
    metadata = {"records": len(packet_records), "frame_bytes": sum(len(frame) for _, frame in packet_records),
                "socket_packets": len(packet_records), "drops": 0, "complete": True, "stop_reason": "signal"}
    metadata.update(overrides)
    footer = json.dumps(metadata, separators=(",", ":")).encode("ascii")
    return bytes(body) + b"E" + struct.pack("!I", len(footer)) + footer


def mutate(frame, offset, value, fix_outer=False, fix_inner=False):
    changed = bytearray(frame)
    changed[offset:offset + len(value)] = value
    if fix_outer:
        header = changed[14:34]
        fix_checksum(header, 10)
        changed[14:34] = header
    if fix_inner:
        header = changed[38:58]
        fix_checksum(header, 10)
        changed[38:58] = header
    return bytes(changed)


class WireCheckTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="gdt-wire-offline-")
        self.addCleanup(self.temporary.cleanup)
        self.origin = Path(self.temporary.name) / "origin.wire"
        self.egress = Path(self.temporary.name) / "egress.wire"

    def write_pair(self, origin_records=None, egress_records=None):
        self.origin.write_bytes(encoded(records("origin") if origin_records is None else origin_records))
        self.egress.write_bytes(encoded(records("egress") if egress_records is None else egress_records))

    def rejected_frame(self, frame, message):
        data = records("origin")
        data[0] = (4, frame)
        self.write_pair(origin_records=data)
        with self.assertRaisesRegex(ValueError, message):
            WIRE.verify(self.origin, self.egress)

    def test_independent_checksum_known_vector(self):
        self.assertEqual(WIRE.checksum(bytes.fromhex("0001f203f4f5f6f7")), 0x220d)
        self.assertEqual(WIRE.checksum(b"\x01"), 0xfeff)

    def test_bidirectional_capture_matches_exact_outer_inner_and_payload(self):
        self.write_pair()
        result = WIRE.verify(self.origin, self.egress)
        self.assertEqual(result["unexpected_ipv4_packets"], 0)
        self.assertEqual(result["identical_packets_both_links"], {"origin": 32, "egress": 32})
        for role in ("origin", "egress"):
            for direction in ("origin", "egress"):
                self.assertEqual(result["captures"][role][direction]["tcp_payload_bytes"], 32768)

    def test_wrong_outer_source_or_destination_rejected(self):
        for offset in (26, 30):
            with self.subTest(offset=offset):
                self.rejected_frame(mutate(ethernet(), offset, socket.inet_aton("203.0.113.8"), fix_outer=True),
                                    "outer source/destination")

    def test_non_gre_ipv4_leak_rejected(self):
        self.rejected_frame(mutate(ethernet(), 23, b"\x06", fix_outer=True), "non-GRE IPv4")

    def test_inner_pair_and_carrier_port_rejected(self):
        self.rejected_frame(mutate(ethernet(), 50, socket.inet_aton("10.77.0.9"), fix_inner=True), "inner source/destination")
        self.rejected_frame(mutate(ethernet(), 60, struct.pack("!H", 22)), "carrier TCP port")

    def test_checksums_all_independently_required(self):
        for offset, description in ((24, "outer IPv4 checksum"), (48, "inner IPv4 checksum"), (74, "TCP checksum")):
            with self.subTest(layer=description):
                frame = bytearray(ethernet())
                frame[offset] ^= 1
                self.rejected_frame(bytes(frame), description)

    def test_gre_flags_inner_protocol_fragmentation_and_length_rejected(self):
        for frame, message in (
                (mutate(ethernet(), 34, b"\x20"), "GRE header"),
                (mutate(ethernet(), 47, b"\x11", fix_inner=True), "carrier TCP"),
                (mutate(ethernet(), 20, b"\x20\0", fix_outer=True), "fragmentation"),
                (ethernet()[:-1], "IPv4 length")):
            with self.subTest(message=message):
                self.rejected_frame(frame, message)

    def test_wrong_direction_or_missing_incoming_rejected(self):
        data = records("origin")
        data[0] = (0, data[0][1])
        self.write_pair(origin_records=data)
        with self.assertRaisesRegex(ValueError, "wire direction"):
            WIRE.verify(self.origin, self.egress)
        self.write_pair(origin_records=records("origin")[:32])
        with self.assertRaisesRegex(ValueError, "lacks egress"):
            WIRE.verify(self.origin, self.egress)

    def test_insufficient_payload_and_no_shared_packets_rejected(self):
        self.write_pair(origin_records=records("origin")[1:])
        with self.assertRaisesRegex(ValueError, "bounded payload"):
            WIRE.verify(self.origin, self.egress)
        other = [(0 if direction == "origin" else 4, ethernet(direction, marker + 100))
                 for direction in ("origin", "egress") for marker in range(32)]
        self.write_pair(egress_records=other)
        with self.assertRaisesRegex(ValueError, "no identical"):
            WIRE.verify(self.origin, self.egress)

    def test_incomplete_dropped_and_invalid_footer_rejected(self):
        good = encoded(records("origin"))
        samples = [good[:-1], good + b"junk", WIRE.MAGIC, b"invalid",
                   encoded(records("origin"), drops=1), encoded(records("origin"), complete=False),
                   encoded(records("origin"), stop_reason="deadline"),
                   encoded(records("origin"), frame_bytes=1), encoded(records("origin"), records=True),
                   encoded(records("origin"), socket_packets=1)]
        for value in samples:
            with self.subTest(size=len(value)):
                self.origin.write_bytes(value)
                with self.assertRaises(ValueError):
                    WIRE.read_capture(self.origin)

    def test_file_record_bounds_and_symlink_rejected(self):
        for value in (b"x" * (WIRE.MAX_BYTES + 1),
                      WIRE.MAGIC + b"P" + struct.pack("!BH", 4, WIRE.MAX_FRAME + 1),
                      WIRE.MAGIC + b"P" + struct.pack("!BH", 9, 14) + b"x" * 14,
                      encoded([(4, b"x" * 14)] * (WIRE.MAX_RECORDS + 1))):
            self.origin.write_bytes(value)
            with self.assertRaises(ValueError):
                WIRE.read_capture(self.origin)
        self.egress.symlink_to(self.origin)
        with self.assertRaises(OSError):
            WIRE.read_capture(self.egress)
        fifo = Path(self.temporary.name) / "fifo"
        os.mkfifo(fifo, 0o600)
        with self.assertRaisesRegex(ValueError, "regular file"):
            WIRE.read_capture(fifo)

    def test_arp_link_control_is_bounded_to_real_pair(self):
        arp = (bytes.fromhex("ffffffffffff0200000000010806")
               + bytes.fromhex("0001080006040001") + b"\x02\0\0\0\0\x01"
               + socket.inet_aton("192.0.2.10") + b"\0" * 6 + socket.inet_aton("192.0.2.20"))
        self.write_pair(origin_records=records("origin") + [(4, arp)])
        self.assertEqual(WIRE.verify(self.origin, self.egress)["captures"]["origin"]["arp"], 1)
        self.rejected_frame(mutate(arp, 38, socket.inet_aton("203.0.113.1")), "ARP escaped")

    def test_ipv6_only_local_control_allowed(self):
        def ipv6(next_header, source="fe80::1", destination="ff02::1", body=b"\x87\0" + b"\0" * 22):
            return (bytes.fromhex("33330000000102000000000186dd")
                    + struct.pack("!IHBB16s16s", 6 << 28, len(body), next_header, 255,
                                  socket.inet_pton(socket.AF_INET6, source), socket.inet_pton(socket.AF_INET6, destination)) + body)
        self.write_pair(origin_records=records("origin") + [(4, ipv6(58))])
        self.assertEqual(WIRE.verify(self.origin, self.egress)["captures"]["origin"]["ipv6_control"], 1)
        for frame, message in ((ipv6(6), "unexpected IPv6 traffic"),
                               (ipv6(58, destination="2001:db8::1"), "destination escaped"),
                               (ipv6(58, source="2001:db8::1"), "unexpected IPv6 source")):
            with self.subTest(message=message):
                self.rejected_frame(frame, message)


class LabFixtureTests(unittest.TestCase):
    def setUp(self):
        source = Path(__file__).with_name("gre-netns-lab.sh").read_text()
        self.tree = ast.parse(source.split("<<'PY'\n", 1)[1].rsplit("\nPY", 1)[0])
        self.case = next(node for node in self.tree.body if isinstance(node, ast.FunctionDef) and node.name == "case")

    def test_lazy_carrier_is_not_awaited_before_client(self):
        waits = {}
        client_line = None
        for node in ast.walk(self.case):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                if node.func.id == "wait_for" and isinstance(node.args[-1], ast.Constant):
                    waits[node.args[-1].value] = node.lineno
                if node.func.id == "run" and any(isinstance(value, ast.Constant) and value.value == "positive"
                                                for value in ast.walk(node.args[0])):
                    client_line = node.lineno
        self.assertIsNotNone(client_line)
        self.assertLess(waits["origin client listener before wire capture"], client_line)
        self.assertGreater(waits["authenticated origin session"], client_line)
        self.assertNotIn("authenticated origin session before wire capture", waits)

    def test_wrong_source_requires_receive_identity_counter(self):
        selected = [node for node in ast.walk(self.case)
                    if (isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "stats_pattern"
                                                            for target in node.targets))
                    or (isinstance(node, ast.FunctionDef) and node.name == "mismatch_rejected")]
        context = {"re": re, "mismatch_log": None}
        exec(compile(ast.Module(body=sorted(selected, key=lambda node: node.lineno), type_ignores=[]),
                     "lab_counter_predicate", "exec"), context)
        for sent, received, rejected, identity, expected in (
                (5, 0, 9, 0, False), (5, 0, 9, 2, True), (0, 0, 9, 2, False), (5, 1, 9, 2, False)):
            context["log_text"] = lambda _path, s=sent, r=received, b=rejected, i=identity: (
                f"[spoof/stats] sent={s} received={r} rejected={b} dropped=0 "
                f"tx_rejected=9 rx_rejected=2 rx_identity_mismatch={i} rx_truncated=0")
            self.assertEqual(context["mismatch_rejected"](), expected)


if __name__ == "__main__":
    unittest.main(verbosity=2)
