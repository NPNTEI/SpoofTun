package main

// ClientHello fragmentation only changes TCP write boundaries, not TLS bytes.
// The kernel, proxy or receiver may coalesce them. This experimental option is
// neither ECH nor a promise of censorship resistance or browser equivalence.
import (
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"math/big"
	"net"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

type tlsFragmentSettings struct {
	enabled            bool
	minSize, maxSize   int
	minDelay, maxDelay time.Duration
}

func parseTLSFragmentSettings(mode, size, interval, ech string) (tlsFragmentSettings, error) {
	var settings tlsFragmentSettings
	if mode == "" {
		mode = "off"
	}
	if mode != "off" && mode != "hello" {
		return settings, errors.New("-tls-fragment must be off or hello")
	}
	if size == "" {
		size = "100-200"
	}
	if interval == "" {
		interval = "1-3ms"
	}
	parseRange := func(value string, low, high int) (int, int, error) {
		parts := strings.Split(value, "-")
		if len(parts) < 1 || len(parts) > 2 {
			return 0, 0, errors.New("expected a value or min-max range")
		}
		a, err := strconv.Atoi(parts[0])
		if err != nil {
			return 0, 0, errors.New("range must contain whole numbers")
		}
		b := a
		if len(parts) == 2 {
			b, err = strconv.Atoi(parts[1])
			if err != nil {
				return 0, 0, errors.New("range must contain whole numbers")
			}
		}
		if a < low || b > high || a > b {
			return 0, 0, fmt.Errorf("require %d <= minimum <= maximum <= %d", low, high)
		}
		return a, b, nil
	}
	var err error
	settings.minSize, settings.maxSize, err = parseRange(size, 16, 4096)
	if err != nil {
		return settings, fmt.Errorf("-tls-fragment-size: %w", err)
	}
	if !strings.HasSuffix(interval, "ms") {
		return settings, errors.New("-tls-fragment-interval requires milliseconds, e.g. 1-3ms")
	}
	a, b, err := parseRange(strings.TrimSuffix(interval, "ms"), 0, 20)
	if err != nil {
		return settings, fmt.Errorf("-tls-fragment-interval: %w", err)
	}
	settings.minDelay, settings.maxDelay = time.Duration(a)*time.Millisecond, time.Duration(b)*time.Millisecond
	settings.enabled = mode == "hello"
	if settings.enabled && ech == ECHModeStrict {
		return settings, errors.New("choose ECH strict OR ClientHello fragmentation, not both")
	}
	return settings, nil
}

// Config is validated before dialing. An invalid programmatic configuration
// fails closed on Write rather than silently ignoring the requested mode.
func wrapTLSClientHello(conn net.Conn, cfg *Config) net.Conn {
	settings, err := parseTLSFragmentSettings(cfg.TLSFragment, cfg.TLSFragmentSize, cfg.TLSFragmentInterval, cfg.ECHMode)
	if err == nil && !settings.enabled {
		return conn
	}
	return &clientHelloFragmentConn{Conn: conn, settings: settings, configErr: err, done: make(chan struct{}), deadlineChanged: make(chan struct{})}
}

type clientHelloFragmentConn struct {
	net.Conn
	settings                 tlsFragmentSettings
	configErr                error
	writeMu                  sync.Mutex
	prefix                   [6]byte
	prefixN, seen, remaining int
	decided, finished        bool
	closeOnce                sync.Once
	done                     chan struct{}
	deadlineMu               sync.Mutex
	writeDeadline            time.Time
	deadlineChanged          chan struct{}
}

func fragmentRandom(min, max int64) (int64, error) {
	if min == max {
		return min, nil
	}
	n, err := rand.Int(rand.Reader, big.NewInt(max-min+1))
	if err != nil {
		return 0, fmt.Errorf("fragment random source: %w", err)
	}
	return min + n.Int64(), nil
}

func (c *clientHelloFragmentConn) Write(p []byte) (int, error) {
	c.writeMu.Lock()
	defer c.writeMu.Unlock()
	if c.configErr != nil {
		return 0, c.configErr
	}
	if len(p) == 0 {
		return 0, nil
	}
	if c.finished {
		return c.Conn.Write(p)
	}
	if !c.decided {
		previousPrefix := c.prefixN
		c.prefixN += copy(c.prefix[c.prefixN:], p)
		if c.prefixN == len(c.prefix) {
			c.decided = true
			if c.prefix[0] != 22 || c.prefix[1] != 3 || c.prefix[2] > 4 || c.prefix[5] != 1 {
				c.finished = true
				return c.Conn.Write(p)
			}
			c.remaining = 5 + int(binary.BigEndian.Uint16(c.prefix[3:5])) - c.seen
			if c.remaining <= 0 {
				return 0, errors.New("invalid initial TLS record length")
			}
		} else {
			n, err := c.Conn.Write(p)
			c.prefixN = previousPrefix + n
			c.seen += n
			return n, err
		}
	}
	fragmentBytes := min(len(p), c.remaining)
	written := 0
	for written < fragmentBytes {
		piece, err := fragmentRandom(int64(c.settings.minSize), int64(c.settings.maxSize))
		if err != nil {
			return written, err
		}
		end := min(written+int(piece), fragmentBytes)
		for written < end {
			n, err := c.Conn.Write(p[written:end])
			written += n
			c.remaining -= n
			if err != nil {
				return written, err
			}
			if n == 0 {
				return written, io.ErrShortWrite
			}
		}
		if c.remaining > 0 {
			delay, err := fragmentRandom(int64(c.settings.minDelay), int64(c.settings.maxDelay))
			if err != nil {
				return written, err
			}
			if err := c.waitFragment(time.Duration(delay)); err != nil {
				return written, err
			}
		}
	}
	if c.remaining == 0 {
		c.finished = true
	}
	if written < len(p) {
		n, err := c.Conn.Write(p[written:])
		return written + n, err
	}
	return written, nil
}

func (c *clientHelloFragmentConn) waitFragment(delay time.Duration) error {
	end := time.Now().Add(delay)
	for {
		c.deadlineMu.Lock()
		deadline, changed := c.writeDeadline, c.deadlineChanged
		c.deadlineMu.Unlock()
		now := time.Now()
		if !deadline.IsZero() && !now.Before(deadline) {
			return os.ErrDeadlineExceeded
		}
		select {
		case <-c.done:
			return net.ErrClosed
		default:
		}
		if !now.Before(end) {
			return nil
		}
		wake := end
		if !deadline.IsZero() && deadline.Before(wake) {
			wake = deadline
		}
		timer := time.NewTimer(time.Until(wake))
		select {
		case <-timer.C:
		case <-changed:
			timer.Stop()
		case <-c.done:
			timer.Stop()
			return net.ErrClosed
		}
	}
}

func (c *clientHelloFragmentConn) setTrackedDeadline(t time.Time, both bool) error {
	c.deadlineMu.Lock()
	defer c.deadlineMu.Unlock()
	// Keep the socket deadline and fragment-delay deadline in the same order.
	// net.Conn allows concurrent setters; releasing this mutex before calling
	// the underlying connection could apply an older socket deadline after a
	// newer delay deadline had already been published.
	var err error
	if both {
		err = c.Conn.SetDeadline(t)
	} else {
		err = c.Conn.SetWriteDeadline(t)
	}
	if err != nil {
		return err
	}
	c.writeDeadline = t
	close(c.deadlineChanged)
	c.deadlineChanged = make(chan struct{})
	return nil
}
func (c *clientHelloFragmentConn) SetDeadline(t time.Time) error {
	return c.setTrackedDeadline(t, true)
}
func (c *clientHelloFragmentConn) SetWriteDeadline(t time.Time) error {
	return c.setTrackedDeadline(t, false)
}
func (c *clientHelloFragmentConn) Close() error {
	c.closeOnce.Do(func() { close(c.done) })
	return c.Conn.Close()
}
