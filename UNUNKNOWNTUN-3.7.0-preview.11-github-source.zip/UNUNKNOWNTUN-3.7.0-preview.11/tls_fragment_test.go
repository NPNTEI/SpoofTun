package main

import (
	"bytes"
	"encoding/binary"
	"errors"
	"net"
	"os"
	"sync"
	"testing"
	"time"
)

type fragmentRecordingConn struct {
	net.Conn
	mu       sync.Mutex
	writes   [][]byte
	maxWrite int
	closed   bool
	wrote    chan struct{}
}

func (c *fragmentRecordingConn) Write(p []byte) (int, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.closed {
		return 0, net.ErrClosed
	}
	n := len(p)
	if c.maxWrite > 0 {
		n = min(n, c.maxWrite)
	}
	c.writes = append(c.writes, bytes.Clone(p[:n]))
	if c.wrote != nil {
		select {
		case c.wrote <- struct{}{}:
		default:
		}
	}
	return n, nil
}
func (c *fragmentRecordingConn) SetDeadline(time.Time) error      { return nil }
func (c *fragmentRecordingConn) SetWriteDeadline(time.Time) error { return nil }
func (c *fragmentRecordingConn) Close() error {
	c.mu.Lock()
	c.closed = true
	c.mu.Unlock()
	return nil
}

func fragmentTestHello(n int) []byte {
	p := bytes.Repeat([]byte{0x41}, n)
	p[0], p[1], p[2], p[5] = 22, 3, 1, 1
	binary.BigEndian.PutUint16(p[3:5], uint16(n-5))
	return p
}

func TestTLSFragmentValidation(t *testing.T) {
	settings, err := parseTLSFragmentSettings("hello", "", "", "off")
	if err != nil || !settings.enabled || settings.minSize != 100 || settings.maxSize != 200 || settings.maxDelay != 3*time.Millisecond {
		t.Fatalf("bad preset: %+v %v", settings, err)
	}
	for _, tc := range [][4]string{
		{"invalid", "100", "1ms", "off"}, {"hello", "15", "1ms", "off"},
		{"hello", "4097", "1ms", "off"}, {"hello", "200-100", "1ms", "off"},
		{"hello", "100", "21ms", "off"}, {"hello", "100", "-1ms", "off"},
		{"hello", "100", "1s", "off"}, {"hello", "100", "1ms", ECHModeStrict},
	} {
		if _, err := parseTLSFragmentSettings(tc[0], tc[1], tc[2], tc[3]); err == nil {
			t.Errorf("accepted invalid %v", tc)
		}
	}
	for _, tc := range [][4]string{{"off", "16-4096", "0-20ms", ECHModeStrict}, {"hello", "16", "0ms", "off"}} {
		if _, err := parseTLSFragmentSettings(tc[0], tc[1], tc[2], tc[3]); err != nil {
			t.Errorf("rejected valid %v: %v", tc, err)
		}
	}
	base := &fragmentRecordingConn{}
	if wrapTLSClientHello(base, &Config{}) != base {
		t.Fatal("off must not alter connection")
	}
	bad := wrapTLSClientHello(base, &Config{TLSFragment: "hello", ECHMode: ECHModeStrict})
	if _, err := bad.Write(fragmentTestHello(100)); err == nil || len(base.writes) != 0 {
		t.Fatal("invalid programmatic config must fail closed")
	}
}

func TestTLSFragmentPreservesBytesAndStopsAfterHello(t *testing.T) {
	for _, prefix := range []int{0, 1, 5} {
		base := &fragmentRecordingConn{}
		wrapped := wrapTLSClientHello(base, &Config{TLSFragment: "hello", TLSFragmentSize: "16", TLSFragmentInterval: "0ms"})
		hello := fragmentTestHello(87)
		application := bytes.Repeat([]byte{23}, 100)
		if prefix > 0 {
			if _, err := wrapped.Write(hello[:prefix]); err != nil {
				t.Fatal(err)
			}
		}
		if _, err := wrapped.Write(append(bytes.Clone(hello[prefix:]), application...)); err != nil {
			t.Fatal(err)
		}
		if _, err := wrapped.Write(application); err != nil {
			t.Fatal(err)
		}
		want := append(append(bytes.Clone(hello), application...), application...)
		if !bytes.Equal(bytes.Join(base.writes, nil), want) {
			t.Fatalf("prefix %d altered TLS bytes", prefix)
		}
		if len(base.writes) < 5 {
			t.Fatalf("prefix %d no fragmentation: %v", prefix, base.writes)
		}
		for _, write := range base.writes[:len(base.writes)-2] {
			if len(write) > 16 {
				t.Fatalf("large hello write: %d", len(write))
			}
		}
		if len(base.writes[len(base.writes)-1]) != 100 || len(base.writes[len(base.writes)-2]) != 100 {
			t.Fatal("fragmented post-hello application bytes")
		}
	}
	base := &fragmentRecordingConn{}
	wrapped := wrapTLSClientHello(base, &Config{TLSFragment: "hello"})
	plain := []byte("not a TLS ClientHello")
	if _, err := wrapped.Write(plain); err != nil || len(base.writes) != 1 || !bytes.Equal(base.writes[0], plain) {
		t.Fatal("non-hello write changed")
	}
}

func TestTLSFragmentShortPrefixWrite(t *testing.T) {
	base := &fragmentRecordingConn{maxWrite: 1}
	wrapped := wrapTLSClientHello(base, &Config{TLSFragment: "hello", TLSFragmentSize: "16", TLSFragmentInterval: "0ms"})
	hello := fragmentTestHello(87)
	// A short write before all six discriminating bytes must not advance the
	// inspected prefix past the bytes actually accepted by the connection.
	n, err := wrapped.Write(hello[:5])
	if n != 1 || err != nil {
		t.Fatalf("prefix write: %d %v", n, err)
	}
	if _, err := writeFull(wrapped, hello[n:]); err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(bytes.Join(base.writes, nil), hello) {
		t.Fatal("short writes corrupted hello")
	}
}

func TestTLSFragmentWaitInterrupts(t *testing.T) {
	for _, mode := range []string{"close", "deadline"} {
		t.Run(mode, func(t *testing.T) {
			base := &fragmentRecordingConn{wrote: make(chan struct{}, 1)}
			wrapped := wrapTLSClientHello(base, &Config{TLSFragment: "hello", TLSFragmentSize: "16", TLSFragmentInterval: "20ms"})
			defer wrapped.Close()
			result := make(chan error, 1)
			go func() { _, err := wrapped.Write(fragmentTestHello(2000)); result <- err }()
			select {
			case <-base.wrote:
			case <-time.After(time.Second):
				t.Fatal("no first fragment")
			}
			want := net.ErrClosed
			if mode == "close" {
				wrapped.Close()
			} else {
				want = os.ErrDeadlineExceeded
				wrapped.SetWriteDeadline(time.Now().Add(-time.Second))
			}
			select {
			case err := <-result:
				if !errors.Is(err, want) {
					t.Fatalf("got %v want %v", err, want)
				}
			case <-time.After(time.Second):
				t.Fatal("fragment delay did not cancel")
			}
		})
	}
}

type fragmentGatedDeadlineConn struct {
	fragmentRecordingConn
	first         time.Time
	firstEntered  chan struct{}
	secondEntered chan struct{}
	releaseFirst  chan struct{}
	deadlineMu    sync.Mutex
	applied       time.Time
	deadlineErr   error
}

func (c *fragmentGatedDeadlineConn) setDeadline(at time.Time) error {
	if at.Equal(c.first) {
		close(c.firstEntered)
		<-c.releaseFirst
	} else {
		close(c.secondEntered)
	}
	c.deadlineMu.Lock()
	defer c.deadlineMu.Unlock()
	if c.deadlineErr != nil {
		return c.deadlineErr
	}
	c.applied = at
	return nil
}

func (c *fragmentGatedDeadlineConn) SetDeadline(at time.Time) error {
	return c.setDeadline(at)
}

func (c *fragmentGatedDeadlineConn) SetWriteDeadline(at time.Time) error {
	return c.setDeadline(at)
}

func TestTLSFragmentConcurrentDeadlineSettersStayConsistent(t *testing.T) {
	first, second := time.Now().Add(time.Hour), time.Now().Add(2*time.Hour)
	base := &fragmentGatedDeadlineConn{
		first: first, firstEntered: make(chan struct{}), secondEntered: make(chan struct{}), releaseFirst: make(chan struct{}),
	}
	wrapped := wrapTLSClientHello(base, &Config{TLSFragment: "hello"}).(*clientHelloFragmentConn)
	defer wrapped.Close()
	var releaseOnce sync.Once
	release := func() { releaseOnce.Do(func() { close(base.releaseFirst) }) }
	defer release()
	firstDone, secondDone := make(chan error, 1), make(chan error, 1)
	go func() { firstDone <- wrapped.SetDeadline(first) }()
	awaitDone(t, base.firstEntered)
	go func() { secondDone <- wrapped.SetWriteDeadline(second) }()
	// The first setter is deliberately paused inside the actual connection.
	// The second must not reach that connection until the first is released.
	select {
	case <-base.secondEntered:
		release()
		<-firstDone
		<-secondDone
		t.Fatal("deadline setters reached the underlying connection out of order")
	case <-time.After(50 * time.Millisecond):
	}
	release()
	if err := <-firstDone; err != nil {
		t.Fatal(err)
	}
	if err := <-secondDone; err != nil {
		t.Fatal(err)
	}
	wrapped.deadlineMu.Lock()
	tracked := wrapped.writeDeadline
	wrapped.deadlineMu.Unlock()
	base.deadlineMu.Lock()
	applied := base.applied
	base.deadlineMu.Unlock()
	if !tracked.Equal(second) || !applied.Equal(tracked) {
		t.Fatalf("fragment deadline %v differs from socket deadline %v", tracked, applied)
	}
}

func TestTLSFragmentFailedDeadlineDoesNotPublishChange(t *testing.T) {
	base := &fragmentGatedDeadlineConn{
		first: time.Now().Add(-time.Hour), firstEntered: make(chan struct{}), secondEntered: make(chan struct{}), releaseFirst: make(chan struct{}),
		deadlineErr: net.ErrClosed,
	}
	wrapped := wrapTLSClientHello(base, &Config{TLSFragment: "hello"}).(*clientHelloFragmentConn)
	defer wrapped.Close()
	changed := wrapped.deadlineChanged
	if err := wrapped.SetWriteDeadline(time.Now().Add(time.Hour)); !errors.Is(err, net.ErrClosed) {
		t.Fatalf("expected connection deadline error, got %v", err)
	}
	if !wrapped.writeDeadline.IsZero() {
		t.Fatal("failed socket setter published a different fragment deadline")
	}
	select {
	case <-changed:
		t.Fatal("failed setter woke deadline waiters as if successful")
	default:
	}
}
