package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"os/signal"
	"syscall"
	"time"
)

// Adapter actions have their own configuration and privileges. Reject unrelated
// tunnel flags instead of quietly ignoring a user's security/transport choices.
func runICMPCommand(relay, ping, check string) (bool, error) {
	name, path, count := "", "", 0
	for _, item := range []struct{ name, path string }{{"icmp-relay", relay}, {"icmp-ping", ping}, {"check-icmp-relay-config", check}} {
		if item.path != "" {
			name, path, count = item.name, item.path, count+1
		}
	}
	if count == 0 {
		return false, nil
	}
	if count != 1 {
		return true, errors.New("[icmp/adapter] select only one relay, ping or offline-check action")
	}
	var invalid string
	flag.Visit(func(f *flag.Flag) {
		if f.Name != name {
			invalid = f.Name
		}
	})
	if invalid != "" || flag.NArg() != 0 {
		return true, fmt.Errorf("[icmp/adapter] standalone -%s accepts only its JSON path; unrelated flags/arguments rejected (%s)", name, invalid)
	}
	if name == "check-icmp-relay-config" {
		if err := CheckICMPRelayConfig(path); err != nil {
			return true, err
		}
		fmt.Println("[icmp/adapter] PASS: configuration checked offline; no socket, route, packet or service change.")
		return true, nil
	}
	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()
	if name == "icmp-relay" {
		err := RunICMPRelay(ctx, path)
		if errors.Is(err, context.Canceled) && ctx.Err() != nil {
			err = nil
		}
		return true, err
	}
	result, err := RunICMPPing(ctx, path)
	if encodeErr := json.NewEncoder(os.Stdout).Encode(result); encodeErr != nil {
		return true, errors.Join(err, encodeErr)
	}
	return true, err
}

// Explicit check with native ICMP temporarily creates its owned TUN/host route.
// Both setup and authentication share one deadline; cleanup always precedes exit.
func validateNativeICMPCheck(cfg *Config, timeout time.Duration) error {
	if cfg == nil || cfg.NativeICMP == nil || cfg.Mode != "origin" || timeout <= 0 || timeout > time.Minute {
		return errors.New("[icmp/check] requires native ICMP origin and a deadline in (0,60s]")
	}
	if err := cfg.NativeICMP.validate(); err != nil {
		return err
	}
	expected := cfg.NativeICMP.GREConfig()
	if cfg.GRE == nil || *cfg.GRE != *expected {
		return errors.New("[icmp/check] exact native inner-TCP/device-isolation adapter required")
	}
	return validateGREForTunnel(expected, cfg)
}

// A CA path is otherwise read twice by the shared TLS loader. Check mode uses
// one size-bounded private snapshot, so a FIFO/device or changing source cannot
// block a later TLS read or change trust between preflight and authentication.
// Native checks require a private CA copy; -system-ca needs no snapshot.
// This bounds file size/type, not latency of arbitrary underlying filesystem I/O.
func prepareNativeICMPCheckCA(ctx context.Context, cfg *Config) (*Config, func() error, error) {
	copyConfig := *cfg
	noop := func() error { return nil }
	if err := ctx.Err(); err != nil {
		return nil, noop, err
	}
	if cfg.CAFile == "" {
		return &copyConfig, noop, nil
	}
	const limit = 1024 * 1024
	f, err := openNativeICMPPrivateFile(cfg.CAFile, limit)
	if err != nil {
		return nil, noop, fmt.Errorf("[icmp/check/ca] require a private, owned, regular single-link CA file of at most 1 MiB (chmod 600), or use -system-ca: %w", err)
	}
	data, readErr := io.ReadAll(io.LimitReader(f, limit+1))
	closeErr := f.Close()
	if err := errors.Join(readErr, closeErr, ctx.Err()); err != nil {
		return nil, noop, fmt.Errorf("[icmp/check/ca] %w", err)
	}
	if len(data) > limit {
		return nil, noop, errors.New("[icmp/check/ca] CA file exceeds 1 MiB")
	}
	directory, err := os.MkdirTemp("", "ununknowntun-native-check-ca-")
	if err != nil {
		return nil, noop, err
	}
	path := directory + string(os.PathSeparator) + "ca.pem"
	cleanup := func() error { return errors.Join(os.Remove(path), os.Remove(directory)) }
	output, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		_ = os.Remove(directory)
		return nil, noop, err
	}
	_, writeErr := output.Write(data)
	closeErr = output.Close()
	if err := errors.Join(writeErr, closeErr, ctx.Err()); err != nil {
		return nil, noop, errors.Join(err, cleanup())
	}
	copyConfig.CAFile = path
	return &copyConfig, cleanup, nil
}

func checkNativeICMPTunnelContext(parent context.Context, cfg *Config, timeout time.Duration) (endpoint, transport string, resultErr error) {
	if err := parent.Err(); err != nil {
		return "", "", err
	}
	if err := validateNativeICMPCheck(cfg, timeout); err != nil {
		return "", "", err
	}
	ctx, cancel := context.WithTimeout(parent, timeout)
	defer cancel()
	prepared, cleanup, err := prepareNativeICMPCheckCA(ctx, cfg)
	if err != nil {
		return "", "", err
	}
	defer func() {
		if err := cleanup(); err != nil {
			endpoint, transport = "", ""
			resultErr = errors.Join(resultErr, fmt.Errorf("[icmp/check/cleanup] CA snapshot: %w", err))
		}
	}()
	if _, err := newOriginTransportContext(ctx, prepared); err != nil {
		return "", "", err
	}
	return checkNativeICMPWith(ctx, prepared, timeout, startNativeICMPUnderlayContext, checkTunnelContext)
}

func checkNativeICMPWith(parent context.Context, cfg *Config, timeout time.Duration,
	start func(context.Context, *NativeICMPConfig) (greUnderlay, error),
	probe func(context.Context, *Config, time.Duration) (string, string, error)) (string, string, error) {
	if err := parent.Err(); err != nil {
		return "", "", err
	}
	if err := validateNativeICMPCheck(cfg, timeout); err != nil {
		return "", "", err
	}
	if start == nil || probe == nil {
		return "", "", errors.New("[icmp/check] missing setup/probe implementation")
	}
	ctx, cancel := context.WithTimeout(parent, timeout)
	defer cancel()
	if err := ctx.Err(); err != nil {
		return "", "", err
	}
	u, err := start(ctx, cfg.NativeICMP)
	if err != nil {
		if u != nil {
			err = errors.Join(err, u.Close())
		}
		return "", "", err
	}
	if u == nil {
		return "", "", errors.New("[icmp/check] setup returned no underlay")
	}
	closed := false
	defer func() {
		if !closed {
			_ = u.Close()
		}
	}()
	underlayErrors := u.Errors()
	if underlayErrors == nil {
		closed = true
		return "", "", errors.Join(errors.New("[icmp/check] underlay has no failure monitor"), u.Close())
	}
	stopped := make(chan struct{})
	watchDone := make(chan struct{})
	failure := make(chan error, 1)
	go func() {
		defer close(stopped)
		select {
		case e, ok := <-underlayErrors:
			if !ok || e == nil {
				e = errors.New("native ICMP underlay stopped unexpectedly")
			}
			failure <- e
			cancel()
		case <-watchDone:
		case <-ctx.Done():
		}
	}()
	endpoint, transport, probeErr := probe(ctx, cfg, timeout)
	close(watchDone)
	<-stopped
	select {
	case e := <-failure:
		probeErr = errors.Join(probeErr, e)
	default:
	}
	// If both watcher branches were ready, it may have selected watchDone.
	// Never turn a queued underlay failure into a successful authentication check.
	select {
	case e, ok := <-underlayErrors:
		if !ok || e == nil {
			e = errors.New("native ICMP underlay stopped unexpectedly before cleanup")
		}
		probeErr = errors.Join(probeErr, e)
	default:
	}
	closeErr := u.Close()
	closed = true
	select {
	case e, ok := <-underlayErrors:
		if ok {
			if e == nil {
				e = errors.New("native ICMP underlay emitted an empty error event")
			}
			probeErr = errors.Join(probeErr, e)
		}
	default:
	}
	if err := errors.Join(probeErr, closeErr, ctx.Err()); err != nil {
		return "", "", fmt.Errorf("[icmp/check] inconclusive/failed: %w; timeout alone does not identify filtering", err)
	}
	stats := u.Stats()
	if stats.Sent == 0 || stats.Received == 0 {
		return "", "", errors.New("[icmp/check] missing bidirectional native ICMP packet counters")
	}
	return endpoint, "native-icmp/" + transport, nil
}
