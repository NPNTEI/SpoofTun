package main

import (
	"bytes"
	"context"
	"errors"
	"flag"
	"fmt"
	"io"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

// These checks deliberately use no raw socket, TUN, target dial or privilege.
// The fixture exercises check orchestration independently of Linux networking.
type nativeCheckUnderlay struct {
	errors     chan error
	stats      GREStats
	closeErr   error
	onClose    func()
	closeCalls atomic.Int32
}

func (u *nativeCheckUnderlay) Errors() <-chan error { return u.errors }
func (u *nativeCheckUnderlay) Stats() GREStats      { return u.stats }
func (u *nativeCheckUnderlay) Close() error {
	if u.closeCalls.Add(1) == 1 && u.onClose != nil {
		u.onClose()
	}
	return u.closeErr
}
func newNativeCheckUnderlay() *nativeCheckUnderlay {
	return &nativeCheckUnderlay{errors: make(chan error, 2), stats: GREStats{Sent: 1, Received: 1}}
}
func nativeCheckConfig() *Config {
	c, _ := nativeICMPTestPair()
	return &Config{Mode: "origin", NativeICMP: c, GRE: c.GREConfig(), Transport: TransportTLS,
		Connect: net.JoinHostPort(c.InnerPeerIP, strconv.Itoa(c.CarrierPort)), ECHMode: ECHModeOff, TLSFragment: "off"}
}
func nativeCheckSuccess(context.Context, *Config, time.Duration) (string, string, error) {
	return "10.77.0.2:31080", TransportTLS, nil
}
func nativeCheckStart(u greUnderlay) func(context.Context, *NativeICMPConfig) (greUnderlay, error) {
	return func(context.Context, *NativeICMPConfig) (greUnderlay, error) { return u, nil }
}
func requireNativeCheckFailure(t *testing.T, endpoint, transport string, err error, u *nativeCheckUnderlay) {
	t.Helper()
	if err == nil || endpoint != "" || transport != "" {
		t.Fatalf("failure returned success values: endpoint=%q transport=%q err=%v", endpoint, transport, err)
	}
	if u != nil && u.closeCalls.Load() != 1 {
		t.Fatalf("cleanup calls=%d, want 1", u.closeCalls.Load())
	}
}

func TestNativeICMPCheckSuccessAndSharedDeadline(t *testing.T) {
	cfg := nativeCheckConfig()
	u := newNativeCheckUnderlay()
	var setupDeadline time.Time
	var setupContext context.Context
	startCalls, probeCalls := 0, 0
	parent, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	parentDeadline, _ := parent.Deadline()
	endpoint, transport, err := checkNativeICMPWith(parent, cfg, 5*time.Second,
		func(ctx context.Context, c *NativeICMPConfig) (greUnderlay, error) {
			startCalls++
			if c != cfg.NativeICMP {
				t.Fatal("setup did not receive configured underlay")
			}
			var ok bool
			setupDeadline, ok = ctx.Deadline()
			if !ok || !setupDeadline.Equal(parentDeadline) {
				t.Fatal("setup lost parent's tighter deadline")
			}
			setupContext = ctx
			return u, nil
		}, func(ctx context.Context, c *Config, timeout time.Duration) (string, string, error) {
			probeCalls++
			deadline, ok := ctx.Deadline()
			if !ok || !deadline.Equal(setupDeadline) || ctx != setupContext {
				t.Fatal("setup and authentication do not share one deadline/context")
			}
			if c != cfg || timeout != 5*time.Second {
				t.Fatal("probe changed configuration or requested timeout")
			}
			return nativeCheckSuccess(ctx, c, timeout)
		})
	if err != nil || endpoint != "10.77.0.2:31080" || transport != "native-icmp/tls" {
		t.Fatalf("%q %q %v", endpoint, transport, err)
	}
	if startCalls != 1 || probeCalls != 1 || u.closeCalls.Load() != 1 {
		t.Fatal("setup/probe/cleanup not called exactly once")
	}
	if setupContext.Err() != context.Canceled {
		t.Fatal("check context remains live after return")
	}
}

func TestNativeICMPCheckFailuresAndCleanup(t *testing.T) {
	for _, kind := range []string{"authentication", "cleanup", "no-packets", "sent-only", "received-only", "missing-monitor"} {
		t.Run(kind, func(t *testing.T) {
			u := newNativeCheckUnderlay()
			sentinel := errors.New(kind)
			probe := nativeCheckSuccess
			switch kind {
			case "authentication":
				probe = func(context.Context, *Config, time.Duration) (string, string, error) {
					return "candidate", "tls", sentinel
				}
			case "cleanup":
				u.closeErr = sentinel
			case "no-packets":
				u.stats = GREStats{}
			case "sent-only":
				u.stats = GREStats{Sent: 1}
			case "received-only":
				u.stats = GREStats{Received: 1}
			case "missing-monitor":
				u.errors = nil
			}
			ep, tr, err := checkNativeICMPWith(context.Background(), nativeCheckConfig(), time.Second, nativeCheckStart(u), probe)
			requireNativeCheckFailure(t, ep, tr, err, u)
			if (kind == "authentication" || kind == "cleanup") && !errors.Is(err, sentinel) {
				t.Fatalf("lost cause: %v", err)
			}
		})
	}
}

func TestNativeICMPCheckSetupFailure(t *testing.T) {
	sentinel := errors.New("setup failed")
	for _, setupErr := range []error{sentinel, nil} {
		ep, tr, err := checkNativeICMPWith(context.Background(), nativeCheckConfig(), time.Second,
			func(context.Context, *NativeICMPConfig) (greUnderlay, error) { return nil, setupErr },
			func(context.Context, *Config, time.Duration) (string, string, error) {
				t.Fatal("probe called without underlay")
				return "", "", nil
			})
		requireNativeCheckFailure(t, ep, tr, err, nil)
		if setupErr != nil && !errors.Is(err, sentinel) {
			t.Fatalf("lost setup error: %v", err)
		}
	}
	u := newNativeCheckUnderlay()
	u.closeErr = errors.New("partial setup cleanup")
	ep, tr, err := checkNativeICMPWith(context.Background(), nativeCheckConfig(), time.Second,
		func(context.Context, *NativeICMPConfig) (greUnderlay, error) { return u, sentinel },
		func(context.Context, *Config, time.Duration) (string, string, error) {
			t.Fatal("probe called after partial setup failure")
			return "", "", nil
		})
	requireNativeCheckFailure(t, ep, tr, err, u)
	if !errors.Is(err, sentinel) || !errors.Is(err, u.closeErr) {
		t.Fatalf("partial setup lost error or cleanup result: %v", err)
	}
}

func TestNativeICMPCheckSetupDeadline(t *testing.T) {
	begin := time.Now()
	ep, tr, err := checkNativeICMPWith(context.Background(), nativeCheckConfig(), 20*time.Millisecond,
		func(ctx context.Context, _ *NativeICMPConfig) (greUnderlay, error) {
			<-ctx.Done()
			return nil, ctx.Err()
		}, func(context.Context, *Config, time.Duration) (string, string, error) {
			t.Fatal("authentication ran after setup timeout")
			return "", "", nil
		})
	requireNativeCheckFailure(t, ep, tr, err, nil)
	if !errors.Is(err, context.DeadlineExceeded) || time.Since(begin) > time.Second {
		t.Fatalf("setup deadline not preserved: duration=%s error=%v", time.Since(begin), err)
	}
}

func TestNativeICMPCheckInvalidBeforeSetup(t *testing.T) {
	tests := []struct {
		name    string
		mutate  func(*Config)
		timeout time.Duration
	}{
		{"missing-native", func(c *Config) { c.NativeICMP = nil }, time.Second},
		{"wrong-mode", func(c *Config) { c.Mode = "egress" }, time.Second},
		{"wrong-native-role", func(c *Config) { c.NativeICMP.Role = "egress"; c.GRE = c.NativeICMP.GREConfig() }, time.Second},
		{"missing-isolation", func(c *Config) { c.GRE = nil }, time.Second},
		{"different-isolation-device", func(c *Config) { c.GRE.TUNName = "another0" }, time.Second},
		{"different-isolation-source", func(c *Config) { c.GRE.SourceIP = "192.0.2.99" }, time.Second},
		{"not-tls", func(c *Config) { c.Transport = TransportWSS }, time.Second},
		{"wrong-endpoint", func(c *Config) { c.Connect = "example.invalid:31080" }, time.Second},
		{"ech", func(c *Config) { c.ECHMode = ECHModeStrict }, time.Second},
		{"fragmentation", func(c *Config) { c.TLSFragment = "on" }, time.Second},
		{"unauthorized", func(c *Config) { c.NativeICMP.Authorized = false; c.GRE = c.NativeICMP.GREConfig() }, time.Second},
		{"invalid-poll", func(c *Config) { c.NativeICMP.PollMS = 4 }, time.Second},
		{"zero-timeout", func(*Config) {}, 0},
		{"negative-timeout", func(*Config) {}, -time.Second},
		{"excessive-timeout", func(*Config) {}, time.Minute + time.Nanosecond},
	}
	start := func(context.Context, *NativeICMPConfig) (greUnderlay, error) {
		t.Fatal("invalid configuration activated underlay")
		return nil, nil
	}
	probe := func(context.Context, *Config, time.Duration) (string, string, error) {
		t.Fatal("invalid configuration probed target")
		return "", "", nil
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			cfg := nativeCheckConfig()
			tt.mutate(cfg)
			ep, tr, err := checkNativeICMPWith(context.Background(), cfg, tt.timeout, start, probe)
			requireNativeCheckFailure(t, ep, tr, err, nil)
		})
	}
	ep, tr, err := checkNativeICMPWith(context.Background(), nil, time.Second, start, probe)
	requireNativeCheckFailure(t, ep, tr, err, nil)
	for _, nilStart := range []bool{false, true} {
		s, p := start, probe
		if nilStart {
			s = nil
		} else {
			p = nil
		}
		ep, tr, err := checkNativeICMPWith(context.Background(), nativeCheckConfig(), time.Second, s, p)
		requireNativeCheckFailure(t, ep, tr, err, nil)
	}
}

func TestNativeICMPCheckCanceledBeforeSetupAndFileAccess(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	cfg := nativeCheckConfig()
	cfg.CAFile = "/does/not/exist"
	start := func(context.Context, *NativeICMPConfig) (greUnderlay, error) {
		t.Fatal("canceled check activated underlay")
		return nil, nil
	}
	ep, tr, err := checkNativeICMPWith(ctx, cfg, time.Second, start, nativeCheckSuccess)
	requireNativeCheckFailure(t, ep, tr, err, nil)
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("lost cancellation: %v", err)
	}
	ep, tr, err = checkNativeICMPTunnelContext(ctx, cfg, time.Second)
	requireNativeCheckFailure(t, ep, tr, err, nil)
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("file access preceded cancellation: %v", err)
	}
}

func TestNativeICMPCheckDeadlineAndUnderlayFailureCancelProbe(t *testing.T) {
	for _, kind := range []string{"deadline", "underlay"} {
		t.Run(kind, func(t *testing.T) {
			u := newNativeCheckUnderlay()
			sentinel := errors.New("receiver failed")
			begin := time.Now()
			ep, tr, err := checkNativeICMPWith(context.Background(), nativeCheckConfig(), 20*time.Millisecond, nativeCheckStart(u),
				func(ctx context.Context, _ *Config, _ time.Duration) (string, string, error) {
					if kind == "underlay" {
						u.errors <- sentinel
					}
					<-ctx.Done()
					return "", "", ctx.Err()
				})
			requireNativeCheckFailure(t, ep, tr, err, u)
			if time.Since(begin) > time.Second {
				t.Fatalf("bounded cooperative probe took %s", time.Since(begin))
			}
			if kind == "deadline" && !errors.Is(err, context.DeadlineExceeded) {
				t.Fatalf("lost deadline: %v", err)
			}
			if kind == "underlay" && !errors.Is(err, sentinel) {
				t.Fatalf("lost underlay failure: %v", err)
			}
		})
	}
}

func TestNativeICMPCheckQueuedFailureRace(t *testing.T) {
	// A successful probe and queued failure make both watcher branches ready.
	// Repeat each form to guard against select randomly hiding failed transport.
	for _, kind := range []string{"error", "nil", "closed"} {
		t.Run(kind, func(t *testing.T) {
			for i := 0; i < 100; i++ {
				u := newNativeCheckUnderlay()
				sentinel := fmt.Errorf("queued failure %d", i)
				switch kind {
				case "error":
					u.errors <- sentinel
				case "nil":
					u.errors <- nil
				case "closed":
					close(u.errors)
				}
				ep, tr, err := checkNativeICMPWith(context.Background(), nativeCheckConfig(), time.Second, nativeCheckStart(u), nativeCheckSuccess)
				requireNativeCheckFailure(t, ep, tr, err, u)
				if kind == "error" && !errors.Is(err, sentinel) {
					t.Fatalf("iteration %d lost queued cause: %v", i, err)
				}
			}
		})
	}
}

func TestNativeICMPCheckCloseDrainsFinalFailure(t *testing.T) {
	for _, kind := range []string{"error", "nil", "normal-close"} {
		t.Run(kind, func(t *testing.T) {
			u := newNativeCheckUnderlay()
			sentinel := errors.New("failure during cleanup")
			u.onClose = func() {
				switch kind {
				case "error":
					u.errors <- sentinel
				case "nil":
					u.errors <- nil
				case "normal-close":
					close(u.errors)
				}
			}
			ep, tr, err := checkNativeICMPWith(context.Background(), nativeCheckConfig(), time.Second, nativeCheckStart(u), nativeCheckSuccess)
			if kind == "normal-close" {
				if err != nil || ep == "" || tr != "native-icmp/tls" || u.closeCalls.Load() != 1 {
					t.Fatalf("normal cleanup failed: %q %q %v", ep, tr, err)
				}
			} else {
				requireNativeCheckFailure(t, ep, tr, err, u)
				if kind == "error" && !errors.Is(err, sentinel) {
					t.Fatalf("lost final error: %v", err)
				}
			}
		})
	}
}

func nativeCheckPrivateDir(t *testing.T) string {
	t.Helper()
	if runtime.GOOS != "linux" && runtime.GOOS != "darwin" {
		t.Skip("secure private-file opener supported on Linux/Darwin")
	}
	path, err := filepath.EvalSymlinks(t.TempDir())
	if err != nil {
		t.Fatal(err)
	}
	return path
}

func TestNativeICMPCheckCASnapshot(t *testing.T) {
	dir := nativeCheckPrivateDir(t)
	source := filepath.Join(dir, "source.pem")
	data := []byte("bounded CA snapshot fixture")
	if err := os.WriteFile(source, data, 0600); err != nil {
		t.Fatal(err)
	}
	cfg := nativeCheckConfig()
	cfg.CAFile = source
	prepared, cleanup, err := prepareNativeICMPCheckCA(context.Background(), cfg)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = cleanup() })
	if prepared == cfg || prepared.CAFile == source || cfg.CAFile != source {
		t.Fatal("snapshot mutated caller or reused changing source")
	}
	if err := os.WriteFile(source, []byte("changed"), 0600); err != nil {
		t.Fatal(err)
	}
	got, err := os.ReadFile(prepared.CAFile)
	if err != nil || !bytes.Equal(got, data) {
		t.Fatalf("snapshot changed: %q %v", got, err)
	}
	for path, mode := range map[string]os.FileMode{prepared.CAFile: 0600, filepath.Dir(prepared.CAFile): 0700} {
		st, err := os.Stat(path)
		if err != nil || st.Mode().Perm() != mode {
			t.Fatalf("unsafe snapshot permissions at %s: %v %v", path, st, err)
		}
	}
	if err := cleanup(); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Stat(filepath.Dir(prepared.CAFile)); !errors.Is(err, os.ErrNotExist) {
		t.Fatalf("snapshot directory survives cleanup: %v", err)
	}
}

func TestNativeICMPCheckCAUnsafeFiles(t *testing.T) {
	for _, kind := range []string{"public", "symlink", "ancestor-symlink", "hardlink", "directory", "oversize", "missing", "fifo"} {
		t.Run(kind, func(t *testing.T) {
			dir := nativeCheckPrivateDir(t)
			path := filepath.Join(dir, "ca.pem")
			if kind != "missing" && kind != "directory" && kind != "fifo" {
				if err := os.WriteFile(path, []byte("certificate"), 0600); err != nil {
					t.Fatal(err)
				}
			}
			switch kind {
			case "public":
				if err := os.Chmod(path, 0644); err != nil {
					t.Fatal(err)
				}
			case "symlink":
				link := filepath.Join(dir, "link.pem")
				if err := os.Symlink(path, link); err != nil {
					t.Fatal(err)
				}
				path = link
			case "ancestor-symlink":
				link := filepath.Join(dir, "linked")
				if err := os.Symlink(dir, link); err != nil {
					t.Fatal(err)
				}
				path = filepath.Join(link, "ca.pem")
			case "hardlink":
				if err := os.Link(path, filepath.Join(dir, "second.pem")); err != nil {
					t.Fatal(err)
				}
			case "directory":
				if err := os.Mkdir(path, 0700); err != nil {
					t.Fatal(err)
				}
			case "oversize":
				if err := os.Truncate(path, 1024*1024+1); err != nil {
					t.Fatal(err)
				}
			case "fifo":
				tool, err := exec.LookPath("mkfifo")
				if err != nil {
					t.Skip("mkfifo utility unavailable")
				}
				ctx, cancel := context.WithTimeout(context.Background(), time.Second)
				defer cancel()
				if output, err := exec.CommandContext(ctx, tool, path).CombinedOutput(); err != nil {
					t.Fatalf("create local FIFO: %v %s", err, output)
				}
			}
			cfg := nativeCheckConfig()
			cfg.CAFile = path
			begin := time.Now()
			prepared, cleanup, err := prepareNativeICMPCheckCA(context.Background(), cfg)
			if err == nil || prepared != nil {
				t.Fatalf("accepted unsafe %s CA: %v", kind, err)
			}
			if err := cleanup(); err != nil {
				t.Fatal(err)
			}
			if time.Since(begin) > time.Second {
				t.Fatal("non-regular file check blocked")
			}
		})
	}
}

func TestNativeICMPCheckCAEmptyAndCanceled(t *testing.T) {
	cfg := nativeCheckConfig()
	prepared, cleanup, err := prepareNativeICMPCheckCA(context.Background(), cfg)
	if err != nil || prepared == cfg || prepared.CAFile != "" {
		t.Fatalf("empty CA: %v", err)
	}
	if err := cleanup(); err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	cfg.CAFile = "/does/not/exist"
	prepared, cleanup, err = prepareNativeICMPCheckCA(ctx, cfg)
	if !errors.Is(err, context.Canceled) || prepared != nil {
		t.Fatalf("cancellation lost: %v", err)
	}
	if err := cleanup(); err != nil {
		t.Fatal(err)
	}
}

func TestNativeICMPCheckPreflightCleansSnapshot(t *testing.T) {
	dir := nativeCheckPrivateDir(t)
	tmp := filepath.Join(dir, "snapshots")
	if err := os.Mkdir(tmp, 0700); err != nil {
		t.Fatal(err)
	}
	t.Setenv("TMPDIR", tmp)
	path := filepath.Join(dir, "bad.pem")
	if err := os.WriteFile(path, []byte("not a certificate"), 0600); err != nil {
		t.Fatal(err)
	}
	cfg := nativeCheckConfig()
	cfg.CAFile = path
	ep, tr, err := checkNativeICMPTunnelContext(context.Background(), cfg, time.Second)
	requireNativeCheckFailure(t, ep, tr, err, nil)
	if !strings.Contains(err.Error(), "no usable CA certificates") {
		t.Fatalf("did not fail TLS before underlay setup: %v", err)
	}
	entries, err := os.ReadDir(tmp)
	if err != nil || len(entries) != 0 {
		t.Fatalf("preflight leaked snapshot: %v %v", entries, err)
	}
	if cfg.CAFile != path {
		t.Fatal("preflight mutated caller CA")
	}
}

func TestICMPCommandRejectsContradictoryActions(t *testing.T) {
	saved := flag.CommandLine
	defer func() { flag.CommandLine = saved }()
	for _, args := range [][]string{
		{"-icmp-relay", "config", "-icmp-ping", "other"},
		{"-icmp-relay", "config", "-check-icmp-relay-config", "other"},
		{"-icmp-ping", "config", "-check-icmp-relay-config", "other"},
		{"-icmp-relay", "config", "-mode", "origin"},
		{"-icmp-ping", "config", "-icmp-config", "native.json"},
		{"-check-icmp-relay-config", "config", "-tls-min-version", "1.2"},
		{"-icmp-ping", "config", "extra-positional"},
	} {
		t.Run(strings.Join(args, "_"), func(t *testing.T) {
			fs := flag.NewFlagSet("test", flag.ContinueOnError)
			fs.SetOutput(io.Discard)
			relay := fs.String("icmp-relay", "", "")
			ping := fs.String("icmp-ping", "", "")
			check := fs.String("check-icmp-relay-config", "", "")
			for _, name := range []string{"mode", "icmp-config", "tls-min-version"} {
				fs.String(name, "", "")
			}
			if err := fs.Parse(args); err != nil {
				t.Fatal(err)
			}
			flag.CommandLine = fs
			handled, err := runICMPCommand(*relay, *ping, *check)
			if !handled || err == nil || !strings.Contains(err.Error(), "[icmp/adapter]") {
				t.Fatalf("contradictory action reached configuration/network: handled=%t err=%v", handled, err)
			}
		})
	}
	handled, err := runICMPCommand("", "", "")
	if handled || err != nil {
		t.Fatalf("empty action handled=%t err=%v", handled, err)
	}
}
