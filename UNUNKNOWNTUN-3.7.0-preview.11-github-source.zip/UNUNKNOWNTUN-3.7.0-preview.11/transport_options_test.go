package main

import (
	"bufio"
	"io"
	"net"
	"net/http"
	"strings"
	"testing"
	"time"
)

func TestWebSocketProfilesMatchTLSAndCapabilities(t *testing.T) {
	for _, profile := range []string{"chrome", "firefox", "ios"} {
		t.Run(profile, func(t *testing.T) {
			hello, err := browserHelloID(profile)
			if err != nil {
				t.Fatal(err)
			}
			wire, err := webSocketRequest("tunnel.example.com", "/assets/test", "sample-key", "Bearer token", profile)
			if err != nil {
				t.Fatal(err)
			}
			req, err := http.ReadRequest(bufio.NewReader(strings.NewReader(wire)))
			if err != nil {
				t.Fatal(err)
			}
			if req.Host != "tunnel.example.com" || req.URL.Path != "/assets/test" || req.Header.Get("Authorization") != "Bearer token" || req.Header.Get("Sec-WebSocket-Key") != "sample-key" {
				t.Fatal("profile changed authenticated routing or WebSocket fields")
			}
			ua := req.Header.Get("User-Agent")
			marker := map[string]string{"chrome": "Chrome/", "firefox": "Firefox/", "ios": "Version/"}[profile] + hello.Version + "."
			if !strings.Contains(ua, marker) {
				t.Fatalf("UA %q does not track hello %v", ua, hello)
			}
			if req.Header.Get("Sec-WebSocket-Extensions") != "" || req.Header.Get("Accept-Encoding") != "" {
				t.Fatal("advertised unimplemented compression")
			}
			if !headerContainsToken(req.Header.Get("Connection"), "upgrade") || req.Header.Get("Upgrade") != "websocket" || req.Header.Get("Sec-WebSocket-Version") != "13" {
				t.Fatal("invalid WebSocket handshake")
			}
		})
	}
	for _, field := range []int{0, 1, 2, 3} {
		values := []string{"example.com", "/test", "key", "auth"}
		values[field] += "\r\nInjected: yes"
		if _, err := webSocketRequest(values[0], values[1], values[2], values[3], "chrome"); err == nil {
			t.Fatalf("accepted request injection in field %d", field)
		}
	}
	if _, err := webSocketRequest("example.com", "/test", "key", "auth", "random"); err == nil {
		t.Fatal("accepted unknown profile")
	}
}

func tcpTestPair(t *testing.T) (*net.TCPConn, *net.TCPConn) {
	t.Helper()
	ln, err := net.ListenTCP("tcp", &net.TCPAddr{IP: net.IPv4(127, 0, 0, 1)})
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()
	a, err := net.DialTCP("tcp", nil, ln.Addr().(*net.TCPAddr))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { a.Close() })
	b, err := ln.AcceptTCP()
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { b.Close() })
	a.SetDeadline(time.Now().Add(5 * time.Second))
	b.SetDeadline(time.Now().Add(5 * time.Second))
	return a, b
}

func TestTCPCongestionOptionalAndFailurePreservesConnection(t *testing.T) {
	a, b := tcpTestPair(t)
	if err := setTCPCongestion(a, ""); err != nil {
		t.Fatalf("default congestion option failed: %v", err)
	}
	if err := setTCPCongestion(a, "gdt_missing"); err == nil {
		t.Fatal("unsupported algorithm unexpectedly exists")
	}
	if _, err := a.Write([]byte("alive")); err != nil {
		t.Fatal(err)
	}
	var reply [5]byte
	if _, err := io.ReadFull(b, reply[:]); err != nil || string(reply[:]) != "alive" {
		t.Fatalf("connection broken after failed socket option: %v", err)
	}
}

func TestTCPCongestionValidation(t *testing.T) {
	for input, expected := range map[string]string{"": "", "default": "", " BBR ": "bbr", "cubic": "cubic", "bbr2": "bbr2"} {
		actual, err := normalizeTCPCongestion(input)
		if err != nil || actual != expected {
			t.Fatalf("%q = %q, %v", input, actual, err)
		}
	}
	for _, value := range []string{"bbr\x00", "bbr;cmd", "two words", "1234567890123456"} {
		if _, err := normalizeTCPCongestion(value); err == nil {
			t.Fatalf("accepted %q", value)
		}
	}
}
