package main

import (
	"context"
	"encoding/hex"
	"errors"
	"fmt"
	"strings"
	"time"
)

// checkTunnelContext uses the same certificate verification, browser TLS,
// ECH/fragment setting, HTTP carrier and UNUNKNOWNTUN authentication as a tunnel.
// It never opens a local listener, a target stream, or writes configuration.
// One deadline covers DNS/ECH discovery, every endpoint attempt and auth.
func checkTunnelContext(parent context.Context, cfg *Config, timeout time.Duration) (string, string, error) {
	if timeout <= 0 || timeout > 60*time.Second {
		return "", "", errors.New("[config] probe timeout must be greater than zero and at most 60s")
	}
	if cfg == nil || cfg.Mode != "origin" {
		return "", "", errors.New("[config] -check-tunnel requires -mode origin")
	}
	ctx, cancel := context.WithTimeout(parent, timeout)
	defer cancel()
	cfg, err := currentRuntimeConfig(cfg)
	if err != nil {
		return "", "", err
	}
	verifiers := 0
	if cfg.SystemCA {
		verifiers++
	}
	if cfg.CAFile != "" {
		verifiers++
	}
	if cfg.Fingerprint != "" {
		verifiers++
		if raw, decodeErr := hex.DecodeString(cfg.Fingerprint); decodeErr != nil || len(raw) != 32 {
			return "", "", errors.New("[config] certificate fingerprint must be 64 hexadecimal characters")
		}
	}
	if verifiers != 1 {
		return "", "", errors.New("[config] choose exactly one of -system-ca, -ca or -fingerprint")
	}
	if (cfg.SystemCA || cfg.CAFile != "") && cfg.SNI == "" {
		return "", "", errors.New("[config] -sni is required with CA verification")
	}
	if len(cfg.Token) < 16 || len(cfg.Token) > MaxTokenSize {
		return "", "", errors.New("[config] a valid shared token is required for the authentication probe")
	}
	if cfg.ECHMode != "" && cfg.ECHMode != ECHModeOff && cfg.ECHMode != ECHModeStrict {
		return "", "", errors.New("[config] ECH mode must be off or strict")
	}
	if cfg.Transport == TransportTLS && cfg.ECHMode == ECHModeStrict {
		return "", "", errors.New("[config] ECH requires WSS or XHTTP")
	}
	if _, err := parseTLSFragmentSettings(cfg.TLSFragment, cfg.TLSFragmentSize, cfg.TLSFragmentInterval, cfg.ECHMode); err != nil {
		return "", "", err
	}
	endpoints, err := parseAddressList(cfg.Connect, "-connect", false)
	if err != nil {
		return "", "", err
	}
	transport, err := newOriginTransportContext(ctx, cfg)
	if err != nil {
		return "", "", fmt.Errorf("[probe/config] %w", err)
	}
	var failures []string
	for _, endpoint := range endpoints {
		if ctx.Err() != nil {
			break
		}
		sess, label, authErr := transport.dialAuthenticatedContext(ctx, endpoint, cfg)
		if authErr != nil {
			failures = append(failures, fmt.Sprintf("%s: %v", endpoint, authErr))
			continue
		}
		sess.Close()
		reg.remove(sess)
		if ctx.Err() != nil {
			break
		}
		return endpoint, label, nil
	}
	err = fmt.Errorf("[probe] no authenticated carrier established: %s", strings.Join(failures, "; "))
	if ctx.Err() != nil {
		err = errors.Join(ctx.Err(), err)
	}
	return "", "", err
}
