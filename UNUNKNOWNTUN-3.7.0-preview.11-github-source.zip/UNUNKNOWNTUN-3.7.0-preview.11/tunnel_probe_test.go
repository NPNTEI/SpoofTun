package main

import (
	"context"
	"crypto/sha256"
	"crypto/tls"
	"encoding/hex"
	"errors"
	"io"
	"net"
	"net/http"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"golang.org/x/net/http2"
)

type probeRoundTripper func(*http.Request) (*http.Response, error)

func (f probeRoundTripper) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

func TestTunnelProbeBoundsECHDiscoveryAndValidatesConfiguration(t *testing.T) {
	cfg := &Config{Mode: "origin", Transport: TransportWSS, Connect: "127.0.0.1:1", Token: "probe-test-shared-token", SystemCA: true,
		SNI: "probe.example.com", WSHost: "probe.example.com", WSPath: "/probe/abcdefghijkl", UTLSProfile: "chrome",
		ECHMode: ECHModeStrict, ECHDoH: "https://doh.example.invalid/dns-query"}
	previous := http.DefaultTransport
	defer func() { http.DefaultTransport = previous }()
	var requests atomic.Int32
	http.DefaultTransport = probeRoundTripper(func(r *http.Request) (*http.Response, error) {
		requests.Add(1)
		<-r.Context().Done()
		return nil, r.Context().Err()
	})
	start := time.Now()
	_, _, err := checkTunnelContext(context.Background(), cfg, 40*time.Millisecond)
	if !errors.Is(err, context.DeadlineExceeded) || requests.Load() != 1 || time.Since(start) > time.Second {
		t.Fatalf("ECH discovery escaped total probe deadline: requests=%d elapsed=%s err=%v", requests.Load(), time.Since(start), err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	_, _, err = checkTunnelContext(ctx, cfg, time.Second)
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("probe ignored canceled parent: %v", err)
	}
	for _, timeout := range []time.Duration{0, -time.Second, 61 * time.Second} {
		if _, _, err := checkTunnelContext(context.Background(), cfg, timeout); err == nil {
			t.Fatalf("accepted timeout %s", timeout)
		}
	}
	copy := *cfg
	copy.Mode = "egress"
	if _, _, err := checkTunnelContext(context.Background(), &copy, time.Second); err == nil {
		t.Fatal("probe accepted egress role")
	}
	copy = *cfg
	copy.Fingerprint = strings.Repeat("a", 64)
	if _, _, err := checkTunnelContext(context.Background(), &copy, time.Second); err == nil {
		t.Fatal("probe accepted ambiguous certificate verification")
	}
}

func TestTunnelProbeUsesRealTransportAndAuthWithoutOpeningStreams(t *testing.T) {
	for _, mode := range []string{TransportWSS, TransportXHTTP, TransportAuto, TransportH2} {
		t.Run(mode, func(t *testing.T) {
			const host = "probe-test.example.com"
			const token = "probe-integration-shared-0123456789abcdef"
			dir := t.TempDir()
			cert, err := loadOrCreateCert(filepath.Join(dir, "test.crt"), filepath.Join(dir, "test.key"), host, false)
			if err != nil {
				t.Fatal(err)
			}
			fingerprint := sha256.Sum256(cert.Certificate[0])
			allow, err := ParseAllowList("127.0.0.1:1")
			if err != nil {
				t.Fatal(err)
			}
			cfg := &Config{Mode: "origin", Transport: mode, Token: token, SNI: host, WSHost: host, WSPath: "/probe/wss-abcdefghijkl",
				XHTTPPath: "/probe/xhttp-abcdefghijkl", XHTTPMode: "packet-up", UTLSProfile: "chrome", ECHMode: ECHModeOff,
				Fingerprint: hex.EncodeToString(fingerprint[:]), allowList: allow, Listen: "invalid-listener-must-not-open", Target: "invalid-target-must-not-dial"}
			limiter := NewAdaptiveRateLimiter(10, 5)
			handler := newXHTTPServer(cfg, func(c net.Conn, ip string) { dispatchEgressConn(c, ip, cfg, limiter) })
			defer handler.Close()
			serverFinished := make(chan struct{}, 1)
			server := managedTestListener(t, func(raw net.Conn) {
				defer func() { serverFinished <- struct{}{} }()
				alpn := "http/1.1"
				if mode == TransportXHTTP {
					alpn = "h2"
				}
				conn := tls.Server(raw, &tls.Config{Certificates: []tls.Certificate{cert}, MinVersion: tls.VersionTLS13, NextProtos: []string{alpn}})
				if err := conn.Handshake(); err != nil {
					return
				}
				if mode == TransportXHTTP {
					(&http2.Server{}).ServeConn(conn, &http2.ServeConnOpts{Handler: handler})
					return
				}
				ws, ip, err := acceptServerWebSocket(conn, host, cfg.WSPath, token)
				if err != nil {
					return
				}
				dispatchEgressConn(ws, ip, cfg, limiter)
			})
			cfg.Connect = server.Addr().String()
			streams, memory := activeStreams.Load(), memoryBudget.Load()
			endpoint, actual, err := checkTunnelContext(context.Background(), cfg, 5*time.Second)
			if err != nil {
				t.Fatal(err)
			}
			want := TransportWSS
			if mode == TransportXHTTP {
				want = TransportXHTTP
			}
			if endpoint != cfg.Connect || actual != want {
				t.Fatalf("result endpoint=%s transport=%s", endpoint, actual)
			}
			select {
			case <-serverFinished:
			case <-time.After(2 * time.Second):
				t.Fatal("successful probe left its carrier open")
			}
			waitForStreamBaseline(t, streams, memory)
		})
	}
}

func TestTunnelProbeTotalDeadlineCancelsTLSHandshake(t *testing.T) {
	server := managedTestListener(t, func(c net.Conn) { _, _ = io.Copy(io.Discard, c) })
	cfg := &Config{Mode: "origin", Transport: TransportTLS, Connect: server.Addr().String(), Token: "probe-deadline-shared-token",
		SNI: "probe.example.com", Fingerprint: strings.Repeat("a", 64)}
	start := time.Now()
	_, _, err := checkTunnelContext(context.Background(), cfg, 50*time.Millisecond)
	if !errors.Is(err, context.DeadlineExceeded) || time.Since(start) > time.Second {
		t.Fatalf("TLS probe escaped total timeout: elapsed=%s err=%v", time.Since(start), err)
	}
	if !strings.Contains(err.Error(), "tls-handshake") {
		t.Fatalf("missing actual failing stage: %v", err)
	}
}
