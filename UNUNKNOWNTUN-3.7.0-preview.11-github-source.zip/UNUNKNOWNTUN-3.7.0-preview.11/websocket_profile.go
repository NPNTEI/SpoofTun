package main

import (
	"fmt"
	"strings"

	utls "github.com/refraction-networking/utls"
)

// WSS metadata must track the pinned uTLS hello, not a randomly chosen browser
// or the current release of a browser with a different ClientHello. These are
// coherent profiles, not a claim of indistinguishability from a browser.
// Deliberately do not advertise permessage-deflate: the framer does not support it.
func webSocketRequest(host, path, key, authorization, profile string) (string, error) {
	hello, err := browserHelloID(profile)
	if err != nil {
		return "", err
	}
	// These values go into an HTTP/1 request verbatim; reject injection even
	// when this function is called outside main's configuration validation.
	for _, value := range []string{host, path, key, authorization} {
		if strings.ContainsAny(value, "\r\n\x00") {
			return "", fmt.Errorf("invalid WebSocket request field")
		}
	}
	if strings.ContainsAny(host, " \t") || strings.ContainsAny(path, " \t") {
		return "", fmt.Errorf("invalid WebSocket host or path")
	}
	var lines []string
	lines = append(lines, "GET "+path+" HTTP/1.1", "Host: "+host)
	switch hello.Client {
	case utls.HelloChrome_Auto.Client:
		ua := "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + hello.Version + ".0.0.0 Safari/537.36"
		lines = append(lines, "Connection: Upgrade", "Pragma: no-cache", "Cache-Control: no-cache", "User-Agent: "+ua, "Upgrade: websocket", "Origin: https://"+host, "Sec-WebSocket-Version: 13", "Accept-Language: en-US,en;q=0.9", "Sec-WebSocket-Key: "+key)
	case utls.HelloFirefox_Auto.Client:
		ua := "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:" + hello.Version + ".0) Gecko/20100101 Firefox/" + hello.Version + ".0"
		lines = append(lines, "User-Agent: "+ua, "Accept: */*", "Accept-Language: en-US,en;q=0.5", "Sec-WebSocket-Version: 13", "Origin: https://"+host, "Sec-WebSocket-Key: "+key, "Connection: Upgrade", "Upgrade: websocket", "Sec-Fetch-Dest: empty", "Sec-Fetch-Mode: websocket", "Sec-Fetch-Site: same-origin", "Pragma: no-cache", "Cache-Control: no-cache")
	case utls.HelloIOS_Auto.Client:
		ua := "Mozilla/5.0 (iPhone; CPU iPhone OS " + hello.Version + "_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/" + hello.Version + ".0 Mobile/15E148 Safari/604.1"
		lines = append(lines, "Upgrade: websocket", "Connection: Upgrade", "Sec-WebSocket-Key: "+key, "Sec-WebSocket-Version: 13", "Origin: https://"+host, "User-Agent: "+ua, "Accept-Language: en-us")
	default:
		return "", fmt.Errorf("unsupported WebSocket browser %q", hello.Client)
	}
	// Keep transport authentication compatible with deployed 3.0.7 servers.
	lines = append(lines, "Authorization: "+authorization, "", "")
	return strings.Join(lines, "\r\n"), nil
}
