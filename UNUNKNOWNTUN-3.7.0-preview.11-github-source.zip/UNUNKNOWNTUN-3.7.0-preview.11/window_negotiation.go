package main

import (
	"crypto/rand"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"log"
)

// Capability discovery uses an existing, authenticated Ping/Pong exchange.
// Legacy peers echo the query unchanged. A supporting peer returns a distinct
// prefix with the same nonce, so an ordinary echo cannot enable new semantics.
// No header, command, or authentication payload changes are required.
const (
	initialWindowQueryPrefix uint32 = 0x47574931 // GWI1
	initialWindowReplyPrefix uint32 = 0x47574131 // GWA1
	maxInitialWindowFrames          = 32
)

func (s *Session) acceptInitialWindowCapability(payload []byte) bool {
	if s.side != "egress" || s.initialStreamSeen.Load() || len(payload) != 8 ||
		binary.BigEndian.Uint32(payload) != initialWindowQueryPrefix {
		return false
	}
	// The read loop handles Open and this query serially. Once any Open has
	// arrived, never change initial-credit semantics for an existing carrier.
	s.fixedInitialWindow.Store(true)
	reply := append([]byte(nil), payload...)
	binary.BigEndian.PutUint32(reply, initialWindowReplyPrefix)
	s.writeAsync(ctrlHeader(CmdPong, 0, 0), reply, true)
	return true
}

// negotiateInitialStreamWindow runs after authentication but before the origin
// session enters its pool or starts its read loop. The caller's absolute auth
// deadline/watchdog bounds the entire exchange, including carrier writes. An
// incomplete exchange is an error, never a silent fallback: the peer may have
// already committed to the negotiated mode before its reply was interrupted.
func negotiateInitialStreamWindow(s *Session) error {
	query := make([]byte, 8)
	binary.BigEndian.PutUint32(query, initialWindowQueryPrefix)
	if _, err := rand.Read(query[4:]); err != nil {
		return fmt.Errorf("initial-window capability nonce: %w", err)
	}
	if err := s.writeFrame(ctrlHeader(CmdPing, 0, 0), query); err != nil {
		return fmt.Errorf("initial-window capability query: %w", err)
	}
	var header [HeaderSize]byte
	for i := 0; i < maxInitialWindowFrames; i++ {
		if _, err := io.ReadFull(s.conn, header[:]); err != nil {
			return fmt.Errorf("initial-window capability reply: %w", err)
		}
		h, err := DecodeHeader(header[:])
		if err != nil {
			return err
		}
		body := make([]byte, int(h.Length)+int(h.PadLen))
		if _, err := io.ReadFull(s.conn, body); err != nil {
			return fmt.Errorf("initial-window capability body: %w", err)
		}
		payload := body[:h.Length]
		if h.Cmd == CmdPong {
			if binary.BigEndian.Uint32(payload[4:]) != binary.BigEndian.Uint32(query[4:]) {
				return errors.New("initial-window capability nonce mismatch")
			}
			switch binary.BigEndian.Uint32(payload) {
			case initialWindowReplyPrefix:
				s.fixedInitialWindow.Store(true)
				log.Printf("[origin] negotiated fixed initial-stream credit")
				return nil
			case initialWindowQueryPrefix:
				// A real echo is the only legacy fallback. The old initial-credit
				// rules remain unchanged for rolling upgrades in either direction.
				log.Printf("[origin] peer uses legacy initial-stream credit; upgrade both endpoints for resize-race protection")
				return nil
			default:
				return errors.New("unexpected initial-window capability response")
			}
		}
		// Egress health sampling can resize a freshly authenticated carrier
		// before our query is read. Process only safe session-level controls;
		// no logical streams exist at this phase.
		if h.Cmd != CmdWindowResize && h.Cmd != CmdPing {
			return fmt.Errorf("unexpected command 0x%02X during capability negotiation", h.Cmd)
		}
		s.handleFrame(h, payload)
		if s.Closed() {
			return errors.New("session closed during initial-window capability negotiation")
		}
	}
	return errors.New("too many frames during initial-window capability negotiation")
}
