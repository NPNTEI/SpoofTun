package main

// XHTTP packet-up wire reference: Xray-core maintainer specification,
// https://github.com/XTLS/Xray-core/discussions/4113#packet-up (read 2026-09-28).
// GET /path/UUID streams download; POST /path/UUID/seq uploads finite bodies.
// Packet-up uses bounded parallel POSTs; streaming profiles are implemented in
// xhttp_stream.go. All profiles retain UNUNKNOWNTUN HMAC and authenticated payloads.
// It is NOT a VLESS endpoint or a claim of stock Xray proxy interoperability.

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/http/httptrace"
	"os"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"golang.org/x/net/http2"
	"golang.org/x/net/netutil"
)

const (
	xhttpMaxPostBytes = 64 * 1024
	xhttpUploadWindow = 8
	xhttpCopyBuffer   = 32 * 1024
	xhttpMaxHTTPConns = MaxSessions * (xhttpUploadWindow + 1)
)

func validateXHTTPPath(path string) error {
	if len(path) < 2 || len(path) > 512 || !strings.HasPrefix(path, "/") ||
		strings.ContainsAny(path, "?#%\\ \t\r\n") || strings.Contains(path, "//") ||
		strings.Contains(path, "/../") || strings.Contains(path, "/./") ||
		strings.HasSuffix(path, "/..") || strings.HasSuffix(path, "/.") {
		return errors.New("XHTTP path must be an absolute clean URL path, without query, escapes, whitespace, or dot segments")
	}
	return nil
}

func newXHTTPID() (string, error) {
	var b [16]byte
	if _, err := rand.Read(b[:]); err != nil {
		return "", err
	}
	b[6] = b[6]&0x0f | 0x40
	b[8] = b[8]&0x3f | 0x80
	s := hex.EncodeToString(b[:])
	return s[:8] + "-" + s[8:12] + "-" + s[12:16] + "-" + s[16:20] + "-" + s[20:], nil
}

func validXHTTPID(s string) bool {
	if len(s) != 36 || s[8] != '-' || s[13] != '-' || s[18] != '-' || s[23] != '-' {
		return false
	}
	decoded, err := hex.DecodeString(strings.ReplaceAll(s, "-", ""))
	return err == nil && len(decoded) == 16
}

// The read pipe supplies real, changeable net.Conn read deadlines. Like a
// socket send buffer, Write accepts copied bytes into a bounded upload window;
// a later HTTP failure closes the stream and is reported by Read/Write. This
// permits pipelining even when the GDT frame writer makes small serial writes.
type xhttpUpload struct {
	seq  uint64
	body []byte
}

type xhttpClientConn struct {
	readSide       net.Conn
	pumpSide       net.Conn
	physical       net.Conn
	client         http.RoundTripper
	host           string
	path           string
	token          string
	body           io.ReadCloser
	ctx            context.Context
	cancel         context.CancelFunc
	writeMu        sync.Mutex
	writeDL        streamDeadline
	seq            uint64
	closeOnce      sync.Once
	closed         chan struct{}
	pumpDone       chan struct{}
	uploads        chan xhttpUpload
	slots          chan struct{}
	uploadDone     chan struct{}
	uploadProgress chan struct{}
	errMu          sync.Mutex
	failure        error
	padding        xhttpPaddingRange
}

func clientXHTTP(raw net.Conn, rawTCP *net.TCPConn, host, path, token string, options ...XHTTPOptions) (net.Conn, error) {
	option, err := normalizeXHTTPOptions(options)
	if err != nil {
		return nil, err
	}
	// ConfigureTransports propagates the Go 1.24+ receive-window limits to
	// x/net/http2. Its stand-alone default otherwise buffers 4 MiB per stream.
	transport, err := http2.ConfigureTransports(&http.Transport{
		DisableCompression:     true,
		MaxResponseHeaderBytes: 16 * 1024,
		HTTP2: &http.HTTP2Config{
			MaxReceiveBufferPerConnection: 256 * 1024,
			MaxReceiveBufferPerStream:     128 * 1024,
		},
	})
	if err != nil {
		return nil, fmt.Errorf("[http-xhttp-connect] configure HTTP/2: %w", err)
	}
	transport.WriteByteTimeout = tunnelWriteDeadline()
	transport.ReadIdleTimeout = 45 * time.Second
	transport.PingTimeout = 10 * time.Second
	transport.MaxHeaderListSize = 16 * 1024
	transport.MaxReadFrameSize = 16 * 1024
	transport.DisableCompression = true
	client, err := transport.NewClientConn(raw)
	if err != nil {
		return nil, fmt.Errorf("[http-xhttp-connect] create HTTP/2 connection: %w", err)
	}
	var conn net.Conn
	if option.Mode == "packet-up" {
		conn, err = newXHTTPClientConn(raw, client, host, path, token, option)
	} else {
		conn, err = newXHTTPStreamClientConn(raw, client, host, path, token, option)
	}
	if err != nil {
		_ = client.Close()
		return nil, err
	}
	return &trackedNetConn{Conn: conn, tcp: rawTCP}, nil
}

func newXHTTPClientConn(raw net.Conn, client http.RoundTripper, host, path, token string, options ...XHTTPOptions) (*xhttpClientConn, error) {
	option, err := normalizeXHTTPOptions(options)
	if err != nil {
		return nil, err
	}
	if option.Mode != "packet-up" {
		return nil, errors.New("packet-up constructor cannot create a streaming carrier")
	}
	padding, _ := parseXHTTPPadding(option.PaddingBytes)
	if err := validateXHTTPPath(path); err != nil {
		return nil, err
	}
	id, err := newXHTTPID()
	if err != nil {
		return nil, err
	}
	ctx, cancel := context.WithCancel(context.Background())
	readSide, pumpSide := net.Pipe()
	c := &xhttpClientConn{
		readSide: readSide, pumpSide: pumpSide, physical: raw, client: client,
		host: host, path: strings.TrimSuffix(path, "/") + "/" + id, token: token,
		ctx: ctx, cancel: cancel, writeDL: newStreamDeadline(),
		closed: make(chan struct{}), pumpDone: make(chan struct{}),
		uploads: make(chan xhttpUpload, xhttpUploadWindow), slots: make(chan struct{}, xhttpUploadWindow),
		uploadDone: make(chan struct{}), uploadProgress: make(chan struct{}, 1),
		padding: padding,
	}
	request, err := c.request(ctx, http.MethodGet, c.path, nil)
	if err != nil {
		_ = c.Close()
		return nil, err
	}
	// Stop this timer after response headers; the GET remains alive for the
	// session. A context.WithTimeout on GET would silently kill healthy tunnels.
	timeoutDone := make(chan struct{})
	timer := time.AfterFunc(authTimeout, func() { cancel(); close(timeoutDone) })
	response, err := client.RoundTrip(request)
	if !timer.Stop() {
		<-timeoutDone
		if response != nil {
			_ = response.Body.Close()
		}
		_ = c.Close()
		return nil, fmt.Errorf("[http-xhttp-download] response headers timeout: %w", context.DeadlineExceeded)
	}
	if err != nil {
		_ = c.Close()
		return nil, fmt.Errorf("[http-xhttp-download] request/response: %w", err)
	}
	if response.StatusCode != http.StatusOK || !strings.HasPrefix(strings.ToLower(response.Header.Get("Content-Type")), "text/event-stream") {
		_ = response.Body.Close()
		_ = c.Close()
		return nil, fmt.Errorf("[http-xhttp-download] rejected: HTTP %d (check CDN rules, route, host, clock, and transport authentication)", response.StatusCode)
	}
	c.body = response.Body
	if raw != nil {
		if err := raw.SetDeadline(time.Time{}); err != nil {
			_ = c.Close()
			return nil, err
		}
	}
	go func() {
		defer close(c.pumpDone)
		defer c.Close()
		_, err := io.CopyBuffer(c.pumpSide, c.body, make([]byte, xhttpCopyBuffer))
		select {
		case <-c.closed:
			return
		default:
		}
		if err == nil {
			err = io.EOF
		}
		c.fail(fmt.Errorf("[http-xhttp-download] stream ended: %w", err))
	}()
	go c.uploadLoop()
	return c, nil
}

func (c *xhttpClientConn) request(ctx context.Context, method, path string, body []byte) (*http.Request, error) {
	req, err := http.NewRequestWithContext(ctx, method, "https://"+c.host+path, bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	auth, err := makeWebSocketAuthorization(c.token, c.host, path, time.Now())
	if err != nil {
		return nil, err
	}
	req.Host = c.host
	req.Header.Set("Authorization", auth)
	req.Header.Set("Cache-Control", "no-store")
	req.Header["User-Agent"] = nil
	if err := setXHTTPRequestPadding(req, c.padding); err != nil {
		return nil, err
	}
	if method == http.MethodPost {
		req.Header.Set("Content-Type", "application/octet-stream")
	}
	return req, nil
}

func (c *xhttpClientConn) connectionError(fallback error) error {
	c.errMu.Lock()
	defer c.errMu.Unlock()
	if c.failure != nil {
		return c.failure
	}
	return fallback
}

func (c *xhttpClientConn) fail(err error) {
	c.errMu.Lock()
	if c.failure == nil {
		c.failure = err
	}
	c.errMu.Unlock()
	_ = c.Close()
}

func (c *xhttpClientConn) Read(p []byte) (int, error) {
	n, err := c.readSide.Read(p)
	if err != nil {
		err = c.connectionError(err)
	}
	return n, err
}

// watchUploadDeadline handles both an already-blocked request and subsequent
// deadline changes. A timed-out POST makes the carrier unusable: retrying its
// sequence could duplicate bytes if the server consumed it before timeout.
func (c *xhttpClientConn) watchUploadDeadline(stop <-chan struct{}, done chan<- struct{}, timedOut *atomic.Bool, cancel context.CancelFunc) {
	defer close(done)
	for {
		at, changed := c.writeDL.snapshot()
		var timer *time.Timer
		var timerC <-chan time.Time
		if !at.IsZero() {
			timer = time.NewTimer(time.Until(at))
			timerC = timer.C
		}
		select {
		case <-stop:
			if timer != nil {
				timer.Stop()
			}
			return
		case <-c.closed:
			if timer != nil {
				timer.Stop()
			}
			return
		case <-changed:
			if timer != nil {
				timer.Stop()
			}
			continue
		case <-timerC:
			// A concurrent extension/clear must win over a stale timer.
			c.writeDL.mu.Lock()
			expired := !c.writeDL.at.IsZero() && !time.Now().Before(c.writeDL.at)
			c.writeDL.mu.Unlock()
			if !expired {
				continue
			}
			timedOut.Store(true)
			cancel()
			c.fail(fmt.Errorf("[http-xhttp-upload] write deadline: %w", os.ErrDeadlineExceeded))
			return
		}
	}
}

// reserveUpload applies backpressure before allocating/copying a body. The
// slot is held until the HTTP reply, so the queue plus in-flight requests can
// never exceed xhttpUploadWindow bodies (512 KiB per carrier).
func (c *xhttpClientConn) reserveUpload() error {
	for {
		at, changed := c.writeDL.snapshot()
		if !at.IsZero() && !time.Now().Before(at) {
			return os.ErrDeadlineExceeded
		}
		var timer *time.Timer
		var timerC <-chan time.Time
		if !at.IsZero() {
			timer = time.NewTimer(time.Until(at))
			timerC = timer.C
		}
		select {
		case c.slots <- struct{}{}:
			if timer != nil {
				timer.Stop()
			}
			return nil
		case <-c.closed:
			if timer != nil {
				timer.Stop()
			}
			return c.connectionError(net.ErrClosed)
		case <-changed:
			if timer != nil {
				timer.Stop()
			}
		case <-timerC:
			// Recheck: a concurrently extended deadline must win.
		}
	}
}

func (c *xhttpClientConn) Write(p []byte) (written int, err error) {
	c.writeMu.Lock()
	defer c.writeMu.Unlock()
	if len(p) == 0 {
		return 0, nil
	}
	select {
	case <-c.closed:
		return 0, c.connectionError(net.ErrClosed)
	default:
	}
	at, _ := c.writeDL.snapshot()
	if !at.IsZero() && !time.Now().Before(at) {
		return 0, os.ErrDeadlineExceeded
	}
	for written < len(p) {
		if err := c.reserveUpload(); err != nil {
			if written > 0 {
				c.fail(fmt.Errorf("[http-xhttp-upload] enqueue: %w", err))
			}
			return written, err
		}
		select {
		case <-c.closed:
			<-c.slots
			return written, c.connectionError(net.ErrClosed)
		default:
		}
		if c.seq == ^uint64(0) {
			<-c.slots
			err := errors.New("[http-xhttp-upload] sequence exhausted")
			c.fail(err)
			return written, err
		}
		n := len(p) - written
		if n > xhttpMaxPostBytes {
			n = xhttpMaxPostBytes
		}
		job := xhttpUpload{seq: c.seq, body: append([]byte(nil), p[written:written+n]...)}
		select {
		case c.uploads <- job:
		case <-c.closed:
			<-c.slots
			return written, c.connectionError(net.ErrClosed)
		}
		c.seq++
		written += n
	}
	return written, nil
}

func (c *xhttpClientConn) uploadLoop() {
	var workers sync.WaitGroup
	defer func() { workers.Wait(); close(c.uploadDone) }()
	for {
		select {
		case <-c.closed:
			return
		case job := <-c.uploads:
			sent := make(chan struct{})
			var sentOnce sync.Once
			markSent := func() { sentOnce.Do(func() { close(sent) }) }
			workers.Add(1)
			go func() {
				defer workers.Done()
				defer markSent()
				err := c.sendUpload(job, markSent)
				if err != nil {
					c.fail(err)
				}
				<-c.slots
				select {
				case c.uploadProgress <- struct{}{}:
				default:
				}
			}()
			// Packet-up emits bodies in sequence but does not wait for response
			// headers. HTTP tracing fires only after the complete body has been
			// written by HTTP/1 or HTTP/2. Intermediaries may still reorder them.
			select {
			case <-sent:
			case <-c.closed:
				return
			}
		}
	}
}

// FIN/Close frames need a delivery barrier before a dedicated MUX-off carrier
// can be released. Ordinary data writes retain bounded socket-like buffering.
// main's frame writer invokes this while its write deadline is still active.
func flushXHTTPUploads(conn net.Conn) error {
	if tracked, ok := conn.(*trackedNetConn); ok {
		return flushXHTTPUploads(tracked.Conn)
	}
	if c, ok := conn.(*xhttpClientConn); ok {
		return c.flushUploads()
	}
	if c, ok := conn.(*xhttpStreamClientConn); ok {
		return c.flushUploads()
	}
	return nil
}

func (c *xhttpClientConn) flushUploads() error {
	c.writeMu.Lock()
	defer c.writeMu.Unlock()
	for {
		select {
		case <-c.closed:
			return c.connectionError(net.ErrClosed)
		default:
		}
		if len(c.slots) == 0 {
			return nil
		}
		at, changed := c.writeDL.snapshot()
		if !at.IsZero() && !time.Now().Before(at) {
			err := fmt.Errorf("[http-xhttp-upload] flush deadline: %w", os.ErrDeadlineExceeded)
			c.fail(err)
			return err
		}
		var timer *time.Timer
		var timerC <-chan time.Time
		if !at.IsZero() {
			timer = time.NewTimer(time.Until(at))
			timerC = timer.C
		}
		select {
		case <-c.closed:
			if timer != nil {
				timer.Stop()
			}
			return c.connectionError(net.ErrClosed)
		case <-changed:
			if timer != nil {
				timer.Stop()
			}
		case <-c.uploadProgress:
			if timer != nil {
				timer.Stop()
			}
		case <-timerC:
		}
	}
}

func (c *xhttpClientConn) sendUpload(job xhttpUpload, markSent func()) error {
	// Even when a caller clears its Write deadline after enqueueing, a queued
	// POST must not hang forever. Independent of the adjustable net.Conn
	// deadline, each actual request retains the tunnel's bounded write timeout.
	ctx, cancel := context.WithTimeout(c.ctx, tunnelWriteDeadline())
	defer cancel()
	ctx = httptrace.WithClientTrace(ctx, &httptrace.ClientTrace{WroteRequest: func(httptrace.WroteRequestInfo) { markSent() }})
	stop, watchDone := make(chan struct{}), make(chan struct{})
	var timedOut atomic.Bool
	go c.watchUploadDeadline(stop, watchDone, &timedOut, cancel)
	defer func() { close(stop); <-watchDone }()
	path := c.path + "/" + strconv.FormatUint(job.seq, 10)
	req, err := c.request(ctx, http.MethodPost, path, job.body)
	if err != nil {
		return fmt.Errorf("[http-xhttp-upload] request: %w", err)
	}
	resp, err := c.client.RoundTrip(req)
	if err != nil {
		if timedOut.Load() {
			err = os.ErrDeadlineExceeded
		}
		return fmt.Errorf("[http-xhttp-upload] sequence %d: %w", job.seq, err)
	}
	// Never drain an intermediary's unbounded error response.
	_ = resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("[http-xhttp-upload] sequence %d rejected: HTTP %d", job.seq, resp.StatusCode)
	}
	return nil
}

func (c *xhttpClientConn) Close() error {
	c.closeOnce.Do(func() {
		close(c.closed)
		c.cancel()
		_ = c.readSide.Close()
		_ = c.pumpSide.Close()
		if c.body != nil {
			_ = c.body.Close()
		}
		if c.physical != nil {
			_ = c.physical.Close()
		}
	})
	return nil
}
func (c *xhttpClientConn) LocalAddr() net.Addr {
	if c.physical != nil {
		return c.physical.LocalAddr()
	}
	return h2Addr("xhttp-local")
}
func (c *xhttpClientConn) RemoteAddr() net.Addr {
	if c.physical != nil {
		return c.physical.RemoteAddr()
	}
	return h2Addr(c.host)
}
func (c *xhttpClientConn) SetDeadline(t time.Time) error {
	if err := c.SetReadDeadline(t); err != nil {
		return err
	}
	return c.SetWriteDeadline(t)
}
func (c *xhttpClientConn) SetReadDeadline(t time.Time) error { return c.readSide.SetReadDeadline(t) }
func (c *xhttpClientConn) SetWriteDeadline(t time.Time) error {
	select {
	case <-c.closed:
		return net.ErrClosed
	default:
	}
	c.writeDL.set(t)
	return nil
}

type xhttpServerSession struct {
	routeBase  string // immutable: binds late uploads to their established route
	app        net.Conn
	wire       net.Conn
	uploadMu   sync.Mutex
	seq        uint64
	pending    map[uint64]*xhttpPendingUpload
	changed    chan struct{}
	closed     chan struct{}
	gapTimeout time.Duration
	closeOnce  sync.Once
	mode       string
	streamPost bool
	streamAck  func(uint64) error
	streamDone chan struct{}
}

type xhttpPendingUpload struct {
	body  []byte
	ready bool
	done  chan struct{}
}

func (s *xhttpServerSession) close() {
	s.closeOnce.Do(func() { close(s.closed); _ = s.app.Close(); _ = s.wire.Close() })
}

func (s *xhttpServerSession) signalUpload() {
	select {
	case s.changed <- struct{}{}:
	default:
	}
}

// Only this goroutine writes upload bytes into the application. Reservations
// and ready bodies share the same eight-sequence window; slow/missing bodies
// cannot cause unbounded buffering or bypass sequence replay protection.
func (s *xhttpServerSession) uploadLoop() {
	var gapAt time.Time
	for {
		s.uploadMu.Lock()
		entry := s.pending[s.seq]
		if entry != nil && entry.ready {
			body := entry.body
			s.uploadMu.Unlock()
			_ = s.wire.SetWriteDeadline(time.Now().Add(tunnelWriteDeadline()))
			_, err := writeFull(s.wire, body)
			_ = s.wire.SetWriteDeadline(time.Time{})
			if err != nil {
				s.close()
				return
			}
			s.uploadMu.Lock()
			delete(s.pending, s.seq)
			s.seq++
			// Release the body before acknowledging delivery and opening a
			// slot. A delayed response itself need not retain the payload.
			entry.body = nil
			close(entry.done)
			s.uploadMu.Unlock()
			gapAt = time.Time{}
			continue
		}
		waiting := len(s.pending) > 0
		s.uploadMu.Unlock()
		var timer *time.Timer
		var timerC <-chan time.Time
		if waiting {
			if gapAt.IsZero() {
				gapAt = time.Now().Add(s.gapTimeout)
			}
			timer = time.NewTimer(time.Until(gapAt))
			timerC = timer.C
		} else {
			gapAt = time.Time{}
		}
		select {
		case <-s.closed:
			if timer != nil {
				timer.Stop()
			}
			return
		case <-s.changed:
			if timer != nil {
				timer.Stop()
			}
		case <-timerC:
			// Missing sequence/body: acknowledgements cannot advance past a
			// gap. Closing both halves also unblocks every waiting POST.
			s.close()
			return
		}
	}
}

type xhttpServer struct {
	cfg        *Config
	accept     func(net.Conn, string)
	mu         sync.Mutex
	sessions   map[string]*xhttpServerSession
	closed     bool
	draining   bool
	gapTimeout time.Duration
}

func newXHTTPServer(cfg *Config, accept func(net.Conn, string)) *xhttpServer {
	return &xhttpServer{cfg: cfg, accept: accept, sessions: make(map[string]*xhttpServerSession), gapTimeout: authTimeout}
}

func (s *xhttpServer) Close() {
	s.mu.Lock()
	s.closed = true
	for _, session := range s.sessions {
		session.close()
	}
	s.mu.Unlock()
}

func (s *xhttpServer) beginDrain() {
	s.mu.Lock()
	s.draining = true
	s.mu.Unlock()
}

func (s *xhttpServer) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	base := xhttpRequestBase(s.cfg, r.URL.Path)
	if !s.acceptsRequestBase(r, base) || r.URL.RawQuery != "" || r.URL.RawPath != "" || canonicalHost(r.Host) != canonicalHost(s.cfg.WSHost) {
		http.NotFound(w, r)
		return
	}
	mode, modeErr := requestedXHTTPMode(r)
	if modeErr != nil || !acceptsXHTTPMode(s.cfg.XHTTPMode, mode) {
		rejectXHTTPStreaming(w, r)
		return
	}
	if mode != "packet-up" {
		s.serveStreaming(w, r, base, mode)
		return
	}
	parts := strings.Split(strings.TrimPrefix(r.URL.Path, base), "/")
	if len(parts) < 1 || len(parts) > 2 || !validXHTTPID(parts[0]) ||
		(len(parts) == 1 && r.Method != http.MethodGet) || (len(parts) == 2 && r.Method != http.MethodPost) {
		http.NotFound(w, r)
		return
	}
	now := time.Now()
	nonce, valid := validWebSocketAuthorization(r.Header.Get("Authorization"), s.cfg.Token, s.cfg.WSHost, r.URL.Path, now)
	if !valid {
		http.NotFound(w, r)
		return
	}
	if err := s.applyPadding(w, r); err != nil {
		http.NotFound(w, r)
		return
	}
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "GET, POST")
	if len(parts) == 1 {
		if r.ContentLength != 0 || !transportNonces.admit(nonce, now) {
			http.NotFound(w, r)
			return
		}
		s.download(w, r, parts[0])
		return
	}
	// POST replay protection is the monotonically delivered per-session sequence
	// plus unique reservations in its bounded out-of-order window,
	// not the global handshake nonce cache. Caching every upload nonce would
	// exhaust that cache during legitimate high-throughput use.
	seq, err := strconv.ParseUint(parts[1], 10, 64)
	if err != nil || strconv.FormatUint(seq, 10) != parts[1] {
		http.NotFound(w, r)
		return
	}
	s.upload(w, r, parts[0], seq)
}

func (s *xhttpServer) download(w http.ResponseWriter, r *http.Request, id string) {
	s.mu.Lock()
	if s.closed || s.draining || len(s.sessions) >= MaxSessions {
		s.mu.Unlock()
		http.Error(w, "XHTTP capacity reached", http.StatusServiceUnavailable)
		return
	}
	if _, exists := s.sessions[id]; exists {
		s.mu.Unlock()
		http.Error(w, "XHTTP duplicate download", http.StatusConflict)
		return
	}
	app, wire := net.Pipe()
	session := &xhttpServerSession{app: app, wire: wire, routeBase: xhttpRequestBase(s.cfg, r.URL.Path), mode: "packet-up", pending: make(map[uint64]*xhttpPendingUpload),
		changed: make(chan struct{}, 1), closed: make(chan struct{}), gapTimeout: s.gapTimeout}
	s.sessions[id] = session
	s.mu.Unlock()
	defer func() {
		session.close()
		s.mu.Lock()
		delete(s.sessions, id)
		s.mu.Unlock()
	}()
	controller := http.NewResponseController(w)
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("X-Accel-Buffering", "no")
	w.WriteHeader(http.StatusOK)
	_ = controller.SetWriteDeadline(time.Now().Add(tunnelWriteDeadline()))
	if err := controller.Flush(); err != nil {
		return
	}
	_ = controller.SetWriteDeadline(time.Time{})
	stop := context.AfterFunc(r.Context(), session.close)
	defer stop()
	ip, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		ip = r.RemoteAddr
	}
	if parsed := net.ParseIP(ip); parsed != nil && parsed.IsLoopback() {
		if forwarded := net.ParseIP(strings.TrimSpace(r.Header.Get("X-Real-IP"))); forwarded != nil {
			ip = forwarded.String()
		}
	}
	go func() { defer session.close(); s.accept(app, ip) }()
	go session.uploadLoop()
	buf := make([]byte, xhttpCopyBuffer)
	for {
		n, err := wire.Read(buf)
		if n > 0 {
			_ = controller.SetWriteDeadline(time.Now().Add(tunnelWriteDeadline()))
			if _, writeErr := w.Write(buf[:n]); writeErr != nil {
				return
			}
			if flushErr := controller.Flush(); flushErr != nil {
				return
			}
			_ = controller.SetWriteDeadline(time.Time{})
		}
		if err != nil {
			return
		}
	}
}

func (s *xhttpServer) upload(w http.ResponseWriter, r *http.Request, id string, seq uint64) {
	s.mu.Lock()
	session := s.sessions[id]
	s.mu.Unlock()
	if session == nil || session.mode != "packet-up" || (s.cfg.PathRotation > 0 && session.routeBase != xhttpRequestBase(s.cfg, r.URL.Path)) {
		http.Error(w, "XHTTP download session missing", http.StatusGone)
		return
	}
	if r.ContentLength > xhttpMaxPostBytes {
		http.Error(w, "XHTTP upload too large", http.StatusRequestEntityTooLarge)
		return
	}
	session.uploadMu.Lock()
	// Subtract only after the lower-bound check to avoid uint64 wraparound.
	if seq < session.seq || seq-session.seq >= xhttpUploadWindow || session.pending[seq] != nil {
		session.uploadMu.Unlock()
		http.Error(w, "XHTTP replayed upload or sequence outside receive window", http.StatusConflict)
		return
	}
	entry := &xhttpPendingUpload{done: make(chan struct{})}
	session.pending[seq] = entry
	session.uploadMu.Unlock()
	session.signalUpload()
	queued := false
	defer func() {
		if !queued {
			session.uploadMu.Lock()
			delete(session.pending, seq)
			session.uploadMu.Unlock()
			session.signalUpload()
		}
	}()
	controller := http.NewResponseController(w)
	_ = controller.SetReadDeadline(time.Now().Add(authTimeout))
	body, err := io.ReadAll(http.MaxBytesReader(w, r.Body, xhttpMaxPostBytes))
	if err != nil {
		var sizeErr *http.MaxBytesError
		if errors.As(err, &sizeErr) {
			http.Error(w, "XHTTP upload too large", http.StatusRequestEntityTooLarge)
		} else {
			http.Error(w, "XHTTP upload body failed", http.StatusBadRequest)
		}
		return
	}
	// Clear only after consuming the complete bounded body. On malformed or
	// timed-out input net/http may drain unread body bytes while finishing its
	// error response; clearing here on that error path permits a slow-body DoS.
	_ = controller.SetReadDeadline(time.Time{})
	if len(body) == 0 {
		http.Error(w, "XHTTP empty upload", http.StatusBadRequest)
		return
	}
	stop := context.AfterFunc(r.Context(), session.close)
	defer stop()
	session.uploadMu.Lock()
	entry.body, entry.ready = body, true
	queued = true
	session.uploadMu.Unlock()
	session.signalUpload()
	select {
	case <-entry.done:
		w.Header().Set("Content-Length", "0")
		w.WriteHeader(http.StatusOK)
	case <-r.Context().Done():
		session.close()
	case <-session.closed:
		http.Error(w, "XHTTP upstream session closed or stalled", http.StatusBadGateway)
	}
}

func newXHTTPHTTPServer(handler http.Handler) *http.Server {
	return &http.Server{
		Handler: handler, ReadHeaderTimeout: 5 * time.Second,
		// Also bound body draining for rejected/unauthenticated requests which
		// never reach upload(). A bodyless GET's background read clears this
		// deadline in net/http, so legitimate long downloads remain supported.
		ReadTimeout: authTimeout,
		IdleTimeout: 30 * time.Second, MaxHeaderBytes: 8192,
	}
}

func runXHTTPEgress(cfg *Config, done chan struct{}) error {
	if err := validateXHTTPPath(cfg.XHTTPPath); err != nil {
		return err
	}
	if _, err := normalizeXHTTPMode(cfg.XHTTPMode); err != nil {
		return err
	}
	if _, err := parseXHTTPPadding(cfg.XHTTPPaddingBytes); err != nil {
		return err
	}
	listener, err := net.Listen("tcp", cfg.Listen)
	if err != nil {
		return fmt.Errorf("XHTTP backend listen %s: %w", cfg.Listen, err)
	}
	limiter := NewAdaptiveRateLimiter(10, 5)
	handler := newXHTTPServer(cfg, func(c net.Conn, ip string) { dispatchEgressConn(c, ip, cfg, limiter) })
	server := newXHTTPHTTPServer(handler)
	stopped := make(chan struct{})
	go limiter.monitor(stopped)
	go func() {
		ticker := time.NewTicker(time.Minute)
		defer ticker.Stop()
		for {
			select {
			case <-done:
				// A packet-up carrier needs NEW POST requests even while an
				// existing TCP stream drains. Shutdown/closing the listener here
				// would break those uploads. Refuse new GET carriers, preserve
				// existing UUIDs, and use the same bounded drain as main().
				handler.beginDrain()
				deadline := time.NewTimer(drainTimeout)
				poll := time.NewTicker(25 * time.Millisecond)
				draining := true
				for draining && reg.liveStreams() != 0 {
					select {
					case <-deadline.C:
						draining = false
					case <-poll.C:
					case <-stopped:
						deadline.Stop()
						poll.Stop()
						return
					}
				}
				deadline.Stop()
				poll.Stop()
				handler.Close()
				_ = server.Close()
				return
			case <-stopped:
				return
			case <-ticker.C:
				limiter.cleanup()
				if cfg.allowList != nil {
					cfg.allowList.CleanupDNS()
				}
			}
		}
	}()
	log.Printf("[egress] XHTTP mode=%s HTTP backend listening on %s, path=%s (TLS terminates at reverse proxy)", cfg.XHTTPMode, cfg.Listen, cfg.XHTTPPath)
	err = server.Serve(netutil.LimitListener(listener, xhttpMaxHTTPConns))
	close(stopped)
	handler.Close()
	if errors.Is(err, http.ErrServerClosed) {
		return nil
	}
	return err
}
