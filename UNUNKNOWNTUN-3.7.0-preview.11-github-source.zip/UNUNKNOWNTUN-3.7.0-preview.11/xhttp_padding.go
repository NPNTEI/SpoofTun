package main

import (
	"crypto/rand"
	"errors"
	"fmt"
	"math/big"
	"net/http"
	"net/url"
	"strconv"
	"strings"
)

const xhttpMaxPaddingBytes = 4096

// XHTTPOptions concern the HTTP carrier, not UNUNKNOWNTUN frame padding or MUX.
type XHTTPOptions struct {
	Mode         string
	PaddingBytes string
}

type xhttpPaddingRange struct{ min, max int }

func normalizeXHTTPMode(mode string) (string, error) {
	mode = strings.ToLower(strings.TrimSpace(mode))
	if mode == "" {
		mode = "packet-up"
	}
	switch mode {
	case "auto", "packet-up", "stream-up", "stream-one":
		return mode, nil
	default:
		return "", errors.New("XHTTP mode must be auto, packet-up, stream-up, or stream-one")
	}
}

func normalizeXHTTPOptions(options []XHTTPOptions) (XHTTPOptions, error) {
	if len(options) > 1 {
		return XHTTPOptions{}, errors.New("only one XHTTP options object is allowed")
	}
	option := XHTTPOptions{}
	if len(options) == 1 {
		option = options[0]
	}
	var err error
	option.Mode, err = normalizeXHTTPMode(option.Mode)
	if err != nil {
		return option, err
	}
	// Streaming upload support cannot be assumed at a CDN, especially without
	// gRPC headers. Auto is deliberately the conservative GDT packet-up profile.
	if option.Mode == "auto" {
		option.Mode = "packet-up"
	}
	_, err = parseXHTTPPadding(option.PaddingBytes)
	return option, err
}

func parseXHTTPPadding(value string) (xhttpPaddingRange, error) {
	value = strings.TrimSpace(value)
	if value == "" {
		value = "0"
	}
	parts := strings.Split(value, "-")
	if len(parts) < 1 || len(parts) > 2 {
		return xhttpPaddingRange{}, errors.New("XHTTP padding must be bytes or min-max bytes, within 0-4096")
	}
	values := make([]int, len(parts))
	for i, part := range parts {
		value, err := strconv.Atoi(part)
		if err != nil || strconv.Itoa(value) != part || value < 0 || value > xhttpMaxPaddingBytes {
			return xhttpPaddingRange{}, errors.New("XHTTP padding must be bytes or min-max bytes, within 0-4096")
		}
		values[i] = value
	}
	rangeValue := xhttpPaddingRange{values[0], values[len(values)-1]}
	if rangeValue.min > rangeValue.max {
		return xhttpPaddingRange{}, errors.New("XHTTP padding minimum exceeds maximum")
	}
	return rangeValue, nil
}

func (p xhttpPaddingRange) generate() (string, error) {
	size := p.min
	if p.max > p.min {
		n, err := rand.Int(rand.Reader, big.NewInt(int64(p.max-p.min+1)))
		if err != nil {
			return "", fmt.Errorf("XHTTP header padding random source: %w", err)
		}
		size += int(n.Int64())
	}
	return strings.Repeat("X", size), nil
}

func setXHTTPRequestPadding(r *http.Request, padding xhttpPaddingRange) error {
	value, err := padding.generate()
	if err != nil {
		return err
	}
	if len(value) != 0 {
		r.Header.Set("Referer", "https://"+r.Host+"/?x_padding="+value)
	}
	return nil
}

func (s *xhttpServer) applyPadding(w http.ResponseWriter, r *http.Request) error {
	padding, err := parseXHTTPPadding(s.cfg.XHTTPPaddingBytes)
	if err != nil {
		return err
	}
	value := ""
	if ref := r.Header.Get("Referer"); ref != "" {
		parsed, err := url.Parse(ref)
		if err != nil || parsed.Scheme != "https" || canonicalHost(parsed.Host) != canonicalHost(r.Host) {
			return errors.New("invalid XHTTP padding referer")
		}
		query, err := url.ParseQuery(parsed.RawQuery)
		if err != nil || len(query["x_padding"]) != 1 {
			return errors.New("invalid XHTTP padding query")
		}
		value = query.Get("x_padding")
	}
	if len(value) > xhttpMaxPaddingBytes || strings.Trim(value, "X") != "" {
		return errors.New("invalid XHTTP padding bytes")
	}
	// Padding is cosmetic, not authentication. Each peer's configured range
	// controls only its own outgoing headers, and old unpadded peers remain valid.
	responsePadding, err := padding.generate()
	if err != nil {
		return err
	}
	if responsePadding != "" {
		w.Header().Set("X-Padding", responsePadding)
	}
	return nil
}
