package main

// Streaming profiles use ordinary HTTP request/response bodies (no gRPC).
// Their bounded response records carry payload and upload-delivery ACKs. This
// UNUNKNOWNTUN extension prevents final-frame loss when a MUX-off carrier closes;
// it is deliberately NOT stock Xray/VLESS wire compatibility.

import (
	"context"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

const xhttpModeHeader = "X-Ununknowntun-Xhttp-Mode"
const xhttpStreamProfile = "gdt-stream-ack-v1"
const xhttpStreamProfileHeader = "X-Ununknowntun-Xhttp-Profile"

func rejectXHTTPStreaming(w http.ResponseWriter, r *http.Request) {
	// A rejected, never-ending upload must not be drained before a generic
	// response is sent. Closing this HTTP/1 connection reveals no auth details.
	if r.ProtoMajor == 1 && r.Method == http.MethodPost {
		w.Header().Set("Connection", "close")
	}
	http.NotFound(w, r)
}

func requestedXHTTPMode(r *http.Request) (string, error) {
	mode := r.Header.Get(xhttpModeHeader)
	if mode == "" {
		return "packet-up", nil
	}
	if mode != "stream-up" && mode != "stream-one" && mode != "packet-up" {
		return "", errors.New("unknown XHTTP request mode")
	}
	if mode != "packet-up" && r.Header.Get(xhttpStreamProfileHeader) != xhttpStreamProfile {
		return "", errors.New("unsupported XHTTP streaming profile")
	}
	return mode, nil
}

func acceptsXHTTPMode(configured, requested string) bool {
	mode, err := normalizeXHTTPMode(configured)
	return err == nil && (mode == "auto" || mode == requested)
}

type xhttpStreamClientConn struct {
	readSide, pumpSide       net.Conn
	uploadSide, uploadReader net.Conn
	physical                 net.Conn
	body, uploadResponse     io.ReadCloser
	ctx                      context.Context
	cancel                   context.CancelFunc
	host                     string
	closed                   chan struct{}
	closeOnce                sync.Once
	writeMu                  sync.Mutex
	writeDL                  streamDeadline
	sent                     uint64
	submitted                atomic.Uint64
	acked                    atomic.Uint64
	progress                 chan struct{}
	errMu                    sync.Mutex
	failure                  error
}

func xhttpStreamRequest(ctx context.Context, method, host, path, token, mode string, body io.ReadCloser, padding xhttpPaddingRange) (*http.Request, error) {
	r, err := http.NewRequestWithContext(ctx, method, "https://"+host+path, body)
	if err != nil {
		return nil, err
	}
	auth, err := makeWebSocketAuthorization(token, host, path, time.Now())
	if err != nil {
		return nil, err
	}
	r.Host = host
	r.Header.Set("Authorization", auth)
	r.Header.Set("Cache-Control", "no-store")
	r.Header.Set(xhttpModeHeader, mode)
	r.Header.Set(xhttpStreamProfileHeader, xhttpStreamProfile)
	r.Header["User-Agent"] = nil
	if method == http.MethodPost {
		r.ContentLength = -1
		r.Header.Set("Content-Type", "application/octet-stream")
	}
	if err := setXHTTPRequestPadding(r, padding); err != nil {
		return nil, err
	}
	return r, nil
}

func (c *xhttpStreamClientConn) roundTripHeaders(client http.RoundTripper, r *http.Request) (*http.Response, error) {
	timeoutDone := make(chan struct{})
	timer := time.AfterFunc(authTimeout, func() {
		c.cancel()
		// net/http's request writer can be blocked inside Body.Read before
		// RoundTrip returns. Cancel the bounded pipe as well as the HTTP context.
		_ = c.uploadReader.Close()
		_ = c.uploadSide.Close()
		close(timeoutDone)
	})
	response, err := client.RoundTrip(r)
	if !timer.Stop() {
		<-timeoutDone
		if response != nil {
			_ = response.Body.Close()
		}
		return nil, fmt.Errorf("[http-xhttp-stream] response headers timeout: %w", context.DeadlineExceeded)
	}
	if err != nil {
		return nil, fmt.Errorf("[http-xhttp-stream] request/response: %w", err)
	}
	if response.StatusCode != http.StatusOK || response.Header.Get(xhttpStreamProfileHeader) != xhttpStreamProfile {
		c.cancel()
		_ = c.uploadReader.Close()
		_ = c.uploadSide.Close()
		_ = response.Body.Close()
		return nil, fmt.Errorf("[http-xhttp-stream] HTTP %d or unsupported streaming profile; check mode on both peers and intermediary streaming support", response.StatusCode)
	}
	return response, nil
}

func newXHTTPStreamClientConn(raw net.Conn, client http.RoundTripper, host, path, token string, option XHTTPOptions) (_ *xhttpStreamClientConn, resultErr error) {
	option, err := normalizeXHTTPOptions([]XHTTPOptions{option})
	if err != nil {
		return nil, err
	}
	if option.Mode != "stream-up" && option.Mode != "stream-one" {
		return nil, errors.New("streaming constructor requires stream-up or stream-one")
	}
	if err := validateXHTTPPath(path); err != nil {
		return nil, err
	}
	padding, _ := parseXHTTPPadding(option.PaddingBytes)
	ctx, cancel := context.WithCancel(context.Background())
	readSide, pumpSide := net.Pipe()
	uploadSide, uploadReader := net.Pipe()
	c := &xhttpStreamClientConn{readSide: readSide, pumpSide: pumpSide, uploadSide: uploadSide, uploadReader: uploadReader,
		physical: raw, ctx: ctx, cancel: cancel, host: host, closed: make(chan struct{}), writeDL: newStreamDeadline(), progress: make(chan struct{}, 1)}
	defer func() {
		if resultErr != nil {
			_ = c.Close()
		}
	}()
	path = strings.TrimSuffix(path, "/") + "/"
	if option.Mode == "stream-up" {
		id, err := newXHTTPID()
		if err != nil {
			return nil, err
		}
		path += id
		request, err := xhttpStreamRequest(ctx, http.MethodGet, host, path, token, option.Mode, nil, padding)
		if err != nil {
			return nil, err
		}
		response, err := c.roundTripHeaders(client, request)
		if err != nil {
			return nil, err
		}
		c.body = response.Body
	}
	request, err := xhttpStreamRequest(ctx, http.MethodPost, host, path, token, option.Mode, uploadReader, padding)
	if err != nil {
		return nil, err
	}
	response, err := c.roundTripHeaders(client, request)
	if err != nil {
		return nil, err
	}
	if option.Mode == "stream-one" {
		c.body = response.Body
	} else {
		c.uploadResponse = response.Body
	}
	if raw != nil {
		if err := raw.SetDeadline(time.Time{}); err != nil {
			return nil, err
		}
	}
	go c.receive()
	if c.uploadResponse != nil {
		go func() {
			// The upload response has no payload. Drain with bounded memory to
			// detect an intermediary closing or rejecting a long upload early.
			_, err := io.CopyBuffer(io.Discard, c.uploadResponse, make([]byte, 1024))
			if err != nil {
				c.fail(fmt.Errorf("[http-xhttp-stream-upload] response ended: %w", err))
			}
			// A normal upload EOF can race the last ACK on the independent GET.
			// Let that ordered download drain instead of cancelling it here.
		}()
	}
	return c, nil
}

func (c *xhttpStreamClientConn) receive() {
	buf := make([]byte, xhttpCopyBuffer)
	var header [5]byte
	for {
		if _, err := io.ReadFull(c.body, header[:]); err != nil {
			c.fail(fmt.Errorf("[http-xhttp-stream-download] record header: %w", err))
			return
		}
		n := binary.BigEndian.Uint32(header[1:])
		if (header[0] == 1 && n > 0 && n <= xhttpCopyBuffer) || (header[0] == 2 && n == 8) {
			if _, err := io.ReadFull(c.body, buf[:n]); err != nil {
				c.fail(fmt.Errorf("[http-xhttp-stream-download] record body: %w", err))
				return
			}
		} else {
			c.fail(errors.New("[http-xhttp-stream-download] malformed or oversized record"))
			return
		}
		if header[0] == 1 {
			if _, err := writeFull(c.pumpSide, buf[:n]); err != nil {
				c.fail(err)
				return
			}
		} else {
			ack := binary.BigEndian.Uint64(buf[:8])
			if ack < c.acked.Load() || ack > c.submitted.Load() {
				c.fail(errors.New("[http-xhttp-stream-upload] invalid delivery acknowledgement"))
				return
			}
			c.acked.Store(ack)
			select {
			case c.progress <- struct{}{}:
			default:
			}
		}
	}
}

func (c *xhttpStreamClientConn) connectionError(err error) error {
	c.errMu.Lock()
	defer c.errMu.Unlock()
	if c.failure != nil {
		return c.failure
	}
	return err
}
func (c *xhttpStreamClientConn) fail(err error) {
	c.errMu.Lock()
	if c.failure == nil {
		c.failure = err
	}
	c.errMu.Unlock()
	_ = c.Close()
}
func (c *xhttpStreamClientConn) Read(p []byte) (int, error) {
	n, err := c.readSide.Read(p)
	if err != nil {
		err = c.connectionError(err)
	}
	return n, err
}
func (c *xhttpStreamClientConn) Write(p []byte) (int, error) {
	c.writeMu.Lock()
	defer c.writeMu.Unlock()
	if uint64(len(p)) > ^uint64(0)-c.sent {
		return 0, errors.New("XHTTP upload byte counter exhausted")
	}
	c.submitted.Store(c.sent + uint64(len(p)))
	n, err := c.uploadSide.Write(p)
	c.sent += uint64(n)
	if err != nil {
		c.fail(fmt.Errorf("[http-xhttp-stream-upload] write: %w", err))
		return n, c.connectionError(err)
	}
	return n, nil
}
func (c *xhttpStreamClientConn) flushUploads() error {
	c.writeMu.Lock()
	defer c.writeMu.Unlock()
	for c.acked.Load() < c.sent {
		at, changed := c.writeDL.snapshot()
		if !at.IsZero() && !time.Now().Before(at) {
			err := fmt.Errorf("[http-xhttp-stream-upload] delivery deadline: %w", os.ErrDeadlineExceeded)
			c.fail(err)
			return err
		}
		var timer *time.Timer
		var timerC <-chan time.Time
		if !at.IsZero() {
			timer = time.NewTimer(time.Until(at))
			timerC = timer.C
		}
		select {
		case <-c.closed:
			if timer != nil {
				timer.Stop()
			}
			if c.acked.Load() >= c.sent {
				return nil
			}
			return c.connectionError(net.ErrClosed)
		case <-changed:
		case <-c.progress:
		case <-timerC:
		}
		if timer != nil {
			timer.Stop()
		}
	}
	return nil
}
func (c *xhttpStreamClientConn) Close() error {
	c.closeOnce.Do(func() {
		close(c.closed)
		c.cancel()
		_ = c.readSide.Close()
		_ = c.pumpSide.Close()
		_ = c.uploadSide.Close()
		_ = c.uploadReader.Close()
		if c.body != nil {
			_ = c.body.Close()
		}
		if c.uploadResponse != nil {
			_ = c.uploadResponse.Close()
		}
		if c.physical != nil {
			_ = c.physical.Close()
		}
	})
	return nil
}
func (c *xhttpStreamClientConn) LocalAddr() net.Addr {
	if c.physical != nil {
		return c.physical.LocalAddr()
	}
	return h2Addr("xhttp-local")
}
func (c *xhttpStreamClientConn) RemoteAddr() net.Addr {
	if c.physical != nil {
		return c.physical.RemoteAddr()
	}
	return h2Addr(c.host)
}
func (c *xhttpStreamClientConn) SetDeadline(t time.Time) error {
	if err := c.SetReadDeadline(t); err != nil {
		return err
	}
	return c.SetWriteDeadline(t)
}
func (c *xhttpStreamClientConn) SetReadDeadline(t time.Time) error {
	return c.readSide.SetReadDeadline(t)
}
func (c *xhttpStreamClientConn) SetWriteDeadline(t time.Time) error {
	c.writeDL.set(t)
	return c.uploadSide.SetWriteDeadline(t)
}

func (s *xhttpServer) serveStreaming(w http.ResponseWriter, r *http.Request, base, mode string) {
	rest := strings.TrimPrefix(r.URL.Path, base)
	if (mode == "stream-one" && (rest != "" || r.Method != http.MethodPost)) ||
		(mode == "stream-up" && (!validXHTTPID(rest) || (r.Method != http.MethodGet && r.Method != http.MethodPost))) {
		rejectXHTTPStreaming(w, r)
		return
	}
	now := time.Now()
	nonce, valid := validWebSocketAuthorization(r.Header.Get("Authorization"), s.cfg.Token, s.cfg.WSHost, r.URL.Path, now)
	if !valid || !transportNonces.admit(nonce, now) || s.applyPadding(w, r) != nil {
		rejectXHTTPStreaming(w, r)
		return
	}
	if r.Method == http.MethodGet && r.ContentLength != 0 {
		http.NotFound(w, r)
		return
	}
	if mode == "stream-up" && r.Method == http.MethodPost {
		s.streamUpload(w, r, rest)
		return
	}
	if mode == "stream-one" {
		// No UUID is present in stream-one's public path. Allocate a private
		// session ID so simultaneous connections remain independently scoped.
		var err error
		rest, err = newXHTTPID()
		if err != nil {
			http.Error(w, "XHTTP session allocation failed", http.StatusServiceUnavailable)
			return
		}
	}
	s.streamDownload(w, r, rest, mode)
}

type xhttpRecordWriter struct {
	mu         sync.Mutex
	w          http.ResponseWriter
	controller *http.ResponseController
}

func (w *xhttpRecordWriter) record(kind byte, body []byte) error {
	w.mu.Lock()
	defer w.mu.Unlock()
	var header [5]byte
	header[0] = kind
	binary.BigEndian.PutUint32(header[1:], uint32(len(body)))
	_ = w.controller.SetWriteDeadline(time.Now().Add(tunnelWriteDeadline()))
	defer w.controller.SetWriteDeadline(time.Time{})
	if _, err := writeFull(w.w, header[:]); err != nil {
		return err
	}
	if _, err := writeFull(w.w, body); err != nil {
		return err
	}
	return w.controller.Flush()
}

func streamingHeaders(w http.ResponseWriter) {
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "GET, POST")
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("X-Accel-Buffering", "no")
	w.Header().Set(xhttpStreamProfileHeader, xhttpStreamProfile)
}

func prepareStreamingResponse(w http.ResponseWriter, r *http.Request) (*http.ResponseController, error) {
	controller := http.NewResponseController(w)
	if r.ProtoMajor == 1 {
		if err := controller.EnableFullDuplex(); err != nil {
			return nil, err
		}
	}
	// ReadTimeout protected headers and unauthenticated/rejected bodies. The
	// authenticated continuous upload now uses cancellation and GDT deadlines.
	_ = controller.SetReadDeadline(time.Time{})
	streamingHeaders(w)
	w.WriteHeader(http.StatusOK)
	_ = controller.SetWriteDeadline(time.Now().Add(tunnelWriteDeadline()))
	if err := controller.Flush(); err != nil {
		return nil, err
	}
	_ = controller.SetWriteDeadline(time.Time{})
	return controller, nil
}

func (s *xhttpServer) streamDownload(w http.ResponseWriter, r *http.Request, id, mode string) {
	s.mu.Lock()
	if s.closed || s.draining || len(s.sessions) >= MaxSessions {
		s.mu.Unlock()
		http.Error(w, "XHTTP capacity reached", http.StatusServiceUnavailable)
		return
	}
	if s.sessions[id] != nil {
		s.mu.Unlock()
		http.Error(w, "XHTTP duplicate download", http.StatusConflict)
		return
	}
	app, wire := net.Pipe()
	session := &xhttpServerSession{app: app, wire: wire, routeBase: xhttpRequestBase(s.cfg, r.URL.Path), mode: mode, closed: make(chan struct{}), streamDone: make(chan struct{})}
	controller := http.NewResponseController(w)
	writer := &xhttpRecordWriter{w: w, controller: controller}
	session.streamAck = func(n uint64) error {
		var body [8]byte
		binary.BigEndian.PutUint64(body[:], n)
		return writer.record(2, body[:])
	}
	s.sessions[id] = session
	s.mu.Unlock()
	var uploadDone chan struct{}
	defer func() {
		session.close()
		if uploadDone != nil {
			if r.ProtoMajor == 1 {
				_ = controller.SetReadDeadline(time.Now())
			}
			_ = r.Body.Close()
			<-uploadDone
		}
		session.uploadMu.Lock()
		postStarted := session.streamPost
		session.uploadMu.Unlock()
		if postStarted {
			<-session.streamDone
		}
		s.mu.Lock()
		delete(s.sessions, id)
		s.mu.Unlock()
	}()
	_, err := prepareStreamingResponse(w, r)
	if err != nil {
		return
	}
	stop := context.AfterFunc(r.Context(), session.close)
	defer stop()
	ip, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		ip = r.RemoteAddr
	}
	if parsed := net.ParseIP(ip); parsed != nil && parsed.IsLoopback() {
		if forwarded := net.ParseIP(strings.TrimSpace(r.Header.Get("X-Real-IP"))); forwarded != nil {
			ip = forwarded.String()
		}
	}
	go func() { defer session.close(); s.accept(app, ip) }()
	if mode == "stream-one" {
		uploadDone = make(chan struct{})
		go func() { defer close(uploadDone); defer session.close(); copyXHTTPStreamingUpload(session, r.Body) }()
	}
	buf := make([]byte, xhttpCopyBuffer)
	for {
		n, err := wire.Read(buf)
		if n > 0 {
			if writeErr := writer.record(1, buf[:n]); writeErr != nil {
				return
			}
		}
		if err != nil {
			return
		}
	}
}

func copyXHTTPStreamingUpload(session *xhttpServerSession, body io.Reader) {
	buf := make([]byte, xhttpCopyBuffer)
	var delivered uint64
	for {
		n, err := body.Read(buf)
		if n > 0 {
			_ = session.wire.SetWriteDeadline(time.Now().Add(tunnelWriteDeadline()))
			_, writeErr := writeFull(session.wire, buf[:n])
			_ = session.wire.SetWriteDeadline(time.Time{})
			if writeErr != nil {
				return
			}
			delivered += uint64(n)
			session.uploadMu.Lock()
			ack := session.streamAck
			session.uploadMu.Unlock()
			if ack == nil || ack(delivered) != nil {
				return
			}
		}
		if err != nil {
			return
		}
	}
}

func (s *xhttpServer) streamUpload(w http.ResponseWriter, r *http.Request, id string) {
	s.mu.Lock()
	session := s.sessions[id]
	s.mu.Unlock()
	if session == nil || session.mode != "stream-up" || (s.cfg.PathRotation > 0 && session.routeBase != xhttpRequestBase(s.cfg, r.URL.Path)) {
		http.Error(w, "XHTTP streaming download session missing", http.StatusGone)
		return
	}
	session.uploadMu.Lock()
	select {
	case <-session.closed:
		session.uploadMu.Unlock()
		http.Error(w, "XHTTP streaming session closed", http.StatusGone)
		return
	default:
	}
	if session.streamPost || session.streamAck == nil {
		session.uploadMu.Unlock()
		http.Error(w, "XHTTP duplicate or unready streaming upload", http.StatusConflict)
		return
	}
	session.streamPost = true
	session.uploadMu.Unlock()
	defer close(session.streamDone)
	defer session.close()
	controller, err := prepareStreamingResponse(w, r)
	if err != nil {
		return
	}
	stop := context.AfterFunc(r.Context(), session.close)
	defer stop()
	// Closing a session must also unblock a peer that stopped sending a body.
	stopped := make(chan struct{})
	watchDone := make(chan struct{})
	go func() {
		defer close(watchDone)
		select {
		case <-session.closed:
			if r.ProtoMajor == 1 {
				_ = controller.SetReadDeadline(time.Now())
			}
			_ = r.Body.Close()
		case <-stopped:
		}
	}()
	defer func() { close(stopped); <-watchDone }()
	copyXHTTPStreamingUpload(session, r.Body)
}
