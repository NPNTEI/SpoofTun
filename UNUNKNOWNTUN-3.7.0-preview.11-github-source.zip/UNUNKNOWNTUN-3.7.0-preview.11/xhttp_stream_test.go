package main

import (
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/tls"
	"encoding/hex"
	"errors"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	utls "github.com/refraction-networking/utls"
	"golang.org/x/net/http2"
)

func TestXHTTPModeAndPaddingValidation(t *testing.T) {
	for _, mode := range []string{"", "auto", "packet-up", "stream-up", "stream-one"} {
		if _, err := normalizeXHTTPMode(mode); err != nil {
			t.Fatal(err)
		}
	}
	if _, err := normalizeXHTTPMode("fast-auto"); err == nil {
		t.Fatal("accepted unknown mode")
	}
	for _, value := range []string{"", "0", "100", "100-1000", "0-4096", "4096"} {
		if _, err := parseXHTTPPadding(value); err != nil {
			t.Fatalf("%q: %v", value, err)
		}
	}
	for _, value := range []string{"-1", "4097", "100-1", "1-2-3", "01", "+1", "1.5", "1ms", "1\r\nX: y"} {
		if _, err := parseXHTTPPadding(value); err == nil {
			t.Fatalf("accepted %q", value)
		}
	}
	option, err := normalizeXHTTPOptions([]XHTTPOptions{{Mode: "auto"}})
	if err != nil || option.Mode != "packet-up" {
		t.Fatalf("auto is not conservative: %+v %v", option, err)
	}
}

func TestXHTTPAllModesPaddingRoundTrip(t *testing.T) {
	for _, mode := range []string{"auto", "packet-up", "stream-up", "stream-one"} {
		t.Run(mode, func(t *testing.T) {
			cfg := &Config{Token: "xhttp-all-modes-padding-token", WSHost: "modes.example.com", XHTTPPath: "/all-modes", XHTTPMode: "auto", XHTTPPaddingBytes: "100-200"}
			handler := newXHTTPServer(cfg, func(c net.Conn, _ string) { _, _ = io.Copy(c, c) })
			defer handler.Close()
			var mu sync.Mutex
			var methods, paths []string
			rt, _ := xhttpTestHTTP(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				if strings.Contains(r.Header.Get("Content-Type"), "grpc") || r.Header.Get("Referer") == "" {
					t.Error("missing padding or unexpected gRPC header")
				}
				mu.Lock()
				methods = append(methods, r.Method)
				paths = append(paths, r.URL.Path)
				mu.Unlock()
				handler.ServeHTTP(w, r)
			}), 100*time.Millisecond)
			option := XHTTPOptions{Mode: mode, PaddingBytes: "100-200"}
			var conn net.Conn
			var err error
			if mode == "auto" || mode == "packet-up" {
				conn, err = newXHTTPClientConn(nil, rt, cfg.WSHost, cfg.XHTTPPath, cfg.Token, option)
			} else {
				conn, err = newXHTTPStreamClientConn(nil, rt, cfg.WSHost, cfg.XHTTPPath, cfg.Token, option)
			}
			if err != nil {
				t.Fatal(err)
			}
			defer conn.Close()
			_ = conn.SetDeadline(time.Now().Add(5 * time.Second))
			// Verify authenticated streaming survives the backend's finite
			// request-body timeout, instead of failing after ten seconds in use.
			time.Sleep(150 * time.Millisecond)
			payload := bytes.Repeat([]byte("bounded-http-stream\x00\xff"), 15000)
			written := make(chan error, 1)
			go func() {
				_, err := writeFull(conn, payload)
				if err == nil {
					err = flushXHTTPUploads(conn)
				}
				written <- err
			}()
			reply := make([]byte, len(payload))
			if _, err := io.ReadFull(conn, reply); err != nil {
				t.Fatal(err)
			}
			if err := <-written; err != nil || !bytes.Equal(payload, reply) {
				t.Fatalf("roundtrip/flush: %v equal=%t", err, bytes.Equal(payload, reply))
			}
			conn.Close()
			mu.Lock()
			defer mu.Unlock()
			if mode == "stream-one" && (len(methods) != 1 || methods[0] != "POST" || paths[0] != cfg.XHTTPPath+"/") {
				t.Fatalf("stream-one must use one POST: %v %v", methods, paths)
			}
			if mode == "stream-up" && (len(methods) != 2 || methods[0] != "GET" || methods[1] != "POST" || paths[0] != paths[1]) {
				t.Fatalf("stream-up must use GET + continuous POST: %v %v", methods, paths)
			}
		})
	}
}

func TestXHTTPStreamingDeliveryBarrierAndDeadline(t *testing.T) {
	for _, mode := range []string{"stream-up", "stream-one"} {
		t.Run(mode, func(t *testing.T) {
			cfg := &Config{Token: "stream-barrier-token", WSHost: "barrier.example.com", XHTTPPath: "/barrier", XHTTPMode: mode}
			accepted := make(chan net.Conn, 1)
			release := make(chan struct{})
			handler := newXHTTPServer(cfg, func(c net.Conn, _ string) { accepted <- c; <-release })
			defer handler.Close()
			defer close(release)
			rt, _ := xhttpTestHTTP(t, handler)
			conn, err := newXHTTPStreamClientConn(nil, rt, cfg.WSHost, cfg.XHTTPPath, cfg.Token, XHTTPOptions{Mode: mode})
			if err != nil {
				t.Fatal(err)
			}
			defer conn.Close()
			server := <-accepted
			_ = conn.SetWriteDeadline(time.Now().Add(time.Second))
			if _, err := conn.Write([]byte("final bytes")); err != nil {
				t.Fatal(err)
			}
			flushed := make(chan error, 1)
			go func() { flushed <- flushXHTTPUploads(conn) }()
			select {
			case err := <-flushed:
				t.Fatalf("flush returned before application received bytes: %v", err)
			case <-time.After(30 * time.Millisecond):
			}
			buf := make([]byte, len("final bytes"))
			if _, err := io.ReadFull(server, buf); err != nil || string(buf) != "final bytes" {
				t.Fatalf("delivery %q %v", buf, err)
			}
			if err := <-flushed; err != nil {
				t.Fatal(err)
			}
			if _, err := conn.Write([]byte("blocked")); err != nil {
				t.Fatal(err)
			}
			_ = conn.SetWriteDeadline(time.Now().Add(50 * time.Millisecond))
			if err := flushXHTTPUploads(conn); !errors.Is(err, os.ErrDeadlineExceeded) {
				t.Fatalf("expected adjustable delivery timeout: %v", err)
			}
		})
	}
}

func TestXHTTPStreamingRejectsWrongTokenAndMode(t *testing.T) {
	cfg := &Config{Token: "only-correct-stream-token", WSHost: "reject.example.com", XHTTPPath: "/reject", XHTTPMode: "packet-up"}
	handler := newXHTTPServer(cfg, func(c net.Conn, _ string) { t.Error("unexpected acceptance") })
	defer handler.Close()
	rt, _ := xhttpTestHTTP(t, handler)
	if conn, err := newXHTTPStreamClientConn(nil, rt, cfg.WSHost, cfg.XHTTPPath, cfg.Token, XHTTPOptions{Mode: "stream-one"}); err == nil {
		conn.Close()
		t.Fatal("mode mismatch accepted")
	}
	cfg.XHTTPMode = "auto"
	if conn, err := newXHTTPStreamClientConn(nil, rt, cfg.WSHost, cfg.XHTTPPath, "wrong-token", XHTTPOptions{Mode: "stream-one"}); err == nil {
		conn.Close()
		t.Fatal("wrong token accepted")
	}
}

func TestXHTTPStreamingH2TLSAndGDTAuthentication(t *testing.T) {
	const host = "stream-auth.example.com"
	dir := t.TempDir()
	cert, err := loadOrCreateCert(filepath.Join(dir, "test.crt"), filepath.Join(dir, "test.key"), host, false)
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(cert.Certificate[0])
	for _, mode := range []string{"stream-up", "stream-one"} {
		t.Run(mode, func(t *testing.T) {
			cfg := &Config{Transport: TransportXHTTP, Token: "stream-authentication-test-token", WSHost: host, SNI: host,
				XHTTPPath: "/stream/auth", XHTTPMode: mode, XHTTPPaddingBytes: "100-200", UTLSProfile: "chrome", ECHMode: ECHModeOff,
				Fingerprint: hex.EncodeToString(sum[:])}
			limiter := NewAdaptiveRateLimiter(10, 5)
			handler := newXHTTPServer(cfg, func(c net.Conn, ip string) { dispatchEgressConn(c, ip, cfg, limiter) })
			defer handler.Close()
			rawClient, rawServer := net.Pipe()
			defer rawClient.Close()
			defer rawServer.Close()
			_ = rawClient.SetDeadline(time.Now().Add(5 * time.Second))
			_ = rawServer.SetDeadline(time.Now().Add(5 * time.Second))
			serverDone := make(chan struct{})
			go func() {
				defer close(serverDone)
				tlsConn := tls.Server(rawServer, &tls.Config{Certificates: []tls.Certificate{cert}, MinVersion: tls.VersionTLS13, NextProtos: []string{"h2"}})
				if err := tlsConn.Handshake(); err != nil {
					t.Error(err)
					return
				}
				_ = rawServer.SetDeadline(time.Time{})
				(&http2.Server{}).ServeConn(tlsConn, &http2.ServeConnOpts{Handler: handler})
			}()
			transport, err := newOriginTransport(cfg)
			if err != nil {
				t.Fatal(err)
			}
			clientTLS := utls.UClient(rawClient, transport.utlsConfig.Clone(), transport.clientHello)
			if err := prepareHTTP2ClientHello(clientTLS); err != nil {
				t.Fatal(err)
			}
			if err := clientTLS.Handshake(); err != nil {
				t.Fatal(err)
			}
			conn, err := clientXHTTP(clientTLS, nil, cfg.WSHost, cfg.XHTTPPath, cfg.Token, XHTTPOptions{Mode: mode, PaddingBytes: cfg.XHTTPPaddingBytes})
			if err != nil {
				t.Fatal(err)
			}
			session, err := authenticateOriginSessionContext(context.Background(), conn, cfg, "memory-pipe", TransportXHTTP, 5*time.Second)
			if err != nil {
				conn.Close()
				t.Fatal(err)
			}
			if !session.authenticated.Load() {
				t.Fatal("UNUNKNOWNTUN challenge authentication did not complete")
			}
			session.Close()
			select {
			case <-serverDone:
			case <-time.After(time.Second):
				t.Fatal("HTTP/2 TLS connection leaked after close")
			}
		})
	}
}

func TestXHTTPStreamingMuxOffEarlyPeerFIN(t *testing.T) {
	for _, mode := range []string{"stream-up", "stream-one"} {
		t.Run(mode, func(t *testing.T) {
			type targetResult struct {
				body []byte
				err  error
			}
			received := make(chan targetResult, 1)
			target := managedTestListener(t, func(c net.Conn) {
				_ = c.(*net.TCPConn).SetReadBuffer(16 * 1024)
				_ = c.(*net.TCPConn).CloseWrite()
				_ = c.SetReadDeadline(time.Now().Add(5 * time.Second))
				body, err := io.ReadAll(c)
				received <- targetResult{body, err}
			})
			allow, err := ParseAllowList(target.Addr().String())
			if err != nil {
				t.Fatal(err)
			}
			cfg := &Config{Token: "stream-early-fin-token", WSHost: "stream-fin.example.com", XHTTPPath: "/stream-fin", XHTTPMode: mode, MuxMode: "off", allowList: allow}
			limiter := NewAdaptiveRateLimiter(10, 5)
			handler := newXHTTPServer(cfg, func(c net.Conn, ip string) { dispatchEgressConn(c, ip, cfg, limiter) })
			defer handler.Close()
			rt, _ := xhttpTestHTTP(t, handler)
			conn, err := newXHTTPStreamClientConn(nil, rt, cfg.WSHost, cfg.XHTTPPath, cfg.Token, XHTTPOptions{Mode: mode})
			if err != nil {
				t.Fatal(err)
			}
			session, err := authenticateOriginSessionContext(context.Background(), conn, cfg, "memory-http", TransportXHTTP, 2*time.Second)
			if err != nil {
				conn.Close()
				t.Fatal(err)
			}
			defer session.Close()
			session.singleStream.Store(true)
			client, edge := tcpTestPair(t)
			_ = edge.SetDeadline(time.Time{})
			stream, err := session.openStream(target.Addr().String(), edge)
			if err != nil {
				t.Fatal(err)
			}
			go func() {
				<-stream.ctx.Done()
				if stream.graceful.Load() {
					session.waitExclusivePeerCompletion()
				}
				session.Close()
			}()
			_ = client.SetDeadline(time.Now().Add(5 * time.Second))
			if _, err := io.ReadAll(client); err != nil {
				t.Fatal(err)
			}
			payload := bytes.Repeat([]byte("final-upload-after-peer-fin"), 10000)
			if _, err := writeFull(client, payload); err != nil {
				t.Fatal(err)
			}
			if err := client.CloseWrite(); err != nil {
				t.Fatal(err)
			}
			select {
			case result := <-received:
				if result.err != nil || !bytes.Equal(result.body, payload) {
					t.Fatalf("final upload truncated: got=%d want=%d err=%v", len(result.body), len(payload), result.err)
				}
			case <-time.After(6 * time.Second):
				t.Fatal("early-FIN upload did not finish")
			}
		})
	}
}

func TestXHTTPStreamingFinalUploadImmediateClose(t *testing.T) {
	for _, mode := range []string{"stream-up", "stream-one"} {
		t.Run(mode, func(t *testing.T) {
			payload := bytes.Repeat([]byte("no-socket-final-upload\x00"), 16000)
			received := make(chan []byte, 1)
			handler := newXHTTPServer(&Config{Token: "final-upload-test-token", WSHost: "final.example.com", XHTTPPath: "/final", XHTTPMode: mode},
				func(c net.Conn, _ string) {
					body, _ := io.ReadAll(c)
					received <- body
				})
			defer handler.Close()
			rt, _ := xhttpTestHTTP(t, handler)
			conn, err := newXHTTPStreamClientConn(nil, rt, "final.example.com", "/final", "final-upload-test-token", XHTTPOptions{Mode: mode})
			if err != nil {
				t.Fatal(err)
			}
			defer conn.Close()
			_ = conn.SetWriteDeadline(time.Now().Add(3 * time.Second))
			if _, err := writeFull(conn, payload); err != nil {
				t.Fatal(err)
			}
			if err := flushXHTTPUploads(conn); err != nil {
				t.Fatal(err)
			}
			conn.Close()
			select {
			case body := <-received:
				if !bytes.Equal(body, payload) {
					t.Fatalf("final bytes lost: %d/%d", len(body), len(payload))
				}
			case <-time.After(time.Second):
				t.Fatal("close did not release reader")
			}
		})
	}
}

func TestXHTTPStreamingPeerClosePreservesFinalAcknowledgement(t *testing.T) {
	for _, mode := range []string{"stream-up", "stream-one"} {
		t.Run(mode, func(t *testing.T) {
			payload := bytes.Repeat([]byte("peer-closes-after-payload"), 2000)
			handler := newXHTTPServer(&Config{Token: "peer-close-test-token", WSHost: "close.example.com", XHTTPPath: "/peer-close", XHTTPMode: mode},
				func(c net.Conn, _ string) {
					body := make([]byte, len(payload))
					if _, err := io.ReadFull(c, body); err != nil || !bytes.Equal(body, payload) {
						t.Errorf("payload corrupted: %v", err)
					}
				})
			defer handler.Close()
			rt, _ := xhttpTestHTTP(t, handler)
			conn, err := newXHTTPStreamClientConn(nil, rt, "close.example.com", "/peer-close", "peer-close-test-token", XHTTPOptions{Mode: mode})
			if err != nil {
				t.Fatal(err)
			}
			defer conn.Close()
			_ = conn.SetWriteDeadline(time.Now().Add(3 * time.Second))
			if _, err := writeFull(conn, payload); err != nil {
				t.Fatal(err)
			}
			if err := flushXHTTPUploads(conn); err != nil {
				t.Fatalf("final delivery ACK was lost: %v", err)
			}
		})
	}
}
