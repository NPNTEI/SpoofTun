package main

import (
	"bufio"
	"bytes"
	"context"
	"crypto/sha256"
	"crypto/tls"
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"net/http/httptrace"
	"net/url"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	utls "github.com/refraction-networking/utls"
	"golang.org/x/net/http2"
)

type xhttpTestRoundTripper func(*http.Request) (*http.Response, error)

func (f xhttpTestRoundTripper) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }

// Unit tests exercise the real net/http HTTP/1.1 server and transport over
// net.Pipe; they do not depend on permission to bind TCP sockets. The separate
// TLS integration test intentionally exercises actual loopback TCP + uTLS.
type xhttpTestListener struct {
	connections chan net.Conn
	done        chan struct{}
	once        sync.Once
}

func (l *xhttpTestListener) Accept() (net.Conn, error) {
	select {
	case c := <-l.connections:
		return c, nil
	case <-l.done:
		return nil, net.ErrClosed
	}
}
func (l *xhttpTestListener) Close() error   { l.once.Do(func() { close(l.done) }); return nil }
func (l *xhttpTestListener) Addr() net.Addr { return h2Addr("127.0.0.1:19843") }
func (l *xhttpTestListener) dial(ctx context.Context, _, _ string) (net.Conn, error) {
	client, server := net.Pipe()
	select {
	case l.connections <- server:
		return client, nil
	case <-ctx.Done():
		client.Close()
		server.Close()
		return nil, ctx.Err()
	case <-l.done:
		client.Close()
		server.Close()
		return nil, net.ErrClosed
	}
}

func xhttpTestHTTP(t *testing.T, handler http.Handler, readTimeout ...time.Duration) (http.RoundTripper, *httptest.Server) {
	t.Helper()
	listener := &xhttpTestListener{connections: make(chan net.Conn), done: make(chan struct{})}
	server := &httptest.Server{Listener: listener, Config: newXHTTPHTTPServer(handler)}
	if len(readTimeout) > 0 {
		server.Config.ReadTimeout = readTimeout[0]
	}
	server.Start()
	transport := &http.Transport{DialContext: listener.dial}
	t.Cleanup(func() { transport.CloseIdleConnections(); server.Close() })
	base, _ := url.Parse(server.URL)
	return xhttpTestRoundTripper(func(r *http.Request) (*http.Response, error) {
		clone := r.Clone(r.Context())
		clone.URL.Scheme, clone.URL.Host = base.Scheme, base.Host
		return transport.RoundTrip(clone)
	}), server
}

func TestXHTTPPacketUpWireRoundTrip(t *testing.T) {
	cfg := &Config{Token: "xhttp-test-token", WSHost: "tunnel.example.com", XHTTPPath: "/assets/xhttp"}
	handler := newXHTTPServer(cfg, func(c net.Conn, _ string) { _, _ = io.Copy(c, c) })
	t.Cleanup(handler.Close)
	var mu sync.Mutex
	var methods, paths []string
	rt, _ := xhttpTestHTTP(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if strings.Contains(strings.ToLower(r.Header.Get("Content-Type")), "grpc") {
			t.Error("XHTTP must not use gRPC headers")
		}
		mu.Lock()
		methods = append(methods, r.Method)
		paths = append(paths, r.URL.Path)
		mu.Unlock()
		handler.ServeHTTP(w, r)
	}))
	conn, err := newXHTTPClientConn(nil, rt, cfg.WSHost, cfg.XHTTPPath, cfg.Token)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(5 * time.Second))
	payload := bytes.Repeat([]byte("real-http-packet-up-no-grpc"), 10000)
	written := make(chan error, 1)
	go func() { _, err := conn.Write(payload); written <- err }()
	reply := make([]byte, len(payload))
	if _, err := io.ReadFull(conn, reply); err != nil {
		t.Fatal(err)
	}
	if err := <-written; err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(payload, reply) {
		t.Fatal("XHTTP data corruption")
	}
	mu.Lock()
	defer mu.Unlock()
	if len(methods) < 3 || methods[0] != http.MethodGet {
		t.Fatalf("expected GET then finite POSTs: %v", methods)
	}
	base := paths[0]
	seen := make(map[string]bool)
	for i := 1; i < len(methods); i++ {
		if methods[i] != http.MethodPost || !strings.HasPrefix(paths[i], base+"/") || seen[paths[i]] {
			t.Fatalf("bad/duplicate packet-up request %s %s", methods[i], paths[i])
		}
		seen[paths[i]] = true
	}
	for i := 0; i < len(methods)-1; i++ {
		if !seen[fmt.Sprintf("%s/%d", base, i)] {
			t.Fatalf("missing sequence %d", i)
		}
	}
	_ = conn.Close()
	select {
	case <-conn.pumpDone:
	case <-time.After(time.Second):
		t.Fatal("download pump leaked after close")
	}
}

func TestXHTTPServerRejectsAuthReplaySequenceAndOversize(t *testing.T) {
	cfg := &Config{Token: "xhttp-auth-token", WSHost: "tunnel.example.com", XHTTPPath: "/xhttp-test"}
	handler := newXHTTPServer(cfg, func(c net.Conn, _ string) { _, _ = io.Copy(io.Discard, c) })
	t.Cleanup(handler.Close)
	rt, _ := xhttpTestHTTP(t, handler)
	id, _ := newXHTTPID()
	base := cfg.XHTTPPath + "/" + id
	auth, _ := makeWebSocketAuthorization(cfg.Token, cfg.WSHost, base, time.Now())
	request := func(method, path, authorization string, body []byte) *http.Response {
		t.Helper()
		req, _ := http.NewRequest(method, "https://"+cfg.WSHost+path, bytes.NewReader(body))
		req.Host = cfg.WSHost
		req.Header.Set("Authorization", authorization)
		resp, err := rt.RoundTrip(req)
		if err != nil {
			t.Fatal(err)
		}
		return resp
	}
	bad := request(http.MethodGet, base, "Bearer invalid", nil)
	bad.Body.Close()
	if bad.StatusCode != http.StatusNotFound {
		t.Fatal("unauthenticated request accepted")
	}
	get := request(http.MethodGet, base, auth, nil)
	defer get.Body.Close()
	if get.StatusCode != http.StatusOK {
		t.Fatalf("valid GET: %d", get.StatusCode)
	}
	replay := request(http.MethodGet, base, auth, nil)
	replay.Body.Close()
	if replay.StatusCode != http.StatusNotFound {
		t.Fatalf("replayed GET accepted: %d", replay.StatusCode)
	}
	post := func(seq int, body []byte) int {
		path := fmt.Sprintf("%s/%d", base, seq)
		auth, _ := makeWebSocketAuthorization(cfg.Token, cfg.WSHost, path, time.Now())
		resp := request(http.MethodPost, path, auth, body)
		resp.Body.Close()
		return resp.StatusCode
	}
	if status := post(xhttpUploadWindow, []byte("outside-window")); status != http.StatusConflict {
		t.Fatalf("outside-window status=%d", status)
	}
	if status := post(0, bytes.Repeat([]byte{'x'}, xhttpMaxPostBytes+1)); status != http.StatusRequestEntityTooLarge {
		t.Fatalf("oversize status=%d", status)
	}
	if status := post(0, []byte("valid")); status != http.StatusOK {
		t.Fatalf("first upload status=%d", status)
	}
	if status := post(0, []byte("replayed")); status != http.StatusConflict {
		t.Fatalf("upload replay status=%d", status)
	}
	if status := post(1, []byte("still-valid")); status != http.StatusOK {
		t.Fatalf("rejected upload advanced sequence: %d", status)
	}
}

func xhttpTestPost(ctx context.Context, rt http.RoundTripper, cfg *Config, base string, seq uint64, body []byte) (int, error) {
	path := base + "/" + strconv.FormatUint(seq, 10)
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, "https://"+cfg.WSHost+path, bytes.NewReader(body))
	if err != nil {
		return 0, err
	}
	auth, err := makeWebSocketAuthorization(cfg.Token, cfg.WSHost, path, time.Now())
	if err != nil {
		return 0, err
	}
	req.Host = cfg.WSHost
	req.Header.Set("Authorization", auth)
	response, err := rt.RoundTrip(req)
	if err != nil {
		return 0, err
	}
	defer response.Body.Close()
	return response.StatusCode, nil
}

func xhttpWaitPending(t *testing.T, handler *xhttpServer, count int) {
	t.Helper()
	deadline := time.Now().Add(time.Second)
	for time.Now().Before(deadline) {
		ready := 0
		handler.mu.Lock()
		for _, session := range handler.sessions {
			session.uploadMu.Lock()
			for _, entry := range session.pending {
				if entry.ready {
					ready++
				}
			}
			session.uploadMu.Unlock()
		}
		handler.mu.Unlock()
		if ready == count {
			return
		}
		time.Sleep(time.Millisecond)
	}
	t.Fatalf("did not observe %d ready out-of-order bodies", count)
}

func TestXHTTPConcurrentReassemblyAndPendingReplay(t *testing.T) {
	cfg := &Config{Token: "reorder-token", WSHost: "reorder.example.com", XHTTPPath: "/reorder"}
	received := make(chan string, 1)
	handler := newXHTTPServer(cfg, func(c net.Conn, _ string) {
		body := make([]byte, 2)
		if _, err := io.ReadFull(c, body); err == nil {
			received <- string(body)
		}
		_, _ = io.Copy(io.Discard, c)
	})
	defer handler.Close()
	rt, _ := xhttpTestHTTP(t, handler)
	conn, err := newXHTTPClientConn(nil, rt, cfg.WSHost, cfg.XHTTPPath, cfg.Token)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	status1 := make(chan int, 1)
	go func() { status, _ := xhttpTestPost(ctx, rt, cfg, conn.path, 1, []byte("1")); status1 <- status }()
	xhttpWaitPending(t, handler, 1)
	// A buffered sequence must not be acknowledged or delivered across a gap.
	select {
	case status := <-status1:
		t.Fatalf("acknowledged a gap: %d", status)
	default:
	}
	select {
	case body := <-received:
		t.Fatalf("delivered out of order: %q", body)
	default:
	}
	if status, err := xhttpTestPost(ctx, rt, cfg, conn.path, 1, []byte("replay")); err != nil || status != http.StatusConflict {
		t.Fatalf("pending replay: status=%d err=%v", status, err)
	}
	if status, err := xhttpTestPost(ctx, rt, cfg, conn.path, xhttpUploadWindow, []byte("beyond-window")); err != nil || status != http.StatusConflict {
		t.Fatalf("receive window: status=%d err=%v", status, err)
	}
	if status, err := xhttpTestPost(ctx, rt, cfg, conn.path, 0, []byte("0")); err != nil || status != http.StatusOK {
		t.Fatalf("gap fill: status=%d err=%v", status, err)
	}
	if status := <-status1; status != http.StatusOK {
		t.Fatalf("reordered upload status=%d", status)
	}
	if body := <-received; body != "01" {
		t.Fatalf("reordered payload %q", body)
	}
	if status, err := xhttpTestPost(ctx, rt, cfg, conn.path, 0, []byte("replay")); err != nil || status != http.StatusConflict {
		t.Fatalf("delivered replay: status=%d err=%v", status, err)
	}
}

func TestXHTTPGapTimeoutAndBoundedReceiveWindow(t *testing.T) {
	cfg := &Config{Token: "gap-token", WSHost: "gap.example.com", XHTTPPath: "/gap-timeout"}
	handler := newXHTTPServer(cfg, func(c net.Conn, _ string) { _, _ = io.Copy(io.Discard, c) })
	handler.gapTimeout = 200 * time.Millisecond
	defer handler.Close()
	rt, _ := xhttpTestHTTP(t, handler)
	conn, err := newXHTTPClientConn(nil, rt, cfg.WSHost, cfg.XHTTPPath, cfg.Token)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	statuses := make(chan int, xhttpUploadWindow-1)
	for i := 1; i < xhttpUploadWindow; i++ {
		go func(seq uint64) {
			status, _ := xhttpTestPost(ctx, rt, cfg, conn.path, seq, make([]byte, xhttpMaxPostBytes))
			statuses <- status
		}(uint64(i))
	}
	xhttpWaitPending(t, handler, xhttpUploadWindow-1)
	if status, err := xhttpTestPost(ctx, rt, cfg, conn.path, xhttpUploadWindow, []byte("too-far")); err != nil || status != http.StatusConflict {
		t.Fatalf("receive window exceeded: status=%d err=%v", status, err)
	}
	for i := 1; i < xhttpUploadWindow; i++ {
		if status := <-statuses; status != http.StatusBadGateway {
			t.Fatalf("gap timeout status=%d", status)
		}
	}
	_ = conn.SetReadDeadline(time.Now().Add(time.Second))
	if _, err := conn.Read(make([]byte, 1)); err == nil {
		t.Fatal("gap timeout did not close download")
	}
}

func TestXHTTPPipelineLatencyAndSmallWrites(t *testing.T) {
	// A 50ms delayed HTTP response models a WAN request/response delay without
	// accessing a network. The serial baseline is 24*50ms. Small, serial Write
	// calls must still overlap requests; chunking only a giant Write is not enough.
	const requests = 24
	const delay = 50 * time.Millisecond
	cfg := &Config{Token: "latency-token", WSHost: "latency.example.com", XHTTPPath: "/latency"}
	handler := newXHTTPServer(cfg, func(c net.Conn, _ string) { _, _ = io.Copy(io.Discard, c) })
	defer handler.Close()
	backend, _ := xhttpTestHTTP(t, handler)
	var active, peak atomic.Int32
	acknowledged := make(chan struct{}, requests)
	rt := xhttpTestRoundTripper(func(r *http.Request) (*http.Response, error) {
		if r.Method == http.MethodGet {
			return backend.RoundTrip(r)
		}
		n := active.Add(1)
		defer active.Add(-1)
		for previous := peak.Load(); n > previous; previous = peak.Load() {
			if peak.CompareAndSwap(previous, n) {
				break
			}
		}
		response, err := backend.RoundTrip(r)
		if err != nil {
			return nil, err
		}
		timer := time.NewTimer(delay)
		defer timer.Stop()
		select {
		case <-timer.C:
			acknowledged <- struct{}{}
			return response, nil
		case <-r.Context().Done():
			response.Body.Close()
			return nil, r.Context().Err()
		}
	})
	conn, err := newXHTTPClientConn(nil, rt, cfg.WSHost, cfg.XHTTPPath, cfg.Token)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	_ = conn.SetWriteDeadline(time.Now().Add(3 * time.Second))
	start := time.Now()
	for i := 0; i < requests; i++ {
		if _, err := conn.Write([]byte{byte(i)}); err != nil {
			t.Fatal(err)
		}
	}
	for i := 0; i < requests; i++ {
		select {
		case <-acknowledged:
		case <-time.After(3 * time.Second):
			t.Fatal("pipeline made no progress")
		}
	}
	elapsed := time.Since(start)
	if peak.Load() < 2 || peak.Load() > xhttpUploadWindow {
		t.Fatalf("concurrency=%d, want 2..%d", peak.Load(), xhttpUploadWindow)
	}
	if elapsed >= requests*delay/2 {
		t.Fatalf("pipeline %s did not improve on serial baseline %s", elapsed, requests*delay)
	}
	t.Logf("%d small writes: %s with %d concurrent POSTs, serial-delay baseline %s", requests, elapsed, peak.Load(), requests*delay)
}

func TestXHTTPAsyncFailureCancelsPipelineWithoutRetry(t *testing.T) {
	getReader, getWriter := io.Pipe()
	defer getWriter.Close()
	var mu sync.Mutex
	seen := make(map[string]int)
	started := make(chan struct{}, xhttpUploadWindow)
	failNow := make(chan struct{})
	rt := xhttpTestRoundTripper(func(r *http.Request) (*http.Response, error) {
		if r.Method == http.MethodGet {
			return &http.Response{StatusCode: 200, Header: http.Header{"Content-Type": []string{"text/event-stream"}}, Body: getReader}, nil
		}
		mu.Lock()
		seen[r.URL.Path]++
		mu.Unlock()
		_, _ = io.Copy(io.Discard, r.Body)
		if trace := httptrace.ContextClientTrace(r.Context()); trace != nil && trace.WroteRequest != nil {
			trace.WroteRequest(httptrace.WroteRequestInfo{})
		}
		started <- struct{}{}
		if strings.HasSuffix(r.URL.Path, "/0") {
			<-failNow
			return &http.Response{StatusCode: 503, Body: io.NopCloser(strings.NewReader("secret-error-body"))}, nil
		}
		<-r.Context().Done()
		return nil, r.Context().Err()
	})
	conn, err := newXHTTPClientConn(nil, rt, "failure.example.com", "/failure", "token")
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	if _, err := conn.Write(make([]byte, xhttpUploadWindow*xhttpMaxPostBytes)); err != nil {
		t.Fatal(err)
	}
	for i := 0; i < xhttpUploadWindow; i++ {
		<-started
	}
	blocked := make(chan error, 1)
	go func() { _, err := conn.Write([]byte("backpressure")); blocked <- err }()
	close(failNow)
	select {
	case <-conn.uploadDone:
	case <-time.After(time.Second):
		t.Fatal("upload workers leaked after failure")
	}
	if _, err := conn.Read(make([]byte, 1)); err == nil || !strings.Contains(err.Error(), "HTTP 503") || strings.Contains(err.Error(), "secret-error-body") {
		t.Fatalf("lost/sensitive upload error: %v", err)
	}
	// The waiting write may win one newly released slot before failure closes
	// the stream, as with a socket buffer; every later write must report failure.
	<-blocked
	if _, err := conn.Write([]byte("after-failure")); err == nil || !strings.Contains(err.Error(), "HTTP 503") {
		t.Fatalf("subsequent write error: %v", err)
	}
	mu.Lock()
	defer mu.Unlock()
	for path, count := range seen {
		if count != 1 {
			t.Fatalf("uncertain upload retried: %s count=%d", path, count)
		}
	}
}

func TestXHTTPBodyEmissionOrderAndFlushBarrier(t *testing.T) {
	getReader, getWriter := io.Pipe()
	defer getWriter.Close()
	firstStarted := make(chan struct{})
	allowFirstBody := make(chan struct{})
	allowReplies := make(chan struct{})
	var mu sync.Mutex
	var emitted []string
	rt := xhttpTestRoundTripper(func(r *http.Request) (*http.Response, error) {
		if r.Method == http.MethodGet {
			return &http.Response{StatusCode: 200, Header: http.Header{"Content-Type": []string{"text/event-stream"}}, Body: getReader}, nil
		}
		if strings.HasSuffix(r.URL.Path, "/0") {
			close(firstStarted)
			select {
			case <-allowFirstBody:
			case <-r.Context().Done():
				return nil, r.Context().Err()
			}
		}
		body, _ := io.ReadAll(r.Body)
		mu.Lock()
		emitted = append(emitted, string(body))
		mu.Unlock()
		if trace := httptrace.ContextClientTrace(r.Context()); trace != nil && trace.WroteRequest != nil {
			trace.WroteRequest(httptrace.WroteRequestInfo{})
		}
		select {
		case <-allowReplies:
			return &http.Response{StatusCode: 200, Body: http.NoBody}, nil
		case <-r.Context().Done():
			return nil, r.Context().Err()
		}
	})
	conn, err := newXHTTPClientConn(nil, rt, "body-order.example.com", "/body-order", "token")
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	_ = conn.SetWriteDeadline(time.Now().Add(2 * time.Second))
	mutable := []byte("first")
	if _, err := conn.Write(mutable); err != nil {
		t.Fatal(err)
	}
	<-firstStarted
	copy(mutable, "WRONG") // Write must own a copy after returning.
	if _, err := conn.Write([]byte("second")); err != nil {
		t.Fatal(err)
	}
	mu.Lock()
	if len(emitted) != 0 {
		t.Errorf("later body emitted before first completed: %v", emitted)
	}
	mu.Unlock()
	flushed := make(chan error, 1)
	go func() { flushed <- flushXHTTPUploads(&trackedNetConn{Conn: conn}) }()
	close(allowFirstBody)
	deadline := time.Now().Add(time.Second)
	for {
		mu.Lock()
		count := len(emitted)
		mu.Unlock()
		if count == 2 {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("body pipeline stalled")
		}
		time.Sleep(time.Millisecond)
	}
	select {
	case err := <-flushed:
		t.Fatalf("flush returned before replies: %v", err)
	default:
	}
	close(allowReplies)
	if err := <-flushed; err != nil {
		t.Fatal(err)
	}
	mu.Lock()
	defer mu.Unlock()
	if strings.Join(emitted, ",") != "first,second" {
		t.Fatalf("body ownership/order broken: %v", emitted)
	}
}

func TestXHTTPFlushDeadlineClosesPendingUpload(t *testing.T) {
	reader, writer := io.Pipe()
	defer writer.Close()
	rt := xhttpTestRoundTripper(func(r *http.Request) (*http.Response, error) {
		if r.Method == http.MethodGet {
			return &http.Response{StatusCode: 200, Header: http.Header{"Content-Type": []string{"text/event-stream"}}, Body: reader}, nil
		}
		_, _ = io.Copy(io.Discard, r.Body)
		if trace := httptrace.ContextClientTrace(r.Context()); trace != nil && trace.WroteRequest != nil {
			trace.WroteRequest(httptrace.WroteRequestInfo{})
		}
		<-r.Context().Done()
		return nil, r.Context().Err()
	})
	conn, err := newXHTTPClientConn(nil, rt, "flush.example.com", "/flush", "token")
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	if _, err := conn.Write([]byte("final-data")); err != nil {
		t.Fatal(err)
	}
	_ = conn.SetWriteDeadline(time.Now().Add(30 * time.Millisecond))
	if err := conn.flushUploads(); !errors.Is(err, os.ErrDeadlineExceeded) {
		t.Fatalf("flush deadline error=%v", err)
	}
	select {
	case <-conn.uploadDone:
	case <-time.After(time.Second):
		t.Fatal("flush timeout leaked upload")
	}
}

func TestXHTTPDownloadFailurePreservesStageAndCause(t *testing.T) {
	reader, writer := io.Pipe()
	rt := xhttpTestRoundTripper(func(r *http.Request) (*http.Response, error) {
		return &http.Response{StatusCode: 200, Header: http.Header{"Content-Type": []string{"text/event-stream"}}, Body: reader}, nil
	})
	conn, err := newXHTTPClientConn(nil, rt, "download-error.example.com", "/download-error", "token")
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	cause := errors.New("simulated HTTP/2 stream reset")
	_ = writer.CloseWithError(cause)
	if _, err := conn.Read(make([]byte, 1)); !errors.Is(err, cause) || !strings.Contains(err.Error(), "[http-xhttp-download]") {
		t.Fatalf("download cause/stage lost: %v", err)
	}
}

func TestXHTTPDeadlineCancellationAndExtension(t *testing.T) {
	for _, operation := range []string{"read", "write", "extend-write"} {
		t.Run(operation, func(t *testing.T) {
			uploadStarted := make(chan struct{})
			var started sync.Once
			getReader, getWriter := io.Pipe()
			defer getWriter.Close()
			rt := xhttpTestRoundTripper(func(r *http.Request) (*http.Response, error) {
				if r.Method == http.MethodGet {
					return &http.Response{StatusCode: 200, Header: http.Header{"Content-Type": []string{"text/event-stream"}}, Body: getReader}, nil
				}
				_, _ = io.Copy(io.Discard, r.Body)
				if trace := httptrace.ContextClientTrace(r.Context()); trace != nil && trace.WroteRequest != nil {
					trace.WroteRequest(httptrace.WroteRequestInfo{})
				}
				started.Do(func() { close(uploadStarted) })
				<-r.Context().Done()
				return nil, r.Context().Err()
			})
			conn, err := newXHTTPClientConn(nil, rt, "example.com", "/deadline-test", "test-token")
			if err != nil {
				t.Fatal(err)
			}
			defer conn.Close()
			result := make(chan error, 1)
			if operation == "read" {
				_ = conn.SetReadDeadline(time.Now().Add(30 * time.Millisecond))
				go func() { _, err := conn.Read(make([]byte, 1)); result <- err }()
			} else {
				_ = conn.SetWriteDeadline(time.Now().Add(30 * time.Millisecond))
				// Fill all bounded transport slots; the ninth body blocks until
				// a response or the adjustable write deadline releases it.
				go func() { _, err := conn.Write(make([]byte, (xhttpUploadWindow+1)*xhttpMaxPostBytes)); result <- err }()
				<-uploadStarted
				if operation == "extend-write" {
					_ = conn.SetWriteDeadline(time.Time{})
					select {
					case err := <-result:
						t.Fatalf("cleared deadline fired: %v", err)
					case <-time.After(60 * time.Millisecond):
					}
					_ = conn.SetWriteDeadline(time.Now().Add(20 * time.Millisecond))
				}
			}
			select {
			case err := <-result:
				if !errors.Is(err, os.ErrDeadlineExceeded) {
					t.Fatalf("deadline error=%v", err)
				}
			case <-time.After(time.Second):
				t.Fatal("operation did not cancel on deadline")
			}
			_ = conn.Close()
			select {
			case <-conn.pumpDone:
			case <-time.After(time.Second):
				t.Fatal("read pump not cleaned up")
			}
		})
	}
}

func TestXHTTPGracefulDrainPreservesExistingUploads(t *testing.T) {
	cfg := &Config{Token: "xhttp-drain-token", WSHost: "drain.example.com", XHTTPPath: "/drain"}
	handler := newXHTTPServer(cfg, func(c net.Conn, _ string) { _, _ = io.Copy(c, c) })
	t.Cleanup(handler.Close)
	rt, _ := xhttpTestHTTP(t, handler)
	conn, err := newXHTTPClientConn(nil, rt, cfg.WSHost, cfg.XHTTPPath, cfg.Token)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(time.Second))
	handler.beginDrain()
	if other, err := newXHTTPClientConn(nil, rt, cfg.WSHost, cfg.XHTTPPath, cfg.Token); err == nil {
		other.Close()
		t.Fatal("draining backend accepted a new carrier")
	}
	payload := []byte("existing-client-can-still-finish")
	written := make(chan error, 1)
	go func() { _, err := conn.Write(payload); written <- err }()
	reply := make([]byte, len(payload))
	if _, err := io.ReadFull(conn, reply); err != nil {
		t.Fatal(err)
	}
	if err := <-written; err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(payload, reply) {
		t.Fatal("drain corrupted existing session")
	}
}

func TestXHTTPRejectedSlowBodyIsBounded(t *testing.T) {
	cfg := &Config{Token: "slow-body-token", WSHost: "slow.example.com", XHTTPPath: "/bounded-body"}
	handler := newXHTTPServer(cfg, nil)
	defer handler.Close()
	serverConfig := newXHTTPHTTPServer(handler)
	if serverConfig.ReadTimeout <= 0 {
		t.Fatal("backend has no body/read-drain timeout")
	}
	serverConfig.ReadTimeout = 40 * time.Millisecond
	listener := &xhttpTestListener{connections: make(chan net.Conn), done: make(chan struct{})}
	server := &httptest.Server{Listener: listener, Config: serverConfig}
	server.Start()
	defer server.Close()
	client, err := listener.dial(context.Background(), "tcp", "ignored")
	if err != nil {
		t.Fatal(err)
	}
	defer client.Close()
	_ = client.SetDeadline(time.Now().Add(time.Second))
	// Valid headers but a chunked body that never supplies even its first
	// chunk. Rejection must not leave net/http's implicit body drain blocked.
	if _, err := io.WriteString(client, "POST /not-a-tunnel HTTP/1.1\r\nHost: slow.example.com\r\nTransfer-Encoding: chunked\r\n\r\n"); err != nil {
		t.Fatal(err)
	}
	response, err := http.ReadResponse(bufio.NewReader(client), nil)
	if err != nil {
		t.Fatalf("rejected slow body did not finish within bound: %v", err)
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusNotFound {
		t.Fatalf("rejected request status=%d", response.StatusCode)
	}
}

func TestXHTTPDownloadSurvivesRequestReadTimeout(t *testing.T) {
	cfg := &Config{Token: "xhttp-long-download-token", WSHost: "long.example.com", XHTTPPath: "/long-download"}
	handler := newXHTTPServer(cfg, func(c net.Conn, _ string) { _, _ = io.Copy(c, c) })
	t.Cleanup(handler.Close)
	rt, _ := xhttpTestHTTP(t, handler, 20*time.Millisecond)
	conn, err := newXHTTPClientConn(nil, rt, cfg.WSHost, cfg.XHTTPPath, cfg.Token)
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(time.Second))
	time.Sleep(60 * time.Millisecond)
	written := make(chan error, 1)
	go func() { _, err := conn.Write([]byte("still-alive")); written <- err }()
	reply := make([]byte, len("still-alive"))
	if _, err := io.ReadFull(conn, reply); err != nil {
		t.Fatalf("request body timeout killed streamed GET: %v", err)
	}
	if err := <-written; err != nil {
		t.Fatal(err)
	}
	if string(reply) != "still-alive" {
		t.Fatalf("unexpected reply: %q", reply)
	}
}

func TestXHTTPCapacityAndMalformedPaths(t *testing.T) {
	if validXHTTPID("12345678-1234-1234-1234-1234567890--") {
		t.Fatal("accepted malformed UUID with extra separators")
	}
	for _, path := range []string{"", "/", "relative", "/a?b", "/a#b", "/a%2fb", "/a/../b", "/a//b", "/a\r\nb"} {
		if validateXHTTPPath(path) == nil {
			t.Errorf("accepted malformed path %q", path)
		}
	}
	cfg := &Config{Token: "capacity-token", WSHost: "example.com", XHTTPPath: "/capacity"}
	handler := newXHTTPServer(cfg, nil)
	for i := 0; i < MaxSessions; i++ {
		handler.sessions[fmt.Sprint(i)] = nil
	}
	id, _ := newXHTTPID()
	path := cfg.XHTTPPath + "/" + id
	auth, _ := makeWebSocketAuthorization(cfg.Token, cfg.WSHost, path, time.Now())
	req := httptest.NewRequest(http.MethodGet, "https://"+cfg.WSHost+path, nil)
	req.Header.Set("Authorization", auth)
	w := httptest.NewRecorder()
	handler.ServeHTTP(w, req)
	if w.Code != http.StatusServiceUnavailable {
		t.Fatalf("capacity status=%d", w.Code)
	}
}

func TestXHTTPLocalTLSAuthenticatedTunnel(t *testing.T) {
	const host, token = "xhttp.example.com", "xhttp-local-integration-token"
	target := managedTestListener(t, func(c net.Conn) { _, _ = io.Copy(c, c); _ = c.(*net.TCPConn).CloseWrite() })
	allow, err := ParseAllowList(target.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	dir := t.TempDir()
	cert, err := loadOrCreateCert(filepath.Join(dir, "test.crt"), filepath.Join(dir, "test.key"), host, false)
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(cert.Certificate[0])
	cfg := &Config{Transport: TransportXHTTP, Token: token, WSHost: host, SNI: host,
		XHTTPPath: "/assets/integration", XHTTPMode: "packet-up", UTLSProfile: "chrome", ECHMode: ECHModeOff,
		Fingerprint: hex.EncodeToString(sum[:]), allowList: allow}
	limiter := NewAdaptiveRateLimiter(10, 5)
	handler := newXHTTPServer(cfg, func(c net.Conn, ip string) { dispatchEgressConn(c, ip, cfg, limiter) })
	t.Cleanup(handler.Close)
	server := managedTestListener(t, func(c net.Conn) {
		tlsConn := tls.Server(c, &tls.Config{Certificates: []tls.Certificate{cert}, MinVersion: tls.VersionTLS13, NextProtos: []string{"h2"}})
		if err := tlsConn.Handshake(); err != nil {
			return
		}
		(&http2.Server{}).ServeConn(tlsConn, &http2.ServeConnOpts{Handler: handler})
	})
	transport, err := newOriginTransport(cfg)
	if err != nil {
		t.Fatal(err)
	}
	conn, label, err := transport.dial(server.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	sess, err := authenticateOriginSessionContext(context.Background(), conn, cfg, server.Addr().String(), label, 5*time.Second)
	if err != nil {
		conn.Close()
		t.Fatal(err)
	}
	defer sess.Close()
	client, edge := tcpTestPair(t)
	_ = edge.SetDeadline(time.Time{})
	if err := sess.OpenStream(target.Addr().String(), edge); err != nil {
		t.Fatal(err)
	}
	payload := bytes.Repeat([]byte("authenticated-xhttp-echo"), 5000)
	written := make(chan error, 1)
	go func() { _, err := writeFull(client, payload); written <- err }()
	reply := make([]byte, len(payload))
	if _, err := io.ReadFull(client, reply); err != nil {
		t.Fatal(err)
	}
	if err := <-written; err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(payload, reply) {
		t.Fatal("authenticated tunnel data corrupted")
	}
	if err := client.CloseWrite(); err != nil {
		t.Fatal(err)
	}
	if extra, err := io.ReadAll(client); err != nil || len(extra) != 0 {
		t.Fatalf("half close extra=%d err=%v", len(extra), err)
	}
}

func TestXHTTPLocalMuxOffEarlyPeerFIN(t *testing.T) {
	// The target half-closes its output first, but still accepts an upload.
	// Releasing a dedicated carrier when the origin has merely enqueued its
	// final FIN can drop that upload before the egress drains it to the target.
	type targetResult struct {
		body []byte
		err  error
	}
	received := make(chan targetResult, 1)
	target := managedTestListener(t, func(c net.Conn) {
		_ = c.(*net.TCPConn).SetReadBuffer(16 * 1024)
		_ = c.(*net.TCPConn).CloseWrite()
		_ = c.SetReadDeadline(time.Now().Add(5 * time.Second))
		body, err := io.ReadAll(c)
		received <- targetResult{body: body, err: err}
	})
	allow, err := ParseAllowList(target.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	cfg := &Config{Token: "early-fin-token", WSHost: "early-fin.example.com", XHTTPPath: "/early-fin", MuxMode: "off", allowList: allow}
	limiter := NewAdaptiveRateLimiter(10, 5)
	handler := newXHTTPServer(cfg, func(c net.Conn, ip string) { dispatchEgressConn(c, ip, cfg, limiter) })
	defer handler.Close()
	rt, _ := xhttpTestHTTP(t, handler)
	conn, err := newXHTTPClientConn(nil, rt, cfg.WSHost, cfg.XHTTPPath, cfg.Token)
	if err != nil {
		t.Fatal(err)
	}
	session, err := authenticateOriginSessionContext(context.Background(), conn, cfg, "memory-http", TransportXHTTP, 2*time.Second)
	if err != nil {
		conn.Close()
		t.Fatal(err)
	}
	defer session.Close()
	session.singleStream.Store(true)
	client, edge := tcpTestPair(t)
	_ = edge.SetDeadline(time.Time{})
	stream, err := session.openStream(target.Addr().String(), edge)
	if err != nil {
		t.Fatal(err)
	}
	// Match runOrigin's MUX-off release condition.
	go func() {
		<-stream.ctx.Done()
		if stream.graceful.Load() {
			session.waitExclusivePeerCompletion()
		}
		session.Close()
	}()
	_ = client.SetDeadline(time.Now().Add(5 * time.Second))
	if _, err := io.ReadAll(client); err != nil {
		t.Fatal(err)
	}
	payload := bytes.Repeat([]byte("final-upload-after-peer-fin"), 10000)
	if _, err := writeFull(client, payload); err != nil {
		t.Fatal(err)
	}
	if err := client.CloseWrite(); err != nil {
		t.Fatal(err)
	}
	select {
	case result := <-received:
		if result.err != nil || !bytes.Equal(result.body, payload) {
			t.Fatalf("final upload truncated: got=%d want=%d err=%v", len(result.body), len(payload), result.err)
		}
	case <-time.After(6 * time.Second):
		t.Fatal("early-FIN upload did not finish")
	}
}

func TestXHTTPPipeTLSAndGDTAuthentication(t *testing.T) {
	// This complements (does not replace) the real TCP-target integration test
	// and remains runnable when the host denies loopback socket binding.
	const host = "xhttp-auth.example.com"
	dir := t.TempDir()
	cert, err := loadOrCreateCert(filepath.Join(dir, "test.crt"), filepath.Join(dir, "test.key"), host, false)
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(cert.Certificate[0])
	for _, fragment := range []string{"off", "hello"} {
		t.Run(fragment, func(t *testing.T) {
			cfg := &Config{Transport: TransportXHTTP, Token: "authenticated-in-memory-xhttp-token", WSHost: host, SNI: host,
				XHTTPPath: "/pipe/auth", XHTTPMode: "packet-up", UTLSProfile: "chrome", ECHMode: ECHModeOff,
				Fingerprint: hex.EncodeToString(sum[:]), TLSFragment: fragment, TLSFragmentSize: "100-200", TLSFragmentInterval: "0ms"}
			limiter := NewAdaptiveRateLimiter(10, 5)
			handler := newXHTTPServer(cfg, func(c net.Conn, ip string) { dispatchEgressConn(c, ip, cfg, limiter) })
			defer handler.Close()
			rawClient, rawServer := net.Pipe()
			defer rawClient.Close()
			defer rawServer.Close()
			_ = rawClient.SetDeadline(time.Now().Add(5 * time.Second))
			_ = rawServer.SetDeadline(time.Now().Add(5 * time.Second))
			serverDone := make(chan struct{})
			serverErrors := make(chan error, 1)
			go func() {
				defer close(serverDone)
				tlsConn := tls.Server(rawServer, &tls.Config{Certificates: []tls.Certificate{cert}, MinVersion: tls.VersionTLS13, NextProtos: []string{"h2"}})
				if err := tlsConn.Handshake(); err != nil {
					serverErrors <- err
					return
				}
				_ = rawServer.SetDeadline(time.Time{})
				(&http2.Server{}).ServeConn(tlsConn, &http2.ServeConnOpts{Handler: handler})
			}()
			transport, err := newOriginTransport(cfg)
			if err != nil {
				t.Fatal(err)
			}
			wrapped := wrapTLSClientHello(rawClient, cfg)
			_ = wrapped.SetDeadline(time.Now().Add(5 * time.Second))
			clientTLS := utls.UClient(wrapped, transport.utlsConfig.Clone(), transport.clientHello)
			if err := prepareHTTP2ClientHello(clientTLS); err != nil {
				t.Fatal(err)
			}
			if err := clientTLS.Handshake(); err != nil {
				t.Fatal(err)
			}
			conn, err := clientXHTTP(clientTLS, nil, cfg.WSHost, cfg.XHTTPPath, cfg.Token)
			if err != nil {
				t.Fatal(err)
			}
			session, err := authenticateOriginSessionContext(context.Background(), conn, cfg, "memory-pipe", TransportXHTTP, 5*time.Second)
			if err != nil {
				conn.Close()
				t.Fatal(err)
			}
			if !session.authenticated.Load() {
				t.Fatal("UNUNKNOWNTUN challenge authentication did not complete")
			}
			session.Close()
			select {
			case <-serverDone:
			case <-time.After(time.Second):
				t.Fatal("HTTP/2 TLS connection leaked after close")
			}
			select {
			case err := <-serverErrors:
				t.Fatal(err)
			default:
			}
		})
	}
}
